-- ==============================================================================
-- 22. AD-HOC AND CROSS-GROUP CONVERSATIONS (CHAT & VIDEO)
-- Explicit participant list, independent of ministry/group membership
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT NOT NULL CHECK (type IN ('direct', 'ad_hoc_group', 'video')),
    title TEXT,
    created_by TEXT NOT NULL,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at TIMESTAMPTZ,
    CONSTRAINT chk_conversation_title CHECK (
        (type = 'direct') OR (title IS NOT NULL AND length(trim(title)) > 0)
    )
);

CREATE TABLE IF NOT EXISTS public.conversation_participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    added_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    left_at TIMESTAMPTZ,
    UNIQUE (conversation_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.conversation_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_conversations_tenant_status ON public.conversations (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_conversations_created_by ON public.conversations (created_by);
CREATE INDEX IF NOT EXISTS idx_conversation_participants_user_active ON public.conversation_participants (user_id, conversation_id) WHERE left_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_conversation_participants_lookup ON public.conversation_participants (conversation_id, user_id);
CREATE INDEX IF NOT EXISTS idx_conversation_messages_conv_created ON public.conversation_messages (conversation_id, created_at DESC);

-- Enable RLS
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_messages ENABLE ROW LEVEL SECURITY;

-- Conversations RLS
CREATE POLICY "Conversations select policy" ON public.conversations
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            EXISTS (
                SELECT 1 FROM public.conversation_participants cp
                WHERE cp.conversation_id = conversations.id
                AND cp.user_id = auth.uid()::text
                AND cp.left_at IS NULL
            )
            OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
        )
    );

CREATE POLICY "Conversations insert policy" ON public.conversations
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
    );

CREATE POLICY "Conversations update policy" ON public.conversations
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            created_by = auth.uid()::text
            OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
        )
    );

-- Conversation Participants RLS
CREATE POLICY "Conversation participants select policy" ON public.conversation_participants
    FOR SELECT TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.conversations c
            WHERE c.id = conversation_participants.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND (
                EXISTS (
                    SELECT 1 FROM public.conversation_participants my_cp
                    WHERE my_cp.conversation_id = c.id
                    AND my_cp.user_id = auth.uid()::text
                    AND my_cp.left_at IS NULL
                )
                OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            )
        )
    );

CREATE POLICY "Conversation participants insert policy" ON public.conversation_participants
    FOR INSERT TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.conversations c
            WHERE c.id = conversation_participants.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND (
                c.created_by = auth.uid()::text
                OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            )
        )
    );

CREATE POLICY "Conversation participants update policy" ON public.conversation_participants
    FOR UPDATE TO authenticated
    USING (
        user_id = auth.uid()::text
        OR EXISTS (
            SELECT 1 FROM public.conversations c
            WHERE c.id = conversation_participants.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND (
                c.created_by = auth.uid()::text
                OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            )
        )
    );

-- Conversation Messages RLS
CREATE POLICY "Conversation messages select policy" ON public.conversation_messages
    FOR SELECT TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.conversations c
            JOIN public.conversation_participants cp ON cp.conversation_id = c.id
            WHERE c.id = conversation_messages.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND cp.user_id = auth.uid()::text
            AND cp.left_at IS NULL
        )
    );

CREATE POLICY "Conversation messages insert policy" ON public.conversation_messages
    FOR INSERT TO authenticated
    WITH CHECK (
        sender_id = auth.uid()::text
        AND EXISTS (
            SELECT 1 FROM public.conversations c
            JOIN public.conversation_participants cp ON cp.conversation_id = c.id
            WHERE c.id = conversation_messages.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND cp.user_id = auth.uid()::text
            AND cp.left_at IS NULL
            AND c.status = 'active'
        )
    );
