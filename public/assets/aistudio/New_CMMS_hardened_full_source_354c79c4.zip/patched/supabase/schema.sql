-- ==============================================================================
-- CHURCH MEMBER MANAGEMENT SYSTEM (CMMS) - SUPABASE POSTGRESQL SCHEMA & RLS
-- Complete Production Authoritative Security Boundary & Multi-Tenant RLS
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- 2. CORE MULTI-TENANT INFRASTRUCTURE
-- ==============================================================================

-- TENANTS (Multi-tenant root container)
CREATE TABLE IF NOT EXISTS public.tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'Active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- BRANCHES / CAMPUSES (Multi-branch structure within a tenant)
CREATE TABLE IF NOT EXISTS public.branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    city TEXT,
    phone TEXT,
    status TEXT NOT NULL DEFAULT 'Active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

-- ==============================================================================
-- 3. IDENTITY & PROFILES (Linked to Supabase Auth auth.users)
-- Authoritative source of tenant, branch, role, and permissions
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE RESTRICT,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    role TEXT NOT NULL DEFAULT 'REGULAR_MEMBER' CHECK (
        role IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER')
    ),
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Suspended', 'Inactive')),
    display_name TEXT,
    member_id TEXT,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    must_change_password BOOLEAN NOT NULL DEFAULT false,
    mfa_enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 4. MEMBERS & DIRECTORY
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
    member_number TEXT NOT NULL,
    first_name TEXT NOT NULL,
    middle_name TEXT,
    last_name TEXT NOT NULL,
    gender TEXT NOT NULL CHECK (gender IN ('Male', 'Female')),
    marital_status TEXT DEFAULT 'Single',
    date_of_birth DATE,
    phone TEXT,
    email TEXT,
    address TEXT,
    city TEXT,
    membership_status TEXT NOT NULL DEFAULT 'Active' CHECK (
        membership_status IN ('Active', 'UnderCare', 'Transferred', 'Disciplined', 'Deceased', 'Inactive')
    ),
    fellowship_group TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, member_number)
);

-- ==============================================================================
-- 5. FAMILIES & HOUSEHOLDS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.families (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    family_code TEXT NOT NULL,
    household_name TEXT NOT NULL,
    head_member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    primary_phone TEXT,
    family_type TEXT DEFAULT 'Nuclear Family',
    primary_language TEXT DEFAULT 'Amharic',
    address TEXT,
    city TEXT,
    region TEXT DEFAULT 'Addis Ababa',
    member_ids JSONB DEFAULT '[]'::jsonb,
    relationships JSONB DEFAULT '[]'::jsonb,
    status TEXT DEFAULT 'Active',
    total_giving NUMERIC(12, 2) DEFAULT 0.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, family_code)
);

-- ==============================================================================
-- 6. MINISTRIES & DEPARTMENTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.ministries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'General',
    leader_name TEXT,
    leader_member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    meeting_day TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ministry Members roster
CREATE TABLE IF NOT EXISTS public.ministry_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ministry_id UUID NOT NULL REFERENCES public.ministries(id) ON DELETE CASCADE,
    member_id UUID NOT NULL REFERENCES public.members(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'Member' CHECK (role IN ('Leader', 'Director', 'Coordinator', 'Chairperson', 'Member', 'Volunteer')),
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (ministry_id, member_id)
);

-- ==============================================================================
-- 7. GROUPS (Small Groups, Fellowship Cells & Bible Study Units)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'Cell Group',
    leader_name TEXT,
    leader_member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    meeting_schedule TEXT,
    location TEXT,
    member_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 8. ATTENDANCE & SESSIONS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.attendance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
    event_name TEXT NOT NULL,
    service_type TEXT NOT NULL,
    member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    visitor_name TEXT,
    visitor_phone TEXT,
    checkin_method TEXT DEFAULT 'Manual Web Click' CHECK (checkin_method IN ('Manual Web Click', 'QR Code Scanning')),
    checkin_time TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Attendance table alias / canonical table for direct check-in records
CREATE TABLE IF NOT EXISTS public.attendance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
    event_id UUID,
    service_type TEXT NOT NULL DEFAULT 'Sunday Service',
    member_id UUID REFERENCES public.members(id) ON DELETE CASCADE,
    check_in_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    verified_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    method TEXT DEFAULT 'QR_CODE' CHECK (method IN ('QR_CODE', 'MANUAL', 'SELF_CHECKIN', 'FACIAL_ID')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 9. EVENTS & CONFERENCES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL DEFAULT 'Conference',
    start_date TIMESTAMPTZ NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    location TEXT NOT NULL,
    description TEXT,
    speakers TEXT[] DEFAULT '{}',
    capacity INTEGER DEFAULT 500,
    registered_count INTEGER DEFAULT 0,
    is_paid BOOLEAN DEFAULT false,
    ticket_price NUMERIC(10, 2) DEFAULT 0.00,
    status TEXT DEFAULT 'Upcoming',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 10. FINANCIAL TRANSACTIONS & LEDGER
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.financial_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
    member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'ETB',
    transaction_type TEXT NOT NULL DEFAULT 'INCOME',
    contribution_type TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    reference_number TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Completed',
    notes TEXT,
    recorded_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, reference_number)
);

-- ==============================================================================
-- 11. DONATIONS (Tithes, Offerings & Pledges)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.donations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    donor_name TEXT,
    donor_email TEXT,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'ETB',
    category TEXT NOT NULL DEFAULT 'Tithe',
    payment_method TEXT NOT NULL DEFAULT 'Telebirr',
    gateway_reference TEXT,
    status TEXT NOT NULL DEFAULT 'Completed',
    is_anonymous BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 12. PASTORAL CARE & PASTORAL RECORDS
-- Contains sensitive pastoral visitations, member care, and ministerial notes
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.pastoral_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
    member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    counselor_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    category TEXT NOT NULL,
    confidentiality TEXT NOT NULL DEFAULT 'MINISTERIAL' CHECK (
        confidentiality IN ('CONFIDENTIAL', 'SEALED', 'MINISTERIAL', 'GENERAL')
    ),
    summary TEXT NOT NULL,
    details TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Open',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 13. PRAYER REQUESTS
-- Confidential personal prayers vs. community intercession
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.prayer_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    request_number TEXT NOT NULL,
    member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    requester_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    requester_name TEXT NOT NULL,
    category TEXT DEFAULT 'Spiritual Concern',
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    is_confidential BOOLEAN NOT NULL DEFAULT false,
    urgency TEXT DEFAULT 'Medium',
    status TEXT DEFAULT 'Pending',
    assigned_intercessor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    testimony_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, request_number)
);

-- ==============================================================================
-- 14. COUNSELING SESSIONS (Highly Confidential Ecclesiastical Records)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.counseling (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    session_code TEXT NOT NULL,
    client_member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    client_name TEXT NOT NULL,
    counselor_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    counselor_name TEXT NOT NULL,
    counseling_type TEXT NOT NULL DEFAULT 'Individual',
    session_date TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL DEFAULT 'Scheduled',
    confidentiality TEXT NOT NULL DEFAULT 'CONFIDENTIAL' CHECK (
        confidentiality IN ('CONFIDENTIAL', 'SEALED', 'GENERAL')
    ),
    private_clinical_notes TEXT,
    action_items TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, session_code)
);

-- ==============================================================================
-- 15. DOCUMENTS & POLICIES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    file_format TEXT DEFAULT 'PDF',
    file_size_mb NUMERIC(6, 2) DEFAULT 1.0,
    uploaded_by TEXT,
    version TEXT DEFAULT 'v1.0',
    is_confidential BOOLEAN DEFAULT false,
    tags TEXT[] DEFAULT '{}',
    download_count INTEGER DEFAULT 0,
    file_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 16. WORKFLOWS & APPROVAL REQUESTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.workflow_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    request_code TEXT NOT NULL,
    request_type TEXT NOT NULL,
    requester_name TEXT NOT NULL,
    requester_phone TEXT,
    requester_email TEXT,
    branch_name TEXT,
    details TEXT NOT NULL,
    amount_requested NUMERIC(12, 2),
    current_step TEXT DEFAULT 'Submitted for Review',
    assigned_role TEXT DEFAULT 'BRANCH_PASTOR',
    status TEXT DEFAULT 'Pending',
    comments TEXT,
    approved_by TEXT,
    approved_at TIMESTAMPTZ,
    rejected_reason TEXT,
    decision_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, request_code)
);

-- ==============================================================================
-- 17. VOLUNTEER SHIFTS & ASSETS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.volunteer_shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    volunteer_member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
    volunteer_name TEXT NOT NULL,
    ministry_id UUID REFERENCES public.ministries(id) ON DELETE SET NULL,
    ministry_name TEXT,
    role_title TEXT NOT NULL,
    shift_date DATE NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    status TEXT DEFAULT 'Scheduled',
    hours_logged NUMERIC(5, 2) DEFAULT 4.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
    asset_code TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    custodian_name TEXT,
    purchase_date DATE,
    purchase_price NUMERIC(12, 2) DEFAULT 0.00,
    current_value NUMERIC(12, 2) DEFAULT 0.00,
    condition TEXT DEFAULT 'Good',
    next_maintenance DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, asset_code)
);

-- ==============================================================================
-- 18. LMS COURSES & REALTIME CHATS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.lms_courses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    course_code TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT DEFAULT 'Discipleship & Foundations',
    instructor_name TEXT,
    description TEXT,
    total_modules INTEGER DEFAULT 8,
    duration_weeks INTEGER DEFAULT 6,
    enrolled_count INTEGER DEFAULT 0,
    pass_percentage NUMERIC(5, 2) DEFAULT 80.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, course_code)
);

CREATE TABLE IF NOT EXISTS public.group_chats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    ministry_id UUID NOT NULL REFERENCES public.ministries(id) ON DELETE CASCADE,
    leader_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS public.video_conferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    ministry_id UUID NOT NULL REFERENCES public.ministries(id) ON DELETE CASCADE,
    leader_profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT 'Group Live Session',
    room_url TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 19. AUDIT LOGS (Immutable System Security & Action Trail)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    user_email TEXT,
    user_name TEXT,
    user_role TEXT,
    action TEXT NOT NULL,
    module TEXT NOT NULL,
    details TEXT NOT NULL,
    ip_address TEXT,
    location TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==============================================================================
-- 20. SECURITY HELPER FUNCTIONS
-- All declared with SECURITY DEFINER and SET search_path = public, pg_temp;
-- to guarantee immunity against search_path hijacking and privilege escalation.
-- ==============================================================================

-- Current Profile Resolution
CREATE OR REPLACE FUNCTION public.get_current_profile()
RETURNS public.profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    current_prof public.profiles;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT * INTO current_prof
    FROM public.profiles
    WHERE id = auth.uid() OR user_id = auth.uid()
    LIMIT 1;

    RETURN current_prof;
END;
$$;

-- Current Tenant Resolution
CREATE OR REPLACE FUNCTION public.get_current_tenant_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT tenant_id FROM public.profiles WHERE id = auth.uid() OR user_id = auth.uid() LIMIT 1;
$$;

-- Current Branch Resolution
CREATE OR REPLACE FUNCTION public.get_current_branch_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT branch_id FROM public.profiles WHERE id = auth.uid() OR user_id = auth.uid() LIMIT 1;
$$;

-- Current Role Resolution
CREATE OR REPLACE FUNCTION public.get_current_role()
RETURNS TEXT
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT COALESCE(role, 'REGULAR_MEMBER') FROM public.profiles WHERE id = auth.uid() OR user_id = auth.uid() LIMIT 1;
$$;

-- Current Member ID Resolution (maps profile to members directory record)
CREATE OR REPLACE FUNCTION public.get_current_member_id()
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    v_member_id UUID;
    v_prof_member_id TEXT;
    v_prof_email TEXT;
    v_tenant_id UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT member_id, email, tenant_id INTO v_prof_member_id, v_prof_email, v_tenant_id
    FROM public.profiles WHERE id = auth.uid() OR user_id = auth.uid() LIMIT 1;

    IF v_prof_member_id IS NOT NULL AND v_prof_member_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN
        RETURN v_prof_member_id::uuid;
    END IF;

    IF v_prof_email IS NOT NULL AND v_tenant_id IS NOT NULL THEN
        SELECT id INTO v_member_id FROM public.members
        WHERE tenant_id = v_tenant_id AND lower(email) = lower(v_prof_email)
        LIMIT 1;
        IF v_member_id IS NOT NULL THEN
            RETURN v_member_id;
        END IF;
    END IF;

    RETURN NULL;
END;
$$;

-- Branch Access Verification
CREATE OR REPLACE FUNCTION public.can_access_branch(target_branch_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
    u_branch UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();
    -- Multi-campus System Admins and Executive Managers have multi-branch access within tenant
    IF u_role IN ('SYSTEM_ADMIN', 'MANAGER') THEN
        RETURN true;
    END IF;

    u_branch := public.get_current_branch_id();
    IF target_branch_id IS NULL OR target_branch_id = u_branch THEN
        RETURN true;
    END IF;

    RETURN false;
END;
$$;

-- Ministry Leadership Verification (Prevents Ministry leader -> unrelated ministry records)
CREATE OR REPLACE FUNCTION public.is_leader_of_ministry(target_ministry_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
    u_member_id UUID;
    u_tenant_id UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();
    IF u_role IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR') THEN
        RETURN true;
    END IF;

    IF u_role <> 'MINISTRY_LEADER' THEN
        RETURN false;
    END IF;

    u_member_id := public.get_current_member_id();
    u_tenant_id := public.get_current_tenant_id();

    IF u_member_id IS NULL THEN
        RETURN false;
    END IF;

    RETURN EXISTS (
        SELECT 1 FROM public.ministry_members mm
        JOIN public.ministries m ON m.id = mm.ministry_id
        WHERE mm.ministry_id = target_ministry_id
          AND m.tenant_id = u_tenant_id
          AND mm.member_id = u_member_id
          AND mm.role IN ('Leader', 'Director', 'Coordinator', 'Chairperson')
    );
END;
$$;

-- Ministry Membership Verification
CREATE OR REPLACE FUNCTION public.is_member_of_ministry(target_ministry_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_member_id UUID;
    u_tenant_id UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    IF public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR') THEN
        RETURN true;
    END IF;

    u_member_id := public.get_current_member_id();
    u_tenant_id := public.get_current_tenant_id();

    IF u_member_id IS NULL THEN
        RETURN false;
    END IF;

    RETURN EXISTS (
        SELECT 1 FROM public.ministry_members mm
        JOIN public.ministries m ON m.id = mm.ministry_id
        WHERE mm.ministry_id = target_ministry_id
          AND m.tenant_id = u_tenant_id
          AND mm.member_id = u_member_id
    );
END;
$$;

-- Small Group Leadership Verification
CREATE OR REPLACE FUNCTION public.is_leader_of_group(target_group_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
    u_member_id UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();
    IF u_role IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR') THEN
        RETURN true;
    END IF;

    u_member_id := public.get_current_member_id();
    IF u_member_id IS NULL THEN
        RETURN false;
    END IF;

    RETURN EXISTS (
        SELECT 1 FROM public.groups g
        WHERE g.id = target_group_id
          AND g.tenant_id = public.get_current_tenant_id()
          AND g.leader_member_id = u_member_id
    );
END;
$$;

-- ==============================================================================
-- SPECIAL SECURITY RULE: PASTORAL & COUNSELING CONFIDENTIALITY BOUNDARY
-- By ecclesiastical privacy mandate:
-- SYSTEM_ADMINISTRATORS do NOT automatically receive unrestricted access to
-- confidential pastoral counseling, private confessions, or sealed ministerial records.
-- Only the designated PASTOR or the assigned COUNSELOR holds access.
-- The function public.has_pastoral_confidential_override() defaults strictly to FALSE.
-- Any administrative diagnostic override must be explicitly authorized, documented,
-- and will trigger an immutable security audit alert.
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.has_pastoral_confidential_override()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    -- Explicit architectural boundary: Defaults to FALSE.
    -- Prevents SYSTEM_ADMIN from automatically receiving unrestricted pastoral access.
    SELECT false;
$$;

-- Centralized RBAC Permission Evaluator
CREATE OR REPLACE FUNCTION public.has_permission(required_permission TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();

    -- SYSTEM_ADMIN administrative permissions
    -- NOTE: Explicitly excludes confidential pastoral care override!
    IF u_role = 'SYSTEM_ADMIN' THEN
        IF required_permission IN ('pastoral.confidential', 'counseling.confidential_notes') THEN
            RETURN public.has_pastoral_confidential_override();
        END IF;
        RETURN true;
    END IF;

    -- MANAGER Permissions
    IF u_role = 'MANAGER' THEN
        RETURN required_permission IN (
            'members.read', 'members.create', 'members.update', 'members.export',
            'attendance.read', 'attendance.create', 'attendance.update',
            'finance.read', 'finance.create', 'finance.approve', 'finance.export',
            'donations.read', 'donations.create', 'donations.export',
            'pastoral.read_general',
            'ministries.read', 'ministries.manage',
            'groups.read', 'groups.manage',
            'branches.read', 'branches.manage',
            'volunteers.read', 'volunteers.manage',
            'workflows.read', 'workflows.manage',
            'reports.read', 'events.read', 'events.manage',
            'documents.read', 'documents.manage'
        );
    END IF;

    -- PASTOR Permissions (Holds ecclesiastical pastoral privilege)
    IF u_role = 'PASTOR' THEN
        RETURN required_permission IN (
            'members.read', 'members.update',
            'attendance.read',
            'pastoral.read', 'pastoral.create', 'pastoral.update',
            'pastoral.confidential',
            'counseling.read', 'counseling.create', 'counseling.update',
            'counseling.confidential_notes',
            'prayer.read', 'prayer.create', 'prayer.update',
            'visitations.read', 'visitations.manage',
            'ministries.read', 'branches.read',
            'groups.read',
            'volunteers.read',
            'workflows.read', 'workflows.manage',
            'events.read',
            'documents.read'
        );
    END IF;

    -- MINISTRY_LEADER Permissions
    IF u_role = 'MINISTRY_LEADER' THEN
        RETURN required_permission IN (
            'members.read',
            'attendance.read', 'attendance.create', 'attendance.update',
            'pastoral.read_general', 'prayer.read', 'prayer.create',
            'ministries.read', 'branches.read',
            'groups.read', 'groups.manage',
            'volunteers.read', 'volunteers.manage',
            'workflows.read', 'workflows.create',
            'events.read',
            'documents.read'
        );
    END IF;

    -- REGULAR_MEMBER Permissions
    IF u_role = 'REGULAR_MEMBER' THEN
        RETURN required_permission IN (
            'members.read_self',
            'attendance.create',
            'finance.read_self',
            'donations.read_self', 'donations.create',
            'prayer.read_self', 'prayer.create',
            'counseling.read_self',
            'workflows.read_self', 'workflows.create',
            'events.read',
            'documents.read'
        );
    END IF;

    RETURN false;
END;
$$;

-- ==============================================================================
-- 21. REVIEW GRANTS & REVOKE UNNECESSARY ANON ACCESS
-- Authoritative security boundary enforcement at PostgreSQL role layer
-- ==============================================================================

-- Revoke all public / anonymous permissions across all exposed tables
REVOKE ALL ON TABLE public.tenants FROM anon, public;
REVOKE ALL ON TABLE public.branches FROM anon, public;
REVOKE ALL ON TABLE public.profiles FROM anon, public;
REVOKE ALL ON TABLE public.members FROM anon, public;
REVOKE ALL ON TABLE public.families FROM anon, public;
REVOKE ALL ON TABLE public.ministries FROM anon, public;
REVOKE ALL ON TABLE public.ministry_members FROM anon, public;
REVOKE ALL ON TABLE public.groups FROM anon, public;
REVOKE ALL ON TABLE public.attendance_records FROM anon, public;
REVOKE ALL ON TABLE public.attendance FROM anon, public;
REVOKE ALL ON TABLE public.events FROM anon, public;
REVOKE ALL ON TABLE public.financial_transactions FROM anon, public;
REVOKE ALL ON TABLE public.donations FROM anon, public;
REVOKE ALL ON TABLE public.pastoral_records FROM anon, public;
REVOKE ALL ON TABLE public.prayer_requests FROM anon, public;
REVOKE ALL ON TABLE public.counseling FROM anon, public;
REVOKE ALL ON TABLE public.documents FROM anon, public;
REVOKE ALL ON TABLE public.workflow_requests FROM anon, public;
REVOKE ALL ON TABLE public.volunteer_shifts FROM anon, public;
REVOKE ALL ON TABLE public.assets FROM anon, public;
REVOKE ALL ON TABLE public.lms_courses FROM anon, public;
REVOKE ALL ON TABLE public.group_chats FROM anon, public;
REVOKE ALL ON TABLE public.video_conferences FROM anon, public;
REVOKE ALL ON TABLE public.audit_logs FROM anon, public;

-- Grant authenticated permissions where appropriate
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.branches TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.profiles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.members TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.families TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.ministries TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.ministry_members TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.groups TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.attendance_records TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.attendance TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.events TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.financial_transactions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.donations TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.pastoral_records TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.prayer_requests TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.counseling TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.documents TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.workflow_requests TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.volunteer_shifts TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.assets TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.lms_courses TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.group_chats TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.video_conferences TO authenticated;
GRANT SELECT, INSERT ON TABLE public.tenants TO authenticated;

-- Audit logs are strictly INSERT & SELECT ONLY for authenticated (NO UPDATE, NO DELETE)
GRANT SELECT, INSERT ON TABLE public.audit_logs TO authenticated;
REVOKE UPDATE, DELETE, TRUNCATE ON TABLE public.audit_logs FROM authenticated;

-- ==============================================================================
-- 22. ROW LEVEL SECURITY (RLS) ACTIVATION
-- Enable RLS on every exposed application table
-- ==============================================================================
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.families ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ministries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ministry_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.donations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pastoral_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prayer_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.counseling ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workflow_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.volunteer_shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lms_courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.video_conferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- 23. AUTHORITATIVE EXPLICIT RLS POLICIES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- A. TENANTS POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Tenants select policy" ON public.tenants;
CREATE POLICY "Tenants select policy" ON public.tenants
    FOR SELECT TO authenticated
    USING (id = public.get_current_tenant_id());

-- ------------------------------------------------------------------------------
-- B. BRANCHES POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Branches select policy" ON public.branches;
DROP POLICY IF EXISTS "Branches insert policy" ON public.branches;
DROP POLICY IF EXISTS "Branches update policy" ON public.branches;
DROP POLICY IF EXISTS "Branches delete policy" ON public.branches;

CREATE POLICY "Branches select policy" ON public.branches
    FOR SELECT TO authenticated
    USING (tenant_id = public.get_current_tenant_id());

CREATE POLICY "Branches insert policy" ON public.branches
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('branches.manage')
    );

CREATE POLICY "Branches update policy" ON public.branches
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('branches.manage')
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('branches.manage')
    );

CREATE POLICY "Branches delete policy" ON public.branches
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- C. PROFILES POLICIES (Users / Profiles)
-- Strict Role Escalation Prevention: User cannot change own role or switch tenants
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Profiles select policy" ON public.profiles;
DROP POLICY IF EXISTS "Profiles insert policy" ON public.profiles;
DROP POLICY IF EXISTS "Profiles update policy" ON public.profiles;
DROP POLICY IF EXISTS "Profiles delete policy" ON public.profiles;

CREATE POLICY "Profiles select policy" ON public.profiles
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        OR auth.uid() = id
        OR auth.uid() = user_id
    );

CREATE POLICY "Profiles insert policy" ON public.profiles
    FOR INSERT TO authenticated
    WITH CHECK (
        auth.uid() = id
        OR auth.uid() = user_id
        OR public.get_current_role() = 'SYSTEM_ADMIN'
    );

CREATE POLICY "Profiles update policy" ON public.profiles
    FOR UPDATE TO authenticated
    USING (
        (auth.uid() = id OR auth.uid() = user_id OR public.get_current_role() = 'SYSTEM_ADMIN')
        AND (tenant_id = public.get_current_tenant_id() OR public.get_current_role() = 'SYSTEM_ADMIN')
    )
    WITH CHECK (
        -- Role escalation & sensitive column prevention: only SYSTEM_ADMIN can modify sensitive security/isolation columns
        (public.get_current_role() = 'SYSTEM_ADMIN')
        OR (
            role = (SELECT p.role FROM public.profiles p WHERE p.id = auth.uid())
            AND tenant_id = (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid())
            AND mfa_enabled IS NOT DISTINCT FROM (SELECT p.mfa_enabled FROM public.profiles p WHERE p.id = auth.uid())
            AND must_change_password IS NOT DISTINCT FROM (SELECT p.must_change_password FROM public.profiles p WHERE p.id = auth.uid())
            AND branch_id IS NOT DISTINCT FROM (SELECT p.branch_id FROM public.profiles p WHERE p.id = auth.uid())
            AND status IS NOT DISTINCT FROM (SELECT p.status FROM public.profiles p WHERE p.id = auth.uid())
            AND member_id IS NOT DISTINCT FROM (SELECT p.member_id FROM public.profiles p WHERE p.id = auth.uid())
        )
    );

-- Enforce security column immutability via BEFORE UPDATE trigger
CREATE OR REPLACE FUNCTION public.check_profile_security_columns_immutable()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    cur_role TEXT;
BEGIN
    cur_role := public.get_current_role();
    IF cur_role != 'SYSTEM_ADMIN' THEN
        -- Disallow updating sensitive security and governance columns by non-admins
        IF (NEW.role IS DISTINCT FROM OLD.role) OR
           (NEW.tenant_id IS DISTINCT FROM OLD.tenant_id) OR
           (NEW.mfa_enabled IS DISTINCT FROM OLD.mfa_enabled) OR
           (NEW.must_change_password IS DISTINCT FROM OLD.must_change_password) OR
           (NEW.branch_id IS DISTINCT FROM OLD.branch_id) OR
           (NEW.status IS DISTINCT FROM OLD.status) OR
           (NEW.member_id IS DISTINCT FROM OLD.member_id) THEN
            RAISE EXCEPTION 'UNAUTHORIZED_COLUMN_MUTATION: Only SYSTEM_ADMIN can modify sensitive profile governance attributes.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_profile_security_columns ON public.profiles;
CREATE TRIGGER trg_protect_profile_security_columns
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.check_profile_security_columns_immutable();

-- Safe new user signup trigger: strictly hardcodes REGULAR_MEMBER (never trusts raw_user_meta_data)
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    def_tenant UUID;
    def_branch UUID;
    full_nm TEXT;
BEGIN
    SELECT id INTO def_tenant FROM public.tenants ORDER BY created_at ASC LIMIT 1;
    IF def_tenant IS NULL THEN
        def_tenant := 'a0000000-0000-0000-0000-000000000001'::uuid;
    END IF;

    SELECT id INTO def_branch FROM public.branches WHERE tenant_id = def_tenant ORDER BY is_headquarters DESC, created_at ASC LIMIT 1;
    IF def_branch IS NULL THEN
        def_branch := 'b0000000-0000-0000-0000-000000000001'::uuid;
    END IF;

    full_nm := COALESCE(
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'name',
        split_part(NEW.email, '@', 1)
    );

    INSERT INTO public.profiles (
        id,
        user_id,
        tenant_id,
        branch_id,
        email,
        full_name,
        display_name,
        phone,
        role,
        status,
        must_change_password,
        mfa_enabled
    ) VALUES (
        NEW.id,
        NEW.id,
        def_tenant,
        def_branch,
        NEW.email,
        full_nm,
        full_nm,
        NEW.phone,
        'REGULAR_MEMBER',
        'Active',
        false,
        false
    )
    ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        phone = COALESCE(EXCLUDED.phone, public.profiles.phone);

    RETURN NEW;
END;
$$;

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'auth' AND table_name = 'users') THEN
        DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
        CREATE TRIGGER on_auth_user_created
            AFTER INSERT ON auth.users
            FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();
    END IF;
END $$;


CREATE POLICY "Profiles delete policy" ON public.profiles
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- D. MEMBERS DIRECTORY POLICIES
-- Tenant and Branch isolation, Member-level privacy
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Members select policy" ON public.members;
DROP POLICY IF EXISTS "Members insert policy" ON public.members;
DROP POLICY IF EXISTS "Members update policy" ON public.members;
DROP POLICY IF EXISTS "Members delete policy" ON public.members;

CREATE POLICY "Members select policy" ON public.members
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            OR (public.get_current_role() = 'MINISTRY_LEADER' AND public.can_access_branch(branch_id))
            OR (
                public.get_current_role() = 'REGULAR_MEMBER'
                AND (
                    id = public.get_current_member_id()
                    OR id = (public.get_current_profile()).member_id::uuid
                    OR email = (public.get_current_profile()).email
                )
            )
        )
    );

CREATE POLICY "Members insert policy" ON public.members
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('members.create')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Members update policy" ON public.members
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.has_permission('members.update') AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND id = public.get_current_member_id())
        )
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.has_permission('members.update') AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND id = public.get_current_member_id())
        )
    );

CREATE POLICY "Members delete policy" ON public.members
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('members.delete')
    );

-- ------------------------------------------------------------------------------
-- E. FAMILIES POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Families select policy" ON public.families;
DROP POLICY IF EXISTS "Families insert policy" ON public.families;
DROP POLICY IF EXISTS "Families update policy" ON public.families;
DROP POLICY IF EXISTS "Families delete policy" ON public.families;

CREATE POLICY "Families select policy" ON public.families
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            OR (public.get_current_role() = 'MINISTRY_LEADER' AND public.can_access_branch(branch_id))
            OR (
                public.get_current_role() = 'REGULAR_MEMBER'
                AND (
                    head_member_id = public.get_current_member_id()
                    OR member_ids @> to_jsonb(public.get_current_member_id()::text)
                )
            )
        )
    );

CREATE POLICY "Families insert policy" ON public.families
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('members.create')
    );

CREATE POLICY "Families update policy" ON public.families
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('members.update')
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('members.update')
    );

CREATE POLICY "Families delete policy" ON public.families
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- F. MINISTRIES & MINISTRIES MEMBERS POLICIES
-- Prevents ministry leader from accessing unrelated ministry records
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Ministries select policy" ON public.ministries;
DROP POLICY IF EXISTS "Ministries insert policy" ON public.ministries;
DROP POLICY IF EXISTS "Ministries update policy" ON public.ministries;
DROP POLICY IF EXISTS "Ministries delete policy" ON public.ministries;

CREATE POLICY "Ministries select policy" ON public.ministries
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.can_access_branch(branch_id)
            OR public.is_member_of_ministry(id)
        )
    );

CREATE POLICY "Ministries insert policy" ON public.ministries
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('ministries.manage')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Ministries update policy" ON public.ministries
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('ministries.manage')
            OR public.is_leader_of_ministry(id)
        )
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('ministries.manage')
            OR public.is_leader_of_ministry(id)
        )
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Ministries delete policy" ON public.ministries
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- Ministry Members Roster Policies
DROP POLICY IF EXISTS "Ministry members select policy" ON public.ministry_members;
DROP POLICY IF EXISTS "Ministry members insert policy" ON public.ministry_members;
DROP POLICY IF EXISTS "Ministry members update policy" ON public.ministry_members;
DROP POLICY IF EXISTS "Ministry members delete policy" ON public.ministry_members;

CREATE POLICY "Ministry members select policy" ON public.ministry_members
    FOR SELECT TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.ministries m
            WHERE m.id = ministry_id
              AND m.tenant_id = public.get_current_tenant_id()
              AND (
                  public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
                  OR public.is_leader_of_ministry(m.id)
                  OR member_id = public.get_current_member_id()
              )
        )
    );

CREATE POLICY "Ministry members insert policy" ON public.ministry_members
    FOR INSERT TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.ministries m
            WHERE m.id = ministry_id
              AND m.tenant_id = public.get_current_tenant_id()
              AND (
                  public.has_permission('ministries.manage')
                  OR public.is_leader_of_ministry(m.id)
                  OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
              )
        )
    );

CREATE POLICY "Ministry members update policy" ON public.ministry_members
    FOR UPDATE TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.ministries m
            WHERE m.id = ministry_id
              AND m.tenant_id = public.get_current_tenant_id()
              AND (
                  public.has_permission('ministries.manage')
                  OR public.is_leader_of_ministry(m.id)
              )
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.ministries m
            WHERE m.id = ministry_id
              AND m.tenant_id = public.get_current_tenant_id()
              AND (
                  public.has_permission('ministries.manage')
                  OR public.is_leader_of_ministry(m.id)
              )
        )
    );

CREATE POLICY "Ministry members delete policy" ON public.ministry_members
    FOR DELETE TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.ministries m
            WHERE m.id = ministry_id
              AND m.tenant_id = public.get_current_tenant_id()
              AND (
                  public.has_permission('ministries.manage')
                  OR public.is_leader_of_ministry(m.id)
                  OR member_id = public.get_current_member_id()
              )
        )
    );

-- ------------------------------------------------------------------------------
-- G. GROUPS POLICIES (Small Groups & Fellowships)
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Groups select policy" ON public.groups;
DROP POLICY IF EXISTS "Groups insert policy" ON public.groups;
DROP POLICY IF EXISTS "Groups update policy" ON public.groups;
DROP POLICY IF EXISTS "Groups delete policy" ON public.groups;

CREATE POLICY "Groups select policy" ON public.groups
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Groups insert policy" ON public.groups
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('groups.manage')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Groups update policy" ON public.groups
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('groups.manage')
            OR public.is_leader_of_group(id)
        )
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('groups.manage')
            OR public.is_leader_of_group(id)
        )
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Groups delete policy" ON public.groups
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- H. ATTENDANCE & ATTENDANCE RECORDS POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Attendance records select policy" ON public.attendance_records;
DROP POLICY IF EXISTS "Attendance records insert policy" ON public.attendance_records;
DROP POLICY IF EXISTS "Attendance records update policy" ON public.attendance_records;
DROP POLICY IF EXISTS "Attendance records delete policy" ON public.attendance_records;

CREATE POLICY "Attendance records select policy" ON public.attendance_records
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER') AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'MINISTRY_LEADER' AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Attendance records insert policy" ON public.attendance_records
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('attendance.create')
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Attendance records update policy" ON public.attendance_records
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('attendance.update')
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('attendance.update')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Attendance records delete policy" ON public.attendance_records
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- Canonical attendance table policies
DROP POLICY IF EXISTS "Attendance select policy" ON public.attendance;
DROP POLICY IF EXISTS "Attendance insert policy" ON public.attendance;
DROP POLICY IF EXISTS "Attendance update policy" ON public.attendance;
DROP POLICY IF EXISTS "Attendance delete policy" ON public.attendance;

CREATE POLICY "Attendance select policy" ON public.attendance
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER') AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'MINISTRY_LEADER' AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Attendance insert policy" ON public.attendance
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('attendance.create')
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Attendance update policy" ON public.attendance
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('attendance.update')
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('attendance.update')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Attendance delete policy" ON public.attendance
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- I. EVENTS POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Events select policy" ON public.events;
DROP POLICY IF EXISTS "Events insert policy" ON public.events;
DROP POLICY IF EXISTS "Events update policy" ON public.events;
DROP POLICY IF EXISTS "Events delete policy" ON public.events;

CREATE POLICY "Events select policy" ON public.events
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (branch_id IS NULL OR public.can_access_branch(branch_id))
    );

CREATE POLICY "Events insert policy" ON public.events
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('events.manage')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Events update policy" ON public.events
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('events.manage')
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('events.manage')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Events delete policy" ON public.events
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
    );

-- ------------------------------------------------------------------------------
-- J. FINANCIAL TRANSACTIONS POLICIES (Strict Ledger Segregation)
-- Regular members may only inspect their own ledger entries
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Finance select policy" ON public.financial_transactions;
DROP POLICY IF EXISTS "Finance insert policy" ON public.financial_transactions;
DROP POLICY IF EXISTS "Finance update policy" ON public.financial_transactions;
DROP POLICY IF EXISTS "Finance delete policy" ON public.financial_transactions;

CREATE POLICY "Finance select policy" ON public.financial_transactions
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER') AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Finance insert policy" ON public.financial_transactions
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.has_permission('finance.create') AND public.can_access_branch(branch_id))
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Finance update policy" ON public.financial_transactions
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('finance.approve')
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('finance.approve')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Finance delete policy" ON public.financial_transactions
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- K. DONATIONS POLICIES (Tithes & Offerings)
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Donations select policy" ON public.donations;
DROP POLICY IF EXISTS "Donations insert policy" ON public.donations;
DROP POLICY IF EXISTS "Donations update policy" ON public.donations;
DROP POLICY IF EXISTS "Donations delete policy" ON public.donations;

CREATE POLICY "Donations select policy" ON public.donations
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER') AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
            OR (
                public.get_current_role() = 'REGULAR_MEMBER'
                AND (
                    member_id = public.get_current_member_id()
                    OR donor_email = (public.get_current_profile()).email
                )
            )
        )
    );

CREATE POLICY "Donations insert policy" ON public.donations
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('donations.create')
            OR (
                public.get_current_role() = 'REGULAR_MEMBER'
                AND (member_id = public.get_current_member_id() OR member_id IS NULL)
            )
        )
    );

CREATE POLICY "Donations update policy" ON public.donations
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('finance.approve')
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('finance.approve')
    );

CREATE POLICY "Donations delete policy" ON public.donations
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- L. PASTORAL RECORDS POLICIES (Ecclesiastical Confidentiality Boundary)
-- CRITICAL SPECIAL RULE: SYSTEM_ADMIN does NOT automatically receive unrestricted access
-- to confidential pastoral counseling or sealed records!
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Pastoral select policy" ON public.pastoral_records;
DROP POLICY IF EXISTS "Pastoral insert policy" ON public.pastoral_records;
DROP POLICY IF EXISTS "Pastoral update policy" ON public.pastoral_records;
DROP POLICY IF EXISTS "Pastoral delete policy" ON public.pastoral_records;

CREATE POLICY "Pastoral select policy" ON public.pastoral_records
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            -- Case 1: Confidential or Sealed pastoral records:
            -- Accessible ONLY by PASTOR in same branch, OR the specific counselor_user_id.
            -- SYSTEM_ADMIN is strictly DENIED unless explicit diagnostic override is active.
            (
                confidentiality IN ('CONFIDENTIAL', 'SEALED', 'MINISTERIAL')
                AND (
                    (public.get_current_role() = 'PASTOR' AND public.can_access_branch(branch_id))
                    OR counselor_user_id = auth.uid()
                    OR (public.get_current_role() = 'SYSTEM_ADMIN' AND public.has_pastoral_confidential_override())
                )
            )
            -- Case 2: General administrative pastoral records:
            OR (
                confidentiality = 'GENERAL'
                AND (
                    (public.get_current_role() IN ('PASTOR', 'MANAGER') AND public.can_access_branch(branch_id))
                    OR (public.get_current_role() = 'MINISTRY_LEADER' AND public.can_access_branch(branch_id))
                    OR (public.get_current_role() = 'SYSTEM_ADMIN')
                )
            )
        )
    );

CREATE POLICY "Pastoral insert policy" ON public.pastoral_records
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.get_current_role() = 'PASTOR'
            OR counselor_user_id = auth.uid()
            OR (public.get_current_role() = 'MANAGER' AND confidentiality = 'GENERAL')
        )
    );

CREATE POLICY "Pastoral update policy" ON public.pastoral_records
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() = 'PASTOR' AND public.can_access_branch(branch_id))
            OR counselor_user_id = auth.uid()
        )
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() = 'PASTOR' AND public.can_access_branch(branch_id))
            OR counselor_user_id = auth.uid()
        )
    );

CREATE POLICY "Pastoral delete policy" ON public.pastoral_records
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            (public.get_current_role() = 'PASTOR' AND public.can_access_branch(branch_id))
            OR counselor_user_id = auth.uid()
        )
    );

-- ------------------------------------------------------------------------------
-- M. PRAYER REQUESTS POLICIES
-- Prevents Member -> another member's confidential records
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Prayer select policy" ON public.prayer_requests;
DROP POLICY IF EXISTS "Prayer insert policy" ON public.prayer_requests;
DROP POLICY IF EXISTS "Prayer update policy" ON public.prayer_requests;
DROP POLICY IF EXISTS "Prayer delete policy" ON public.prayer_requests;

CREATE POLICY "Prayer select policy" ON public.prayer_requests
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            -- Submitting member can ALWAYS read their own prayer request
            (requester_user_id = auth.uid() OR member_id = public.get_current_member_id())
            -- Pastors can read all prayer requests in their branch/campus
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
            -- Non-confidential requests can be read by ministry leaders and campus community
            OR (
                is_confidential = false
                AND (
                    public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER', 'MINISTRY_LEADER')
                    OR assigned_intercessor_id = auth.uid()
                )
            )
        )
    );

CREATE POLICY "Prayer insert policy" ON public.prayer_requests
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('prayer.create')
            OR requester_user_id = auth.uid()
            OR member_id = public.get_current_member_id()
        )
    );

CREATE POLICY "Prayer update policy" ON public.prayer_requests
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            requester_user_id = auth.uid()
            OR member_id = public.get_current_member_id()
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
            OR assigned_intercessor_id = auth.uid()
        )
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            requester_user_id = auth.uid()
            OR member_id = public.get_current_member_id()
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
            OR assigned_intercessor_id = auth.uid()
        )
    );

CREATE POLICY "Prayer delete policy" ON public.prayer_requests
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            requester_user_id = auth.uid()
            OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR')
        )
    );

-- ------------------------------------------------------------------------------
-- N. COUNSELING SESSIONS POLICIES (Ecclesiastical Counseling Boundary)
-- SPECIAL RULE: SYSTEM_ADMIN is NOT permitted to view confidential counseling sessions!
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Counseling select policy" ON public.counseling;
DROP POLICY IF EXISTS "Counseling insert policy" ON public.counseling;
DROP POLICY IF EXISTS "Counseling update policy" ON public.counseling;
DROP POLICY IF EXISTS "Counseling delete policy" ON public.counseling;

CREATE POLICY "Counseling select policy" ON public.counseling
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            -- Counselor assigned or Pastor holds access
            (counselor_user_id = auth.uid())
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
            -- Client member can view appointment session metadata (date, counselor name, status)
            OR (client_member_id = public.get_current_member_id())
            -- SYSTEM_ADMIN can ONLY view if explicit pastoral confidential override is designed/active
            OR (public.get_current_role() = 'SYSTEM_ADMIN' AND public.has_pastoral_confidential_override())
        )
    );

CREATE POLICY "Counseling insert policy" ON public.counseling
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.get_current_role() = 'PASTOR'
            OR counselor_user_id = auth.uid()
            OR (public.get_current_role() = 'REGULAR_MEMBER' AND client_member_id = public.get_current_member_id())
        )
    );

CREATE POLICY "Counseling update policy" ON public.counseling
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            counselor_user_id = auth.uid()
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
        )
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            counselor_user_id = auth.uid()
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
        )
    );

CREATE POLICY "Counseling delete policy" ON public.counseling
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            counselor_user_id = auth.uid()
            OR (public.get_current_role() = 'PASTOR' AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
        )
    );

-- ------------------------------------------------------------------------------
-- O. DOCUMENTS & POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Documents select policy" ON public.documents;
DROP POLICY IF EXISTS "Documents insert policy" ON public.documents;
DROP POLICY IF EXISTS "Documents update policy" ON public.documents;
DROP POLICY IF EXISTS "Documents delete policy" ON public.documents;

CREATE POLICY "Documents select policy" ON public.documents
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            -- Public / unclassified documents are accessible to everyone in the tenant
            (is_confidential = false AND (branch_id IS NULL OR public.can_access_branch(branch_id)))
            -- Confidential documents require managerial or administrative clearance
            OR (
                is_confidential = true
                AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR')
                AND (branch_id IS NULL OR public.can_access_branch(branch_id))
            )
        )
    );

CREATE POLICY "Documents insert policy" ON public.documents
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('documents.manage')
    );

CREATE POLICY "Documents update policy" ON public.documents
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('documents.manage')
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('documents.manage')
    );

CREATE POLICY "Documents delete policy" ON public.documents
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
    );

-- ------------------------------------------------------------------------------
-- P. WORKFLOW REQUESTS POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Workflows select policy" ON public.workflow_requests;
DROP POLICY IF EXISTS "Workflows insert policy" ON public.workflow_requests;
DROP POLICY IF EXISTS "Workflows update policy" ON public.workflow_requests;
DROP POLICY IF EXISTS "Workflows delete policy" ON public.workflow_requests;

CREATE POLICY "Workflows select policy" ON public.workflow_requests
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('workflows.manage')
            OR requester_email = (public.get_current_profile()).email
            OR (branch_id IS NOT NULL AND public.can_access_branch(branch_id))
        )
    );

CREATE POLICY "Workflows insert policy" ON public.workflow_requests
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('workflows.create')
    );

CREATE POLICY "Workflows update policy" ON public.workflow_requests
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('workflows.manage')
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.has_permission('workflows.manage')
    );

CREATE POLICY "Workflows delete policy" ON public.workflow_requests
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- Q. VOLUNTEER SHIFTS & ASSETS POLICIES
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Volunteers select policy" ON public.volunteer_shifts;
DROP POLICY IF EXISTS "Volunteers insert policy" ON public.volunteer_shifts;
DROP POLICY IF EXISTS "Volunteers update policy" ON public.volunteer_shifts;
DROP POLICY IF EXISTS "Volunteers delete policy" ON public.volunteer_shifts;

CREATE POLICY "Volunteers select policy" ON public.volunteer_shifts
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR')
            OR volunteer_member_id = public.get_current_member_id()
            OR (ministry_id IS NOT NULL AND public.is_leader_of_ministry(ministry_id))
        )
    );

CREATE POLICY "Volunteers insert policy" ON public.volunteer_shifts
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('volunteers.manage')
            OR (ministry_id IS NOT NULL AND public.is_leader_of_ministry(ministry_id))
        )
    );

CREATE POLICY "Volunteers update policy" ON public.volunteer_shifts
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('volunteers.manage')
            OR (ministry_id IS NOT NULL AND public.is_leader_of_ministry(ministry_id))
            OR (volunteer_member_id = public.get_current_member_id())
        )
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (
            public.has_permission('volunteers.manage')
            OR (ministry_id IS NOT NULL AND public.is_leader_of_ministry(ministry_id))
        )
    );

CREATE POLICY "Volunteers delete policy" ON public.volunteer_shifts
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
    );

-- Assets Policies
DROP POLICY IF EXISTS "Assets select policy" ON public.assets;
DROP POLICY IF EXISTS "Assets insert policy" ON public.assets;
DROP POLICY IF EXISTS "Assets update policy" ON public.assets;
DROP POLICY IF EXISTS "Assets delete policy" ON public.assets;

CREATE POLICY "Assets select policy" ON public.assets
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Assets insert policy" ON public.assets
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Assets update policy" ON public.assets
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
        AND public.can_access_branch(branch_id)
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
        AND public.can_access_branch(branch_id)
    );

CREATE POLICY "Assets delete policy" ON public.assets
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- R. GROUP CHATS & VIDEO CONFERENCES (Strict Tenant & Ministry Isolation)
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Group chats select policy" ON public.group_chats;
DROP POLICY IF EXISTS "Group chats insert policy" ON public.group_chats;
DROP POLICY IF EXISTS "Group chats update policy" ON public.group_chats;
DROP POLICY IF EXISTS "Group chats delete policy" ON public.group_chats;

CREATE POLICY "Group chats select policy" ON public.group_chats
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.is_member_of_ministry(ministry_id)
    );

CREATE POLICY "Group chats insert policy" ON public.group_chats
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.is_leader_of_ministry(ministry_id))
    );

CREATE POLICY "Group chats update policy" ON public.group_chats
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.is_leader_of_ministry(ministry_id))
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.is_leader_of_ministry(ministry_id))
    );

CREATE POLICY "Group chats delete policy" ON public.group_chats
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.get_current_role() = 'SYSTEM_ADMIN')
    );

-- Video Conferences Policies
DROP POLICY IF EXISTS "Video conf select policy" ON public.video_conferences;
DROP POLICY IF EXISTS "Video conf insert policy" ON public.video_conferences;
DROP POLICY IF EXISTS "Video conf update policy" ON public.video_conferences;
DROP POLICY IF EXISTS "Video conf delete policy" ON public.video_conferences;

CREATE POLICY "Video conf select policy" ON public.video_conferences
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.is_member_of_ministry(ministry_id)
    );

CREATE POLICY "Video conf insert policy" ON public.video_conferences
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.is_leader_of_ministry(ministry_id))
    );

CREATE POLICY "Video conf update policy" ON public.video_conferences
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.is_leader_of_ministry(ministry_id))
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.is_leader_of_ministry(ministry_id))
    );

CREATE POLICY "Video conf delete policy" ON public.video_conferences
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (leader_profile_id = auth.uid() OR public.get_current_role() = 'SYSTEM_ADMIN')
    );

-- LMS Courses Policies
DROP POLICY IF EXISTS "Lms courses select policy" ON public.lms_courses;
DROP POLICY IF EXISTS "Lms courses insert policy" ON public.lms_courses;
DROP POLICY IF EXISTS "Lms courses update policy" ON public.lms_courses;
DROP POLICY IF EXISTS "Lms courses delete policy" ON public.lms_courses;

CREATE POLICY "Lms courses select policy" ON public.lms_courses
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
    );

CREATE POLICY "Lms courses insert policy" ON public.lms_courses
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
    );

CREATE POLICY "Lms courses update policy" ON public.lms_courses
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
    )
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() IN ('SYSTEM_ADMIN', 'MANAGER')
    );

CREATE POLICY "Lms courses delete policy" ON public.lms_courses
    FOR DELETE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

-- ------------------------------------------------------------------------------
-- S. AUDIT LOGS POLICIES (Immutable System Security Trail)
-- Strict Read-Only for SYSTEM_ADMIN; Append-Only for authenticated users.
-- ZERO UPDATE AND ZERO DELETE POLICIES EXIST (Strict Immutability).
-- ------------------------------------------------------------------------------
DROP POLICY IF EXISTS "Audit logs select policy" ON public.audit_logs;
DROP POLICY IF EXISTS "Audit logs insert policy" ON public.audit_logs;

CREATE POLICY "Audit logs select policy" ON public.audit_logs
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND public.get_current_role() = 'SYSTEM_ADMIN'
    );

CREATE POLICY "Audit logs insert policy" ON public.audit_logs
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
    );

-- NOTE: No UPDATE or DELETE policy is defined on public.audit_logs.
-- PostgreSQL RLS denies all UPDATE and DELETE operations by default when RLS is active.

-- ==============================================================================
-- 21. PERFORMANCE INDEXES (Query Optimization & Fast Scan Coverage)
-- Designed for high throughput multi-tenant filtering, sorting, and pagination
-- ==============================================================================

-- Member & Directory Queries
CREATE INDEX IF NOT EXISTS idx_members_tenant_branch ON public.members (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_members_tenant_status ON public.members (tenant_id, membership_status);
CREATE INDEX IF NOT EXISTS idx_members_tenant_created_desc ON public.members (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_members_phone ON public.members (tenant_id, phone);
CREATE INDEX IF NOT EXISTS idx_members_email ON public.members (tenant_id, email);
CREATE INDEX IF NOT EXISTS idx_members_member_number ON public.members (tenant_id, member_number);
-- Family membership is represented by families.member_ids (JSONB) in this schema.
CREATE INDEX IF NOT EXISTS idx_families_member_ids_gin ON public.families USING GIN (member_ids);

-- User Profiles & Authentication
CREATE INDEX IF NOT EXISTS idx_profiles_tenant_role ON public.profiles (tenant_id, role);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles (email);

-- Attendance Queries
CREATE INDEX IF NOT EXISTS idx_attendance_records_tenant_branch_checkin ON public.attendance_records (tenant_id, branch_id, checkin_time DESC);
CREATE INDEX IF NOT EXISTS idx_attendance_records_member_checkin ON public.attendance_records (member_id, checkin_time DESC);

-- Financial & Transactions Ledger
CREATE INDEX IF NOT EXISTS idx_financial_tx_tenant_branch ON public.financial_transactions (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_financial_tx_tenant_date ON public.financial_transactions (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_donations_tenant_created ON public.donations (tenant_id, created_at DESC);

-- Ministry & Groups
CREATE INDEX IF NOT EXISTS idx_ministries_tenant_branch ON public.ministries (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_ministry_members_lookup ON public.ministry_members (ministry_id, member_id);

-- Events & Calendars
CREATE INDEX IF NOT EXISTS idx_events_tenant_start_date ON public.events (tenant_id, start_date DESC);

-- Audit & Security
CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant_created ON public.audit_logs (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON public.audit_logs (user_id);

-- ==============================================================================
-- 22. AD-HOC AND CROSS-GROUP CONVERSATIONS (CHAT & VIDEO)
-- Explicit participant list, independent of ministry/group membership
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT NOT NULL CHECK (type IN ('direct', 'ad_hoc_group', 'video')),
    title TEXT,
    created_by TEXT NOT NULL,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at TIMESTAMPTZ,
    CONSTRAINT chk_conversation_title CHECK (
        (type = 'direct') OR (title IS NOT NULL AND length(trim(title)) > 0)
    )
);

CREATE TABLE IF NOT EXISTS public.conversation_participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    added_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    left_at TIMESTAMPTZ,
    UNIQUE (conversation_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.conversation_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_conversations_tenant_status ON public.conversations (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_conversations_created_by ON public.conversations (created_by);
CREATE INDEX IF NOT EXISTS idx_conversation_participants_user_active ON public.conversation_participants (user_id, conversation_id) WHERE left_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_conversation_participants_lookup ON public.conversation_participants (conversation_id, user_id);
CREATE INDEX IF NOT EXISTS idx_conversation_messages_conv_created ON public.conversation_messages (conversation_id, created_at DESC);

-- Enable RLS
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_messages ENABLE ROW LEVEL SECURITY;

-- Conversations RLS
CREATE POLICY "Conversations select policy" ON public.conversations
    FOR SELECT TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            EXISTS (
                SELECT 1 FROM public.conversation_participants cp
                WHERE cp.conversation_id = conversations.id
                AND cp.user_id = auth.uid()::text
                AND cp.left_at IS NULL
            )
            OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
        )
    );

CREATE POLICY "Conversations insert policy" ON public.conversations
    FOR INSERT TO authenticated
    WITH CHECK (
        tenant_id = public.get_current_tenant_id()
    );

CREATE POLICY "Conversations update policy" ON public.conversations
    FOR UPDATE TO authenticated
    USING (
        tenant_id = public.get_current_tenant_id()
        AND (
            created_by = auth.uid()::text
            OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
        )
    );

-- Conversation Participants RLS
CREATE POLICY "Conversation participants select policy" ON public.conversation_participants
    FOR SELECT TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.conversations c
            WHERE c.id = conversation_participants.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND (
                EXISTS (
                    SELECT 1 FROM public.conversation_participants my_cp
                    WHERE my_cp.conversation_id = c.id
                    AND my_cp.user_id = auth.uid()::text
                    AND my_cp.left_at IS NULL
                )
                OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            )
        )
    );

CREATE POLICY "Conversation participants insert policy" ON public.conversation_participants
    FOR INSERT TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.conversations c
            WHERE c.id = conversation_participants.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND (
                c.created_by = auth.uid()::text
                OR public.get_current_role() IN ('SYSTEM_ADMIN', 'PASTOR', 'MANAGER')
            )
        )
    );

-- Conversation Messages RLS
CREATE POLICY "Conversation messages select policy" ON public.conversation_messages
    FOR SELECT TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.conversations c
            JOIN public.conversation_participants cp ON cp.conversation_id = c.id
            WHERE c.id = conversation_messages.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND cp.user_id = auth.uid()::text
            AND cp.left_at IS NULL
        )
    );

CREATE POLICY "Conversation messages insert policy" ON public.conversation_messages
    FOR INSERT TO authenticated
    WITH CHECK (
        sender_id = auth.uid()::text
        AND EXISTS (
            SELECT 1 FROM public.conversations c
            JOIN public.conversation_participants cp ON cp.conversation_id = c.id
            WHERE c.id = conversation_messages.conversation_id
            AND c.tenant_id = public.get_current_tenant_id()
            AND cp.user_id = auth.uid()::text
            AND cp.left_at IS NULL
            AND c.status = 'active'
        )
    );


