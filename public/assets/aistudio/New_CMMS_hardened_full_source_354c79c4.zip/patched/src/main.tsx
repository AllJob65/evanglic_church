import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter} from 'react-router-dom';
import App from './App.tsx';
import {ErrorBoundary} from './components/ErrorBoundary';
import './index.css';

// =========================================================================
// GOOGLE TRANSLATE VIRTUAL DOM PROTECTION & CRASH PREVENTION PATCH
// Prevents React from throwing 'NotFoundError: Failed to execute 'removeChild' or 'insertBefore' on 'Node''
// when Google Translate mutates real DOM text nodes.
// =========================================================================
if (typeof window !== 'undefined' && typeof Node !== 'undefined') {
  const originalRemoveChild = Node.prototype.removeChild;
  Node.prototype.removeChild = function <T extends Node>(child: T): T {
    try {
      return originalRemoveChild.call(this, child) as T;
    } catch (err: any) {
      if (err.name === 'NotFoundError' || err.message?.includes('NotFoundError')) {
        // Child was already replaced or modified by Google Translate - suppress fatal React unmount error
        return child;
      }
      throw err;
    }
  };

  const originalInsertBefore = Node.prototype.insertBefore;
  Node.prototype.insertBefore = function <T extends Node>(newNode: T, referenceNode: Node | null): T {
    try {
      return originalInsertBefore.call(this, newNode, referenceNode) as T;
    } catch (err: any) {
      if (err.name === 'NotFoundError' || err.message?.includes('NotFoundError')) {
        // Fallback to appendChild if referenceNode was modified by translation widget
        return this.appendChild(newNode) as T;
      }
      throw err;
    }
  };

  // Prevent raw unhandled browser events (e.g., {"isTrusted": true}) from crashing the app
  window.addEventListener(
    'error',
    (event) => {
      // If the error property is null, missing, or is an Event object without a message, prevent bubbling
      if (!event.error || (typeof event.error === 'object' && !('message' in event.error) && event.error.isTrusted)) {
        console.warn('[Global Error Guard] Captured benign browser event dispatch:', event);
        event.preventDefault();
        event.stopImmediatePropagation?.();
        return true;
      }
    },
    true
  );

  window.addEventListener('unhandledrejection', (event) => {
    if (!event.reason || (typeof event.reason === 'object' && !('message' in event.reason) && event.reason.isTrusted)) {
      console.warn('[Global Error Guard] Captured benign unhandled rejection event:', event);
      event.preventDefault();
      event.stopImmediatePropagation?.();
    }
  });

  window.onerror = function (msg, url, line, col, error) {
    const errObj = error as any;
    if (!error || !msg || msg === 'Script error.' || (typeof errObj === 'object' && !errObj?.message && errObj?.isTrusted)) {
      return true;
    }
    return false;
  };
}

// Initialize Theme, Brand Colors, and Accessibility Classes from localStorage immediately on startup
try {
  const root = document.documentElement;
  const savedTheme =
    localStorage.getItem('cmms-theme') ||
    localStorage.getItem('cmms_theme_mode') ||
    localStorage.getItem('theme');
  root.classList.remove('light', 'dark', 'advanced-dark');
  if (savedTheme === 'advanced-dark') {
    root.classList.add('dark', 'advanced-dark');
  } else if (savedTheme === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.add('light');
  }

  const primaryColor = localStorage.getItem('cmms_primary_color') || '#2563eb';
  const accentColor = localStorage.getItem('cmms_accent_color') || '#7c3aed';
  const loginPanelColor = localStorage.getItem('cmms_login_panel_color') || '#0f172a';
  root.style.setProperty('--cmms-primary-color', primaryColor);
  root.style.setProperty('--cmms-accent-color', accentColor);
  root.style.setProperty('--cmms-login-panel-color', loginPanelColor);
  root.style.setProperty('--color-primary', primaryColor);
  root.style.setProperty('--color-accent', accentColor);

  if (localStorage.getItem('cmms_high_contrast') === 'true') {
    root.classList.add('high-contrast-mode');
  }
  const fontScale = localStorage.getItem('cmms_font_scale');
  if (fontScale === 'large') root.classList.add('text-scale-lg');
  else if (fontScale === 'xlarge') root.classList.add('text-scale-xl');
  if (localStorage.getItem('cmms_reduce_motion') === 'true') {
    root.classList.add('reduce-motion');
  }
  if (localStorage.getItem('cmms_dyslexic_font') === 'true') {
    root.classList.add('font-dyslexic');
  }
} catch (e) {
  // fallback if localStorage not accessible
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </BrowserRouter>
  </StrictMode>,
);


