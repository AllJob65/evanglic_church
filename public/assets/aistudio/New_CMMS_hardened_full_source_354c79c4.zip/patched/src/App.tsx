import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Routes, Route, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { CMMSProvider, useCMMS } from './context/CMMSContext';
import { AuthProvider, useAuth, ProtectedRoute, STAFF_ALLOWED_ROLES } from './context/AuthContext';
import { LanguageProvider, useTranslation } from './i18n/LanguageContext';
import { BibleProvider } from './context/BibleContext';
import { AppLayout } from './components/layout/AppLayout';
import { ErrorBoundary } from './components/ErrorBoundary';

// LAZY LOADED ROUTE MODULES (Code-split for performance & fast initial boot):
const LoginPage = lazy(() =>
  import('./components/LoginPage').then((m) => ({ default: m.LoginPage }))
);
const ChangePasswordPage = lazy(() =>
  import('./components/ChangePasswordPage').then((m) => ({ default: m.ChangePasswordPage }))
);
const SupabasePasswordResetPage = lazy(() =>
  import('./components/SupabasePasswordResetPage').then((m) => ({ default: m.SupabasePasswordResetPage }))
);
const ChurchPeopleFrontpage = lazy(() =>
  import('./components/ChurchPeopleFrontpage').then((m) => ({ default: m.ChurchPeopleFrontpage }))
);
const MemberProfileModule = lazy(() =>
  import('./components/MemberProfileModule').then((m) => ({ default: m.MemberProfileModule }))
);
const GoogleFormRegistration = lazy(() =>
  import('./components/GoogleFormRegistration').then((m) => ({ default: m.GoogleFormRegistration }))
);

// PORTAL MODULES:
import { DashboardModule } from './components/DashboardModule';
import { ApprovalsModule } from './components/ApprovalsModule';
import { MemberModule } from './components/MemberModule';
import { FamilyModule } from './components/FamilyModule';
import { BranchModule } from './components/BranchModule';
import { MinistryModule } from './components/MinistryModule';
import { AttendanceModule } from './components/AttendanceModule';
import { BibleView } from './components/BibleView';
import { BiblePassageView } from './components/bible/BiblePassageView';
import { VerseOfTheDayView } from './components/bible/VerseOfTheDayView';
import { DevotionModule } from './components/DevotionModule';
import { EventModule } from './components/EventModule';
import { CommunicationModule } from './components/CommunicationModule';
import { PrayerCounselingModule } from './components/PrayerCounselingModule';
import { VisitationCareModule } from './components/VisitationCareModule';
import { AssetModule } from './components/AssetModule';
import { DocumentModule } from './components/DocumentModule';
import { PredictiveModule } from './components/PredictiveModule';
import { ReportsModule } from './components/ReportsModule';
import { SecurityAuditModule } from './components/SecurityAuditModule';
import { SettingsModule } from './components/SettingsModule';
import { MobilePreviewModule } from './components/MobilePreviewModule';
import { BackupModule } from './components/BackupModule';
import { ApiHubModule } from './components/ApiHubModule';
import { RolePermissionsModal } from './components/RolePermissionsModal';

const ModuleLoadingFallback: React.FC = () => (
  <div
    role="status"
    aria-live="polite"
    className="w-full min-h-[380px] flex flex-col items-center justify-center p-8 text-center space-y-4"
  >
    <div className="w-10 h-10 border-3 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 animate-pulse">
      Loading module...
    </p>
  </div>
);

/**
 * Authenticated Application Shell
 * Wraps all protected portal modules inside the unified global AppLayout
 */
const PortalLayout: React.FC = () => {
  const location = useLocation();

  return (
    <AppLayout>
      <Routes location={location}>
        {/* Dashboard - Protected behind ProtectedRoute */}
                  <Route
                    path="/dashboard"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Church Dashboard">
                            <DashboardModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/dashboard/*"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Church Dashboard">
                            <DashboardModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Profile */}
                  <Route
                    path="/my-profile"
                    element={
                      <ProtectedRoute>
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Member Profile">
                            <MemberProfileModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/profile" element={<Navigate to="/my-profile" replace />} />

                  {/* Approvals */}
                  <Route
                    path="/approvals"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Approvals & Governance">
                            <ApprovalsModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Members Directory */}
                  <Route
                    path="/members"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Members Directory">
                            <MemberModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/members/*"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Members Directory">
                            <MemberModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Family & Households */}
                  <Route
                    path="/families"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Family & Households">
                            <FamilyModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Campuses & Branches */}
                  <Route
                    path="/branches"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Campuses & Branches">
                            <BranchModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Ministries & Groups */}
                  <Route
                    path="/ministries"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'MINISTRY_LEADER', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Ministries & Small Groups">
                            <MinistryModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Attendance */}
                  <Route
                    path="/attendance"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Attendance & Check-in">
                            <AttendanceModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Holy Bible Module */}
                  <Route
                    path="/bible"
                    element={
                      <ProtectedRoute>
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Holy Bible">
                            <BibleView />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/bible/*"
                    element={
                      <ProtectedRoute>
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Holy Bible">
                            <BibleView />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Devotions & Scripture */}
                  <Route
                    path="/devotions"
                    element={
                      <ProtectedRoute>
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Devotions & Scripture">
                            <DevotionModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/devotion" element={<Navigate to="/devotions" replace />} />

                  {/* Events */}
                  <Route
                    path="/events"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Events & Calendar">
                            <EventModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Communications */}
                  <Route
                    path="/communications"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Communications & SMS">
                            <CommunicationModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Prayer & Counseling */}
                  <Route
                    path="/prayer-counseling"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Prayer & Counseling">
                            <PrayerCounselingModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/prayer_counseling" element={<Navigate to="/prayer-counseling" replace />} />

                  {/* Visitation Care */}
                  <Route
                    path="/visitations"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Pastoral Care & Visitations">
                            <VisitationCareModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Asset Management */}
                  <Route
                    path="/assets"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Asset Management">
                            <AssetModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Document Archive */}
                  <Route
                    path="/documents"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Document Archive">
                            <DocumentModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Predictive & AI Analytics */}
                  <Route
                    path="/predictive"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Predictive & AI Analytics">
                            <PredictiveModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Reports & Growth Analytics */}
                  <Route
                    path="/reports"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER', 'PASTOR']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Reports & Analytics">
                            <ReportsModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/report" element={<Navigate to="/reports" replace />} />

                  {/* Backup & Disaster Recovery */}
                  <Route
                    path="/backup"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN']} fallbackModule="dashboard">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Backup & Disaster Recovery">
                            <BackupModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/admin/backup"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN']} fallbackModule="dashboard">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Backup & Disaster Recovery">
                            <BackupModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/admin/restore"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN']} fallbackModule="dashboard">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Backup & Disaster Recovery">
                            <BackupModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* Security & Audit */}
                  <Route
                    path="/security-audit"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN', 'MANAGER']} fallbackModule="devotions">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Security & Audit Governance">
                            <SecurityAuditModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/security_audit" element={<Navigate to="/security-audit" replace />} />

                  {/* System Settings */}
                  <Route
                    path="/settings"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN']} fallbackModule="dashboard">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="System Settings">
                            <SettingsModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/admin/settings"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN']} fallbackModule="dashboard">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="System Settings">
                            <SettingsModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />

                  {/* API Hub */}
                  <Route
                    path="/admin/api"
                    element={
                      <ProtectedRoute allowedRoles={['SYSTEM_ADMIN']} fallbackModule="dashboard">
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="API & Integration Hub">
                            <ApiHubModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/api-integrations" element={<Navigate to="/admin/api" replace />} />
                  <Route path="/integrations" element={<Navigate to="/admin/api" replace />} />
                  <Route path="/api" element={<Navigate to="/admin/api" replace />} />

                  {/* Mobile Preview */}
                  <Route
                    path="/mobile-preview"
                    element={
                      <ProtectedRoute>
                        <Suspense fallback={<ModuleLoadingFallback />}>
                          <ErrorBoundary moduleName="Mobile App Preview">
                            <MobilePreviewModule />
                          </ErrorBoundary>
                        </Suspense>
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/mobile_preview" element={<Navigate to="/mobile-preview" replace />} />

                  {/* Catch-all for portal: fallback to dashboard */}
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Routes>
    </AppLayout>
  );
};

/**
 * Root Application Router
 * Enforces:
 * 1. "/" strictly renders ChurchPeopleFrontpage with no auto-redirect.
 * 2. Unauthenticated visitors can freely access "/", "/login", "/register".
 * 3. "/dashboard" and portal modules remain protected behind ProtectedRoute.
 */
const MainAppRoutes: React.FC = () => {
  const navigate = useNavigate();
  const { userProfile, onboardingState, error: authError } = useAuth();
  const location = useLocation();

  // Supabase's default recovery email verifies the link and returns to Site URL
  // with type=recovery in the URL fragment. Route that session to the reset form.
  useEffect(() => {
    const hashParams = new URLSearchParams(location.hash.replace(/^#/, ''));
    const queryParams = new URLSearchParams(location.search);
    const isRecoveryLink =
      hashParams.get('type') === 'recovery' ||
      (queryParams.get('type') === 'recovery' && Boolean(queryParams.get('token_hash')));
    if (isRecoveryLink && location.pathname !== '/reset-password') {
      navigate(
        { pathname: '/reset-password', search: location.search, hash: location.hash },
        { replace: true }
      );
    }
  }, [location.pathname, location.search, location.hash, navigate]);

  // When Google OAuth redirects back to window.location.origin ('/'),
  // if the user is in an onboarding state (NEW_USER, PENDING, REJECTED) or hit WRONG_PORTAL,
  // navigate to /login so LoginPage displays GoogleAuthOnboarding or the portal error banner.
  useEffect(() => {
    if (
      location.pathname === '/' &&
      (onboardingState === 'NEW_USER' ||
        onboardingState === 'PENDING' ||
        onboardingState === 'REJECTED' ||
        (authError && authError.includes('Staff Portal')))
    ) {
      navigate('/login', { replace: true });
    }
  }, [location.pathname, onboardingState, authError, navigate]);

  const getBranchFromUrl = () => {
    const params = new URLSearchParams(location.search);
    return params.get('branch') || undefined;
  };

  return (
    <Routes>
      {/* 1. Base path strictly renders ChurchPeopleFrontpage without automatic redirect to /dashboard */}
      <Route
        path="/"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Church Portal Frontpage">
              <ChurchPeopleFrontpage
                onLaunchApp={() => {
                  navigate('/login');
                }}
                onEnterPortal={(role) => {
                  if (role && role !== 'REGULAR_MEMBER') {
                    navigate('/staff/login');
                  } else {
                    navigate('/login');
                  }
                }}
                onFindGroup={() => {
                  navigate('/login?redirect=/ministries');
                }}
                onOpenRegister={() => navigate('/register')}
                onOpenLogin={() => navigate('/login')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/landing"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Church Portal Frontpage">
              <ChurchPeopleFrontpage
                onLaunchApp={() => {
                  navigate('/login');
                }}
                onEnterPortal={(role) => {
                  if (role && role !== 'REGULAR_MEMBER') {
                    navigate('/staff/login');
                  } else {
                    navigate('/login');
                  }
                }}
                onFindGroup={() => {
                  navigate('/login?redirect=/ministries');
                }}
                onOpenRegister={() => navigate('/register')}
                onOpenLogin={() => navigate('/login')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />

      {/* 2. Public Login & Password Recovery Routes */}
      <Route
        path="/login"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Authentication">
              <LoginPage
                defaultTab="member"
                portalLocked
                onOpenGoogleForm={() => navigate('/register')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/login/member"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Authentication">
              <LoginPage
                defaultTab="member"
                portalLocked
                onOpenGoogleForm={() => navigate('/register')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/login/staff"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Staff Authentication">
              <LoginPage
                defaultTab="staff"
                portalLocked
                onOpenGoogleForm={() => navigate('/register')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/staff/login"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Staff Authentication">
              <LoginPage
                defaultTab="staff"
                portalLocked
                onOpenGoogleForm={() => navigate('/register')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/staff"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Staff Authentication">
              <LoginPage
                defaultTab="staff"
                portalLocked
                onOpenGoogleForm={() => navigate('/register')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/forgot-password"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Password Recovery">
              <LoginPage
                onOpenGoogleForm={() => navigate('/register')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/reset-password"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Password Reset">
              <SupabasePasswordResetPage />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/change-password"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Mandatory Password Change">
              <ChangePasswordPage />
            </ErrorBoundary>
          </Suspense>
        }
      />

      {/* 3. Public Member Registration Routes */}
      <Route
        path="/register/:token"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Registration">
              <TokenRegistrationRouteWrapper
                preSelectedBranchId={getBranchFromUrl()}
                onBackToPortal={() => navigate('/')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/register"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Registration">
              <GoogleFormRegistration
                preSelectedBranchId={getBranchFromUrl()}
                onBackToPortal={() => navigate('/')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/registration"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Registration">
              <GoogleFormRegistration
                preSelectedBranchId={getBranchFromUrl()}
                onBackToPortal={() => navigate('/')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/form"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Registration">
              <GoogleFormRegistration
                preSelectedBranchId={getBranchFromUrl()}
                onBackToPortal={() => navigate('/')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />
      <Route
        path="/google-form"
        element={
          <Suspense fallback={<ModuleLoadingFallback />}>
            <ErrorBoundary moduleName="Member Registration">
              <GoogleFormRegistration
                preSelectedBranchId={getBranchFromUrl()}
                onBackToPortal={() => navigate('/')}
              />
            </ErrorBoundary>
          </Suspense>
        }
      />

      {/* 4. Authenticated & Protected Application Shell */}
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <PortalLayout />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
};

const TokenRegistrationRouteWrapper: React.FC<{
  preSelectedBranchId?: string;
  onBackToPortal?: () => void;
}> = ({ preSelectedBranchId, onBackToPortal }) => {
  const { token } = useParams<{ token: string }>();
  return (
    <GoogleFormRegistration
      registrationToken={token}
      preSelectedBranchId={preSelectedBranchId}
      onBackToPortal={onBackToPortal}
    />
  );
};

export default function App() {
  return (
    <ErrorBoundary isRoot fallbackTitle="Application Error">
      <LanguageProvider>
        <AuthProvider>
          <CMMSProvider>
            <BibleProvider>
              <MainAppRoutes />
            </BibleProvider>
          </CMMSProvider>
        </AuthProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}

