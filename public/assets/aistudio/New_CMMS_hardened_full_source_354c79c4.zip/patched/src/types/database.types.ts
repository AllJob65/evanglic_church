export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          user_id?: string | null;
          tenant_id?: string | null;
          email: string;
          full_name: string;
          display_name?: string | null;
          member_id?: string | null;
          role: string;
          status?: string | null;
          branch_id: string | null;
          avatar_url: string | null;
          phone: string | null;
          must_change_password?: boolean | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          user_id?: string | null;
          tenant_id?: string | null;
          email: string;
          full_name: string;
          display_name?: string | null;
          member_id?: string | null;
          role?: string;
          status?: string | null;
          branch_id?: string | null;
          avatar_url?: string | null;
          phone?: string | null;
          must_change_password?: boolean | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          tenant_id?: string | null;
          email?: string;
          full_name?: string;
          display_name?: string | null;
          member_id?: string | null;
          role?: string;
          status?: string | null;
          branch_id?: string | null;
          avatar_url?: string | null;
          phone?: string | null;
          must_change_password?: boolean | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      members: {
        Row: {
          id: string;
          member_id_number: string;
          first_name: string;
          father_name: string;
          grand_father_name: string;
          mother_name: string | null;
          gender: 'Male' | 'Female';
          marital_status: 'Single' | 'Married' | 'Divorced' | 'Widowed';
          spouse_name: string | null;
          spouse_phone: string | null;
          date_of_birth: string | null;
          age: number | null;
          primary_phone: string;
          alt_phone: string | null;
          email: string | null;
          street_address: string | null;
          city: string;
          subcity: string | null;
          woreda: string | null;
          kebele: string | null;
          house_number: string | null;
          branch_id: string;
          membership_status: 'Active' | 'UnderCare' | 'Transferred' | 'Disciplined' | 'Deceased' | 'Inactive';
          membership_date: string;
          is_baptized: boolean;
          photo_url: string | null;
          emergency_contact_name: string | null;
          emergency_contact_phone: string | null;
          emergency_contact_relation: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          member_id_number: string;
          first_name: string;
          father_name: string;
          grand_father_name: string;
          mother_name?: string | null;
          gender: 'Male' | 'Female';
          marital_status?: 'Single' | 'Married' | 'Divorced' | 'Widowed';
          spouse_name?: string | null;
          spouse_phone?: string | null;
          date_of_birth?: string | null;
          age?: number | null;
          primary_phone: string;
          alt_phone?: string | null;
          email?: string | null;
          street_address?: string | null;
          city?: string;
          subcity?: string | null;
          woreda?: string | null;
          kebele?: string | null;
          house_number?: string | null;
          branch_id: string;
          membership_status?: 'Active' | 'UnderCare' | 'Transferred' | 'Disciplined' | 'Deceased' | 'Inactive';
          membership_date?: string;
          is_baptized?: boolean;
          photo_url?: string | null;
          emergency_contact_name?: string | null;
          emergency_contact_phone?: string | null;
          emergency_contact_relation?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          member_id_number?: string;
          first_name?: string;
          father_name?: string;
          grand_father_name?: string;
          mother_name?: string | null;
          gender?: 'Male' | 'Female';
          marital_status?: 'Single' | 'Married' | 'Divorced' | 'Widowed';
          spouse_name?: string | null;
          spouse_phone?: string | null;
          date_of_birth?: string | null;
          age?: number | null;
          primary_phone?: string;
          alt_phone?: string | null;
          email?: string | null;
          street_address?: string | null;
          city?: string;
          subcity?: string | null;
          woreda?: string | null;
          kebele?: string | null;
          house_number?: string | null;
          branch_id?: string;
          membership_status?: 'Active' | 'UnderCare' | 'Transferred' | 'Disciplined' | 'Deceased' | 'Inactive';
          membership_date?: string;
          is_baptized?: boolean;
          photo_url?: string | null;
          emergency_contact_name?: string | null;
          emergency_contact_phone?: string | null;
          emergency_contact_relation?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      attendance: {
        Row: {
          id: string;
          branch_id: string;
          event_type: string;
          event_date: string;
          total_attendees: number;
          male_count: number;
          female_count: number;
          children_count: number;
          first_timers_count: number;
          recorded_by: string;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          branch_id: string;
          event_type: string;
          event_date: string;
          total_attendees: number;
          male_count?: number;
          female_count?: number;
          children_count?: number;
          first_timers_count?: number;
          recorded_by: string;
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          branch_id?: string;
          event_type?: string;
          event_date?: string;
          total_attendees?: number;
          male_count?: number;
          female_count?: number;
          children_count?: number;
          first_timers_count?: number;
          recorded_by?: string;
          notes?: string | null;
          created_at?: string;
        };
      };
      contributions: {
        Row: {
          id: string;
          member_id: string | null;
          branch_id: string;
          contribution_type: 'Tithe' | 'Offering' | 'BuildingFund' | 'Missions' | 'Charity' | 'SpecialPledge';
          amount: number;
          currency: string;
          payment_method: 'Telebirr' | 'CBEBirr' | 'BankTransfer' | 'Cash' | 'Check';
          transaction_reference: string | null;
          transaction_date: string;
          recorded_by: string;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          member_id?: string | null;
          branch_id: string;
          contribution_type: 'Tithe' | 'Offering' | 'BuildingFund' | 'Missions' | 'Charity' | 'SpecialPledge';
          amount: number;
          currency?: string;
          payment_method: 'Telebirr' | 'CBEBirr' | 'BankTransfer' | 'Cash' | 'Check';
          transaction_reference?: string | null;
          transaction_date?: string;
          recorded_by: string;
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          member_id?: string | null;
          branch_id?: string;
          contribution_type?: 'Tithe' | 'Offering' | 'BuildingFund' | 'Missions' | 'Charity' | 'SpecialPledge';
          amount?: number;
          currency?: string;
          payment_method?: 'Telebirr' | 'CBEBirr' | 'BankTransfer' | 'Cash' | 'Check';
          transaction_reference?: string | null;
          transaction_date?: string;
          recorded_by?: string;
          notes?: string | null;
          created_at?: string;
        };
      };
      branches: {
        Row: {
          id: string;
          name: string;
          code: string;
          city: string;
          address: string;
          phone: string | null;
          is_main_hq: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          code: string;
          city: string;
          address: string;
          phone?: string | null;
          is_main_hq?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          code?: string;
          city?: string;
          address?: string;
          phone?: string | null;
          is_main_hq?: boolean;
          created_at?: string;
        };
      };
      ministries: {
        Row: {
          id: string;
          branch_id: string;
          name: string;
          description: string | null;
          category: string;
          leader_name: string | null;
          director_member_id: string | null;
          established_date: string;
          status: 'Active' | 'Inactive' | 'Archived';
          member_count: number;
          annual_budget: number;
          spent_budget: number;
          meeting_day: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          branch_id: string;
          name: string;
          description?: string | null;
          category?: string;
          leader_name?: string | null;
          director_member_id?: string | null;
          established_date?: string;
          status?: 'Active' | 'Inactive' | 'Archived';
          member_count?: number;
          annual_budget?: number;
          spent_budget?: number;
          meeting_day?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          branch_id?: string;
          name?: string;
          description?: string | null;
          category?: string;
          leader_name?: string | null;
          director_member_id?: string | null;
          established_date?: string;
          status?: 'Active' | 'Inactive' | 'Archived';
          member_count?: number;
          annual_budget?: number;
          spent_budget?: number;
          meeting_day?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      ministry_members: {
        Row: {
          id: string;
          ministry_id: string;
          user_id: string;
          role: 'Leader' | 'CoLeader' | 'Member' | 'Volunteer';
          status: 'Active' | 'Inactive' | 'Pending';
          joined_at: string;
        };
        Insert: {
          id?: string;
          ministry_id: string;
          user_id: string;
          role?: 'Leader' | 'CoLeader' | 'Member' | 'Volunteer';
          status?: 'Active' | 'Inactive' | 'Pending';
          joined_at?: string;
        };
        Update: {
          id?: string;
          ministry_id?: string;
          user_id?: string;
          role?: 'Leader' | 'CoLeader' | 'Member' | 'Volunteer';
          status?: 'Active' | 'Inactive' | 'Pending';
          joined_at?: string;
        };
      };
      ministry_messages: {
        Row: {
          id: string;
          ministry_id: string;
          sender_id: string | null;
          sender_name: string;
          sender_email: string | null;
          sender_role: string;
          sender_avatar: string | null;
          text: string;
          scripture_ref: string | null;
          attachment_url: string | null;
          attachment_name: string | null;
          is_pinned: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          ministry_id: string;
          sender_id?: string | null;
          sender_name: string;
          sender_email?: string | null;
          sender_role?: string;
          sender_avatar?: string | null;
          text: string;
          scripture_ref?: string | null;
          attachment_url?: string | null;
          attachment_name?: string | null;
          is_pinned?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          ministry_id?: string;
          sender_id?: string | null;
          sender_name?: string;
          sender_email?: string | null;
          sender_role?: string;
          sender_avatar?: string | null;
          text?: string;
          scripture_ref?: string | null;
          attachment_url?: string | null;
          attachment_name?: string | null;
          is_pinned?: boolean;
          created_at?: string;
        };
      };
      ministry_message_reactions: {
        Row: {
          id: string;
          message_id: string;
          user_id: string;
          user_name: string;
          emoji: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          message_id: string;
          user_id: string;
          user_name: string;
          emoji: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          message_id?: string;
          user_id?: string;
          user_name?: string;
          emoji?: string;
          created_at?: string;
        };
      };
      ministry_video_rooms: {
        Row: {
          id: string;
          ministry_id: string;
          title: string;
          host_id: string | null;
          host_name: string;
          is_active: boolean;
          participants: Json;
          started_at: string;
          ended_at: string | null;
        };
        Insert: {
          id?: string;
          ministry_id: string;
          title: string;
          host_id?: string | null;
          host_name: string;
          is_active?: boolean;
          participants?: Json;
          started_at?: string;
          ended_at?: string | null;
        };
        Update: {
          id?: string;
          ministry_id?: string;
          title?: string;
          host_id?: string | null;
          host_name?: string;
          is_active?: boolean;
          participants?: Json;
          started_at?: string;
          ended_at?: string | null;
        };
      };
      ministry_activity_logs: {
        Row: {
          id: string;
          ministry_id: string;
          user_id: string | null;
          user_name: string | null;
          action_type: string;
          title: string;
          description: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          ministry_id: string;
          user_id?: string | null;
          user_name?: string | null;
          action_type: string;
          title: string;
          description?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          ministry_id?: string;
          user_id?: string | null;
          user_name?: string | null;
          action_type?: string;
          title?: string;
          description?: string | null;
          created_at?: string;
        };
      };
      groups: {
        Row: {
          id: string;
          tenant_id: string;
          branch_id: string | null;
          name: string;
          category: string;
          leader_name: string | null;
          leader_member_id: string | null;
          meeting_schedule: string | null;
          location: string | null;
          member_count: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          branch_id?: string | null;
          name: string;
          category?: string;
          leader_name?: string | null;
          leader_member_id?: string | null;
          meeting_schedule?: string | null;
          location?: string | null;
          member_count?: number;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          tenant_id?: string;
          branch_id?: string | null;
          name?: string;
          category?: string;
          leader_name?: string | null;
          leader_member_id?: string | null;
          meeting_schedule?: string | null;
          location?: string | null;
          member_count?: number;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      attendance_records: {
        Row: {
          id: string;
          tenant_id: string;
          branch_id: string;
          event_id: string | null;
          service_type: string;
          member_id: string | null;
          check_in_time: string;
          verified_by: string | null;
          method: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          branch_id: string;
          event_id?: string | null;
          service_type?: string;
          member_id?: string | null;
          check_in_time?: string;
          verified_by?: string | null;
          method?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          tenant_id?: string;
          branch_id?: string;
          event_id?: string | null;
          service_type?: string;
          member_id?: string | null;
          check_in_time?: string;
          verified_by?: string | null;
          method?: string;
          created_at?: string;
        };
      };
      donations: {
        Row: {
          id: string;
          tenant_id: string;
          branch_id: string | null;
          member_id: string | null;
          donor_name: string | null;
          donor_email: string | null;
          amount: number;
          currency: string;
          category: string;
          payment_method: string;
          gateway_reference: string | null;
          status: string;
          is_anonymous: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          branch_id?: string | null;
          member_id?: string | null;
          donor_name?: string | null;
          donor_email?: string | null;
          amount: number;
          currency?: string;
          category?: string;
          payment_method?: string;
          gateway_reference?: string | null;
          status?: string;
          is_anonymous?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          tenant_id?: string;
          branch_id?: string | null;
          member_id?: string | null;
          donor_name?: string | null;
          donor_email?: string | null;
          amount?: number;
          currency?: string;
          category?: string;
          payment_method?: string;
          gateway_reference?: string | null;
          status?: string;
          is_anonymous?: boolean;
          created_at?: string;
        };
      };
      prayer_requests: {
        Row: {
          id: string;
          tenant_id: string;
          branch_id: string | null;
          request_number: string;
          member_id: string | null;
          requester_user_id: string | null;
          requester_name: string;
          category: string;
          title: string;
          description: string;
          is_confidential: boolean;
          urgency: string;
          status: string;
          assigned_intercessor_id: string | null;
          testimony_notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          branch_id?: string | null;
          request_number: string;
          member_id?: string | null;
          requester_user_id?: string | null;
          requester_name: string;
          category?: string;
          title: string;
          description: string;
          is_confidential?: boolean;
          urgency?: string;
          status?: string;
          assigned_intercessor_id?: string | null;
          testimony_notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          tenant_id?: string;
          branch_id?: string | null;
          request_number?: string;
          member_id?: string | null;
          requester_user_id?: string | null;
          requester_name?: string;
          category?: string;
          title?: string;
          description?: string;
          is_confidential?: boolean;
          urgency?: string;
          status?: string;
          assigned_intercessor_id?: string | null;
          testimony_notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      counseling: {
        Row: {
          id: string;
          tenant_id: string;
          branch_id: string | null;
          session_code: string;
          client_member_id: string | null;
          client_name: string;
          counselor_user_id: string | null;
          counselor_name: string;
          counseling_type: string;
          session_date: string;
          status: string;
          confidentiality: string;
          private_clinical_notes: string | null;
          action_items: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          branch_id?: string | null;
          session_code: string;
          client_member_id?: string | null;
          client_name: string;
          counselor_user_id?: string | null;
          counselor_name: string;
          counseling_type?: string;
          session_date: string;
          status?: string;
          confidentiality?: string;
          private_clinical_notes?: string | null;
          action_items?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          tenant_id?: string;
          branch_id?: string | null;
          session_code?: string;
          client_member_id?: string | null;
          client_name?: string;
          counselor_user_id?: string | null;
          counselor_name?: string;
          counseling_type?: string;
          session_date?: string;
          status?: string;
          confidentiality?: string;
          private_clinical_notes?: string | null;
          action_items?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      conversations: {
        Row: {
          id: string;
          type: 'direct' | 'ad_hoc_group' | 'video';
          title: string | null;
          created_by: string;
          tenant_id: string;
          branch_id: string | null;
          status: 'active' | 'ended';
          created_at: string;
          ended_at: string | null;
        };
        Insert: {
          id?: string;
          type: 'direct' | 'ad_hoc_group' | 'video';
          title?: string | null;
          created_by: string;
          tenant_id: string;
          branch_id?: string | null;
          status?: 'active' | 'ended';
          created_at?: string;
          ended_at?: string | null;
        };
        Update: {
          id?: string;
          type?: 'direct' | 'ad_hoc_group' | 'video';
          title?: string | null;
          created_by?: string;
          tenant_id?: string;
          branch_id?: string | null;
          status?: 'active' | 'ended';
          created_at?: string;
          ended_at?: string | null;
        };
      };
      conversation_participants: {
        Row: {
          id: string;
          conversation_id: string;
          user_id: string;
          added_by: string;
          added_at: string;
          left_at: string | null;
        };
        Insert: {
          id?: string;
          conversation_id: string;
          user_id: string;
          added_by: string;
          added_at?: string;
          left_at?: string | null;
        };
        Update: {
          id?: string;
          conversation_id?: string;
          user_id?: string;
          added_by?: string;
          added_at?: string;
          left_at?: string | null;
        };
      };
      conversation_messages: {
        Row: {
          id: string;
          conversation_id: string;
          sender_id: string;
          body: string;
          created_at: string;
          edited_at: string | null;
          deleted_at: string | null;
        };
        Insert: {
          id?: string;
          conversation_id: string;
          sender_id: string;
          body: string;
          created_at?: string;
          edited_at?: string | null;
          deleted_at?: string | null;
        };
        Update: {
          id?: string;
          conversation_id?: string;
          sender_id?: string;
          body?: string;
          created_at?: string;
          edited_at?: string | null;
          deleted_at?: string | null;
        };
      };
      [key: string]: {
        Row: Record<string, any>;
        Insert: Record<string, any>;
        Update: Record<string, any>;
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      is_super_admin: {
        Args: Record<PropertyKey, never>;
        Returns: boolean;
      };
      get_user_branch: {
        Args: Record<PropertyKey, never>;
        Returns: string;
      };
    };
    Enums: {
      [_ in never]: never;
    };
  };
}
