import { Router } from 'express';
import { pastoralController } from '../controllers/pastoralController';
import { authenticateJWT } from '../middleware/authMiddleware';
import { tenantContextMiddleware } from '../middleware/tenantMiddleware';
import { requirePermission } from '../middleware/rbacMiddleware';

const router = Router();

router.use(authenticateJWT);
router.use(tenantContextMiddleware);

// Pastoral Notes & Confidential Counseling
router.get('/notes', requirePermission('pastoral.read'), (req, res) => pastoralController.getNotes(req, res));
router.post('/notes', requirePermission('pastoral.create'), (req, res) => pastoralController.createNote(req, res));

// Prayer Requests
router.get('/prayer', requirePermission('prayer.read'), (req, res) => pastoralController.getPrayers(req, res));
router.post('/prayer', requirePermission('prayer.create'), (req, res) => pastoralController.createPrayer(req, res));
router.put('/prayer/:id/status', requirePermission('prayer.update'), (req, res) => pastoralController.updatePrayerStatus(req, res));

// Counseling Sessions
router.get('/counseling', requirePermission('counseling.read'), (req, res) => pastoralController.getCounseling(req, res));
router.post('/counseling', requirePermission('counseling.create'), (req, res) => pastoralController.createCounseling(req, res));
router.put('/counseling/:id/status', requirePermission('counseling.create'), (req, res) => pastoralController.updateCounselingStatus(req, res));

// Visitations
router.get('/visitations', requirePermission('visitations.read'), (req, res) => pastoralController.getVisitations(req, res));
router.post('/visitations', requirePermission('visitations.manage'), (req, res) => pastoralController.createVisitation(req, res));

export default router;
