import { Router } from 'express';
import { memberController } from '../controllers/memberController';
import { authenticateJWT } from '../middleware/authMiddleware';
import { tenantContextMiddleware } from '../middleware/tenantMiddleware';
import { requirePermission } from '../middleware/rbacMiddleware';

const router = Router();

// Apply auth & tenant context to all member routes
router.use(authenticateJWT);
router.use(tenantContextMiddleware);

// Members CRUD
router.get('/', requirePermission('members.read'), (req, res) => memberController.getMembers(req, res));
router.get('/:id', requirePermission('members.read'), (req, res) => memberController.getMemberById(req, res));
router.post('/', requirePermission('members.create'), (req, res) => memberController.createMember(req, res));
router.put('/:id', requirePermission('members.update'), (req, res) => memberController.updateMember(req, res));
router.delete('/:id', requirePermission('members.delete'), (req, res) => memberController.deleteMember(req, res));
router.post('/:id/photo', requirePermission('members.update'), (req, res) => memberController.uploadPhoto(req, res));
router.post('/bulk', requirePermission('members.create'), (req, res) => memberController.bulkImport(req, res));

// Families CRUD
router.get('/families/all', requirePermission('families.read'), (req, res) => memberController.getFamilies(req, res));
router.post('/families', requirePermission('families.create'), (req, res) => memberController.createFamily(req, res));
router.put('/families/:id', requirePermission('families.update'), (req, res) => memberController.updateFamily(req, res));

export default router;
