import { Router } from 'express';
import authRoutes from './authRoutes';
import memberRoutes from './memberRoutes';
import attendanceRoutes from './attendanceRoutes';
import pastoralRoutes from './pastoralRoutes';
import approvalRoutes from './approvalRoutes';
import queueRoutes from './queueRoutes';

const router = Router();

router.use('/auth', authRoutes);
router.use('/members', memberRoutes);
router.use('/attendance', attendanceRoutes);
router.use('/pastoral', pastoralRoutes);
router.use('/approvals', approvalRoutes);
router.use('/queue', queueRoutes);

export default router;
