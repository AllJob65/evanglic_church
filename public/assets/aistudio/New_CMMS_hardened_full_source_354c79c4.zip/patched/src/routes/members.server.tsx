import type { LoaderFunctionArgs, ActionFunctionArgs } from 'react-router-dom';
import { createSupabaseServerClient } from '../utils/supabase.server';
import { emailSchema, sanitizeEmail } from '../schemas/email.schema';
import { validateEthiopianPhone, formatToE164 } from '../schemas/phone.schema';
import { z } from 'zod';

// Member Form Submission Validation Schema for Action Handler
const memberFormActionSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters').trim(),
  fatherName: z.string().min(2, 'Father name must be at least 2 characters').trim(),
  grandFatherName: z.string().min(2, 'Grandfather name is required').trim(),
  gender: z.enum(['Male', 'Female']),
  maritalStatus: z.enum(['Single', 'Married', 'Divorced', 'Widowed']).default('Single'),
  spouseName: z.string().optional().transform((val) => (val ? val.trim() : undefined)),
  spousePhone: z
    .string()
    .optional()
    .transform((val) => (val ? val.trim() : ''))
    .refine((val) => {
      if (!val || val === '') return true;
      return validateEthiopianPhone(val).isValid;
    }, {
      message: 'Invalid Ethiopian phone format for spouse (must be 09/07 or +2519/+2517)',
    })
    .transform((val) => (val ? formatToE164(val) : undefined)),
  primaryPhone: z
    .string()
    .transform((val) => val.trim())
    .refine((val) => validateEthiopianPhone(val).isValid, {
      message: 'Invalid Ethiopian phone format (must be 09/07 or +2519/+2517 with 8 digits)',
    })
    .transform((val) => formatToE164(val)),
  email: z
    .string()
    .optional()
    .transform((val) => (val ? sanitizeEmail(val) : undefined))
    .pipe(emailSchema.optional()),
  branchId: z.string().min(1, 'Branch selection is required'),
});

/**
 * React Router v7 / Remix Server Loader
 * Queries members securely using authenticated session and returns synchronized cookie headers
 */
export async function loader({ request }: LoaderFunctionArgs) {
  const { supabase, headers } = createSupabaseServerClient(request);

  // Authenticate user session
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return Response.json(
      { error: 'Unauthorized: Please log in', user: null, members: [] },
      { status: 401, headers }
    );
  }

  // Fetch members with RLS applied at database level
  const { data: members, error: dbError } = await supabase
    .from('members')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);

  if (dbError) {
    return Response.json(
      { error: dbError.message, user, members: [] },
      { status: 500, headers }
    );
  }

  return Response.json(
    { members: members ?? [], user, error: null },
    { status: 200, headers }
  );
}

/**
 * React Router v7 / Remix Server Action
 * Validates incoming form data with Zod and commits to Supabase with session headers
 */
export async function action({ request }: ActionFunctionArgs) {
  const { supabase, headers } = createSupabaseServerClient(request);

  // Verify authentication
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return Response.json(
      { success: false, error: 'Unauthorized' },
      { status: 401, headers }
    );
  }

  const formData = await request.formData();
  const rawData = Object.fromEntries(formData.entries());

  // Strict Runtime Validation
  const parseResult = memberFormActionSchema.safeParse(rawData);
  if (!parseResult.success) {
    return Response.json(
      {
        success: false,
        errors: parseResult.error.flatten().fieldErrors,
      },
      { status: 400, headers }
    );
  }

  const validated = parseResult.data;
  const newMemberIdNumber = `GC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  // Insert into Supabase table (protected by RLS)
  const insertPayload = {
    member_id_number: newMemberIdNumber,
    first_name: validated.firstName,
    father_name: validated.fatherName,
    grand_father_name: validated.grandFatherName,
    gender: validated.gender,
    marital_status: validated.maritalStatus,
    spouse_name: validated.maritalStatus === 'Married' ? validated.spouseName ?? null : null,
    spouse_phone: validated.maritalStatus === 'Married' ? validated.spousePhone ?? null : null,
    primary_phone: validated.primaryPhone,
    email: validated.email ?? null,
    branch_id: validated.branchId,
    membership_status: 'Active' as const,
    membership_date: new Date().toISOString().split('T')[0],
    city: 'Addis Ababa',
  };

  const { data, error } = await supabase
    .from('members')
    .insert(insertPayload as any)
    .select()
    .single();

  if (error) {
    return Response.json(
      { success: false, error: error.message },
      { status: 500, headers }
    );
  }

  return Response.json(
    { success: true, member: data, error: null },
    { status: 201, headers }
  );
}
