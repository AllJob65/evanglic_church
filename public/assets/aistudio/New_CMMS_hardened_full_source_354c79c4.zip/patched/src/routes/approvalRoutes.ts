import { Router } from 'express';
import { approvalController } from '../controllers/approvalController';
import { authenticateJWT } from '../middleware/authMiddleware';
import { tenantContextMiddleware } from '../middleware/tenantMiddleware';
import { requirePermission } from '../middleware/rbacMiddleware';

const router = Router();

router.use(authenticateJWT);
router.use(tenantContextMiddleware);

// Approval Queue
router.get('/', requirePermission('workflows.manage'), (req, res) => approvalController.getQueue(req, res));
router.post('/submit', requirePermission('workflows.create'), (req, res) => approvalController.submit(req, res));
router.post('/:id/approve', requirePermission('workflows.manage'), (req, res) => approvalController.approve(req, res));
router.post('/:id/reject', requirePermission('workflows.manage'), (req, res) => approvalController.reject(req, res));

export default router;
