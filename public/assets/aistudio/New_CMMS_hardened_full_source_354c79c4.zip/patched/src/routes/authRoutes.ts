import authRouter from '../../server/routes/auth';

export default authRouter;

