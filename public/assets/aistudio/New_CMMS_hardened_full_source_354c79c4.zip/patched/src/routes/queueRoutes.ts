import { Router } from 'express';
import { queueService } from '../services/queueService';
import { authenticateJWT } from '../middleware/authMiddleware';
import { requireRoles } from '../middleware/rbacMiddleware';

const router = Router();

router.use(authenticateJWT);

// View queue stats & active jobs
router.get('/stats', requireRoles('SYSTEM_ADMIN'), (req, res) => {
  res.json(queueService.getStats());
});

router.get('/jobs', requireRoles('SYSTEM_ADMIN'), (req, res) => {
  const status = req.query.status as any;
  res.json(queueService.getJobs(status));
});

// Trigger asynchronous background task
router.post('/jobs', requireRoles('SYSTEM_ADMIN'), async (req, res) => {
  const { name, data } = req.body || {};
  if (typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'Job name is required' });
  }
  try {
    const job = await queueService.addJob(name as any, data);
    return res.status(202).json({
      success: true,
      message: `Background task '${name}' enqueued successfully`,
      job,
    });
  } catch (error) {
    if ((error as any)?.code === 'QUEUE_BACKEND_UNAVAILABLE') {
      return res.status(503).json({
        error: 'Durable background processing is not configured. No task was accepted.',
        code: 'QUEUE_BACKEND_UNAVAILABLE',
      });
    }
    return res.status(500).json({ error: 'Unable to enqueue background task.', code: 'QUEUE_ENQUEUE_FAILED' });
  }
});

export default router;
