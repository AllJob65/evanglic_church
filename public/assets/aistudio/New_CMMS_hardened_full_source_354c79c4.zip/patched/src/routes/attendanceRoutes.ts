import { Router } from 'express';
import { attendanceController } from '../controllers/attendanceController';
import { authenticateJWT } from '../middleware/authMiddleware';
import { tenantContextMiddleware } from '../middleware/tenantMiddleware';
import { requirePermission } from '../middleware/rbacMiddleware';

const router = Router();

router.use(authenticateJWT);
router.use(tenantContextMiddleware);

// Fast write & bulk attendance
router.get('/', requirePermission('attendance.read'), (req, res) => attendanceController.getAttendance(req, res));
router.post('/check-in', requirePermission('attendance.create'), (req, res) => attendanceController.checkIn(req, res));
router.post('/bulk', requirePermission('attendance.create'), (req, res) => attendanceController.bulkAttendance(req, res));
router.get('/live-counts', requirePermission('attendance.read'), (req, res) => attendanceController.getLiveCounts(req, res));

// Event calendar
router.get('/events/all', requirePermission('events.read'), (req, res) => attendanceController.getEvents(req, res));
router.post('/events', requirePermission('events.manage'), (req, res) => attendanceController.createEvent(req, res));

export default router;
