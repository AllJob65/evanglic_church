import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import enTranslations from './locales/en.json';
import amTranslations from './locales/am.json';
import tiTranslations from './locales/ti.json';
import omTranslations from './locales/om.json';
import amOverrides from './locales/overrides/am.override.json';
import amMachineTranslations from './locales/machine/am.json';
import tiMachineTranslations from './locales/machine/ti.json';
import omMachineTranslations from './locales/machine/om.json';

export type LanguageCode = 'en' | 'am' | 'ti' | 'om';
export type SupportedLanguage = LanguageCode | 'English' | 'Amharic' | 'Tigrigna' | 'Afaan Oromoo' | 'Oromo';

export const CODE_TO_NAME: Record<LanguageCode, string> = {
  en: 'English',
  am: 'Amharic',
  ti: 'Tigrigna',
  om: 'Afaan Oromoo',
};

export const NAME_TO_CODE: Record<string, LanguageCode> = {
  English: 'en',
  Amharic: 'am',
  Tigrigna: 'ti',
  'Afaan Oromoo': 'om',
  Oromo: 'om',
  en: 'en',
  am: 'am',
  ti: 'ti',
  om: 'om',
};

export interface LanguageContextType {
  language: LanguageCode;
  langCode: LanguageCode;
  languageName: string;
  setLanguage: (lang: SupportedLanguage | string) => void;
  t: (key: string, paramsOrDefault?: string | Record<string, string | number>, maybeFallback?: string) => string;
  fontClass: string;
  isEthiopic: boolean;
}

const STORAGE_KEY = 'cmms_app_language';

// Helper to normalize language code
export function normalizeLanguageCode(lang: string | null | undefined): LanguageCode {
  if (!lang) return 'en';
  const lower = lang.toLowerCase().trim();
  if (lower === 'am' || lower === 'amharic' || lower === 'አማርኛ' || lower === 'አማ') return 'am';
  if (lower === 'ti' || lower === 'tigrigna' || lower === 'tigrinya' || lower === 'ትግርኛ' || lower === 'ትግ') return 'ti';
  if (lower === 'om' || lower === 'oromo' || lower === 'afaan oromoo' || lower === 'oromoo') return 'om';
  return 'en';
}

export function isUnifiedLanguage(lang: string | null | undefined): boolean {
  if (!lang) return false;
  const lower = lang.toLowerCase().trim();
  return (
    lower === 'en' || lower === 'english' ||
    lower === 'am' || lower === 'amharic' || lower === 'አማርኛ' || lower === 'አማ' ||
    lower === 'ti' || lower === 'tigrigna' || lower === 'tigrinya' || lower === 'ትግርኛ' || lower === 'ትግ' ||
    lower === 'om' || lower === 'oromo' || lower === 'afaan oromoo' || lower === 'oromoo'
  );
}

// Separate Human vs Machine dictionaries according to strict priority order:
// 1. Human value in active locale file (am, ti, om) + human overrides
// 2. Machine fallback if available (stored separately, never overwriting human value)
// 3. English master value from en.json
// 4. Fallback string or key
const humanDictionaries: Record<LanguageCode, Record<string, string>> = {
  en: enTranslations,
  am: {
    ...amTranslations,
    ...amOverrides,
  },
  ti: tiTranslations,
  om: omTranslations,
};

const machineDictionaries: Record<LanguageCode, Record<string, string>> = {
  en: {},
  am: amMachineTranslations as Record<string, string>,
  ti: tiMachineTranslations as Record<string, string>,
  om: omMachineTranslations as Record<string, string>,
};

// Kept for backward compatibility if any module reads dictionaries directly
export const dictionaries = humanDictionaries;

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return normalizeLanguageCode(saved);
    } catch {
      return 'en';
    }
  });

  const isEthiopic = language === 'am' || language === 'ti';
  const fontClass = isEthiopic ? 'font-menbere' : 'font-montserrat';

  const setLanguage = (lang: SupportedLanguage | string) => {
    const code = normalizeLanguageCode(lang);
    setLanguageState(code);
    try {
      localStorage.setItem(STORAGE_KEY, code);
    } catch (e) {
      console.warn('Failed to save language preference:', e);
    }
  };

  // Cross-tab and window storage synchronization
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        const code = normalizeLanguageCode(e.newValue);
        setLanguageState(code);
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Sync font classes on HTML root and body and set document.documentElement.lang
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    
    // Remove previous script classes
    root.classList.remove('font-menbere', 'font-montserrat', 'font-amharic');
    body.classList.remove('font-menbere', 'font-montserrat', 'font-amharic');

    root.lang = language;
    root.setAttribute('lang', language);

    if (isEthiopic) {
      root.classList.add('font-menbere');
      body.classList.add('font-menbere');
    } else {
      root.classList.add('font-montserrat');
      body.classList.add('font-montserrat');
    }
  }, [language, isEthiopic]);

  const languageName = useMemo(() => {
    switch (language) {
      case 'am':
        return 'አማርኛ (Amharic)';
      case 'ti':
        return 'ትግርኛ (Tigrigna)';
      case 'om':
        return 'Afaan Oromoo (Oromo)';
      default:
        return 'English';
    }
  }, [language]);

  const t = (
    key: string,
    paramsOrDefault?: string | Record<string, string | number>,
    maybeFallback?: string
  ): string => {
    if (!key) return '';
    const trimmedKey = key.trim();
    const humanDict = humanDictionaries[language] || humanDictionaries.en;
    const machineDict = machineDictionaries[language] || {};
    const defaultFallback =
      typeof paramsOrDefault === 'string'
        ? paramsOrDefault
        : maybeFallback || key;

    // TRANSLATION SOURCE ORDER (for am, ti, om):
    // 1. A human-written value in the active locale file (key or trimmedKey)
    // 2. If fallback text is provided and language !== 'en', check if fallback string exists in humanDict!
    // 3. A machine translation fallback if available
    // 4. The English string from en.json (key, trimmedKey, or defaultFallback)
    // 5. The defaultFallback string
    let text =
      humanDict[key] ??
      humanDict[trimmedKey] ??
      (language !== 'en' && typeof paramsOrDefault === 'string'
        ? (humanDict[paramsOrDefault] ?? humanDict[paramsOrDefault.trim()])
        : undefined) ??
      (language !== 'en' && maybeFallback
        ? (humanDict[maybeFallback] ?? humanDict[maybeFallback.trim()])
        : undefined) ??
      machineDict[key] ??
      machineDict[trimmedKey] ??
      enTranslations[key as keyof typeof enTranslations] ??
      enTranslations[trimmedKey as keyof typeof enTranslations] ??
      (typeof paramsOrDefault === 'string'
        ? (enTranslations[paramsOrDefault as keyof typeof enTranslations] ??
           enTranslations[paramsOrDefault.trim() as keyof typeof enTranslations])
        : undefined) ??
      defaultFallback;

    if (paramsOrDefault && typeof paramsOrDefault === 'object') {
      Object.entries(paramsOrDefault).forEach(([paramKey, paramValue]) => {
        // Matches {{paramKey}} or {paramKey}
        const regex = new RegExp(`{{\\s*${paramKey}\\s*}}|{\\s*${paramKey}\\s*}`, 'g');
        text = text.replace(regex, String(paramValue));
      });
    }

    return text;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        langCode: language,
        languageName,
        setLanguage,
        t,
        fontClass,
        isEthiopic,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    // Fallback if rendered outside provider
    return {
      language: 'en',
      langCode: 'en',
      languageName: 'English',
      setLanguage: () => {},
      t: (key: string, paramsOrDefault?: string | Record<string, string | number>, maybeFallback?: string) => {
        const defaultFallback = typeof paramsOrDefault === 'string' ? paramsOrDefault : maybeFallback || key;
        let text = enTranslations[key as keyof typeof enTranslations] || defaultFallback;
        if (paramsOrDefault && typeof paramsOrDefault === 'object') {
          Object.entries(paramsOrDefault).forEach(([k, v]) => {
            text = text.replace(new RegExp(`{{\\s*${k}\\s*}}|{\\s*${k}\\s*}`, 'g'), String(v));
          });
        }
        return text;
      },
      fontClass: 'font-montserrat',
      isEthiopic: false,
    };
  }
  return context;
};

export default LanguageContext;
