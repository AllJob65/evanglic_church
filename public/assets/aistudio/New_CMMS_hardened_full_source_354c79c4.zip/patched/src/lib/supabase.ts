import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/database.types';

const rawUrl = (
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_URL) ||
  (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_URL) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_URL) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_URL) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.NEXT_PUBLIC_SUPABASE_URL) ||
  ''
).trim();

// Ensure the clean root project URL is used (strip any trailing /rest/v1/ or slashes)
export const supabaseUrl = rawUrl ? rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '') : '';

export const rawKey = (
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_ANON_KEY) ||
  (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_ANON_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_ANON_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_SERVICE_ROLE_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_SECRET_KEY) ||
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_PUBLISHABLE_KEY) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_ANON_KEY) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.NEXT_PUBLIC_SUPABASE_ANON_KEY) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
  ''
).trim();

/**
 * Validates whether a key is a privileged secret / service_role key.
 * Supabase strictly prohibits using secret keys in the browser ("Forbidden use of secret API key in browser").
 */
export const isSecretKey = (key: string): boolean => {
  if (!key) return false;
  const k = key.trim().toLowerCase();
  return k.startsWith('sb_secret_') || k.includes('service_role') || k.includes('secret');
};

const isBrowser = typeof window !== 'undefined';

// Filter out secret keys in the browser to prevent "Forbidden use of secret API key in browser" error
export const supabaseAnonKey = isBrowser && isSecretKey(rawKey) ? '' : rawKey;

// Server-side code can safely use service_role / secret key; browser requires a safe public anon key
export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseUrl.startsWith('http') &&
  !supabaseUrl.includes('placeholder') &&
  !supabaseUrl.includes('unconfigured') &&
  (isBrowser ? Boolean(supabaseAnonKey && !isSecretKey(supabaseAnonKey)) : Boolean(rawKey))
);

// Effective key for client instance
const effectiveKey = isBrowser
  ? (isSupabaseConfigured ? supabaseAnonKey : 'unconfigured-public-anon-key')
  : (rawKey || 'unconfigured-public-anon-key');

const effectiveUrl = (isSupabaseConfigured || (!isBrowser && rawKey))
  ? supabaseUrl
  : 'https://unconfigured.supabase.local';

export const REMEMBER_ME_KEY = 'cmms-remember-me';

// In-memory fallback storage for mobile private browsing / restricted webviews
const memoryStorage = new Map<string, string>();

const safeGetItem = (storage: Storage | undefined, key: string): string | null => {
  try {
    return storage ? storage.getItem(key) : (memoryStorage.get(key) ?? null);
  } catch {
    return memoryStorage.get(key) ?? null;
  }
};

const safeSetItem = (storage: Storage | undefined, key: string, value: string): void => {
  memoryStorage.set(key, value);
  try {
    storage?.setItem(key, value);
  } catch {
    // Fallback to memoryStorage on mobile Safari private mode / quota error
  }
};

const safeRemoveItem = (storage: Storage | undefined, key: string): void => {
  memoryStorage.delete(key);
  try {
    storage?.removeItem(key);
  } catch {
    // Ignore storage removal errors
  }
};

/**
 * Checks whether the user selected Remember Me.
 * Checked (true) -> localStorage (persists across browser restarts)
 * Unchecked (false) -> sessionStorage (cleared when browser closes)
 */
export const isRememberMeActive = (): boolean => {
  if (!isBrowser) return true;
  if (safeGetItem(localStorage, REMEMBER_ME_KEY) === 'true') return true;
  if (safeGetItem(sessionStorage, REMEMBER_ME_KEY) === 'false') return false;
  if (safeGetItem(localStorage, REMEMBER_ME_KEY) === 'false') return false;
  return true;
};

/**
 * Sets the Remember Me preference flag in the appropriate storage.
 */
export const setRememberMeActive = (remember: boolean) => {
  if (!isBrowser) return;
  if (remember) {
    safeSetItem(localStorage, REMEMBER_ME_KEY, 'true');
    safeRemoveItem(sessionStorage, REMEMBER_ME_KEY);
  } else {
    safeSetItem(sessionStorage, REMEMBER_ME_KEY, 'false');
    safeRemoveItem(localStorage, REMEMBER_ME_KEY);
  }
};

/**
 * Custom storage adapter for Supabase Auth that delegates to
 * localStorage or sessionStorage based on the Remember Me preference.
 */
export const authStorageAdapter = {
  getItem: (key: string): string | null => {
    if (!isBrowser) return null;
    const remember = isRememberMeActive();
    if (remember) {
      return safeGetItem(localStorage, key) ?? safeGetItem(sessionStorage, key);
    } else {
      return safeGetItem(sessionStorage, key) ?? safeGetItem(localStorage, key);
    }
  },
  setItem: (key: string, value: string): void => {
    if (!isBrowser) return;
    const remember = isRememberMeActive();
    if (remember) {
      safeSetItem(localStorage, key, value);
      safeRemoveItem(sessionStorage, key);
    } else {
      safeSetItem(sessionStorage, key, value);
      safeRemoveItem(localStorage, key);
    }
  },
  removeItem: (key: string): void => {
    if (!isBrowser) return;
    safeRemoveItem(localStorage, key);
    safeRemoveItem(sessionStorage, key);
  },
};

/**
 * Store an application authentication token in the active storage
 */
export const storeAuthToken = (token: string, remember: boolean) => {
  if (!isBrowser) return;
  setRememberMeActive(remember);
  if (remember) {
    safeSetItem(localStorage, 'cmms_access_token', token);
    safeRemoveItem(sessionStorage, 'cmms_access_token');
  } else {
    safeSetItem(sessionStorage, 'cmms_access_token', token);
    safeRemoveItem(localStorage, 'cmms_access_token');
  }
};

/**
 * Store an application refresh token in the active storage
 */
export const storeRefreshToken = (refreshToken: string, remember: boolean) => {
  if (!isBrowser || !refreshToken) return;
  if (remember) {
    safeSetItem(localStorage, 'cmms_refresh_token', refreshToken);
    safeRemoveItem(sessionStorage, 'cmms_refresh_token');
  } else {
    safeSetItem(sessionStorage, 'cmms_refresh_token', refreshToken);
    safeRemoveItem(localStorage, 'cmms_refresh_token');
  }
};

/**
 * Store user profile in the active storage
 */
export const storeAuthUser = (user: any, remember: boolean) => {
  if (!isBrowser) return;
  const json = JSON.stringify(user);
  if (remember) {
    safeSetItem(localStorage, 'cmms_auth_user', json);
    safeRemoveItem(sessionStorage, 'cmms_auth_user');
  } else {
    safeSetItem(sessionStorage, 'cmms_auth_user', json);
    safeRemoveItem(localStorage, 'cmms_auth_user');
  }
};

/**
 * Retrieve the active auth token from either sessionStorage or localStorage
 */
export const getStoredAuthToken = (): string | null => {
  if (!isBrowser) return null;
  return safeGetItem(sessionStorage, 'cmms_access_token') || safeGetItem(localStorage, 'cmms_access_token');
};

/**
 * Retrieve the active refresh token from either sessionStorage or localStorage
 */
export const getStoredRefreshToken = (): string | null => {
  if (!isBrowser) return null;
  return safeGetItem(sessionStorage, 'cmms_refresh_token') || safeGetItem(localStorage, 'cmms_refresh_token');
};

/**
 * Retrieve the active auth user from either sessionStorage or localStorage
 */
export const getStoredAuthUser = (): any | null => {
  if (!isBrowser) return null;
  const raw = safeGetItem(sessionStorage, 'cmms_auth_user') || safeGetItem(localStorage, 'cmms_auth_user');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

/**
 * Clear all authentication records from both localStorage and sessionStorage
 */
export const clearAllAuthStorage = () => {
  memoryStorage.clear();
  if (!isBrowser) return;
  safeRemoveItem(localStorage, 'cmms_access_token');
  safeRemoveItem(localStorage, 'cmms_refresh_token');
  safeRemoveItem(localStorage, 'cmms_auth_user');
  safeRemoveItem(localStorage, REMEMBER_ME_KEY);
  safeRemoveItem(sessionStorage, 'cmms_access_token');
  safeRemoveItem(sessionStorage, 'cmms_refresh_token');
  safeRemoveItem(sessionStorage, 'cmms_auth_user');
  safeRemoveItem(sessionStorage, REMEMBER_ME_KEY);

  const clearTargetKeys = (storage: Storage) => {
    try {
      for (let i = storage.length - 1; i >= 0; i--) {
        const key = storage.key(i);
        if (
          key &&
          (key.startsWith('sb-') ||
            key.includes('supabase') ||
            key.startsWith('cmms_access_token') ||
            key.startsWith('cmms_refresh_token') ||
            key.startsWith('cmms_auth_user'))
        ) {
          storage.removeItem(key);
        }
      }
    } catch (e) {
      console.warn('Storage purge notice:', e);
    }
  };

  clearTargetKeys(localStorage);
  clearTargetKeys(sessionStorage);
};

// Client-safe Supabase instance (fails securely with stub when unconfigured or in browser with secret key)
export const supabase = createClient<any>(
  effectiveUrl,
  effectiveKey,
  {
    auth: {
      persistSession: isBrowser,
      autoRefreshToken: isBrowser,
      detectSessionInUrl: isBrowser,
      storage: authStorageAdapter,
    },
  }
);

// Helper to create an isolated administrative client that bypasses RLS and prevents in-memory session mutation
export const getAdminClient = () => {
  return !isBrowser && rawKey
    ? createClient<any>(supabaseUrl || 'https://unconfigured.supabase.local', rawKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
          detectSessionInUrl: false,
        },
      })
    : supabase;
};

// Helper to create a clean isolated auth client for signInWithPassword / refreshSession on the server
export const createIsolatedAuthClient = () => {
  const keyToUse = supabaseAnonKey || rawKey || 'unconfigured-public-anon-key';
  return createClient<any>(supabaseUrl || 'https://unconfigured.supabase.local', keyToUse, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  });
};

// Server-side administrative client (bypasses RLS with secret key, persists no user session)
export const adminSupabase = getAdminClient();



