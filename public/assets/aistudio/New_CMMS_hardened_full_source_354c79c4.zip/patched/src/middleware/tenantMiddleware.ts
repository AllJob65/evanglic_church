import type { Response, NextFunction } from 'express';
import type { AuthenticatedRequest } from './authMiddleware';

/**
 * Tenant & branch isolation.
 *
 * Replaces the original, which
 *  - fell back to a hard-coded tenant ('tenant-grace-main') and branch ('br-1'),
 *  - trusted X-Tenant-ID / ?tenantId from unauthenticated callers,
 *  - let PASTOR / MANAGER pick ANY branch string via header or query without checking
 *    it against the branches they are assigned to,
 *  - echoed tenant and branch ids back in response headers.
 *
 * Contract: after this middleware, `req.tenantId` / `req.branchId` come from the verified
 * session or from server-side configuration, never from client input.
 */

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
/** Legacy short ids still present in older data ("br-001", "b-1"). */
const LEGACY_BRANCH_RE = /^b(?:r)?-\d{1,6}$/i;

const BRANCH_WILDCARD_ROLES = new Set(['SYSTEM_ADMIN', 'PASTOR', 'MANAGER']);

function firstString(value: unknown): string | undefined {
  const v = Array.isArray(value) ? value[0] : value;
  return typeof v === 'string' && v.trim() ? v.trim() : undefined;
}

function isWellFormedBranchId(value: string): boolean {
  return UUID_RE.test(value) || LEGACY_BRANCH_RE.test(value);
}

function deny(res: Response, status: number, code: string, message: string): void {
  res.status(status).json({ success: false, code, error: message });
}

export interface TenantContextOptions {
  /**
   * Public (unauthenticated) routes only. Tenant and branch come from server config,
   * e.g. CMMS_PUBLIC_PRAYER_TENANT_ID / CMMS_PUBLIC_PRAYER_BRANCH_ID. When omitted,
   * unauthenticated requests are rejected.
   */
  anonymousScope?: () => { tenantId: string; branchId: string } | null;
}

export function createTenantContextMiddleware(options: TenantContextOptions = {}) {
  return function tenantContextMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
    const user = req.user;

    if (!user) {
      const scope = options.anonymousScope?.() ?? null;
      if (!scope) {
        deny(res, 401, 'UNAUTHENTICATED', 'Authentication required.');
        return;
      }
      req.tenantId = scope.tenantId;
      req.branchId = scope.branchId;
      next();
      return;
    }

    const tenantId = typeof user.tenantId === 'string' ? user.tenantId.trim() : '';
    if (!tenantId) {
      // A verified user without a tenant is a data-integrity problem; never guess one.
      console.error(`[Tenant] Session for user ${user.id} has no tenantId; request denied.`);
      deny(res, 403, 'TENANT_UNRESOLVED', 'Your account is not assigned to an organisation.');
      return;
    }
    req.tenantId = tenantId;

    const requested = firstString(req.headers['x-branch-id']) ?? firstString(req.query?.branchId);
    const assigned: string[] = Array.isArray(user.branchIds) ? user.branchIds.map(String) : [];
    const hasWildcard =
      assigned.includes('*') || BRANCH_WILDCARD_ROLES.has(String(user.role ?? '').toUpperCase());

    if (!requested) {
      req.branchId = user.branchId || (hasWildcard ? 'all' : undefined);
      if (!req.branchId) {
        deny(res, 403, 'BRANCH_UNRESOLVED', 'Your account is not assigned to a branch.');
        return;
      }
      next();
      return;
    }

    if (requested === 'all') {
      if (!hasWildcard) {
        deny(res, 403, 'BRANCH_FORBIDDEN', 'You are not permitted to view all branches.');
        return;
      }
      req.branchId = 'all';
      next();
      return;
    }

    if (!isWellFormedBranchId(requested)) {
      deny(res, 400, 'INVALID_BRANCH_ID', 'Malformed branch identifier.');
      return;
    }

    // Wildcard users may pick any branch *within their tenant*; row-level scoping by
    // tenant_id in every query is what enforces the tenant boundary, not this header.
    if (!hasWildcard && requested !== user.branchId && !assigned.includes(requested)) {
      deny(res, 403, 'BRANCH_FORBIDDEN', 'You are not assigned to the requested branch.');
      return;
    }

    req.branchId = requested;
    next();
  };
}

/** Drop-in for existing `router.use(tenantContextMiddleware)` call sites: authenticated-only. */
export const tenantContextMiddleware = createTenantContextMiddleware();
