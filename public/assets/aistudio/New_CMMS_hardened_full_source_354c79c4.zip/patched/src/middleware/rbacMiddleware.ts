import { Response, NextFunction } from 'express';
import { AuthenticatedRequest } from './authMiddleware';
import { UserRole } from '../types';
import {
  Permission,
  ROLE_PERMISSIONS,
  hasPermission as checkPermission,
  requirePermission as authRequirePermission,
  requireAnyPermission as authRequireAnyPermission,
  verifyResourceAccess,
  filterCollectionByAccess,
} from '../security/authorization';

export type { Permission };
export {
  ROLE_PERMISSIONS,
  verifyResourceAccess,
  filterCollectionByAccess,
};

/**
 * Normalizes legacy colon notation ('members:read' -> 'members.read')
 */
function normalizePermission(perm: string): Permission {
  const mapped = perm.replace(':', '.') as Permission;
  // Specific legacy mappings
  if (mapped === ('members.write' as any)) return 'members.update';
  if (mapped === ('attendance.write' as any)) return 'attendance.update';
  if (mapped === ('pastoral.write' as any)) return 'pastoral.update';
  if (mapped === ('finances.read' as any)) return 'finance.read';
  if (mapped === ('finances.write' as any)) return 'finance.create';
  if (mapped === ('finances.approve' as any)) return 'finance.approve';
  if (mapped === ('approvals.manage' as any)) return 'workflows.manage';
  if (mapped === ('reports.view' as any)) return 'reports.read';
  return mapped;
}

/**
 * Centralized Permission Check Middleware:
 * Verifies that the authenticated user possesses the required permission.
 * Returns 403 Forbidden with details if authorization fails.
 */
export function requirePermission(permission: Permission | string) {
  const normalized = normalizePermission(permission as string);
  return authRequirePermission(normalized);
}

/**
 * Checks if user has ANY of the specified permissions
 */
export function requireAnyPermission(...permissions: (Permission | string)[]) {
  const normalized = permissions.map((p) => normalizePermission(p as string));
  return authRequireAnyPermission(...normalized);
}

/**
 * Role-based access guard
 */
export function requireRoles(...allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'Authentication required to access this resource',
        code: 'UNAUTHENTICATED',
      });
    }

    if (req.user.role === 'SYSTEM_ADMIN' || allowedRoles.includes(req.user.role)) {
      return next();
    }

    return res.status(403).json({
      error: `Access denied. Requires one of roles: [${allowedRoles.join(', ')}]`,
      code: 'FORBIDDEN_ROLE',
    });
  };
}

/**
 * Functional permission check for programmatic checks inside route handlers
 */
export function hasPermission(role: any, permission: Permission | string): boolean {
  return checkPermission(role, normalizePermission(permission as string));
}

/**
 * Confidentiality guard for pastoral counseling records
 */
export function checkPastoralConfidentiality(
  level: string = 'MINISTERIAL',
  userRole: UserRole = 'REGULAR_MEMBER',
  counselorId?: string,
  currentUserId?: string
): boolean {
  if (userRole === 'SYSTEM_ADMIN') return true;

  const normalized = level.toUpperCase();
  if (normalized === 'SEALED') {
    return Boolean(counselorId && currentUserId && counselorId === currentUserId);
  }

  if (normalized === 'CONFIDENTIAL' || normalized === 'PASTORAL') {
    return userRole === 'PASTOR' || userRole === 'MANAGER';
  }

  // MINISTERIAL / GENERAL
  return userRole === 'PASTOR' || userRole === 'MANAGER' || userRole === 'MINISTRY_LEADER';
}
