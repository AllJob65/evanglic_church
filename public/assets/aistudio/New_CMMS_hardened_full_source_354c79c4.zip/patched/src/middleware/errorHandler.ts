import { Request, Response, NextFunction } from 'express';

export function globalErrorHandler(
  err: any,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction
) {
  // Safe server-side console logging (never transmitted over network)
  console.error(`[Error Handler] ${req.method} ${req.path}:`, {
    name: err?.name,
    message: err?.message,
    status: err?.status || err?.statusCode || 500,
    stack: err?.stack,
  });

  const statusCode = typeof err.status === 'number' ? err.status : typeof err.statusCode === 'number' ? err.statusCode : 500;

  // Safe client response: Never return internal database traces, stack traces, or exception objects
  let clientMessage = 'An unexpected error occurred. Please contact the administrator.';
  let errorCode = err.code || 'INTERNAL_ERROR';

  if (statusCode >= 400 && statusCode < 500) {
    // Client operational errors (e.g. Validation, Unauthorized, Forbidden, Not Found)
    clientMessage = err.message || 'Invalid request';
  } else {
    // 500+ Internal errors: mask exception details to prevent information disclosure
    clientMessage = 'An internal server error occurred. The technical event has been logged.';
    errorCode = 'INTERNAL_SERVER_ERROR';
  }

  res.status(statusCode).json({
    success: false,
    error: clientMessage,
    code: errorCode,
    timestamp: new Date().toISOString(),
    path: req.path,
  });
}
