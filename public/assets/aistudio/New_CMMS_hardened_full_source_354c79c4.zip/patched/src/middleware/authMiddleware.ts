import { Request, Response, NextFunction } from 'express';
import {
  AuthenticatedRequest,
  AuthenticatedUserPayload,
  authenticateToken,
} from '../security/authorization';

export type { AuthenticatedRequest, AuthenticatedUserPayload };

/**
 * Authentication Middleware:
 * Supabase Auth is the single authoritative source of truth.
 * Verifies the Bearer session token via supabase.auth.getUser(token).
 * Loads trusted profile from public.profiles table.
 * Strictly derives identity, tenant, branch, and role from trusted database record.
 */
export const authenticateJWT = authenticateToken;
