import { describe, it, expect, beforeEach } from 'vitest';
import { db } from '../../server/db';
import {
  securityAuditService,
  redactSensitiveMetadata,
  toSafeSessionId,
} from '../../server/services/securityAuditService';
import {
  isSessionTokenRevoked,
  revokeSessionToken,
  revokeAllUserSessions,
  getUserSessionRevokedAt,
} from '../security/authorization';
import auditRouter from '../../server/routes/audit';

describe('CMMS Production Security & Audit Hardening — Adversarial & Evidence Verification Suite', () => {
  beforeEach(() => {
    db.setSimulatePersistenceFailure(false);
  });

  it('1. Read-only startup & legacy record flagging: never rewrites existing legacy audit hashes and explicitly flags legacy records', () => {
    const state = db.getState();
    const originalLogs = [...state.auditLogs];

    try {
      // Simulate a pre-existing legacy record at the beginning of history (without prevHash / integrityHash)
      const legacyRecord = {
        id: 'legacy-seed-001',
        timestamp: '2026-01-01T00:00:00.000Z',
        userEmail: 'legacy@gracecathedral.org',
        userName: 'Legacy Admin',
        userRole: 'SYSTEM_ADMIN' as const,
        action: 'Legacy System Initialization',
        module: 'System',
        details: 'Pre-v2.0 record without cryptographic hash',
        ipAddress: '127.0.0.1',
      };

      // Reset logs to just the legacy record, then append 2 new v2.0 chained events
      state.auditLogs = [legacyRecord as any];
      db.writeAuditCheckpoint(state.auditLogs);

      // Re-run startup hydration: must NOT rewrite or backfill hashes onto legacyRecord
      securityAuditService.hydrateFromDurableStore();
      const afterHydrateLegacy = state.auditLogs.find((l) => l.id === 'legacy-seed-001')!;
      expect(afterHydrateLegacy.prevHash).toBeUndefined();
      expect(afterHydrateLegacy.integrityHash).toBeUndefined();

      // Append two new security events
      const ev1 = securityAuditService.recordEvent({
        eventType: 'AUTH_LOGIN_SUCCESS',
        action: 'Admin Login',
        module: 'Authentication',
        details: 'Authenticated admin@gracecathedral.org',
        actorId: 'usr-admin-1',
        actorEmail: 'admin@gracecathedral.org',
        actorRole: 'SYSTEM_ADMIN',
        outcome: 'SUCCESS',
        severity: 'LOW',
      });
      const ev2 = securityAuditService.recordEvent({
        eventType: 'SECURITY_CONFIG_CHANGED',
        action: 'Updated MFA Enforcement',
        module: 'Security Settings',
        details: 'Set MFA enforcement to enforced',
        actorId: 'usr-admin-1',
        actorEmail: 'admin@gracecathedral.org',
        actorRole: 'SYSTEM_ADMIN',
        outcome: 'SUCCESS',
        severity: 'MEDIUM',
      });

      expect(ev1.prevHash).toBe('GENESIS_CMMS_AUDIT_CHAIN_0000000000000000');
      expect(ev2.prevHash).toBe(ev1.integrityHash);

      // Verify read-only integrity: chain is intact, and legacy-seed-001 is explicitly flagged
      const verification = securityAuditService.verifyAuditTrailIntegrity();
      expect(verification.verified).toBe(true);
      expect(verification.totalRecords).toBe(3);
      expect(verification.chainedRecords).toBe(2);
      expect(verification.legacyUnchainedRecords).toBe(1);
      expect(verification.legacyRecordIds).toContain('legacy-seed-001');
      expect(verification.checkpointVerified).toBe(true);
    } finally {
      state.auditLogs = originalLogs;
      db.persist();
      db.writeAuditCheckpoint(state.auditLogs);
    }
  });

  it('2. Adversarial Test — Change a record: detects in-place field mutation via SHA-256 mismatch', () => {
    const entry = securityAuditService.recordEvent({
      eventType: 'ROLE_PERMISSION_CHANGED',
      action: 'Role Assignment Updated',
      module: 'User Access & RBAC',
      details: 'Assigned PASTOR role to pastor@gracecathedral.org',
      actorId: 'usr-admin-1',
      actorEmail: 'admin@gracecathedral.org',
      actorRole: 'SYSTEM_ADMIN',
      outcome: 'SUCCESS',
      severity: 'HIGH',
    });

    const originalDetails = entry.details;
    // Adversarially mutate the record's details in place
    entry.details = 'TAMPERED: Assigned REGULAR_MEMBER role';

    const tamperedResult = securityAuditService.verifyAuditTrailIntegrity();
    expect(tamperedResult.verified).toBe(false);
    expect(tamperedResult.brokenAtRecordId).toBe(entry.id);
    expect(tamperedResult.failureReason).toContain('Tamper detected');

    // Restore original details
    entry.details = originalDetails;
    expect(securityAuditService.verifyAuditTrailIntegrity().verified).toBe(true);
  });

  it('3. Adversarial Test — Remove a record (middle of chain & latest record against checkpoint): detects deletion', () => {
    const r1 = securityAuditService.recordEvent({
      eventType: 'AUTH_LOGIN_FAILURE',
      action: 'Failed Login 1',
      module: 'Authentication',
      details: 'Invalid password attempt 1',
      actorEmail: 'intruder@example.com',
      outcome: 'FAILURE',
      severity: 'MEDIUM',
    });
    const r2 = securityAuditService.recordEvent({
      eventType: 'AUTH_LOGIN_FAILURE',
      action: 'Failed Login 2',
      module: 'Authentication',
      details: 'Invalid password attempt 2',
      actorEmail: 'intruder@example.com',
      outcome: 'FAILURE',
      severity: 'MEDIUM',
    });

    const logs = db.getState().auditLogs;

    // Case A: Remove r1 (middle record that r2 links to)
    const idxR1 = logs.findIndex((l) => l.id === r1.id);
    const [removedMiddle] = logs.splice(idxR1, 1);

    const midRemovalCheck = securityAuditService.verifyAuditTrailIntegrity();
    expect(midRemovalCheck.verified).toBe(false);
    expect(midRemovalCheck.brokenAtRecordId).toBe(r2.id);
    expect(midRemovalCheck.failureReason).toContain('Broken hash link');

    // Restore r1
    logs.splice(idxR1, 0, removedMiddle);
    expect(securityAuditService.verifyAuditTrailIntegrity().verified).toBe(true);

    // Case B: Remove the newest record r2 (tail truncation attack) — caught by independent HMAC checkpoint!
    const idxR2 = logs.findIndex((l) => l.id === r2.id);
    const [removedLatest] = logs.splice(idxR2, 1);

    const tailTruncationCheck = securityAuditService.verifyAuditTrailIntegrity();
    expect(tailTruncationCheck.verified).toBe(false);
    expect(tailTruncationCheck.checkpointVerified).toBe(false);
    expect(tailTruncationCheck.failureReason).toContain('truncation/deletion detected');

    // Restore r2
    logs.splice(idxR2, 0, removedLatest);
    expect(securityAuditService.verifyAuditTrailIntegrity().verified).toBe(true);
  });

  it('4. Adversarial Test — Reorder records & break a hash link: detects out-of-order records and broken prevHash', () => {
    const a = securityAuditService.recordEvent({
      eventType: 'MFA_CHALLENGE_ISSUED',
      action: 'MFA Challenge Issued',
      module: 'MFA Security',
      details: 'Issued TOTP challenge',
      actorEmail: 'admin@gracecathedral.org',
      outcome: 'SUCCESS',
      severity: 'LOW',
    });
    const b = securityAuditService.recordEvent({
      eventType: 'MFA_VERIFICATION_SUCCESS',
      action: 'MFA Verified',
      module: 'MFA Security',
      details: 'Verified TOTP code',
      actorEmail: 'admin@gracecathedral.org',
      outcome: 'SUCCESS',
      severity: 'LOW',
    });

    const logs = db.getState().auditLogs;
    const idxB = logs.findIndex((l) => l.id === b.id);
    const idxA = logs.findIndex((l) => l.id === a.id);

    // Swap order of A and B
    const temp = logs[idxB];
    logs[idxB] = logs[idxA];
    logs[idxA] = temp;

    const reorderCheck = securityAuditService.verifyAuditTrailIntegrity();
    expect(reorderCheck.verified).toBe(false);
    expect(reorderCheck.failureReason).toContain('Broken hash link');

    // Restore order
    logs[idxA] = logs[idxB];
    logs[idxB] = temp;
    expect(securityAuditService.verifyAuditTrailIntegrity().verified).toBe(true);

    // Explicitly break a hash link on B
    const origPrev = b.prevHash;
    b.prevHash = '0000000000000000000000000000000000000000000000000000000000000000';
    const brokenLinkCheck = securityAuditService.verifyAuditTrailIntegrity();
    expect(brokenLinkCheck.verified).toBe(false);
    expect(brokenLinkCheck.brokenAtRecordId).toBe(b.id);
    expect(brokenLinkCheck.failureReason).toContain('Broken hash link');

    b.prevHash = origPrev;
    expect(securityAuditService.verifyAuditTrailIntegrity().verified).toBe(true);
  });

  it('5. Adversarial Test — Disable database access: propagates persistence errors and rolls back unpersisted memory mutation', () => {
    const countBefore = db.getState().auditLogs.length;
    db.setSimulatePersistenceFailure(true);

    expect(() =>
      securityAuditService.recordEvent({
        eventType: 'PRIVILEGED_ADMIN_ACTION',
        action: 'Should Fail When DB Disabled',
        module: 'System',
        details: 'Testing persistence failure propagation',
        actorEmail: 'admin@gracecathedral.org',
      })
    ).toThrow(/Simulated durable database write failure/);

    // Verify in-memory auditLogs was rolled back so it never diverges from durable storage
    expect(db.getState().auditLogs.length).toBe(countBefore);
    // Verify persistence error was recorded for Security Overview visibility
    expect(db.getPersistenceErrors().length).toBeGreaterThan(0);

    db.setSimulatePersistenceFailure(false);
  });

  it('6. Adversarial Test — Cross-tenant audit query: blocks cross-tenant query with 403 and records HIGH severity block event', () => {
    // Invoke the GET /logs handler on auditRouter with a cross-tenant query parameter
    const layer = (auditRouter as any).stack.find(
      (s: any) => s.route && s.route.path === '/logs' && s.route.methods.get
    );
    expect(layer).toBeDefined();
    const getLogsHandler = layer.route.stack[layer.route.stack.length - 1].handle;

    const reqMock: any = {
      user: {
        id: 'usr-admin-tenant-a',
        email: 'admin@tenant-a.org',
        name: 'Tenant A Admin',
        role: 'SYSTEM_ADMIN',
        tenantId: '773627bc-212b-4336-be98-dd44b141d84e',
        branchId: 'branch-1',
        permissions: ['audit.read'],
      },
      query: {
        tenantId: '99999999-9999-4999-9999-999999999999', // Cross-tenant target!
      },
      headers: {},
    };

    let statusCode = 200;
    let bodyPayload: any = null;
    const resMock: any = {
      status(code: number) {
        statusCode = code;
        return this;
      },
      json(payload: any) {
        bodyPayload = payload;
        return this;
      },
    };

    getLogsHandler(reqMock, resMock);
    expect(statusCode).toBe(403);
    expect(bodyPayload?.code).toBe('CROSS_TENANT_ACCESS_DENIED');
  });

  it('7. Session revocation & refresh-token reuse across restarts and simulated multiple instances', () => {
    const rawAccessToken = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.multi_instance_session_${Date.now()}.sig`;
    const rawRefreshToken = `rt_secret_rotation_multi_instance_${Date.now()}`;

    // Instance 1 registers session and rotates refresh token
    const session = securityAuditService.registerSession({
      rawAccessToken,
      rawRefreshToken,
      userId: 'usr-multi-instance-test',
      userEmail: 'pastor.multi@gracecathedral.org',
      userName: 'Pastor Multi',
      userRole: 'PASTOR',
    });
    expect(isSessionTokenRevoked(rawAccessToken)).toBe(false);

    // Revoke token on Instance 1 (writes to durable cmms_db.json)
    revokeSessionToken(rawAccessToken);
    expect(isSessionTokenRevoked(rawAccessToken)).toBe(true);

    // Simulate Instance 2 / Process Restart by reloading disk snapshot and re-hydrating
    db.reloadFromDisk();
    securityAuditService.hydrateFromDurableStore();

    // Instance 2 MUST reject the revoked access token even if its process-local Map was cleared
    expect(isSessionTokenRevoked(rawAccessToken)).toBe(true);
    expect(securityAuditService.isSessionIdRevoked(session.sessionId)).toBe(true);

    // Test user-wide revocation across restart / second instance
    const targetUserId = `usr-global-revoke-${Date.now()}`;
    expect(getUserSessionRevokedAt(targetUserId)).toBeUndefined();

    revokeAllUserSessions(targetUserId);
    db.reloadFromDisk();
    securityAuditService.hydrateFromDurableStore();

    expect(getUserSessionRevokedAt(targetUserId)).toBeDefined();

    // Test refresh-token reuse detection across restart / second instance
    const firstUse = securityAuditService.verifyAndRotateRefreshToken({
      oldRefreshToken: rawRefreshToken,
      newAccessToken: 'at_new_after_rotate',
      userId: 'usr-multi-instance-test',
      userEmail: 'pastor.multi@gracecathedral.org',
    });
    expect(firstUse.reuseDetected).toBe(false);

    db.reloadFromDisk();
    securityAuditService.hydrateFromDurableStore();

    const replayUse = securityAuditService.verifyAndRotateRefreshToken({
      oldRefreshToken: rawRefreshToken,
      userId: 'usr-multi-instance-test',
      userEmail: 'pastor.multi@gracecathedral.org',
    });
    expect(replayUse.reuseDetected).toBe(true);
    expect(session.sessionId).toMatch(/^sess_[a-f0-9]{12}$/);
  });

  it('8. Redacts sensitive credentials, JWTs, cookies, and MFA secrets from all metadata', () => {
    const dirty = {
      password: 'MySecretPassword!123',
      refresh_token: 'rt_99999999',
      totpCode: '123456',
      note: 'Header Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U sent',
    };
    const clean = redactSensitiveMetadata(dirty);
    expect(clean.password).toBe('[REDACTED]');
    expect(clean.refresh_token).toBe('[REDACTED]');
    expect(clean.totpCode).toBe('[REDACTED]');
    expect(clean.note).not.toContain('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9');
    expect(toSafeSessionId('raw-jwt-token')).toMatch(/^sess_[a-f0-9]{12}$/);
  });
});
