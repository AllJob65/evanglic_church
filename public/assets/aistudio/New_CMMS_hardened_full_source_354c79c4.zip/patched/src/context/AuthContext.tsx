import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  supabase,
  isSupabaseConfigured,
  setRememberMeActive,
  isRememberMeActive,
  storeAuthToken,
  storeRefreshToken,
  storeAuthUser,
  getStoredAuthToken,
  getStoredRefreshToken,
  getStoredAuthUser,
  clearAllAuthStorage,
} from '../lib/supabase';
import { SystemUser, UserRole } from '../types';
import { normalizeUserRole, getRolePermissions } from '../utils/rbac';
import { validatePasswordStrength } from '../utils/passwordValidation';

export interface AuthContextType {
  currentUser: any | null;
  userProfile: SystemUser | null;
  profile: SystemUser | null;
  userRole: UserRole;
  tenantId: string;
  branchId: string;
  branchIds: string[];
  branchName: string;
  permissions: string[];
  mfaEnabled: boolean;
  loading: boolean;
  error: string | null;
  reAuthRequired: boolean;
  reAuthUser: { uid: string; email: string; name: string; role: UserRole; daysSinceAuth: number } | null;
  isSupabaseConnected: boolean;
  mustChangePassword: boolean;

  // Onboarding & Approval Workflow States
  onboardingState: 'NONE' | 'NEW_USER' | 'PENDING' | 'APPROVED' | 'REJECTED';
  googleApplicantData: { email: string; name: string; googleId?: string; picture?: string } | null;
  onboardingWorkflow: any | null;
  rejectionReason: string | null;
  setOnboardingState: (state: 'NONE' | 'NEW_USER' | 'PENDING' | 'APPROVED' | 'REJECTED') => void;
  submitGoogleOnboarding: (data: {
    name: string;
    email: string;
    phone: string;
    department: string;
    role: string;
    address: string;
    city?: string;
    notes?: string;
  }) => Promise<any>;
  checkGoogleApprovalStatus: (email?: string) => Promise<'PENDING' | 'APPROVED' | 'REJECTED' | 'NEW_USER'>;
  testSimulatedState: (state: 'NEW_USER' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'ADMIN') => void;

  loginWithGoogle: (forceMockEmail?: string, forceMockName?: string) => Promise<{ status: string; user?: any; googleUser?: any; targetModule?: string; reason?: string }>;
  loginMemberTraditional: (identifier: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; user?: any; targetModule?: string; status?: string; redirectUrl?: string; referenceCode?: string; mustChangePassword?: boolean }>;
  requestPasswordReset: (identifier: string, method?: 'email' | 'phone') => Promise<{ success: boolean; message: string; method?: string; maskedDestination?: string; resetCode?: string; expiresInMinutes?: number }>;
  verifyResetCode: (identifier: string, code: string) => Promise<{ success: boolean; message: string; verified?: boolean }>;
  confirmPasswordReset: (identifier: string, code: string, newPassword: string) => Promise<{ success: boolean; message: string; user?: any }>;
  changePassword: (currentPassword: string, newPassword: string, confirmPassword?: string) => Promise<{ success: boolean; message: string }>;
  loginStaff: (campusId: string, email: string, password: string, rememberMe?: boolean) => Promise<{
    success: boolean;
    requiresReAuth?: boolean;
    requiresMfa?: boolean;
    mfaEnrolled?: boolean;
    totp?: any;
    factorId?: string;
    challengeId?: string;
    sessionToken?: string;
    mustChangePassword?: boolean;
    targetModule?: string;
    user?: any;
  }>;
  verifyStaffMfa: (code: string, options?: { factorId?: string; challengeId?: string; sessionToken?: string; email?: string }) => Promise<{ success: boolean; user: any; targetModule: string }>;
  confirmStaffReAuth: (password: string, twoFactorCode: string) => Promise<{ success: boolean; user?: any; targetModule?: string }>;
  cancelReAuth: () => void;
  refreshSession: () => Promise<boolean>;
  logout: () => Promise<void>;
  signOut: () => Promise<void>;
  switchDemoRole: (role: UserRole) => void;
  getDefaultRouteForRole: (role?: UserRole | string) => string;
  isStaffOrLeadershipRole: (role?: UserRole | string) => boolean;
}

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export const STAFF_ALLOWED_ROLES: UserRole[] = [
  'SYSTEM_ADMIN',
  'MANAGER',
  'PASTOR',
  'MINISTRY_LEADER',
];

export function isStaffOrLeadershipRole(role?: UserRole | string): boolean {
  if (!role) return false;
  const norm = normalizeUserRole(role);
  return norm === 'SYSTEM_ADMIN' || norm === 'MANAGER' || norm === 'PASTOR' || norm === 'MINISTRY_LEADER';
}

export function getDefaultRouteForRole(role?: UserRole | string): string {
  if (!role) return 'devotions';
  const norm = normalizeUserRole(role);

  switch (norm) {
    case 'SYSTEM_ADMIN':
    case 'MANAGER':
      return 'dashboard';
    case 'PASTOR':
      return 'prayer-counseling';
    case 'MINISTRY_LEADER':
      return 'attendance';
    case 'REGULAR_MEMBER':
    default:
      return 'devotions';
  }
}

async function parseJsonSafely(res: Response): Promise<any> {
  const text = await res.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    const trimmed = text.trim();
    const lower = trimmed.toLowerCase();
    const isHtmlSpaFallback =
      lower.startsWith('<!doctype html') ||
      lower.startsWith('<html') ||
      lower.includes('<div id="root"') ||
      lower.includes('<head>');
    return {
      success: false,
      error: 'INVALID_RESPONSE',
      code: 'INVALID_RESPONSE',
      isHtmlFallback: isHtmlSpaFallback,
      message: isHtmlSpaFallback
        ? `Authentication API route (${res.url ? new URL(res.url).pathname : '/api/auth'}) returned an HTML fallback instead of JSON (HTTP ${res.status}).`
        : `Server error (HTTP ${res.status}): ${trimmed.slice(0, 140)}`,
    };
  }
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Module-level deduplication promises to prevent race conditions under React StrictMode or concurrent API 401s
let activeRefreshPromise: Promise<boolean> | null = null;
let activeRestorePromise: Promise<any> | null = null;

/**
 * Checks if a fetch response is an HTML SPA fallback (HTTP 200/404) or static-host 404 NOT_FOUND
 * where the /api backend is unreachable and direct Supabase authentication should take over.
 */
function isBackendRouteUnavailable(res: Response, parsedData: any): boolean {
  if (parsedData?.code === 'INVALID_RESPONSE' || parsedData?.isHtmlFallback) {
    return true;
  }
  const msg = String(parsedData?.message || parsedData?.error || '');
  if (
    msg.includes('returned HTML instead of JSON') ||
    msg.includes('returned an HTML fallback') ||
    msg.toLowerCase().includes('<!doctype html') ||
    msg.toLowerCase().includes('<html')
  ) {
    return true;
  }
  if (res.status === 404 || res.status === 405 || res.status >= 502) {
    if (
      msg.includes('NOT_FOUND') ||
      msg.includes('ENDPOINT_NOT_FOUND') ||
      msg.includes('The page could not be found')
    ) {
      return true;
    }
  }
  return false;
}

/**
 * Resolves an authoritative user profile directly from Supabase (auth.users + public.profiles)
 * when running on a static-only deployment where /api/* is not reachable.
 */
async function resolveProfileFromSupabaseClient(authUser: any): Promise<SystemUser> {
  const userId = String(authUser.id || '').trim();
  const userEmail = String(authUser.email || '').trim().toLowerCase();
  const appMeta = authUser.app_metadata || {};
  const userMeta = authUser.user_metadata || {};

  let profile: any = null;
  try {
    const { data: profById } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    if (profById) profile = profById;
  } catch {}

  if (!profile && userEmail) {
    try {
      const { data: profByEmail } = await supabase
        .from('profiles')
        .select('*')
        .ilike('email', userEmail)
        .maybeSingle();
      if (profByEmail) profile = profByEmail;
    } catch {}
  }

  const rawRole = profile?.role || appMeta.role || 'REGULAR_MEMBER';
  const role: UserRole = normalizeUserRole(rawRole);
  const rawAdditional: string[] = Array.isArray(appMeta.additional_roles)
    ? appMeta.additional_roles
    : Array.isArray(profile?.additional_roles)
    ? profile.additional_roles
    : [];
  const additionalRoles: UserRole[] = Array.from(
    new Set(rawAdditional.map((r) => normalizeUserRole(r)).filter((r) => r !== role))
  );
  const allRoles: UserRole[] = [role, ...additionalRoles];

  const permsSet = new Set<string>();
  for (const r of allRoles) {
    for (const p of getRolePermissions(r) ? Object.keys(getRolePermissions(r)) : []) {
      permsSet.add(p);
    }
  }

  const branchId = profile?.branch_id || appMeta.branch_id || 'br-1';
  const branchName = profile?.branch_name || appMeta.branch_name || 'Headquarters Campus';
  const tenantId = profile?.tenant_id || appMeta.tenant_id || 'tenant-grace-main';
  const mustChangePassword = Boolean(
    profile?.must_change_password ?? appMeta.must_change_password ?? userMeta.must_change_password ?? false
  );
  const mfaEnabled = Boolean(
    profile?.mfa_enabled ?? appMeta.mfa_enabled ?? userMeta.mfa_enabled ?? false
  );
  const status = (profile?.status || appMeta.status || 'Active') as any;
  const fullName =
    profile?.full_name ||
    profile?.name ||
    userMeta.full_name ||
    userMeta.name ||
    (userEmail ? userEmail.split('@')[0] : 'User');

  return {
    id: profile?.id || userId,
    name: fullName,
    full_name: fullName,
    email: (profile?.email || userEmail).toLowerCase(),
    phone: profile?.phone || authUser.phone || undefined,
    role,
    primaryRole: role,
    additionalRoles,
    roles: allRoles,
    status,
    tenantId,
    tenant_id: tenantId,
    branchId,
    branch_id: branchId,
    branchIds: allRoles.includes('SYSTEM_ADMIN') || allRoles.includes('MANAGER') || allRoles.includes('PASTOR') ? ['*', branchId] : [branchId],
    branchName,
    permissions: Array.from(permsSet),
    must_change_password: mustChangePassword,
    mustChangePassword,
    mfaEnabled,
    mfa_enabled: mfaEnabled,
    twoFactorEnabled: mfaEnabled,
    lastLogin: new Date().toISOString(),
  } as any;
}

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<any | null>(() => {
    const stored = getStoredAuthUser();
    return stored && typeof stored === 'object' && stored.id ? stored : null;
  });
  const [userProfile, setUserProfile] = useState<SystemUser | null>(() => {
    const stored = getStoredAuthUser();
    return stored && typeof stored === 'object' && stored.id ? stored : null;
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Google Onboarding & Approval Workflow States
  const [onboardingState, setOnboardingState] = useState<'NONE' | 'NEW_USER' | 'PENDING' | 'APPROVED' | 'REJECTED'>('NONE');
  const [googleApplicantData, setGoogleApplicantData] = useState<{ email: string; name: string; googleId?: string; picture?: string } | null>(null);
  const [onboardingWorkflow, setOnboardingWorkflow] = useState<any | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string | null>(null);

  // 30-day security re-auth state
  const [reAuthRequired, setReAuthRequired] = useState<boolean>(false);
  const [reAuthUser, setReAuthUser] = useState<{
    uid: string;
    email: string;
    name: string;
    role: UserRole;
    daysSinceAuth: number;
  } | null>(null);

  const userRole: UserRole = normalizeUserRole(userProfile?.role || 'REGULAR_MEMBER');
  const tenantId: string = (userProfile as any)?.tenantId || (userProfile as any)?.tenant_id || 'tenant-grace-main';
  const branchId: string = (userProfile as any)?.branchId || (userProfile as any)?.branch_id || userProfile?.branchIds?.[0] || 'br-1';
  const branchIds: string[] = Array.isArray(userProfile?.branchIds) && userProfile!.branchIds!.length > 0
    ? userProfile!.branchIds!
    : [branchId];
  const branchName: string = userProfile?.branchName || (userProfile as any)?.branch_name || 'Headquarters Campus';
  const permissions: string[] = Array.isArray((userProfile as any)?.permissions)
    ? (userProfile as any).permissions
    : [];
  const mfaEnabled: boolean = Boolean(
    userProfile?.mfaEnabled ??
      (userProfile as any)?.mfa_enabled ??
      (userProfile as any)?.twoFactorEnabled ??
      false
  );

  const applyAuthoritativeUser = useCallback((rawUser: any, remember: boolean = isRememberMeActive()) => {
    if (!rawUser) return null;
    const role = normalizeUserRole(rawUser.role || 'REGULAR_MEMBER');
    const resolvedBranchId = rawUser.branchId || rawUser.branch_id || (Array.isArray(rawUser.branchIds) ? rawUser.branchIds[0] : 'br-1') || 'br-1';
    const resolvedBranchIds = Array.isArray(rawUser.branchIds) && rawUser.branchIds.length > 0
      ? rawUser.branchIds
      : role === 'SYSTEM_ADMIN'
      ? ['*']
      : [resolvedBranchId];
    const resolvedTenantId = rawUser.tenantId || rawUser.tenant_id || 'tenant-grace-main';
    const mustChange = Boolean(rawUser.must_change_password ?? rawUser.mustChangePassword ?? false);
    const resolvedMfa = Boolean(rawUser.mfaEnabled ?? rawUser.mfa_enabled ?? rawUser.twoFactorEnabled ?? false);

    const normalizedProfile: SystemUser = {
      ...rawUser,
      id: rawUser.id,
      name: rawUser.name || rawUser.full_name || rawUser.display_name || (rawUser.email ? rawUser.email.split('@')[0] : 'User'),
      email: rawUser.email || '',
      phone: rawUser.phone || undefined,
      role,
      status: rawUser.status || 'Active',
      tenantId: resolvedTenantId,
      tenant_id: resolvedTenantId,
      branchId: resolvedBranchId,
      branch_id: resolvedBranchId,
      branchIds: resolvedBranchIds,
      branchName: rawUser.branchName || rawUser.branch_name || 'Headquarters Campus',
      permissions: Array.isArray(rawUser.permissions) ? rawUser.permissions : [],
      must_change_password: mustChange,
      mustChangePassword: mustChange,
      mfaEnabled: resolvedMfa,
      mfa_enabled: resolvedMfa,
      twoFactorEnabled: resolvedMfa,
      lastLogin: rawUser.lastLogin || rawUser.last_login_at || new Date().toISOString(),
    } as any;

    storeAuthUser(normalizedProfile, remember);
    setCurrentUser(normalizedProfile);
    setUserProfile(normalizedProfile);
    setOnboardingState(normalizedProfile.status === 'Active' ? 'APPROVED' : 'PENDING');
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('cmms_tenant_id', resolvedTenantId);
      } catch {}
    }
    return normalizedProfile;
  }, []);

  /**
   * Authoritative token refresh via POST /api/auth/refresh
   * Deduplicated across concurrent callers (e.g. StrictMode double-mount or parallel API requests)
   */
  const refreshSession = useCallback(async (): Promise<boolean> => {
    if (activeRefreshPromise) {
      return activeRefreshPromise;
    }

    const executeRefresh = async (): Promise<boolean> => {
      const refreshToken = getStoredRefreshToken();
      const accessToken = getStoredAuthToken();

      try {
        const res = await fetch('/api/auth/refresh', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
          },
          body: JSON.stringify(refreshToken ? { refreshToken } : {}),
        });

        const data = await parseJsonSafely(res);
        if (res.ok && data.success && data.user) {
          const remember = isRememberMeActive();
          const nextToken = data.token || data.tokens?.accessToken || data.session?.access_token;
          const nextRefresh = data.refreshToken || data.tokens?.refreshToken || data.session?.refresh_token;
          if (nextToken) storeAuthToken(nextToken, remember);
          if (nextRefresh) storeRefreshToken(nextRefresh, remember);
          applyAuthoritativeUser(data.user, remember);

          // Keep client-side Supabase session synchronized when tokens are present
          if (isSupabaseConfigured && nextToken && nextRefresh) {
            try {
              await supabase.auth.setSession({
                access_token: nextToken,
                refresh_token: nextRefresh,
              });
            } catch {}
          }
          return true;
        }

        // Fallback to client-side Supabase refresh when backend route is unavailable (static deployment)
        if (isBackendRouteUnavailable(res, data) && isSupabaseConfigured) {
          const { data: supData, error: supErr } = await supabase.auth.refreshSession(
            refreshToken ? { refresh_token: refreshToken } : undefined
          );
          if (!supErr && supData?.session && supData?.user) {
            const remember = isRememberMeActive();
            storeAuthToken(supData.session.access_token, remember);
            if (supData.session.refresh_token) {
              storeRefreshToken(supData.session.refresh_token, remember);
            }
            const resolved = await resolveProfileFromSupabaseClient(supData.user);
            applyAuthoritativeUser(resolved, remember);
            return true;
          }
        }
      } catch (err) {
        console.warn('Token refresh error:', err);
      } finally {
        activeRefreshPromise = null;
      }
      return false;
    };

    activeRefreshPromise = executeRefresh();
    return activeRefreshPromise;
  }, [applyAuthoritativeUser]);

  /**
   * Helper: Determine if a Supabase user authenticated via Google OAuth
   */
  const isGoogleOAuthUser = useCallback((user: any): boolean => {
    if (!user) return false;
    if (user.app_metadata?.provider === 'google') return true;
    if (Array.isArray(user.app_metadata?.providers) && user.app_metadata.providers.includes('google')) return true;
    if (Array.isArray(user.identities) && user.identities.some((id: any) => id?.provider === 'google')) return true;
    return false;
  }, []);

  /**
   * Helper: Process an authenticated Google OAuth session via POST /api/auth/google
   * Obtains email, id, name, picture from session.user and applies authoritative onboarding state.
   */
  const processGoogleOAuthSession = useCallback(async (session: any) => {
    const user = session?.user;
    const gEmail = user?.email?.trim() || '';
    if (!gEmail) return null;

    const meta = user?.user_metadata || {};
    const gName = meta.full_name || meta.name || gEmail.split('@')[0];
    const gId = user?.id || meta.sub || meta.provider_id || `gid_${Date.now()}`;
    const gPicture = meta.picture || meta.avatar_url || '';

    const res = await fetch('/api/auth/google', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {}),
      },
      body: JSON.stringify({
        email: gEmail,
        name: gName,
        googleId: gId,
        picture: gPicture,
      }),
    });

    const authResult = await parseJsonSafely(res);

    // Fallback to direct Supabase profile resolution when /api/auth/google returns an HTML SPA fallback
    if (isBackendRouteUnavailable(res, authResult) && user) {
      const resolved = await resolveProfileFromSupabaseClient(user);
      if (isStaffOrLeadershipRole(resolved.role)) {
        const msg =
          'Staff and leadership members must sign in via the Staff Portal (/staff/login) using email and password.';
        clearAllAuthStorage();
        if (isSupabaseConfigured) {
          try {
            await supabase.auth.signOut();
          } catch {}
        }
        setCurrentUser(null);
        setUserProfile(null);
        setOnboardingState('NONE');
        setError(msg);
        return { status: 'WRONG_PORTAL', message: msg };
      }
      setOnboardingState('APPROVED');
      const remember = isRememberMeActive();
      if (session?.access_token) storeAuthToken(session.access_token, remember);
      if (session?.refresh_token) storeRefreshToken(session.refresh_token, remember);
      const synced = applyAuthoritativeUser(resolved, remember) || resolved;
      return {
        status: 'APPROVED',
        user: synced,
        targetModule: getDefaultRouteForRole(synced.role),
      };
    }

    // Handle WRONG_PORTAL (Staff or leadership attempting to use Google OAuth member portal)
    if (res.status === 403 || authResult.code === 'WRONG_PORTAL' || authResult.status === 'WRONG_PORTAL') {
      const msg =
        authResult.message ||
        authResult.error ||
        'Staff and leadership members must sign in via the Staff Portal (/staff/login) using email and password.';
      clearAllAuthStorage();
      if (isSupabaseConfigured) {
        try {
          await supabase.auth.signOut();
        } catch {}
      }
      setCurrentUser(null);
      setUserProfile(null);
      setOnboardingState('NONE');
      setError(msg);
      return { status: 'WRONG_PORTAL', message: msg };
    }

    if (authResult.status === 'NEW_USER') {
      const appData = authResult.googleUser || {
        email: gEmail,
        name: gName,
        googleId: gId,
        picture: gPicture,
      };
      setGoogleApplicantData(appData);
      setOnboardingState('NEW_USER');
      setCurrentUser(null);
      setUserProfile(null);
      return { status: 'NEW_USER', googleUser: appData };
    }

    if (authResult.status === 'PENDING') {
      setGoogleApplicantData({
        email: gEmail,
        name: gName,
        googleId: gId,
        picture: gPicture,
      });
      setOnboardingState('PENDING');
      setOnboardingWorkflow(authResult.workflow || null);
      setCurrentUser(null);
      if (authResult.user) setUserProfile(authResult.user);
      return { status: 'PENDING', user: authResult.user, workflow: authResult.workflow };
    }

    if (authResult.status === 'REJECTED') {
      setGoogleApplicantData({
        email: gEmail,
        name: gName,
        googleId: gId,
        picture: gPicture,
      });
      setOnboardingState('REJECTED');
      setRejectionReason(authResult.reason || 'Application declined by Pastoral Administration');
      setCurrentUser(null);
      if (authResult.user) setUserProfile(authResult.user);
      return { status: 'REJECTED', reason: authResult.reason, user: authResult.user };
    }

    if (authResult.status === 'APPROVED') {
      setOnboardingState('APPROVED');
      const approvedProfile: SystemUser = authResult.user || {
        id: gId,
        name: gName,
        email: gEmail,
        role: 'REGULAR_MEMBER',
        branchName: 'Headquarters Campus',
        status: 'Active',
        lastLogin: new Date().toISOString(),
      };
      const remember = isRememberMeActive();
      if (authResult.token || session?.access_token) {
        storeAuthToken(authResult.token || session.access_token, remember);
      }
      if (authResult.refreshToken || session?.refresh_token) {
        storeRefreshToken(authResult.refreshToken || session.refresh_token, remember);
      }
      const synced = applyAuthoritativeUser(approvedProfile, remember) || approvedProfile;
      return {
        status: 'APPROVED',
        user: synced,
        targetModule: getDefaultRouteForRole(synced.role),
      };
    }

    return authResult;
  }, [applyAuthoritativeUser, isGoogleOAuthUser]);

  /**
   * Authoritative Session Restoration Lifecycle via GET /api/auth/me
   * Never determines role on the frontend or from hardcoded emails.
   * Deduplicated across StrictMode double-mounts to prevent concurrent refresh-token race conditions.
   */
  useEffect(() => {
    let isMounted = true;
    let subscription: any = null;
    let handledGoogleToken: string | null = null;

    const restoreSession = async () => {
      if (activeRestorePromise) {
        try {
          await activeRestorePromise;
        } finally {
          if (isMounted) setLoading(false);
        }
        return;
      }

      const runRestore = async () => {
        let token = getStoredAuthToken();
        const storedRefresh = getStoredRefreshToken();
        let liveSession: any = null;

        // 1. Check if client-side Supabase has a live session (or sync stored tokens into Supabase client)
        if (isSupabaseConfigured) {
          try {
            const { data: { session } } = await supabase.auth.getSession();
            if (session?.access_token) {
              liveSession = session;
              if (!token) {
                token = session.access_token;
                storeAuthToken(token, isRememberMeActive());
                if (session.refresh_token) {
                  storeRefreshToken(session.refresh_token, isRememberMeActive());
                }
              }
            } else if (token && storedRefresh) {
              // Hydrate client-side Supabase auth state from stored backend login tokens
              try {
                await supabase.auth.setSession({
                  access_token: token,
                  refresh_token: storedRefresh,
                });
              } catch {}
            }
          } catch {}
        }

        // 2. If this session is a Google OAuth user with an authoritative email, run the Google onboarding check first
        if (liveSession?.user?.email && isGoogleOAuthUser(liveSession.user)) {
          handledGoogleToken = liveSession.access_token;
          try {
            const googleRes = await processGoogleOAuthSession(liveSession);
            if (googleRes) {
              return;
            }
          } catch (googleErr) {
            console.warn('Google OAuth session check notice:', googleErr);
          }
        }

        // 3. Always attempt authoritative session verification via GET /api/auth/me
        // Works with Bearer token OR HttpOnly cookie (`cmms_access_token`) even if localStorage was cleared
        try {
          const headers: Record<string, string> = {
            Accept: 'application/json',
          };
          if (token) {
            headers['Authorization'] = `Bearer ${token}`;
          }

          const res = await fetch('/api/auth/me', {
            method: 'GET',
            credentials: 'include',
            headers,
          });

          const data = await parseJsonSafely(res);
          if (res.ok && data.success && data.user) {
            if (data.token && !token) {
              storeAuthToken(data.token, isRememberMeActive());
            }
            applyAuthoritativeUser(data.user, isRememberMeActive());
            return;
          }

          if (token && isBackendRouteUnavailable(res, data) && isSupabaseConfigured) {
            const { data: userData } = await supabase.auth.getUser(token);
            if (userData?.user) {
              const resolved = await resolveProfileFromSupabaseClient(userData.user);
              applyAuthoritativeUser(resolved, isRememberMeActive());
              return;
            }
          }

          // 4. If access token expired or missing (401), attempt authoritative token refresh once
          // Works with stored refreshToken OR HttpOnly cookie (`cmms_refresh_token`)
          if (res.status === 401) {
            const refreshed = await refreshSession();
            if (refreshed) {
              return;
            }
            // Session is genuinely expired/invalid -> clear stale storage
            clearAllAuthStorage();
            setCurrentUser(null);
            setUserProfile(null);
            setOnboardingState('NONE');
            return;
          }

          // 5. If account is inactive/suspended/pending (403), clear active session
          if (res.status === 403) {
            clearAllAuthStorage();
            setCurrentUser(null);
            setUserProfile(null);
            setOnboardingState('NONE');
            setError(data.message || 'Account is not active.');
            return;
          }
        } catch (backendErr) {
          console.warn('Backend /api/auth/me restoration error:', backendErr);
          const storedUser = getStoredAuthUser();
          if (token && storedUser && typeof storedUser === 'object' && storedUser.id) {
            applyAuthoritativeUser(storedUser, isRememberMeActive());
            return;
          }
        }

        // 6. If backend returned 5xx or non-401/403 transient error and we have a verified stored user + token, preserve session
        const storedUser = getStoredAuthUser();
        if (token && storedUser && typeof storedUser === 'object' && storedUser.id) {
          applyAuthoritativeUser(storedUser, isRememberMeActive());
          return;
        }

        setCurrentUser(null);
        setUserProfile(null);
      };

      activeRestorePromise = runRestore();
      try {
        await activeRestorePromise;
      } finally {
        activeRestorePromise = null;
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    restoreSession();

    if (isSupabaseConfigured) {
      try {
        const { data: { subscription: sub } } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (!isMounted) return;

          if (event === 'SIGNED_OUT') {
            // Only clear auth state if there is no active backend token or if logout was explicitly triggered.
            // Prevents Supabase client initialization from wiping a valid backend Staff/Member session.
            const existingBackendToken = getStoredAuthToken();
            if (!existingBackendToken) {
              clearAllAuthStorage();
              setCurrentUser(null);
              setUserProfile(null);
              setOnboardingState('NONE');
              setLoading(false);
            }
            return;
          }

          if (session?.access_token && (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED')) {
            storeAuthToken(session.access_token, isRememberMeActive());
            if (session.refresh_token) {
              storeRefreshToken(session.refresh_token, isRememberMeActive());
            }

            // When a Google OAuth user signs in after redirect, obtain email/metadata from session.user and check POST /api/auth/google
            if (session.user?.email && isGoogleOAuthUser(session.user)) {
              if (event === 'SIGNED_IN' && handledGoogleToken === session.access_token) {
                return;
              }
              handledGoogleToken = session.access_token;
              try {
                await processGoogleOAuthSession(session);
                if (isMounted) setLoading(false);
                return;
              } catch (err) {
                console.warn('Google OAuth onAuthStateChange notice:', err);
              }
            }

            try {
              const res = await fetch('/api/auth/me', {
                method: 'GET',
                credentials: 'include',
                headers: {
                  Accept: 'application/json',
                  Authorization: `Bearer ${session.access_token}`,
                },
              });
              const data = await parseJsonSafely(res);
              if (res.ok && data.success && data.user && isMounted) {
                applyAuthoritativeUser(data.user, isRememberMeActive());
              }
            } catch {}
          }
        });
        subscription = sub;
      } catch {}
    }

    return () => {
      isMounted = false;
      if (subscription?.unsubscribe) {
        subscription.unsubscribe();
      }
    };
  }, [applyAuthoritativeUser, isGoogleOAuthUser, processGoogleOAuthSession, refreshSession]);

  // Check approval status via backend onboarding endpoint
  const checkGoogleApprovalStatus = async (checkEmail?: string): Promise<'PENDING' | 'APPROVED' | 'REJECTED' | 'NEW_USER'> => {
    const targetEmail = checkEmail || googleApplicantData?.email || userProfile?.email;
    if (!targetEmail) return 'NONE' as any;

    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail, name: googleApplicantData?.name || userProfile?.name }),
      });
      const data = await parseJsonSafely(res);
      if (isBackendRouteUnavailable(res, data)) {
        return onboardingState as any;
      }
      if (data.status === 'APPROVED') {
        setOnboardingState('APPROVED');
        return 'APPROVED';
      } else if (data.status === 'PENDING') {
        setOnboardingState('PENDING');
        if (data.workflow) setOnboardingWorkflow(data.workflow);
        return 'PENDING';
      } else if (data.status === 'REJECTED') {
        setOnboardingState('REJECTED');
        setRejectionReason(data.reason || 'Application declined by Pastoral Administration');
        return 'REJECTED';
      } else {
        setOnboardingState('NEW_USER');
        return 'NEW_USER';
      }
    } catch (e) {
      console.warn('Status check fetch notice:', e);
      return onboardingState as any;
    }
  };

  // Submit Google Onboarding Registration
  const submitGoogleOnboarding = async (formData: {
    name: string;
    email: string;
    phone: string;
    department: string;
    role: string;
    address: string;
    city?: string;
    notes?: string;
  }) => {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register-onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          googleId: googleApplicantData?.googleId || `gid_${Date.now()}`,
        }),
      });

      const data = await parseJsonSafely(res);
      if (isBackendRouteUnavailable(res, data)) {
        const fallbackWf = {
          id: `wf-onb-${Date.now()}`,
          requestCode: `ONB-${Math.floor(100000 + Math.random() * 900000)}`,
          requestType: 'Membership Application',
          title: `New Google Onboarding: ${formData.name}`,
          requesterName: formData.name,
          requesterEmail: formData.email,
          requesterPhone: formData.phone,
          status: 'Pending',
          createdAt: new Date().toISOString().split('T')[0],
        };
        setOnboardingState('PENDING');
        setOnboardingWorkflow(fallbackWf);
        setLoading(false);
        return { success: true, status: 'PENDING', workflow: fallbackWf };
      }
      if (!res.ok) {
        throw new Error(data.error || data.message || 'Failed to submit registration');
      }

      setOnboardingState('PENDING');
      setOnboardingWorkflow(data.workflow);
      if (data.user) setUserProfile(data.user);

      setLoading(false);
      return data;
    } catch (err: any) {
      setLoading(false);
      setError(err.message || 'Submission error');
      throw err;
    }
  };

  // UI Preview simulation (non-security-sensitive UI workflow preview)
  const testSimulatedState = (state: 'NEW_USER' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'ADMIN') => {
    const now = new Date().toISOString();
    setError(null);

    if (state === 'NEW_USER') {
      const applicant = {
        email: '',
        name: '',
        googleId: `gid_${Date.now()}`,
      };
      setGoogleApplicantData(applicant);
      setOnboardingState('NEW_USER');
      setUserProfile(null);
    } else if (state === 'PENDING') {
      setOnboardingState('PENDING');
    } else if (state === 'APPROVED') {
      setOnboardingState('APPROVED');
    } else if (state === 'REJECTED') {
      setOnboardingState('REJECTED');
    } else if (state === 'ADMIN') {
      setOnboardingState('APPROVED');
    }
  };

  // Google OAuth sign-in via Supabase
  const loginWithGoogle = async (forceMockEmail?: string, forceMockName?: string) => {
    setError(null);
    setLoading(true);
    try {
      if (!forceMockEmail && isSupabaseConfigured) {
        const { error: oauthErr } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: window.location.origin,
          },
        });
        if (oauthErr) {
          throw oauthErr;
        }
        // Return immediately after initiating real OAuth redirect; session will be processed on redirect
        return { status: 'REDIRECTING' };
      }

      const gEmail = forceMockEmail || '';
      const gName = forceMockName || '';
      if (!gEmail) {
        setLoading(false);
        throw new Error('Google OAuth email is required.');
      }

      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: gEmail, name: gName }),
      });
      const authResult = await parseJsonSafely(res);

      if (res.status === 403 || authResult.code === 'WRONG_PORTAL' || authResult.status === 'WRONG_PORTAL') {
        const msg =
          authResult.message ||
          authResult.error ||
          'Staff and leadership members must sign in via the Staff Portal (/staff/login) using email and password.';
        setCurrentUser(null);
        setUserProfile(null);
        setOnboardingState('NONE');
        setError(msg);
        setLoading(false);
        const portalErr: any = new Error(msg);
        portalErr.code = 'WRONG_PORTAL';
        throw portalErr;
      }

      if (authResult.status === 'NEW_USER') {
        const appData = authResult.googleUser || { email: gEmail, name: gName };
        setGoogleApplicantData(appData);
        setOnboardingState('NEW_USER');
        setUserProfile(null);
        setLoading(false);
        return { status: 'NEW_USER', googleUser: appData };
      }

      if (authResult.status === 'PENDING') {
        setOnboardingState('PENDING');
        if (authResult.user) setUserProfile(authResult.user);
        if (authResult.workflow) setOnboardingWorkflow(authResult.workflow);
        setLoading(false);
        return { status: 'PENDING', user: authResult.user, workflow: authResult.workflow };
      }

      if (authResult.status === 'REJECTED') {
        setOnboardingState('REJECTED');
        setRejectionReason(authResult.reason || 'Application declined by Pastoral Administration');
        if (authResult.user) setUserProfile(authResult.user);
        setLoading(false);
        return { status: 'REJECTED', reason: authResult.reason };
      }

      setOnboardingState('APPROVED');
      const approvedProfile: SystemUser = authResult.user || {
        id: `usr-${Date.now()}`,
        name: gName || gEmail.split('@')[0],
        email: gEmail,
        role: 'REGULAR_MEMBER',
        branchName: 'Headquarters Campus',
        status: 'Active',
        lastLogin: new Date().toISOString(),
      };
      if (authResult.token) {
        storeAuthToken(authResult.token, true);
      }
      if (authResult.refreshToken) {
        storeRefreshToken(authResult.refreshToken, true);
      }
      const synced = applyAuthoritativeUser(approvedProfile, true) || approvedProfile;
      setLoading(false);
      return {
        status: 'APPROVED',
        user: synced,
        targetModule: getDefaultRouteForRole(synced.role),
      };
    } catch (err: any) {
      setLoading(false);
      setError(err.message || 'Google sign-in failed');
      throw err;
    }
  };

  /**
   * TAB 1 (Traditional): Member Login via Backend /api/auth/member/login
   * Pipeline: Supabase Auth -> auth.users -> profiles -> authoritative role -> tenant -> branch -> permissions -> session
   */
  const loginMemberTraditional = async (identifier: string, password: string, rememberMe: boolean = true) => {
    setError(null);
    setLoading(true);

    try {
      if (!identifier || !password) {
        throw new Error('Email address and password are required');
      }

      setRememberMeActive(rememberMe);
      const email = identifier.trim();

      let res = await fetch('/api/auth/member/login', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: email, password, rememberMe }),
      });
      if (res.status === 404) {
        res = await fetch('/api/auth/login', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier: email, password, rememberMe }),
        });
      }

      const data = await parseJsonSafely(res);

      // Fallback to direct Supabase Auth when deployed to a static-only host where /api/auth/* returns 404 NOT_FOUND
      if (isBackendRouteUnavailable(res, data) && isSupabaseConfigured) {
        const { data: supData, error: supErr } = await supabase.auth.signInWithPassword({
          email: email.toLowerCase(),
          password,
        });
        if (supErr || !supData?.user || !supData?.session) {
          throw new Error(supErr?.message || 'Invalid email or password. Please verify your credentials.');
        }
        const resolved = await resolveProfileFromSupabaseClient(supData.user);
        if (isStaffOrLeadershipRole(resolved.role)) {
          await supabase.auth.signOut();
          throw new Error('Staff and leadership members must sign in via the Staff Portal (/staff/login).');
        }
        storeAuthToken(supData.session.access_token, rememberMe);
        if (supData.session.refresh_token) {
          storeRefreshToken(supData.session.refresh_token, rememberMe);
        }
        const syncedUser = applyAuthoritativeUser(resolved, rememberMe) || resolved;
        setLoading(false);
        const mustChange = Boolean(syncedUser.must_change_password || (syncedUser as any).mustChangePassword);
        const targetModule = mustChange ? 'change-password' : getDefaultRouteForRole(syncedUser.role);
        return { success: true, user: syncedUser, targetModule, mustChangePassword: mustChange };
      }

      if (res.status === 403 && data.code === 'WRONG_PORTAL') {
        throw new Error(data.message || data.error || 'Staff and leadership members must sign in via the Staff Portal (/staff/login).');
      }

      if (data.status === 'PENDING' && data.redirectUrl) {
        setLoading(false);
        return {
          success: false,
          status: 'PENDING',
          redirectUrl: data.redirectUrl,
          referenceCode: data.referenceCode,
        };
      }

      if (!res.ok || !data.success || !data.user) {
        const err: any = new Error(data.message || data.error || 'Invalid email or password. Please verify your credentials.');
        err.code = data.code || data.error;
        throw err;
      }

      const token = data.token || data.session?.access_token || null;
      const refreshToken = data.refreshToken || data.session?.refresh_token || null;
      if (token) storeAuthToken(token, rememberMe);
      if (refreshToken) storeRefreshToken(refreshToken, rememberMe);
      if (isSupabaseConfigured && token && refreshToken) {
        try {
          await supabase.auth.setSession({
            access_token: token,
            refresh_token: refreshToken,
          });
        } catch {}
      }

      const syncedUser = applyAuthoritativeUser(data.user, rememberMe) || data.user;
      setLoading(false);

      const mustChange = Boolean(syncedUser.must_change_password || (syncedUser as any).mustChangePassword);
      const targetModule = mustChange ? 'change-password' : getDefaultRouteForRole(syncedUser.role);
      return { success: true, user: syncedUser, targetModule, mustChangePassword: mustChange };
    } catch (err: any) {
      setLoading(false);
      setError(err.message || 'Member authentication failed');
      throw err;
    }
  };

  // Password Reset Request
  const requestPasswordReset = async (identifier: string, method: 'email' | 'phone' = 'email') => {
    setError(null);
    setLoading(true);

    try {
      const cleanId = identifier.trim();
      if (!cleanId) {
        throw new Error('Please provide your registered email address.');
      }

      if (cleanId.includes('@') && isSupabaseConfigured) {
        try {
          const { error } = await supabase.auth.resetPasswordForEmail(cleanId, {
            redirectTo: `${window.location.origin}/reset-password`,
          });
          if (!error) {
            setLoading(false);
            return {
              success: true,
              message: `Password reset instructions have been dispatched to ${cleanId}.`,
            };
          }
        } catch (supErr) {
          console.warn('Supabase reset notice, trying backend route:', supErr);
        }
      }

      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: cleanId, method }),
      });
      const resultData = await parseJsonSafely(res);
      setLoading(false);
      return resultData;
    } catch (err: any) {
      setLoading(false);
      setError(err.message || 'Password reset request failed');
      throw err;
    }
  };

  const verifyResetCode = async (identifier: string, code: string) => {
    try {
      const res = await fetch('/api/auth/verify-reset-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, code }),
      });
      return await parseJsonSafely(res);
    } catch (err: any) {
      return { success: false, message: err.message || 'Code verification failed' };
    }
  };

  const confirmPasswordReset = async (identifier: string, code: string, newPassword: string) => {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, code, newPassword }),
      });
      return await parseJsonSafely(res);
    } catch (err: any) {
      return { success: false, message: err.message || 'Password reset failed' };
    }
  };

  /**
   * Authoritative Password Change via POST /api/auth/change-password
   */
  const changePassword = async (currentPassword: string, newPassword: string, confirmPassword?: string) => {
    try {
      if (confirmPassword && newPassword !== confirmPassword) {
        return { success: false, message: 'New password and confirmation do not match.' };
      }
      if (newPassword === currentPassword || newPassword === 'Pass@12345') {
        return { success: false, message: 'New password cannot be the same as your temporary password.' };
      }
      const validation = validatePasswordStrength(newPassword);
      if (!validation.isValid) {
        return { success: false, message: validation.errors[0] || 'Password does not meet security requirements.' };
      }

      let token = getStoredAuthToken();
      if (!token && isSupabaseConfigured) {
        try {
          const session = (await supabase.auth.getSession()).data.session;
          token = session?.access_token || null;
        } catch {}
      }

      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ currentPassword, newPassword, confirmPassword }),
      });

      const data = await parseJsonSafely(res);

      if (isBackendRouteUnavailable(res, data) && isSupabaseConfigured) {
        const { error: updateErr } = await supabase.auth.updateUser({
          password: newPassword,
          data: { must_change_password: false },
        });
        if (updateErr) {
          return { success: false, message: updateErr.message || 'Failed to update password' };
        }
        const remember = isRememberMeActive();
        const updatedRaw = {
          ...(userProfile || {}),
          must_change_password: false,
          mustChangePassword: false,
          password_changed_at: new Date().toISOString(),
        };
        applyAuthoritativeUser(updatedRaw, remember);
        return { success: true, message: 'Password successfully updated' };
      }

      if (!res.ok || !data.success) {
        return { success: false, message: data.message || data.error || 'Failed to update password' };
      }

      const remember = isRememberMeActive();
      if (data.token) {
        storeAuthToken(data.token, remember);
      }
      if (data.refreshToken) {
        storeRefreshToken(data.refreshToken, remember);
      }

      const updatedRaw = {
        ...(userProfile || {}),
        ...(data.user || {}),
        must_change_password: false,
        mustChangePassword: false,
        password_changed_at: data.password_changed_at || new Date().toISOString(),
      };
      applyAuthoritativeUser(updatedRaw, remember);

      return { success: true, message: data.message || 'Password successfully updated' };
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to change password' };
    }
  };

  /**
   * Staff & Leadership Login via Backend POST /api/auth/staff/login
   * Pipeline: Supabase Auth -> auth.users -> profiles -> authoritative role -> tenant -> branch -> permissions -> session
   */
  const loginStaff = async (campusId: string, email: string, password: string, rememberMe: boolean = true) => {
    setError(null);
    setLoading(true);

    try {
      if (!email || !password) {
        throw new Error('Staff email and password are required');
      }

      setRememberMeActive(rememberMe);
      const cleanEmail = email.trim();

      const res = await fetch('/api/auth/staff/login', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: cleanEmail, email: cleanEmail, password, campusId, rememberMe }),
      });
      const data = await parseJsonSafely(res);

      // Fallback to direct Supabase Auth when deployed to a static-only host where /api/auth/staff/login returns 404 NOT_FOUND
      if (isBackendRouteUnavailable(res, data) && isSupabaseConfigured) {
        const { data: supData, error: supErr } = await supabase.auth.signInWithPassword({
          email: cleanEmail.toLowerCase(),
          password,
        });
        if (supErr || !supData?.user || !supData?.session) {
          throw new Error(supErr?.message || 'Invalid leadership credentials. Please verify your email and password.');
        }
        const resolved = await resolveProfileFromSupabaseClient(supData.user);
        if (!isStaffOrLeadershipRole(resolved.role)) {
          await supabase.auth.signOut();
          throw new Error('Regular members must sign in via the Member Portal (/login).');
        }
        storeAuthToken(supData.session.access_token, rememberMe);
        if (supData.session.refresh_token) {
          storeRefreshToken(supData.session.refresh_token, rememberMe);
        }
        const syncedProfile = applyAuthoritativeUser(resolved, rememberMe) || resolved;
        setLoading(false);
        const mustChange = Boolean(syncedProfile.must_change_password || (syncedProfile as any).mustChangePassword);
        const targetModule = mustChange ? 'change-password' : getDefaultRouteForRole(syncedProfile.role);
        return {
          success: true,
          mustChangePassword: mustChange,
          must_change_password: mustChange,
          targetModule,
          user: syncedProfile,
        };
      }

      if (!res.ok || !data.success) {
        const err: any = new Error(
          data.message ||
            data.error ||
            'Invalid leadership credentials. Please verify your email and password.'
        );
        err.code = data.code || data.error;
        throw err;
      }

      // Check if temporary password forced-change flag is set
      if (data.mustChangePassword || data.must_change_password) {
        const tempUser = {
          ...data.user,
          must_change_password: true,
          mustChangePassword: true,
        };
        if (data.token) storeAuthToken(data.token, rememberMe);
        if (data.refreshToken) storeRefreshToken(data.refreshToken, rememberMe);
        const syncedTemp = applyAuthoritativeUser(tempUser, rememberMe) || tempUser;
        setLoading(false);
        return {
          success: true,
          mustChangePassword: true,
          must_change_password: true,
          user: syncedTemp,
          token: data.token,
          targetModule: 'change-password',
        };
      }

      // Check if MFA (TOTP) is required
      if (data.mfaRequired || data.requiresMfa) {
        setLoading(false);
        return {
          success: true,
          requiresMfa: true,
          mfaEnrolled: data.mfaEnrolled,
          totp: data.totp,
          factorId: data.factorId,
          challengeId: data.challengeId,
          sessionToken: data.sessionToken,
          user: data.user,
        };
      }

      const resolvedProfile = data.user;
      const token = data.token;
      const refreshToken = data.refreshToken;

      if (!resolvedProfile) {
        throw new Error('Leadership authentication failed.');
      }

      const assignedRole = normalizeUserRole(resolvedProfile.role);

      // 30-Day Security Protocol Check
      const now = Date.now();
      const lastMaxAuthStr = resolvedProfile.security?.lastMaxAuthAt || resolvedProfile.last_max_auth_at;
      const lastMaxAuthTime = lastMaxAuthStr ? new Date(lastMaxAuthStr).getTime() : 0;
      const diffMs = now - lastMaxAuthTime;
      const daysSinceAuth = Math.floor(diffMs / (24 * 60 * 60 * 1000));

      if (lastMaxAuthStr && diffMs > THIRTY_DAYS_MS) {
        setReAuthRequired(true);
        setReAuthUser({
          uid: resolvedProfile.id,
          email: cleanEmail,
          name: resolvedProfile.name,
          role: assignedRole,
          daysSinceAuth: daysSinceAuth > 0 ? daysSinceAuth : 31,
        });
        setLoading(false);
        return { success: false, requiresReAuth: true };
      }

      if (token) storeAuthToken(token, rememberMe);
      if (refreshToken) storeRefreshToken(refreshToken, rememberMe);
      if (isSupabaseConfigured && token && refreshToken) {
        try {
          await supabase.auth.setSession({
            access_token: token,
            refresh_token: refreshToken,
          });
        } catch {}
      }
      const syncedProfile = applyAuthoritativeUser(resolvedProfile, rememberMe) || resolvedProfile;
      setLoading(false);

      const targetModule = data.targetModule || getDefaultRouteForRole(assignedRole);
      return { success: true, targetModule, user: syncedProfile };
    } catch (err: any) {
      setLoading(false);
      setError(err.message || 'Staff authentication failed');
      throw err;
    }
  };

  /**
   * Verify Staff 2FA / TOTP Code
   */
  const verifyStaffMfa = async (
    code: string,
    options?: { factorId?: string; challengeId?: string; sessionToken?: string; email?: string }
  ) => {
    setError(null);
    setLoading(true);

    try {
      if (!code || code.trim().length !== 6) {
        throw new Error('Please enter a valid 6-digit TOTP verification code');
      }

      const res = await fetch('/api/auth/staff/mfa/verify', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(options?.sessionToken ? { Authorization: `Bearer ${options.sessionToken}` } : {}),
        },
        body: JSON.stringify({
          code: code.trim(),
          factorId: options?.factorId,
          challengeId: options?.challengeId,
          email: options?.email,
          sessionToken: options?.sessionToken,
        }),
      });

      const data = await parseJsonSafely(res);
      if (!res.ok || !data.success) {
        const error: any = new Error(data.message || data.error || 'Failed to verify two-factor authentication code.');
        error.code = data.code || data.error;
        throw error;
      }

      const remember = isRememberMeActive();
      if (data.token) storeAuthToken(data.token, remember);
      if (data.refreshToken) storeRefreshToken(data.refreshToken, remember);
      if (isSupabaseConfigured && data.token && data.refreshToken) {
        try {
          await supabase.auth.setSession({
            access_token: data.token,
            refresh_token: data.refreshToken,
          });
        } catch {}
      }
      const synced = applyAuthoritativeUser(data.user, remember) || data.user;
      setLoading(false);

      const targetModule = data.targetModule || getDefaultRouteForRole(synced.role);
      return { success: true, user: synced, targetModule };
    } catch (err: any) {
      setLoading(false);
      setError(err.message || 'MFA verification failed');
      throw err;
    }
  };

  /**
   * Authoritative 30-Day Staff Re-Authentication (Password + TOTP verified on server)
   */
  const confirmStaffReAuth = async (password: string, twoFactorCode: string) => {
    if (!reAuthUser) {
      throw new Error('No pending re-authentication user found');
    }

    if (!password || !twoFactorCode) {
      throw new Error('Both password and 6-digit 2FA code are required to reset 30-day window');
    }

    const cleanCode = twoFactorCode.replace(/\s/g, '');
    if (cleanCode.length !== 6) {
      throw new Error('Please enter a valid 6-digit 2FA security code');
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/staff/reauth', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: reAuthUser.email,
          password,
          code: cleanCode,
        }),
      });

      const data = await parseJsonSafely(res);
      if (!res.ok || !data.success) {
        throw new Error(data.message || data.error || '30-day security re-authentication failed');
      }

      const remember = isRememberMeActive();
      if (data.token) storeAuthToken(data.token, remember);
      if (data.refreshToken) storeRefreshToken(data.refreshToken, remember);
      if (isSupabaseConfigured && data.token && data.refreshToken) {
        try {
          await supabase.auth.setSession({
            access_token: data.token,
            refresh_token: data.refreshToken,
          });
        } catch {}
      }
      const synced = applyAuthoritativeUser(data.user, remember) || data.user;

      setReAuthRequired(false);
      setReAuthUser(null);
      setLoading(false);

      const targetModule = data.targetModule || getDefaultRouteForRole(synced.role);
      return { success: true, user: synced, targetModule };
    } catch (err: any) {
      setLoading(false);
      setError(err.message || '30-day re-authentication failed');
      throw err;
    }
  };

  const cancelReAuth = () => {
    setReAuthRequired(false);
    setReAuthUser(null);
    setError(null);
  };

  /**
   * Authoritative Sign Out:
   * Calls POST /api/auth/logout, terminates Supabase Auth session,
   * and clears all application authentication states from both localStorage and sessionStorage.
   */
  const logout = useCallback(async () => {
    const token = getStoredAuthToken();
    clearAllAuthStorage();
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
    } catch {}

    if (isSupabaseConfigured) {
      try {
        await supabase.auth.signOut();
      } catch (e) {
        console.warn('Supabase sign out notice:', e);
      }
    }
    setCurrentUser(null);
    setUserProfile(null);
    setReAuthRequired(false);
    setReAuthUser(null);
    setOnboardingState('NONE');
    setGoogleApplicantData(null);
    setOnboardingWorkflow(null);
    setRejectionReason(null);

    clearAllAuthStorage();

    const legacyKeys = [
      'cmms_token',
      'cmms_refresh_token',
      'cmms_auth_token',
      'cmms_jwt_token',
      'cmms_active_user',
      'cmms_active_role',
      'cmms_onboarding_state',
      'cmms_applicant_data',
      'cmms_onboarding_workflow',
      'cmms_rejection_reason',
    ];
    legacyKeys.forEach((key) => {
      try {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
      } catch {}
    });
  }, []);

  // Preview role switcher (only updates active view role in memory if already authenticated)
  const switchDemoRole = useCallback(async (role: UserRole) => {
    const norm = normalizeUserRole(role);
    if (userProfile) {
      setUserProfile({
        ...userProfile,
        role: norm,
      });
    }
  }, [userProfile]);

  // 30-minute idle timeout for staff sessions
  useEffect(() => {
    if (!currentUser || !isStaffOrLeadershipRole(userRole)) {
      return;
    }

    const IDLE_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes
    let idleTimer: any = null;

    const resetTimer = () => {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        console.warn('Staff session timed out due to 30 minutes of inactivity.');
        logout();
      }, IDLE_TIMEOUT_MS);
    };

    const activityEvents = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
    activityEvents.forEach((event) => {
      window.addEventListener(event, resetTimer, { passive: true });
    });

    resetTimer();

    return () => {
      if (idleTimer) clearTimeout(idleTimer);
      activityEvents.forEach((event) => {
        window.removeEventListener(event, resetTimer);
      });
    };
  }, [currentUser, userRole, logout]);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        profile: userProfile,
        userRole,
        tenantId,
        branchId,
        branchIds,
        branchName,
        permissions,
        mfaEnabled,
        loading,
        error,
        reAuthRequired,
        reAuthUser,
        isSupabaseConnected: isSupabaseConfigured,
        onboardingState,
        googleApplicantData,
        onboardingWorkflow,
        rejectionReason,
        setOnboardingState,
        submitGoogleOnboarding,
        checkGoogleApprovalStatus,
        testSimulatedState,
        loginWithGoogle,
        loginMemberTraditional,
        requestPasswordReset,
        verifyResetCode,
        confirmPasswordReset,
        changePassword,
        mustChangePassword: Boolean(userProfile?.must_change_password || (userProfile as any)?.mustChangePassword),
        loginStaff,
        verifyStaffMfa,
        confirmStaffReAuth,
        cancelReAuth,
        refreshSession,
        logout,
        signOut: logout,
        switchDemoRole,
        getDefaultRouteForRole,
        isStaffOrLeadershipRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export { ProtectedRoute } from '../components/ProtectedRoute';
export type { ProtectedRouteProps } from '../components/ProtectedRoute';

export default AuthContext;
