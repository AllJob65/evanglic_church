import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useCMMS } from './CMMSContext';
import { YouVersionBible } from '../types';

export interface BibleContextType {
  selectedVersionId: number;
  setSelectedVersionId: (versionId: number) => void;
  selectedSlotKey: string;
  setSelectedSlotKey: (slotKey: string) => void;
  userVisibleBibles: YouVersionBible[];
  otherAvailableBibles: YouVersionBible[];
  configuredSlots: any[];
  refreshUserBibles: () => Promise<void>;
  currentBook: string;
  setCurrentBook: (book: string) => void;
  currentChapter: string;
  setCurrentChapter: (chapter: string) => void;
  currentReference: string;
  setCurrentReference: (ref: string) => void;
  jumpToReference: (ref: string) => void;
  selectedLanguageId: string;
  setSelectedLanguageId: (langId: string) => void;
}

const STORAGE_KEY_VERSION = 'cmms_selected_bible_version_id';
const STORAGE_KEY_SLOT = 'cmms_selected_bible_slot_key';
const STORAGE_KEY_BOOK = 'cmms_selected_bible_book';
const STORAGE_KEY_CHAPTER = 'cmms_selected_bible_chapter';

const DEFAULT_USER_VISIBLE_BIBLES: YouVersionBible[] = [
  {
    id: 1260,
    slotKey: 'AM05',
    abbreviation: 'NASV',
    localized_abbreviation: 'NASV',
    title: 'New Amharic Standard Version 2024',
    localized_title: 'አዲሱ መደበኛ ትርጒም',
    userDisplayLabel: 'አዲሱ መደበኛ ትርጒም (New Amharic Standard Version 2024) — NASV',
    language_tag: 'am',
    enabled: true,
    displayOrder: 1,
    isDefault: false,
    isFeatured: true,
  },
  {
    id: 111,
    slotKey: 'NIV',
    abbreviation: 'NIV11',
    localized_abbreviation: 'NIV',
    title: 'New International Version 2011',
    localized_title: 'New International Version',
    userDisplayLabel: 'New International Version (NIV)',
    language_tag: 'en',
    enabled: true,
    displayOrder: 3,
    isDefault: true,
    isFeatured: true,
  },
];

const BibleContext = createContext<BibleContextType | undefined>(undefined);

export const BibleProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { language } = useCMMS();

  // Determine initial version based on cached value or user's active locale
  const [selectedVersionId, setSelectedVersionIdState] = useState<number>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY_VERSION);
      if (cached) {
        const parsed = parseInt(cached, 10);
        if (!isNaN(parsed) && parsed > 0) return parsed;
      }
    } catch {
      // Ignore local storage error
    }
    // Default: 1260 for Amharic, 111 (NIV) for English/others
    return language === 'Amharic' ? 1260 : 111;
  });

  const [selectedSlotKey, setSelectedSlotKeyState] = useState<string>(() => {
    try {
      const cachedSlot = localStorage.getItem(STORAGE_KEY_SLOT);
      if (cachedSlot) return cachedSlot;
    } catch {}
    return language === 'Amharic' ? 'AM05' : 'NIV';
  });

  const [userVisibleBibles, setUserVisibleBibles] = useState<YouVersionBible[]>(DEFAULT_USER_VISIBLE_BIBLES);
  const [otherAvailableBibles, setOtherAvailableBibles] = useState<YouVersionBible[]>([]);
  const [configuredSlots, setConfiguredSlots] = useState<any[]>([]);

  const refreshUserBibles = useCallback(async () => {
    try {
      const res = await fetch('/api/bible/youversion/bibles?scope=user');
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.bibles) && data.bibles.length > 0) {
        setUserVisibleBibles(data.bibles);
      }
      if (Array.isArray(data.otherBibles)) {
        setOtherAvailableBibles(data.otherBibles);
      }
      if (Array.isArray(data.configuredSlots)) {
        setConfiguredSlots(data.configuredSlots);
      }
    } catch {
      // Keep default verified list if offline
    }
  }, []);

  useEffect(() => {
    refreshUserBibles();
  }, [refreshUserBibles]);

  const [currentBook, setCurrentBookState] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_BOOK) || 'JHN';
    } catch {
      return 'JHN';
    }
  });

  const [currentChapter, setCurrentChapterState] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_CHAPTER) || '3';
    } catch {
      return '3';
    }
  });

  const [currentReference, setCurrentReference] = useState<string>('JHN.3.16');
  const [selectedLanguageId, setSelectedLanguageId] = useState<string>(
    language === 'Amharic' ? 'am' : 'en'
  );

  const setSelectedVersionId = useCallback((versionId: number) => {
    setSelectedVersionIdState(versionId);
    try {
      localStorage.setItem(STORAGE_KEY_VERSION, String(versionId));
    } catch {
      // Ignore
    }
  }, []);

  const setSelectedSlotKey = useCallback((slotKey: string) => {
    setSelectedSlotKeyState(slotKey);
    try {
      localStorage.setItem(STORAGE_KEY_SLOT, slotKey);
    } catch {
      // Ignore
    }
  }, []);

  const setCurrentBook = useCallback((book: string) => {
    setCurrentBookState(book);
    try {
      localStorage.setItem(STORAGE_KEY_BOOK, book);
    } catch {
      // Ignore
    }
  }, []);

  const setCurrentChapter = useCallback((chapter: string) => {
    setCurrentChapterState(chapter);
    try {
      localStorage.setItem(STORAGE_KEY_CHAPTER, chapter);
    } catch {
      // Ignore
    }
  }, []);

  // Jump to a given reference, parsing either USFM ("JHN.3.16") or human readable format
  const jumpToReference = useCallback((ref: string) => {
    if (!ref || typeof ref !== 'string') return;
    setCurrentReference(ref);

    // If format is like "JHN.3.16" or "PSA.23.1-6"
    const usfmMatch = ref.match(/^([A-Z0-9]{3})\.([0-9]+)/i);
    if (usfmMatch) {
      const book = usfmMatch[1].toUpperCase();
      const chapter = usfmMatch[2];
      setCurrentBook(book);
      setCurrentChapter(chapter);
      return;
    }

    // Common book mappings for human-readable references e.g. "John 3:16"
    const humanMatch = ref.match(/^([1-3]?\s*[A-Za-z]+)\s+([0-9]+)/);
    if (humanMatch) {
      const rawBook = humanMatch[1].trim().toLowerCase();
      const chapter = humanMatch[2];
      const bookMap: Record<string, string> = {
        'genesis': 'GEN', 'gen': 'GEN',
        'exodus': 'EXO', 'exo': 'EXO',
        'psalms': 'PSA', 'psalm': 'PSA', 'psa': 'PSA',
        'proverbs': 'PRO', 'pro': 'PRO',
        'isaiah': 'ISA', 'isa': 'ISA',
        'matthew': 'MAT', 'matt': 'MAT', 'mat': 'MAT',
        'mark': 'MRK', 'mrk': 'MRK',
        'luke': 'LUK', 'luk': 'LUK',
        'john': 'JHN', 'jhn': 'JHN',
        'acts': 'ACT', 'act': 'ACT',
        'romans': 'ROM', 'rom': 'ROM',
        'revelation': 'REV', 'rev': 'REV',
      };
      if (bookMap[rawBook]) {
        setCurrentBook(bookMap[rawBook]);
        setCurrentChapter(chapter);
      }
    }
  }, [setCurrentBook, setCurrentChapter]);

  return (
    <BibleContext.Provider
      value={{
        selectedVersionId,
        setSelectedVersionId,
        selectedSlotKey,
        setSelectedSlotKey,
        userVisibleBibles,
        otherAvailableBibles,
        configuredSlots,
        refreshUserBibles,
        currentBook,
        setCurrentBook,
        currentChapter,
        setCurrentChapter,
        currentReference,
        setCurrentReference,
        jumpToReference,
        selectedLanguageId,
        setSelectedLanguageId,
      }}
    >
      {children}
    </BibleContext.Provider>
  );
};

export const useBible = (): BibleContextType => {
  const context = useContext(BibleContext);
  if (!context) {
    throw new Error('useBible must be used within a BibleProvider');
  }
  return context;
};
