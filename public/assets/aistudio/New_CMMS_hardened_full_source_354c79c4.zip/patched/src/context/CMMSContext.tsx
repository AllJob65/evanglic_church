import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  UserRole,
  Member,
  Family,
  Branch,
  Ministry,
  AttendanceRecord,
  AttendanceSession,
  EventItem,
  CommunicationMessage,
  CommunicationLog,
  CommunicationSystemStatus,
  PrayerRequest,
  CounselingSession,
  VisitationRecord,
  VolunteerShift,
  Asset,
  DocumentItem,
  LmsCourse,
  WorkflowRequest,
  AuditLog,
  SystemUser,
  ProfileChangeRequest,
} from '../types';
import {
  initialBranches,
  initialMembers,
  initialFamilies,
  initialMinistries,
  initialAttendanceRecords,
  initialAttendanceSessions,
  initialEvents,
  initialCommunications,
  initialPrayerRequests,
  initialCounselingSessions,
  initialVisitations,
  initialVolunteerShifts,
  initialAssets,
  initialDocuments,
  initialCourses,
  initialWorkflows,
  initialAuditLogs,
  initialSystemUsers,
  initialProfileChangeRequests,
} from '../data/mockData';
import { getRolePermissions } from '../utils/rbac';
import { useTranslation, CODE_TO_NAME, SupportedLanguage } from '../i18n/LanguageContext';
import { apiService } from '../services/api';
import { getStoredAuthToken } from '../lib/supabase';
import { updateBrowserFavicon, updateBrowserTitle } from '../utils/favicon';
import { MODULE_TO_PATH, parseCurrentLocation } from '../utils/routes';
import { normalizeUserRole } from '../utils/rbac';
import { useAuth } from './AuthContext';

export type ModuleTab =
  | 'dashboard'
  | 'bible'
  | 'devotions'
  | 'members'
  | 'families'
  | 'branches'
  | 'ministries'
  | 'attendance'
  | 'events'
  | 'communications'
  | 'prayer_counseling'
  | 'visitations'
  | 'volunteers'
  | 'assets'
  | 'documents'
  | 'lms'
  | 'workflows'
  | 'predictive'
  | 'backup'
  | 'security_audit'
  | 'settings'
  | 'api_integrations'
  | 'mobile_preview'
  | 'approvals'
  | 'reports'
  | 'my_profile';

interface CMMSContextType {
  isAuthenticated: boolean;
  setIsAuthenticated: (auth: boolean) => void;
  currentUser: { name: string; displayName?: string; email: string; role: UserRole; photoUrl?: string; memberId?: string } | null;
  login: (email: string, role?: UserRole, name?: string) => void;
  logout: () => void;

  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  selectedBranchId: string;
  setSelectedBranchId: (branchId: string) => void;
  activeModule: ModuleTab;
  setActiveModule: (module: ModuleTab) => void;
  globalSearchQuery: string;
  setGlobalSearchQuery: (query: string) => void;
  themeMode: 'light' | 'dark' | 'advanced-dark' | 'system';
  setThemeMode: (mode: 'light' | 'dark' | 'advanced-dark' | 'system') => void;
  systemName: string;
  setSystemName: (name: string) => void;
  titleBadge: string;
  setTitleBadge: (badge: string) => void;
  churchMotto: string;
  setChurchMotto: (motto: string) => void;
  churchName: string;
  setChurchName: (name: string) => void;
  primaryColorHex: string;
  setPrimaryColorHex: (hex: string) => void;
  accentColorHex: string;
  setAccentColorHex: (hex: string) => void;
  loginPanelColorHex: string;
  setLoginPanelColorHex: (hex: string) => void;
  faviconUrl: string;
  setFaviconUrl: (url: string) => void;
  darkLogoUrl: string;
  setDarkLogoUrl: (url: string) => void;
  updateBranding: (name: string, lightLogo: string, darkLogo?: string, favicon?: string) => void;
  updateFullBranding: (brandingUpdates: {
    systemName?: string;
    churchName?: string;
    titleBadge?: string;
    churchMotto?: string;
    faviconUrl?: string;
    churchLogoUrl?: string;
    darkLogoUrl?: string;
    primaryColorHex?: string;
    accentColorHex?: string;
    loginPanelColorHex?: string;
    defaultThemeMode?: 'light' | 'dark' | 'advanced-dark' | 'system';
  }) => Promise<void>;
  updateUserProfilePhoto: (photoUrl: string) => void;
  dashboardSubTab: 'overview' | 'backup_restore' | 'system_health' | 'readiness' | 'backup' | 'health';
  setDashboardSubTab: (tab: 'overview' | 'backup_restore' | 'system_health' | 'readiness' | 'backup' | 'health') => void;
  backupSubTab: string;
  setBackupSubTab: (tab: string) => void;
  language: string;
  langCode: 'en' | 'am' | 'ti' | 'om';
  languageCode: 'en' | 'am' | 'ti' | 'om';
  setLanguage: (lang: string) => void;
  t: (key: string, fallbackOrParams?: string | Record<string, string | number>, maybeFallback?: string) => string;
  fontClass: string;
  isEthiopic: boolean;
  currency: 'USD' | 'ETB' | 'EUR' | 'GBP';
  setCurrency: (curr: 'USD' | 'ETB' | 'EUR' | 'GBP') => void;
  churchLogoUrl: string;
  setChurchLogoUrl: (url: string) => void;
  isSidebarCollapsed: boolean;
  setIsSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;

  // Data collections
  branches: Branch[];
  members: Member[];
  families: Family[];
  ministries: Ministry[];
  attendanceRecords: AttendanceRecord[];
  attendanceSessions: AttendanceSession[];
  activeAttendanceSessions: AttendanceSession[];
  events: EventItem[];
  communications: CommunicationMessage[];
  communicationLogs: CommunicationLog[];
  communicationStatus: CommunicationSystemStatus | null;
  prayerRequests: PrayerRequest[];
  counselingSessions: CounselingSession[];
  visitations: VisitationRecord[];
  volunteerShifts: VolunteerShift[];
  assets: Asset[];
  documents: DocumentItem[];
  documentCategories: string[];
  courses: LmsCourse[];
  workflows: WorkflowRequest[];
  auditLogs: AuditLog[];
  systemUsers: SystemUser[];
  profileChangeRequests: ProfileChangeRequest[];

  // Mutators
  addMember: (member: Member) => Promise<Member>;
  updateMember: (member: Member) => Promise<Member>;
  deleteMember: (id: string) => void;
  addFamily: (family: Family) => void;
  updateFamily: (family: Family) => void;
  deleteFamily: (id: string) => void;
  addBranch: (branch: Branch) => void;
  updateBranch: (branch: Branch) => void;
  deleteBranch: (id: string) => void;
  swapMemberBranch: (memberId: string, newBranchId: string) => void;
  addMinistry: (ministry: Partial<Ministry>) => Promise<Ministry>;
  updateMinistry: (ministry: Ministry) => Promise<Ministry>;
  deleteMinistry: (id: string) => Promise<boolean>;
  removeMemberFromMinistry: (memberId: string, ministryId: string) => void;
  deleteSubMinistry: (ministryId: string, subMinistryId: string) => Promise<void>;
  refreshMinistries: () => Promise<Ministry[]>;
  recordAttendance: (record: AttendanceRecord) => void;
  bulkImportAttendance: (records: AttendanceRecord[]) => void;
  
  // Real-time Active Attendance Sessions (Leader Activation & Member Check-In)
  activateAttendanceSession: (payload: {
    groupId: string;
    groupName?: string;
    branchId?: string;
    leaderId?: string;
    leaderName?: string;
    type: 'instant' | 'scheduled';
    title: string;
    serviceType?: string;
    location?: string;
  }) => AttendanceSession;
  closeAttendanceSession: (sessionId: string) => void;
  rotateSessionToken: (sessionId: string) => string;
  checkInToSession: (params: {
    sessionId: string;
    checkInType?: 'qr' | 'manual' | 'Manual Web Click' | 'QR Code Scanning';
    memberId?: string;
    memberName?: string;
    token?: string;
  }) => Promise<{ success: boolean; message: string; record?: AttendanceRecord }>;
  addEvent: (evt: EventItem) => void;
  sendCommunication: (comm: CommunicationMessage) => void;
  sendSms: (payload: {
    recipient?: string;
    recipients?: (string | { phone?: string; memberId?: string; familyId?: string; name?: string })[];
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    subject?: string;
    message: string;
    triggerType?: string;
  }) => Promise<any>;
  sendEmail: (payload: {
    recipient?: string;
    recipients?: (string | { email?: string; memberId?: string; familyId?: string; name?: string })[];
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    subject: string;
    message: string;
    html?: string;
    triggerType?: string;
  }) => Promise<any>;
  sendBroadcast: (payload: {
    channel: 'SMS' | 'EMAIL' | 'BOTH' | 'Multi-Channel';
    targetType: 'all_active' | 'branch' | 'ministry' | 'family' | 'custom_members';
    branchId?: string;
    ministryId?: string;
    familyId?: string;
    memberIds?: string[];
    subject?: string;
    message: string;
    triggerType?: string;
  }) => Promise<any>;
  retryCommunicationLog: (id: string) => Promise<any>;
  refreshCommunicationLogs: () => Promise<void>;
  addPrayerRequest: (req: PrayerRequest) => void;
  updatePrayerStatus: (id: string, status: PrayerRequest['status'], notes?: string) => void;
  addCounselingSession: (session: CounselingSession) => void;
  addVisitationRecord: (record: VisitationRecord) => void;
  addVolunteerShift: (shift: VolunteerShift) => void;
  addAsset: (asset: Asset) => void;
  addDocument: (doc: DocumentItem) => void;
  deleteDocument: (id: string) => void;
  addDocumentCategory: (categoryName: string) => void;
  deleteDocumentCategory: (categoryName: string) => void;
  addCourse: (course: LmsCourse) => void;
  updateCourse: (course: LmsCourse) => void;
  deleteCourse: (id: string) => void;
  addWorkflowRequest: (wf: WorkflowRequest) => void;
  updateWorkflowStatus: (
    id: string,
    status: WorkflowRequest['status'],
    comment?: string,
    approverName?: string
  ) => Promise<{ success: boolean; workflow?: WorkflowRequest; error?: string }>;
  addAuditLog: (action: string, moduleName: string, details: string, commitData?: string, location?: string) => void;
  
  // Member Profile Change Requests & Admin Approvals
  submitProfileChangeRequest: (
    memberId: string,
    changes: Partial<Member>,
    baselineMember?: Partial<Member>
  ) => ProfileChangeRequest;
  approveProfileChangeRequest: (requestId: string, adminNotes?: string) => void;
  rejectProfileChangeRequest: (requestId: string, reason: string) => void;

  // Unified Household Registration & Propagation
  registerUnifiedHousehold: (payload: {
    head: Partial<Member>;
    spouse?: Partial<Member>;
    children: Partial<Member>[];
    household: Partial<Family>;
  }) => Family;
  propagateHouseholdAddress: (
    householdId: string,
    address: {
      streetAddress: string;
      woreda?: string;
      kebele?: string;
      houseNumber?: string;
      city: string;
      region: string;
    }
  ) => void;

  // System Users & Roles
  addSystemUser: (user: SystemUser) => void;
  updateSystemUser: (user: SystemUser) => void;
  removeSystemUser: (id: string) => void;
  resetUserPassword: (id: string, newPassword?: string) => void;
  updateUserRole: (userId: string, newRole: UserRole) => void;
  toggleUserMfa: (userId: string, enabled?: boolean) => void;

  // Backup & Restore
  exportSystemBackupJSON: () => string;
  restoreSystemBackupJSON: (jsonString: string) => boolean;
  resetToDefaultData: () => void;
  reloadFromBackend: () => Promise<void>;
  refreshFromBackend: () => Promise<void>;
  getAuthHeaders: (extraHeaders?: Record<string, string>) => Record<string, string>;

  // Aliases & helpers
  markAttendance: (record: AttendanceRecord) => void;
  userProfile: Member | null;

  // RBAC permissions helper
  permissions: ReturnType<typeof getRolePermissions>;
}

const CMMSContext = createContext<CMMSContextType | undefined>(undefined);

export const CMMSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { userProfile, loading: authLoading, logout: authLogout } = useAuth();

  // Parse initial route parameters from window location
  const initialRoute = useMemo(() => {
    return parseCurrentLocation(location.pathname, location.search, location.hash);
  }, []);

  const isAuthenticated = !authLoading && !!userProfile;
  const setIsAuthenticated = useCallback((_auth: boolean) => {
    // Auth state is authoritatively managed by AuthProvider/Supabase
  }, []);
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    email: string;
    role: UserRole;
    photoUrl?: string;
    memberId?: string;
  } | null>(() => {
    if (userProfile) {
      return {
        name: userProfile.name,
        email: userProfile.email,
        role: userProfile.role,
        memberId: (userProfile as any).id || (userProfile as any).memberId,
        photoUrl: (userProfile as any).photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100',
      };
    }
    return null;
  });

  const [activeRole, setActiveRoleState] = useState<UserRole>(() =>
    userProfile ? normalizeUserRole(userProfile.role) : 'REGULAR_MEMBER'
  );

  // Synchronize currentUser and activeRole with verified auth state
  useEffect(() => {
    if (userProfile) {
      setCurrentUser({
        name: userProfile.name,
        email: userProfile.email,
        role: userProfile.role,
        memberId: (userProfile as any).id || (userProfile as any).memberId,
        photoUrl: (userProfile as any).photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100',
      });
      setActiveRoleState(normalizeUserRole(userProfile.role));
    } else if (!authLoading) {
      setCurrentUser(null);
      setActiveRoleState('REGULAR_MEMBER');
    }
  }, [userProfile, authLoading]);

  const [selectedBranchId, setSelectedBranchIdState] = useState<string>(() => {
    if (initialRoute.branchId) return initialRoute.branchId;
    if (typeof window !== 'undefined') {
      try {
        const savedBranch = localStorage.getItem('cmms_selected_branch_id') || sessionStorage.getItem('cmms_selected_branch_id');
        if (savedBranch) return savedBranch;
      } catch {}
    }
    return 'all';
  });

  const setSelectedBranchId = useCallback((branchId: string) => {
    setSelectedBranchIdState(branchId);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('cmms_selected_branch_id', branchId);
        sessionStorage.setItem('cmms_selected_branch_id', branchId);
      } catch {}
    }
  }, []);
  const [activeModule, setActiveModuleState] = useState<ModuleTab>(initialRoute.module);
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>('');

  // Subpages for Dashboard & Backup
  const [dashboardSubTab, setDashboardSubTabState] = useState<'overview' | 'backup_restore' | 'system_health' | 'readiness'>(
    initialRoute.dashboardSubTab || 'overview'
  );
  const [backupSubTab, setBackupSubTab] = useState<string>('scheduled');

  // Role landing helper
  const getLandingPathForRole = (role?: UserRole | string): string => {
    if (!role) return '/devotions';
    const norm = normalizeUserRole(role);
    if (norm === 'SYSTEM_ADMIN' || norm === 'MANAGER') {
      return '/dashboard';
    }
    if (norm === 'PASTOR') {
      return '/prayer-counseling';
    }
    if (norm === 'MINISTRY_LEADER') {
      return '/attendance';
    }
    return '/devotions';
  };

  // Bidirectional sync: when URL changes (popstate, back/forward, direct link), update active module & subTab
  useEffect(() => {
    const parsed = parseCurrentLocation(location.pathname, location.search, location.hash);
    
    // Public routes (landing frontpage '/', '/landing', login '/login', registration '/register') should never be auto-redirected
    if (parsed.isPublicRoute) {
      return;
    }

    // Wait for authentication session restoration before enforcing role redirects on refresh
    if (authLoading) {
      if (parsed.module !== activeModule) {
        setActiveModuleState(parsed.module);
      }
      return;
    }

    // Check if current role is member trying to access admin view
    const effectiveRole = userProfile ? normalizeUserRole(userProfile.role) : normalizeUserRole(activeRole);
    const isMember = effectiveRole === 'REGULAR_MEMBER';
    const adminOnlyModules: ModuleTab[] = [
      'dashboard',
      'members',
      'families',
      'branches',
      'ministries',
      'approvals',
      'workflows',
      'predictive',
      'reports',
      'backup',
      'security_audit',
      'settings',
    ];

    if (userProfile && isMember && adminOnlyModules.includes(parsed.module) && location.pathname !== '/login') {
      setActiveModuleState('devotions');
      navigate('/devotions', { replace: true });
      return;
    }

    if (parsed.module !== activeModule) {
      setActiveModuleState(parsed.module);
    }
    if (parsed.dashboardSubTab && parsed.dashboardSubTab !== dashboardSubTab) {
      setDashboardSubTabState(parsed.dashboardSubTab);
    }
    if (parsed.branchId && parsed.branchId !== selectedBranchId) {
      setSelectedBranchId(parsed.branchId);
    }
  }, [location.pathname, location.search, location.hash, activeRole, authLoading, userProfile, navigate]);

  // Wrapped active module setter to navigate cleanly with RBAC guard
  const setActiveModule = useCallback((module: ModuleTab) => {
    const isMember = normalizeUserRole(activeRole) === 'REGULAR_MEMBER';
    const adminOnlyModules: ModuleTab[] = [
      'dashboard',
      'members',
      'families',
      'branches',
      'ministries',
      'approvals',
      'workflows',
      'predictive',
      'reports',
      'backup',
      'security_audit',
      'settings',
    ];

    if (isMember && adminOnlyModules.includes(module)) {
      setActiveModuleState('devotions');
      navigate('/devotions');
      return;
    }

    setActiveModuleState(module);
    const targetPath = MODULE_TO_PATH[module] || '/dashboard';
    if (location.pathname !== targetPath) {
      navigate(targetPath);
    }
  }, [location.pathname, navigate, activeRole]);

  const setDashboardSubTab = useCallback((tab: 'overview' | 'backup_restore' | 'system_health' | 'readiness') => {
    setDashboardSubTabState(tab);
    if (activeModule === 'dashboard') {
      const targetPath = tab === 'overview' ? '/dashboard' : `/dashboard/${tab}`;
      if (location.pathname !== targetPath) {
        navigate(targetPath);
      }
    }
  }, [activeModule, location.pathname, navigate]);

  const login = (email: string, role?: UserRole, name?: string) => {
    const assignedRole = role || activeRole;
    const userName = name || (email.includes('@') ? email.split('@')[0] : email);
    setCurrentUser({
      name: userName,
      email,
      role: assignedRole,
      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100',
    });
    setActiveRoleState(assignedRole);
    
    // Log user joining/logging into system with location
    const newLog: AuditLog = {
      id: `log-login-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userEmail: email,
      userName: userName,
      userRole: assignedRole,
      action: 'User Joined / Authenticated',
      module: 'Security & Access',
      ipAddress: '197.156.103.42',
      location: 'Addis Ababa, Bole (HQ Campus Terminal)',
      details: `${userName} (${email}) signed in successfully as ${assignedRole}`,
      commitData: `{"session": "active", "authMethod": "Bearer Token / Password", "loginTime": "${new Date().toISOString()}"}`,
      device: 'MacBook Pro / Chrome 124.0 (Desktop)',
    };
    setAuditLogs((prev) => [newLog, ...prev.filter((l) => l.id !== newLog.id)]);

    if (location.pathname === '/login' || location.pathname === '/') {
      const targetPath = getLandingPathForRole(assignedRole);
      navigate(targetPath);
    }
  };

  const logout = async () => {
    setCurrentUser(null);
    await authLogout();
    navigate('/login', { replace: true });
  };
  
  // Theme state with Light Mode strictly as default when no saved preference exists
  const [themeMode, setThemeModeState] = useState<'light' | 'dark' | 'advanced-dark' | 'system'>(() => {
    try {
      const saved =
        localStorage.getItem('cmms-theme') ||
        localStorage.getItem('cmms_theme_mode') ||
        localStorage.getItem('theme');
      if (saved === 'dark' || saved === 'advanced-dark' || saved === 'light' || saved === 'system') {
        return saved;
      }
    } catch {}
    return 'light';
  });

  const setThemeMode = (mode: 'light' | 'dark' | 'advanced-dark' | 'system') => {
    setThemeModeState(mode);
    try {
      const binaryTheme = mode === 'dark' || mode === 'advanced-dark' ? 'dark' : 'light';
      localStorage.setItem('cmms_theme_mode', mode);
      localStorage.setItem('cmms-theme', mode === 'advanced-dark' ? 'advanced-dark' : binaryTheme);
      localStorage.setItem('theme', binaryTheme);
    } catch {}
  };

  // Profile change requests state
  const [profileChangeRequests, setProfileChangeRequests] = useState<ProfileChangeRequest[]>(initialProfileChangeRequests);

  // Sync theme class to root html element and document body
  React.useEffect(() => {
    const root = document.documentElement;
    const body = document.body;

    const applyTheme = () => {
      root.classList.remove('light', 'dark', 'advanced-dark');
      body.classList.remove('light', 'dark', 'advanced-dark');

      let resolved: 'light' | 'dark' | 'advanced-dark' = 'light';
      if (themeMode === 'advanced-dark') {
        resolved = 'advanced-dark';
      } else if (themeMode === 'dark') {
        resolved = 'dark';
      } else if (themeMode === 'system' && typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
        resolved = 'dark';
      } else {
        resolved = 'light';
      }

      if (resolved === 'advanced-dark') {
        root.classList.add('dark', 'advanced-dark');
        body.classList.add('dark', 'advanced-dark');
      } else if (resolved === 'dark') {
        root.classList.add('dark');
        body.classList.add('dark');
      } else {
        root.classList.add('light');
        body.classList.add('light');
      }
    };

    applyTheme();
  }, [themeMode]);
  const [systemName, setSystemNameState] = useState<string>(() => {
    const saved = localStorage.getItem('cmms_system_name');
    if (!saved || saved === 'CMMS') return 'Grace Cathedral International';
    return saved;
  });

  const [titleBadge, setTitleBadgeState] = useState<string>(() => {
    return localStorage.getItem('cmms_title_badge') || 'Sovereign Portal';
  });

  const setTitleBadge = (badge: string) => {
    setTitleBadgeState(badge);
    localStorage.setItem('cmms_title_badge', badge);
    updateBrowserTitle(systemName, badge);
  };

  const [churchMotto, setChurchMottoState] = useState<string>(() => {
    return localStorage.getItem('cmms_church_motto') || 'Reaching the Lost, Discipling the Found, Transforming Nations';
  });

  const setChurchMotto = (motto: string) => {
    setChurchMottoState(motto);
    localStorage.setItem('cmms_church_motto', motto);
  };

  const [churchName, setChurchNameState] = useState<string>(() => {
    const saved = localStorage.getItem('cmms_church_name');
    if (!saved || saved.includes('Grace Cathedral')) return 'Church Management System';
    return saved;
  });

  const setChurchName = (name: string) => {
    setChurchNameState(name);
    localStorage.setItem('cmms_church_name', name);
  };

  const [primaryColorHex, setPrimaryColorHexState] = useState<string>(() => {
    return localStorage.getItem('cmms_primary_color') || '#2563eb';
  });

  const setPrimaryColorHex = (hex: string) => {
    setPrimaryColorHexState(hex);
    localStorage.setItem('cmms_primary_color', hex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--cmms-primary-color', hex);
      document.documentElement.style.setProperty('--color-primary', hex);
    }
  };

  const [accentColorHex, setAccentColorHexState] = useState<string>(() => {
    return localStorage.getItem('cmms_accent_color') || '#7c3aed';
  });

  const setAccentColorHex = (hex: string) => {
    setAccentColorHexState(hex);
    localStorage.setItem('cmms_accent_color', hex);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--cmms-accent-color', hex);
      document.documentElement.style.setProperty('--color-accent', hex);
    }
  };

  const [loginPanelColorHex, setLoginPanelColorHexState] = useState<string>(() => {
    return localStorage.getItem('cmms_login_panel_color') || '#0f172a';
  });

  // Helper to compute derived interactive state & WCAG contrast tokens from brand hex values
  const applyDerivedBrandTokens = React.useCallback(
    (primaryHex: string, accentHex: string, panelHex: string, mode: string) => {
      if (typeof document === 'undefined') return;
      const root = document.documentElement;
      const parseHex = (h: string, fallback: [number, number, number]): [number, number, number] => {
        const clean = (h || '').replace('#', '').trim();
        if (clean.length === 3) {
          const r = parseInt(clean[0] + clean[0], 16);
          const g = parseInt(clean[1] + clean[1], 16);
          const b = parseInt(clean[2] + clean[2], 16);
          return Number.isNaN(r) ? fallback : [r, g, b];
        }
        if (clean.length === 6) {
          const r = parseInt(clean.slice(0, 2), 16);
          const g = parseInt(clean.slice(2, 4), 16);
          const b = parseInt(clean.slice(4, 6), 16);
          return Number.isNaN(r) ? fallback : [r, g, b];
        }
        return fallback;
      };

      const clamp = (n: number) => Math.max(0, Math.min(255, Math.round(n)));
      const toHex = (r: number, g: number, b: number) =>
        `#${[clamp(r), clamp(g), clamp(b)].map((x) => x.toString(16).padStart(2, '0')).join('')}`;

      const [pr, pg, pb] = parseHex(primaryHex, [37, 99, 235]);
      const isDarkTheme = mode === 'dark' || mode === 'advanced-dark';

      // Hover state: slightly darker shade in Light Mode (-18%), slightly lighter shade in Dark Mode (+18%)
      const hoverHex = isDarkTheme
        ? toHex(pr + (255 - pr) * 0.18, pg + (255 - pg) * 0.18, pb + (255 - pb) * 0.18)
        : toHex(pr * 0.84, pg * 0.84, pb * 0.84);

      // Focus ring state: brand color with 35% opacity layer
      const focusRingRgba = `rgba(${pr}, ${pg}, ${pb}, 0.35)`;

      // Over-Brand Text contrast calculation (WCAG relative luminance of login split panel)
      const [br, bg, bb] = parseHex(panelHex, [15, 23, 42]);
      const srgb = [br / 255, bg / 255, bb / 255].map((c) =>
        c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
      );
      const luminance = 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
      const isLightBrandPanel = luminance > 0.52;

      root.style.setProperty('--cmms-primary-color', primaryHex || '#2563eb');
      root.style.setProperty('--cmms-primary-hover', hoverHex);
      root.style.setProperty('--cmms-focus-ring', focusRingRgba);
      root.style.setProperty('--cmms-accent-color', accentHex || '#7c3aed');
      root.style.setProperty('--cmms-secondary-action', accentHex || '#7c3aed');
      root.style.setProperty('--cmms-login-panel-color', panelHex || '#0f172a');
      root.style.setProperty('--cmms-over-brand-text', isLightBrandPanel ? '#0F172A' : '#FFFFFF');
      root.style.setProperty('--cmms-over-brand-muted', isLightBrandPanel ? '#475569' : '#CBD5E1');
      root.style.setProperty(
        '--cmms-over-brand-card-bg',
        isLightBrandPanel ? 'rgba(15, 23, 42, 0.05)' : 'rgba(255, 255, 255, 0.06)'
      );
      root.style.setProperty(
        '--cmms-over-brand-card-border',
        isLightBrandPanel ? 'rgba(15, 23, 42, 0.12)' : 'rgba(255, 255, 255, 0.14)'
      );
      root.style.setProperty('--color-primary', primaryHex || '#2563eb');
      root.style.setProperty('--color-primary-hover', hoverHex);
      root.style.setProperty('--color-accent', accentHex || '#7c3aed');
    },
    []
  );

  const setLoginPanelColorHex = (hex: string) => {
    setLoginPanelColorHexState(hex);
    localStorage.setItem('cmms_login_panel_color', hex);
    applyDerivedBrandTokens(primaryColorHex, accentColorHex, hex, themeMode);
  };

  // Sync brand color CSS variables & derived interactive/contrast tokens to root html element
  React.useEffect(() => {
    applyDerivedBrandTokens(primaryColorHex, accentColorHex, loginPanelColorHex, themeMode);
  }, [primaryColorHex, accentColorHex, loginPanelColorHex, themeMode, applyDerivedBrandTokens]);

  const [faviconUrl, setFaviconUrlState] = useState<string>(() => {
    return (
      localStorage.getItem('cmms_favicon_url') ||
      'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%232563eb"/><path d="M16 4l-9 8v16h18V12l-9-8zm0 5l5 4.5v12.5h-10V13.5l5-4.5z" fill="%23ffffff"/><rect x="14" y="19" width="4" height="7" rx="1" fill="%23ffffff"/></svg>'
    );
  });

  const setFaviconUrl = (url: string) => {
    setFaviconUrlState(url);
    localStorage.setItem('cmms_favicon_url', url);
    updateBrowserFavicon(url);
  };

  const [churchLogoUrl, setChurchLogoUrlState] = useState<string>(() => {
    return localStorage.getItem('cmms_church_logo') || '';
  });

  const [darkLogoUrl, setDarkLogoUrlState] = useState<string>(() => {
    return localStorage.getItem('cmms_dark_logo') || '';
  });

  const setSystemName = (name: string) => {
    setSystemNameState(name);
    localStorage.setItem('cmms_system_name', name);
    updateBrowserTitle(name, titleBadge);
  };

  const setChurchLogoUrl = (url: string) => {
    setChurchLogoUrlState(url);
    localStorage.setItem('cmms_church_logo', url);
  };

  const setDarkLogoUrl = (url: string) => {
    setDarkLogoUrlState(url);
    localStorage.setItem('cmms_dark_logo', url);
  };

  const updateBranding = (name: string, lightLogo: string, darkLogo?: string, favicon?: string) => {
    setSystemName(name);
    setChurchLogoUrl(lightLogo);
    if (darkLogo !== undefined) {
      setDarkLogoUrl(darkLogo);
    }
    if (favicon) {
      setFaviconUrl(favicon);
    }
    addAuditLog('Updated Branding Settings', 'System Settings', `Updated system name to "${name}"`);
  };

  const updateFullBranding = async (updates: {
    systemName?: string;
    churchName?: string;
    titleBadge?: string;
    churchMotto?: string;
    faviconUrl?: string;
    churchLogoUrl?: string;
    darkLogoUrl?: string;
    primaryColorHex?: string;
    accentColorHex?: string;
    loginPanelColorHex?: string;
    defaultThemeMode?: 'light' | 'dark' | 'advanced-dark' | 'system';
  }) => {
    if (updates.systemName) setSystemName(updates.systemName);
    if (updates.churchName) setChurchName(updates.churchName);
    if (updates.titleBadge) setTitleBadge(updates.titleBadge);
    if (updates.churchMotto) setChurchMotto(updates.churchMotto);
    if (updates.faviconUrl) setFaviconUrl(updates.faviconUrl);
    if (updates.churchLogoUrl !== undefined) setChurchLogoUrl(updates.churchLogoUrl);
    if (updates.darkLogoUrl !== undefined) setDarkLogoUrl(updates.darkLogoUrl);
    if (updates.primaryColorHex) setPrimaryColorHex(updates.primaryColorHex);
    if (updates.accentColorHex) setAccentColorHex(updates.accentColorHex);
    if (updates.loginPanelColorHex) setLoginPanelColorHex(updates.loginPanelColorHex);
    if (updates.defaultThemeMode) setThemeMode(updates.defaultThemeMode);

    try {
      await apiService.updateBranding(updates);
    } catch (err) {
      console.warn('[Branding] Backend branding update warning:', err);
    }

    addAuditLog('Updated Sovereign Branding & Favicon', 'Super Admin Settings', `Customized church system identity`);
  };

  // Synchronize live system branding from backend on initial mount
  React.useEffect(() => {
    fetch('/api/system/branding')
      .then((res) => (res.ok ? res.json() : null))
      .then((b) => {
        if (b) {
          if (b.churchName) setChurchNameState(b.churchName);
          if (b.systemName) setSystemNameState(b.systemName);
          if (b.titleBadge) setTitleBadgeState(b.titleBadge);
          if (b.churchMotto) setChurchMottoState(b.churchMotto);
          if (b.churchLogoUrl !== undefined) setChurchLogoUrlState(b.churchLogoUrl);
          if (b.darkLogoUrl !== undefined) setDarkLogoUrlState(b.darkLogoUrl);
          if (b.faviconUrl) setFaviconUrlState(b.faviconUrl);
          if (b.primaryColorHex) {
            setPrimaryColorHexState(b.primaryColorHex);
            localStorage.setItem('cmms_primary_color', b.primaryColorHex);
          }
          if (b.accentColorHex) {
            setAccentColorHexState(b.accentColorHex);
            localStorage.setItem('cmms_accent_color', b.accentColorHex);
          }
          if (b.loginPanelColorHex) {
            setLoginPanelColorHexState(b.loginPanelColorHex);
            localStorage.setItem('cmms_login_panel_color', b.loginPanelColorHex);
          }
        }
      })
      .catch((err) => console.info('[Branding] Initial fetch notice:', err));
  }, []);

  // Sync favicon and document title on initial mount & updates
  React.useEffect(() => {
    updateBrowserFavicon(faviconUrl);
    updateBrowserTitle(systemName, titleBadge);
  }, [faviconUrl, systemName, titleBadge]);

  const updateUserProfilePhoto = (photoUrl: string) => {
    if (currentUser) {
      setCurrentUser({ ...currentUser, photoUrl });
      addAuditLog('Updated Profile Photo', 'User Profile', 'Uploaded new avatar photo from device');
    }
  };

  const { language: langCode, setLanguage: setUnifiedLanguage, t: unifiedT, fontClass, isEthiopic } = useTranslation();
  const language = CODE_TO_NAME[langCode] || 'English';
  const setLanguage = useCallback((lang: string) => {
    setUnifiedLanguage(lang as SupportedLanguage);
  }, [setUnifiedLanguage]);
  const t = useCallback((key: string, fallbackOrParams?: string | Record<string, string | number>, maybeFallback?: string) => {
    return unifiedT(key, fallbackOrParams, maybeFallback);
  }, [unifiedT]);

  const [currency, setCurrency] = useState<'USD' | 'ETB' | 'EUR' | 'GBP'>('USD');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const toggleSidebar = () => setIsSidebarCollapsed((prev) => !prev);

  React.useEffect(() => {
    document.title = systemName && !systemName.includes('Grace Cathedral') ? `${systemName} — Dashboard` : 'CMMS Dashboard';
  }, [systemName]);

  // Document Categories state
  const [documentCategories, setDocumentCategories] = useState<string[]>([
    'Sermon Outlines & Media',
    'Board Meeting Minutes',
    'Church Policies & Handbooks',
    'Financial Statements',
    'Legal & Registration',
    'Training Materials',
  ]);

  // State collections
  const [branches, setBranches] = useState<Branch[]>(initialBranches);
  const [members, setMembers] = useState<Member[]>(initialMembers);
  const [families, setFamilies] = useState<Family[]>(initialFamilies);
  const [ministries, setMinistries] = useState<Ministry[]>(initialMinistries);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(initialAttendanceRecords);
  
  // Real-time Active Attendance Sessions
  const [attendanceSessions, setAttendanceSessions] = useState<AttendanceSession[]>(() => {
    try {
      const stored = localStorage.getItem('cmms_attendance_sessions');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to parse cached attendance sessions', e);
    }
    return initialAttendanceSessions;
  });

  // Sync sessions across tabs and localStorage
  useEffect(() => {
    try {
      localStorage.setItem('cmms_attendance_sessions', JSON.stringify(attendanceSessions));
    } catch (e) {
      console.warn('Failed to cache attendance sessions', e);
    }
  }, [attendanceSessions]);

  // Listen for storage events or custom broadcast events across windows/tabs
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'cmms_attendance_sessions' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) {
            setAttendanceSessions(parsed);
          }
        } catch {}
      }
    };
    const handleCustomSync = (e: any) => {
      if (e.detail?.sessions) {
        setAttendanceSessions(e.detail.sessions);
      }
    };
    window.addEventListener('storage', handleStorage);
    window.addEventListener('cmms_attendance_session_broadcast', handleCustomSync as EventListener);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('cmms_attendance_session_broadcast', handleCustomSync as EventListener);
    };
  }, []);

  const activeAttendanceSessions = useMemo(() => {
    return attendanceSessions.filter((s) => s.status === 'active');
  }, [attendanceSessions]);

  const broadcastSessions = (updated: AttendanceSession[]) => {
    try {
      localStorage.setItem('cmms_attendance_sessions', JSON.stringify(updated));
      window.dispatchEvent(
        new CustomEvent('cmms_attendance_session_broadcast', { detail: { sessions: updated } })
      );
    } catch {}
  };

  const activateAttendanceSession = (payload: {
    groupId: string;
    groupName?: string;
    branchId?: string;
    leaderId?: string;
    leaderName?: string;
    type: 'instant' | 'scheduled';
    title: string;
    serviceType?: string;
    location?: string;
  }): AttendanceSession => {
    const sessionUniqueId = `att_${Date.now().toString().slice(-6)}`;
    const dynamicToken = `jwt_${sessionUniqueId}_${Math.random().toString(36).substring(2, 10)}`;
    const newSession: AttendanceSession = {
      id: `session-${Date.now()}`,
      sessionId: sessionUniqueId,
      groupId: payload.groupId,
      groupName: payload.groupName || ministries.find((m) => m.id === payload.groupId)?.name || 'General Fellowship',
      branchId: payload.branchId || selectedBranchId || 'br-001',
      leaderId: payload.leaderId || currentUser?.memberId || 'mem-101',
      leaderName: payload.leaderName || currentUser?.name || 'Group Leader',
      type: payload.type,
      title: payload.title,
      serviceType: payload.serviceType || 'Ministry Attendance',
      status: 'active',
      startTime: new Date().toISOString(),
      endTime: null,
      qrPayloadToken: dynamicToken,
      location: payload.location || 'Church Main Campus',
      attendeeCount: 0,
    };

    setAttendanceSessions((prev) => {
      const updated = [newSession, ...prev];
      broadcastSessions(updated);
      return updated;
    });

    addAuditLog(
      'Activated Attendance Session',
      'Attendance Management',
      `Leader started ${payload.type} session "${payload.title}" (Session ID: ${sessionUniqueId})`
    );

    return newSession;
  };

  const closeAttendanceSession = (sessionId: string) => {
    setAttendanceSessions((prev) => {
      const updated = prev.map((s) =>
        s.sessionId === sessionId || s.id === sessionId
          ? { ...s, status: 'closed' as const, endTime: new Date().toISOString() }
          : s
      );
      broadcastSessions(updated);
      return updated;
    });

    addAuditLog(
      'Closed Attendance Session',
      'Attendance Management',
      `Session ID ${sessionId} marked as closed.`
    );
  };

  const rotateSessionToken = (sessionId: string): string => {
    const nextToken = `jwt_${sessionId}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    setAttendanceSessions((prev) => {
      const updated = prev.map((s) =>
        s.sessionId === sessionId || s.id === sessionId
          ? { ...s, qrPayloadToken: nextToken }
          : s
      );
      broadcastSessions(updated);
      return updated;
    });
    return nextToken;
  };

  const checkInToSession = async (params: {
    sessionId: string;
    checkInType?: 'qr' | 'manual' | 'Manual Web Click' | 'QR Code Scanning';
    memberId?: string;
    memberName?: string;
    token?: string;
  }): Promise<{ success: boolean; message: string; record?: AttendanceRecord }> => {
    const session = attendanceSessions.find(
      (s) => (s.sessionId === params.sessionId || s.id === params.sessionId) && s.status === 'active'
    );

    if (!session) {
      return { success: false, message: 'Active session not found or already closed by leader.' };
    }

    const effectiveMemberId = params.memberId || currentUser?.memberId || members[0]?.id || 'mem-101';
    const targetMember = members.find((m) => m.id === effectiveMemberId);
    const effectiveMemberName =
      params.memberName ||
      (targetMember ? `${targetMember.firstName} ${targetMember.lastName}` : currentUser?.name || 'Verified Member');

    const checkInMethod =
      params.checkInType === 'qr' || params.checkInType === 'QR Code Scanning'
        ? 'QR Code Scanning'
        : 'Manual Web Click';

    const normalizedCheckInType = params.checkInType === 'qr' || params.checkInType === 'QR Code Scanning' ? 'qr' : 'manual';

    const newRecord: AttendanceRecord = {
      id: `rec-${Date.now()}`,
      recordId: `rec_${Date.now().toString().slice(-6)}`,
      sessionId: session.sessionId,
      serviceName: session.title,
      eventName: session.title,
      serviceType: session.serviceType || 'Ministry Attendance',
      branchId: session.branchId || 'br-001',
      date: new Date().toISOString().substring(0, 10),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      memberId: effectiveMemberId,
      memberName: effectiveMemberName,
      checkInTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      checkedInTime: new Date().toISOString(),
      checkInType: normalizedCheckInType,
      checkInMethod: checkInMethod,
      status: 'Present',
      notes: `Checked into ${session.title} via ${checkInMethod}`,
    };

    // Prevent duplicate check-in to same session for same member
    const alreadyCheckedIn = attendanceRecords.some(
      (r) => (r.sessionId === session.sessionId || r.serviceName === session.title) && r.memberId === effectiveMemberId && r.date === newRecord.date
    );

    if (alreadyCheckedIn) {
      return {
        success: true,
        message: `Already checked into "${session.title}" today!`,
        record: newRecord,
      };
    }

    setAttendanceRecords((prev) => [newRecord, ...prev]);

    // Increment attendeeCount on the session
    setAttendanceSessions((prev) => {
      const updated = prev.map((s) =>
        s.sessionId === session.sessionId
          ? { ...s, attendeeCount: (s.attendeeCount || 0) + 1 }
          : s
      );
      broadcastSessions(updated);
      return updated;
    });

    addAuditLog(
      'Session Check-In Recorded',
      'Attendance Management',
      `${effectiveMemberName} (${effectiveMemberId}) checked into session "${session.title}" via ${checkInMethod}`
    );

    // Call Supabase / Backend integration
    apiService.recordAttendance(newRecord).catch((e) => console.warn('Backend record attendance note:', e));

    return {
      success: true,
      message: `Successfully checked in to "${session.title}"!`,
      record: newRecord,
    };
  };
  const [events, setEvents] = useState<EventItem[]>(initialEvents);
  const [communications, setCommunications] = useState<CommunicationMessage[]>(initialCommunications);
  const [communicationLogs, setCommunicationLogs] = useState<CommunicationLog[]>([]);
  const [communicationStatus, setCommunicationStatus] = useState<CommunicationSystemStatus | null>(null);
  const [prayerRequests, setPrayerRequests] = useState<PrayerRequest[]>(initialPrayerRequests);
  const [counselingSessions, setCounselingSessions] = useState<CounselingSession[]>(initialCounselingSessions);
  const [visitations, setVisitations] = useState<VisitationRecord[]>(initialVisitations);
  const [volunteerShifts, setVolunteerShifts] = useState<VolunteerShift[]>(initialVolunteerShifts);
  const [assets, setAssets] = useState<Asset[]>(initialAssets);
  const [documents, setDocuments] = useState<DocumentItem[]>(initialDocuments);
  const [courses, setCourses] = useState<LmsCourse[]>(initialCourses);
  const [workflows, setWorkflows] = useState<WorkflowRequest[]>(initialWorkflows);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(initialAuditLogs);
  const [systemUsers, setSystemUsers] = useState<SystemUser[]>(initialSystemUsers);

  // Re-fetch PostgreSQL-backed system state and the dedicated membership queue.
  // The membership queue is read independently so it cannot disappear when a
  // legacy/general workflow snapshot is stale or partially populated.
  const reloadFromBackend = async () => {
    let state: any = null;
    try {
      state = await apiService.fetchSystemState();
    } catch (err) {
      console.warn('[CMMS] system state refresh failed:', err);
    }

    if (state) {
      if (Array.isArray(state.branches)) setBranches(state.branches);
      if (Array.isArray(state.members)) setMembers(state.members);
      if (Array.isArray(state.families)) setFamilies(state.families);
      if (Array.isArray(state.ministries)) setMinistries(state.ministries);
      if (Array.isArray(state.attendanceRecords)) setAttendanceRecords(state.attendanceRecords);
      if (Array.isArray(state.events)) setEvents(state.events);
      if (Array.isArray(state.communications)) setCommunications(state.communications);
      if (Array.isArray(state.communicationLogs)) setCommunicationLogs(state.communicationLogs);
      if (Array.isArray(state.prayerRequests)) setPrayerRequests(state.prayerRequests);
      if (Array.isArray(state.counselingSessions)) setCounselingSessions(state.counselingSessions);
      if (Array.isArray(state.visitations)) setVisitations(state.visitations);
      if (Array.isArray(state.volunteerShifts)) setVolunteerShifts(state.volunteerShifts);
      if (Array.isArray(state.assets)) setAssets(state.assets);
      if (Array.isArray(state.documents)) setDocuments(state.documents);
      if (Array.isArray(state.courses)) setCourses(state.courses);
      if (Array.isArray(state.workflows)) setWorkflows(state.workflows);
      if (Array.isArray((state as any).profileChangeRequests)) setProfileChangeRequests((state as any).profileChangeRequests);
      if (Array.isArray(state.auditLogs)) {
        const seen = new Set<string>();
        const dedupedLogs = state.auditLogs.map((log, idx) => {
          let logId = log.id || `log-${Date.now()}-${idx}`;
          if (seen.has(logId)) logId = `${logId}-${idx}-${Math.random().toString(36).substring(2, 6)}`;
          seen.add(logId);
          return { ...log, id: logId };
        });
        setAuditLogs(dedupedLogs);
      }
      if (Array.isArray(state.systemUsers)) setSystemUsers(state.systemUsers);
    }

    // Dedicated PostgreSQL repositories are authoritative for member and branch lists.
    const [databaseMembers, databaseBranches] = await Promise.allSettled([
      apiService.getMembers(),
      apiService.getBranches(),
    ]);
    if (databaseMembers.status === 'fulfilled' && Array.isArray(databaseMembers.value)) setMembers(databaseMembers.value);
    else if (databaseMembers.status === 'rejected') console.warn('[CMMS] PostgreSQL member reload failed:', databaseMembers.reason);
    if (databaseBranches.status === 'fulfilled' && Array.isArray(databaseBranches.value)) setBranches(databaseBranches.value);
    else if (databaseBranches.status === 'rejected') console.warn('[CMMS] PostgreSQL branch reload failed:', databaseBranches.reason);

    try {
      const approvalQueue = await apiService.getMembershipApprovals();
      if (Array.isArray(approvalQueue?.workflows)) {
        setWorkflows((current) => [
          ...current.filter((workflow) => workflow.requestType !== 'Membership Application'),
          ...approvalQueue.workflows,
        ]);
      }
    } catch (err) {
      console.warn('[CMMS] membership approval queue refresh failed:', err);
    }
  };

  // Initial load from backend API - strictly guarded by authentication status
  React.useEffect(() => {
    if (!isAuthenticated) return;
    reloadFromBackend();
  }, [isAuthenticated]);

  const userAdditionalRoles = useMemo<UserRole[]>(() => {
    const raw = (userProfile as any)?.additionalRoles || (userProfile as any)?.additional_roles || [];
    if (!Array.isArray(raw)) return [];
    return raw.map((r: string) => normalizeUserRole(r)).filter((r: UserRole) => r !== normalizeUserRole(activeRole));
  }, [userProfile, activeRole]);

  const permissions = useMemo(
    () => getRolePermissions(activeRole, userAdditionalRoles),
    [activeRole, userAdditionalRoles]
  );

  const deleteFamily = (id: string) => {
    const target = families.find((f) => f.id === id);
    setFamilies((prev) => prev.filter((f) => f.id !== id));
    addAuditLog('Deleted Household', 'Family Management', `Deleted family ${target?.householdName || id}`);
  };

  const updateBranch = (b: Branch) => {
    setBranches((prev) => prev.map((item) => (item.id === b.id ? b : item)));
    addAuditLog('Updated Branch', 'Branch Management', `Updated campus details for ${b.name}`);
  };

  const deleteBranch = (id: string) => {
    const target = branches.find((b) => b.id === id);
    setBranches((prev) => prev.filter((b) => b.id !== id));
    addAuditLog('Deleted Branch', 'Branch Management', `Removed branch campus ${target?.name || id}`);
  };

  const swapMemberBranch = (memberId: string, newBranchId: string) => {
    setMembers((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, branchId: newBranchId } : m))
    );
    addAuditLog('Swapped Member Branch', 'Branch Management', `Transferred member ${memberId} to branch ${newBranchId}`);
  };

  const removeMemberFromBranch = (memberId: string) => {
    setMembers((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, branchId: '' } : m))
    );
    addAuditLog('Removed Member From Branch', 'Branch Management', `Unassigned member ${memberId} from branch`);
  };

  const refreshMinistries = useCallback(async (): Promise<Ministry[]> => {
    try {
      const serverMinistries = await apiService.getMinistries();
      if (Array.isArray(serverMinistries)) {
        setMinistries(serverMinistries);
        return serverMinistries;
      }
      return ministries;
    } catch (err) {
      console.warn('[CMMS] Failed to refresh ministries from backend:', err);
      throw err;
    }
  }, [ministries]);

  const addMinistry = async (m: Partial<Ministry>): Promise<Ministry> => {
    // 1. Authoritative backend database commit
    const saved = await apiService.createMinistry(m as Ministry);
    if (!saved || !saved.id) {
      throw new Error('Database failed to return saved ministry record.');
    }
    // 2. Synchronize local state with the actual saved database record
    setMinistries((prev) => [saved, ...prev.filter((item) => item.id !== saved.id)]);
    addAuditLog('Established Ministry', 'Ministry Management', `Created ministry ${saved.name}`);
    return saved;
  };

  const updateMinistry = async (m: Ministry): Promise<Ministry> => {
    // 1. Authoritative backend update
    const updated = await apiService.updateMinistry(m);
    // 2. Synchronize local state with saved response
    setMinistries((prev) => prev.map((item) => (item.id === m.id ? (updated || m) : item)));
    addAuditLog('Updated Ministry', 'Ministry Management', `Updated ministry details for ${m.name}`);
    return updated || m;
  };

  const deleteMinistry = async (id: string): Promise<boolean> => {
    const target = ministries.find((m) => m.id === id);
    // 1. Delete on backend database
    await apiService.deleteMinistry(id);
    // 2. Synchronize local state
    setMinistries((prev) => prev.filter((m) => m.id !== id));
    addAuditLog('Deleted Ministry', 'Ministry Management', `Removed ministry ${target?.name || id}`);
    return true;
  };

  const removeMemberFromMinistry = (memberId: string, ministryId: string) => {
    setMembers((prev) =>
      prev.map((m) =>
        m.id === memberId
          ? { ...m, ministryIds: m.ministryIds.filter((mid) => mid !== ministryId) }
          : m
      )
    );
    addAuditLog('Removed Member from Ministry', 'Ministry Management', `Removed member ${memberId} from ministry ${ministryId}`);
  };

  const deleteSubMinistry = async (ministryId: string, subMinistryId: string): Promise<void> => {
    await apiService.deleteSubMinistry(ministryId, subMinistryId);
    setMinistries((prev) =>
      prev.map((m) =>
        m.id === ministryId
          ? { ...m, subMinistries: m.subMinistries?.filter((sub) => sub.id !== subMinistryId) }
          : m
      )
    );
    addAuditLog('Deleted Sub-Ministry', 'Ministry Management', `Deleted sub-ministry ${subMinistryId} from ${ministryId}`);
  };

  const bulkImportAttendance = (records: AttendanceRecord[]) => {
    setAttendanceRecords((prev) => [...records, ...prev]);
    addAuditLog('Bulk Imported Attendance', 'Attendance Management', `Bulk imported ${records.length} attendance records`);
  };

  const addDocumentCategory = (catName: string) => {
    if (!documentCategories.includes(catName)) {
      setDocumentCategories((prev) => [...prev, catName]);
      addAuditLog('Added Custom Document Category', 'Document Vault', `Added category ${catName}`);
    }
  };

  const deleteDocumentCategory = (catName: string) => {
    setDocumentCategories((prev) => prev.filter((c) => c !== catName));
    addAuditLog('Deleted Document Category', 'Document Vault', `Removed document category ${catName}`);
  };

  const updateUserRole = (userId: string, newRole: UserRole) => {
    setSystemUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, role: newRole } : u))
    );
    addAuditLog('Updated User Role', 'Super Admin Security', `Changed role for user ${userId} to ${newRole}`);
    apiService.updateUserRole(userId, newRole).catch((err) => {
      console.warn('Failed to persist role update to backend:', err);
    });
  };

  const toggleUserMfa = (userId: string, enabled?: boolean) => {
    const target = systemUsers.find((u) => u.id === userId);
    const nextEnabled = enabled !== undefined ? enabled : target?.mfaEnabled === false;
    setSystemUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, mfaEnabled: nextEnabled, isMfaEnabled: nextEnabled } : u))
    );
    addAuditLog('Toggled User MFA', '2FA Security', `Toggled MFA status for user ${userId}`);
    apiService.toggleMfa(userId, nextEnabled).catch((err) => {
      console.warn('Failed to persist MFA toggle to backend:', err);
    });
  };

  const addCourse = (course: LmsCourse) => {
    setCourses((prev) => [course, ...prev]);
    addAuditLog('Created Course', 'Discipleship LMS', `Added course ${course.title} (${course.courseCode})`);
  };

  const updateCourse = (course: LmsCourse) => {
    setCourses((prev) => prev.map((c) => (c.id === course.id ? course : c)));
    addAuditLog('Updated Course', 'Discipleship LMS', `Updated course ${course.title}`);
  };

  const deleteCourse = (id: string) => {
    const target = courses.find((c) => c.id === id);
    setCourses((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('Deleted Course', 'Discipleship LMS', `Deleted course ${target?.title || id}`);
  };

  const addAuditLog = (action: string, moduleName: string, details: string, commitData?: string, location?: string) => {
    const uniqueId = `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}-${Math.floor(Math.random() * 1000)}`;
    const newLog: AuditLog = {
      id: uniqueId,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userEmail: currentUser?.email || 'admin@gracecathedral.org',
      userName: currentUser?.name || 'Administrator',
      userRole: currentUser?.role || activeRole,
      action,
      module: moduleName,
      ipAddress: '197.156.103.42',
      location: location || 'Addis Ababa, Bole (HQ Campus Terminal)',
      details,
      commitData: commitData || `{"module": "${moduleName}", "action": "${action}", "timestamp": "${new Date().toISOString()}"}`,
      device: 'MacBook Pro / Chrome (Desktop Terminal)',
    };
    setAuditLogs((prev) => [newLog, ...prev.filter((l) => l.id !== uniqueId)]);
  };

  const addSystemUser = (user: SystemUser) => {
    setSystemUsers((prev) => [user, ...prev]);
    addAuditLog('Created System User', 'User Management', `Added system user ${user.name} (${user.email}) as ${user.role}`);
  };

  const updateSystemUser = (updatedUser: SystemUser) => {
    setSystemUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );
    addAuditLog(
      'Updated System User & Access',
      'User Management & RBAC',
      `Updated user ${updatedUser.name} (${updatedUser.email}) - Role: ${updatedUser.role}, Tier: ${updatedUser.approvalRoleLevel || 'Standard'}`
    );
  };

  const removeSystemUser = (id: string) => {
    const target = systemUsers.find((u) => u.id === id);
    setSystemUsers((prev) => prev.filter((u) => u.id !== id));
    addAuditLog('Removed System User', 'User Management', `Removed system user ${target?.name || id}`);
    apiService.deleteUser(id).catch((err) => {
      console.warn('Failed to delete user on backend:', err);
    });
  };

  const resetUserPassword = (id: string, newPassword?: string) => {
    const target = systemUsers.find((u) => u.id === id);
    addAuditLog('Reset User Password', 'User Management', `Triggered password reset for user ${target?.name || id}`);
  };

  const exportSystemBackupJSON = (): string => {
    // Trigger real server-side snapshot creation and download
    apiService.triggerServerBackup('Full System').catch((err) => {
      console.warn('Server-side backup trigger error:', err);
    });

    // Also construct client representation for instant synchronous returns
    const backupObj = {
      version: '5.0',
      exportDate: new Date().toISOString(),
      branches,
      members,
      families,
      ministries,
      attendanceRecords,
      attendanceSessions,
      events,
      communications,
      prayerRequests,
      counselingSessions,
      visitations,
      volunteerShifts,
      assets,
      documents,
      documentCategories,
      courses,
      workflows,
      auditLogs,
      systemUsers,
      branding: {
        churchName,
        systemName,
        titleBadge,
        churchMotto,
        faviconUrl,
        churchLogoUrl,
        darkLogoUrl,
        primaryColorHex,
        accentColorHex,
        headquartersAddress: '',
        contactPhone: '',
        contactEmail: '',
        taxIdNumber: '',
      },
    };
    addAuditLog('Exported System Backup', 'Settings & System', 'Generated full JSON system database backup snapshot');
    return JSON.stringify(backupObj, null, 2);
  };

  const restoreSystemBackupJSON = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      // Synchronously patch local React state for instantaneous UI response
      if (data.members && Array.isArray(data.members)) setMembers(data.members);
      if (data.families && Array.isArray(data.families)) setFamilies(data.families);
      if (data.branches && Array.isArray(data.branches)) setBranches(data.branches);
      if (data.ministries && Array.isArray(data.ministries)) setMinistries(data.ministries);
      if (data.attendanceRecords && Array.isArray(data.attendanceRecords)) setAttendanceRecords(data.attendanceRecords);
      if (data.events && Array.isArray(data.events)) setEvents(data.events);
      if (data.communications && Array.isArray(data.communications)) setCommunications(data.communications);
      if (data.prayerRequests && Array.isArray(data.prayerRequests)) setPrayerRequests(data.prayerRequests);
      if (data.counselingSessions && Array.isArray(data.counselingSessions)) setCounselingSessions(data.counselingSessions);
      if (data.visitations && Array.isArray(data.visitations)) setVisitations(data.visitations);
      if (data.volunteerShifts && Array.isArray(data.volunteerShifts)) setVolunteerShifts(data.volunteerShifts);
      if (data.assets && Array.isArray(data.assets)) setAssets(data.assets);
      if (data.documents && Array.isArray(data.documents)) setDocuments(data.documents);
      if (data.courses && Array.isArray(data.courses)) setCourses(data.courses);
      if (data.workflows && Array.isArray(data.workflows)) setWorkflows(data.workflows);
      if (data.systemUsers && Array.isArray(data.systemUsers)) setSystemUsers(data.systemUsers);
      if (data.auditLogs && Array.isArray(data.auditLogs)) setAuditLogs(data.auditLogs);

      // Persist real server-side restore
      apiService.restoreServerBackup(data, true)
        .then(() => reloadFromBackend())
        .catch((err) => console.error('Failed to apply server restore:', err));

      addAuditLog('Restored System Backup', 'Settings & System', 'Successfully imported and restored system database from backup');
      return true;
    } catch (e) {
      console.error('Backup restore error:', e);
      return false;
    }
  };

  const resetToDefaultData = () => {
    // Send real server reset command
    apiService.resetServerDatabase(true)
      .then(() => reloadFromBackend())
      .catch((err) => console.error('Failed to reset server database:', err));

    setBranches(initialBranches);
    setMembers(initialMembers);
    setFamilies(initialFamilies);
    setMinistries(initialMinistries);
    setAttendanceRecords(initialAttendanceRecords);
    setEvents(initialEvents);
    setCommunications(initialCommunications);
    setPrayerRequests(initialPrayerRequests);
    setCounselingSessions(initialCounselingSessions);
    setVisitations(initialVisitations);
    setVolunteerShifts(initialVolunteerShifts);
    setAssets(initialAssets);
    setDocuments(initialDocuments);
    setWorkflows(initialWorkflows);
    setAuditLogs(initialAuditLogs);
    setSystemUsers(initialSystemUsers);
    addAuditLog('Factory Reset', 'Settings & System', 'Reset system data to initial factory defaults');
  };

  const setActiveRole = (role: UserRole) => {
    setActiveRoleState(role);
    try {
      localStorage.setItem('cmms_active_role', role);
      sessionStorage.setItem('cmms_active_role', role);
    } catch {}
    addAuditLog('Switched Role', 'Security & RBAC', `Switched active role to ${role}`);
  };

  const addMember = async (m: Member): Promise<Member> => {
    // Do not report success or expose a locally-created member until the backend confirms persistence.
    // This prevents account provisioning from succeeding while the member record silently fails.
    const savedMember = await apiService.createMember(m);
    if (!savedMember?.id) throw new Error('The database did not return the saved member record.');
    // Refresh from PostgreSQL so the list uses the exact persisted row and
    // database-generated identifiers rather than a locally constructed object.
    try {
      const persistedMembers = await apiService.getMembers();
      setMembers(persistedMembers);
    } catch (refreshError) {
      console.warn('[CMMS] Member was saved; list refresh will retry on next reload:', refreshError);
      setMembers((prev) => [savedMember, ...prev.filter((item) => item.id !== savedMember.id)]);
    }
    addAuditLog(
      'Created Member',
      'Member Management',
      `Added new member ${savedMember.firstName} ${savedMember.lastName} (${savedMember.memberIdNumber || savedMember.id})`
    );
    return savedMember;
  };

  const updateMember = async (m: Member): Promise<Member> => {
    const savedMember = await apiService.updateMember(m);
    if (!savedMember?.id) throw new Error('The database did not confirm the member update.');
    setMembers((prev) => prev.map((item) => (item.id === savedMember.id ? savedMember : item)));
    addAuditLog('Updated Member', 'Member Management', `Updated profile for ${savedMember.firstName} ${savedMember.lastName}`);
    return savedMember;
  };

  const deleteMember = (id: string) => {
    const target = members.find((m) => m.id === id);
    setMembers((prev) => prev.filter((item) => item.id !== id));
    addAuditLog('Archived Member', 'Member Management', `Archived member ID ${target?.memberIdNumber || id}`);
    apiService.deleteMember(id).catch((e) => console.warn('Failed to delete member on backend:', e));
  };

  const addFamily = (f: Family) => {
    setFamilies((prev) => [f, ...prev]);
    addAuditLog('Registered Household', 'Family Management', `Added family household ${f.householdName}`);
    apiService.createFamily(f).catch((e) => console.warn('Failed to sync family to backend:', e));
  };

  const updateFamily = (f: Family) => {
    setFamilies((prev) => prev.map((item) => (item.id === f.id ? f : item)));
    addAuditLog('Updated Family', 'Family Management', `Updated relationships for ${f.householdName}`);
    apiService.updateFamily(f).catch((e) => console.warn('Failed to update family on backend:', e));
  };

  const addBranch = (b: Branch) => {
    setBranches((prev) => [...prev, b]);
    addAuditLog('Created Branch', 'Branch Management', `Established new campus ${b.name}`);
    apiService.createBranch(b).catch((e) => console.warn('Failed to sync branch to backend:', e));
  };

  const recordAttendance = (rec: AttendanceRecord) => {
    setAttendanceRecords((prev) => [rec, ...prev]);
    addAuditLog('Recorded Attendance', 'Attendance Management', `Check-in for member ID ${rec.memberId} via ${rec.checkInMethod}`);
    apiService.recordAttendance(rec).catch((e) => console.warn('Failed to sync attendance to backend:', e));
  };

  const addEvent = (evt: EventItem) => {
    setEvents((prev) => [evt, ...prev]);
    addAuditLog('Created Event', 'Event Management', `Scheduled event ${evt.title}`);
    apiService.createEvent(evt).catch((e) => console.warn('Failed to sync event to backend:', e));
  };

  const sendCommunication = (comm: CommunicationMessage) => {
    setCommunications((prev) => [comm, ...prev]);
    addAuditLog('Broadcast Message', 'Communications', `Sent ${comm.channel} campaign: ${comm.subject}`);
    apiService.sendCommunication(comm).catch((e) => console.warn('Failed to sync communication to backend:', e));
  };

  const refreshCommunicationLogs = useCallback(async () => {
    try {
      const [logsRes, statusRes] = await Promise.all([
        apiService.getCommunicationLogs({ limit: 500 }).catch(() => null),
        apiService.getCommunicationStatus().catch(() => null),
      ]);
      if (logsRes && Array.isArray(logsRes.logs)) {
        setCommunicationLogs(logsRes.logs);
      }
      if (statusRes && statusRes.sms && statusRes.email) {
        setCommunicationStatus({ sms: statusRes.sms, email: statusRes.email });
      }
    } catch (e) {
      console.warn('Failed to refresh communication logs:', e);
    }
  }, []);

  const sendSms = async (payload: {
    recipient?: string;
    recipients?: (string | { phone?: string; memberId?: string; familyId?: string; name?: string })[];
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    subject?: string;
    message: string;
    triggerType?: string;
  }) => {
    const res = await apiService.sendSms(payload);
    if (res.logs && Array.isArray(res.logs)) {
      setCommunicationLogs((prev) => [...res.logs, ...prev]);
    } else if (res.log) {
      setCommunicationLogs((prev) => [res.log, ...prev]);
    }
    if (res.communication) {
      setCommunications((prev) => [res.communication!, ...prev]);
    }
    return res;
  };

  const sendEmail = async (payload: {
    recipient?: string;
    recipients?: (string | { email?: string; memberId?: string; familyId?: string; name?: string })[];
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    subject: string;
    message: string;
    html?: string;
    triggerType?: string;
  }) => {
    const res = await apiService.sendEmail(payload);
    if (res.logs && Array.isArray(res.logs)) {
      setCommunicationLogs((prev) => [...res.logs, ...prev]);
    } else if (res.log) {
      setCommunicationLogs((prev) => [res.log, ...prev]);
    }
    if (res.communication) {
      setCommunications((prev) => [res.communication!, ...prev]);
    }
    return res;
  };

  const sendBroadcast = async (payload: {
    channel: 'SMS' | 'EMAIL' | 'BOTH' | 'Multi-Channel';
    targetType: 'all_active' | 'branch' | 'ministry' | 'family' | 'custom_members';
    branchId?: string;
    ministryId?: string;
    familyId?: string;
    memberIds?: string[];
    subject?: string;
    message: string;
    triggerType?: string;
  }) => {
    const res = await apiService.sendBroadcast(payload);
    if (res.logs && Array.isArray(res.logs)) {
      setCommunicationLogs((prev) => [...res.logs, ...prev]);
    }
    if (res.communication) {
      setCommunications((prev) => [res.communication, ...prev]);
    }
    return res;
  };

  const retryCommunicationLog = async (id: string) => {
    const res = await apiService.retryCommunicationLog(id);
    if (res.log) {
      setCommunicationLogs((prev) =>
        prev.map((l) => (l.id === id ? res.log : l))
      );
    }
    return res;
  };

  const addPrayerRequest = (req: PrayerRequest) => {
    setPrayerRequests((prev) => [req, ...prev]);
    addAuditLog('Submitted Prayer Request', 'Prayer Ministry', `Added request #${req.requestNumber}: ${req.title}`);
    apiService.createPrayerRequest(req).catch((e) => console.warn('Failed to sync prayer request to backend:', e));
  };

  const updatePrayerStatus = (id: string, status: PrayerRequest['status'], notes?: string) => {
    setPrayerRequests((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status, testimonyNotes: notes || item.testimonyNotes } : item
      )
    );
    addAuditLog('Updated Prayer Request', 'Prayer Ministry', `Updated prayer request status to ${status}`);
    apiService.updatePrayerStatus(id, status, notes).catch((e) => console.warn('Failed to update prayer status on backend:', e));
  };

  const addCounselingSession = (session: CounselingSession) => {
    setCounselingSessions((prev) => [session, ...prev]);
    addAuditLog('Scheduled Counseling', 'Counseling Ministry', `Booked ${session.counselingType} counseling for ${session.clientName}`);
    apiService.createCounselingSession(session).catch((e) => console.warn('Failed to sync counseling session to backend:', e));
  };

  const addVisitationRecord = (record: VisitationRecord) => {
    setVisitations((prev) => [record, ...prev]);
    addAuditLog('Logged Pastoral Visit', 'Visitation & Care', `Completed ${record.visitationType} visit for ${record.memberName}`);
    apiService.createVisitation(record).catch((e) => console.warn('Failed to sync visitation record to backend:', e));
  };

  const addVolunteerShift = (shift: VolunteerShift) => {
    setVolunteerShifts((prev) => [shift, ...prev]);
    addAuditLog('Assigned Volunteer Shift', 'Volunteers', `Scheduled ${shift.volunteerName} for ${shift.roleTitle}`);
    apiService.createVolunteerShift(shift).catch((e) => console.warn('Failed to sync volunteer shift to backend:', e));
  };

  const addAsset = (asset: Asset) => {
    setAssets((prev) => [asset, ...prev]);
    addAuditLog('Registered Church Asset', 'Asset Management', `Added asset ${asset.name} (${asset.assetCode})`);
    apiService.createAsset(asset).catch((e) => console.warn('Failed to sync asset to backend:', e));
  };

  const addDocument = (doc: DocumentItem) => {
    setDocuments((prev) => [doc, ...prev]);
    addAuditLog('Uploaded Document', 'Document Management', `Uploaded document ${doc.title}`);
    apiService.createDocument(doc).catch((e) => console.warn('Failed to sync document to backend:', e));
  };

  const deleteDocument = (id: string) => {
    const target = documents.find((d) => d.id === id);
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    addAuditLog('Deleted Document', 'Document Management', `Removed document ${target?.title || id}`);
    apiService.deleteDocument(id).catch((e) => console.warn('Failed to delete document on backend:', e));
  };

  const addWorkflowRequest = (wf: WorkflowRequest) => {
    setWorkflows((prev) => [wf, ...prev]);
    addAuditLog(
      'Submitted Workflow Request',
      'Workflows & Approvals',
      `New ${wf.requestType} submitted by ${wf.requesterName} (${wf.requestCode})`
    );
    apiService.submitWorkflowRequest(wf).catch((err) => {
      console.warn('Failed to sync workflow request to backend:', err);
    });
  };

  const updateWorkflowStatus = async (
    id: string,
    status: WorkflowRequest['status'],
    comment?: string,
    approverName?: string
  ): Promise<{ success: boolean; workflow?: WorkflowRequest; error?: string }> => {
    const targetWf = workflows.find((w) => w.id === id);
    const approvedBy = approverName || currentUser?.name || currentUser?.email || 'Authorized Pastor / Admin';
    const approvedAt = new Date().toISOString();
    const decisionComments = comment || '';

    // 1. Commit to backend database BEFORE updating UI state!
    let backendResult: any;
    try {
      backendResult = targetWf?.requestType === 'Membership Application'
        ? await apiService.decideMembershipApplication(id, status === 'Approved' ? 'Approve' : 'Reject', decisionComments, decisionComments)
        : await apiService.updateWorkflowStatus(id, status, decisionComments, approvedBy);
    } catch (backendErr: any) {
      console.error('[CMMS] Failed to commit workflow approval/status to backend:', backendErr);
      // If approval persistence fails, do NOT update UI or report success!
      throw new Error(backendErr?.message || 'Failed to commit approval record to backend server. UI will not update.');
    }

    const updatedWfFromBackend: WorkflowRequest = backendResult?.workflow || backendResult;

    // 2. Only after successful backend commit, update local state
    if (targetWf?.requestType === 'Membership Application') {
      await reloadFromBackend();
      // Approval creates a member through /auth, so explicitly reload the
      // dedicated member endpoint as well (the generic state snapshot may lag).
      try {
        const persistedMembers = await apiService.getMembers();
        setMembers(persistedMembers);
      } catch (refreshError) {
        console.warn('[CMMS] Approval succeeded, but the member directory refresh failed:', refreshError);
      }
    }

    // Membership state was reloaded from PostgreSQL after the authoritative decision.
    if (targetWf?.requestType === 'Membership Application') {
      // Do not synthesize a client-side member; the database response is authoritative.
    }

    setWorkflows((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              status,
              comments: decisionComments || item.comments,
              approvedBy: status === 'Approved' ? approvedBy : item.approvedBy,
              approvedAt: status === 'Approved' ? approvedAt : item.approvedAt,
              rejectedReason: status === 'Rejected' ? (decisionComments || 'Rejected by administration') : item.rejectedReason,
              ...(updatedWfFromBackend && typeof updatedWfFromBackend === 'object' ? updatedWfFromBackend : {}),
            }
          : item
      )
    );

    addAuditLog(
      'Updated Workflow',
      'Workflows & Approvals',
      `Workflow request #${id} (${targetWf?.requestCode || ''}) updated to ${status} by ${approvedBy}`
    );

    return { success: true, workflow: updatedWfFromBackend };
  };

  // Member Profile Change Requests & Workflow
  const submitProfileChangeRequest = (
    memberId: string,
    changes: Partial<Member>,
    baselineMember?: Partial<Member>
  ): ProfileChangeRequest => {
    const member = members.find((m) => m.id === memberId) || baselineMember;
    const changedFields: ProfileChangeRequest['changedFields'] = [];

    const fieldLabels: Record<string, string> = {
      title: 'Title',
      firstName: 'First Name',
      middleName: 'Middle Name',
      lastName: 'Last Name',
      gender: 'Gender',
      dateOfBirth: 'Date of Birth',
      nationality: 'Nationality',
      nationalIdNumber: 'National ID Number',
      passportNumber: 'Passport Number',
      photoUrl: 'Member Photo & Profile Avatar',
      maritalStatus: 'Marital Status',
      marriageDate: 'Marriage Date (Wedding Date)',
      divorceDate: 'Divorce Date',
      spouseName: 'Spouse Full Name',
      spousePhone: 'Spouse Phone Number',
      spouseMemberId: 'Spouse Member ID',
      maleChildrenCount: 'Male Children',
      femaleChildrenCount: 'Female Children',
      adoptedChildrenCount: 'Adopted Children',
      primaryPhone: 'Primary Phone Number',
      altPhone: 'Alternative Phone',
      email: 'Email Address',
      preferredCommChannel: 'Preferred Communication',
      woreda: 'Woreda (Worda)',
      kebele: 'Kebele',
      houseNumber: 'House Number',
      streetAddress: 'Street Address',
      city: 'Sub-City / City',
      subCity: 'Sub-City',
      region: 'Region / State',
      postalCode: 'Postal Code',
      branchId: 'Assigned Campus Branch',
      membershipDate: 'Membership Date',
      membershipLocation: 'Membership Received Location / Church',
      salvationDate: 'Salvation Date',
      salvationLocation: 'Where Saved (Church / City / Location)',
      isWaterBaptized: 'Is Water Baptized?',
      waterBaptismDate: 'Baptism Date',
      waterBaptismLocation: 'Where Baptized (Church / Lake / Location)',
      isHolySpiritBaptized: 'Holy Spirit Baptized',
      foundationCourseCompleted: 'Foundation Class Completed',
      membershipStatus: 'Membership Status',
      departureReason: 'Reason for Departure / Status Change',
      departureDate: 'Status / Departure Date',
      departureEndDate: 'Excommunication End Date',
      excommunicationDescription: 'Excommunication Description & Official Decree',
      excommunicationPaperName: 'Paper of Excommunication',
      educationLevel: 'Education Level',
      fieldOfStudy: 'Field of Study',
      occupation: 'Occupation / Profession',
      employerName: 'Employer / Organization',
      employerType: 'Employer Type',
      employerTypeOther: 'Specify Other Employer Type',
      emergencyContact: 'Emergency Contact Info',
      bloodType: 'Blood Type',
      ministryIds: 'Ministries Enrolled',
      ministriesJoinedNow: 'Ministries Joined Now',
      ministriesServedBefore: 'Past Ministries Served',
    };

    const normalizeDisplayValue = (key: string, val: any): string => {
      if (val === null || val === undefined || val === 'Not provided' || val === 'Not available') return '';
      if (key === 'branchId') {
        const b = branches.find((br) => br.id === val);
        return b ? `${b.name} (${val})` : String(val);
      }
      if (key === 'emergencyContact' && typeof val === 'object') {
        const name = val.name === 'Not provided' ? '' : (val.name || '');
        const rel = val.relationship === 'Not provided' ? '' : (val.relationship || '');
        const phone = val.phone === 'Not provided' ? '' : (val.phone || '');
        if (!name && !rel && !phone) return '';
        return `${name}${rel ? ` (${rel})` : ''}${phone ? ` - ${phone}` : ''}`.trim();
      }
      if (Array.isArray(val)) return val.join(', ');
      if (typeof val === 'boolean') return val ? 'Yes' : 'No';
      if (typeof val === 'object') return JSON.stringify(val);
      return String(val).trim();
    };

    Object.entries(changes).forEach(([key, val]) => {
      if (val !== undefined) {
        const oldVal = member ? (member as any)[key] : '';
        const oldValStr = normalizeDisplayValue(key, oldVal);
        const newValStr = normalizeDisplayValue(key, val);
        if (oldValStr !== newValStr) {
          changedFields.push({
            fieldKey: key,
            fieldLabel: fieldLabels[key] || key,
            oldValue: oldValStr || 'Not Provided',
            newValue: newValStr || 'Not Provided',
          });
        }
      }
    });

    const resolvedName = member
      ? `${member.firstName || ''} ${member.lastName || ''}`.trim() || (member as any).name || currentUser?.name || 'Member'
      : currentUser?.name || 'Member';

    const newRequest: ProfileChangeRequest = {
      id: `pcr-${Date.now().toString().slice(-6)}`,
      memberId,
      memberIdNumber: member?.memberIdNumber || 'CMMS-MEMBER',
      memberName: resolvedName,
      memberEmail: member?.email || currentUser?.email || '',
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      status: 'Pending',
      changedFields,
      newSnapshot: changes,
      requestedChanges: changes,
    };

    setProfileChangeRequests((prev) => [newRequest, ...prev]);

    // Persist to backend
    apiService
      .submitProfileChangeRequest({
        ...newRequest,
        changes,
        previousSnapshot: member,
      })
      .catch((err) => console.warn('[CMMS] Failed to persist profile change request to backend:', err));

    addAuditLog(
      'Submitted Profile Change Request',
      'Member Portal & Approvals',
      `Member ${newRequest.memberName} (${newRequest.memberIdNumber}) requested ${changedFields.length} field updates. Pending Administrator Authorization.`
    );

    return newRequest;
  };

  const approveProfileChangeRequest = (requestId: string, adminNotes?: string) => {
    const request = profileChangeRequests.find((r) => r.id === requestId);
    if (!request) return;

    const snapshot = request.newSnapshot || request.requestedChanges || {};

    // Apply updates to member record in database
    setMembers((prev) => {
      const exists = prev.some(
        (m) =>
          m.id === request.memberId ||
          (request.memberEmail && m.email?.toLowerCase() === request.memberEmail.toLowerCase())
      );
      if (exists) {
        return prev.map((m) => {
          if (
            m.id === request.memberId ||
            (request.memberEmail && m.email?.toLowerCase() === request.memberEmail.toLowerCase())
          ) {
            return {
              ...m,
              ...snapshot,
              lastActive: new Date().toISOString().split('T')[0],
            };
          }
          return m;
        });
      }
      // If synthesized profile approved for the first time, add to members state
      const newMember: Member = {
        id: request.memberId,
        memberIdNumber: request.memberIdNumber || `CMMS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        title: snapshot.title || 'Mr',
        firstName: snapshot.firstName || request.memberName.split(' ')[0] || 'Member',
        middleName: snapshot.middleName || '',
        lastName: snapshot.lastName || request.memberName.split(' ').slice(1).join(' ') || '',
        gender: snapshot.gender || 'Male',
        dateOfBirth: snapshot.dateOfBirth || '1990-01-01',
        primaryPhone: snapshot.primaryPhone || '',
        altPhone: snapshot.altPhone || '',
        email: snapshot.email || request.memberEmail || '',
        preferredCommChannel: snapshot.preferredCommChannel || 'SMS',
        streetAddress: snapshot.streetAddress || '',
        city: snapshot.city || 'Addis Ababa',
        subCity: snapshot.subCity || '',
        woreda: snapshot.woreda || '',
        kebele: snapshot.kebele || '',
        houseNumber: snapshot.houseNumber || '',
        region: snapshot.region || 'Addis Ababa',
        maritalStatus: snapshot.maritalStatus || 'Single',
        branchId: snapshot.branchId || branches[0]?.id || 'br-1',
        membershipStatus: snapshot.membershipStatus || 'Active',
        emergencyContact: snapshot.emergencyContact || { name: '', relationship: '', phone: '' },
        ministryIds: snapshot.ministryIds || [],
        createdAt: new Date().toISOString().split('T')[0],
        lastActive: new Date().toISOString().split('T')[0],
        attendanceScore: 100,
        ...snapshot,
      };
      return [newMember, ...prev];
    });

    // Update request state
    const reviewer = currentUser?.name || 'System Administrator';
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    setProfileChangeRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'Approved' as const,
              reviewedBy: reviewer,
              reviewedAt: timestamp,
              adminNotes: adminNotes || 'Authorized and applied to database.',
            }
          : r
      )
    );

    apiService
      .updateProfileChangeRequestStatus(requestId, 'Approved', adminNotes, reviewer)
      .catch((err) => console.warn('[CMMS] Failed to sync profile approval to backend:', err));

    addAuditLog(
      'Authorized Member Profile Update',
      'Administration & Approvals',
      `Approved and committed profile changes for ${request.memberName} (${request.memberIdNumber}). ${request.changedFields.length} fields updated in database.`
    );
  };

  const rejectProfileChangeRequest = (requestId: string, reason: string) => {
    const request = profileChangeRequests.find((r) => r.id === requestId);
    if (!request) return;

    const reviewer = currentUser?.name || 'System Administrator';
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    setProfileChangeRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'Rejected' as const,
              reviewedBy: reviewer,
              reviewedAt: timestamp,
              rejectionReason: reason,
            }
          : r
      )
    );

    apiService
      .updateProfileChangeRequestStatus(requestId, 'Rejected', reason, reviewer)
      .catch((err) => console.warn('[CMMS] Failed to sync profile rejection to backend:', err));

    addAuditLog(
      'Rejected Member Profile Update',
      'Administration & Approvals',
      `Declined profile change request for ${request.memberName} (${request.memberIdNumber}). Reason: ${reason}`
    );
  };

  // Unified Household Registration & Propagation
  const registerUnifiedHousehold = (payload: {
    head: Partial<Member>;
    spouse?: Partial<Member>;
    children: Partial<Member>[];
    household: Partial<Family>;
  }): Family => {
    const famId = `fam-${Date.now().toString().slice(-5)}`;
    const familyCode = `FAM-2026-${Math.floor(100 + Math.random() * 900)}`;
    const sharedPhone = payload.household.primaryHouseholdPhone || payload.head.primaryPhone || '';
    const sharedAddress = payload.household.address || payload.head.streetAddress || 'Bole Sub-City, Cathedral Road';
    const sharedCity = payload.household.city || payload.head.city || 'Addis Ababa';
    const sharedRegion = payload.household.region || payload.head.region || 'Addis Ababa';
    const sharedWoreda = payload.household.woreda || payload.head.woreda || 'Woreda 03';
    const sharedKebele = payload.household.kebele || payload.head.kebele || 'Kebele 08';
    const sharedHouseNumber = payload.household.houseNumber || payload.head.houseNumber || 'H-104';

    const headMemberId = payload.head.id || `mem-head-${Date.now().toString().slice(-4)}`;
    const headMember: Member = {
      id: headMemberId,
      memberIdNumber: payload.head.memberIdNumber || `CMMS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      title: payload.head.title || 'Mr.',
      firstName: payload.head.firstName || 'Head',
      middleName: payload.head.middleName || '',
      lastName: payload.head.lastName || payload.household.householdName?.replace('Household', '').trim() || 'Family',
      dateOfBirth: payload.head.dateOfBirth || '1985-05-12',
      age: payload.head.age || 41,
      gender: payload.head.gender || 'Male',
      photoUrl: payload.head.photoUrl || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300',
      primaryPhone: sharedPhone,
      email: payload.head.email || '',
      preferredCommChannel: payload.head.preferredCommChannel || 'SMS',
      streetAddress: sharedAddress,
      city: sharedCity,
      region: sharedRegion,
      woreda: sharedWoreda,
      kebele: sharedKebele,
      houseNumber: sharedHouseNumber,
      familyId: famId,
      familyRole: 'Head',
      maritalStatus: payload.spouse ? 'Married' : (payload.head.maritalStatus || 'Single'),
      spouseName: payload.spouse ? `${payload.spouse.firstName} ${payload.spouse.lastName}` : payload.head.spouseName,
      spousePhone: payload.spouse?.primaryPhone,
      isWaterBaptized: payload.head.isWaterBaptized ?? true,
      branchId: payload.head.branchId || branches[0]?.id || 'br-001',
      membershipStatus: 'Active',
      emergencyContact: payload.head.emergencyContact || {
        name: payload.spouse?.firstName ? `${payload.spouse.firstName} ${payload.spouse.lastName}` : 'Church Pastoral Office',
        relationship: payload.spouse ? 'Spouse' : 'Pastoral Care',
        phone: payload.spouse?.primaryPhone || sharedPhone,
      },
      ministryIds: payload.head.ministryIds || [],
      createdAt: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString().split('T')[0],
      attendanceScore: 100,
    };

    const newMembersToBatch: Member[] = [headMember];
    const memberIds: string[] = [headMemberId];
    const relationships: Family['relationships'] = [];

    let spouseMemberId = '';
    if (payload.spouse && payload.spouse.firstName) {
      spouseMemberId = payload.spouse.id || `mem-spouse-${Date.now().toString().slice(-4)}`;
      const spouseMember: Member = {
        id: spouseMemberId,
        memberIdNumber: payload.spouse.memberIdNumber || `CMMS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        title: payload.spouse.title || (headMember.gender === 'Male' ? 'Mrs.' : 'Mr.'),
        firstName: payload.spouse.firstName,
        middleName: payload.spouse.middleName || '',
        lastName: payload.spouse.lastName || headMember.lastName,
        dateOfBirth: payload.spouse.dateOfBirth || '1988-08-20',
        age: payload.spouse.age || 38,
        gender: payload.spouse.gender || (headMember.gender === 'Male' ? 'Female' : 'Male'),
        photoUrl: payload.spouse.photoUrl || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=300',
        primaryPhone: payload.spouse.primaryPhone || sharedPhone,
        email: payload.spouse.email || '',
        preferredCommChannel: payload.spouse.preferredCommChannel || 'SMS',
        streetAddress: sharedAddress,
        city: sharedCity,
        region: sharedRegion,
        woreda: sharedWoreda,
        kebele: sharedKebele,
        houseNumber: sharedHouseNumber,
        familyId: famId,
        familyRole: 'Spouse',
        maritalStatus: 'Married',
        spouseName: `${headMember.firstName} ${headMember.lastName}`,
        spousePhone: headMember.primaryPhone,
        spouseMemberId: headMember.id,
        isWaterBaptized: payload.spouse.isWaterBaptized ?? true,
        branchId: headMember.branchId,
        membershipStatus: 'Active',
        emergencyContact: {
          name: `${headMember.firstName} ${headMember.lastName}`,
          relationship: 'Spouse',
          phone: headMember.primaryPhone,
        },
        ministryIds: payload.spouse.ministryIds || [],
        createdAt: new Date().toISOString().split('T')[0],
        lastActive: new Date().toISOString().split('T')[0],
        attendanceScore: 95,
      };
      newMembersToBatch.push(spouseMember);
      memberIds.push(spouseMemberId);
      relationships.push(
        { fromMemberId: headMemberId, toMemberId: spouseMemberId, relationType: 'Spouse' },
        { fromMemberId: spouseMemberId, toMemberId: headMemberId, relationType: 'Spouse' }
      );
    }

    if (payload.children && payload.children.length > 0) {
      payload.children.forEach((ch, idx) => {
        if (!ch.firstName) return;
        const childId = ch.id || `mem-child-${Date.now().toString().slice(-4)}-${idx + 1}`;
        const childMember: Member = {
          id: childId,
          memberIdNumber: ch.memberIdNumber || `CMMS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          title: ch.gender === 'Female' ? 'Miss' : 'Master',
          firstName: ch.firstName,
          middleName: ch.middleName || headMember.firstName,
          lastName: ch.lastName || headMember.lastName,
          dateOfBirth: ch.dateOfBirth || '2015-06-10',
          age: ch.age || (ch.dateOfBirth ? Math.max(1, new Date().getFullYear() - parseInt(ch.dateOfBirth.slice(0, 4))) : 10),
          gender: ch.gender || 'Male',
          photoUrl: ch.photoUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300',
          primaryPhone: ch.primaryPhone || sharedPhone,
          email: ch.email || '',
          preferredCommChannel: 'SMS',
          streetAddress: sharedAddress,
          city: sharedCity,
          region: sharedRegion,
          woreda: sharedWoreda,
          kebele: sharedKebele,
          houseNumber: sharedHouseNumber,
          familyId: famId,
          familyRole: 'Child',
          maritalStatus: 'Single',
          isWaterBaptized: ch.isWaterBaptized ?? false,
          branchId: headMember.branchId,
          membershipStatus: 'Active',
          membershipType: 'Youth Member',
          emergencyContact: {
            name: `${headMember.firstName} ${headMember.lastName}`,
            relationship: 'Father / Guardian',
            phone: headMember.primaryPhone,
          },
          ministryIds: ch.ministryIds || [],
          createdAt: new Date().toISOString().split('T')[0],
          lastActive: new Date().toISOString().split('T')[0],
          attendanceScore: 100,
        };
        newMembersToBatch.push(childMember);
        memberIds.push(childId);
        relationships.push({ fromMemberId: headMemberId, toMemberId: childId, relationType: 'Parent' });
        relationships.push({ fromMemberId: childId, toMemberId: headMemberId, relationType: 'Child' });
        if (spouseMemberId) {
          relationships.push({ fromMemberId: spouseMemberId, toMemberId: childId, relationType: 'Parent' });
          relationships.push({ fromMemberId: childId, toMemberId: spouseMemberId, relationType: 'Child' });
        }
      });
    }

    const newHousehold: Family = {
      id: famId,
      familyCode,
      householdName: payload.household.householdName || `The ${headMember.lastName} Household`,
      headOfHouseholdMemberId: headMemberId,
      primaryHouseholdPhone: sharedPhone,
      familyType: payload.household.familyType || (spouseMemberId ? 'Nuclear Family' : 'Single Parent'),
      primaryLanguage: payload.household.primaryLanguage || 'Amharic',
      address: sharedAddress,
      woreda: sharedWoreda,
      kebele: sharedKebele,
      houseNumber: sharedHouseNumber,
      city: sharedCity,
      region: sharedRegion,
      memberIds,
      relationships,
      registrationDate: new Date().toISOString().split('T')[0],
      status: 'Active',
    };

    setMembers((prev) => [...newMembersToBatch, ...prev]);
    setFamilies((prev) => [newHousehold, ...prev]);

    addAuditLog(
      'Registered Unified Household Container',
      'Family & Household Management',
      `Batch created household container "${newHousehold.householdName}" (${familyCode}) with Head ${headMember.firstName}, Spouse and ${payload.children?.length || 0} children linked to container ID ${famId}`,
      JSON.stringify({ householdId: famId, familyCode, membersCreated: newMembersToBatch.length, sharedPhone })
    );

    return newHousehold;
  };

  const propagateHouseholdAddress = (
    householdId: string,
    address: {
      streetAddress: string;
      woreda?: string;
      kebele?: string;
      houseNumber?: string;
      city: string;
      region: string;
    }
  ) => {
    setFamilies((prev) =>
      prev.map((f) => {
        if (f.id === householdId) {
          return {
            ...f,
            address: address.streetAddress,
            woreda: address.woreda,
            kebele: address.kebele,
            houseNumber: address.houseNumber,
            city: address.city,
            region: address.region,
          };
        }
        return f;
      })
    );

    setMembers((prev) =>
      prev.map((m) => {
        if (m.familyId === householdId) {
          return {
            ...m,
            streetAddress: address.streetAddress,
            woreda: address.woreda,
            kebele: address.kebele,
            houseNumber: address.houseNumber,
            city: address.city,
            region: address.region,
          };
        }
        return m;
      })
    );

    addAuditLog(
      'Propagated Household Address',
      'Family & Household Management',
      `Propagated address updates to all member profiles linked to household container ${householdId}`
    );
  };

  const getAuthHeaders = useCallback((extraHeaders: Record<string, string> = {}): Record<string, string> => {
    const token = getStoredAuthToken();
    const tenantId =
      typeof window !== 'undefined'
        ? localStorage.getItem('cmms_tenant_id') || 'tenant-grace-main'
        : 'tenant-grace-main';
    const headers: Record<string, string> = {
      Accept: 'application/json',
      'x-tenant-id': tenantId,
      ...extraHeaders,
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }, []);

  const contextValue = React.useMemo(() => ({
    isAuthenticated,
    setIsAuthenticated,
    currentUser,
    login,
    logout,
    activeRole,
    setActiveRole,
    selectedBranchId,
    setSelectedBranchId,
    activeModule,
    setActiveModule,
    globalSearchQuery,
    setGlobalSearchQuery,
    themeMode,
    setThemeMode,
    systemName,
    setSystemName,
    titleBadge,
    setTitleBadge,
    churchMotto,
    setChurchMotto,
    churchName,
    setChurchName,
    primaryColorHex,
    setPrimaryColorHex,
    accentColorHex,
    setAccentColorHex,
    loginPanelColorHex,
    setLoginPanelColorHex,
    faviconUrl,
    setFaviconUrl,
    darkLogoUrl,
    setDarkLogoUrl,
    updateBranding,
    updateFullBranding,
    updateUserProfilePhoto,
    dashboardSubTab,
    setDashboardSubTab,
    backupSubTab,
    setBackupSubTab,
    language,
    langCode,
    languageCode: langCode,
    fontClass,
    isEthiopic,
    setLanguage,
    t,
    currency,
    setCurrency,
    churchLogoUrl,
    setChurchLogoUrl,
    isSidebarCollapsed,
    setIsSidebarCollapsed,
    toggleSidebar,
    branches,
    members,
    families,
    ministries,
    attendanceRecords,
    attendanceSessions,
    activeAttendanceSessions,
    activateAttendanceSession,
    closeAttendanceSession,
    rotateSessionToken,
    checkInToSession,
    events,
    communications,
    communicationLogs,
    communicationStatus,
    prayerRequests,
    counselingSessions,
    visitations,
    volunteerShifts,
    assets,
    documents,
    documentCategories,
    courses,
    workflows,
    auditLogs,
    systemUsers,
    profileChangeRequests,
    addMember,
    updateMember,
    deleteMember,
    addFamily,
    updateFamily,
    deleteFamily,
    addBranch,
    updateBranch,
    deleteBranch,
    swapMemberBranch,
    removeMemberFromBranch,
    addMinistry,
    updateMinistry,
    deleteMinistry,
    removeMemberFromMinistry,
    deleteSubMinistry,
    refreshMinistries,
    recordAttendance,
    bulkImportAttendance,
    addEvent,
    sendCommunication,
    sendSms,
    sendEmail,
    sendBroadcast,
    retryCommunicationLog,
    refreshCommunicationLogs,
    addPrayerRequest,
    updatePrayerStatus,
    addCounselingSession,
    addVisitationRecord,
    addVolunteerShift,
    addAsset,
    addDocument,
    deleteDocument,
    addDocumentCategory,
    deleteDocumentCategory,
    addCourse,
    updateCourse,
    deleteCourse,
    addWorkflowRequest,
    updateWorkflowStatus,
    addAuditLog,
    submitProfileChangeRequest,
    approveProfileChangeRequest,
    rejectProfileChangeRequest,
    registerUnifiedHousehold,
    propagateHouseholdAddress,
    addSystemUser,
    updateSystemUser,
    removeSystemUser,
    resetUserPassword,
    updateUserRole,
    toggleUserMfa,
    exportSystemBackupJSON,
    restoreSystemBackupJSON,
    resetToDefaultData,
    reloadFromBackend,
    refreshFromBackend: reloadFromBackend,
    getAuthHeaders,
    markAttendance: recordAttendance,
    userProfile: members[0] || null,
    permissions,
  }), [
    isAuthenticated,
    currentUser,
    activeRole,
    selectedBranchId,
    activeModule,
    globalSearchQuery,
    themeMode,
    systemName,
    titleBadge,
    churchMotto,
    churchName,
    primaryColorHex,
    accentColorHex,
    loginPanelColorHex,
    faviconUrl,
    darkLogoUrl,
    dashboardSubTab,
    backupSubTab,
    language,
    currency,
    churchLogoUrl,
    isSidebarCollapsed,
    branches,
    members,
    families,
    ministries,
    attendanceRecords,
    attendanceSessions,
    activeAttendanceSessions,
    events,
    communications,
    prayerRequests,
    counselingSessions,
    visitations,
    volunteerShifts,
    assets,
    documents,
    documentCategories,
    courses,
    workflows,
    auditLogs,
    systemUsers,
    profileChangeRequests,
    permissions,
  ]);

  return (
    <CMMSContext.Provider value={contextValue}>
      {children}
    </CMMSContext.Provider>
  );
};

export const useCMMS = () => {
  const context = useContext(CMMSContext);
  if (!context) {
    throw new Error('useCMMS must be used within a CMMSProvider');
  }
  return context;
};
