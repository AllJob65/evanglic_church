import {
  createServerClient,
  parseCookieHeader,
  serializeCookieHeader,
} from '@supabase/ssr';
import type { Database } from '../types/database.types';

/**
 * Normalizes Supabase API URL to ensure clean root endpoint without /rest/v1/
 */
function getNormalizedSupabaseUrl(): string {
  const rawUrl =
    (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_URL) ||
    (typeof process !== 'undefined' && process.env?.SUPABASE_URL) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_URL) ||
    '';

  return rawUrl.trim().replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '') || 'https://unconfigured.supabase.local';
}

/**
 * Retrieves Supabase Publishable / Anon API Key safely from process or import.meta
 */
function getSupabasePublishableKey(): string {
  const key =
    (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_ANON_KEY) ||
    (typeof process !== 'undefined' && process.env?.SUPABASE_ANON_KEY) ||
    (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
    (typeof process !== 'undefined' && process.env?.SUPABASE_PUBLISHABLE_KEY) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_ANON_KEY) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
    '';

  return key.trim() || 'unconfigured-public-anon-key';
}

export interface SupabaseServerContext {
  supabase: ReturnType<typeof createServerClient<Database>>;
  headers: Headers;
}

/**
 * Creates a server-side Supabase client tailored for React Router v7 / Remix SSR loaders & actions.
 *
 * @param request Standard Web API Request object from loader/action args
 * @returns Object containing the typed Supabase client and response Headers with synchronized cookies
 */
export function createSupabaseServerClient(request: Request): SupabaseServerContext {
  const headers = new Headers();
  const supabaseUrl = getNormalizedSupabaseUrl();
  const supabaseKey = getSupabasePublishableKey();

  const supabase = createServerClient<Database>(supabaseUrl, supabaseKey, {
    cookies: {
      getAll() {
        const cookieHeader = request.headers.get('Cookie') ?? '';
        return parseCookieHeader(cookieHeader);
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => {
          headers.append(
            'Set-Cookie',
            serializeCookieHeader(name, value, {
              ...options,
              sameSite: options?.sameSite ?? 'lax',
              secure: process.env.NODE_ENV === 'production',
              path: options?.path ?? '/',
            })
          );
        });
      },
    },
  });

  return { supabase, headers };
}

export default createSupabaseServerClient;
