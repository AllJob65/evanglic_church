export interface EthiopianDate {
  year: number;
  month: number;
  day: number;
  monthName: string;
  monthNameAmharic: string;
  formatted: string;
  formattedAmharic: string;
}

export const ETHIOPIAN_MONTHS = [
  { id: 1, en: 'Meskerem', am: 'መስከረም' },
  { id: 2, en: 'Tikimt', am: 'ጥቅምት' },
  { id: 3, en: 'Hidar', am: 'ኅዳር' },
  { id: 4, en: 'Tahsas', am: 'ታኅሣሥ' },
  { id: 5, en: 'Tir', am: 'ጥር' },
  { id: 6, en: 'Yakatit', am: 'የካቲት' },
  { id: 7, en: 'Megabit', am: 'መጋቢት' },
  { id: 8, en: 'Miyazya', am: 'ሚያዝያ' },
  { id: 9, en: 'Ginbot', am: 'ግንቦት' },
  { id: 10, en: 'Sene', am: 'ሰኔ' },
  { id: 11, en: 'Hamle', am: 'ሐምሌ' },
  { id: 12, en: 'Nehase', am: 'ነሐሴ' },
  { id: 13, en: 'Pagume', am: 'ጳጉሜ' },
];

/**
 * Converts a Gregorian Date string (YYYY-MM-DD) or Date object to Ethiopian Date representation
 */
export function gregorianToEthiopian(gregorianDateStr: string | Date | undefined | null): EthiopianDate | null {
  if (!gregorianDateStr) return null;
  const date = typeof gregorianDateStr === 'string' ? new Date(gregorianDateStr) : gregorianDateStr;
  if (isNaN(date.getTime())) return null;

  const gYear = date.getFullYear();
  const gMonth = date.getMonth() + 1; // 1-12
  const gDay = date.getDate();

  const isGregorianLeap = (gYear % 4 === 0 && gYear % 100 !== 0) || (gYear % 400 === 0);
  const gDaysInMonth = [0, 31, isGregorianLeap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  const newYearDay = (gYear % 4 === 3) ? 12 : 11;

  let eYear = gYear - 8;
  if (gMonth > 9 || (gMonth === 9 && gDay >= newYearDay)) {
    eYear = gYear - 7;
  }

  let totalDays = 0;
  if (gMonth < 9 || (gMonth === 9 && gDay < newYearDay)) {
    const prevYear = gYear - 1;
    const prevNewYearDay = (prevYear % 4 === 3) ? 12 : 11;
    totalDays += (30 - prevNewYearDay + 1);
    totalDays += 31 + 30 + 31; // Oct, Nov, Dec of prev year
    for (let m = 1; m < gMonth; m++) {
      totalDays += gDaysInMonth[m];
    }
    totalDays += gDay;
  } else {
    if (gMonth === 9) {
      totalDays = gDay - newYearDay + 1;
    } else {
      totalDays = (30 - newYearDay + 1);
      for (let m = 10; m < gMonth; m++) {
        totalDays += gDaysInMonth[m];
      }
      totalDays += gDay;
    }
  }

  let eMonth = Math.floor((totalDays - 1) / 30) + 1;
  let eDay = ((totalDays - 1) % 30) + 1;

  if (eMonth > 13) eMonth = 13;

  const monthObj = ETHIOPIAN_MONTHS[eMonth - 1] || ETHIOPIAN_MONTHS[0];

  return {
    year: eYear,
    month: eMonth,
    day: eDay,
    monthName: monthObj.en,
    monthNameAmharic: monthObj.am,
    formatted: `${monthObj.en} ${eDay}, ${eYear} E.C.`,
    formattedAmharic: `${monthObj.am} ${eDay} ቀን ${eYear} ዓ.ም`,
  };
}

/**
 * Converts Ethiopian Date (Year, Month, Day) to Gregorian Date string (YYYY-MM-DD)
 */
export function ethiopianToGregorian(eYear: number, eMonth: number, eDay: number): string {
  // Base calculation for Ethiopian New Year
  const gYear = eMonth >= 1 && eMonth <= 4 ? eYear + 7 : eYear + 8;
  const newYearDay = (gYear % 4 === 3) ? 12 : 11;

  // Approximate offset in days from Sep 1
  let totalEthDays = (eMonth - 1) * 30 + (eDay - 1);
  
  // Starting date is Sep newYearDay of (eYear + 7)
  const baseDate = new Date(eYear + 7, 8, newYearDay); // Sep is index 8
  baseDate.setDate(baseDate.getDate() + totalEthDays);

  const yyyy = baseDate.getFullYear();
  const mm = String(baseDate.getMonth() + 1).padStart(2, '0');
  const dd = String(baseDate.getDate()).padStart(2, '0');

  return `${yyyy}-${mm}-${dd}`;
}
