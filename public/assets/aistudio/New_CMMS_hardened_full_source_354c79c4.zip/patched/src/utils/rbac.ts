import { UserRole, RolePermissions } from '../types';

export interface RoleSpecification {
  role: UserRole;
  title: string;
  badgeColor: string;
  dashboardType: 'system' | 'church' | 'pastoral' | 'finance' | 'ministry' | 'records' | 'member';
  overview: string;
  coreFeatures: string[];
  permissionsDescription: string;
  allowedModules: string[];
  deniedModules?: string[];
}

export const ROLE_SPECIFICATIONS: Record<UserRole, RoleSpecification> = {
  'SYSTEM_ADMIN': {
    role: 'SYSTEM_ADMIN',
    title: 'System Administrator',
    badgeColor: 'bg-amber-500/15 text-amber-600 border-amber-500/30 dark:text-amber-400',
    dashboardType: 'system',
    overview: 'Absolute full system control. Has access to all pages, APIs, and infrastructure tools.',
    coreFeatures: [
      'Absolute full system and multi-campus control',
      'Database Backup (/admin/backup) and PostgreSQL Engine',
      'System Restore (/admin/restore) and Schema Migrations',
      'System Settings (/admin/settings), Branding & Global Config',
      'Security Audit Logs, 2FA Governance & Telemetry',
      'Global user management & role provisioning',
    ],
    permissionsDescription: 'Unrestricted full administrative, operational, and infrastructural access.',
    allowedModules: ['*'],
  },
  'MANAGER': {
    role: 'MANAGER',
    title: 'Operations Manager',
    badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
    dashboardType: 'church',
    overview: 'Full operational access to ALL features, dashboards, user approvals, pastoral logs, and rosters. EXCEPTION: Strictly DENIED access to Database Backup (/admin/backup), System Restore (/admin/restore), and System Settings (/admin/settings).',
    coreFeatures: [
      'Full operational dashboards & analytics matrix',
      'Member & Family Directories with full lifecycle management',
      'User Approvals & Profile Change Request Queue',
      'Operations & Ministry Resource Workflows',
      'Pastoral Care Logs & Visitation Records',
      'Attendance Tracking, Event Management & Communications',
    ],
    permissionsDescription: 'Full operational access to all church modules. Denied access to database backup, restore, and system settings.',
    allowedModules: [
      'dashboard',
      'approvals',
      'members',
      'families',
      'branches',
      'ministries',
      'attendance',
      'devotions',
      'events',
      'communications',
      'prayer_counseling',
      'visitations',
      'assets',
      'documents',
      'predictive',
      'security_audit',
      'mobile_preview',
      'my_profile',
    ],
    deniedModules: ['backup', 'restore', 'settings', 'api_integrations'],
  },
  'PASTOR': {
    role: 'PASTOR',
    title: 'Pastor',
    badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
    dashboardType: 'pastoral',
    overview: 'Access to Member Directory, Pastoral Care Logs, Prayer Requests, Attendance Rosters, and Live Streaming.',
    coreFeatures: [
      'Member Directory & Spiritual Profiles',
      'Pastoral Care Logs & Counseling Notes',
      'Confidential Prayer Requests & Intercession Tracker',
      'Service Attendance Rosters & Follow-up',
      'Live Streaming & Daily Devotionals Publishing',
    ],
    permissionsDescription: 'Pastoral care, counseling, prayer intercession, member directory, and live broadcast access.',
    allowedModules: [
      'members',
      'prayer_counseling',
      'visitations',
      'attendance',
      'devotions',
      'events',
      'communications',
      'documents',
      'my_profile',
    ],
  },
  'MINISTRY_LEADER': {
    role: 'MINISTRY_LEADER',
    title: 'Ministry Leader',
    badgeColor: 'bg-indigo-500/15 text-indigo-600 border-indigo-500/30 dark:text-indigo-400',
    dashboardType: 'ministry',
    overview: 'Access to Attendance Rosters, Ministry Member lists, and Live Broadcast hosting for their assigned ministry.',
    coreFeatures: [
      'Assigned Ministry Member Lists & Rosters',
      'Department Attendance Tracking & Rosters',
      'Live Broadcast Hosting for Assigned Ministry',
      'Ministry Events & Rehearsal Scheduling',
      'Department Communications & Broadcasts',
    ],
    permissionsDescription: 'Assigned ministry members, attendance rosters, and live broadcast hosting privileges.',
    allowedModules: [
      'attendance',
      'ministries',
      'events',
      'communications',
      'devotions',
      'documents',
      'my_profile',
    ],
  },
  'REGULAR_MEMBER': {
    role: 'REGULAR_MEMBER',
    title: 'Regular Member',
    badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
    dashboardType: 'member',
    overview: 'Access to Joined Ministries, Attendance Check-In QR, Daily Devotionals, and Receiver-Only Live Broadcasts.',
    coreFeatures: [
       'Joined Ministries & Fellowships Participation',
       'Attendance Check-In QR Digital Pass',
       'Receiver-Only Live Broadcasts & Sermons',
       'Daily Devotionals & Prayer Request Submission',
       'Self-service Profile Management',
     ],
     permissionsDescription: 'Personal profile self-service, joined ministries, attendance QR check-in, devotionals, and receiver-only live broadcasts.',
     allowedModules: [
       'devotions',
       'prayer_counseling',
       'ministries',
       'attendance',
       'events',
       'documents',
       'my_profile',
       'mobile_preview',
     ],
  },
};

export const ROLE_PERMISSIONS_MATRIX: Record<UserRole, RolePermissions> = {
  'SYSTEM_ADMIN': {
    role: 'SYSTEM_ADMIN',
    financialApprovalLimit: 999999999,
    canManageUsers: true,
    canAssignRoles: true,
    canViewAllMembers: true,
    canCreateMembers: true,
    canEditMembers: true,
    canDeleteMembers: true,
    canManageAttendance: true,
    canManageEvents: true,
    canViewFinances: true,
    canManageFinances: true,
    canApproveExpenses: true,
    canManageBudgets: true,
    canManagePrayerRequests: true,
    canManageCounseling: true,
    canManageMinistries: true,
    canManageBranches: true,
    canGenerateReports: true,
    canViewReports: true,
    canExportData: true,
    canManageCommunication: true,
    canManageSystem: true,
    canManageWorkflows: true,
    canViewAuditLogs: true,
    canViewCounseling: true,
    canAccessBackupAndRestore: true,
    canAccessSystemSettings: true,
    canHostLiveBroadcast: true,
    dataExportScope: 'Unlimited',
  },
  'MANAGER': {
    role: 'MANAGER',
    financialApprovalLimit: 250000,
    canManageUsers: true,
    canAssignRoles: false,
    canViewAllMembers: true,
    canCreateMembers: true,
    canEditMembers: true,
    canDeleteMembers: false,
    canManageAttendance: true,
    canManageEvents: true,
    canViewFinances: true,
    canManageFinances: true,
    canApproveExpenses: true,
    canManageBudgets: true,
    canManagePrayerRequests: true,
    canManageCounseling: true,
    canManageMinistries: true,
    canManageBranches: true,
    canGenerateReports: true,
    canViewReports: true,
    canExportData: true,
    canManageCommunication: true,
    canManageSystem: false,
    canManageWorkflows: true,
    canViewAuditLogs: true,
    canViewCounseling: true,
    canAccessBackupAndRestore: false, // Strictly DENIED
    canAccessSystemSettings: false,   // Strictly DENIED
    canHostLiveBroadcast: true,
    dataExportScope: 'Branch Data',
  },
  'PASTOR': {
    role: 'PASTOR',
    financialApprovalLimit: 5000,
    canManageUsers: false,
    canAssignRoles: false,
    canViewAllMembers: true,
    canCreateMembers: false,
    canEditMembers: true,
    canDeleteMembers: false,
    canManageAttendance: true,
    canManageEvents: true,
    canViewFinances: false,
    canManageFinances: false,
    canApproveExpenses: false,
    canManageBudgets: false,
    canManagePrayerRequests: true,
    canManageCounseling: true,
    canManageMinistries: true,
    canManageBranches: false,
    canGenerateReports: true,
    canViewReports: true,
    canExportData: false,
    canManageCommunication: true,
    canManageSystem: false,
    canManageWorkflows: true,
    canViewAuditLogs: false,
    canViewCounseling: true,
    canAccessBackupAndRestore: false,
    canAccessSystemSettings: false,
    canHostLiveBroadcast: true,
    dataExportScope: 'Branch Data',
  },
  'MINISTRY_LEADER': {
    role: 'MINISTRY_LEADER',
    financialApprovalLimit: 2000,
    canManageUsers: false,
    canAssignRoles: false,
    canViewAllMembers: false,
    canCreateMembers: false,
    canEditMembers: false,
    canDeleteMembers: false,
    canManageAttendance: true,
    canManageEvents: true,
    canViewFinances: false,
    canManageFinances: false,
    canApproveExpenses: false,
    canManageBudgets: false,
    canManagePrayerRequests: false,
    canManageCounseling: false,
    canManageMinistries: true,
    canManageBranches: false,
    canGenerateReports: true,
    canViewReports: true,
    canExportData: false,
    canManageCommunication: true,
    canManageSystem: false,
    canManageWorkflows: false,
    canViewAuditLogs: false,
    canViewCounseling: false,
    canAccessBackupAndRestore: false,
    canAccessSystemSettings: false,
    canHostLiveBroadcast: true,
    dataExportScope: 'Ministry Data',
  },
  'REGULAR_MEMBER': {
    role: 'REGULAR_MEMBER',
    financialApprovalLimit: 0,
    canManageUsers: false,
    canAssignRoles: false,
    canViewAllMembers: false,
    canCreateMembers: false,
    canEditMembers: false,
    canDeleteMembers: false,
    canManageAttendance: false,
    canManageEvents: false,
    canViewFinances: false,
    canManageFinances: false,
    canApproveExpenses: false,
    canManageBudgets: false,
    canManagePrayerRequests: false,
    canManageCounseling: false,
    canManageMinistries: false,
    canManageBranches: false,
    canGenerateReports: false,
    canViewReports: false,
    canExportData: false,
    canManageCommunication: false,
    canManageSystem: false,
    canManageWorkflows: false,
    canViewAuditLogs: false,
    canViewCounseling: false,
    canAccessBackupAndRestore: false,
    canAccessSystemSettings: false,
    canHostLiveBroadcast: false, // Receiver-only
    dataExportScope: 'Personal Only',
  },
};

/**
 * Normalizes any legacy string into one of the 5 canonical UserRoles
 */
export function normalizeUserRole(role?: string): UserRole {
  if (!role) return 'REGULAR_MEMBER';
  const clean = role.trim().toUpperCase().replace(/[\s-]+/g, '_');
  if (
    clean === 'SYSTEM_ADMIN' ||
    clean === 'SYSTEM_ADMINISTRATOR' ||
    clean === 'SUPER_ADMIN' ||
    clean === 'SUPER_ADMINISTRATOR' ||
    clean.includes('SUPER')
  ) {
    return 'SYSTEM_ADMIN';
  }
  if (
    clean === 'MANAGER' ||
    clean === 'BRANCH_MANAGER' ||
    clean === 'BRANCH_ADMINISTRATOR' ||
    clean === 'CHURCH_ADMIN' ||
    clean === 'CHURCH_ADMINISTRATOR' ||
    clean === 'FINANCE_OFFICER' ||
    clean === 'SECRETARY' ||
    clean === 'STAFF_MEMBER' ||
    clean.includes('MANAGER')
  ) {
    return 'MANAGER';
  }
  if (clean === 'PASTOR' || clean.includes('PASTOR') || clean.includes('COUNSELOR')) {
    return 'PASTOR';
  }
  if (
    clean === 'MINISTRY_LEADER' ||
    clean === 'MINISTRY_DIRECTOR' ||
    clean === 'MINISTRY_COORDINATOR' ||
    clean === 'GROUP_LEADER' ||
    clean === 'TEAM_LEADER' ||
    clean === 'VOLUNTEER_LEADER' ||
    clean.includes('LEADER')
  ) {
    return 'MINISTRY_LEADER';
  }
  return 'REGULAR_MEMBER';
}

export function getRolePermissions(
  roleOrRoles: UserRole | string | (UserRole | string)[],
  additionalRoles?: (UserRole | string)[]
): RolePermissions {
  const rolesInput: (UserRole | string)[] = Array.isArray(roleOrRoles)
    ? roleOrRoles
    : [roleOrRoles, ...(Array.isArray(additionalRoles) ? additionalRoles : [])];

  const normalizedRoles: UserRole[] = Array.from(
    new Set(rolesInput.filter(Boolean).map((r) => normalizeUserRole(String(r))))
  );
  if (normalizedRoles.length === 0) {
    return ROLE_PERMISSIONS_MATRIX['REGULAR_MEMBER'];
  }

  const primaryRole = normalizedRoles[0];
  if (normalizedRoles.length === 1) {
    return ROLE_PERMISSIONS_MATRIX[primaryRole] || ROLE_PERMISSIONS_MATRIX['REGULAR_MEMBER'];
  }

  const hasSystemAdmin = normalizedRoles.includes('SYSTEM_ADMIN');
  const matrices = normalizedRoles.map((r) => ROLE_PERMISSIONS_MATRIX[r] || ROLE_PERMISSIONS_MATRIX['REGULAR_MEMBER']);

  const maxLimit = Math.max(...matrices.map((m) => m.financialApprovalLimit || 0));
  const scopeRank: Record<string, number> = {
    'Personal Only': 1,
    'Ministry Data': 2,
    'Branch Data': 3,
    'Unlimited': 4,
  };
  let bestScope: RolePermissions['dataExportScope'] = 'Personal Only';
  for (const m of matrices) {
    if ((scopeRank[m.dataExportScope] || 0) > (scopeRank[bestScope] || 0)) {
      bestScope = m.dataExportScope;
    }
  }

  return {
    role: primaryRole,
    financialApprovalLimit: maxLimit,
    canManageUsers: matrices.some((m) => m.canManageUsers),
    canAssignRoles: hasSystemAdmin && matrices.some((m) => m.canAssignRoles),
    canViewAllMembers: matrices.some((m) => m.canViewAllMembers),
    canCreateMembers: matrices.some((m) => m.canCreateMembers),
    canEditMembers: matrices.some((m) => m.canEditMembers),
    canDeleteMembers: hasSystemAdmin && matrices.some((m) => m.canDeleteMembers),
    canManageAttendance: matrices.some((m) => m.canManageAttendance),
    canManageEvents: matrices.some((m) => m.canManageEvents),
    canViewFinances: matrices.some((m) => m.canViewFinances),
    canManageFinances: matrices.some((m) => m.canManageFinances),
    canApproveExpenses: matrices.some((m) => m.canApproveExpenses),
    canManageBudgets: matrices.some((m) => m.canManageBudgets),
    canManagePrayerRequests: matrices.some((m) => m.canManagePrayerRequests),
    canManageCounseling: matrices.some((m) => m.canManageCounseling),
    canManageMinistries: matrices.some((m) => m.canManageMinistries),
    canManageBranches: hasSystemAdmin && matrices.some((m) => m.canManageBranches),
    canGenerateReports: matrices.some((m) => m.canGenerateReports),
    canViewReports: matrices.some((m) => m.canViewReports),
    canExportData: matrices.some((m) => m.canExportData),
    canManageCommunication: matrices.some((m) => m.canManageCommunication),
    // Explicit infrastructure boundary: non-SYSTEM_ADMIN roles NEVER gain system settings or backup/restore
    canManageSystem: hasSystemAdmin && matrices.some((m) => m.canManageSystem),
    canManageWorkflows: matrices.some((m) => m.canManageWorkflows),
    canViewAuditLogs: matrices.some((m) => m.canViewAuditLogs),
    canViewCounseling: matrices.some((m) => m.canViewCounseling),
    canAccessBackupAndRestore: hasSystemAdmin && matrices.some((m) => m.canAccessBackupAndRestore),
    canAccessSystemSettings: hasSystemAdmin && matrices.some((m) => m.canAccessSystemSettings),
    canHostLiveBroadcast: matrices.some((m) => m.canHostLiveBroadcast),
    dataExportScope: bestScope,
  };
}

export function getRoleSpecification(role: UserRole): RoleSpecification {
  const norm = normalizeUserRole(role);
  return ROLE_SPECIFICATIONS[norm] || ROLE_SPECIFICATIONS['REGULAR_MEMBER'];
}

export function isSystemAdmin(role: UserRole | string | (UserRole | string)[]): boolean {
  if (Array.isArray(role)) {
    return role.some((r) => normalizeUserRole(String(r)) === 'SYSTEM_ADMIN');
  }
  return normalizeUserRole(role) === 'SYSTEM_ADMIN';
}

export function isManager(role: UserRole | string | (UserRole | string)[]): boolean {
  if (Array.isArray(role)) {
    return role.some((r) => normalizeUserRole(String(r)) === 'MANAGER');
  }
  return normalizeUserRole(role) === 'MANAGER';
}

export function isPastor(role: UserRole | string | (UserRole | string)[]): boolean {
  if (Array.isArray(role)) {
    return role.some((r) => normalizeUserRole(String(r)) === 'PASTOR');
  }
  return normalizeUserRole(role) === 'PASTOR';
}

export function isMinistryLeader(role: UserRole | string | (UserRole | string)[]): boolean {
  if (Array.isArray(role)) {
    return role.some((r) => normalizeUserRole(String(r)) === 'MINISTRY_LEADER');
  }
  return normalizeUserRole(role) === 'MINISTRY_LEADER';
}

export function isRegularMember(role: UserRole | string | (UserRole | string)[]): boolean {
  if (Array.isArray(role)) {
    return role.length === 1 && normalizeUserRole(String(role[0])) === 'REGULAR_MEMBER';
  }
  return normalizeUserRole(role) === 'REGULAR_MEMBER';
}

export function canAccessBackupAndRestore(role: UserRole | string | (UserRole | string)[]): boolean {
  return isSystemAdmin(role);
}

export function canAccessSystemSettings(role: UserRole | string | (UserRole | string)[]): boolean {
  return isSystemAdmin(role);
}

export function canAccessBackupAndSettings(role: UserRole | string | (UserRole | string)[]): boolean {
  return isSystemAdmin(role);
}

export function canHostLiveBroadcast(role: UserRole | string | (UserRole | string)[]): boolean {
  const list = Array.isArray(role) ? role : [role];
  return list.some((item) => {
    const r = normalizeUserRole(String(item));
    return r === 'SYSTEM_ADMIN' || r === 'MANAGER' || r === 'PASTOR' || r === 'MINISTRY_LEADER';
  });
}

export function isReceiverOnlyLiveBroadcast(role: UserRole | string | (UserRole | string)[]): boolean {
  return !canHostLiveBroadcast(role);
}

export function isModuleAuthorized(
  roleOrRoles: UserRole | string | (UserRole | string)[],
  moduleId: string,
  additionalRoles?: (UserRole | string)[]
): boolean {
  const rolesInput: (UserRole | string)[] = Array.isArray(roleOrRoles)
    ? roleOrRoles
    : [roleOrRoles, ...(Array.isArray(additionalRoles) ? additionalRoles : [])];

  const normalizedRoles: UserRole[] = Array.from(
    new Set(rolesInput.filter(Boolean).map((r) => normalizeUserRole(String(r))))
  );
  if (normalizedRoles.length === 0) return false;

  // Infrastructure explicit deny rule: only SYSTEM_ADMIN can access backup, restore, settings, api_integrations
  const systemModules = ['backup', 'restore', 'settings', 'api_integrations'];
  if (systemModules.includes(moduleId) && !normalizedRoles.includes('SYSTEM_ADMIN')) {
    return false;
  }

  return normalizedRoles.some((normRole) => {
    const spec = ROLE_SPECIFICATIONS[normRole];
    if (!spec) return false;
    if (spec.allowedModules.includes('*')) {
      if (spec.deniedModules && spec.deniedModules.includes(moduleId)) {
        return false;
      }
      return true;
    }
    if (spec.deniedModules && spec.deniedModules.includes(moduleId)) {
      return false;
    }
    return spec.allowedModules.includes(moduleId);
  });
}

export function getAllowedModulesForRole(
  roleOrRoles: UserRole | string | (UserRole | string)[],
  additionalRoles?: (UserRole | string)[]
): string[] {
  const rolesInput: (UserRole | string)[] = Array.isArray(roleOrRoles)
    ? roleOrRoles
    : [roleOrRoles, ...(Array.isArray(additionalRoles) ? additionalRoles : [])];

  const normalizedRoles: UserRole[] = Array.from(
    new Set(rolesInput.filter(Boolean).map((r) => normalizeUserRole(String(r))))
  );
  if (normalizedRoles.includes('SYSTEM_ADMIN')) {
    return ['*'];
  }
  const unionModules = new Set<string>();
  const systemDenied = new Set(['backup', 'restore', 'settings', 'api_integrations']);
  for (const r of normalizedRoles) {
    const spec = ROLE_SPECIFICATIONS[r];
    if (!spec) continue;
    for (const m of spec.allowedModules) {
      if (!systemDenied.has(m)) {
        unionModules.add(m);
      }
    }
  }
  return Array.from(unionModules);
}

// ==============================================================================
// UNIFIED PERMISSIONS CATALOG & EFFECTIVE PERMISSIONS ENGINE (Browser & Server Safe)
// ==============================================================================
export type Permission =
  | 'members.read'
  | 'members.create'
  | 'members.update'
  | 'members.delete'
  | 'members.export'
  | 'families.read'
  | 'families.create'
  | 'families.update'
  | 'families.delete'
  | 'attendance.read'
  | 'attendance.create'
  | 'attendance.update'
  | 'attendance.delete'
  | 'events.read'
  | 'events.create'
  | 'events.update'
  | 'events.delete'
  | 'events.manage'
  | 'finance.read'
  | 'finance.create'
  | 'finance.approve'
  | 'finance.export'
  | 'pastoral.read'
  | 'pastoral.create'
  | 'pastoral.update'
  | 'pastoral.confidential'
  | 'prayer.read'
  | 'prayer.create'
  | 'prayer.update'
  | 'prayer.delete'
  | 'counseling.read'
  | 'counseling.create'
  | 'counseling.update'
  | 'counseling.confidential'
  | 'visitations.read'
  | 'visitations.create'
  | 'visitations.update'
  | 'visitations.manage'
  | 'ministries.read'
  | 'ministries.manage'
  | 'groups.read'
  | 'groups.manage'
  | 'volunteers.read'
  | 'volunteers.manage'
  | 'assets.read'
  | 'assets.manage'
  | 'documents.read'
  | 'documents.manage'
  | 'communications.read'
  | 'communications.manage'
  | 'workflows.read'
  | 'workflows.create'
  | 'workflows.manage'
  | 'branches.read'
  | 'branches.manage'
  | 'users.read'
  | 'users.manage'
  | 'reports.read'
  | 'reports.export'
  | 'system.manage'
  | 'backup.manage'
  | 'audit.read'
  | 'devotions.read'
  | 'devotions.manage'
  | 'devotions.engage'
  | 'bible.read'
  | 'bible.personal';

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  SYSTEM_ADMIN: [
    'members.read',
    'members.create',
    'members.update',
    'members.delete',
    'members.export',
    'families.read',
    'families.create',
    'families.update',
    'families.delete',
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'attendance.delete',
    'events.read',
    'events.create',
    'events.update',
    'events.delete',
    'events.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'pastoral.read',
    'pastoral.create',
    'pastoral.update',
    'pastoral.confidential',
    'prayer.read',
    'prayer.create',
    'prayer.update',
    'prayer.delete',
    'counseling.read',
    'counseling.create',
    'counseling.update',
    'counseling.confidential',
    'visitations.read',
    'visitations.create',
    'visitations.update',
    'visitations.manage',
    'ministries.read',
    'ministries.manage',
    'groups.read',
    'groups.manage',
    'volunteers.read',
    'volunteers.manage',
    'assets.read',
    'assets.manage',
    'documents.read',
    'documents.manage',
    'communications.read',
    'communications.manage',
    'workflows.read',
    'workflows.create',
    'workflows.manage',
    'branches.read',
    'branches.manage',
    'users.read',
    'users.manage',
    'reports.read',
    'reports.export',
    'system.manage',
    'backup.manage',
    'audit.read',
    'devotions.read',
    'devotions.manage',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],
  MANAGER: [
    'members.read',
    'members.create',
    'members.update',
    'members.export',
    'families.read',
    'families.create',
    'families.update',
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'events.read',
    'events.create',
    'events.update',
    'events.delete',
    'events.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'pastoral.read',
    'pastoral.create',
    'pastoral.update',
    'prayer.read',
    'prayer.create',
    'prayer.update',
    'counseling.read',
    'visitations.read',
    'visitations.create',
    'visitations.update',
    'visitations.manage',
    'ministries.read',
    'ministries.manage',
    'groups.read',
    'groups.manage',
    'volunteers.read',
    'volunteers.manage',
    'assets.read',
    'assets.manage',
    'documents.read',
    'documents.manage',
    'communications.read',
    'communications.manage',
    'workflows.read',
    'workflows.create',
    'workflows.manage',
    'branches.read',
    'reports.read',
    'reports.export',
    'devotions.read',
    'devotions.manage',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],
  PASTOR: [
    'members.read',
    'members.create',
    'members.update',
    'families.read',
    'families.create',
    'families.update',
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'events.read',
    'events.create',
    'events.update',
    'events.manage',
    'pastoral.read',
    'pastoral.create',
    'pastoral.update',
    'pastoral.confidential',
    'counseling.read',
    'counseling.create',
    'counseling.update',
    'counseling.confidential',
    'prayer.read',
    'prayer.create',
    'prayer.update',
    'visitations.read',
    'visitations.create',
    'visitations.update',
    'visitations.manage',
    'ministries.read',
    'groups.read',
    'groups.manage',
    'documents.read',
    'communications.read',
    'communications.manage',
    'branches.read',
    'workflows.read',
    'workflows.create',
    'workflows.manage',
    'reports.read',
    'devotions.read',
    'devotions.manage',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],
  MINISTRY_LEADER: [
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'events.read',
    'events.create',
    'events.update',
    'events.manage',
    'ministries.read',
    'groups.read',
    'groups.manage',
    'volunteers.read',
    'documents.read',
    'communications.read',
    'communications.manage',
    'branches.read',
    'workflows.read',
    'workflows.create',
    'reports.read',
    'devotions.read',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],
  REGULAR_MEMBER: [
    'attendance.create',
    'events.read',
    'finance.read',
    'prayer.read',
    'prayer.create',
    'counseling.read',
    'ministries.read',
    'groups.read',
    'documents.read',
    'branches.read',
    'workflows.create',
    'devotions.read',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],
};

export const ROLE_EXPLICIT_DENY_PERMISSIONS: Record<UserRole, Permission[]> = {
  SYSTEM_ADMIN: [],
  MANAGER: [
    'system.manage',
    'backup.manage',
    'members.delete',
    'families.delete',
    'attendance.delete',
    'prayer.delete',
  ],
  PASTOR: [
    'system.manage',
    'backup.manage',
    'audit.read',
    'users.read',
    'users.manage',
    'branches.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'members.delete',
    'families.delete',
  ],
  MINISTRY_LEADER: [
    'system.manage',
    'backup.manage',
    'audit.read',
    'users.read',
    'users.manage',
    'branches.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'pastoral.confidential',
    'counseling.confidential',
    'members.delete',
    'families.delete',
  ],
  REGULAR_MEMBER: [
    'system.manage',
    'backup.manage',
    'audit.read',
    'users.read',
    'users.manage',
    'branches.manage',
    'members.create',
    'members.update',
    'members.delete',
    'members.export',
    'pastoral.confidential',
    'counseling.confidential',
  ],
};

export interface RoleDefinitionRecord {
  id: UserRole;
  code: UserRole;
  name: string;
  description: string;
  isSystemRole: boolean;
  permissions: Permission[];
  explicitDeniedPermissions: Permission[];
}

export const ROLES_CATALOG: Record<UserRole, RoleDefinitionRecord> = {
  SYSTEM_ADMIN: {
    id: 'SYSTEM_ADMIN',
    code: 'SYSTEM_ADMIN',
    name: 'System Administrator',
    description: 'Full infrastructure, security, multi-campus, backup/restore, and RBAC governance.',
    isSystemRole: true,
    permissions: ROLE_PERMISSIONS.SYSTEM_ADMIN,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.SYSTEM_ADMIN,
  },
  MANAGER: {
    id: 'MANAGER',
    code: 'MANAGER',
    name: 'Operations Manager',
    description: 'Operational management across members, events, finance, ministries, and approvals. Denied system settings and backup/restore.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.MANAGER,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.MANAGER,
  },
  PASTOR: {
    id: 'PASTOR',
    code: 'PASTOR',
    name: 'Pastor & Spiritual Counselor',
    description: 'Spiritual oversight, member directory, confidential pastoral counseling, visitations, prayer requests, and devotionals.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.PASTOR,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.PASTOR,
  },
  MINISTRY_LEADER: {
    id: 'MINISTRY_LEADER',
    code: 'MINISTRY_LEADER',
    name: 'Ministry Leader',
    description: 'Ministry roster management, department attendance, volunteer coordination, and ministry events.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.MINISTRY_LEADER,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.MINISTRY_LEADER,
  },
  REGULAR_MEMBER: {
    id: 'REGULAR_MEMBER',
    code: 'REGULAR_MEMBER',
    name: 'Regular Member',
    description: 'Personal profile self-service, attendance QR check-in, devotionals, Bible study, and personal prayer requests.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.REGULAR_MEMBER,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.REGULAR_MEMBER,
  },
};

export function resolveUserRolesList(
  primaryRoleInput?: UserRole | string | null,
  additionalRolesInput?: (UserRole | string)[] | null
): {
  primaryRole: UserRole;
  additionalRoles: UserRole[];
  allRoles: UserRole[];
  userRoles: { role: UserRole; isPrimary: boolean }[];
} {
  const primaryRole = normalizeUserRole(primaryRoleInput || 'REGULAR_MEMBER');
  const rawExtras = Array.isArray(additionalRolesInput) ? additionalRolesInput : [];
  const additionalRoles: UserRole[] = [];
  for (const r of rawExtras) {
    if (!r) continue;
    const norm = normalizeUserRole(String(r));
    if (norm !== primaryRole && !additionalRoles.includes(norm)) {
      additionalRoles.push(norm);
    }
  }
  const allRoles: UserRole[] = [primaryRole, ...additionalRoles];
  const userRoles = allRoles.map((r, idx) => ({
    role: r,
    isPrimary: idx === 0,
  }));
  return { primaryRole, additionalRoles, allRoles, userRoles };
}

export function computeEffectivePermissions(
  primaryRoleInput: UserRole | string,
  additionalRolesInput?: (UserRole | string)[] | null,
  explicitUserDeniedPermissions?: (Permission | string)[] | null
): {
  primaryRole: UserRole;
  additionalRoles: UserRole[];
  allRoles: UserRole[];
  userRoles: { role: UserRole; isPrimary: boolean }[];
  effectivePermissions: Permission[];
  deniedPermissions: Permission[];
  roleBreakdown: { role: UserRole; isPrimary: boolean; grantedPermissions: Permission[] }[];
} {
  const { primaryRole, additionalRoles, allRoles, userRoles } = resolveUserRolesList(
    primaryRoleInput,
    additionalRolesInput
  );

  const unionSet = new Set<Permission>();
  const roleBreakdown: { role: UserRole; isPrimary: boolean; grantedPermissions: Permission[] }[] = [];

  for (const assignment of userRoles) {
    const perms = ROLE_PERMISSIONS[assignment.role] || [];
    for (const p of perms) {
      unionSet.add(p);
    }
    roleBreakdown.push({
      role: assignment.role,
      isPrimary: assignment.isPrimary,
      grantedPermissions: [...perms],
    });
  }

  const hasSystemAdmin = allRoles.includes('SYSTEM_ADMIN');
  const deniedSet = new Set<Permission>();

  if (!hasSystemAdmin) {
    deniedSet.add('system.manage');
    deniedSet.add('backup.manage');
    deniedSet.add('branches.manage');
    deniedSet.add('members.delete');
    deniedSet.add('families.delete');
    deniedSet.add('attendance.delete');
    deniedSet.add('prayer.delete');

    const candidateDenies = new Set<Permission>();
    for (const r of allRoles) {
      for (const d of ROLE_EXPLICIT_DENY_PERMISSIONS[r] || []) {
        candidateDenies.add(d);
      }
    }
    for (const d of candidateDenies) {
      const grantedByAnyAssignedRole = allRoles.some((r) => (ROLE_PERMISSIONS[r] || []).includes(d));
      if (!grantedByAnyAssignedRole) {
        deniedSet.add(d);
      }
    }
  }

  if (Array.isArray(explicitUserDeniedPermissions)) {
    for (const rawDeny of explicitUserDeniedPermissions) {
      if (rawDeny && typeof rawDeny === 'string') {
        deniedSet.add(rawDeny as Permission);
      }
    }
  }

  for (const deniedPerm of deniedSet) {
    unionSet.delete(deniedPerm);
  }

  return {
    primaryRole,
    additionalRoles,
    allRoles,
    userRoles,
    effectivePermissions: Array.from(unionSet),
    deniedPermissions: Array.from(deniedSet),
    roleBreakdown,
  };
}

