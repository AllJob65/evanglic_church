/**
 * Dynamic Favicon & Browser Title Manager
 * Enables live updating of the browser tab's icon and document title from Super Admin settings.
 */

// Preset SVG Favicons for Super Admin Quick Selector
export const FAVICON_PRESETS: { id: string; name: string; category: string; svgDataUri: string }[] = [
  {
    id: 'cathedral-crest',
    name: 'Cathedral Crest',
    category: 'Architecture',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%232563eb"/><path d="M16 4l-9 8v16h18V12l-9-8zm0 5l5 4.5v12.5h-10V13.5l5-4.5z" fill="%23ffffff"/><rect x="14" y="19" width="4" height="7" rx="1" fill="%23ffffff"/></svg>',
  },
  {
    id: 'golden-cross',
    name: 'Golden Cross',
    category: 'Classic Cross',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%231e293b"/><path d="M14 4h4v7h7v4h-7v13h-4V15H7v-4h7V4z" fill="%23f59e0b"/></svg>',
  },
  {
    id: 'sacred-flame',
    name: 'Sacred Flame / Holy Spirit',
    category: 'Holy Spirit',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%237c2d12"/><path d="M16 3c1 4 6 7 6 12 0 4.4-3.6 8-8 8s-8-3.6-8-8c0-3.5 3-6.5 5-9 0 3 2 4 4 4 1-3 1-5 3-7z" fill="%23ea580c"/></svg>',
  },
  {
    id: 'sovereign-crown',
    name: 'Sovereign Crown',
    category: 'Royal / Kingship',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%234c1d95"/><path d="M5 24h22l-2-12-6 5-3-9-3 9-6-5-2 12z" fill="%23fbbf24"/><circle cx="5" cy="11" r="1.5" fill="%23fbbf24"/><circle cx="16" cy="7" r="1.5" fill="%23fbbf24"/><circle cx="27" cy="11" r="1.5" fill="%23fbbf24"/></svg>',
  },
  {
    id: 'holy-dove',
    name: 'Holy Dove of Peace',
    category: 'Peace & Grace',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%230284c7"/><path d="M7 16c3-1 6-4 8-8 2 4 5 7 10 7-3 2-4 5-3 9-3-2-6-2-9 0-1-3-3-6-6-8z" fill="%23ffffff"/></svg>',
  },
  {
    id: 'open-bible',
    name: 'Open Scripture Bible',
    category: 'Word & Scripture',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%230f172a"/><path d="M6 7v16c3-1 6-1 10 1 4-2 7-2 10-1V7c-3-1-6-1-10 1-4-2-7-2-10-1zm10 2v13" fill="%23e2e8f0" stroke="%2338bdf8" stroke-width="1.5"/></svg>',
  },
  {
    id: 'shield-of-faith',
    name: 'Shield of Faith',
    category: 'Defense & Honor',
    svgDataUri: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%231e1b4b"/><path d="M16 4l10 4v8c0 7-5 11-10 13-5-2-10-6-10-13V8l10-4zm-1 6v5H10v2h5v6h2v-6h5v-2h-5v-5h-2z" fill="%23a855f7"/></svg>',
  },
];

/**
 * Updates the browser favicon dynamically in the DOM head
 */
export function updateBrowserFavicon(iconUrlOrDataUri: string) {
  if (typeof document === 'undefined') return;

  try {
    let link: HTMLLinkElement | null = document.querySelector("link[rel*='icon']");
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.getElementsByTagName('head')[0].appendChild(link);
    }
    link.href = iconUrlOrDataUri;

    // Also update apple-touch-icon if present
    let appleLink: HTMLLinkElement | null = document.querySelector("link[rel='apple-touch-icon']");
    if (appleLink) {
      appleLink.href = iconUrlOrDataUri;
    }
  } catch (err) {
    console.warn('[Favicon] Failed to update browser favicon:', err);
  }
}

/**
 * Updates the browser title dynamically in document.title
 */
export function updateBrowserTitle(systemName: string, titleBadge?: string) {
  if (typeof document === 'undefined') return;

  try {
    const badge = titleBadge ? ` - ${titleBadge}` : '';
    document.title = `${systemName || 'Church Management System'}${badge}`;
  } catch (err) {
    console.warn('[Title] Failed to update browser title:', err);
  }
}
