// Utility to safely interact with Google Translate engine without breaking React DOM

export const GOOGLE_TRANSLATE_LANGUAGES: Record<string, string> = {
  English: 'en',
  Amharic: 'am',
  Tigrigna: 'ti',
  'Afaan Oromoo': 'om',
  Spanish: 'es',
  French: 'fr',
  Arabic: 'ar',
  German: 'de',
  Chinese: 'zh-CN',
  Portuguese: 'pt',
  Swahili: 'sw',
  Italian: 'it',
  Korean: 'ko',
  Japanese: 'ja',
  Hindi: 'hi',
  Russian: 'ru',
  Dutch: 'nl',
  Turkish: 'tr',
  Hebrew: 'he',
  Greek: 'el',
};

// Set cookie for Google Translate
export function setGoogleTranslateCookie(langCode: string) {
  if (typeof document === 'undefined') return;

  const cookieVal = langCode === 'en' ? '' : `/auto/${langCode}`;
  const date = new Date();
  date.setTime(date.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year
  const expires = `; expires=${date.toUTCString()}`;

  // Set standard googtrans cookie
  document.cookie = `googtrans=${cookieVal}; path=/${expires}`;
  document.cookie = `googtrans=${cookieVal}; path=/; domain=${window.location.hostname}${expires}`;
  document.cookie = `goog-trans=${cookieVal}; path=/${expires}`;
}

// Clear cookie for Google Translate when using native church languages
export function clearGoogleTranslateCookie() {
  if (typeof document === 'undefined') return;
  document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
  document.cookie = `googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=${window.location.hostname}`;
  document.cookie = 'goog-trans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';

  // Remove Google Translate banner iframe and restore body position
  try {
    const banner = document.querySelector('.goog-te-banner-frame');
    if (banner && banner.parentNode) {
      banner.parentNode.removeChild(banner);
    }
    document.body.style.top = '0px';
    document.body.classList.remove('translated-ltr', 'translated-rtl');
  } catch {
    // ignore
  }
}

// Trigger Google Translate engine programmatically (ONLY for external languages outside en/am/ti/om)
export function triggerGoogleTranslate(langNameOrCode: string) {
  if (typeof window === 'undefined') return;

  const langCode = GOOGLE_TRANSLATE_LANGUAGES[langNameOrCode] || langNameOrCode || 'en';
  const lower = langCode.toLowerCase().trim();

  // Internal native languages must never run Google Translate
  if (
    lower === 'en' || lower === 'english' ||
    lower === 'am' || lower === 'amharic' ||
    lower === 'ti' || lower === 'tigrigna' || lower === 'tigrinya' ||
    lower === 'om' || lower === 'oromo' || lower === 'afaan oromoo'
  ) {
    clearGoogleTranslateCookie();
    return;
  }

  setGoogleTranslateCookie(langCode);

  // Attempt to update hidden Google Translate combo box if present
  try {
    const combo = document.querySelector('.goog-te-combo') as HTMLSelectElement | null;
    if (combo) {
      combo.value = langCode;
      combo.dispatchEvent(new Event('change', { bubbles: true }));
    }
  } catch (e) {
    console.warn('Google Translate combo event notice:', e);
  }
}

// Initialize Google Translate Script if not yet present
export function initGoogleTranslateScript() {
  if (typeof window === 'undefined') return;

  if (!document.getElementById('google-translate-script')) {
    (window as any).googleTranslateElementInit = () => {
      try {
        if ((window as any).google && (window as any).google.translate) {
          new (window as any).google.translate.TranslateElement(
            {
              pageLanguage: 'en',
              includedLanguages: 'en,am,om,ti,es,fr,ar,de,zh-CN,pt,sw,it,ko,ja,hi,ru,nl,tr,he,el',
              layout: (window as any).google.translate.TranslateElement.InlineLayout.SIMPLE,
              autoDisplay: false,
            },
            'google_translate_element'
          );
        }
      } catch (e) {
        console.warn('Google Translate initialization notice:', e);
      }
    };

    const script = document.createElement('script');
    script.id = 'google-translate-script';
    script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
    script.async = true;
    script.onerror = () => {
      console.warn('[Google Translate] Script load failed or was blocked.');
    };
    document.body.appendChild(script);
  }
}
