export {
  ETHIOPIAN_PHONE_REGEX,
  formatToE164,
  formatEthioPhone,
  validateEthiopianPhone as validateEthiopianPhoneStrict,
} from '../schemas/phone.schema';

export interface PhoneValidationResult {
  isValid: boolean;
  error?: string;
  formatted: string;
  normalized?: string;
  carrier?: 'Ethio Telecom' | 'Safaricom Ethiopia';
}

const ETHIOPIAN_LOCAL_LENGTH = 10; // 0912345678
const ETHIOPIAN_SHORT_LENGTH = 9;  // 912345678
const ETHIOPIAN_INTL_LENGTH = 13;  // +251912345678

export function sanitizeEthiopianPhoneInput(input: string): string {
  if (!input) return '';

  let value = input.replace(/\D/g, '');

  if (value.startsWith('0')) {
    return value.substring(0, 10);
  }

  if (value.startsWith('9') || value.startsWith('7')) {
    return value.substring(0, 9);
  }

  return value;
}

export function normalizeEthiopianPhone(phone: string): string {
  const sanitized = sanitizeEthiopianPhoneInput(phone);

  if (/^\+251[97]\d{8}$/.test(sanitized)) {
    return sanitized;
  }

  if (/^0[97]\d{8}$/.test(sanitized)) {
    return `+251${sanitized.substring(1)}`;
  }

  if (/^[97]\d{8}$/.test(sanitized)) {
    return `+251${sanitized}`;
  }

  return sanitized;
}

export function validateEthiopianPhone(
  phone: string,
  isOptional = false
): PhoneValidationResult {

  if (!phone?.trim()) {
    return isOptional
      ? { isValid: true, formatted: '' }
      : {
          isValid: false,
          error: 'Phone number is required',
          formatted: ''
        };
  }

  const sanitized = sanitizeEthiopianPhoneInput(phone);

  if (sanitized.startsWith('+251')) {

    if (sanitized.length < ETHIOPIAN_INTL_LENGTH) {
      return {
        isValid: false,
        error: `Phone number is too short. Expected ${ETHIOPIAN_INTL_LENGTH} characters (+251XXXXXXXXX).`,
        formatted: sanitized
      };
    }

    if (sanitized.length > ETHIOPIAN_INTL_LENGTH) {
      return {
        isValid: false,
        error: `Phone number is too long. Expected ${ETHIOPIAN_INTL_LENGTH} characters.`,
        formatted: sanitized
      };
    }

    if (!/^\+251[97]\d{8}$/.test(sanitized)) {
      return {
        isValid: false,
        error: 'Must start with +2519 or +2517.',
        formatted: sanitized
      };
    }

    return {
      isValid: true,
      formatted: sanitized,
      normalized: sanitized
    };
  }

  if (sanitized.startsWith('0')) {

    if (sanitized.length < ETHIOPIAN_LOCAL_LENGTH) {
      return {
        isValid: false,
        error: `Phone number is too short. Expected ${ETHIOPIAN_LOCAL_LENGTH} digits.`,
        formatted: sanitized
      };
    }

    if (sanitized.length > ETHIOPIAN_LOCAL_LENGTH) {
      return {
        isValid: false,
        error: `Phone number is too long. Expected ${ETHIOPIAN_LOCAL_LENGTH} digits.`,
        formatted: sanitized
      };
    }

    if (!/^0[97]\d{8}$/.test(sanitized)) {
      return {
        isValid: false,
        error: 'Must start with 09 or 07.',
        formatted: sanitized
      };
    }

    return {
      isValid: true,
      formatted: sanitized,
      normalized: `+251${sanitized.substring(1)}`
    };
  }

  if (/^[97]/.test(sanitized)) {

    if (sanitized.length < ETHIOPIAN_SHORT_LENGTH) {
      return {
        isValid: false,
        error: `Phone number is too short. Expected ${ETHIOPIAN_SHORT_LENGTH} digits.`,
        formatted: sanitized
      };
    }

    if (sanitized.length > ETHIOPIAN_SHORT_LENGTH) {
      return {
        isValid: false,
        error: `Phone number is too long. Expected ${ETHIOPIAN_SHORT_LENGTH} digits.`,
        formatted: sanitized
      };
    }

    if (!/^[97]\d{8}$/.test(sanitized)) {
      return {
        isValid: false,
        error: 'Must start with 9 or 7.',
        formatted: sanitized
      };
    }

    return {
      isValid: true,
      formatted: `0${sanitized}`,
      normalized: `+251${sanitized}`
    };
  }

  return {
    isValid: false,
    error:
      'Valid formats: +251912345678, 0912345678, 0712345678, 912345678, 712345678',
    formatted: sanitized
  };
}