/**
 * Password Security & Validation Utilities
 * Enforces strong password rules and protects against common/leaked passwords.
 */

export interface PasswordValidationResult {
  isValid: boolean;
  score: number; // 0 to 4
  errors: string[];
  feedback: string;
  requirements: {
    minLength: boolean;
    hasUppercase: boolean;
    hasLowercase: boolean;
    hasNumber: boolean;
    hasSymbol: boolean;
    notCommonOrLeaked: boolean;
  };
}

// Banned list of common leaked/compromised passwords
const COMMON_LEAKED_PASSWORDS = new Set([
  'password',
  'password123',
  'password@2026',
  'password@2026!',
  'member@2026',
  'member@2026!',
  '123456',
  '12345678',
  '123456789',
  '1234567890',
  'admin',
  'admin123',
  'admin@2026',
  'administrator',
  'qwerty',
  'welcome',
  'welcome123',
  'church123',
  'cathedral',
  'grace123',
  'jesus123',
  'christian',
  'p@ssw0rd',
  'p@ssword',
  'letmein',
  'monkey',
  'dragon',
  'master',
  'sunshine',
  'princess',
  'football',
  'iloveyou',
]);

/**
 * Validates password strength and checks against common/compromised lists.
 */
export function validatePasswordStrength(password: string): PasswordValidationResult {
  const errors: string[] = [];

  const minLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSymbol = /[^A-Za-z0-9]/.test(password);

  const normalized = password.trim().toLowerCase();
  const notCommonOrLeaked = !COMMON_LEAKED_PASSWORDS.has(normalized);

  if (!minLength) {
    errors.push('Must be at least 8 characters long');
  }
  if (!hasUppercase) {
    errors.push('Must include at least one uppercase letter (A-Z)');
  }
  if (!hasLowercase) {
    errors.push('Must include at least one lowercase letter (a-z)');
  }
  if (!hasNumber) {
    errors.push('Must include at least one digit (0-9)');
  }
  if (!hasSymbol) {
    errors.push('Must include at least one special character (e.g. !@#$%^&*)');
  }
  if (!notCommonOrLeaked) {
    errors.push('This password is on a list of known compromised or easily guessable passwords');
  }

  // Calculate score (0-4)
  let score = 0;
  if (minLength) score++;
  if (hasUppercase && hasLowercase) score++;
  if (hasNumber && hasSymbol) score++;
  if (password.length >= 12 && notCommonOrLeaked) score++;

  let feedback = 'Weak password';
  if (score === 4) feedback = 'Very Strong';
  else if (score === 3) feedback = 'Strong';
  else if (score === 2) feedback = 'Fair';
  else if (score === 1) feedback = 'Weak';

  const isValid = minLength && hasUppercase && hasLowercase && hasNumber && hasSymbol && notCommonOrLeaked;

  return {
    isValid,
    score,
    errors,
    feedback,
    requirements: {
      minLength,
      hasUppercase,
      hasLowercase,
      hasNumber,
      hasSymbol,
      notCommonOrLeaked,
    },
  };
}
