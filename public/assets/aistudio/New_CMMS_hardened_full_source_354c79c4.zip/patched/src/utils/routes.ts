import { ModuleTab } from '../context/CMMSContext';
import { UserRole } from '../types';

export const MODULE_TO_PATH: Record<ModuleTab, string> = {
  dashboard: '/dashboard',
  bible: '/bible',
  devotions: '/devotions',
  members: '/members',
  families: '/families',
  branches: '/branches',
  ministries: '/ministries',
  attendance: '/attendance',
  events: '/events',
  communications: '/communications',
  prayer_counseling: '/prayer-counseling',
  visitations: '/visitations',
  volunteers: '/volunteers',
  assets: '/assets',
  documents: '/documents',
  lms: '/lms',
  workflows: '/workflows',
  predictive: '/predictive',
  backup: '/backup',
  security_audit: '/security-audit',
  settings: '/settings',
  api_integrations: '/admin/api',
  mobile_preview: '/mobile-preview',
  approvals: '/approvals',
  reports: '/predictive',
  my_profile: '/my-profile',
};

export const PATH_TO_MODULE: Record<string, ModuleTab> = {
  '/dashboard': 'dashboard',
  '/bible': 'bible',
  '/bible/passage': 'bible',
  '/bible/verse-of-the-day': 'bible',
  '/devotions': 'devotions',
  '/devotion': 'devotions',
  '/members': 'members',
  '/families': 'families',
  '/branches': 'branches',
  '/ministries': 'ministries',
  '/attendance': 'attendance',
  '/events': 'events',
  '/communications': 'communications',
  '/prayer-counseling': 'prayer_counseling',
  '/prayer_counseling': 'prayer_counseling',
  '/visitations': 'visitations',
  '/volunteers': 'volunteers',
  '/assets': 'assets',
  '/documents': 'documents',
  '/lms': 'lms',
  '/workflows': 'workflows',
  '/predictive': 'predictive',
  '/backup': 'backup',
  '/security-audit': 'security_audit',
  '/security_audit': 'security_audit',
  '/settings': 'settings',
  '/admin/api': 'api_integrations',
  '/api-integrations': 'api_integrations',
  '/integrations': 'api_integrations',
  '/api': 'api_integrations',
  '/mobile-preview': 'mobile_preview',
  '/mobile_preview': 'mobile_preview',
  '/approvals': 'approvals',
  '/reports': 'reports',
  '/my-profile': 'my_profile',
  '/profile': 'my_profile',
};

export interface ParsedRoute {
  module: ModuleTab;
  dashboardSubTab?: 'overview' | 'backup_restore' | 'system_health' | 'readiness';
  isLanding: boolean;
  isPublicForm: boolean;
  isLogin: boolean;
  isPublicRoute: boolean;
  roleOverride?: UserRole;
  branchId?: string;
}

export function parseCurrentLocation(pathname: string, search: string, hash: string): ParsedRoute {
  const searchParams = new URLSearchParams(search);

  // Landing page detection
  const isLanding = pathname === '/' || pathname === '' || pathname === '/landing';

  // Public form detection
  const isPublicForm =
    pathname === '/register' ||
    pathname === '/registration' ||
    pathname === '/form' ||
    pathname === '/google-form' ||
    searchParams.get('form') === 'true' ||
    searchParams.get('view') === 'registration' ||
    hash.includes('google-form') ||
    hash.includes('member-registration');

  const isLogin = pathname === '/login';
  const isPublicRoute = isLanding || isPublicForm || isLogin;

  // Role query param
  const roleParam = searchParams.get('role');
  let roleOverride: UserRole | undefined = undefined;
  if (roleParam) {
    roleOverride = roleParam as UserRole;
  }

  // Branch query param
  const branchId = searchParams.get('branch') || undefined;

  // Normalize pathname (remove trailing slash)
  const normalizedPath = pathname.length > 1 && pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;

  // Sub-tabs on /dashboard
  let dashboardSubTab: 'overview' | 'backup_restore' | 'system_health' | 'readiness' | undefined = undefined;
  if (
    normalizedPath === '/dashboard/backup' ||
    normalizedPath === '/dashboard/backup_restore' ||
    searchParams.get('tab') === 'backup_restore'
  ) {
    dashboardSubTab = 'backup_restore';
  } else if (
    normalizedPath === '/dashboard/health' ||
    normalizedPath === '/dashboard/system_health' ||
    searchParams.get('tab') === 'system_health'
  ) {
    dashboardSubTab = 'system_health';
  } else if (normalizedPath === '/dashboard/readiness' || searchParams.get('tab') === 'readiness') {
    dashboardSubTab = 'readiness';
  } else if (normalizedPath === '/dashboard/overview' || searchParams.get('tab') === 'overview') {
    dashboardSubTab = 'overview';
  }

  // Find base module
  let targetModule: ModuleTab = 'dashboard';

  // Check exact path match
  if (PATH_TO_MODULE[normalizedPath]) {
    targetModule = PATH_TO_MODULE[normalizedPath];
  } else {
    // Check prefix match (e.g. /members/123 -> members, /dashboard/... -> dashboard)
    const segments = normalizedPath.split('/').filter(Boolean);
    if (segments.length > 0) {
      const firstSegment = `/${segments[0]}`;
      if (PATH_TO_MODULE[firstSegment]) {
        targetModule = PATH_TO_MODULE[firstSegment];
      }
    }
  }

  // Also support ?module=... query param
  const moduleQuery = searchParams.get('module') as ModuleTab;
  if (moduleQuery && MODULE_TO_PATH[moduleQuery]) {
    targetModule = moduleQuery;
  }

  return {
    module: targetModule,
    dashboardSubTab,
    isLanding,
    isPublicForm,
    isLogin,
    isPublicRoute,
    roleOverride,
    branchId,
  };
}
