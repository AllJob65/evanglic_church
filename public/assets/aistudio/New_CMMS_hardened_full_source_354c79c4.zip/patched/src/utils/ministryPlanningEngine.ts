import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import {
  MinistryAnnualPlan,
  MinistryPlanObjective,
  MinistryPlanActivityItem,
  MinistryPlanKpiItem,
  MinistryPlanRiskItem,
  MinistryQuarterMilestone,
  MinistryMonthlyTimelineItem,
  MinistryQuarterlyReport,
  MinistryAnnualReport,
} from '../types';

export const CALENDAR_MONTHS: {
  monthIndex: number;
  month: string;
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  defaultFocus: string;
}[] = [
  { monthIndex: 1, month: 'January', quarter: 'Q1', defaultFocus: 'Vision Casting, Prayer & Fasting, Leadership Alignment' },
  { monthIndex: 2, month: 'February', quarter: 'Q1', defaultFocus: 'Volunteer Mobilization & Core Training Workshops' },
  { monthIndex: 3, month: 'March', quarter: 'Q1', defaultFocus: 'Q1 Outreach Execution & Quarter-End Review' },
  { monthIndex: 4, month: 'April', quarter: 'Q2', defaultFocus: 'Easter / Resurrection Season Ministry & Evangelism' },
  { monthIndex: 5, month: 'May', quarter: 'Q2', defaultFocus: 'Discipleship Deepening & Mid-Year Fellowship' },
  { monthIndex: 6, month: 'June', quarter: 'Q2', defaultFocus: 'Mid-Year Assessment, Youth/Family Impact & Q2 Review' },
  { monthIndex: 7, month: 'July', quarter: 'Q3', defaultFocus: 'Summer Mission, Community Service & Skill Building' },
  { monthIndex: 8, month: 'August', quarter: 'Q3', defaultFocus: 'Annual Ministry Conference & Leadership Retreat' },
  { monthIndex: 9, month: 'September', quarter: 'Q3', defaultFocus: 'New Year / Meskerem Revival & Campus Integration' },
  { monthIndex: 10, month: 'October', quarter: 'Q4', defaultFocus: 'Harvest Outreach & Mentorship Cohort Launch' },
  { monthIndex: 11, month: 'November', quarter: 'Q4', defaultFocus: 'Gratitude & Stewardship Drive, Year-End Preparation' },
  { monthIndex: 12, month: 'December', quarter: 'Q4', defaultFocus: 'Christmas Celebration, Annual Evaluation & Next-Year Handover' },
];

export const QUARTER_DEFINITIONS: {
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  title: string;
  months: string[];
  defaultSummary: string;
}[] = [
  {
    quarter: 'Q1',
    title: 'Quarter 1 (Jan – Mar): Foundation, Alignment & Mobilization',
    months: ['January', 'February', 'March'],
    defaultSummary: 'Establish operational readiness, train volunteers, launch Q1 core programs, and align team with annual objectives.',
  },
  {
    quarter: 'Q2',
    title: 'Quarter 2 (Apr – Jun): Expansion, Evangelism & Mid-Year Impact',
    months: ['April', 'May', 'June'],
    defaultSummary: 'Execute seasonal outreach, deepen discipleship cohorts, and conduct mid-year KPI and budget review.',
  },
  {
    quarter: 'Q3',
    title: 'Quarter 3 (Jul – Sep): Intensive Ministry, Retreat & Revival',
    months: ['July', 'August', 'September'],
    defaultSummary: 'Deliver major conferences/retreats, expand community service footprint, and onboard new ministry members.',
  },
  {
    quarter: 'Q4',
    title: 'Quarter 4 (Oct – Dec): Harvest Consolidation & Annual Evaluation',
    months: ['October', 'November', 'December'],
    defaultSummary: 'Complete annual deliverables, measure full-year KPI outcomes, and compile annual ministry report.',
  },
];

/**
 * Automatically generates Q1, Q2, Q3, Q4 quarterly milestones and the 12-month timeline
 * from the plan's objectives, activities, expected participants, responsible person,
 * required resources, and optional budget.
 */
export function generateQuarterlyAndMonthlySchedule(params: {
  ministryName: string;
  year: number;
  objectives: MinistryPlanObjective[];
  activities: MinistryPlanActivityItem[];
  responsiblePerson: string;
  expectedParticipants: number;
  requiredResources: string;
  optionalBudget: number;
}): {
  quarterlyMilestones: MinistryQuarterMilestone[];
  monthlyActivities: MinistryMonthlyTimelineItem[];
} {
  const {
    ministryName,
    year,
    objectives,
    activities,
    responsiblePerson,
    expectedParticipants,
    requiredResources,
    optionalBudget,
  } = params;

  const totalBudget = Number(optionalBudget) || 0;
  const totalParticipants = Number(expectedParticipants) || 0;

  // 1. Build 12 Monthly Timeline Items (January - December)
  const monthlyActivities: MinistryMonthlyTimelineItem[] = CALENDAR_MONTHS.map((m) => {
    const matchedActivities = activities.filter(
      (a) => a.month.toLowerCase() === m.month.toLowerCase()
    );
    const quarterObjectives = objectives.filter(
      (o) => o.targetQuarter === m.quarter || o.targetQuarter === 'All Quarters'
    );

    const activityTitles =
      matchedActivities.length > 0
        ? matchedActivities.map((a) => `${a.title}${a.description ? ` — ${a.description}` : ''}`)
        : [
            `${ministryName} ${m.month} ${year}: ${m.defaultFocus}`,
            ...(quarterObjectives.length > 0
              ? [`Advance Objective: ${quarterObjectives[0].title}`]
              : []),
          ];

    const monthBudget =
      matchedActivities.length > 0
        ? matchedActivities.reduce((sum, a) => sum + (Number(a.estimatedBudget) || 0), 0)
        : Math.round(totalBudget / 12);

    const monthParticipants =
      matchedActivities.length > 0
        ? Math.max(...matchedActivities.map((a) => Number(a.expectedParticipants) || 0), Math.round(totalParticipants / 4))
        : Math.round(totalParticipants / 4);

    const monthResponsible =
      matchedActivities.find((a) => a.responsiblePerson)?.responsiblePerson ||
      responsiblePerson ||
      'Ministry Coordinator';

    const monthResources =
      matchedActivities.find((a) => a.requiredResources)?.requiredResources ||
      requiredResources ||
      'Standard Ministry Facilities & Volunteer Team';

    return {
      monthIndex: m.monthIndex,
      month: m.month,
      quarter: m.quarter,
      focusTheme: m.defaultFocus,
      activities: activityTitles,
      responsiblePerson: monthResponsible,
      expectedParticipants: monthParticipants,
      allocatedBudget: monthBudget,
      requiredResources: monthResources,
      status: 'Planned',
    };
  });

  // 2. Build Q1, Q2, Q3, Q4 Quarterly Milestones
  const quarterlyMilestones: MinistryQuarterMilestone[] = QUARTER_DEFINITIONS.map((qDef) => {
    const qMonths = monthlyActivities.filter((m) => m.quarter === qDef.quarter);
    const qActivities = activities.filter((a) => a.quarter === qDef.quarter);
    const qObjectives = objectives.filter(
      (o) => o.targetQuarter === qDef.quarter || o.targetQuarter === 'All Quarters'
    );

    const deliverables: string[] = [
      ...qObjectives.map((o) => `Objective: ${o.title}`),
      ...qActivities.map((a) => `Activity: ${a.title} (${a.month})`),
    ];

    if (deliverables.length === 0) {
      deliverables.push(
        ...qMonths.map((m) => `${m.month}: ${m.activities[0] || m.focusTheme}`)
      );
    }

    const allocatedBudget =
      qActivities.length > 0
        ? qActivities.reduce((sum, a) => sum + (Number(a.estimatedBudget) || 0), 0)
        : qMonths.reduce((sum, m) => sum + (Number(m.allocatedBudget) || 0), 0);

    const qParticipants =
      qActivities.length > 0
        ? Math.max(...qActivities.map((a) => Number(a.expectedParticipants) || 0), Math.round(totalParticipants / 4))
        : Math.max(...qMonths.map((m) => Number(m.expectedParticipants) || 0), Math.round(totalParticipants / 4));

    return {
      quarter: qDef.quarter,
      title: qDef.title,
      months: qDef.months,
      milestoneSummary:
        qObjectives.length > 0
          ? `${qDef.defaultSummary} Key Focus: ${qObjectives.map((o) => o.title).join('; ')}.`
          : qDef.defaultSummary,
      deliverables,
      plannedActivitiesCount: Math.max(qActivities.length, qMonths.reduce((s, m) => s + m.activities.length, 0)),
      expectedParticipants: qParticipants,
      allocatedBudget,
      responsiblePerson:
        qActivities.find((a) => a.responsiblePerson)?.responsiblePerson ||
        responsiblePerson ||
        'Ministry Leader',
      status: 'Pending',
    };
  });

  return { quarterlyMilestones, monthlyActivities };
}

/**
 * Aggregates quarterly reports (Q1..Q4) into a comprehensive MinistryAnnualReport.
 */
export function aggregateQuarterlyReportsIntoAnnualReport(
  plan: MinistryAnnualPlan,
  overrides?: {
    executiveSummary?: string;
    keyAchievements?: string;
    majorChallenges?: string;
    lessonsLearned?: string;
    strategicRecommendationsNextYear?: string;
    status?: 'Draft' | 'Submitted' | 'Approved';
    submittedBy?: string;
    submittedByName?: string;
  }
): MinistryAnnualReport {
  const reports = [...(plan.quarterlyReports || [])].sort((a, b) =>
    a.quarter.localeCompare(b.quarter)
  );

  const quartersIncluded = reports.map((r) => r.quarter);
  const totalPlannedActivities = Math.max(
    plan.activities?.length || 0,
    reports.length * 3
  );
  const totalActualActivitiesCompleted = reports.length > 0 ? reports.length * 3 : 0;

  const totalExpectedParticipants =
    reports.reduce((sum, r) => sum + (Number(r.plannedParticipants) || 0), 0) ||
    Number(plan.expectedParticipants) ||
    0;

  const totalActualParticipants = reports.reduce(
    (sum, r) => sum + (Number(r.actualParticipants) || 0),
    0
  );

  const participantAchievementRate =
    totalExpectedParticipants > 0
      ? Number(((totalActualParticipants / totalExpectedParticipants) * 100).toFixed(1))
      : 0;

  const totalAllocatedBudget =
    reports.reduce((sum, r) => sum + (Number(r.allocatedBudget) || 0), 0) ||
    Number(plan.optionalBudget) ||
    0;

  const totalActualExpense = reports.reduce(
    (sum, r) => sum + (Number(r.actualExpense) || 0),
    0
  );

  const totalBudgetVariance = totalAllocatedBudget - totalActualExpense;
  const budgetUtilizationRate =
    totalAllocatedBudget > 0
      ? Number(((totalActualExpense / totalAllocatedBudget) * 100).toFixed(1))
      : 0;

  // Aggregate KPI results across quarters
  const aggregatedKpiResults = (plan.kpis || []).map((kpi) => {
    const matchingEntries = reports.flatMap((r) =>
      (r.kpiPerformance || []).filter(
        (kp) => kp.kpiId === kpi.id || kp.kpiName.toLowerCase() === kpi.name.toLowerCase()
      )
    );
    const totalActual =
      matchingEntries.length > 0
        ? matchingEntries.reduce((sum, item) => sum + (Number(item.actualAchieved) || 0), 0)
        : Number(kpi.actualValue) || 0;
    const annualTarget = Number(kpi.targetValue) || 1;
    const isPercentageUnit = kpi.unit.includes('%');
    const effectiveActual =
      isPercentageUnit && matchingEntries.length > 0
        ? Number((totalActual / matchingEntries.length).toFixed(1))
        : totalActual;
    const achievementRate =
      annualTarget > 0
        ? Number(Math.min(200, (effectiveActual / annualTarget) * 100).toFixed(1))
        : 0;

    return {
      kpiName: kpi.name,
      unit: kpi.unit,
      annualTarget,
      totalActual: effectiveActual,
      achievementRate,
    };
  });

  const overallKpiAchievementRate =
    aggregatedKpiResults.length > 0
      ? Number(
          (
            aggregatedKpiResults.reduce((sum, k) => sum + k.achievementRate, 0) /
            aggregatedKpiResults.length
          ).toFixed(1)
        )
      : reports.length > 0
      ? Number(
          (
            reports.reduce((sum, r) => sum + (Number(r.overallKpiScore) || 0), 0) /
            reports.length
          ).toFixed(1)
        )
      : 0;

  const quarterlyBreakdown = (['Q1', 'Q2', 'Q3', 'Q4'] as const).map((q) => {
    const rep = reports.find((r) => r.quarter === q);
    const milestone = (plan.quarterlyMilestones || []).find((m) => m.quarter === q);
    return {
      quarter: q,
      plannedActivity: rep?.plannedActivity || milestone?.milestoneSummary || `${q} Planned Activities`,
      actualActivity: rep?.actualActivity || 'Pending quarterly report submission',
      plannedParticipants: rep?.plannedParticipants ?? milestone?.expectedParticipants ?? 0,
      actualParticipants: rep?.actualParticipants ?? 0,
      allocatedBudget: rep?.allocatedBudget ?? milestone?.allocatedBudget ?? 0,
      actualExpense: rep?.actualExpense ?? 0,
      kpiScore: rep?.overallKpiScore ?? 0,
      results: rep?.results || 'Not yet reported',
      challenges: rep?.challenges || 'None reported',
      lessonsLearned: rep?.lessonsLearned || 'None reported',
    };
  });

  const synthesizedAchievements =
    overrides?.keyAchievements ||
    reports.map((r) => `[${r.quarter}] ${r.results}`).join('\n') ||
    'Executed annual ministry objectives and quarterly milestones.';

  const synthesizedChallenges =
    overrides?.majorChallenges ||
    reports.map((r) => `[${r.quarter}] ${r.challenges}`).filter(Boolean).join('\n') ||
    'Managed operational and scheduling constraints across quarters.';

  const synthesizedLessons =
    overrides?.lessonsLearned ||
    reports.map((r) => `[${r.quarter}] ${r.lessonsLearned}`).filter(Boolean).join('\n') ||
    'Early volunteer mobilization and continuous pastoral alignment improve outcomes.';

  const synthesizedNextYear =
    overrides?.strategicRecommendationsNextYear ||
    reports.map((r) => `[${r.quarter} -> Next] ${r.nextQuarterAction}`).filter(Boolean).join('\n') ||
    'Expand discipleship cohorts and strengthen cross-ministry collaboration in the upcoming year.';

  const defaultExecSummary =
    overrides?.executiveSummary ||
    `${plan.ministryName} (${plan.year}) Annual Performance Summary: ${reports.length}/4 quarterly reports submitted (${quartersIncluded.join(', ') || 'None'}). Total participants reached: ${totalActualParticipants.toLocaleString()} vs ${totalExpectedParticipants.toLocaleString()} planned (${participantAchievementRate}%). Budget utilization: ${plan.currency || 'ETB'} ${totalActualExpense.toLocaleString()} of ${totalAllocatedBudget.toLocaleString()} (${budgetUtilizationRate}%). Overall KPI Achievement: ${overallKpiAchievementRate}%.`;

  return {
    id: plan.annualReport?.id || `marep-${plan.id}-${plan.year}`,
    planId: plan.id,
    ministryId: plan.ministryId,
    ministryName: plan.ministryName,
    branchId: plan.branchId,
    year: plan.year,
    executiveSummary: defaultExecSummary,
    quartersIncluded,
    totalPlannedActivities,
    totalActualActivitiesCompleted,
    totalExpectedParticipants,
    totalActualParticipants,
    participantAchievementRate,
    totalAllocatedBudget,
    totalActualExpense,
    totalBudgetVariance,
    budgetUtilizationRate,
    overallKpiAchievementRate,
    aggregatedKpiResults,
    quarterlyBreakdown,
    keyAchievements: synthesizedAchievements,
    majorChallenges: synthesizedChallenges,
    lessonsLearned: synthesizedLessons,
    strategicRecommendationsNextYear: synthesizedNextYear,
    status: overrides?.status || plan.annualReport?.status || 'Submitted',
    submittedBy: overrides?.submittedBy || plan.submittedBy || 'usr-leader',
    submittedByName: overrides?.submittedByName || plan.submittedByName || plan.responsiblePerson,
    submittedAt: new Date().toISOString(),
    approvedByName: plan.annualReport?.approvedByName,
    approvedAt: plan.annualReport?.approvedAt,
    pastorComments: plan.annualReport?.pastorComments,
  };
}

/**
 * Generates a REAL binary PDF document for a Ministry Annual Plan (including Q1-Q4, Monthly Timeline,
 * KPIs, Risks, Review History, Quarterly Reports, and Aggregated Annual Report).
 */
export function buildMinistryPlanPdfBuffer(plan: MinistryAnnualPlan): Uint8Array {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 40;

  // Header Banner
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 82, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(`${plan.ministryName.toUpperCase()} — ${plan.year} ANNUAL PLAN & REPORT`, 40, 34);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Plan Code: ${plan.planCode}  |  Workflow Status: ${plan.status.toUpperCase()}  |  Revision: v${plan.revisionNumber}`,
    40,
    52
  );
  doc.text(
    `Responsible Leader: ${plan.responsiblePerson}  |  Target Audience: ${plan.targetAudience}  |  Expected Participants: ${plan.expectedParticipants.toLocaleString()}`,
    40,
    68
  );

  y = 104;
  doc.setTextColor(15, 23, 42);

  // Section 1: Plan Metadata & Vision
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('1. Executive Overview & Strategic Parameters', 40, y);
  y += 10;

  autoTable(doc, {
    startY: y,
    head: [['Parameter', 'Specification']],
    body: [
      ['Plan Title', plan.title],
      ['Ministry / Department', plan.ministryName],
      ['Planning Year', String(plan.year)],
      ['Workflow Status', `${plan.status} (Revision #${plan.revisionNumber})`],
      ['Responsible Person', plan.responsiblePerson],
      ['Target Audience', plan.targetAudience],
      ['Expected Participants', plan.expectedParticipants.toLocaleString()],
      ['Optional Annual Budget', `${plan.currency || 'ETB'} ${(plan.optionalBudget || 0).toLocaleString()}`],
      ['Required Resources', plan.requiredResources || 'Standard Ministry Resources'],
      ['Vision & Strategic Statement', plan.visionStatement || 'Equipping believers and advancing church mission.'],
      ['Expected Outcomes', (plan.expectedOutcomes || []).join(' • ') || 'Spiritual growth and community impact'],
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 64, 175], textColor: 255, fontSize: 9 },
    bodyStyles: { fontSize: 8.5, textColor: [30, 41, 59] },
    columnStyles: { 0: { cellWidth: 150, fontStyle: 'bold' } },
    margin: { left: 40, right: 40 },
  });

  y = (doc as any).lastAutoTable.finalY + 20;

  // Section 2: Strategic Objectives
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('2. Annual Objectives & KPIs', 40, y);
  y += 8;

  autoTable(doc, {
    startY: y,
    head: [['Objective Title', 'Description', 'Priority', 'Target Quarter']],
    body: (plan.objectives || []).map((o) => [
      o.title,
      o.description,
      o.priority,
      o.targetQuarter,
    ]),
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], textColor: 255, fontSize: 8.5 },
    bodyStyles: { fontSize: 8 },
    margin: { left: 40, right: 40 },
  });

  y = (doc as any).lastAutoTable.finalY + 12;

  autoTable(doc, {
    startY: y,
    head: [['KPI Name', 'Unit', 'Baseline', 'Target', 'Weight (%)']],
    body: (plan.kpis || []).map((k) => [
      k.name,
      k.unit,
      String(k.baselineValue),
      String(k.targetValue),
      `${k.weightPercentage}%`,
    ]),
    theme: 'striped',
    headStyles: { fillColor: [5, 150, 105], textColor: 255, fontSize: 8.5 },
    bodyStyles: { fontSize: 8 },
    margin: { left: 40, right: 40 },
  });

  y = (doc as any).lastAutoTable.finalY + 20;

  // Section 3: Auto-Generated Q1 - Q4 Quarterly Milestones
  if (y > 680) {
    doc.addPage();
    y = 45;
  }
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('3. Quarterly Milestones (Q1, Q2, Q3, Q4)', 40, y);
  y += 8;

  autoTable(doc, {
    startY: y,
    head: [['Quarter', 'Months', 'Milestone Summary & Deliverables', 'Participants', 'Budget', 'Lead']],
    body: (plan.quarterlyMilestones || []).map((qm) => [
      qm.quarter,
      (qm.months || []).join(', '),
      `${qm.milestoneSummary}\n• ${(qm.deliverables || []).join('\n• ')}`,
      qm.expectedParticipants.toLocaleString(),
      `${plan.currency || 'ETB'} ${qm.allocatedBudget.toLocaleString()}`,
      qm.responsiblePerson,
    ]),
    theme: 'grid',
    headStyles: { fillColor: [79, 70, 229], textColor: 255, fontSize: 8.5 },
    bodyStyles: { fontSize: 8 },
    columnStyles: {
      0: { cellWidth: 42, fontStyle: 'bold' },
      1: { cellWidth: 85 },
      2: { cellWidth: 215 },
    },
    margin: { left: 40, right: 40 },
  });

  y = (doc as any).lastAutoTable.finalY + 20;

  // Section 4: 12-Month Activity Timeline
  if (y > 650) {
    doc.addPage();
    y = 45;
  }
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('4. Monthly Activity Timeline (January – December)', 40, y);
  y += 8;

  autoTable(doc, {
    startY: y,
    head: [['Month', 'Qtr', 'Planned Activities & Focus', 'Responsible', 'Target Pax', 'Budget']],
    body: (plan.monthlyActivities || []).map((m) => [
      m.month,
      m.quarter,
      (m.activities || []).join('; ') || m.focusTheme,
      m.responsiblePerson,
      m.expectedParticipants.toLocaleString(),
      `${plan.currency || 'ETB'} ${m.allocatedBudget.toLocaleString()}`,
    ]),
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], textColor: 255, fontSize: 8.5 },
    bodyStyles: { fontSize: 7.5 },
    margin: { left: 40, right: 40 },
  });

  y = (doc as any).lastAutoTable.finalY + 20;

  // Section 5: Risks & Mitigation
  if (y > 680) {
    doc.addPage();
    y = 45;
  }
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('5. Risk Register & Mitigation Strategy', 40, y);
  y += 8;

  autoTable(doc, {
    startY: y,
    head: [['Identified Risk', 'Severity', 'Likelihood', 'Mitigation Plan', 'Owner']],
    body: (plan.risks || []).map((r) => [
      r.riskDescription,
      r.severity,
      r.likelihood,
      r.mitigationPlan,
      r.owner,
    ]),
    theme: 'grid',
    headStyles: { fillColor: [180, 83, 9], textColor: 255, fontSize: 8.5 },
    bodyStyles: { fontSize: 8 },
    margin: { left: 40, right: 40 },
  });

  y = (doc as any).lastAutoTable.finalY + 20;

  // Section 6: Quarterly Reports & Annual Aggregation (if any)
  if ((plan.quarterlyReports || []).length > 0) {
    if (y > 640) {
      doc.addPage();
      y = 45;
    }
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('6. Submitted Quarterly Reports (Q1–Q4 Monitoring)', 40, y);
    y += 8;

    autoTable(doc, {
      startY: y,
      head: [
        [
          'Qtr',
          'Planned vs Actual Activity',
          'Pax (Plan/Act)',
          'KPI %',
          'Budget vs Actual Expense',
          'Results, Challenges & Next Actions',
        ],
      ],
      body: (plan.quarterlyReports || []).map((qr) => [
        qr.quarter,
        `Plan: ${qr.plannedActivity}\nActual: ${qr.actualActivity}`,
        `${qr.plannedParticipants} / ${qr.actualParticipants}`,
        `${qr.overallKpiScore}%`,
        `Alloc: ${qr.allocatedBudget.toLocaleString()}\nSpent: ${qr.actualExpense.toLocaleString()}\nVar: ${qr.budgetVariance.toLocaleString()}`,
        `Results: ${qr.results}\nChallenges: ${qr.challenges}\nLessons: ${qr.lessonsLearned}\nNext: ${qr.nextQuarterAction}`,
      ]),
      theme: 'grid',
      headStyles: { fillColor: [4, 120, 87], textColor: 255, fontSize: 8 },
      bodyStyles: { fontSize: 7.5 },
      margin: { left: 40, right: 40 },
    });

    y = (doc as any).lastAutoTable.finalY + 20;
  }

  // Section 7: Aggregated Annual Report
  const annual = plan.annualReport || aggregateQuarterlyReportsIntoAnnualReport(plan);
  if (y > 640) {
    doc.addPage();
    y = 45;
  }
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('7. Aggregated Annual Report Summary', 40, y);
  y += 8;

  autoTable(doc, {
    startY: y,
    head: [['Annual Metric', 'Aggregated Performance']],
    body: [
      ['Executive Summary', annual.executiveSummary],
      ['Quarters Reported', annual.quartersIncluded.join(', ') || 'None yet'],
      [
        'Participants (Expected vs Actual)',
        `${annual.totalExpectedParticipants.toLocaleString()} Planned / ${annual.totalActualParticipants.toLocaleString()} Actual (${annual.participantAchievementRate}%)`,
      ],
      [
        'Budget & Expense Monitoring',
        `Allocated: ${plan.currency || 'ETB'} ${annual.totalAllocatedBudget.toLocaleString()} | Spent: ${plan.currency || 'ETB'} ${annual.totalActualExpense.toLocaleString()} | Variance: ${plan.currency || 'ETB'} ${annual.totalBudgetVariance.toLocaleString()} (${annual.budgetUtilizationRate}% utilized)`,
      ],
      ['Overall KPI Achievement Rate', `${annual.overallKpiAchievementRate}%`],
      ['Key Achievements', annual.keyAchievements],
      ['Major Challenges', annual.majorChallenges],
      ['Lessons Learned', annual.lessonsLearned],
      ['Next-Year Strategic Recommendations', annual.strategicRecommendationsNextYear],
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 138], textColor: 255, fontSize: 8.5 },
    bodyStyles: { fontSize: 8 },
    columnStyles: { 0: { cellWidth: 160, fontStyle: 'bold' } },
    margin: { left: 40, right: 40 },
  });

  const arrayBuffer = doc.output('arraybuffer');
  return new Uint8Array(arrayBuffer);
}

/**
 * Generates a REAL binary Excel (.xlsx) workbook for a Ministry Annual Plan,
 * its Q1-Q4 milestones, 12-month timeline, KPIs, risks, quarterly reports, and aggregated annual report.
 */
export function buildMinistryPlanXlsxBuffer(plan: MinistryAnnualPlan): Uint8Array {
  const wb = XLSX.utils.book_new();

  // Sheet 1: Overview
  const overviewRows = [
    ['MINISTRY ANNUAL PLAN & WORKFLOW REPORT'],
    ['Plan Code', plan.planCode],
    ['Ministry', plan.ministryName],
    ['Year', plan.year],
    ['Plan Title', plan.title],
    ['Workflow Status', plan.status],
    ['Revision Number', plan.revisionNumber],
    ['Responsible Person', plan.responsiblePerson],
    ['Target Audience', plan.targetAudience],
    ['Expected Participants', plan.expectedParticipants],
    ['Required Resources', plan.requiredResources],
    ['Optional Budget', plan.optionalBudget],
    ['Currency', plan.currency || 'ETB'],
    ['Vision Statement', plan.visionStatement],
    ['Mitigation Summary', plan.mitigationSummary],
    ['Expected Outcomes', (plan.expectedOutcomes || []).join('; ')],
    ['Submitted By', plan.submittedByName || ''],
    ['Submitted At', plan.submittedAt || ''],
    ['Reviewed By', plan.reviewedByName || ''],
    ['Approved By', plan.approvedByName || ''],
    ['Approved At', plan.approvedAt || ''],
  ];
  const wsOverview = XLSX.utils.aoa_to_sheet(overviewRows);
  wsOverview['!cols'] = [{ wch: 28 }, { wch: 75 }];
  XLSX.utils.book_append_sheet(wb, wsOverview, '1_Plan_Overview');

  // Sheet 2: Objectives & KPIs
  const objRows = (plan.objectives || []).map((o, idx) => ({
    '#': idx + 1,
    Objective_Title: o.title,
    Description: o.description,
    Priority: o.priority,
    Target_Quarter: o.targetQuarter,
  }));
  const wsObjectives = XLSX.utils.json_to_sheet(
    objRows.length > 0
      ? objRows
      : [{ '#': 1, Objective_Title: 'None', Description: '', Priority: 'High', Target_Quarter: 'All Quarters' }]
  );
  wsObjectives['!cols'] = [{ wch: 6 }, { wch: 32 }, { wch: 50 }, { wch: 12 }, { wch: 16 }];
  XLSX.utils.book_append_sheet(wb, wsObjectives, '2_Objectives');

  const kpiRows = (plan.kpis || []).map((k, idx) => ({
    '#': idx + 1,
    KPI_Name: k.name,
    Unit: k.unit,
    Baseline: k.baselineValue,
    Target: k.targetValue,
    Weight_Percent: k.weightPercentage,
  }));
  const wsKpis = XLSX.utils.json_to_sheet(
    kpiRows.length > 0
      ? kpiRows
      : [{ '#': 1, KPI_Name: 'Default KPI', Unit: '%', Baseline: 0, Target: 100, Weight_Percent: 100 }]
  );
  wsKpis['!cols'] = [{ wch: 6 }, { wch: 35 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 16 }];
  XLSX.utils.book_append_sheet(wb, wsKpis, '3_KPIs');

  // Sheet 4: Quarterly Milestones (Q1-Q4)
  const qRows = (plan.quarterlyMilestones || []).map((qm) => ({
    Quarter: qm.quarter,
    Title: qm.title,
    Months: (qm.months || []).join(', '),
    Milestone_Summary: qm.milestoneSummary,
    Deliverables: (qm.deliverables || []).join(' | '),
    Planned_Activities_Count: qm.plannedActivitiesCount,
    Expected_Participants: qm.expectedParticipants,
    Allocated_Budget: qm.allocatedBudget,
    Responsible_Person: qm.responsiblePerson,
    Status: qm.status,
  }));
  const wsQuarters = XLSX.utils.json_to_sheet(qRows);
  wsQuarters['!cols'] = [
    { wch: 10 },
    { wch: 36 },
    { wch: 24 },
    { wch: 45 },
    { wch: 50 },
    { wch: 18 },
    { wch: 18 },
    { wch: 18 },
    { wch: 24 },
    { wch: 14 },
  ];
  XLSX.utils.book_append_sheet(wb, wsQuarters, '4_Quarterly_Q1_Q4');

  // Sheet 5: Monthly Timeline (Jan-Dec)
  const mRows = (plan.monthlyActivities || []).map((m) => ({
    Month_No: m.monthIndex,
    Month: m.month,
    Quarter: m.quarter,
    Focus_Theme: m.focusTheme,
    Monthly_Activities: (m.activities || []).join(' | '),
    Responsible_Person: m.responsiblePerson,
    Expected_Participants: m.expectedParticipants,
    Allocated_Budget: m.allocatedBudget,
    Required_Resources: m.requiredResources,
    Status: m.status,
  }));
  const wsMonthly = XLSX.utils.json_to_sheet(mRows);
  wsMonthly['!cols'] = [
    { wch: 10 },
    { wch: 14 },
    { wch: 10 },
    { wch: 38 },
    { wch: 50 },
    { wch: 24 },
    { wch: 18 },
    { wch: 18 },
    { wch: 32 },
    { wch: 14 },
  ];
  XLSX.utils.book_append_sheet(wb, wsMonthly, '5_Monthly_Timeline');

  // Sheet 6: Risks & Mitigation
  const rRows = (plan.risks || []).map((r, idx) => ({
    '#': idx + 1,
    Risk_Description: r.riskDescription,
    Severity: r.severity,
    Likelihood: r.likelihood,
    Mitigation_Strategy: r.mitigationPlan,
    Risk_Owner: r.owner,
  }));
  const wsRisks = XLSX.utils.json_to_sheet(
    rRows.length > 0
      ? rRows
      : [{ '#': 1, Risk_Description: 'None', Severity: 'Low', Likelihood: 'Low', Mitigation_Strategy: '', Risk_Owner: '' }]
  );
  wsRisks['!cols'] = [{ wch: 6 }, { wch: 40 }, { wch: 12 }, { wch: 12 }, { wch: 48 }, { wch: 22 }];
  XLSX.utils.book_append_sheet(wb, wsRisks, '6_Risks_Mitigation');

  // Sheet 7: Quarterly Reports
  const qrRows = (plan.quarterlyReports || []).map((qr) => ({
    Quarter: qr.quarter,
    Year: qr.year,
    Status: qr.status,
    Planned_Activity: qr.plannedActivity,
    Actual_Activity: qr.actualActivity,
    Planned_Participants: qr.plannedParticipants,
    Actual_Participants: qr.actualParticipants,
    Results: qr.results,
    Overall_KPI_Score_Percent: qr.overallKpiScore,
    Allocated_Budget: qr.allocatedBudget,
    Actual_Expense: qr.actualExpense,
    Budget_Variance: qr.budgetVariance,
    Budget_Expense_Monitoring_Notes: qr.budgetExpenseNotes,
    Challenges: qr.challenges,
    Lessons_Learned: qr.lessonsLearned,
    Next_Quarter_Action: qr.nextQuarterAction,
    Submitted_By: qr.submittedByName,
    Submitted_At: qr.submittedAt,
  }));
  const wsQuarterlyReports = XLSX.utils.json_to_sheet(
    qrRows.length > 0
      ? qrRows
      : [
          {
            Quarter: 'Q1',
            Year: plan.year,
            Status: 'Pending',
            Planned_Activity: '',
            Actual_Activity: '',
            Planned_Participants: 0,
            Actual_Participants: 0,
            Results: '',
            Overall_KPI_Score_Percent: 0,
            Allocated_Budget: 0,
            Actual_Expense: 0,
            Budget_Variance: 0,
            Budget_Expense_Monitoring_Notes: '',
            Challenges: '',
            Lessons_Learned: '',
            Next_Quarter_Action: '',
            Submitted_By: '',
            Submitted_At: '',
          },
        ]
  );
  XLSX.utils.book_append_sheet(wb, wsQuarterlyReports, '7_Quarterly_Reports');

  // Sheet 8: Aggregated Annual Report
  const annual = plan.annualReport || aggregateQuarterlyReportsIntoAnnualReport(plan);
  const annualRows = [
    ['AGGREGATED ANNUAL MINISTRY REPORT', `${plan.ministryName} (${plan.year})`],
    ['Report Status', annual.status],
    ['Quarters Aggregated', annual.quartersIncluded.join(', ') || 'None'],
    ['Executive Summary', annual.executiveSummary],
    ['Total Expected Participants', annual.totalExpectedParticipants],
    ['Total Actual Participants', annual.totalActualParticipants],
    ['Participant Achievement Rate (%)', annual.participantAchievementRate],
    ['Total Allocated Budget', annual.totalAllocatedBudget],
    ['Total Actual Expense', annual.totalActualExpense],
    ['Total Budget Variance', annual.totalBudgetVariance],
    ['Budget Utilization Rate (%)', annual.budgetUtilizationRate],
    ['Overall KPI Achievement Rate (%)', annual.overallKpiAchievementRate],
    ['Key Achievements', annual.keyAchievements],
    ['Major Challenges', annual.majorChallenges],
    ['Lessons Learned', annual.lessonsLearned],
    ['Next-Year Strategic Recommendations', annual.strategicRecommendationsNextYear],
  ];
  const wsAnnual = XLSX.utils.aoa_to_sheet(annualRows);
  wsAnnual['!cols'] = [{ wch: 34 }, { wch: 80 }];
  XLSX.utils.book_append_sheet(wb, wsAnnual, '8_Annual_Report');

  const out = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  return new Uint8Array(out);
}

/**
 * Browser download helpers for PDF and Excel (.xlsx)
 */
export function downloadPlanPdfInBrowser(plan: MinistryAnnualPlan, filenameSuffix = 'Annual_Plan_and_Report') {
  const bytes = buildMinistryPlanPdfBuffer(plan);
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const safeMin = plan.ministryName.replace(/[^a-zA-Z0-9_-]/g, '_');
  a.href = url;
  a.download = `${safeMin}_${plan.year}_${filenameSuffix}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadPlanXlsxInBrowser(plan: MinistryAnnualPlan, filenameSuffix = 'Annual_Plan_and_Report') {
  const bytes = buildMinistryPlanXlsxBuffer(plan);
  const blob = new Blob([bytes], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const safeMin = plan.ministryName.replace(/[^a-zA-Z0-9_-]/g, '_');
  a.href = url;
  a.download = `${safeMin}_${plan.year}_${filenameSuffix}.xlsx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export const downloadMinistryPlanPdf = downloadPlanPdfInBrowser;
export const downloadMinistryPlanXlsx = downloadPlanXlsxInBrowser;
