import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/database.types';

const rawUrl = (
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_URL) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_URL) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_URL) ||
  ''
).trim();

export const supabaseUrl = rawUrl ? rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '') : '';

export const rawKey = (
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_ANON_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_ANON_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_SERVICE_ROLE_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_SECRET_KEY) ||
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
  (typeof process !== 'undefined' && process.env?.SUPABASE_PUBLISHABLE_KEY) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_ANON_KEY) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_PUBLISHABLE_KEY) ||
  ''
).trim();

export const isSecretKey = (key: string): boolean => {
  if (!key) return false;
  const k = key.trim().toLowerCase();
  return k.startsWith('sb_secret_') || k.includes('service_role') || k.includes('secret');
};

const isBrowser = typeof window !== 'undefined';
export const supabaseKey = isBrowser && isSecretKey(rawKey) ? '' : rawKey;

export const isConfigured = Boolean(
  supabaseUrl &&
  supabaseUrl.startsWith('http') &&
  !supabaseUrl.includes('placeholder') &&
  !supabaseUrl.includes('unconfigured') &&
  (isBrowser ? Boolean(supabaseKey && !isSecretKey(supabaseKey)) : Boolean(rawKey))
);
export const isSupabaseConfigured = isConfigured;

const effectiveKey = isBrowser
  ? (isConfigured ? supabaseKey : 'unconfigured-public-anon-key')
  : (rawKey || 'unconfigured-public-anon-key');

const effectiveUrl = (isConfigured || (!isBrowser && rawKey))
  ? supabaseUrl
  : 'https://unconfigured.supabase.local';

export const supabase = createClient<any>(
  effectiveUrl,
  effectiveKey,
  {
    auth: {
      persistSession: isBrowser,
      autoRefreshToken: isBrowser,
      detectSessionInUrl: isBrowser,
    },
  }
);

export const createTypedSupabaseClient = () =>
  createClient<Database>(
    effectiveUrl,
    effectiveKey,
    {
      auth: {
        persistSession: isBrowser,
        autoRefreshToken: isBrowser,
        detectSessionInUrl: isBrowser,
      },
    }
  );

export default supabase;
