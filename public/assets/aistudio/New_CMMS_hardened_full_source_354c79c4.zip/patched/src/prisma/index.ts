import { db } from '../../server/db';
import {
  Member,
  Branch,
  Ministry,
  AttendanceRecord,
  SystemUser,
  AuditLog,
  PrayerRequest,
  CounselingSession,
  WorkflowRequest,
} from '../types';

export interface TenantRecord {
  id: string;
  slug: string;
  name: string;
  customDomain?: string;
  defaultCurrency: string;
  timezone: string;
  status: 'Active' | 'Suspended' | 'Provisioning';
  createdAt: string;
  updatedAt: string;
}

export interface PastoralNoteRecord {
  id: string;
  tenantId: string;
  branchId: string;
  memberId: string;
  pastorUserId: string;
  category: 'Counseling' | 'Prayer Request' | 'Hospital Visitation' | 'Spiritual Guidance' | 'Disciplinary';
  confidentiality: 'Public' | 'Ministerial' | 'Confidential' | 'Strictly Confidential';
  summary: string;
  details: string;
  followUpRequired: boolean;
  followUpDate?: string;
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed';
  createdAt: string;
  updatedAt: string;
}

const DEFAULT_TENANT_ID = 'tenant-grace-main';

// In-Memory & Persistent ORM Client mirroring Prisma Query API
export class PrismaClient {
  private tenantId: string = DEFAULT_TENANT_ID;

  constructor(tenantId?: string) {
    if (tenantId) this.tenantId = tenantId;
  }

  public $setTenant(tenantId: string) {
    this.tenantId = tenantId;
    return this;
  }

  // 1. Tenant Operations
  public tenant = {
    findUnique: async ({ where }: { where: { id?: string; slug?: string } }) => {
      const branding = db.getBranding();
      return {
        id: where.id || DEFAULT_TENANT_ID,
        slug: where.slug || 'grace-cathedral',
        name: branding.churchName,
        defaultCurrency: 'ETB',
        timezone: 'Africa/Addis_Ababa',
        status: 'Active' as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    },
    findFirst: async () => {
      const branding = db.getBranding();
      return {
        id: DEFAULT_TENANT_ID,
        slug: 'grace-cathedral',
        name: branding.churchName,
        defaultCurrency: 'ETB',
        timezone: 'Africa/Addis_Ababa',
        status: 'Active' as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    },
  };

  // 2. User Operations
  public user = {
    findUnique: async ({ where }: { where: { email?: string; id?: string } }) => {
      const users = db.getState().systemUsers;
      return users.find(
        (u) =>
          (where.email && u.email.toLowerCase() === where.email.toLowerCase()) ||
          (where.id && u.id === where.id)
      ) || null;
    },
    findMany: async (args?: { where?: { tenantId?: string; branchId?: string; role?: string; status?: string } }) => {
      let list = [...db.getState().systemUsers];
      if (args?.where?.branchId && args.where.branchId !== 'all') {
        list = list.filter((u) => u.branchIds?.includes(args.where?.branchId || '') || u.branchName?.includes(args.where?.branchId || ''));
      }
      if (args?.where?.role) {
        list = list.filter((u) => u.role === args.where?.role);
      }
      if (args?.where?.status) {
        list = list.filter((u) => u.status === args.where?.status);
      }
      return list;
    },
    create: async ({ data }: { data: Partial<SystemUser> & { branchId?: string; photoUrl?: string } }) => {
      const newUser: SystemUser = {
        id: data.id || `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: data.name || 'User',
        email: data.email || `user-${Date.now()}@grace.org`,
        role: data.role || 'MANAGER',
        branchName: data.branchName || 'Headquarters Campus',
        branchIds: data.branchIds || (data.branchId ? [data.branchId] : ['br-1']),
        status: data.status || 'Active',
        isMfaEnabled: Boolean(data.isMfaEnabled || data.mfaEnabled),
        lastLogin: 'Never',
      };
      db.getState().systemUsers.unshift(newUser);
      db.persist();
      return newUser;
    },
    update: async ({ where, data }: { where: { id: string }; data: Partial<SystemUser> }) => {
      const user = db.getState().systemUsers.find((u) => u.id === where.id);
      if (!user) throw new Error(`User with ID ${where.id} not found`);
      Object.assign(user, data);
      db.persist();
      return user;
    },
    delete: async ({ where }: { where: { id: string } }) => {
      const state = db.getState();
      const idx = state.systemUsers.findIndex((u) => u.id === where.id);
      if (idx === -1) throw new Error(`User with ID ${where.id} not found`);
      const deleted = state.systemUsers.splice(idx, 1)[0];
      db.persist();
      return deleted;
    },
  };

  // 3. Branch Operations
  public branch = {
    findMany: async (args?: { where?: { status?: string } }) => {
      let list = [...db.getState().branches];
      if (args?.where?.status) list = list.filter((b) => b.status === args.where?.status);
      return list;
    },
    findUnique: async ({ where }: { where: { id: string } }) => {
      return db.getState().branches.find((b) => b.id === where.id) || null;
    },
    create: async ({ data }: { data: Branch }) => {
      const newBranch: Branch = {
        ...data,
        id: data.id || `br-${Date.now()}`,
      };
      db.getState().branches.unshift(newBranch);
      db.persist();
      return newBranch;
    },
    update: async ({ where, data }: { where: { id: string }; data: Partial<Branch> }) => {
      const branch = db.getState().branches.find((b) => b.id === where.id);
      if (!branch) throw new Error(`Branch with ID ${where.id} not found`);
      Object.assign(branch, data);
      db.persist();
      return branch;
    },
    delete: async ({ where }: { where: { id: string } }) => {
      const state = db.getState();
      const idx = state.branches.findIndex((b) => b.id === where.id);
      if (idx === -1) throw new Error(`Branch with ID ${where.id} not found`);
      const deleted = state.branches.splice(idx, 1)[0];
      db.persist();
      return deleted;
    },
  };

  // 4. Member Operations
  public member = {
    findMany: async (args?: { where?: { branchId?: string; search?: string; membershipStatus?: string } }) => {
      let list = [...db.getState().members];
      if (args?.where?.branchId && args.where.branchId !== 'all') {
        list = list.filter((m) => m.branchId === args.where?.branchId);
      }
      if (args?.where?.membershipStatus) {
        list = list.filter((m) => (m.membershipStatus as string) === args.where?.membershipStatus);
      }
      if (args?.where?.search) {
        const q = args.where.search.toLowerCase();
        list = list.filter(
          (m) =>
            m.firstName.toLowerCase().includes(q) ||
            m.lastName.toLowerCase().includes(q) ||
            m.primaryPhone.includes(q) ||
            m.memberIdNumber.toLowerCase().includes(q)
        );
      }
      return list;
    },
    findUnique: async ({ where }: { where: { id?: string; memberIdNumber?: string } }) => {
      return (
        db.getState().members.find(
          (m) =>
            (where.id && m.id === where.id) ||
            (where.memberIdNumber && m.memberIdNumber === where.memberIdNumber)
        ) || null
      );
    },
    create: async ({ data }: { data: Member }) => {
      const newMember: Member = {
        ...data,
        id: data.id || `mem-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      };
      db.getState().members.unshift(newMember);
      db.persist();
      return newMember;
    },
    createMany: async ({ data }: { data: Member[] }) => {
      const inserted: Member[] = [];
      for (const item of data) {
        const mem: Member = {
          ...item,
          id: item.id || `mem-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        };
        inserted.push(mem);
        db.getState().members.unshift(mem);
      }
      db.persist();
      return { count: inserted.length };
    },
    update: async ({ where, data }: { where: { id: string }; data: Partial<Member> }) => {
      const member = db.getState().members.find((m) => m.id === where.id);
      if (!member) throw new Error(`Member with ID ${where.id} not found`);
      Object.assign(member, data);
      db.persist();
      return member;
    },
    delete: async ({ where }: { where: { id: string } }) => {
      const state = db.getState();
      const idx = state.members.findIndex((m) => m.id === where.id);
      if (idx === -1) throw new Error(`Member with ID ${where.id} not found`);
      const deleted = state.members.splice(idx, 1)[0];
      db.persist();
      return deleted;
    },
  };

  // 5. Group / Ministry Operations
  public group = {
    findMany: async (args?: { where?: { branchId?: string; status?: string } }) => {
      let list = [...db.getState().ministries];
      if (args?.where?.branchId && args.where.branchId !== 'all') {
        list = list.filter((m) => m.branchId === args.where?.branchId);
      }
      return list;
    },
    create: async ({ data }: { data: Ministry }) => {
      const newMin: Ministry = {
        ...data,
        id: data.id || `min-${Date.now()}`,
      };
      db.getState().ministries.unshift(newMin);
      db.persist();
      return newMin;
    },
  };

  // 6. Attendance Operations
  public attendance = {
    findMany: async (args?: { where?: { branchId?: string; date?: string; memberId?: string } }) => {
      let list = [...db.getState().attendanceRecords];
      if (args?.where?.branchId && args.where.branchId !== 'all') {
        list = list.filter((a) => a.branchId === args.where?.branchId);
      }
      if (args?.where?.date) {
        list = list.filter((a) => a.date === args.where?.date);
      }
      if (args?.where?.memberId) {
        list = list.filter((a) => a.memberId === args.where?.memberId);
      }
      return list;
    },
    create: async ({ data }: { data: AttendanceRecord }) => {
      const newRecord: AttendanceRecord = {
        ...data,
        id: data.id || `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      };
      db.getState().attendanceRecords.unshift(newRecord);
      db.persist();
      return newRecord;
    },
    createMany: async ({ data }: { data: AttendanceRecord[] }) => {
      const inserted: AttendanceRecord[] = [];
      for (const item of data) {
        const rec: AttendanceRecord = {
          ...item,
          id: item.id || `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        };
        inserted.push(rec);
        db.getState().attendanceRecords.unshift(rec);
      }
      db.persist();
      return { count: inserted.length };
    },
  };

  // 7. Pastoral Note Operations
  public pastoralNote = {
    findMany: async (args?: { where?: { branchId?: string; memberId?: string; category?: string } }) => {
      const prayers = db.getState().prayerRequests;
      const sessions = db.getState().counselingSessions;
      
      const notes: PastoralNoteRecord[] = [
        ...prayers.map((p) => ({
          id: p.id,
          tenantId: DEFAULT_TENANT_ID,
          branchId: 'br-1',
          memberId: p.memberId || '',
          pastorUserId: 'pastor-1',
          category: 'Prayer Request' as const,
          confidentiality: (p.isConfidential ? 'Strictly Confidential' : 'Ministerial') as any,
          summary: p.title || p.category,
          details: p.description || '',
          followUpRequired: p.status !== 'Answered',
          status: (p.status === 'Answered' ? 'Resolved' : 'In Progress') as any,
          createdAt: p.submittedDate || new Date().toISOString(),
          updatedAt: p.submittedDate || new Date().toISOString(),
        })),
        ...sessions.map((s) => ({
          id: s.id,
          tenantId: DEFAULT_TENANT_ID,
          branchId: 'br-1',
          memberId: s.clientMemberId || '',
          pastorUserId: s.counselorName || 'pastor-1',
          category: 'Counseling' as const,
          confidentiality: 'Confidential' as const,
          summary: `${s.counselorName} - ${s.counselingType}`,
          details: s.encryptedCaseNotes || 'Confidential Counseling Note',
          followUpRequired: false,
          followUpDate: s.sessionDate,
          status: (s.status === 'Completed' ? 'Resolved' : 'Open') as any,
          createdAt: s.sessionDate || new Date().toISOString(),
          updatedAt: s.sessionDate || new Date().toISOString(),
        })),
      ];

      let filtered = notes;
      if (args?.where?.branchId && args.where.branchId !== 'all') {
        filtered = filtered.filter((n) => n.branchId === args.where?.branchId);
      }
      if (args?.where?.memberId) {
        filtered = filtered.filter((n) => n.memberId === args.where?.memberId);
      }
      return filtered;
    },
    create: async ({ data }: { data: Partial<PastoralNoteRecord> }) => {
      const newSession: CounselingSession = {
        id: data.id || `coun-${Date.now()}`,
        sessionCode: `CS-${Date.now()}`,
        clientMemberId: data.memberId || '',
        clientName: data.summary || 'Member Care',
        counselorName: data.pastorUserId || 'Senior Pastor',
        counselingType: 'Spiritual',
        sessionDate: new Date().toISOString().split('T')[0],
        sessionTime: '10:00 AM',
        mode: 'In-Person',
        status: (data.status === 'Resolved' ? 'Completed' : 'Scheduled') as any,
        encryptedCaseNotes: data.details || data.summary || '',
      };
      db.getState().counselingSessions.unshift(newSession);
      db.persist();
      return data;
    },
  };

  // 8. Audit Log Operations
  public auditLog = {
    findMany: async (args?: { where?: { module?: string; userEmail?: string }; take?: number }) => {
      let logs = [...db.getState().auditLogs];
      if (args?.where?.module) logs = logs.filter((l) => l.module === args.where?.module);
      if (args?.where?.userEmail) logs = logs.filter((l) => l.userEmail.toLowerCase() === args.where?.userEmail?.toLowerCase());
      if (args?.take) logs = logs.slice(0, args.take);
      return logs;
    },
    create: async ({ data }: { data: Partial<AuditLog> }) => {
      db.addAuditLog(data);
      return data;
    },
  };

  // 9. Workflow & Approval Queue
  public workflow = {
    findMany: async (args?: { where?: { status?: string; branchId?: string } }) => {
      let list = [...db.getState().workflows];
      if (args?.where?.status) list = list.filter((w) => w.status === args.where?.status);
      if (args?.where?.branchId && args.where.branchId !== 'all') list = list.filter((w) => w.branchId === args.where?.branchId);
      return list;
    },
    create: async ({ data }: { data: WorkflowRequest }) => {
      const req: WorkflowRequest = {
        ...data,
        id: data.id || `wf-${Date.now()}`,
      };
      db.getState().workflows.unshift(req);
      db.persist();
      return req;
    },
    update: async ({ where, data }: { where: { id: string }; data: Partial<WorkflowRequest> }) => {
      const wf = db.getState().workflows.find((w) => w.id === where.id);
      if (!wf) throw new Error(`Workflow with ID ${where.id} not found`);
      Object.assign(wf, data);
      db.persist();
      return wf;
    },
  };
}

export const prisma = new PrismaClient();
