import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { VisitationRecord } from '../types';
import {
  UserMinus,
  Plus,
  Heart,
  MapPin,
  Calendar,
  CheckCircle2,
  X,
  PhoneCall,
} from 'lucide-react';

export const VisitationCareModule: React.FC = () => {
  const { visitations, addVisitationRecord, members, permissions, currentUser } = useCMMS();
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  const [memberId, setMemberId] = useState(members[0]?.id || '');
  const [visitationType, setVisitationType] =
    useState<VisitationRecord['visitationType']>('Sick Member / Hospital');
  const [summaryNotes, setSummaryNotes] = useState('');

  const handleLogVisit = (e: React.FormEvent) => {
    e.preventDefault();
    const mem = members.find((m) => m.id === memberId);

    const newVis: VisitationRecord = {
      id: `vis-${Date.now().toString().slice(-4)}`,
      visitationCode: `VST-2026-${Math.floor(100 + Math.random() * 900)}`,
      memberId: mem?.id || '',
      memberName: mem ? `${mem.firstName} ${mem.lastName}` : 'Member',
      visitorNames: [currentUser?.name || 'Pastoral Care Team'],
      visitationType,
      visitDate: new Date().toISOString().split('T')[0],
      location: mem?.streetAddress || 'Member Residence',
      summaryNotes,
      prayerPoints: ['Pastoral care blessing', 'Health recovery'],
      followUpRequired: true,
      status: 'Completed',
    };

    addVisitationRecord(newVis);
    setIsLogModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <UserMinus className="w-6 h-6 text-amber-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Pastoral Visitation & Care Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200">
              {visitations.length} Pastoral Visits Logged
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Hospital visits, bereavement support, inactive re-engagement, and missing member tracking.
          </p>
        </div>

        {permissions.canEditMembers && (
          <button
            onClick={() => setIsLogModalOpen(true)}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Log Pastoral Visitation
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {visitations.map((v) => (
          <div
            key={v.id}
            className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                {v.visitationCode}
              </span>
              <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-amber-100 text-amber-800">
                {v.visitationType}
              </span>
            </div>

            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Member: {v.memberName}</h3>
              <p className="text-slate-500">Visitors: {v.visitorNames.join(', ')}</p>
              <p className="text-slate-500 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3.5 h-3.5" /> {v.location}
              </p>
            </div>

            <p className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-300 italic">
              "{v.summaryNotes}"
            </p>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Visited on: {v.visitDate}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                {v.status}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Log Visitation Modal */}
      {isLogModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Log Pastoral Visitation</h3>
              <button onClick={() => setIsLogModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleLogVisit} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1">Select Member Visited</label>
                <select
                  value={memberId}
                  onChange={(e) => setMemberId(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Visitation Category</label>
                <select
                  value={visitationType}
                  onChange={(e) => setVisitationType(e.target.value as any)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Sick Member / Hospital">Sick Member / Hospital</option>
                  <option value="New Convert">New Convert Follow-up</option>
                  <option value="Bereavement">Bereavement Support</option>
                  <option value="Inactive Re-engagement">Inactive Re-engagement</option>
                  <option value="Missing Member">Missing Member Investigation</option>
                  <option value="Elderly Care">Elderly Home Care</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Conversation & Care Summary</label>
                <textarea
                  rows={3}
                  required
                  value={summaryNotes}
                  onChange={(e) => setSummaryNotes(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsLogModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-amber-600 text-white rounded-xl font-semibold">
                  Save Visit Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
