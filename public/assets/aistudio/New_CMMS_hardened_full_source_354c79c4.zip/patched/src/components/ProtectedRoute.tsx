import React from 'react';
import { Navigate, useLocation, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { normalizeUserRole } from '../utils/rbac';
import { UserRole } from '../types';

export interface ProtectedRouteProps {
  children?: React.ReactNode;
  allowedRoles?: UserRole[];
  fallbackModule?: string;
  redirectToLogin?: boolean;
}

/**
 * Frontend Route Guard Component
 * Enforces strict 3-state authentication:
 * 1. LOADING -> Renders clean security verification spinner (prevents dashboard flash)
 * 2. UNAUTHENTICATED -> Immediately redirects to /login with redirect query param
 * 3. AUTHENTICATED -> Evaluates role/permission access control
 */
export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  allowedRoles,
  fallbackModule = 'dashboard',
}) => {
  const { userProfile, loading, userRole, getDefaultRouteForRole } = useAuth();
  const location = useLocation();

  // 1. Authentication is still resolving -> Render clean, non-flashing loading state
  if (loading) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="w-full min-h-[60vh] flex flex-col items-center justify-center space-y-4 p-8"
      >
        <div className="w-10 h-10 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
        <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 animate-pulse">
          Verifying security credentials...
        </p>
      </div>
    );
  }

  // 2. Unauthenticated -> Redirect immediately to /login
  if (!userProfile) {
    const redirectTarget = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/login?redirect=${redirectTarget}`} state={{ from: location }} replace />;
  }

  // 3. Mandatory First-Login Password Change Gate (Enforced universally, even for SYSTEM_ADMIN)
  const mustChange = Boolean(userProfile.must_change_password || (userProfile as any).mustChangePassword);
  if (mustChange && location.pathname !== '/change-password') {
    return <Navigate to="/change-password" replace />;
  }

  const normRole = normalizeUserRole(userRole);

  // 4. SYSTEM_ADMIN has universal access (only after password change)
  if (normRole === 'SYSTEM_ADMIN') {
    return <>{children || <Outlet />}</>;
  }

  // 5. Check allowed roles array
  if (allowedRoles && allowedRoles.length > 0) {
    const isAuthorized = allowedRoles.some((r) => normalizeUserRole(r) === normRole);

    if (!isAuthorized) {
      // Direct redirect to default authorized route for this role to prevent address bar bypass
      const targetFallback = getDefaultRouteForRole(normRole) || fallbackModule;
      const targetPath = targetFallback.startsWith('/') ? targetFallback : `/${targetFallback}`;
      
      // If user is already on the target path, avoid loop
      if (location.pathname === targetPath) {
        return <Navigate to="/devotions" replace />;
      }

      return <Navigate to={targetPath} replace />;
    }
  }

  return <>{children || <Outlet />}</>;
};

export default ProtectedRoute;
