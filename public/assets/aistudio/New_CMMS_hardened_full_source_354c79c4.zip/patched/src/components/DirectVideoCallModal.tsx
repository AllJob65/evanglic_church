import React, { useState, useEffect } from 'react';
import { useTranslation } from '../i18n/LanguageContext';
import { apiService } from '../services/api';
import { getClientSocket } from '../services/clientSocket';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  PhoneOff,
  Maximize2,
  Minimize2,
  Shield,
  User,
  ExternalLink,
  Lock,
} from 'lucide-react';

export interface DirectVideoCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  conversationId: string;
  roomUrl: string;
  remoteParticipantName: string;
  remoteParticipantRole?: string;
  remoteParticipantAvatar?: string;
  isIncomingCall?: boolean;
}

export const DirectVideoCallModal: React.FC<DirectVideoCallModalProps> = ({
  isOpen,
  onClose,
  conversationId,
  roomUrl,
  remoteParticipantName,
  remoteParticipantRole,
  remoteParticipantAvatar,
  isIncomingCall = false,
}) => {
  const { t } = useTranslation();
  const [callStatus, setCallStatus] = useState<'calling' | 'connected' | 'ended'>('calling');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  // Timer when connected
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (callStatus === 'connected') {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [callStatus]);

  // Socket listener for call events
  useEffect(() => {
    if (!isOpen || !conversationId) return;

    const socket = getClientSocket();

    const handleCallAccepted = (data: { conversationId: string }) => {
      if (data.conversationId === conversationId) {
        setCallStatus('connected');
      }
    };

    const handleCallDeclined = (data: { conversationId: string }) => {
      if (data.conversationId === conversationId) {
        setCallStatus('ended');
      }
    };

    const handleCallEnded = (data: { conversationId: string }) => {
      if (data.conversationId === conversationId) {
        setCallStatus('ended');
      }
    };

    socket.on('direct_video:call_accepted', handleCallAccepted);
    socket.on('direct_video:call_declined', handleCallDeclined);
    socket.on('direct_video:call_ended', handleCallEnded);

    // If recipient accepted immediately on answer, set connected
    if (isIncomingCall) {
      setCallStatus('connected');
    }

    return () => {
      socket.off('direct_video:call_accepted', handleCallAccepted);
      socket.off('direct_video:call_declined', handleCallDeclined);
      socket.off('direct_video:call_ended', handleCallEnded);
    };
  }, [isOpen, conversationId, isIncomingCall]);

  if (!isOpen) return null;

  const handleEndCall = async () => {
    try {
      const socket = getClientSocket();
      socket.emit('direct_video:end_call', { conversationId });
      await apiService.endDirectVideoCall(conversationId);
    } catch (err) {
      console.warn('Error ending call:', err);
    } finally {
      setCallStatus('ended');
      setTimeout(() => {
        onClose();
        setCallDuration(0);
        setCallStatus('calling');
      }, 500);
    }
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Construct Jitsi iframe URL with clean configuration
  const iframeSrc = `${roomUrl}#config.prejoinPageEnabled=false&config.startWithAudioMuted=${isMuted}&config.startWithVideoMuted=${isVideoOff}&interfaceConfig.SHOW_JITSI_WATERMARK=false&interfaceConfig.SHOW_WATERMARK_FOR_GUESTS=false`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div
        className={`bg-slate-900 border border-slate-700/80 rounded-3xl overflow-hidden shadow-2xl flex flex-col transition-all duration-300 ${
          isFullscreen
            ? 'w-full h-full fixed inset-0 rounded-none'
            : 'w-full max-w-4xl h-[88vh] max-h-[780px]'
        }`}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-850/90 border-b border-slate-800 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5">
                  <span>{remoteParticipantName || t('member', 'Member')}</span>
                  {remoteParticipantRole && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-900/60 text-blue-300 border border-blue-700/50">
                      {remoteParticipantRole}
                    </span>
                  )}
                </h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800">
                  <Lock className="w-3 h-3 text-emerald-400" />
                  {t('private_1on1', '1:1 Private Video')}
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                {callStatus === 'calling' && (
                  <span className="text-amber-400 flex items-center gap-1.5 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    {t('calling_status', 'Calling participant...')}
                  </span>
                )}
                {callStatus === 'connected' && (
                  <span className="text-emerald-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    {t('connected', 'Connected')} • {formatDuration(callDuration)}
                  </span>
                )}
                {callStatus === 'ended' && (
                  <span className="text-rose-400">{t('call_ended', 'Call ended')}</span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={roomUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[44px] min-w-[44px] p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all flex items-center justify-center cursor-pointer border border-slate-700"
              title={t('open_external', 'Open in external tab')}
            >
              <ExternalLink className="w-4 h-4" />
            </a>
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="min-h-[44px] min-w-[44px] p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all flex items-center justify-center cursor-pointer border border-slate-700"
              title={isFullscreen ? t('exit_fullscreen', 'Exit Fullscreen') : t('fullscreen', 'Fullscreen')}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Video Frame or Ringing Display */}
        <div className="flex-1 relative bg-slate-950 flex items-center justify-center overflow-hidden">
          {callStatus === 'calling' && (
            <div className="text-center p-8 space-y-6 max-w-md animate-in zoom-in-95">
              <div className="relative mx-auto w-28 h-28">
                <div className="absolute inset-0 rounded-full bg-blue-600/20 animate-ping"></div>
                <div className="absolute inset-2 rounded-full bg-blue-500/30 animate-pulse"></div>
                <div className="relative w-28 h-28 rounded-full overflow-hidden border-2 border-blue-400 shadow-xl flex items-center justify-center bg-slate-800">
                  {remoteParticipantAvatar ? (
                    <img
                      src={remoteParticipantAvatar}
                      alt={remoteParticipantName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="w-12 h-12 text-slate-400" />
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white">{remoteParticipantName}</h3>
                <p className="text-xs text-slate-400 mt-1">
                  {t('ringing_prompt', 'Waiting for member to answer private video counseling call...')}
                </p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={handleEndCall}
                  className="min-h-[44px] px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span>{t('cancel_call', 'Cancel Call')}</span>
                </button>
              </div>
            </div>
          )}

          {callStatus === 'connected' && (
            <iframe
              src={iframeSrc}
              title="1:1 Direct Video Call"
              allow="camera; microphone; display-capture; autoplay; clipboard-write"
              className="w-full h-full border-0"
            />
          )}

          {callStatus === 'ended' && (
            <div className="text-center p-8 space-y-4 animate-in fade-in">
              <div className="w-16 h-16 rounded-full bg-rose-900/40 border border-rose-700/50 flex items-center justify-center text-rose-400 mx-auto">
                <PhoneOff className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-white">{t('call_ended', 'Call Ended')}</h3>
              <p className="text-xs text-slate-400">
                {t('call_duration_notice', { duration: formatDuration(callDuration) })}
              </p>
              <button
                onClick={onClose}
                className="min-h-[44px] px-6 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all cursor-pointer"
              >
                {t('close', 'Close')}
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {callStatus === 'connected' && (
          <div className="px-6 py-3.5 bg-slate-900 border-t border-slate-800 flex items-center justify-center gap-4 shrink-0">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`min-h-[44px] min-w-[44px] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer border ${
                isMuted
                  ? 'bg-rose-600/20 text-rose-400 border-rose-600/40 hover:bg-rose-600/30'
                  : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              <span>{isMuted ? t('unmute', 'Unmute') : t('mute', 'Mute')}</span>
            </button>

            <button
              onClick={() => setIsVideoOff(!isVideoOff)}
              className={`min-h-[44px] min-w-[44px] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer border ${
                isVideoOff
                  ? 'bg-rose-600/20 text-rose-400 border-rose-600/40 hover:bg-rose-600/30'
                  : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
              <span>{isVideoOff ? t('start_cam', 'Start Cam') : t('stop_cam', 'Stop Cam')}</span>
            </button>

            <button
              onClick={handleEndCall}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer"
            >
              <PhoneOff className="w-4 h-4" />
              <span>{t('end_call', 'End Call')}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
