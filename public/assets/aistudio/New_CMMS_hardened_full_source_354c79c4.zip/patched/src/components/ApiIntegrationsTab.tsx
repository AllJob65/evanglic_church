import React, { useState, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Globe,
  Radio,
  BookOpen,
  Send,
  CheckCircle,
  Key,
  Server,
  Zap,
  Copy,
  Check,
  Search,
  MessageSquare,
  ShieldCheck,
  Smartphone,
  Sparkles,
} from 'lucide-react';

export const ApiIntegrationsTab: React.FC = () => {
  const { addAuditLog, sendCommunication } = useCMMS();

  // SMS Gateway State (Strictly Ethio Telecom)
  const [testRecipient, setTestRecipient] = useState('+251911223344');
  const [testMessage, setTestMessage] = useState('Grace Cathedral: Blessed Sunday! "The Lord bless you and keep you" (Num 6:24).');
  const [smsSending, setSmsSending] = useState(false);
  const [smsResult, setSmsResult] = useState<any>(null);

  // Bible API State
  const [bibleSearchQuery, setBibleSearchQuery] = useState('God');
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'am' | 'om' | 'ti'>('en');
  const [bibleResults, setBibleResults] = useState<any[]>([]);
  const [verseOfTheDay, setVerseOfTheDay] = useState<any>(null);
  const [copiedVerse, setCopiedVerse] = useState<string | null>(null);

  useEffect(() => {
    // Fetch Verse of the day
    fetch('/api/integrations/bible/verse-of-the-day')
      .then((res) => res.json())
      .then((data) => setVerseOfTheDay(data))
      .catch((e) => console.warn('Verse of day fetch error:', e));

    // Fetch initial Bible search
    handleSearchBible('peace');
  }, []);

  const handleSearchBible = async (query = bibleSearchQuery) => {
    try {
      const res = await fetch(`/api/integrations/bible/search?q=${encodeURIComponent(query)}&lang=${selectedLanguage}`);
      const data = await res.json();
      setBibleResults(data.verses || []);
    } catch (err) {
      console.warn('Bible search error:', err);
    }
  };

  const handleSendTestSms = async (e: React.FormEvent) => {
    e.preventDefault();
    setSmsSending(true);
    setSmsResult(null);

    try {
      const res = await fetch('/api/integrations/sms/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gateway: 'EthioTelecom',
          recipients: [testRecipient],
          message: testMessage,
          senderId: 'GRACECATH',
        }),
      });
      const data = await res.json();
      setSmsResult(data);

      addAuditLog(
        'SMS Gateway API Test',
        'API Integrations',
        `Dispatched test SMS to ${testRecipient} via Ethio Telecom REST Gateway`
      );
    } catch (err: any) {
      setSmsResult({ error: err.message || 'Failed to dispatch SMS' });
    } finally {
      setSmsSending(false);
    }
  };

  const handleCopyScripture = (text: string, ref: string) => {
    navigator.clipboard.writeText(`"${text}" — ${ref}`);
    setCopiedVerse(ref);
    setTimeout(() => setCopiedVerse(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-gradient-to-r from-blue-500/10 via-indigo-500/10 to-emerald-500/10 dark:from-blue-950/40 dark:to-emerald-950/40 border border-blue-200 dark:border-blue-900 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Sovereign API Integrations Gateway
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Integrated API connectors for Ethio Telecom REST SMS Gateway and Multilingual Scripture Engines.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 rounded-full text-xs font-bold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Gateways Online
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ================= SECTION 1: SMS GATEWAY API ================= */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-blue-600" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Ethio Telecom SMS Gateway</h4>
            </div>
            <span className="text-[11px] font-mono font-bold text-slate-500">Balance: 4,250 Credits</span>
          </div>

          {/* Active Provider Badge */}
          <div className="p-3.5 rounded-xl border border-blue-500/40 bg-blue-50/50 dark:bg-blue-950/40 flex items-center justify-between">
            <div>
              <p className="font-bold text-xs text-slate-900 dark:text-white">Ethio Telecom REST SMS</p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Direct HTTP REST endpoint (/sms/v1/send)</p>
            </div>
            <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/60 px-2 py-0.5 rounded-md">
              Exclusive Gateway
            </span>
          </div>

          {/* Test SMS Dispatch Form */}
          <form onSubmit={handleSendTestSms} className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Recipient Phone Number (Ethiopian format: +251 9/7... or 09/07... 10 digits):
              </label>
              <input
                type="text"
                required
                value={testRecipient}
                onChange={(e) => setTestRecipient(e.target.value)}
                placeholder="+251911223344 or 0911223344"
                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Message Body:</label>
                <span className="text-[10px] text-slate-400 font-mono">
                  {testMessage.length} chars ({Math.ceil(testMessage.length / 160)} SMS segment)
                </span>
              </div>
              <textarea
                rows={3}
                required
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <button
              type="submit"
              disabled={smsSending}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" /> {smsSending ? 'Dispatching via Gateway...' : 'Send Test SMS Message'}
            </button>
          </form>

          {smsResult && (
            <div
              className={`p-3 rounded-xl text-xs font-mono border ${
                smsResult.success
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                  : 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
              }`}
            >
              {smsResult.success ? (
                <div>
                  <p className="font-bold flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Dispatch Success (ID: {smsResult.dispatchId})
                  </p>
                  <p className="text-[10px] mt-1 text-slate-600 dark:text-slate-400">
                    Sent to: {smsResult.successfulNumbers?.join(', ')} via {smsResult.gatewayUsed}
                  </p>
                </div>
              ) : (
                <p className="font-bold">Error: {smsResult.error || 'Failed to dispatch'}</p>
              )}
            </div>
          )}
        </div>

        {/* ================= SECTION 2: BIBLE SCRIPTURE API ================= */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Multilingual Bible API Explorer</h4>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold">
              {(['en', 'am', 'om', 'ti'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => {
                    setSelectedLanguage(l);
                    handleSearchBible(bibleSearchQuery);
                  }}
                  className={`px-2 py-0.5 rounded uppercase ${
                    selectedLanguage === l
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          {/* Verse of the day card */}
          {verseOfTheDay && (
            <div className="p-3.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-xs">
              <div className="flex items-center justify-between font-bold text-indigo-900 dark:text-indigo-200 mb-1">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" /> Verse of the Day: {verseOfTheDay.reference}
                </span>
                <span className="text-[10px] uppercase">{verseOfTheDay.theme}</span>
              </div>
              <p className="text-slate-800 dark:text-slate-200 italic mt-1">
                "{selectedLanguage === 'am' ? verseOfTheDay.text_am : selectedLanguage === 'om' ? verseOfTheDay.text_om : selectedLanguage === 'ti' ? verseOfTheDay.text_ti : verseOfTheDay.text_en}"
              </p>
            </div>
          )}

          {/* Search bar */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={bibleSearchQuery}
                onChange={(e) => setBibleSearchQuery(e.target.value)}
                placeholder="Search Bible by keyword (e.g. peace, grace, trust, hope)..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>
            <button
              onClick={() => handleSearchBible(bibleSearchQuery)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold cursor-pointer"
            >
              Search
            </button>
          </div>

          {/* Search results list */}
          <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
            {bibleResults.map((v) => (
              <div
                key={v.reference}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                  <span>{v.reference}</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleCopyScripture(v.text, v.reference)}
                      className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-[10px] font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      {copiedVerse === v.reference ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      {copiedVerse === v.reference ? 'Copied' : 'Copy'}
                    </button>
                    <button
                      onClick={() => {
                        setTestMessage(`"${v.text}" — ${v.reference}`);
                        addAuditLog('Loaded Scripture to SMS', 'Communications', `Selected ${v.reference} for SMS broadcast`);
                      }}
                      className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 hover:bg-blue-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Send className="w-3 h-3" /> Use in SMS
                    </button>
                  </div>
                </div>
                <p className="text-slate-700 dark:text-slate-300 text-[11px] leading-relaxed italic">
                  "{v.text}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
