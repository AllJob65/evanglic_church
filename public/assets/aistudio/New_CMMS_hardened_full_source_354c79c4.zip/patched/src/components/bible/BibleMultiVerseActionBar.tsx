import React from 'react';
import {
  FileText,
  Copy,
  Share2,
  X,
  Check,
  Bookmark,
  SunMedium,
  Radio,
  Send,
} from 'lucide-react';
import { BibleVerseItem, BibleBookInfo } from '../../data/bibleCanon';

export interface BibleMultiVerseActionBarProps {
  selectedVerses: BibleVerseItem[];
  bookEnglish?: string;
  bookAmharic?: string;
  currentBook?: BibleBookInfo;
  chapterNum?: number;
  chapterNumber?: number;
  onClearSelection: () => void;
  onOpenNoteModal?: () => void;
  onOpenDevotionModal?: () => void;
  onApplyHighlight?: (color: 'yellow' | 'green' | 'blue' | 'rose' | 'purple') => void;
  onHighlightVerses?: (color: 'yellow' | 'green' | 'blue' | 'rose' | 'purple') => void;
  onCopySelected?: () => void;
  onCopyVerses?: () => void;
  onShareSelected?: () => void;
  onShareVerses?: () => void;
  onBookmarkVerses?: () => void;
  onBroadcastVerses?: () => void;
  onComposeMessage?: () => void;
  onPostDevotionalToMembers?: () => void;
  isPastorOrAdmin?: boolean;
  isCopied?: boolean;
}

export const BibleMultiVerseActionBar: React.FC<BibleMultiVerseActionBarProps> = ({
  selectedVerses,
  bookEnglish,
  bookAmharic,
  currentBook,
  chapterNum,
  chapterNumber,
  onClearSelection,
  onOpenNoteModal,
  onOpenDevotionModal,
  onApplyHighlight,
  onHighlightVerses,
  onCopySelected,
  onCopyVerses,
  onShareSelected,
  onShareVerses,
  onBookmarkVerses,
  onBroadcastVerses,
  onComposeMessage,
  onPostDevotionalToMembers,
  isPastorOrAdmin = false,
  isCopied = false,
}) => {
  if (selectedVerses.length === 0) return null;

  const bEng = bookEnglish || currentBook?.nameEnglish || '';
  const bAmh = bookAmharic || currentBook?.nameAmharic || '';
  const chNum = chapterNumber || chapterNum || 1;

  // Format verse range (e.g. "John 3:16-18" or "John 3:16, 18, 20")
  const verseNumbers = selectedVerses
    .map((v) => (v.verse !== undefined ? v.verse : v.verseNumber))
    .sort((a, b) => a - b);
  const isContinuous =
    verseNumbers.length > 1 &&
    verseNumbers[verseNumbers.length - 1] - verseNumbers[0] === verseNumbers.length - 1;
  const rangeCitation = isContinuous
    ? `${bEng} ${chNum}:${verseNumbers[0]}–${verseNumbers[verseNumbers.length - 1]}`
    : `${bEng} ${chNum}:${verseNumbers.join(', ')}`;

  const amhRangeCitation = isContinuous
    ? `${bAmh} ${chNum}፥${verseNumbers[0]}–${verseNumbers[verseNumbers.length - 1]}`
    : `${bAmh} ${chNum}፥${verseNumbers.join('፣ ')}`;

  const handleHighlight = onHighlightVerses || onApplyHighlight;
  const handleCopy = onCopyVerses || onCopySelected;
  const handleShare = onShareVerses || onShareSelected;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-11/12 max-w-3xl animate-in slide-in-from-bottom-5">
      <div className="bg-slate-900/95 text-white backdrop-blur-md rounded-2xl p-3 sm:p-4 shadow-2xl border border-slate-700/80 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Left: Selected indicator & citation */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-blue-600 text-xs font-black text-white">
              {selectedVerses.length}
            </span>
            <div className="min-w-0">
              <div className="text-xs font-black text-amber-300 truncate">
                {rangeCitation}
              </div>
              <div className="text-[11px] text-slate-300 truncate font-menbere">
                {amhRangeCitation}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClearSelection}
            className="sm:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            title="Deselect all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center flex-wrap sm:flex-nowrap gap-1.5 w-full sm:w-auto justify-center sm:justify-end">
          {/* Color Highlighting Group */}
          {handleHighlight && (
            <div className="flex items-center gap-1 px-2 py-1 bg-slate-800 rounded-xl border border-slate-700">
              <button
                type="button"
                onClick={() => handleHighlight('yellow')}
                className="w-5 h-5 rounded-full bg-amber-400 hover:scale-110 transition-transform shadow-xs cursor-pointer"
                title="Highlight Yellow"
              />
              <button
                type="button"
                onClick={() => handleHighlight('green')}
                className="w-5 h-5 rounded-full bg-emerald-400 hover:scale-110 transition-transform shadow-xs cursor-pointer"
                title="Highlight Green"
              />
              <button
                type="button"
                onClick={() => handleHighlight('blue')}
                className="w-5 h-5 rounded-full bg-cyan-400 hover:scale-110 transition-transform shadow-xs cursor-pointer"
                title="Highlight Blue"
              />
              <button
                type="button"
                onClick={() => handleHighlight('rose')}
                className="w-5 h-5 rounded-full bg-rose-400 hover:scale-110 transition-transform shadow-xs cursor-pointer"
                title="Highlight Rose"
              />
              <button
                type="button"
                onClick={() => handleHighlight('purple')}
                className="w-5 h-5 rounded-full bg-purple-400 hover:scale-110 transition-transform shadow-xs cursor-pointer"
                title="Highlight Purple"
              />
            </div>
          )}

          {/* Private Note Button (For Any Authenticated Member - STRICTLY CONFIDENTIAL) */}
          {onOpenNoteModal && (
            <button
              type="button"
              id="multi-verse-note-btn"
              onClick={onOpenNoteModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold transition-all border border-slate-700 cursor-pointer"
              title="Add Private Study Note (Confidential to You)"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>Private Note</span>
            </button>
          )}

          {/* Post to Members (PASTOR / SYSTEM_ADMIN Only - Church Daily Devotion) */}
          {isPastorOrAdmin && (onPostDevotionalToMembers || onOpenDevotionModal) && (
            <button
              type="button"
              id="multi-verse-post-devotion-btn"
              onClick={onPostDevotionalToMembers || onOpenDevotionModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              title="Post Church Daily Devotional to Members (Pastor & System Admin)"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post to Members</span>
            </button>
          )}

          {/* Bookmark Button */}
          {onBookmarkVerses && (
            <button
              type="button"
              id="multi-verse-bookmark-btn"
              onClick={onBookmarkVerses}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
              title="Bookmark Verses"
            >
              <Bookmark className="w-4 h-4" />
            </button>
          )}

          {/* Broadcast Button */}
          {onBroadcastVerses && (
            <button
              type="button"
              id="multi-verse-broadcast-btn"
              onClick={onBroadcastVerses}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 hover:text-purple-200 transition-colors"
              title="Broadcast Verses to Screen"
            >
              <Radio className="w-4 h-4" />
            </button>
          )}

          {/* Copy Button */}
          {handleCopy && (
            <button
              type="button"
              id="multi-verse-copy-btn"
              onClick={handleCopy}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
              title="Copy Verses"
            >
              {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          )}

          {/* Share Button */}
          {handleShare && (
            <button
              type="button"
              id="multi-verse-share-btn"
              onClick={handleShare}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
              title="Share Verses"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}

          {/* Clear Desktop */}
          <button
            type="button"
            onClick={onClearSelection}
            className="hidden sm:flex p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Deselect all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
