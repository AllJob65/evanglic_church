import React, { useState, useEffect } from 'react';
import { useBible } from '../../context/BibleContext';
import { Sparkles, BookOpen, AlertCircle, RefreshCw, Sun, Copy, Check, Share2, Volume2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { bibleService } from '../../services/bibleService';
import { YouVersionVerseOfTheDay } from '../../types';

export interface VerseOfTheDayCardProps {
  versionId?: number;
  size?: 'default' | 'lg';
  showSunIcon?: boolean;
  showShareButton?: boolean;
  background?: 'light' | 'dark';
  className?: string;
  showCardHeader?: boolean;
}

const DEFAULT_VOTD: YouVersionVerseOfTheDay = {
  day: 1,
  passageId: 'JHN.3.16',
  textAmharic: 'እግዚአብሔር ዓለምን እንዲሁ ወዶአልና አንድያ ልጁን እስኪሰጥ ድረስ፤ በርሱ የሚያምን ሁሉ የዘላለም ሕይወት እንዲኖረው እንጂ እንዳይጠፋ።',
  textEnglish: 'For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.',
};

export const VerseOfTheDayCard: React.FC<VerseOfTheDayCardProps> = ({
  size = 'default',
  showSunIcon = true,
  showShareButton = true,
  background = 'light',
  className = '',
  showCardHeader = true,
}) => {
  const { jumpToReference } = useBible();
  const navigate = useNavigate();
  const [votd, setVotd] = useState<YouVersionVerseOfTheDay | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [hasError, setHasError] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);

  const fetchVotd = async () => {
    setIsLoading(true);
    setHasError(false);
    try {
      const data = await bibleService.getVerseOfTheDay();
      if (data && (data.textAmharic || data.textEnglish)) {
        setVotd(data);
      } else {
        setHasError(true);
      }
    } catch {
      setHasError(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVotd();
  }, []);

  const currentData = votd || DEFAULT_VOTD;
  const displayRef = currentData.passageId || 'JHN.3.16';

  const handleCopy = async () => {
    const textToCopy = `"${currentData.textAmharic || currentData.textEnglish}"\n— ${displayRef}`;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleShare = async () => {
    const textToShare = `"${currentData.textAmharic || currentData.textEnglish}" — ${displayRef}`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `Verse of the Day: ${displayRef}`,
          text: textToShare,
          url: window.location.href,
        });
        return;
      } catch {
        // Fallback to copy
      }
    }
    handleCopy();
  };

  const handleRecite = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    const textToSpeak = currentData.textEnglish || currentData.textAmharic || '';
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = 0.9;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleOpenReader = () => {
    jumpToReference(displayRef);
    navigate('/bible');
  };

  const isDarkBg = background === 'dark';

  return (
    <div
      className={`rounded-3xl border transition-all ${
        isDarkBg
          ? 'bg-slate-900 border-slate-800 text-white'
          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white'
      } shadow-sm overflow-hidden ${className}`}
    >
      {showCardHeader && (
        <div className="px-5 py-4 bg-gradient-to-r from-blue-900/5 via-indigo-900/5 to-transparent dark:from-blue-950/40 dark:via-indigo-950/20 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {showSunIcon && (
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Sun className="w-4 h-4" />
              </div>
            )}
            <div>
              <h3 className="text-sm font-black flex flex-wrap items-center gap-2">
                <span>የዕለቱ ጥቅስ (Verse of the Day)</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-bold">
                  YouVersion Platform
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Daily scripture inspiration powered by Grace Cathedral Bible Service
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleOpenReader}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Read in Holy Bible Reader"
          >
            <BookOpen className="w-4 h-4" />
            <span className="hidden sm:inline">Open Reader</span>
          </button>
        </div>
      )}

      {/* Main Content */}
      <div className={`p-4 sm:p-7 flex flex-col justify-between ${size === 'lg' ? 'min-h-[220px]' : 'min-h-[160px]'}`}>
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-8 space-y-3">
            <RefreshCw className="w-6 h-6 text-blue-600 animate-spin" />
            <span className="text-xs text-slate-500">Loading daily scripture...</span>
          </div>
        ) : hasError ? (
          <div className="text-center py-6 px-4 space-y-3">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>
            <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
              Bible content is temporarily unavailable — try again shortly
            </p>
            <p className="text-[11px] text-slate-500">
              The live verse feed cannot be reached. You can retry the connection or view the offline default passage.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
              <button
                type="button"
                onClick={fetchVotd}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setVotd(DEFAULT_VOTD);
                  setHasError(false);
                }}
                className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold cursor-pointer"
              >
                View Offline Fallback
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Amharic Scripture */}
            {currentData.textAmharic && (
              <blockquote className="text-base sm:text-lg font-medium leading-relaxed font-serif text-slate-800 dark:text-slate-100">
                «{currentData.textAmharic}»
              </blockquote>
            )}

            {/* English Scripture */}
            {currentData.textEnglish && (
              <p className="text-sm sm:text-base font-normal leading-relaxed text-slate-600 dark:text-slate-300 italic">
                "{currentData.textEnglish}"
              </p>
            )}

            {/* Reference Badge & Actions */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-xs font-black tracking-wide">
                  {displayRef}
                </span>
                <span className="text-xs text-slate-400 font-medium">Day {currentData.day || 1}</span>
              </div>

              <div className="flex items-center gap-1">
                {/* Text to Speech */}
                <button
                  type="button"
                  onClick={handleRecite}
                  className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl transition-colors cursor-pointer ${
                    isPlayingAudio
                      ? 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400'
                  }`}
                  title={isPlayingAudio ? 'Stop Recitation' : 'Listen to Verse'}
                >
                  <Volume2 className="w-4 h-4" />
                </button>

                {/* Copy */}
                <button
                  type="button"
                  onClick={handleCopy}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors cursor-pointer"
                  title="Copy Verse"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>

                {/* Share */}
                {showShareButton && (
                  <button
                    type="button"
                    onClick={handleShare}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors cursor-pointer"
                    title="Share Verse"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VerseOfTheDayCard;
