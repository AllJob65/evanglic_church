import React, { useMemo } from 'react';
import {
  Bookmark,
  Share2,
  Copy,
  MessageSquarePlus,
  Send,
  X,
  FileText,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  CheckSquare,
  Square,
  SunMedium,
} from 'lucide-react';
import { BibleChapterData, BibleVerseItem, BibleBookInfo } from '../../data/bibleCanon';
import { BibleReaderSettings } from '../../types';

export interface AlignedBibleVerse {
  verseKey: string;
  verseNumber: number;
  english: string;
  amharic: string;
  isRedLetter?: boolean;
  rawVerse: BibleVerseItem;
}

interface BibleScriptureViewerProps {
  currentChapter: BibleChapterData;
  currentBook: BibleBookInfo;
  selectedBookId: string;
  selectedChapterNum: number;
  translationMode: 'Amharic' | 'English' | 'Parallel';
  viewLayout: 'verse' | 'paragraph';
  readerSettings: BibleReaderSettings;
  fontSizePx: number;
  lineSpacing: 'compact' | 'normal' | 'relaxed';
  readerTheme: 'light' | 'parchment' | 'dark' | 'midnight';
  showRedLetters: boolean;
  highlights: Record<string, 'yellow' | 'green' | 'blue' | 'rose' | 'purple'>;
  bookmarks: { id: string; bookId?: string; chapter?: number; verse?: number }[];
  notes: Record<string, { note: string; date: string; id?: string }>;
  selectedVerses: BibleVerseItem[];
  onToggleSelectVerse: (verse: BibleVerseItem) => void;
  activeVerseMenuId: string | null;
  setActiveVerseMenuId: (id: string | null) => void;
  currentSpokenVerseNum: number | null;
  onSetHighlightColor: (verseNum: number, color: 'yellow' | 'green' | 'blue' | 'rose' | 'purple' | null) => void;
  onToggleBookmarkVerse: (verse: BibleVerseItem) => void;
  onOpenNoteModalForVerse: (verseKey: string, initialText?: string) => void;
  onDeleteNote: (verseKey: string) => void;
  onShareVerse: (verse: BibleVerseItem) => void;
  onCopyVerse: (verse: BibleVerseItem) => void;
  onBroadcastVerse: (verse: BibleVerseItem) => void;
  onPrevChapter: () => void;
  onNextChapter: () => void;
}

export const BibleScriptureViewer: React.FC<BibleScriptureViewerProps> = ({
  currentChapter,
  currentBook,
  selectedBookId,
  selectedChapterNum,
  translationMode,
  viewLayout,
  readerSettings,
  fontSizePx,
  lineSpacing,
  readerTheme,
  showRedLetters,
  highlights,
  bookmarks,
  notes,
  selectedVerses,
  onToggleSelectVerse,
  activeVerseMenuId,
  setActiveVerseMenuId,
  currentSpokenVerseNum,
  onSetHighlightColor,
  onToggleBookmarkVerse,
  onOpenNoteModalForVerse,
  onDeleteNote,
  onShareVerse,
  onCopyVerse,
  onBroadcastVerse,
  onPrevChapter,
  onNextChapter,
}) => {
  // Build canonical verse-aligned structure keyed by book + chapter + verseNumber
  const alignedVerses: AlignedBibleVerse[] = useMemo(() => {
    const byVerseNum = new Map<number, AlignedBibleVerse>();
    const rawList = currentChapter?.verses || [];

    for (const item of rawList) {
      const vNum = Number(item.verseNumber || item.verse);
      if (!vNum || isNaN(vNum)) continue;

      const canonicalKey = item.verseKey || `${selectedBookId}.${selectedChapterNum}.${vNum}`;
      const engText = (item.english || item.textEnglish || '').trim();
      const amhText = (item.amharic || item.textAmharic || '').trim();

      const existing = byVerseNum.get(vNum);
      if (existing) {
        const mergedEng = existing.english || engText;
        const mergedAmh = existing.amharic || amhText;
        byVerseNum.set(vNum, {
          verseKey: canonicalKey,
          verseNumber: vNum,
          english: mergedEng,
          amharic: mergedAmh,
          isRedLetter: Boolean(existing.isRedLetter || item.isRedLetter),
          rawVerse: {
            ...existing.rawVerse,
            ...item,
            verseKey: canonicalKey,
            verseNumber: vNum,
            verse: vNum,
            english: mergedEng,
            textEnglish: mergedEng,
            amharic: mergedAmh,
            textAmharic: mergedAmh,
          },
        });
      } else {
        byVerseNum.set(vNum, {
          verseKey: canonicalKey,
          verseNumber: vNum,
          english: engText,
          amharic: amhText,
          isRedLetter: Boolean(item.isRedLetter),
          rawVerse: {
            ...item,
            verseKey: canonicalKey,
            verseNumber: vNum,
            verse: vNum,
            english: engText,
            textEnglish: engText,
            amharic: amhText,
            textAmharic: amhText,
          },
        });
      }
    }

    return Array.from(byVerseNum.values()).sort((a, b) => a.verseNumber - b.verseNumber);
  }, [currentChapter?.verses, selectedBookId, selectedChapterNum]);

  const activeTheme = readerSettings.theme || readerTheme;
  const isDarkCanvas = activeTheme === 'dark' || activeTheme === 'midnight';
  const isParchment = activeTheme === 'parchment';

  // Determine Theme Classes (Self-contained to the Bible Scripture View only)
  const getThemeClasses = () => {
    switch (activeTheme) {
      case 'parchment':
        return 'bg-amber-50 text-stone-900 border-amber-200/80';
      case 'dark':
        return 'dark bg-slate-900 text-slate-100 border-slate-800';
      case 'midnight':
        return 'dark bg-slate-950 text-indigo-100 border-indigo-950';
      case 'light':
      default:
        return 'bg-white text-slate-900 border-slate-200';
    }
  };

  // Determine Width Class (Parallel view uses a wider container so both 50/50 columns breathe comfortably)
  const getWidthClass = () => {
    if (translationMode === 'Parallel') {
      return 'max-w-7xl mx-auto';
    }
    switch (readerSettings.readingWidth) {
      case 'narrow':
        return 'max-w-3xl mx-auto';
      case 'wide':
        return 'max-w-7xl mx-auto';
      case 'normal':
      default:
        return 'max-w-5xl mx-auto';
    }
  };

  // Determine Line Spacing Class
  const getLineSpacingClass = () => {
    const spacing = readerSettings.lineSpacing || lineSpacing;
    switch (spacing) {
      case 'compact':
        return 'leading-snug space-y-2';
      case 'spacious':
      case 'relaxed':
        return 'leading-loose space-y-5';
      case 'comfortable':
      case 'normal':
      default:
        return 'leading-relaxed space-y-3.5';
    }
  };

  const isVerseSelected = (vNum: number) =>
    selectedVerses.some((sv) => (sv.verse || sv.verseNumber) === vNum);

  const isVerseBookmarked = (vNum: number, legacyVerseKey: string) =>
    bookmarks.some(
      (b) =>
        b.id === legacyVerseKey ||
        b.id === `bm-${legacyVerseKey}` ||
        (b.bookId === selectedBookId && Number(b.chapter) === Number(selectedChapterNum) && Number(b.verse) === vNum)
    );

  return (
    <div className={getWidthClass()}>
      <div
        data-bible-theme={activeTheme}
        className={`bible-scripture-canvas ${
          isDarkCanvas ? 'bible-canvas-dark' : isParchment ? 'bible-canvas-parchment' : 'bible-canvas-light'
        } p-4 sm:p-8 lg:p-10 rounded-3xl border shadow-md transition-all ${getThemeClasses()}`}
      >
        {/* Chapter Header */}
        <div className="text-center pb-6 mb-6 border-b border-slate-200/50 dark:border-slate-700/50 space-y-1.5">
          <span className="text-[11px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 block">
            {currentBook.categoryAmharic || currentBook.category} • {currentBook.testament === 'Old' ? 'ብሉይ ኪዳን (Old Testament)' : 'ሐዲስ ኪዳን (New Testament)'}
          </span>
          <h1 className="text-2xl sm:text-3xl font-black">
            {currentBook.nameEnglish} {selectedChapterNum} — {currentBook.nameAmharic} ምዕራፍ {selectedChapterNum}
          </h1>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-bold mt-1">
            <span>Version: {readerSettings.preferredVersionName || 'YouVersion Authorized'}</span>
            <span>•</span>
            <span>Mode: {translationMode}</span>
          </div>
          {currentChapter.summary && (
            <p className="text-xs italic text-slate-600 dark:text-slate-400 max-w-xl mx-auto pt-2">
              {currentChapter.summary}
            </p>
          )}
        </div>

        {/* SCRIPTURE CONTENT */}
        {translationMode === 'Parallel' ? (
          /* TRUE SIDE-BY-SIDE PARALLEL VIEW (Aligned Verse-by-Verse) */
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden">
            {/* Sticky Parallel Column Headers */}
            <div className="grid grid-cols-1 md:grid-cols-2 bg-slate-100/90 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700">
              <div className="px-4 py-3 flex items-center justify-between border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-600 dark:bg-blue-400" />
                  <span className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-100">
                    English
                  </span>
                </div>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  { currentBook.nameEnglish } { selectedChapterNum }
                </span>
              </div>
              <div className="px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 dark:bg-emerald-400" />
                  <span className="text-sm font-menbere font-black text-slate-800 dark:text-slate-100">
                    አማርኛ
                  </span>
                </div>
                <span className="text-xs font-menbere font-semibold text-slate-500 dark:text-slate-400">
                  { currentBook.nameAmharic } ምዕራፍ { selectedChapterNum }
                </span>
              </div>
            </div>

            {/* Verse-by-Verse Aligned Rows */}
            <div className="divide-y divide-slate-200/70 dark:divide-slate-800/80" style={{ fontSize: `${fontSizePx}px` }}>
              {alignedVerses.map((aligned) => {
                const vNum = aligned.verseNumber;
                const verse = aligned.rawVerse;
                const storageVerseKey = `${selectedBookId}-${selectedChapterNum}-${vNum}`;
                const isBookmarked = isVerseBookmarked(vNum, storageVerseKey);
                const highlight = highlights[storageVerseKey];
                const verseNote = notes[storageVerseKey];
                const isMenuOpen = activeVerseMenuId === storageVerseKey;
                const isSpoken = currentSpokenVerseNum === vNum;
                const isSelected = isVerseSelected(vNum);
                const isRed = Boolean(
                  aligned.isRedLetter && readerSettings.showRedLetters !== false && showRedLetters
                );

                let highlightClass = '';
                if (highlight === 'yellow')
                  highlightClass = 'bg-yellow-100/70 dark:bg-yellow-950/40 border-l-4 border-l-yellow-400';
                if (highlight === 'green')
                  highlightClass = 'bg-emerald-100/70 dark:bg-emerald-950/40 border-l-4 border-l-emerald-400';
                if (highlight === 'blue')
                  highlightClass = 'bg-sky-100/70 dark:bg-sky-950/40 border-l-4 border-l-sky-400';
                if (highlight === 'rose')
                  highlightClass = 'bg-rose-100/70 dark:bg-rose-950/40 border-l-4 border-l-rose-400';
                if (highlight === 'purple')
                  highlightClass = 'bg-purple-100/70 dark:bg-purple-950/40 border-l-4 border-l-purple-400';

                return (
                  <div
                    key={aligned.verseKey}
                    id={`verse-${vNum}`}
                    data-verse-key={aligned.verseKey}
                    className={`transition-colors ${highlightClass} ${
                      isSelected
                        ? 'bg-blue-50/90 dark:bg-blue-950/60 ring-1 ring-inset ring-blue-500/60'
                        : isSpoken
                        ? 'bg-blue-50/80 dark:bg-blue-950/50'
                        : 'hover:bg-slate-50/80 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    {/* Side-by-Side 50/50 Grid Row for Verse vNum */}
                    <div className="grid grid-cols-1 md:grid-cols-2 items-stretch">
                      {/* LEFT COLUMN: ENGLISH VERSE */}
                      <div
                        onClick={(e) => {
                          if (e.shiftKey || selectedVerses.length > 0) {
                            onToggleSelectVerse(verse);
                          }
                        }}
                        className="p-3.5 sm:p-4 md:border-r border-slate-200/80 dark:border-slate-800 flex items-start gap-3"
                      >
                        <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleSelectVerse(verse);
                            }}
                            className={`w-5 h-5 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-blue-600 text-white shadow-xs'
                                : 'border border-slate-300 dark:border-slate-600 text-transparent hover:border-blue-500'
                            }`}
                            title={`Select verse ${vNum}`}
                          >
                            <CheckSquare className={`w-3.5 h-3.5 ${isSelected ? 'opacity-100' : 'opacity-0'}`} />
                          </button>

                          {readerSettings.showVerseNumbers !== false && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveVerseMenuId(isMenuOpen ? null : storageVerseKey);
                              }}
                              className={`min-w-7 h-7 px-1.5 rounded-xl font-black text-xs shrink-0 flex items-center justify-center cursor-pointer hover:scale-105 transition-all ${
                                isSelected
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                              }`}
                              title="Click for verse actions (highlight, study note, share)"
                            >
                              {vNum}
                            </button>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <span className="md:hidden text-[10px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 block mb-0.5">
                            English
                          </span>
                          {aligned.english ? (
                            <p
                              className={`text-slate-800 dark:text-slate-200 font-normal leading-relaxed break-words ${
                                isRed ? 'text-red-600 dark:text-red-400 font-semibold' : ''
                              }`}
                            >
                              {aligned.english}
                            </p>
                          ) : (
                            <p className="text-slate-400 dark:text-slate-500 italic select-none">—</p>
                          )}
                        </div>
                      </div>

                      {/* RIGHT COLUMN: AMHARIC VERSE */}
                      <div
                        onClick={(e) => {
                          if (e.shiftKey || selectedVerses.length > 0) {
                            onToggleSelectVerse(verse);
                          }
                        }}
                        className="p-3.5 sm:p-4 border-t md:border-t-0 border-slate-100 dark:border-slate-800/60 flex items-start justify-between gap-3"
                      >
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          {readerSettings.showVerseNumbers !== false && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveVerseMenuId(isMenuOpen ? null : storageVerseKey);
                              }}
                              className={`min-w-7 h-7 px-1.5 rounded-xl font-black text-xs shrink-0 flex items-center justify-center cursor-pointer hover:scale-105 transition-all mt-0.5 ${
                                isSelected
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300'
                              }`}
                              title="Click for verse actions (highlight, study note, share)"
                            >
                              {vNum}
                            </button>
                          )}

                          <div className="flex-1 min-w-0">
                            <span className="md:hidden text-[11px] font-menbere font-black text-emerald-600 dark:text-emerald-400 block mb-0.5">
                              አማርኛ
                            </span>
                            {aligned.amharic ? (
                              <p
                                lang="am"
                                style={{ fontSize: `${Math.round(fontSizePx * 1.05)}px`, lineHeight: 1.85 }}
                                className={`font-menbere font-normal text-slate-800 dark:text-slate-100 tracking-normal break-words ${
                                  isRed ? 'text-red-600 dark:text-red-400 font-semibold' : ''
                                }`}
                              >
                                {aligned.amharic}
                              </p>
                            ) : (
                              <p className="text-slate-400 dark:text-slate-500 italic select-none">—</p>
                            )}
                          </div>
                        </div>

                        {/* Fast Action Buttons */}
                        <div className="shrink-0 flex items-center gap-1 opacity-80 hover:opacity-100 pt-0.5">
                          {readerSettings.enableBookmarks !== false && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleBookmarkVerse(verse);
                              }}
                              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                                isBookmarked
                                  ? 'text-amber-500 bg-amber-100 dark:bg-amber-950'
                                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                              }`}
                              title="Bookmark verse"
                            >
                              <Bookmark className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onShareVerse(verse);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                            title="Share verse"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onCopyVerse(verse);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                            title="Copy verse"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Note Attached Display (Full Width under the Aligned Verse Pair) */}
                    {verseNote && (
                      <div className="mx-4 mb-3 p-2.5 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800/50 text-xs text-purple-900 dark:text-purple-200 flex items-start justify-between gap-2">
                        <div>
                          <span className="font-black text-[10px] uppercase text-purple-700 dark:text-purple-300 block">
                            📝 የጥናት ማስታወሻ ({verseNote.date})
                          </span>
                          <p className="italic">{verseNote.note}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onDeleteNote(storageVerseKey)}
                          className="text-slate-400 hover:text-rose-500 p-1 cursor-pointer"
                          title="Delete Note"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* INLINE VERSE ACTION MENU MODAL */}
                    {isMenuOpen && (
                      <div className="mx-4 mb-3 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xl z-20 flex flex-wrap items-center justify-between gap-2 animate-in fade-in">
                        {/* Highlighter Colors */}
                        {readerSettings.enableHighlights !== false && (
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-bold text-slate-400 uppercase">Highlight:</span>
                            <button
                              type="button"
                              onClick={() => onSetHighlightColor(vNum, 'yellow')}
                              className="w-5 h-5 rounded-full bg-yellow-400 ring-1 ring-yellow-500 hover:scale-125 transition-all cursor-pointer"
                              title="Yellow Highlight"
                            />
                            <button
                              type="button"
                              onClick={() => onSetHighlightColor(vNum, 'green')}
                              className="w-5 h-5 rounded-full bg-emerald-400 ring-1 ring-emerald-500 hover:scale-125 transition-all cursor-pointer"
                              title="Green Highlight"
                            />
                            <button
                              type="button"
                              onClick={() => onSetHighlightColor(vNum, 'blue')}
                              className="w-5 h-5 rounded-full bg-sky-400 ring-1 ring-sky-500 hover:scale-125 transition-all cursor-pointer"
                              title="Blue Highlight"
                            />
                            <button
                              type="button"
                              onClick={() => onSetHighlightColor(vNum, 'rose')}
                              className="w-5 h-5 rounded-full bg-rose-400 ring-1 ring-rose-500 hover:scale-125 transition-all cursor-pointer"
                              title="Rose Highlight"
                            />
                            <button
                              type="button"
                              onClick={() => onSetHighlightColor(vNum, 'purple')}
                              className="w-5 h-5 rounded-full bg-purple-400 ring-1 ring-purple-500 hover:scale-125 transition-all cursor-pointer"
                              title="Purple Highlight"
                            />
                            {highlight && (
                              <button
                                type="button"
                                onClick={() => onSetHighlightColor(vNum, null)}
                                className="text-[10px] text-rose-500 font-bold hover:underline ml-1 cursor-pointer"
                              >
                                Clear
                              </button>
                            )}
                          </div>
                        )}

                        {/* Actions: Add Note, Share, Broadcast */}
                        <div className="flex items-center gap-1.5">
                          {readerSettings.enableNotes !== false && (
                            <button
                              type="button"
                              onClick={() => {
                                onOpenNoteModalForVerse(storageVerseKey, verseNote?.note);
                                setActiveVerseMenuId(null);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 dark:bg-purple-950 dark:hover:bg-purple-900 text-purple-800 dark:text-purple-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <MessageSquarePlus className="w-3 h-3" />
                              ማስታወሻ (Note)
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => onShareVerse(verse)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Share2 className="w-3 h-3" />
                            አጋራ (Share)
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              onBroadcastVerse(verse);
                              setActiveVerseMenuId(null);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-blue-100 hover:bg-blue-200 dark:bg-blue-950 dark:hover:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Send className="w-3 h-3" />
                            አሰራጭ (Broadcast)
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ) : viewLayout === 'paragraph' ? (
          /* CONTINUOUS PARAGRAPH READING VIEW (Single Language Mode) */
          <div className={getLineSpacingClass()} style={{ fontSize: `${fontSizePx}px` }}>
            <p className="text-justify leading-relaxed">
              {alignedVerses.map((aligned) => {
                const vNum = aligned.verseNumber;
                const v = aligned.rawVerse;
                const verseKey = `${selectedBookId}-${selectedChapterNum}-${vNum}`;
                const isBookmarked = isVerseBookmarked(vNum, verseKey);
                const highlight = highlights[verseKey];
                const hasNote = Boolean(notes[verseKey]);
                const isSpoken = currentSpokenVerseNum === vNum;
                const isSelected = isVerseSelected(vNum);

                let highlightBg = '';
                if (highlight === 'yellow') highlightBg = 'bg-yellow-200/60 dark:bg-yellow-900/50 text-yellow-950 dark:text-yellow-100 rounded px-1';
                if (highlight === 'green') highlightBg = 'bg-emerald-200/60 dark:bg-emerald-900/50 text-emerald-950 dark:text-emerald-100 rounded px-1';
                if (highlight === 'blue') highlightBg = 'bg-sky-200/60 dark:bg-sky-900/50 text-sky-950 dark:text-sky-100 rounded px-1';
                if (highlight === 'rose') highlightBg = 'bg-rose-200/60 dark:bg-rose-900/50 text-rose-950 dark:text-rose-100 rounded px-1';
                if (highlight === 'purple') highlightBg = 'bg-purple-200/60 dark:bg-purple-900/50 text-purple-950 dark:text-purple-100 rounded px-1';

                return (
                  <span
                    key={aligned.verseKey}
                    onClick={(e) => {
                      if (e.shiftKey || selectedVerses.length > 0) {
                        onToggleSelectVerse(v);
                      } else {
                        setActiveVerseMenuId(activeVerseMenuId === verseKey ? null : verseKey);
                      }
                    }}
                    className={`cursor-pointer inline transition-all hover:bg-blue-100/50 dark:hover:bg-blue-900/30 p-0.5 rounded ${
                      isSelected ? 'ring-2 ring-blue-500 bg-blue-100/80 dark:bg-blue-950/80 rounded font-medium' : ''
                    } ${isSpoken ? 'bg-blue-300 dark:bg-blue-800 font-bold' : ''} ${highlightBg}`}
                  >
                    {readerSettings.showVerseNumbers !== false && (
                      <sup className="text-[10px] font-black text-blue-600 dark:text-blue-400 mr-1 select-none">
                        {vNum}
                      </sup>
                    )}
                    <span
                      className={`${
                        translationMode === 'Amharic' ? 'font-menbere' : ''
                      } ${
                        aligned.isRedLetter && (readerSettings.showRedLetters !== false && showRedLetters)
                          ? 'text-red-600 dark:text-red-400 font-medium'
                          : ''
                      }`}
                    >
                      {translationMode === 'English' ? aligned.english : aligned.amharic}
                    </span>
                    {isBookmarked && <span className="text-amber-500 text-xs ml-0.5 select-none">★</span>}
                    {hasNote && <span className="text-purple-500 text-xs ml-0.5 select-none">📝</span>}{' '}
                  </span>
                );
              })}
            </p>
          </div>
        ) : (
          /* VERSE BY VERSE LIST VIEW (Single Language Mode: English or Amharic) */
          <div className={getLineSpacingClass()} style={{ fontSize: `${fontSizePx}px` }}>
            {alignedVerses.map((aligned) => {
              const vNum = aligned.verseNumber;
              const verse = aligned.rawVerse;
              const verseKey = `${selectedBookId}-${selectedChapterNum}-${vNum}`;
              const isBookmarked = isVerseBookmarked(vNum, verseKey);
              const highlight = highlights[verseKey];
              const verseNote = notes[verseKey];
              const isMenuOpen = activeVerseMenuId === verseKey;
              const isSpoken = currentSpokenVerseNum === vNum;
              const isSelected = isVerseSelected(vNum);

              let highlightClass = '';
              if (highlight === 'yellow') highlightClass = 'bg-yellow-100/70 dark:bg-yellow-950/40 border-l-4 border-yellow-400 pl-3 rounded-r-xl';
              if (highlight === 'green') highlightClass = 'bg-emerald-100/70 dark:bg-emerald-950/40 border-l-4 border-emerald-400 pl-3 rounded-r-xl';
              if (highlight === 'blue') highlightClass = 'bg-sky-100/70 dark:bg-sky-950/40 border-l-4 border-sky-400 pl-3 rounded-r-xl';
              if (highlight === 'rose') highlightClass = 'bg-rose-100/70 dark:bg-rose-950/40 border-l-4 border-rose-400 pl-3 rounded-r-xl';
              if (highlight === 'purple') highlightClass = 'bg-purple-100/70 dark:bg-purple-950/40 border-l-4 border-purple-400 pl-3 rounded-r-xl';

              return (
                <div
                  key={aligned.verseKey}
                  id={`verse-${vNum}`}
                  data-verse-key={aligned.verseKey}
                  className={`relative p-2.5 sm:p-3.5 rounded-2xl transition-all ${highlightClass} ${
                    isSelected
                      ? 'ring-2 ring-blue-500 bg-blue-50/90 dark:bg-blue-950/70 shadow-xs'
                      : isSpoken
                      ? 'ring-2 ring-blue-500 bg-blue-50/80 dark:bg-blue-950/50'
                      : 'hover:bg-slate-100/60 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Multi-Select & Verse Number Pill */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onToggleSelectVerse(verse)}
                        className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'border border-slate-300 dark:border-slate-600 text-transparent hover:border-blue-500'
                        }`}
                        title="Select verse for multi-verse devotion/note"
                      >
                        <CheckSquare className={`w-3.5 h-3.5 ${isSelected ? 'opacity-100' : 'opacity-0'}`} />
                      </button>

                      {readerSettings.showVerseNumbers !== false && (
                        <button
                          type="button"
                          onClick={() => setActiveVerseMenuId(isMenuOpen ? null : verseKey)}
                          className={`w-7 h-7 rounded-xl font-black text-xs shrink-0 flex items-center justify-center cursor-pointer hover:scale-110 transition-all ${
                            isSelected
                              ? 'bg-blue-600 text-white'
                              : 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                          }`}
                          title="Click for verse actions (highlight, study note, share)"
                        >
                          {vNum}
                        </button>
                      )}
                    </div>

                    {/* Verse Text Area */}
                    <div className="flex-1 space-y-1">
                      {translationMode === 'English' && (
                        <p className={`text-slate-800 dark:text-slate-200 font-normal leading-relaxed ${
                          aligned.isRedLetter && (readerSettings.showRedLetters !== false && showRedLetters)
                            ? 'text-red-600 dark:text-red-400 font-semibold'
                            : ''
                        }`}>
                          {aligned.english || '—'}
                        </p>
                      )}

                      {translationMode === 'Amharic' && (
                        <p
                          lang="am"
                          style={{ fontSize: `${Math.round(fontSizePx * 1.05)}px`, lineHeight: 1.85 }}
                          className={`font-menbere font-normal text-slate-800 dark:text-slate-100 leading-relaxed ${
                            aligned.isRedLetter && (readerSettings.showRedLetters !== false && showRedLetters)
                              ? 'text-red-600 dark:text-red-400 font-semibold'
                              : ''
                          }`}
                        >
                          {aligned.amharic || '—'}
                        </p>
                      )}

                      {/* Note Attached Display */}
                      {verseNote && (
                        <div className="mt-2 p-2.5 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800/50 text-xs text-purple-900 dark:text-purple-200 flex items-start justify-between gap-2">
                          <div>
                            <span className="font-black text-[10px] uppercase text-purple-700 dark:text-purple-300 block">
                              📝 የጥናት ማስታወሻ ({verseNote.date})
                            </span>
                            <p className="italic">{verseNote.note}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => onDeleteNote(verseKey)}
                            className="text-slate-400 hover:text-rose-500 p-1"
                            title="Delete Note"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Fast Action Buttons */}
                    <div className="shrink-0 flex items-center gap-1 opacity-80 hover:opacity-100">
                      {readerSettings.enableBookmarks !== false && (
                        <button
                          type="button"
                          onClick={() => onToggleBookmarkVerse(verse)}
                          className={`p-1.5 rounded-lg transition-all ${
                            isBookmarked ? 'text-amber-500 bg-amber-100 dark:bg-amber-950' : 'text-slate-400 hover:text-slate-700'
                          }`}
                          title="Bookmark verse"
                        >
                          <Bookmark className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onShareVerse(verse)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
                        title="Share verse"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onCopyVerse(verse)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
                        title="Copy verse"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* INLINE VERSE ACTION MENU MODAL */}
                  {isMenuOpen && (
                    <div className="mt-3 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xl z-20 flex flex-wrap items-center justify-between gap-2 animate-in fade-in">
                      {/* Highlighter Colors */}
                      {readerSettings.enableHighlights !== false && (
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">Highlight:</span>
                          <button
                            type="button"
                            onClick={() => onSetHighlightColor(vNum, 'yellow')}
                            className="w-5 h-5 rounded-full bg-yellow-400 ring-1 ring-yellow-500 hover:scale-125 transition-all"
                            title="Yellow Highlight"
                          />
                          <button
                            type="button"
                            onClick={() => onSetHighlightColor(vNum, 'green')}
                            className="w-5 h-5 rounded-full bg-emerald-400 ring-1 ring-emerald-500 hover:scale-125 transition-all"
                            title="Green Highlight"
                          />
                          <button
                            type="button"
                            onClick={() => onSetHighlightColor(vNum, 'blue')}
                            className="w-5 h-5 rounded-full bg-sky-400 ring-1 ring-sky-500 hover:scale-125 transition-all"
                            title="Blue Highlight"
                          />
                          <button
                            type="button"
                            onClick={() => onSetHighlightColor(vNum, 'rose')}
                            className="w-5 h-5 rounded-full bg-rose-400 ring-1 ring-rose-500 hover:scale-125 transition-all"
                            title="Rose Highlight"
                          />
                          <button
                            type="button"
                            onClick={() => onSetHighlightColor(vNum, 'purple')}
                            className="w-5 h-5 rounded-full bg-purple-400 ring-1 ring-purple-500 hover:scale-125 transition-all"
                            title="Purple Highlight"
                          />
                          {highlight && (
                            <button
                              type="button"
                              onClick={() => onSetHighlightColor(vNum, null)}
                              className="text-[10px] text-rose-500 font-bold hover:underline ml-1"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                      )}

                      {/* Actions: Add Note, Share, Broadcast */}
                      <div className="flex items-center gap-1.5">
                        {readerSettings.enableNotes !== false && (
                          <button
                            type="button"
                            onClick={() => {
                              onOpenNoteModalForVerse(verseKey, verseNote?.note);
                              setActiveVerseMenuId(null);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 dark:bg-purple-950 dark:hover:bg-purple-900 text-purple-800 dark:text-purple-200 text-xs font-bold flex items-center gap-1"
                          >
                            <MessageSquarePlus className="w-3 h-3" />
                            ማስታወሻ (Note)
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onShareVerse(verse)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-200 text-xs font-bold flex items-center gap-1"
                        >
                          <Share2 className="w-3 h-3" />
                          አጋራ (Share)
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onBroadcastVerse(verse);
                            setActiveVerseMenuId(null);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-blue-100 hover:bg-blue-200 dark:bg-blue-950 dark:hover:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-bold flex items-center gap-1"
                        >
                          <Send className="w-3 h-3" />
                          አሰራጭ (Broadcast)
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* STUDY FOOTNOTES & CROSS REFERENCES */}
        {(readerSettings.showFootnotes || readerSettings.showCrossReferences) && (
          <div className="mt-8 pt-6 border-t border-slate-200/50 dark:border-slate-700/50 space-y-4">
            {readerSettings.showFootnotes && (
              <div className="p-4 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 text-xs space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-300">
                  <FileText className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span>Study Footnotes & Context (የግርጌ ማስታወሻዎችና ትርጓሜ)</span>
                </div>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
                  {currentChapter.summary || `${currentBook.nameEnglish} (${currentBook.nameAmharic}) Chapter ${selectedChapterNum} — Authentic manuscript notes and canonical translation concordance.`}
                </p>
              </div>
            )}

            {readerSettings.showCrossReferences && (
              <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-900/40 text-xs space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-blue-900 dark:text-blue-300">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Cross References (ተዛማጅ የመጽሐፍ ቅዱስ ክፍሎች)</span>
                </div>
                <div className="flex flex-wrap gap-2 pt-1">
                  {['John 1:1', 'Psalm 119:105', 'Hebrews 4:12', '2 Timothy 3:16', 'Romans 8:28'].map((ref) => (
                    <span
                      key={ref}
                      className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-blue-200 dark:border-slate-700 text-[11px] font-bold text-blue-700 dark:text-blue-300 shadow-xs"
                    >
                      {ref}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* BOTTOM CHAPTER PAGINATION */}
        <div className="mt-10 pt-6 border-t border-slate-200/50 dark:border-slate-700/50 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onPrevChapter}
            className="px-4 py-2.5 rounded-2xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center gap-2 border border-slate-200 dark:border-slate-700 shadow-xs cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous Chapter
          </button>

          <span className="text-xs font-bold text-slate-500">
            {currentBook.nameEnglish} {selectedChapterNum} / {currentBook.chaptersCount}
          </span>

          <button
            type="button"
            onClick={onNextChapter}
            className="px-4 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer"
          >
            Next Chapter
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
