import React from 'react';
import { useBible } from '../../context/BibleContext';
import { VerseOfTheDayCard } from './VerseOfTheDayCard';
import { Sun, ArrowLeft, BookOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const VerseOfTheDayView: React.FC = () => {
  const { selectedVersionId, setSelectedVersionId } = useBible();
  const navigate = useNavigate();

  return (
    <div className="space-y-6 max-w-4xl mx-auto p-4 sm:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate('/bible')}
            className="p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Back to Bible Reader"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Sun className="w-6 h-6 text-amber-500" />
              <span>Verse of the Day (የዕለቱ ጥቅስ)</span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Official YouVersion Verse of the Day
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => navigate('/bible')}
          className="px-4 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer self-start sm:self-auto"
        >
          <BookOpen className="w-4 h-4" />
          <span>Open Bible Reader</span>
        </button>
      </div>

      {/* Main Card */}
      <VerseOfTheDayCard
        versionId={selectedVersionId}
        size="lg"
        showSunIcon={true}
        showShareButton={true}
        showCardHeader={false}
      />
    </div>
  );
};

export default VerseOfTheDayView;
