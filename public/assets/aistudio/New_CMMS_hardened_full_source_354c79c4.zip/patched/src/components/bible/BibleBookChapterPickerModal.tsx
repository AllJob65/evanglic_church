import React, { useState, useMemo } from 'react';
import { Search, X, BookOpen, Sparkles, ChevronRight, Check } from 'lucide-react';
import { BIBLE_CANON, BibleBookInfo } from '../../data/bibleCanon';

interface BibleBookChapterPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedBookId: string;
  selectedChapterNum?: number;
  selectedChapter?: number;
  onSelectBookAndChapter: (bookId: string, chapterNum: number) => void;
}

const POPULAR_BOOKS = [
  { id: 'GEN', label: 'Genesis', amh: 'ዘፍጥረት' },
  { id: 'PSA', label: 'Psalms', amh: 'መዝሙር' },
  { id: 'PRO', label: 'Proverbs', amh: 'ምሳሌ' },
  { id: 'ISA', label: 'Isaiah', amh: 'ኢሳይያስ' },
  { id: 'MAT', label: 'Matthew', amh: 'ማቴዎስ' },
  { id: 'JHN', label: 'John', amh: 'ዮሐንስ' },
  { id: 'ROM', label: 'Romans', amh: 'ሮሜ' },
  { id: 'REV', label: 'Revelation', amh: 'ራእይ' },
];

export const BibleBookChapterPickerModal: React.FC<BibleBookChapterPickerModalProps> = ({
  isOpen,
  onClose,
  selectedBookId,
  selectedChapterNum,
  selectedChapter,
  onSelectBookAndChapter,
}) => {
  const currentCh = selectedChapterNum !== undefined ? selectedChapterNum : (selectedChapter !== undefined ? selectedChapter : 1);
  const [searchTerm, setSearchTerm] = useState('');
  const [testamentFilter, setTestamentFilter] = useState<'All' | 'Old' | 'New'>('All');
  const [activeBookId, setActiveBookId] = useState<string>(selectedBookId || 'JHN');

  // Find currently active book object
  const activeBook = useMemo(() => {
    return BIBLE_CANON.find((b) => b.id === activeBookId) || BIBLE_CANON[0];
  }, [activeBookId]);

  // Filtered books
  const filteredBooks = useMemo(() => {
    return BIBLE_CANON.filter((b) => {
      const matchTestament = testamentFilter === 'All' || b.testament === testamentFilter;
      const q = searchTerm.trim().toLowerCase();
      const matchSearch =
        !q ||
        b.nameEnglish.toLowerCase().includes(q) ||
        b.nameAmharic.toLowerCase().includes(q) ||
        b.shortCode.toLowerCase().includes(q) ||
        b.id.toLowerCase().includes(q);
      return matchTestament && matchSearch;
    });
  }, [testamentFilter, searchTerm]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-400 text-slate-950">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                Select Book & Chapter (መጽሐፍና ምዕራፍ ምረጥ)
              </h3>
              <p className="text-xs text-blue-200">
                Pick from all 66 books of the Holy Bible in 1-click
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Jump Bar & Filters */}
        <div className="p-3.5 bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 space-y-2.5">
          {/* Quick jumps */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-[10px] font-black uppercase text-slate-400 shrink-0 mr-1">
              Quick Jump:
            </span>
            {POPULAR_BOOKS.map((pb) => (
              <button
                key={pb.id}
                type="button"
                onClick={() => {
                  setActiveBookId(pb.id);
                  setSearchTerm('');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold shrink-0 transition-all ${
                  activeBookId === pb.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-blue-400'
                }`}
              >
                {pb.label} ({pb.amh})
              </button>
            ))}
          </div>

          {/* Search & Testament Tabs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search books (e.g. John, Psalms, ዮሐንስ, Gen)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-xl text-xs border border-slate-300 dark:border-slate-700 focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-1 shrink-0">
              {(['All', 'Old', 'New'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTestamentFilter(t)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    testamentFilter === t
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {t === 'All' ? 'All (66)' : t === 'Old' ? 'Old Testament (39)' : 'New Testament (27)'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Modal 2-Column Split: Left Books List, Right Chapters Grid */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-0">
          {/* Books List (5 cols on md) */}
          <div className="md:col-span-6 lg:col-span-5 p-3 overflow-y-auto border-r border-slate-200 dark:border-slate-800 max-h-[50vh] md:max-h-full space-y-1.5">
            <span className="text-[10px] font-black uppercase text-slate-400 block px-2 pb-1">
              Step 1: Choose Book ({filteredBooks.length} available)
            </span>
            {filteredBooks.map((book) => {
              const isSelected = activeBookId === book.id;
              return (
                <button
                  key={book.id}
                  type="button"
                  onClick={() => setActiveBookId(book.id)}
                  className={`w-full p-2.5 rounded-2xl border text-left transition-all flex items-center justify-between gap-2 ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md ring-2 ring-blue-400'
                      : 'bg-slate-50/80 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}>
                        {book.testament === 'Old' ? 'OT' : 'NT'}
                      </span>
                      <span className="text-xs font-bold truncate">
                        {book.nameEnglish}
                      </span>
                    </div>
                    <p className={`text-[11px] font-menbere truncate mt-0.5 ${isSelected ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'}`}>
                      {book.nameAmharic}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`text-[10px] font-bold block ${isSelected ? 'text-blue-200' : 'text-slate-400'}`}>
                      {book.chaptersCount} Ch.
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Chapters Grid (7 cols on md) */}
          <div className="md:col-span-6 lg:col-span-7 p-4 overflow-y-auto max-h-[50vh] md:max-h-full flex flex-col justify-between bg-slate-50/50 dark:bg-slate-900/40">
            <div>
              {/* Selected Book Heading */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-[10px] font-black uppercase text-blue-600 dark:text-blue-400 block">
                    Step 2: Choose Chapter
                  </span>
                  <h4 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    {activeBook.nameEnglish} — {activeBook.nameAmharic}
                  </h4>
                </div>
                <span className="px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-bold">
                  {activeBook.chaptersCount} Chapters
                </span>
              </div>

              {/* Numbered Chapters Grid */}
              <div className="grid grid-cols-5 sm:grid-cols-6 lg:grid-cols-7 gap-2">
                {Array.from({ length: activeBook.chaptersCount }, (_, i) => i + 1).map((chNum) => {
                  const isCurrent = selectedBookId === activeBook.id && selectedChapterNum === chNum;
                  return (
                    <button
                      key={chNum}
                      type="button"
                      onClick={() => {
                        onSelectBookAndChapter(activeBook.id, chNum);
                        onClose();
                      }}
                      className={`h-11 rounded-xl text-xs font-black flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isCurrent
                          ? 'bg-blue-600 text-white shadow-md ring-2 ring-amber-400 scale-105'
                          : 'bg-white dark:bg-slate-800 hover:bg-blue-500 hover:text-white text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-xs hover:scale-105'
                      }`}
                    >
                      <span>{chNum}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bottom help prompt */}
            <div className="pt-4 mt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
              <span>Click any chapter number to open reading view immediately</span>
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
