import React, { useState, useEffect } from 'react';
import {
  Inbox,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  MessageSquare,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Copy,
  Check,
  Share2,
  RefreshCw,
  X,
  Heart,
  Volume2,
} from 'lucide-react';
import { bibleService } from '../../services/bibleService';
import { useCMMS } from '../../context/CMMSContext';

interface BibleInboxViewProps {
  onOpenInReader?: (reference: string, translationId?: number | string) => void;
  onClose?: () => void;
}

export const BibleInboxView: React.FC<BibleInboxViewProps> = ({ onOpenInReader, onClose }) => {
  const { currentUser: currentCmmsUser } = useCMMS();
  const [inboxItems, setInboxItems] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedMessage, setSelectedMessage] = useState<any | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const currentUser = {
    userId: currentCmmsUser?.memberId || currentCmmsUser?.email || 'default-member-id',
    userName: currentCmmsUser?.name || 'Church Member',
    userRole: (currentCmmsUser?.role as string) || 'REGULAR_MEMBER',
  };

  const loadInbox = async () => {
    setIsLoading(true);
    try {
      const data = await bibleService.getUserInbox(currentUser);
      setInboxItems(data.items || []);
      setUnreadCount(data.unreadCount || 0);

      // Auto-select first message if none selected
      if (!selectedMessage && data.items && data.items.length > 0) {
        setSelectedMessage(data.items[0]);
      }
    } catch (e) {
      console.error('Error fetching inbox:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadInbox();
  }, [currentUser.userId]);

  const handleSelectMessage = async (item: any) => {
    setSelectedMessage(item);
    if (!item.read) {
      // Mark as read immediately
      await bibleService.markInboxMessageRead(currentUser, item.id);
      // Update local state
      setInboxItems((prev) =>
        prev.map((m) => (m.id === item.id ? { ...m, read: true, readAt: new Date().toISOString() } : m))
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
    }
  };

  const handleCopyPassage = (item: any) => {
    const text = `"${item.passageText}"\n— ${item.reference} (${item.translationAbbreviation || 'Scripture'})\n\nPastor's Note:\n${item.note || ''}`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col h-[750px]">
      {/* Inbox Header */}
      <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900">
            <Inbox className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Pastoral Scripture Inbox
              </h3>
              {unreadCount > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-600 text-white">
                  {unreadCount} New
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Bible verses and devotional reflections sent to you by church leadership
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadInbox}
            className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            title="Refresh Inbox"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Inbox Body: 2 Columns */}
      <div className="grid grid-cols-1 md:grid-cols-12 flex-1 overflow-hidden">
        {/* Left Column: Messages List (4 cols) */}
        <div className="md:col-span-5 border-r border-slate-200 dark:border-slate-800 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/80">
          {inboxItems.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <Inbox className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-xs font-bold text-slate-500">Your Scripture inbox is currently empty</p>
              <p className="text-[11px] text-slate-400">
                When pastors or ministry leads share scheduled verses or notes, they will appear here.
              </p>
            </div>
          ) : (
            inboxItems.map((item) => {
              const isSelected = selectedMessage?.id === item.id;
              return (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => handleSelectMessage(item)}
                  className={`w-full text-left p-4 transition-all cursor-pointer flex flex-col gap-1.5 ${
                    isSelected
                      ? 'bg-blue-50/70 dark:bg-blue-950/40 border-l-4 border-blue-600'
                      : !item.read
                      ? 'bg-amber-50/40 dark:bg-amber-950/10 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-1.5">
                      {!item.read && (
                        <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />
                      )}
                      <span className="text-xs font-black text-slate-900 dark:text-white">
                        {item.reference}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">
                        ({item.translationAbbreviation || 'NIV'})
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {item.sentAt
                        ? new Date(item.sentAt).toLocaleDateString([], { month: 'short', day: 'numeric' })
                        : ''}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-1 italic font-serif">
                    "{item.passageText}"
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                    <span className="font-bold text-slate-600 dark:text-slate-300">
                      {item.senderName} ({item.senderRole})
                    </span>
                    {item.read ? (
                      <span className="flex items-center gap-0.5 text-emerald-600 dark:text-emerald-400">
                        <Check className="w-3 h-3" /> Read
                      </span>
                    ) : (
                      <span className="text-blue-600 font-bold">New</span>
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Right Column: Selected Message Reader (7 cols) */}
        <div className="md:col-span-7 p-6 overflow-y-auto bg-slate-50/30 dark:bg-slate-900/40 flex flex-col justify-between space-y-6">
          {selectedMessage ? (
            <div className="space-y-6">
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-xl text-xs font-black bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900">
                      {selectedMessage.reference}
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      {selectedMessage.translationName || selectedMessage.translationAbbreviation}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Sent by <strong>{selectedMessage.senderName}</strong> ({selectedMessage.senderRole}) on{' '}
                    {selectedMessage.sentAt ? new Date(selectedMessage.sentAt).toLocaleString() : ''}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopyPassage(selectedMessage)}
                    className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="Copy Verse and Note"
                  >
                    {copiedId === selectedMessage.id ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                    <span className="hidden sm:inline">Copy</span>
                  </button>

                  {onOpenInReader && (
                    <button
                      type="button"
                      onClick={() =>
                        onOpenInReader(selectedMessage.reference, selectedMessage.translationId)
                      }
                      className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                      title="Open Chapter in Bible Reader"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Open in Reader</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Holy Scripture Box */}
              <div className="p-6 rounded-3xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4" />
                    <span>Holy Scripture</span>
                  </span>
                  <span className="text-xs font-bold text-slate-400">
                    {selectedMessage.reference}
                  </span>
                </div>

                <p className="text-base font-serif leading-relaxed text-slate-900 dark:text-slate-100 italic">
                  "{selectedMessage.passageText}"
                </p>
              </div>

              {/* Pastor's Separate Reflection */}
              {selectedMessage.note && (
                <div className="p-6 rounded-3xl bg-amber-50/80 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/50 shadow-sm space-y-2.5">
                  <div className="flex items-center gap-2 text-amber-900 dark:text-amber-300">
                    <MessageSquare className="w-4 h-4" />
                    <span className="text-xs font-black uppercase tracking-wider">
                      Pastor's Encouragement & Reflection
                    </span>
                  </div>

                  <p className="text-xs text-amber-950 dark:text-amber-100 whitespace-pre-line leading-relaxed">
                    {selectedMessage.note}
                  </p>
                </div>
              )}

              {/* Footer Note */}
              <div className="p-4 rounded-2xl bg-blue-50/40 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/40 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                <span>
                  Delivered through CMMS Pastoral Care to <strong>{selectedMessage.recipientType}</strong>
                </span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Received
                </span>
              </div>
            </div>
          ) : (
            <div className="m-auto text-center space-y-2 py-20">
              <BookOpen className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-500">Select a message to read</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
