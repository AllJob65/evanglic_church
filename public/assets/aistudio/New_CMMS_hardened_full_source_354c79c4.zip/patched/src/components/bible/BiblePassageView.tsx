import React, { useState } from 'react';
import { useBible } from '../../context/BibleContext';
import { BiblePassage, normalizeToUsfm } from './BiblePassage';
import { BookOpen, Search, ArrowLeft, ExternalLink, Sparkles, Globe } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';

export const BiblePassageView: React.FC = () => {
  const { selectedVersionId, setSelectedVersionId, jumpToReference } = useBible();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const initialRef = searchParams.get('ref') || 'JHN.3.16';
  const [reference, setReference] = useState<string>(initialRef);
  const [inputVal, setInputVal] = useState<string>('');

  const QUICK_PASSAGES = [
    { label: 'John 3:16', ref: 'JHN.3.16' },
    { label: 'Psalm 23', ref: 'PSA.23.1-6' },
    { label: 'Romans 8:28', ref: 'ROM.8.28' },
    { label: 'Philippians 4:13', ref: 'PHP.4.13' },
    { label: 'Genesis 1:1-5', ref: 'GEN.1.1-5' },
    { label: '1 Corinthians 13:4-8', ref: '1CO.13.4-8' },
    { label: 'Proverbs 3:5-6', ref: 'PRO.3.5-6' },
    { label: 'Isaiah 40:31', ref: 'ISA.40.31' },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    const usfm = normalizeToUsfm(inputVal.trim());
    setReference(usfm);
    setSearchParams({ ref: usfm });
    setInputVal('');
  };

  const handleSelectPreset = (ref: string) => {
    setReference(ref);
    setSearchParams({ ref });
  };

  const handleOpenReader = () => {
    jumpToReference(reference);
    navigate('/bible');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto p-4 sm:p-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate('/bible')}
            className="p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Back to Bible Reader"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-blue-600" />
              <span>Scripture Passages & Verses</span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Official YouVersion BibleCard passage reader
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleOpenReader}
          className="px-4 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer self-start sm:self-auto"
        >
          <span>Open in Full Bible Reader</span>
          <ExternalLink className="w-4 h-4" />
        </button>
      </div>

      {/* Search and Presets Box */}
      <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Search passage e.g. JHN.3.16, Psalms 23:1-6, Romans 8:28..."
              className="w-full pl-10 pr-4 py-2.5 text-xs rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer transition-colors"
          >
            Lookup
          </button>
        </form>

        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-xs font-bold text-slate-400">Popular Passages:</span>
          {QUICK_PASSAGES.map((p) => (
            <button
              key={p.ref}
              type="button"
              onClick={() => handleSelectPreset(p.ref)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                reference === p.ref
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Passage Display Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 sm:p-6">
        <BiblePassage
          reference={reference}
          versionId={selectedVersionId}
          onVersionChange={setSelectedVersionId}
          showVersionPicker={true}
          showHeading={true}
          title={`Scripture Passage: ${reference}`}
          onReadFullChapter={handleOpenReader}
        />
      </div>
    </div>
  );
};

export default BiblePassageView;
