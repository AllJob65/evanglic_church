import React, { useState } from 'react';
import { SunMedium, X, BookOpen, Send } from 'lucide-react';
import { BibleVerseItem, BibleBookInfo } from '../../data/bibleCanon';
import { Devotion } from '../../types';

interface BibleDevotionModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedVerses: BibleVerseItem[];
  currentBook: BibleBookInfo;
  chapterNumber: number;
  onSaveDevotion: (devotionData: Partial<Devotion>) => Promise<void>;
}

export const BibleDevotionModal: React.FC<BibleDevotionModalProps> = ({
  isOpen,
  onClose,
  selectedVerses,
  currentBook,
  chapterNumber,
  onSaveDevotion,
}) => {
  if (!isOpen || selectedVerses.length === 0) return null;

  const sortedVerses = [...selectedVerses].sort(
    (a, b) => (a.verse || a.verseNumber) - (b.verse || b.verseNumber)
  );
  const verseNumbers = sortedVerses.map((v) => v.verse || v.verseNumber);
  const isContinuous =
    verseNumbers.length > 1 &&
    verseNumbers[verseNumbers.length - 1] - verseNumbers[0] === verseNumbers.length - 1;

  const citation = isContinuous
    ? `${currentBook.nameEnglish} ${chapterNumber}:${verseNumbers[0]}–${verseNumbers[verseNumbers.length - 1]}`
    : `${currentBook.nameEnglish} ${chapterNumber}:${verseNumbers.join(', ')}`;

  const amhCitation = isContinuous
    ? `${currentBook.nameAmharic} ${chapterNumber}፥${verseNumbers[0]}–${verseNumbers[verseNumbers.length - 1]}`
    : `${currentBook.nameAmharic} ${chapterNumber}፥${verseNumbers.join('፣ ')}`;

  // Combine verses text
  const englishText = sortedVerses.map((v) => `[${v.verse || v.verseNumber}] ${v.english || v.textEnglish}`).join(' ');
  const amharicText = sortedVerses.map((v) => `[${v.verse || v.verseNumber}] ${v.amharic || v.textAmharic}`).join(' ');

  const [title, setTitle] = useState(`Reflection on ${citation}`);
  const [topic, setTopic] = useState('Faith & Strength');
  const [reflection, setReflection] = useState('');
  const [prayer, setPrayer] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    try {
      await onSaveDevotion({
        title: title.trim(),
        amharicTitle: `የዕለት ቃል ከ${amhCitation}`,
        scriptureReference: citation,
        keyVerse: englishText,
        body: reflection.trim() || `Meditation and study on ${citation}:\n\n${englishText}\n\n${amharicText}`,
        prayer: prayer.trim() || 'Lord, help me apply this holy scripture to my daily walk. Amen.',
        topic: topic,
        authorName: 'Church Member / Bible Reader',
        publishedAt: new Date().toISOString(),
        status: 'published',
      });
      onClose();
    } catch (err) {
      console.error('Failed to create devotion from Bible passage:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/20">
              <SunMedium className="w-5 h-5 text-amber-200" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                Add to Daily Devotion (የዕለት ቃል / ጥናት)
              </h3>
              <p className="text-xs text-amber-100">
                Create a devotion from {citation} ({amhCitation})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Selected Scripture Preview Box */}
          <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-amber-900 dark:text-amber-300">
              <span>{citation}</span>
              <span className="font-menbere text-amber-700 dark:text-amber-400">{amhCitation}</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic line-clamp-3">
              "{englishText}"
            </p>
          </div>

          {/* Devotion Title */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400 mb-1">
              Devotion Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              placeholder="e.g. Walking in Grace and Faith"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Topic */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400 mb-1">
              Spiritual Topic
            </label>
            <select
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
            >
              <option value="Faith & Strength">Faith & Strength (እምነት እና ብርታት)</option>
              <option value="Prayer & Communion">Prayer & Communion (ጸሎት እና ሕብረት)</option>
              <option value="Spiritual Growth">Spiritual Growth (መንፈሳዊ ዕድገት)</option>
              <option value="Peace & Protection">Peace & Protection (ሰላም እና ጥበቃ)</option>
              <option value="Grace & Thanksgiving">Grace & Thanksgiving (ጸጋ እና ምስጋና)</option>
              <option value="Worship & Praise">Worship & Praise (አምልኮ እና ውዳሴ)</option>
              <option value="Leadership & Service">Leadership & Service (አመራር እና አገልግሎት)</option>
              <option value="Family & Marriage">Family & Marriage (ቤተሰብ እና ጋብቻ)</option>
            </select>
          </div>

          {/* Personal Reflection */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400 mb-1">
              Meditation & Reflection (የጥናት ማስታወሻ / አስተንትኖ)
            </label>
            <textarea
              rows={3}
              value={reflection}
              onChange={(e) => setReflection(e.target.value)}
              placeholder="What is God speaking to your heart through this passage?"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Closing Prayer */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400 mb-1">
              Prayer (የጸሎት ቃል)
            </label>
            <textarea
              rows={2}
              value={prayer}
              onChange={(e) => setPrayer(e.target.value)}
              placeholder="Lord Jesus, teach me to live according to Your holy word..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white shadow-md disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Saving...' : 'Save Devotion'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
