import React, { useState, useEffect } from 'react';
import {
  Send,
  Calendar,
  Clock,
  FileText,
  Users,
  CheckCircle2,
  AlertCircle,
  Search,
  BookOpen,
  Copy,
  Trash2,
  Edit3,
  RefreshCw,
  Sparkles,
  ChevronRight,
  Shield,
  Layers,
  X,
  ExternalLink,
  MessageSquare,
  Globe,
  Radio,
} from 'lucide-react';
import { BibleMessage, BibleRecipientType, BibleMessageStatus } from '../../types';
import { bibleService } from '../../services/bibleService';
import { useCMMS } from '../../context/CMMSContext';
import { BIBLE_CANON, BibleBookInfo } from '../../data/bibleCanon';

interface BibleMessageManagerProps {
  initialReference?: string;
  initialPassageText?: string;
  initialBookId?: string;
  initialChapter?: number;
  initialVerseStart?: number;
  initialVerseEnd?: number;
  initialTranslationId?: number | string;
  onClose?: () => void;
  onOpenInReader?: (ref: string) => void;
}

const QUICK_PASSAGE_PRESETS = [
  { label: 'John 3:16-17', bookId: 'JHN', bookName: 'John', chapter: 3, vStart: 16, vEnd: 17, text: 'For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life. For God did not send his Son into the world to condemn the world, but to save the world through him.' },
  { label: 'Romans 8:28', bookId: 'ROM', bookName: 'Romans', chapter: 8, vStart: 28, vEnd: 28, text: 'And we know that in all things God works for the good of those who love him, who have been called according to his purpose.' },
  { label: 'Psalm 23:1-3', bookId: 'PSA', bookName: 'Psalms', chapter: 23, vStart: 1, vEnd: 3, text: 'The Lord is my shepherd; I shall not want. He makes me lie down in green pastures. He leads me beside still waters. He restores my soul.' },
  { label: 'Philippians 4:13', bookId: 'PHP', bookName: 'Philippians', chapter: 4, vStart: 13, vEnd: 13, text: 'I can do all this through him who gives me strength.' },
  { label: 'Isaiah 40:31', bookId: 'ISA', bookName: 'Isaiah', chapter: 40, vStart: 31, vEnd: 31, text: 'But those who hope in the Lord will renew their strength. They will soar on wings like eagles; they will run and not grow weary, they will walk and not be faint.' },
  { label: 'Proverbs 3:5-6', bookId: 'PRO', bookName: 'Proverbs', chapter: 3, vStart: 5, vEnd: 6, text: 'Trust in the Lord with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.' },
  { label: '1 Corinthians 13:4-7', bookId: '1CO', bookName: '1 Corinthians', chapter: 13, vStart: 4, vEnd: 7, text: 'Love is patient, love is kind. It does not envy, it does not boast, it is not proud. It does not dishonor others, it is not self-seeking, it is not easily angered, it keeps no record of wrongs.' },
  { label: 'Matthew 28:19-20', bookId: 'MAT', bookName: 'Matthew', chapter: 28, vStart: 19, vEnd: 20, text: 'Therefore go and make disciples of all nations, baptizing them in the name of the Father and of the Son and of the Holy Spirit, and teaching them to obey everything I have commanded you.' },
];

const TRANSLATIONS = [
  { id: 111, abbr: 'NIV', name: 'New International Version (NIV)', lang: 'English' },
  { id: 3034, abbr: 'BSB', name: 'Berean Standard Bible (BSB)', lang: 'English' },
  { id: 1, abbr: 'KJV', name: 'King James Version (KJV)', lang: 'English' },
  { id: 206, abbr: 'WEB', name: 'World English Bible (WEB)', lang: 'English' },
  { id: 1260, abbr: 'NASV', name: 'New Amharic Standard (NASV / አዲሱ መደበኛ)', lang: 'Amharic' },
];

export const BibleMessageManager: React.FC<BibleMessageManagerProps> = ({
  initialReference,
  initialPassageText,
  initialBookId,
  initialChapter,
  initialVerseStart,
  initialVerseEnd,
  initialTranslationId,
  onClose,
  onOpenInReader,
}) => {
  const { currentUser: currentCmmsUser, ministries, branches, members } = useCMMS();

  // Active view tab: 'composer' | 'scheduled' | 'sent' | 'drafts'
  const [activeTab, setActiveTab] = useState<'composer' | 'scheduled' | 'sent' | 'drafts'>('composer');

  // Messages state
  const [messages, setMessages] = useState<BibleMessage[]>([]);
  const [stats, setStats] = useState({ total: 0, sent: 0, scheduled: 0, drafts: 0, cancelled: 0 });
  const [isLoading, setIsLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Composer Form State
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [selectedTranslationId, setSelectedTranslationId] = useState<number | string>(initialTranslationId || 111);
  const [selectedBookId, setSelectedBookId] = useState<string>(initialBookId || 'JHN');
  const [selectedChapter, setSelectedChapter] = useState<number>(initialChapter || 3);
  const [verseStart, setVerseStart] = useState<number>(initialVerseStart || 16);
  const [verseEnd, setVerseEnd] = useState<number | undefined>(initialVerseEnd || 17);
  const [reference, setReference] = useState<string>(initialReference || 'John 3:16-17');
  const [passageText, setPassageText] = useState<string>(
    initialPassageText ||
      'For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life. For God did not send his Son into the world to condemn the world, but to save the world through him.'
  );
  const [pastorNote, setPastorNote] = useState<string>('');
  const [recipientType, setRecipientType] = useState<BibleRecipientType>('all');
  const [selectedTargetIds, setSelectedTargetIds] = useState<string[]>([]);

  // Schedule modal state
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [scheduleDate, setScheduleDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [scheduleTime, setScheduleTime] = useState<string>('08:00');
  const [scheduleTimezone, setScheduleTimezone] = useState<string>('Africa/Addis_Ababa');

  // Confirmation dialog before send/schedule
  const [confirmationDialog, setConfirmationDialog] = useState<{
    isOpen: boolean;
    mode: 'send' | 'schedule';
    recipientCount: number;
    sampleNames: string[];
  } | null>(null);

  // Recipient Count preview
  const [recipientCount, setRecipientCount] = useState<number>(0);
  const [sampleRecipients, setSampleRecipients] = useState<string[]>([]);
  const [isCalculatingRecipients, setIsCalculatingRecipients] = useState(false);

  // Active message details modal
  const [viewingMessage, setViewingMessage] = useState<BibleMessage | null>(null);

  const currentUser = {
    userId: currentCmmsUser?.memberId || currentCmmsUser?.email || 'usr-pastor-samuel',
    userName: currentCmmsUser?.name || 'Pastor Samuel Abebe',
    userRole: (currentCmmsUser?.role as string) || 'PASTOR',
  };

  // Load messages from server
  const loadMessages = async () => {
    setIsLoading(true);
    try {
      const data = await bibleService.getMessages({
        status: statusFilter === 'all' ? undefined : statusFilter,
        search: searchQuery || undefined,
      });
      setMessages(data.messages);
      setStats(data.stats);
    } catch (e) {
      console.error('Error loading Bible messages:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMessages();
  }, [statusFilter, searchQuery]);

  // Update recipient count dynamically whenever targeting changes
  useEffect(() => {
    let isCancelled = false;
    const updateCount = async () => {
      setIsCalculatingRecipients(true);
      try {
        const res = await bibleService.getRecipientCount(recipientType, selectedTargetIds);
        if (!isCancelled) {
          setRecipientCount(res.count);
          setSampleRecipients(res.sampleNames);
        }
      } catch (e) {
        console.error('Error fetching recipient count:', e);
      } finally {
        if (!isCancelled) setIsCalculatingRecipients(false);
      }
    };
    updateCount();
    return () => {
      isCancelled = true;
    };
  }, [recipientType, selectedTargetIds]);

  // Sync reference when book, chapter, or verses change
  const handleBookChange = (bookId: string) => {
    setSelectedBookId(bookId);
    const book = BIBLE_CANON.find((b) => b.id === bookId);
    const bName = book?.nameEnglish || bookId;
    const newRef = `${bName} ${selectedChapter}:${verseStart}${verseEnd && verseEnd > verseStart ? `-${verseEnd}` : ''}`;
    setReference(newRef);
    lookupPassageText(bookId, selectedChapter, verseStart, verseEnd);
  };

  const handleChapterChange = (chapter: number) => {
    setSelectedChapter(chapter);
    const book = BIBLE_CANON.find((b) => b.id === selectedBookId);
    const bName = book?.nameEnglish || selectedBookId;
    const newRef = `${bName} ${chapter}:${verseStart}${verseEnd && verseEnd > verseStart ? `-${verseEnd}` : ''}`;
    setReference(newRef);
    lookupPassageText(selectedBookId, chapter, verseStart, verseEnd);
  };

  const handleVerseRangeChange = (start: number, end?: number) => {
    setVerseStart(start);
    setVerseEnd(end);
    const book = BIBLE_CANON.find((b) => b.id === selectedBookId);
    const bName = book?.nameEnglish || selectedBookId;
    const newRef = `${bName} ${selectedChapter}:${start}${end && end > start ? `-${end}` : ''}`;
    setReference(newRef);
    lookupPassageText(selectedBookId, selectedChapter, start, end);
  };

  // Lookup passage text live from YouVersion via bibleService
  const lookupPassageText = (bookId: string, chapter: number, start: number, end?: number) => {
    const isAmharic = selectedTranslationId === 1260;
    bibleService.getPassage(bookId, chapter, String(selectedTranslationId)).then((chapterData) => {
      if (chapterData && chapterData.verses && chapterData.verses.length > 0) {
        const vEnd = end && end >= start ? end : start;
        const matched = chapterData.verses.filter((v) => v.verseNumber >= start && v.verseNumber <= vEnd);
        if (matched.length > 0) {
          const text = matched
            .map((v) => (isAmharic ? v.textAmharic : selectedTranslationId === 1 ? v.textKJV || v.textEnglish : v.textEnglish))
            .join(' ');
          setPassageText(text);
          return;
        }
      }
      setPassageText('');
    }).catch(() => {
      setPassageText('');
    });
  };

  // Handle Preset selection
  const handleApplyPreset = (preset: typeof QUICK_PASSAGE_PRESETS[0]) => {
    setSelectedBookId(preset.bookId);
    setSelectedChapter(preset.chapter);
    setVerseStart(preset.vStart);
    setVerseEnd(preset.vEnd);
    setReference(preset.label);
    setPassageText(preset.text);
  };

  // Get active translation info
  const currentTrans = TRANSLATIONS.find((t) => t.id === Number(selectedTranslationId)) || TRANSLATIONS[0];
  const currentBook = BIBLE_CANON.find((b) => b.id === selectedBookId) || BIBLE_CANON[0];

  // Open Confirmation dialog
  const promptSendConfirmation = () => {
    if (!reference.trim() || !passageText.trim()) {
      alert('Please select a valid Scripture passage before sending.');
      return;
    }
    setConfirmationDialog({
      isOpen: true,
      mode: 'send',
      recipientCount,
      sampleNames: sampleRecipients,
    });
  };

  const promptScheduleConfirmation = () => {
    if (!reference.trim() || !passageText.trim()) {
      alert('Please select a valid Scripture passage before scheduling.');
      return;
    }
    setIsScheduleModalOpen(true);
  };

  // Execute Save as Draft
  const handleSaveDraft = async () => {
    try {
      const payload: Partial<BibleMessage> = {
        translationId: currentTrans.id,
        translationName: currentTrans.name,
        translationAbbreviation: currentTrans.abbr,
        bookId: currentBook.id,
        bookName: currentBook.nameEnglish,
        chapter: selectedChapter,
        verseStart,
        verseEnd,
        reference,
        passageText,
        note: pastorNote,
        recipientType,
        recipientTargetIds: selectedTargetIds,
        recipientTargetNames: getTargetNames(),
        status: 'draft',
      };

      if (editingMessageId) {
        await bibleService.updateMessage(currentUser, editingMessageId, payload);
      } else {
        await bibleService.createMessage(currentUser, payload);
      }

      await loadMessages();
      setActiveTab('drafts');
      setEditingMessageId(null);
    } catch (e: any) {
      alert(`Failed to save draft: ${e.message}`);
    }
  };

  // Execute Schedule Message
  const handleExecuteSchedule = async () => {
    try {
      const scheduledDateTime = new Date(`${scheduleDate}T${scheduleTime}:00`).toISOString();
      const payload: Partial<BibleMessage> = {
        translationId: currentTrans.id,
        translationName: currentTrans.name,
        translationAbbreviation: currentTrans.abbr,
        bookId: currentBook.id,
        bookName: currentBook.nameEnglish,
        chapter: selectedChapter,
        verseStart,
        verseEnd,
        reference,
        passageText,
        note: pastorNote,
        recipientType,
        recipientTargetIds: selectedTargetIds,
        recipientTargetNames: getTargetNames(),
        status: 'scheduled',
        scheduledAt: scheduledDateTime,
        timezone: scheduleTimezone,
      };

      if (editingMessageId) {
        await bibleService.updateMessage(currentUser, editingMessageId, payload);
      } else {
        await bibleService.createMessage(currentUser, payload);
      }

      setIsScheduleModalOpen(false);
      await loadMessages();
      setActiveTab('scheduled');
      setEditingMessageId(null);
    } catch (e: any) {
      alert(`Failed to schedule message: ${e.message}`);
    }
  };

  // Execute Send Immediately
  const handleExecuteSendNow = async () => {
    try {
      const payload: Partial<BibleMessage> = {
        translationId: currentTrans.id,
        translationName: currentTrans.name,
        translationAbbreviation: currentTrans.abbr,
        bookId: currentBook.id,
        bookName: currentBook.nameEnglish,
        chapter: selectedChapter,
        verseStart,
        verseEnd,
        reference,
        passageText,
        note: pastorNote,
        recipientType,
        recipientTargetIds: selectedTargetIds,
        recipientTargetNames: getTargetNames(),
        status: 'sent',
      };

      if (editingMessageId) {
        await bibleService.updateMessage(currentUser, editingMessageId, payload);
      } else {
        await bibleService.createMessage(currentUser, payload);
      }

      setConfirmationDialog(null);
      await loadMessages();
      setActiveTab('sent');
      setEditingMessageId(null);
      setPastorNote('');
    } catch (e: any) {
      alert(`Failed to broadcast message: ${e.message}`);
    }
  };

  // Helper to extract target names for audit & UI
  const getTargetNames = (): string[] => {
    if (recipientType === 'all') return ['Entire Church Fellowship'];
    if (recipientType === 'ministry') {
      return ministries.filter((m) => selectedTargetIds.includes(m.id)).map((m) => m.name);
    }
    if (recipientType === 'branch') {
      return branches.filter((b) => selectedTargetIds.includes(b.id)).map((b) => b.name);
    }
    if (recipientType === 'members') {
      return members
        .filter((m) => selectedTargetIds.includes(m.id))
        .map((m) => `${m.firstName} ${m.lastName}`.trim());
    }
    return ['Custom Target'];
  };

  // Load draft into composer
  const handleEditDraft = (msg: BibleMessage) => {
    setEditingMessageId(msg.id);
    setSelectedTranslationId(msg.translationId);
    setSelectedBookId(msg.bookId);
    setSelectedChapter(msg.chapter);
    setVerseStart(msg.verseStart);
    setVerseEnd(msg.verseEnd);
    setReference(msg.reference);
    setPassageText(msg.passageText);
    setPastorNote(msg.note || '');
    setRecipientType(msg.recipientType);
    setSelectedTargetIds(msg.recipientTargetIds || []);
    setActiveTab('composer');
  };

  // Quick Send from Table
  const handleSendFromList = async (msg: BibleMessage) => {
    if (
      !window.confirm(
        `Are you sure you want to broadcast "${msg.reference}" to ${msg.recipientCount || 'all eligible'} members immediately?`
      )
    ) {
      return;
    }
    try {
      await bibleService.sendMessageNow(currentUser, msg.id);
      await loadMessages();
    } catch (e: any) {
      alert(`Failed to send message: ${e.message}`);
    }
  };

  // Cancel Scheduled
  const handleCancelMessage = async (msg: BibleMessage) => {
    if (!window.confirm(`Are you sure you want to cancel scheduled broadcast for "${msg.reference}"?`)) return;
    try {
      await bibleService.cancelMessage(currentUser, msg.id);
      await loadMessages();
    } catch (e: any) {
      alert(`Failed to cancel message: ${e.message}`);
    }
  };

  // Duplicate Message
  const handleDuplicateMessage = async (msg: BibleMessage) => {
    try {
      await bibleService.duplicateMessage(currentUser, msg.id);
      await loadMessages();
      setActiveTab('drafts');
    } catch (e: any) {
      alert(`Failed to duplicate message: ${e.message}`);
    }
  };

  // Delete Message
  const handleDeleteMessage = async (msg: BibleMessage) => {
    if (!window.confirm(`Permanently delete this message record?`)) return;
    try {
      await bibleService.deleteMessage(currentUser, msg.id);
      await loadMessages();
    } catch (e: any) {
      alert(`Failed to delete message: ${e.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-slate-900 dark:text-white">
                  Pastor & Ministry Bible Message Center
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                  Pastoral Office
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Compose, schedule, and broadcast Holy Scripture passages with pastoral notes to congregation members
              </p>
            </div>
          </div>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 self-start sm:self-auto cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* 4 Metric Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">Sent Messages</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <p className="text-xl font-black text-slate-900 dark:text-white mt-1">{stats.sent}</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">Scheduled Queue</span>
              <Clock className="w-4 h-4 text-blue-500" />
            </div>
            <p className="text-xl font-black text-slate-900 dark:text-white mt-1">{stats.scheduled}</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">Active Drafts</span>
              <FileText className="w-4 h-4 text-amber-500" />
            </div>
            <p className="text-xl font-black text-slate-900 dark:text-white mt-1">{stats.drafts}</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">Total Church Outreach</span>
              <Users className="w-4 h-4 text-purple-500" />
            </div>
            <p className="text-xl font-black text-slate-900 dark:text-white mt-1">
              {messages
                .filter((m) => m.status === 'sent')
                .reduce((acc, m) => acc + (m.recipientCount || 0), 0)}
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => setActiveTab('composer')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'composer'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>Compose Scripture Message</span>
            {editingMessageId && (
              <span className="ml-1 px-1.5 py-0.5 rounded bg-amber-400 text-slate-900 text-[10px] font-black">
                Editing
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('scheduled')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'scheduled'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Scheduled Delivery ({stats.scheduled})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('sent')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'sent'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Sent Messages ({stats.sent})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('drafts')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'drafts'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Drafts ({stats.drafts})</span>
          </button>
        </div>
      </div>

      {/* =================================================================== */}
      {/* 1. COMPOSER TAB */}
      {/* =================================================================== */}
      {activeTab === 'composer' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Scripture Selection & Note Form */}
          <div className="lg:col-span-2 space-y-6">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <span>1. Scripture Passage Selection</span>
                </h3>
                <span className="text-xs font-bold text-slate-400">
                  Translation: {currentTrans.abbr}
                </span>
              </div>

              {/* Translation and Preset Picker */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                    Bible Translation / Version
                  </label>
                  <select
                    value={selectedTranslationId}
                    onChange={(e) => {
                      setSelectedTranslationId(e.target.value);
                      lookupPassageText(selectedBookId, selectedChapter, verseStart, verseEnd);
                    }}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                  >
                    {TRANSLATIONS.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.lang})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                    Quick Key Scripture Presets
                  </label>
                  <select
                    onChange={(e) => {
                      const preset = QUICK_PASSAGE_PRESETS.find((p) => p.label === e.target.value);
                      if (preset) handleApplyPreset(preset);
                    }}
                    defaultValue=""
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                  >
                    <option value="" disabled>
                      Choose inspirational scripture preset...
                    </option>
                    {QUICK_PASSAGE_PRESETS.map((p) => (
                      <option key={p.label} value={p.label}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Book, Chapter, Verse Start, Verse End Picker */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Book</label>
                  <select
                    value={selectedBookId}
                    onChange={(e) => handleBookChange(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  >
                    {BIBLE_CANON.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.nameEnglish} ({b.nameAmharic})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Chapter</label>
                  <input
                    type="number"
                    min={1}
                    max={150}
                    value={selectedChapter}
                    onChange={(e) => handleChapterChange(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Verse Start</label>
                  <input
                    type="number"
                    min={1}
                    max={176}
                    value={verseStart}
                    onChange={(e) => handleVerseRangeChange(Math.max(1, parseInt(e.target.value, 10) || 1), verseEnd)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Verse End (Optional)</label>
                  <input
                    type="number"
                    min={verseStart}
                    max={176}
                    value={verseEnd || ''}
                    placeholder="End verse"
                    onChange={(e) =>
                      handleVerseRangeChange(
                        verseStart,
                        e.target.value ? Math.max(verseStart, parseInt(e.target.value, 10)) : undefined
                      )
                    }
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  />
                </div>
              </div>

              {/* Passage Text Preview Card */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-blue-600 dark:text-blue-400">
                    {reference} ({currentTrans.abbr})
                  </span>
                  {onOpenInReader && (
                    <button
                      type="button"
                      onClick={() => onOpenInReader(reference)}
                      className="text-[11px] text-slate-500 hover:text-blue-600 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Preview in Reader</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <textarea
                  rows={4}
                  value={passageText}
                  onChange={(e) => setPassageText(e.target.value)}
                  placeholder="Scripture passage text..."
                  className="w-full p-2.5 text-xs font-serif leading-relaxed rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 resize-y"
                />
              </div>

              {/* Pastor's Separate Note / Reflection */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-amber-500" />
                    <span>2. Pastor / Leader Reflection & Note</span>
                  </label>
                  <span className="text-[11px] text-slate-400">{pastorNote.length} characters</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  This note is displayed separately from the Holy Scripture passage so recipients clearly distinguish pastoral encouragement from God's inspired word.
                </p>
                <textarea
                  rows={4}
                  value={pastorNote}
                  onChange={(e) => setPastorNote(e.target.value)}
                  placeholder="Write pastoral encouragement, study prompt, prayer guidance, or sermon application..."
                  className="w-full p-3 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Right Col: Recipient Targeting & Action Bar */}
          <div className="space-y-6">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                <span>3. Recipient Targeting</span>
              </h3>

              {/* Target Type Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300">
                  Target Audience
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { id: 'all', label: 'Entire Church Congregation', desc: 'All registered active members' },
                    { id: 'ministry', label: 'Specific Ministry Group', desc: 'Choir, Youth, Intercession, etc.' },
                    { id: 'branch', label: 'Specific Branch / Chapel', desc: 'Headquarters, Bole Chapel, etc.' },
                    { id: 'members', label: 'Selected Individual Members', desc: 'Handpicked recipients' },
                  ].map((target) => (
                    <label
                      key={target.id}
                      className={`p-3 rounded-2xl border text-xs cursor-pointer flex items-start gap-3 transition-all ${
                        recipientType === target.id
                          ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/40 text-slate-900 dark:text-white shadow-xs'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="recipientType"
                        checked={recipientType === target.id}
                        onChange={() => {
                          setRecipientType(target.id as BibleRecipientType);
                          setSelectedTargetIds([]);
                        }}
                        className="mt-0.5 text-blue-600"
                      />
                      <div>
                        <p className="font-bold">{target.label}</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">{target.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Secondary selector based on recipientType */}
              {recipientType === 'ministry' && (
                <div className="space-y-2 animate-in fade-in">
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300">
                    Select Ministries
                  </label>
                  <div className="max-h-40 overflow-y-auto space-y-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {ministries.map((min) => (
                      <label key={min.id} className="flex items-center gap-2 text-xs cursor-pointer p-1 rounded hover:bg-white dark:hover:bg-slate-700">
                        <input
                          type="checkbox"
                          checked={selectedTargetIds.includes(min.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedTargetIds([...selectedTargetIds, min.id]);
                            } else {
                              setSelectedTargetIds(selectedTargetIds.filter((id) => id !== min.id));
                            }
                          }}
                          className="rounded text-blue-600"
                        />
                        <span className="font-medium text-slate-800 dark:text-slate-200">{min.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {recipientType === 'branch' && (
                <div className="space-y-2 animate-in fade-in">
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300">
                    Select Branch / Campus
                  </label>
                  <div className="max-h-40 overflow-y-auto space-y-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {branches.map((br) => (
                      <label key={br.id} className="flex items-center gap-2 text-xs cursor-pointer p-1 rounded hover:bg-white dark:hover:bg-slate-700">
                        <input
                          type="checkbox"
                          checked={selectedTargetIds.includes(br.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedTargetIds([...selectedTargetIds, br.id]);
                            } else {
                              setSelectedTargetIds(selectedTargetIds.filter((id) => id !== br.id));
                            }
                          }}
                          className="rounded text-blue-600"
                        />
                        <span className="font-medium text-slate-800 dark:text-slate-200">{br.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {recipientType === 'members' && (
                <div className="space-y-2 animate-in fade-in">
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300">
                    Pick Members ({selectedTargetIds.length} chosen)
                  </label>
                  <div className="max-h-48 overflow-y-auto space-y-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {members.slice(0, 30).map((mem) => (
                      <label key={mem.id} className="flex items-center gap-2 text-xs cursor-pointer p-1 rounded hover:bg-white dark:hover:bg-slate-700">
                        <input
                          type="checkbox"
                          checked={selectedTargetIds.includes(mem.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedTargetIds([...selectedTargetIds, mem.id]);
                            } else {
                              setSelectedTargetIds(selectedTargetIds.filter((id) => id !== mem.id));
                            }
                          }}
                          className="rounded text-blue-600"
                        />
                        <span className="font-medium text-slate-800 dark:text-slate-200">
                          {mem.firstName} {mem.lastName}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Recipient Count Indicator */}
              <div className="p-3.5 rounded-2xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  <span className="text-xs font-bold text-purple-900 dark:text-purple-200">
                    Audience Reach:
                  </span>
                </div>
                <span className="text-sm font-black text-purple-700 dark:text-purple-300">
                  {isCalculatingRecipients ? 'Calculating...' : `${recipientCount} Members`}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={promptSendConfirmation}
                  className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Scripture Now</span>
                </button>

                <button
                  type="button"
                  onClick={promptScheduleConfirmation}
                  className="w-full py-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-xs font-bold flex items-center justify-center gap-2 border border-indigo-200 dark:border-indigo-800 transition-all cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Schedule For Later</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveDraft}
                  className="w-full py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <FileText className="w-4 h-4" />
                  <span>{editingMessageId ? 'Update Draft' : 'Save as Draft'}</span>
                </button>

                {editingMessageId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingMessageId(null);
                      setPastorNote('');
                    }}
                    className="w-full py-2 text-center text-[11px] text-slate-500 hover:text-slate-800 dark:hover:text-white cursor-pointer font-bold"
                  >
                    Cancel Editing
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 2. SCHEDULED MESSAGES TAB */}
      {/* =================================================================== */}
      {activeTab === 'scheduled' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                <span>Active Scheduled Delivery Queue</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Scripture messages queued for background delivery without requiring browser to remain open
              </p>
            </div>
            <button
              type="button"
              onClick={loadMessages}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              title="Refresh Queue"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {messages.filter((m) => m.status === 'scheduled').length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <Clock className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
                <p className="text-sm font-bold text-slate-500">No scheduled Bible messages currently in queue</p>
                <button
                  type="button"
                  onClick={() => setActiveTab('composer')}
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Schedule a Scripture Message</span>
                </button>
              </div>
            ) : (
              messages
                .filter((m) => m.status === 'scheduled')
                .map((msg) => (
                  <div key={msg.id} className="p-5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <span className="px-2.5 py-1 rounded-lg text-xs font-black bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                          {msg.reference}
                        </span>
                        <span className="text-xs font-bold text-slate-500">
                          ({msg.translationAbbreviation || 'NIV'})
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                          Scheduled
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500">
                        <Calendar className="w-3.5 h-3.5 text-blue-500" />
                        <span>
                          {msg.scheduledAt ? new Date(msg.scheduledAt).toLocaleString() : 'Pending'}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs font-serif text-slate-700 dark:text-slate-300 line-clamp-2 italic">
                      "{msg.passageText}"
                    </p>

                    {msg.note && (
                      <div className="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 text-xs text-amber-900 dark:text-amber-200">
                        <span className="font-bold">Pastor's Note:</span> {msg.note}
                      </div>
                    )}

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                      <div className="flex items-center gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5" />
                          <span>{msg.recipientCount} Recipients ({msg.recipientType})</span>
                        </span>
                        <span>•</span>
                        <span>By {msg.senderName}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleSendFromList(msg)}
                          className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Send Now</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleEditDraft(msg)}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCancelMessage(msg)}
                          className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <span>Cancel</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 3. SENT MESSAGE HISTORY TAB */}
      {/* =================================================================== */}
      {activeTab === 'sent' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <span>Broadcast History & Delivery Reports</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Audited scripture messages sent to the congregation
              </p>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Search reference, note, or sender..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {messages.filter((m) => m.status === 'sent').length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <Send className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
                <p className="text-sm font-bold text-slate-500">No sent Scripture messages found</p>
              </div>
            ) : (
              messages
                .filter((m) => m.status === 'sent')
                .map((msg) => (
                  <div key={msg.id} className="p-5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <span className="px-2.5 py-1 rounded-lg text-xs font-black bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          {msg.reference}
                        </span>
                        <span className="text-xs font-bold text-slate-500">
                          ({msg.translationAbbreviation || 'NIV'})
                        </span>
                        <span className="text-[11px] font-bold text-slate-400">
                          Delivered to {msg.recipientCount} members ({msg.recipientType})
                        </span>
                      </div>

                      <div className="text-xs font-bold text-slate-400">
                        {msg.sentAt ? new Date(msg.sentAt).toLocaleString() : 'Delivered'}
                      </div>
                    </div>

                    <p className="text-xs font-serif text-slate-700 dark:text-slate-300 line-clamp-2 italic">
                      "{msg.passageText}"
                    </p>

                    {msg.note && (
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200">
                        <span className="font-bold text-amber-600 dark:text-amber-400">Pastor Note:</span> {msg.note}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs text-slate-400">
                        Sent by <strong className="text-slate-700 dark:text-slate-200">{msg.senderName}</strong> ({msg.senderRole})
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleDuplicateMessage(msg)}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>Reuse as Draft</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setViewingMessage(msg)}
                          className="px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-600 dark:text-blue-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>View Details</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 4. DRAFTS TAB */}
      {/* =================================================================== */}
      {activeTab === 'drafts' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-500" />
                <span>Scripture Message Drafts</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Work-in-progress sermon scripture messages (not visible to members)
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setEditingMessageId(null);
                setActiveTab('composer');
              }}
              className="px-3 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>New Draft</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {messages.filter((m) => m.status === 'draft').length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <FileText className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
                <p className="text-sm font-bold text-slate-500">No saved drafts</p>
              </div>
            ) : (
              messages
                .filter((m) => m.status === 'draft')
                .map((msg) => (
                  <div key={msg.id} className="p-5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-blue-600 dark:text-blue-400">
                          {msg.reference}
                        </span>
                        <span className="text-xs text-slate-400">({msg.translationAbbreviation || 'NIV'})</span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        Updated {new Date(msg.updatedAt).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="text-xs font-serif text-slate-700 dark:text-slate-300 line-clamp-1 italic">
                      "{msg.passageText}"
                    </p>

                    {msg.note && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1">
                        Note: {msg.note}
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-2">
                      <span className="text-xs text-slate-500">
                        Target: {msg.recipientType} ({msg.recipientCount} members)
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleEditDraft(msg)}
                          className="px-3 py-1 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Open Composer</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDuplicateMessage(msg)}
                          className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          title="Duplicate"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteMessage(msg)}
                          className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* CONFIRMATION DIALOG BEFORE SEND/SCHEDULE */}
      {/* =================================================================== */}
      {confirmationDialog && confirmationDialog.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                <Send className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-black text-slate-900 dark:text-white">
                  Confirm Immediate Broadcast
                </h4>
                <p className="text-xs text-slate-500">Review outreach details before delivery</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-slate-500">Scripture Reference:</span>
                <span className="font-black text-blue-600 dark:text-blue-400">
                  {reference} ({currentTrans.abbr})
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="font-bold text-slate-500">Audience Scope:</span>
                <span className="font-black text-purple-600 dark:text-purple-400 capitalize">
                  {recipientType}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="font-bold text-slate-500">Total Confirmed Recipients:</span>
                <span className="font-black text-emerald-600 dark:text-emerald-400">
                  {confirmationDialog.recipientCount} Church Members
                </span>
              </div>
            </div>

            {pastorNote && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/20 text-xs text-amber-900 dark:text-amber-200 border border-amber-200/50">
                <p className="font-bold mb-1">Attached Note:</p>
                <p className="line-clamp-2 italic">{pastorNote}</p>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmationDialog(null)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Go Back
              </button>
              <button
                type="button"
                onClick={handleExecuteSendNow}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black flex items-center gap-2 cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>Confirm & Send Now</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* SCHEDULE MODAL */}
      {/* =================================================================== */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-black text-slate-900 dark:text-white">
                  Schedule Scripture Delivery
                </h4>
                <p className="text-xs text-slate-500">Pick date, time, and timezone</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  Delivery Date
                </label>
                <input
                  type="date"
                  value={scheduleDate}
                  onChange={(e) => setScheduleDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  Delivery Time
                </label>
                <input
                  type="time"
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  Timezone
                </label>
                <select
                  value={scheduleTimezone}
                  onChange={(e) => setScheduleTimezone(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                >
                  <option value="Africa/Addis_Ababa">East Africa Time (EAT - Addis Ababa / UTC+3)</option>
                  <option value="UTC">Coordinated Universal Time (UTC)</option>
                  <option value="America/New_York">Eastern Time (US & Canada - UTC-5)</option>
                  <option value="Europe/London">London (GMT / UTC+0)</option>
                </select>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/60 text-xs text-indigo-900 dark:text-indigo-200">
              <span className="font-bold">Estimated Delivery:</span> {scheduleDate} at {scheduleTime} ({scheduleTimezone}) to <strong>{recipientCount} members</strong>.
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsScheduleModalOpen(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteSchedule}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center gap-2 cursor-pointer shadow-md"
              >
                <Calendar className="w-4 h-4" />
                <span>Queue Scheduled Message</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* MESSAGE DETAILS MODAL */}
      {/* =================================================================== */}
      {viewingMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black px-2.5 py-1 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                {viewingMessage.reference} ({viewingMessage.translationAbbreviation || 'NIV'})
              </span>
              <button
                type="button"
                onClick={() => setViewingMessage(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Holy Scripture Text
              </span>
              <p className="text-xs font-serif text-slate-800 dark:text-slate-100 leading-relaxed italic">
                "{viewingMessage.passageText}"
              </p>
            </div>

            {viewingMessage.note && (
              <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 space-y-1 text-xs text-amber-950 dark:text-amber-200">
                <span className="font-black text-amber-700 dark:text-amber-400">Pastor's Reflection:</span>
                <p className="whitespace-pre-line leading-relaxed">{viewingMessage.note}</p>
              </div>
            )}

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs text-slate-500 space-y-1">
              <div><strong>Sender:</strong> {viewingMessage.senderName} ({viewingMessage.senderRole})</div>
              <div><strong>Audience:</strong> {viewingMessage.recipientType} ({viewingMessage.recipientCount} members)</div>
              <div><strong>Sent At:</strong> {viewingMessage.sentAt ? new Date(viewingMessage.sentAt).toLocaleString() : 'N/A'}</div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setViewingMessage(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
