import React, { useState, useEffect } from 'react';
import { useBible } from '../../context/BibleContext';
import { BookOpen, ExternalLink, Sparkles, Copy, Check, Volume2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BibleVerseItem } from '../../data/bibleData';
import { BIBLE_CANON } from '../../data/bibleCanon';
import { bibleService } from '../../services/bibleService';

export interface BiblePassageProps {
  reference: string;
  versionId?: number;
  onVersionChange?: (versionId: number) => void;
  background?: 'light' | 'dark';
  showVersionPicker?: boolean;
  maxWidth?: number | '100%';
  className?: string;
  showHeading?: boolean;
  title?: string;
  subtitle?: string;
  onReadFullChapter?: () => void;
}

/**
 * Normalizes common human scripture references (e.g. "John 3:16", "Genesis 1:1-5")
 * to standard USFM format (e.g. "JHN.3.16", "GEN.1.1-5").
 */
export function normalizeToUsfm(ref: string): string {
  if (!ref || typeof ref !== 'string') return 'JHN.3.16';
  const trimmed = ref.trim();

  if (/^[A-Z0-9]{3}\.[0-9]+/i.test(trimmed)) {
    return trimmed.toUpperCase();
  }

  const BOOK_NAME_TO_USFM: Record<string, string> = {
    'genesis': 'GEN', 'gen': 'GEN',
    'exodus': 'EXO', 'exo': 'EXO',
    'leviticus': 'LEV', 'lev': 'LEV',
    'numbers': 'NUM', 'num': 'NUM',
    'deuteronomy': 'DEU', 'deut': 'DEU', 'deu': 'DEU',
    'joshua': 'JOS', 'josh': 'JOS',
    'judges': 'JDG', 'judg': 'JDG',
    'ruth': 'RUT', 'rut': 'RUT',
    '1 samuel': '1SA', '1 sam': '1SA', '1samuel': '1SA', '1sa': '1SA',
    '2 samuel': '2SA', '2 sam': '2SA', '2samuel': '2SA', '2sa': '2SA',
    '1 kings': '1KI', '1 kgs': '1KI', '1kings': '1KI', '1ki': '1KI',
    '2 kings': '2KI', '2 kgs': '2KI', '2kings': '2KI', '2ki': '2KI',
    '1 chronicles': '1CH', '1 chr': '1CH', '1ch': '1CH',
    '2 chronicles': '2CH', '2 chr': '2CH', '2ch': '2CH',
    'ezra': 'EZR', 'ezr': 'EZR',
    'nehemiah': 'NEH', 'neh': 'NEH',
    'esther': 'EST', 'est': 'EST',
    'job': 'JOB',
    'psalms': 'PSA', 'psalm': 'PSA', 'psa': 'PSA', 'ps': 'PSA',
    'proverbs': 'PRO', 'prov': 'PRO', 'pro': 'PRO',
    'ecclesiastes': 'ECC', 'eccl': 'ECC',
    'song of solomon': 'SNG', 'song of songs': 'SNG', 'song': 'SNG',
    'isaiah': 'ISA', 'isa': 'ISA',
    'jeremiah': 'JER', 'jer': 'JER',
    'lamentations': 'LAM', 'lam': 'LAM',
    'ezekiel': 'EZK', 'ezek': 'EZK',
    'daniel': 'DAN', 'dan': 'DAN',
    'hosea': 'HOS', 'hos': 'HOS',
    'joel': 'JOL', 'jol': 'JOL',
    'amos': 'AMO', 'amo': 'AMO',
    'obadiah': 'OBA', 'oba': 'OBA',
    'jonah': 'JON', 'jon': 'JON',
    'micah': 'MIC', 'mic': 'MIC',
    'nahum': 'NAM', 'nam': 'NAM',
    'habakkuk': 'HAB', 'hab': 'HAB',
    'zephaniah': 'ZEP', 'zep': 'ZEP',
    'haggai': 'HAG', 'hag': 'HAG',
    'zechariah': 'ZEC', 'zec': 'ZEC',
    'malachi': 'MAL', 'mal': 'MAL',
    'matthew': 'MAT', 'matt': 'MAT', 'mat': 'MAT',
    'mark': 'MRK', 'mrk': 'MRK',
    'luke': 'LUK', 'luk': 'LUK',
    'john': 'JHN', 'jhn': 'JHN',
    'acts': 'ACT', 'act': 'ACT',
    'romans': 'ROM', 'rom': 'ROM',
    '1 corinthians': '1CO', '1 cor': '1CO', '1co': '1CO',
    '2 corinthians': '2CO', '2 cor': '2CO', '2co': '2CO',
    'galatians': 'GAL', 'gal': 'GAL',
    'ephesians': 'EPH', 'eph': 'EPH',
    'philippians': 'PHP', 'phil': 'PHP', 'php': 'PHP',
    'colossians': 'COL', 'col': 'COL',
    '1 thessalonians': '1TH', '1 thess': '1TH', '1th': '1TH',
    '2 thessalonians': '2TH', '2 thess': '2TH', '2th': '2TH',
    '1 timothy': '1TI', '1 tim': '1TI', '1ti': '1TI',
    '2 timothy': '2TI', '2 tim': '2TI', '2ti': '2TI',
    'titus': 'TIT', 'tit': 'TIT',
    'philemon': 'PHM', 'phm': 'PHM',
    'hebrews': 'HEB', 'heb': 'HEB',
    'james': 'JAS', 'jas': 'JAS',
    '1 peter': '1PE', '1 pet': '1PE', '1pe': '1PE',
    '2 peter': '2PE', '2 pet': '2PE', '2pe': '2PE',
    '1 john': '1JN', '1 jhn': '1JN', '1jn': '1JN',
    '2 john': '2JN', '2 jhn': '2JN', '2jn': '2JN',
    '3 john': '3JN', '3 jhn': '3JN', '3jn': '3JN',
    'jude': 'JUD', 'jud': 'JUD',
    'revelation': 'REV', 'rev': 'REV',
  };

  const match = trimmed.match(/^([1-3]?\s*[A-Za-z]+)\s+([0-9]+)(?:[:.]([0-9]+(?:-[0-9]+)?))?/i);
  if (match) {
    const bookName = match[1].trim().toLowerCase();
    const chapter = match[2];
    const verses = match[3];
    const usfmBook = BOOK_NAME_TO_USFM[bookName] || 'JHN';
    return verses ? `${usfmBook}.${chapter}.${verses}` : `${usfmBook}.${chapter}`;
  }

  return trimmed;
}

export const BiblePassage: React.FC<BiblePassageProps> = ({
  reference,
  versionId: propVersionId,
  onVersionChange,
  background = 'light',
  showVersionPicker = true,
  maxWidth = '100%',
  className = '',
  showHeading = false,
  title,
  subtitle,
  onReadFullChapter,
}) => {
  const {
    selectedVersionId,
    setSelectedVersionId,
    selectedSlotKey,
    setSelectedSlotKey,
    userVisibleBibles,
    otherAvailableBibles,
    configuredSlots,
    jumpToReference,
  } = useBible();
  const navigate = useNavigate();
  const [copied, setCopied] = useState<boolean>(false);

  const activeVersionId = propVersionId || selectedVersionId;
  const usfmRef = normalizeToUsfm(reference);

  // Parse USFM components e.g. "JHN.3.16" or "PSA.23.1-6"
  const parts = usfmRef.split('.');
  const bookCode = (parts[0] || 'JHN').toUpperCase();
  const chapterNum = parseInt(parts[1] || '1', 10);
  const verseRange = parts[2] || '';

  let startVerse = 1;
  let endVerse = 999;
  if (verseRange.includes('-')) {
    const [s, e] = verseRange.split('-');
    startVerse = parseInt(s, 10) || 1;
    endVerse = parseInt(e, 10) || 999;
  } else if (verseRange) {
    startVerse = parseInt(verseRange, 10) || 1;
    endVerse = startVerse;
  }

  // Find book info
  const bookInfo = BIBLE_CANON.find((b) => b.id.toUpperCase() === bookCode) || {
    id: bookCode,
    nameEnglish: bookCode,
    nameAmharic: bookCode,
  };

  const [allVerses, setAllVerses] = useState<BibleVerseItem[]>([]);
  const [isLoadingPassage, setIsLoadingPassage] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;
    setIsLoadingPassage(true);
    bibleService.getPassage(bookCode, chapterNum, String(activeVersionId))
      .then((data) => {
        if (isMounted) {
          setAllVerses(data?.verses || []);
          setIsLoadingPassage(false);
        }
      })
      .catch(() => {
        if (isMounted) {
          setAllVerses([]);
          setIsLoadingPassage(false);
        }
      });
    return () => { isMounted = false; };
  }, [bookCode, chapterNum, activeVersionId]);

  const filteredVerses = allVerses.filter(
    (v) => (v.verseNumber || v.verse || 1) >= startVerse && (v.verseNumber || v.verse || 1) <= endVerse
  );

  const handleVersionChange = (newVersionId: number) => {
    if (onVersionChange) {
      onVersionChange(newVersionId);
    } else {
      setSelectedVersionId(newVersionId);
    }
  };

  const handleOpenReader = () => {
    if (onReadFullChapter) {
      onReadFullChapter();
    } else {
      jumpToReference(usfmRef);
      navigate('/bible');
    }
  };

  const handleCopyPassage = async () => {
    const combined = filteredVerses
      .map((v) => `[${v.verseNumber || v.verse}] ${v.textAmharic || ''}\n${v.textEnglish || ''}`)
      .join('\n\n');
    const fullText = `${bookInfo.nameEnglish} ${chapterNum}:${verseRange || '1'}\n\n${combined}`;
    try {
      await navigator.clipboard.writeText(fullText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const isDark = background === 'dark';

  return (
    <div
      style={{ maxWidth }}
      className={`rounded-2xl border transition-all ${
        isDark
          ? 'bg-slate-900 border-slate-800 text-white'
          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white'
      } shadow-xs overflow-hidden ${className}`}
    >
      {showHeading && (
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <div>
              <h4 className="text-sm font-black">
                {title || `${bookInfo.nameEnglish} ${chapterNum}${verseRange ? `:${verseRange}` : ''}`}
              </h4>
              {subtitle ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  {bookInfo.nameAmharic} ምዕራፍ {chapterNum}
                </p>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={handleOpenReader}
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>Open in Bible Reader</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Passage Content Container */}
      <div className="p-4 sm:p-6 space-y-4">
        {/* Subheader bar with version picker & actions */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-black text-blue-600 dark:text-blue-400">
              {bookInfo.nameEnglish} {chapterNum}:{verseRange || '1-end'}
            </span>
            <span className="text-slate-400">•</span>
            <span className="font-medium text-slate-500">{bookInfo.nameAmharic}</span>
          </div>

          <div className="flex items-center gap-2">
            {showVersionPicker && (
              <select
                value={`${selectedSlotKey || 'NIV'}:${activeVersionId}`}
                onChange={(e) => {
                  const [slotPart, idPart] = e.target.value.split(':');
                  const numId = Number(idPart);
                  if (!isNaN(numId) && numId > 0) {
                    setSelectedSlotKey(slotPart || 'NIV');
                    handleVersionChange(numId);
                  }
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200"
              >
                <optgroup label="Primary Translations">
                  {userVisibleBibles.map((b) => {
                    const sKey = b.slotKey || `CUSTOM_${b.id}`;
                    const label =
                      b.userDisplayLabel ||
                      `${b.localized_abbreviation || b.abbreviation} — ${b.localized_title || b.title}`;
                    return (
                      <option key={`${sKey}:${b.id}`} value={`${sKey}:${b.id}`}>
                        {label}
                      </option>
                    );
                  })}
                </optgroup>
                {otherAvailableBibles.length > 0 && (
                  <optgroup label={`More Options — Oromiffa (${otherAvailableBibles.length})`}>
                    {otherAvailableBibles.map((b) => {
                      const sKey = b.slotKey || `MORE_${b.id}`;
                      const label =
                        b.userDisplayLabel ||
                        `${b.localized_abbreviation || b.abbreviation} — ${b.localized_title || b.title}`;
                      return (
                        <option key={`${sKey}:${b.id}`} value={`${sKey}:${b.id}`}>
                          {label}
                        </option>
                      );
                    })}
                  </optgroup>
                )}
              </select>
            )}

            <button
              type="button"
              onClick={handleCopyPassage}
              className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors"
              title="Copy Scripture"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Verses list (Aligned Verse-by-Verse Side-by-Side) */}
        <div className="rounded-xl border border-slate-200/70 dark:border-slate-800 overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 bg-slate-100/80 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-xs font-black">
            <div className="px-3.5 py-2 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 uppercase tracking-wider">
              English
            </div>
            <div className="px-3.5 py-2 font-menbere text-slate-700 dark:text-slate-200">
              አማርኛ
            </div>
          </div>
          <div className="divide-y divide-slate-200/60 dark:divide-slate-800/70 font-serif leading-relaxed">
            {filteredVerses.map((v) => {
              const vNum = v.verseNumber || v.verse || 1;
              const vKey = v.verseKey || `${bookCode}.${chapterNum}.${vNum}`;
              const engText = (v.english || v.textEnglish || '').trim();
              const amhText = (v.amharic || v.textAmharic || '').trim();
              return (
                <div key={vKey} className="grid grid-cols-1 md:grid-cols-2 items-stretch">
                  <div className="p-3 sm:p-3.5 md:border-r border-slate-200/70 dark:border-slate-800 flex items-start gap-2.5">
                    <span className="text-xs font-sans font-black text-blue-600 dark:text-blue-400 mt-0.5 select-none shrink-0">
                      {vNum}
                    </span>
                    <p className="text-slate-800 dark:text-slate-100 text-xs sm:text-sm font-sans leading-relaxed">
                      {engText || '—'}
                    </p>
                  </div>
                  <div className="p-3 sm:p-3.5 border-t md:border-t-0 border-slate-100 dark:border-slate-800/60 flex items-start gap-2.5">
                    <span className="text-xs font-sans font-black text-emerald-600 dark:text-emerald-400 mt-0.5 select-none shrink-0">
                      {vNum}
                    </span>
                    <p
                      lang="am"
                      className="font-menbere text-slate-800 dark:text-slate-100 text-sm sm:text-base leading-loose"
                    >
                      {amhText || '—'}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BiblePassage;
