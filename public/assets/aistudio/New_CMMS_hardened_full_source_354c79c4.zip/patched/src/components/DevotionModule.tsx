import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCMMS } from '../context/CMMSContext';
import { useBible } from '../context/BibleContext';
import { devotionService } from '../services/devotionService';
import { Devotion, DevotionComment, DevotionReactionType, DevotionStatus } from '../types';
import { normalizeUserRole } from '../utils/rbac';
import { ActionMenu } from './ui/ActionMenu';
import {
  Sparkles,
  BookOpen,
  Calendar,
  Heart,
  Volume2,
  VolumeX,
  Share2,
  Copy,
  Plus,
  Trash2,
  Edit3,
  Search,
  CheckCircle2,
  Clock,
  User,
  ExternalLink,
  ShieldCheck,
  Send,
  MessageSquare,
  Lock,
  Layers,
  Check,
  X,
  RefreshCw,
  Eye,
  Archive,
  BookMarked,
  Filter,
} from 'lucide-react';

interface JournalEntry {
  id: string;
  date: string;
  title: string;
  scripture: string;
  reflection: string;
  prayer: string;
}

const DEVOTION_TOPICS = [
  'All',
  'Faith & Strength',
  'Prayer & Communion',
  'Spiritual Growth',
  'Peace & Protection',
  'Grace & Thanksgiving',
  'Worship & Praise',
  'Leadership & Service',
  'Family & Marriage',
];

export const DevotionModule: React.FC = () => {
  const { language, t, currentUser, activeRole } = useCMMS();
  const { jumpToReference } = useBible();
  const navigate = useNavigate();

  const normRole = normalizeUserRole(currentUser?.role || activeRole || 'REGULAR_MEMBER');
  const isPastorOrAdmin = ['SYSTEM_ADMIN', 'SUPERADMIN', 'PASTOR'].includes(normRole);

  const userContext = useMemo(() => ({
    userId: currentUser?.memberId || currentUser?.email || 'u-default-member',
    userName: currentUser?.name || 'Church Member',
    userRole: normRole,
  }), [currentUser, normRole]);

  // Tab Navigation (Bible reading is completely separate in /bible)
  const [activeTab, setActiveTab] = useState<'today' | 'archive' | 'journal' | 'manage'>('today');

  // Devotions Data
  const [devotionsList, setDevotionsList] = useState<Devotion[]>([]);
  const [activeDevotion, setActiveDevotion] = useState<Devotion | null>(null);
  const [isLoadingDevotions, setIsLoadingDevotions] = useState(true);
  const [devotionLoadError, setDevotionLoadError] = useState<string | null>(null);

  // Audio Speech Narration
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Filters & Search
  const [selectedTopic, setSelectedTopic] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft' | 'scheduled' | 'archived'>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Comments for Active Devotion
  const [comments, setComments] = useState<DevotionComment[]>([]);
  const [commentInput, setCommentInput] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);

  // Create / Edit Devotion Modal (Pastor & SYSTEM_ADMIN Only)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingDevotionId, setEditingDevotionId] = useState<string | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formAmharicTitle, setFormAmharicTitle] = useState('');
  const [formBibleReference, setFormBibleReference] = useState('');
  const [formTopic, setFormTopic] = useState('Faith & Strength');
  const [formContent, setFormContent] = useState('');
  const [formPrayer, setFormPrayer] = useState('');
  const [formPublicationDate, setFormPublicationDate] = useState(new Date().toISOString().split('T')[0]);
  const [formVisibility, setFormVisibility] = useState<'ALL_MEMBERS' | 'BRANCH_ONLY'>('ALL_MEMBERS');
  const [isSavingDevotion, setIsSavingDevotion] = useState(false);

  // Personal Devotional Journal (Scoped to User)
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    try {
      const saved = localStorage.getItem(`cmms_devotional_journal_${userContext.userId}`);
      return saved ? JSON.parse(saved) : [
        {
          id: 'j-1',
          date: new Date().toISOString().split('T')[0],
          title: 'Walking in the Peace of Christ',
          scripture: 'Philippians 4:6-7',
          reflection: 'Today God reminded me to turn every anxious thought into petition with thanksgiving. His peace guards my heart.',
          prayer: 'Lord, grant me a steadfast mind today anchored in Your unfailing love.',
        },
      ];
    } catch {
      return [];
    }
  });

  const [isJournalModalOpen, setIsJournalModalOpen] = useState(false);
  const [journalTitle, setJournalTitle] = useState('');
  const [journalScripture, setJournalScripture] = useState('');
  const [journalReflection, setJournalReflection] = useState('');
  const [journalPrayer, setJournalPrayer] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Load Devotions from Server
  const loadDevotions = async () => {
    setIsLoadingDevotions(true);
    setDevotionLoadError(null);
    try {
      const list = await devotionService.getDevotions(userContext, {
        topic: selectedTopic !== 'All' ? selectedTopic : undefined,
        status: isPastorOrAdmin && statusFilter !== 'all' ? statusFilter : undefined,
        search: searchQuery || undefined,
      });

      // Regular members & ministry leaders only see published posts
      const filtered = isPastorOrAdmin ? list : list.filter((d) => d.status === 'published');
      setDevotionsList(filtered);

      if (filtered.length > 0) {
        if (!activeDevotion || !filtered.some((d) => d.id === activeDevotion.id)) {
          setActiveDevotion(filtered[0]);
        }
      } else {
        setActiveDevotion(null);
      }
    } catch (err: any) {
      console.warn('[DevotionModule] Error loading devotions:', err);
      setDevotionLoadError('Bible devotion content is temporarily unavailable — try again shortly');
    } finally {
      setIsLoadingDevotions(false);
    }
  };

  useEffect(() => {
    loadDevotions();
  }, [selectedTopic, statusFilter, userContext.userId, userContext.userRole]);

  // Load Comments for Active Devotion
  useEffect(() => {
    if (activeDevotion?.id) {
      devotionService.getComments(activeDevotion.id).then((comms) => {
        setComments(comms || []);
      }).catch(() => setComments([]));
    } else {
      setComments([]);
    }
  }, [activeDevotion?.id]);

  // Save Journal Entries to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(`cmms_devotional_journal_${userContext.userId}`, JSON.stringify(journalEntries));
    } catch {}
  }, [journalEntries, userContext.userId]);

  // Jump to Holy Bible reader for a scripture reference
  const handleReadInHolyBible = (reference?: string) => {
    const targetRef = reference || activeDevotion?.scriptureReference || 'JHN.3.16';
    jumpToReference(targetRef);
    navigate('/bible');
  };

  // Handle Reactions (Heart, Amen, Praying, Inspiring)
  const handleToggleReaction = async (reactionType: DevotionReactionType) => {
    if (!activeDevotion) return;
    const devotionId = activeDevotion.id;
    const isCurrentlyActive = (activeDevotion.userReactions || []).includes(reactionType);

    const updatedUserReactions = isCurrentlyActive
      ? (activeDevotion.userReactions || []).filter((r) => r !== reactionType)
      : [...(activeDevotion.userReactions || []), reactionType];

    const currentCount = activeDevotion.reactionsCount?.[reactionType] || 0;
    const newCount = isCurrentlyActive ? Math.max(0, currentCount - 1) : currentCount + 1;

    const updatedDevotion: Devotion = {
      ...activeDevotion,
      userReactions: updatedUserReactions,
      reactionsCount: {
        ...(activeDevotion.reactionsCount || { heart: 0, amen: 0, praying: 0, inspiring: 0 }),
        [reactionType]: newCount,
      },
    };

    setActiveDevotion(updatedDevotion);
    setDevotionsList((prev) => prev.map((d) => (d.id === devotionId ? updatedDevotion : d)));

    try {
      const res = await devotionService.toggleReaction(userContext, devotionId, reactionType);
      if (res && res.reactionsCount) {
        setActiveDevotion((prev) => (prev?.id === devotionId ? { ...prev, reactionsCount: res.reactionsCount, userReactions: res.userReactions } : prev));
      }
    } catch {}
  };

  // Handle Comment Submission
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDevotion || !commentInput.trim() || isSubmittingComment) return;
    setIsSubmittingComment(true);
    try {
      const newComm = await devotionService.addComment(userContext, activeDevotion.id, commentInput.trim());
      if (newComm) {
        setComments((prev) => [newComm, ...prev]);
        setCommentInput('');
        showToast('Comment posted successfully');
      }
    } catch {
      showToast('Failed to post comment');
    } finally {
      setIsSubmittingComment(false);
    }
  };

  // Handle Delete Comment
  const handleDeleteComment = async (commentId: string) => {
    if (!activeDevotion) return;
    const ok = await devotionService.deleteComment(userContext, activeDevotion.id, commentId);
    if (ok) {
      setComments((prev) => prev.filter((c) => c.id !== commentId));
      showToast('Comment deleted');
    }
  };

  // Open Create Devotion Modal
  const handleOpenCreateModal = (devotionToEdit?: Devotion) => {
    if (devotionToEdit) {
      setEditingDevotionId(devotionToEdit.id);
      setFormTitle(devotionToEdit.title);
      setFormAmharicTitle(devotionToEdit.amharicTitle || '');
      setFormBibleReference(devotionToEdit.scriptureReference);
      setFormTopic(devotionToEdit.topic || 'Faith & Strength');
      setFormContent(devotionToEdit.body);
      setFormPrayer(devotionToEdit.prayer || '');
      setFormPublicationDate(devotionToEdit.publishedAt ? devotionToEdit.publishedAt.split('T')[0] : new Date().toISOString().split('T')[0]);
    } else {
      setEditingDevotionId(null);
      setFormTitle('');
      setFormAmharicTitle('');
      setFormBibleReference('Hebrews 11:1');
      setFormTopic('Faith & Strength');
      setFormContent('');
      setFormPrayer('');
      setFormPublicationDate(new Date().toISOString().split('T')[0]);
    }
    setFormVisibility('ALL_MEMBERS');
    setIsCreateModalOpen(true);
  };

  // Save or Publish Devotion (Pastor & SYSTEM_ADMIN Only)
  const handleSaveDevotion = async (targetStatus: DevotionStatus) => {
    if (!formTitle.trim() || !formBibleReference.trim() || !formContent.trim() || isSavingDevotion) return;
    setIsSavingDevotion(true);
    try {
      const payload = {
        title: formTitle.trim(),
        amharicTitle: formAmharicTitle.trim() || undefined,
        topic: formTopic,
        scriptureReference: formBibleReference.trim(),
        body: formContent.trim(),
        prayer: formPrayer.trim() || undefined,
        status: targetStatus,
        publishedAt: targetStatus === 'published' ? new Date(formPublicationDate).toISOString() : undefined,
      };

      if (editingDevotionId) {
        const updated = await devotionService.updateDevotion(userContext, editingDevotionId, payload);
        if (updated) {
          setDevotionsList((prev) => prev.map((d) => (d.id === editingDevotionId ? updated : d)));
          if (activeDevotion?.id === editingDevotionId) setActiveDevotion(updated);
          showToast(`Devotion ${targetStatus === 'published' ? 'published' : 'saved as draft'}`);
        }
      } else {
        const created = await devotionService.createDevotion(userContext, payload);
        if (created) {
          setDevotionsList((prev) => [created, ...prev]);
          setActiveDevotion(created);
          showToast(`Daily Devotion ${targetStatus === 'published' ? 'published successfully' : 'saved as draft'}`);
        }
      }
      setIsCreateModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Failed to save devotion');
    } finally {
      setIsSavingDevotion(false);
    }
  };

  // Handle Delete Devotion (Pastor & SYSTEM_ADMIN Only)
  const handleDeleteDevotion = async (id: string) => {
    if (!confirm('Are you sure you want to delete this Daily Devotion?')) return;
    try {
      const ok = await devotionService.deleteDevotion(userContext, id);
      if (ok) {
        setDevotionsList((prev) => prev.filter((d) => d.id !== id));
        if (activeDevotion?.id === id) {
          const remaining = devotionsList.filter((d) => d.id !== id);
          setActiveDevotion(remaining.length > 0 ? remaining[0] : null);
        }
        showToast('Devotion deleted successfully');
      }
    } catch {
      showToast('Failed to delete devotion');
    }
  };

  // Handle Status Toggle (Publish / Unpublish)
  const handleToggleStatus = async (devotion: Devotion, newStatus: DevotionStatus) => {
    try {
      const updated = await devotionService.updateStatus(userContext, devotion.id, newStatus);
      if (updated) {
        setDevotionsList((prev) => prev.map((d) => (d.id === devotion.id ? { ...d, status: newStatus } : d)));
        if (activeDevotion?.id === devotion.id) setActiveDevotion({ ...activeDevotion, status: newStatus });
        showToast(`Devotion marked as ${newStatus}`);
      }
    } catch {
      showToast('Failed to update status');
    }
  };

  // Audio Speech Narration
  const handleToggleAudio = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      showToast('Speech narration not supported in this browser');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    } else {
      if (!activeDevotion) return;
      window.speechSynthesis.cancel();
      const textToRead = `${activeDevotion.title}. Scripture reference: ${activeDevotion.scriptureReference}. ${activeDevotion.body}. ${activeDevotion.prayer ? 'Closing Prayer: ' + activeDevotion.prayer : ''}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.95;
      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);
      window.speechSynthesis.speak(utterance);
      setIsPlayingAudio(true);
    }
  };

  // Journal Entry Creation
  const handleSaveJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!journalTitle.trim() || !journalReflection.trim()) return;
    const newEntry: JournalEntry = {
      id: `j-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      title: journalTitle.trim(),
      scripture: journalScripture.trim() || activeDevotion?.scriptureReference || 'Scripture Reflection',
      reflection: journalReflection.trim(),
      prayer: journalPrayer.trim(),
    };
    setJournalEntries([newEntry, ...journalEntries]);
    setJournalTitle('');
    setJournalScripture('');
    setJournalReflection('');
    setJournalPrayer('');
    setIsJournalModalOpen(false);
    showToast('Personal journal entry saved');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-2xl shadow-2xl text-xs font-bold flex items-center gap-2 animate-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =================================================================== */}
      {/* 1. TOP HEADER HERO BANNER                                           */}
      {/* =================================================================== */}
      <div className="p-6 bg-gradient-to-r from-indigo-950 via-slate-900 to-blue-950 rounded-3xl text-white shadow-xl border border-indigo-900/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Church-Published Daily Devotional</span>
            <span className="text-slate-400">·</span>
            <span className="text-emerald-300">Pastoral Ministry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Daily Devotion & Word (የዕለቱ ቃልና ጸሎት)
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Spiritual nourishment published by our pastors for personal meditation, prayer, and congregation communion.
          </p>
        </div>

        {/* Action Button for Pastor & SYSTEM_ADMIN */}
        <div className="flex items-center gap-2 shrink-0">
          {isPastorOrAdmin && (
            <button
              type="button"
              onClick={() => handleOpenCreateModal()}
              className="px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Daily Devotion</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleReadInHolyBible()}
            className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-2 border border-white/20 transition-all cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-blue-300" />
            <span>Open Holy Bible</span>
          </button>
        </div>
      </div>

      {/* =================================================================== */}
      {/* 2. TAB NAVIGATION BAR                                               */}
      {/* =================================================================== */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800 text-xs font-bold">
        <button
          type="button"
          onClick={() => setActiveTab('today')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'today'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Today's Devotion</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('archive')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'archive'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Archive className="w-4 h-4" />
          <span>Devotions Library</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('journal')}
          className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'journal'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
          }`}
        >
          <BookMarked className="w-4 h-4" />
          <span>My Personal Journal ({journalEntries.length})</span>
        </button>

        {isPastorOrAdmin && (
          <button
            type="button"
            onClick={() => setActiveTab('manage')}
            className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'manage'
                ? 'bg-amber-600 text-white shadow-md'
                : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 hover:bg-amber-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Manage Devotions ({devotionsList.length})</span>
          </button>
        )}
      </div>

      {/* Outage / Degraded Error Notice */}
      {devotionLoadError && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-bold">{devotionLoadError}</span>
          </div>
          <button
            type="button"
            onClick={loadDevotions}
            className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold inline-flex items-center gap-1 cursor-pointer shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry</span>
          </button>
        </div>
      )}

      {/* =================================================================== */}
      {/* 3. TAB: TODAY'S DEVOTION (MEMBER & LEADER VIEW)                     */}
      {/* =================================================================== */}
      {activeTab === 'today' && (
        <div className="space-y-6">
          {isLoadingDevotions ? (
            <div className="p-12 text-center text-xs text-slate-500 space-y-3">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-blue-600" />
              <p>Loading church daily devotion...</p>
            </div>
          ) : !activeDevotion ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Sparkles className="w-8 h-8 text-amber-400 mx-auto" />
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                No devotional posted yet for today
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Check back shortly or browse previous devotions in the Library tab.
              </p>
              {isPastorOrAdmin && (
                <button
                  type="button"
                  onClick={() => handleOpenCreateModal()}
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold inline-flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Publish Today's Devotion</span>
                </button>
              )}
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 sm:p-8 space-y-6">
              {/* Devotion Metadata Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap text-xs">
                    <span className="px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-extrabold">
                      {activeDevotion.topic || 'Daily Devotion'}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-500 font-medium">
                      Published {activeDevotion.publishedAt ? new Date(activeDevotion.publishedAt).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : 'Today'}
                    </span>
                    {activeDevotion.authorName && (
                      <>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-700 dark:text-slate-300 font-bold flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-blue-600" />
                          <span>{activeDevotion.authorName}</span>
                        </span>
                      </>
                    )}
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                    {activeDevotion.title}
                  </h2>
                  {activeDevotion.amharicTitle && (
                    <p className="text-lg font-bold text-amber-600 dark:text-amber-400">
                      {activeDevotion.amharicTitle}
                    </p>
                  )}
                </div>

                {/* Audio & Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleToggleAudio}
                    className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                      isPlayingAudio
                        ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                        : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    <span>{isPlayingAudio ? 'Stop Audio' : 'Listen'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const text = `${activeDevotion.title}\nScripture: ${activeDevotion.scriptureReference}\n\n${activeDevotion.body}\n\nPrayer: ${activeDevotion.prayer || ''}`;
                      navigator.clipboard?.writeText(text);
                      showToast('Devotion copied to clipboard');
                    }}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                    title="Copy Devotion"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* BIBLE REFERENCE & READ IN HOLY BIBLE CARD (Requirement 9) */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50/80 dark:from-blue-950/40 dark:to-indigo-950/20 border border-blue-200 dark:border-blue-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[11px] font-black uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    Scripture Anchor Text
                  </span>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white">
                    {activeDevotion.scriptureReference}
                  </h3>
                  {activeDevotion.keyVerse && (
                    <blockquote className="text-xs italic text-slate-600 dark:text-slate-300 font-serif">
                      "{activeDevotion.keyVerse}"
                    </blockquote>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => handleReadInHolyBible(activeDevotion.scriptureReference)}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer shrink-0"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Read in Holy Bible</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Devotional Body Content */}
              <div className="space-y-4 text-slate-800 dark:text-slate-200 text-sm sm:text-base leading-relaxed whitespace-pre-line font-serif">
                {activeDevotion.body}
              </div>

              {/* Closing Prayer Section */}
              {activeDevotion.prayer && (
                <div className="p-5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/40 space-y-2">
                  <span className="text-xs font-black uppercase text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5" />
                    <span>Closing Prayer (የዕለቱ ጸሎት)</span>
                  </span>
                  <p className="text-xs sm:text-sm text-amber-950 dark:text-amber-100 italic leading-relaxed font-serif">
                    «{activeDevotion.prayer}»
                  </p>
                </div>
              )}

              {/* Reactions Bar (Heart, Amen, Praying, Inspiring) */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-wrap">
                  {[
                    { type: 'amen' as const, label: 'Amen', icon: '🙏' },
                    { type: 'heart' as const, label: 'Blessed', icon: '❤️' },
                    { type: 'praying' as const, label: 'Praying', icon: '✨' },
                    { type: 'inspiring' as const, label: 'Inspiring', icon: '🕊️' },
                  ].map((r) => {
                    const count = activeDevotion.reactionsCount?.[r.type] || 0;
                    const isSelected = (activeDevotion.userReactions || []).includes(r.type);
                    return (
                      <button
                        key={r.type}
                        type="button"
                        onClick={() => handleToggleReaction(r.type)}
                        className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        <span>{r.icon}</span>
                        <span>{r.label}</span>
                        {count > 0 && <span className="opacity-80">({count})</span>}
                      </button>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setJournalTitle(activeDevotion.title);
                    setJournalScripture(activeDevotion.scriptureReference);
                    setJournalPrayer(activeDevotion.prayer || '');
                    setIsJournalModalOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <BookMarked className="w-4 h-4 text-blue-600" />
                  <span>Write Personal Reflection</span>
                </button>
              </div>

              {/* Congregation Comments Feed */}
              <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-blue-600" />
                    <span>Congregation Reflections ({comments.length})</span>
                  </h4>
                </div>

                <form onSubmit={handleAddComment} className="flex gap-2">
                  <input
                    type="text"
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    placeholder="Share an uplifting takeaway or amen..."
                    className="flex-1 px-4 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="submit"
                    disabled={isSubmittingComment || !commentInput.trim()}
                    className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold cursor-pointer flex items-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Post</span>
                  </button>
                </form>

                <div className="space-y-3">
                  {comments.map((comm) => (
                    <div
                      key={comm.id}
                      className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{comm.userName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {comm.createdAt ? new Date(comm.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recent'}
                          </span>
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{comm.commentText}</p>
                      </div>
                      {(isPastorOrAdmin || comm.userId === userContext.userId) && (
                        <button
                          type="button"
                          onClick={() => handleDeleteComment(comm.id)}
                          className="p-1 text-slate-400 hover:text-rose-500 cursor-pointer"
                          title="Delete comment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =================================================================== */}
      {/* 4. TAB: DEVOTIONS ARCHIVE & LIBRARY                                 */}
      {/* =================================================================== */}
      {activeTab === 'archive' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Archive className="w-5 h-5 text-blue-600" />
                <span>Devotions Library & History</span>
              </h2>
              <p className="text-xs text-slate-500">
                Browse through all past published pastoral devotions and scripture teachings
              </p>
            </div>

            {/* Topic Filter */}
            <div className="flex items-center gap-2">
              <select
                value={selectedTopic}
                onChange={(e) => setSelectedTopic(e.target.value)}
                className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
              >
                {DEVOTION_TOPICS.map((top) => (
                  <option key={top} value={top}>{top}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {devotionsList
              .filter((d) => isPastorOrAdmin || d.status === 'published')
              .map((dev) => (
                <div
                  key={dev.id}
                  className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold">
                        {dev.topic}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {dev.publishedAt ? new Date(dev.publishedAt).toLocaleDateString() : 'Published'}
                      </span>
                    </div>

                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      {dev.title}
                    </h3>

                    <div className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 font-bold">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>{dev.scriptureReference}</span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
                      {dev.body}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveDevotion(dev);
                        setActiveTab('today');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-100 text-xs font-bold cursor-pointer"
                    >
                      Read Full Devotion
                    </button>

                    <button
                      type="button"
                      onClick={() => handleReadInHolyBible(dev.scriptureReference)}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Read in Holy Bible</span>
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 5. TAB: MY PERSONAL DEVOTIONAL JOURNAL                              */}
      {/* =================================================================== */}
      {activeTab === 'journal' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <BookMarked className="w-5 h-5 text-blue-600" />
                <span>My Devotional Journal (የግል መንፈሳዊ ማስታወሻ)</span>
              </h2>
              <div className="flex items-center gap-1 text-xs text-emerald-600 font-semibold mt-0.5">
                <Lock className="w-3.5 h-3.5" />
                <span>Strictly private to your account</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setJournalTitle('');
                setJournalScripture('');
                setJournalReflection('');
                setJournalPrayer('');
                setIsJournalModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>New Journal Entry</span>
            </button>
          </div>

          <div className="space-y-4">
            {journalEntries.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                You haven't written any journal reflections yet. Click "New Journal Entry" above to record what God is speaking to your heart.
              </div>
            ) : (
              journalEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-black text-slate-900 dark:text-white">{entry.title}</h3>
                      <div className="flex items-center gap-2 text-xs text-blue-600 dark:text-blue-400 font-bold">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>{entry.scripture}</span>
                        <span className="text-slate-400 font-normal">· {entry.date}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setJournalEntries((prev) => prev.filter((j) => j.id !== entry.id))}
                      className="p-1.5 text-slate-400 hover:text-rose-500 cursor-pointer"
                      title="Delete Entry"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-200 whitespace-pre-line leading-relaxed font-serif">
                    {entry.reflection}
                  </p>
                  {entry.prayer && (
                    <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                      <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400 block">Prayer:</span>
                      <p className="text-xs text-slate-600 dark:text-slate-300 italic">{entry.prayer}</p>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 6. TAB: DEVOTIONS MANAGEMENT & HISTORY (PASTOR & ADMIN ONLY)        */}
      {/* =================================================================== */}
      {activeTab === 'manage' && isPastorOrAdmin && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-600" />
                <span>Devotions Management & Publication History</span>
              </h2>
              <p className="text-xs text-slate-500">
                Authorized for PASTOR and SYSTEM_ADMIN roles only. Manage drafts, scheduled releases, and published words.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
              >
                <option value="all">All Statuses</option>
                <option value="published">Published</option>
                <option value="draft">Drafts</option>
                <option value="scheduled">Scheduled</option>
                <option value="archived">Archived</option>
              </select>

              <button
                type="button"
                onClick={() => handleOpenCreateModal()}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Create Daily Devotion</span>
              </button>
            </div>
          </div>

          {/* Devotions Management Table */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-black uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">Title & Topic</th>
                  <th className="p-3.5">Bible Reference</th>
                  <th className="p-3.5">Author</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {devotionsList.map((dev) => (
                  <tr key={dev.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                      <div>{dev.title}</div>
                      <span className="text-[10px] text-slate-400 font-normal">{dev.topic}</span>
                    </td>
                    <td className="p-3.5 font-bold text-blue-600 dark:text-blue-400">
                      {dev.scriptureReference}
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300 font-medium">
                      {dev.authorName || 'Pastor'}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          dev.status === 'published'
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : dev.status === 'scheduled'
                            ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {dev.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-400">
                      {dev.publishedAt ? new Date(dev.publishedAt).toLocaleDateString() : 'Not Set'}
                    </td>
                    <td className="p-3.5 text-right whitespace-nowrap">
                      <ActionMenu
                        recordTitle={dev.title}
                        primaryAction={{
                          id: 'toggle-status',
                          label: dev.status === 'published' ? 'Unpublish' : 'Publish',
                          icon: dev.status === 'published' ? <Archive className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />,
                          onClick: () => handleToggleStatus(dev, dev.status === 'published' ? 'draft' : 'published'),
                        }}
                        secondaryActions={[
                          {
                            id: 'edit-devotion',
                            label: 'Edit Devotion',
                            icon: <Edit3 className="w-3.5 h-3.5 text-blue-600" />,
                            onClick: () => handleOpenCreateModal(dev),
                          },
                          {
                            id: 'delete-devotion',
                            label: 'Delete Devotion',
                            icon: <Trash2 className="w-3.5 h-3.5" />,
                            variant: 'danger',
                            dividerBefore: true,
                            onClick: () => handleDeleteDevotion(dev.id),
                          },
                        ]}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 7. MODAL: CREATE / EDIT DAILY DEVOTION (REQUIREMENT 6 FORM)        */}
      {/* =================================================================== */}
      {isCreateModalOpen && isPastorOrAdmin && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white flex items-center justify-between">
              <div>
                <h3 className="text-base sm:text-lg font-black tracking-tight">
                  {editingDevotionId ? 'Edit Daily Devotion' : 'Create Daily Devotion'}
                </h3>
                <p className="text-xs text-blue-200">
                  Church-wide devotional content published to all authorized members
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form matching Specification */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs">
              {/* Title */}
              <div>
                <label className="block font-black text-slate-700 dark:text-slate-200 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Walking by Faith in Uncertain Times"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  required
                />
              </div>

              {/* Amharic Title (Optional) */}
              <div>
                <label className="block font-bold text-slate-500 mb-1">
                  Amharic Title (ርዕስ በአማርኛ - Optional)
                </label>
                <input
                  type="text"
                  value={formAmharicTitle}
                  onChange={(e) => setFormAmharicTitle(e.target.value)}
                  placeholder="e.g. በእምነት መመላለስ"
                  className="w-full px-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              {/* Bible Reference & Topic */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-black text-slate-700 dark:text-slate-200 mb-1">
                    Bible Reference *
                  </label>
                  <input
                    type="text"
                    value={formBibleReference}
                    onChange={(e) => setFormBibleReference(e.target.value)}
                    placeholder="e.g. Hebrews 11:1, John 3:16"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-500 mb-1">Topic</label>
                  <select
                    value={formTopic}
                    onChange={(e) => setFormTopic(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  >
                    {DEVOTION_TOPICS.filter((t) => t !== 'All').map((top) => (
                      <option key={top} value={top}>{top}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Devotional Content */}
              <div>
                <label className="block font-black text-slate-700 dark:text-slate-200 mb-1">
                  Devotional Content *
                </label>
                <textarea
                  rows={6}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Write the devotional reflection, spiritual exposition, and pastoral encouragement..."
                  className="w-full p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white leading-relaxed font-serif"
                  required
                />
              </div>

              {/* Prayer [Optional] */}
              <div>
                <label className="block font-bold text-slate-500 mb-1">
                  Prayer [Optional]
                </label>
                <textarea
                  rows={2}
                  value={formPrayer}
                  onChange={(e) => setFormPrayer(e.target.value)}
                  placeholder="Optional closing prayer for the congregation..."
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-serif italic"
                />
              </div>

              {/* Publication Date & Visibility */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-500 mb-1">Publication Date</label>
                  <input
                    type="date"
                    value={formPublicationDate}
                    onChange={(e) => setFormPublicationDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-500 mb-1">Visibility</label>
                  <select
                    value={formVisibility}
                    onChange={(e) => setFormVisibility(e.target.value as any)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  >
                    <option value="ALL_MEMBERS">All Members</option>
                    <option value="BRANCH_ONLY">Current Campus Only</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Modal Footer matching [ Save Draft ] [ Publish ] Specification */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={isSavingDevotion || !formTitle.trim() || !formContent.trim()}
                  onClick={() => handleSaveDevotion('draft')}
                  className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-bold cursor-pointer"
                >
                  Save Draft
                </button>

                <button
                  type="button"
                  disabled={isSavingDevotion || !formTitle.trim() || !formContent.trim()}
                  onClick={() => handleSaveDevotion('published')}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-black cursor-pointer shadow-md"
                >
                  {isSavingDevotion ? 'Saving...' : 'Publish'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 8. MODAL: CREATE PERSONAL JOURNAL ENTRY                             */}
      {/* =================================================================== */}
      {isJournalModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 space-y-4 animate-in zoom-in-95 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <BookMarked className="w-4 h-4 text-blue-600" />
                  <span>Personal Prayer & Reflection Journal</span>
                </h3>
                <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1 mt-0.5">
                  <Lock className="w-3 h-3" />
                  <span>Private to your account only</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsJournalModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveJournal} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-300 mb-1">Title *</label>
                <input
                  type="text"
                  value={journalTitle}
                  onChange={(e) => setJournalTitle(e.target.value)}
                  placeholder="e.g. Overcoming Fear with Trust"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-300 mb-1">Scripture Reference</label>
                <input
                  type="text"
                  value={journalScripture}
                  onChange={(e) => setJournalScripture(e.target.value)}
                  placeholder="e.g. Isaiah 40:31"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-300 mb-1">Personal Reflection *</label>
                <textarea
                  rows={4}
                  value={journalReflection}
                  onChange={(e) => setJournalReflection(e.target.value)}
                  placeholder="Write how God spoke to you through this scripture..."
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-serif"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-300 mb-1">Prayer</label>
                <textarea
                  rows={2}
                  value={journalPrayer}
                  onChange={(e) => setJournalPrayer(e.target.value)}
                  placeholder="A personal prayer response..."
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-serif italic"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsJournalModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 text-white font-black shadow-md"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DevotionModule;
