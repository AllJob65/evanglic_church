import React from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  TrendingUp,
  Brain,
  AlertTriangle,
  Users,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  BookOpen,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

export const PredictiveModule: React.FC = () => {
  const { members, attendanceSessions, prayerRequests } = useCMMS();

  // Attrition risk analysis
  const highRiskMembers = members.filter(
    (m) => m.attendanceScore !== undefined && m.attendanceScore < 75
  );

  const forecastData = attendanceSessions.map((s) => ({
    month: s.date,
    attendance: s.presentCount || 0,
    devotionCompletion: 0,
  }));

  const churnRiskCategories = [
    { name: 'Low Risk (80-100% Attendance)', count: members.filter((m) => (m.attendanceScore || 100) >= 80).length, color: 'bg-emerald-500' },
    { name: 'Moderate Risk (50-79% Score)', count: members.filter((m) => (m.attendanceScore || 100) >= 50 && (m.attendanceScore || 100) < 80).length, color: 'bg-amber-500' },
    { name: 'High Attrition Risk (<50% Score)', count: highRiskMembers.length, color: 'bg-rose-500' },
  ];

  const baptizedCount = members.filter((m) => m.isWaterBaptized).length;
  const discipledCount = members.filter((m) => m.discipleshipStatus === 'Discipled').length;
  const latestAttendance = attendanceSessions.length > 0 ? attendanceSessions[0].presentCount : 0;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 p-6 rounded-2xl text-white shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Brain className="w-7 h-7 text-purple-400" />
            <h1 className="text-2xl font-bold">Analytics & Early Warning Engine</h1>
          </div>
          <p className="text-xs text-purple-200/80 mt-1">
            Attendance retention, spiritual growth trends, and pastoral intervention alerts.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Latest Attendance
            </span>
            <div className="p-2.5 bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{latestAttendance}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">{attendanceSessions.length} recorded sessions</p>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Discipled Members
            </span>
            <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{discipledCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Completed foundation & discipleship</p>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              High Attrition Risk Members
            </span>
            <div className="p-2.5 bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 rounded-xl">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-rose-600 dark:text-rose-400">
              {highRiskMembers.length}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Inactivity / low attendance rate</p>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Baptized Members
            </span>
            <div className="p-2.5 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded-xl">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{baptizedCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Water baptized believers</p>
        </div>
      </div>

      {/* Forecast Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Attendance & Devotional Completion Forecast (Next 4 Months)
              </h3>
              <p className="text-xs text-slate-500">
                Predictive regression model factoring seasonal holidays and baptism cohorts.
              </p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} />
                <YAxis yAxisId="left" stroke="#8b5cf6" fontSize={11} />
                <YAxis yAxisId="right" orientation="right" stroke="#10b981" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '0.75rem',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="attendance"
                  stroke="#8b5cf6"
                  strokeWidth={3}
                  name="Attendance Forecast"
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="devotionCompletion"
                  stroke="#10b981"
                  strokeWidth={3}
                  name="Devotion Completion (%)"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Churn Risk Breakdown */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Member Retention Risk Matrix
            </h3>
            <p className="text-xs text-slate-500">Automated engagement scoring</p>
          </div>

          <div className="space-y-4 pt-2 text-xs">
            {churnRiskCategories.map((cat) => (
              <div key={cat.name} className="space-y-1">
                <div className="flex justify-between font-semibold text-slate-800 dark:text-slate-200">
                  <span>{cat.name}</span>
                  <span>{cat.count} Members</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${cat.color}`}
                    style={{ width: `${(cat.count / Math.max(members.length, 1)) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 mt-4 space-y-1">
            <p className="font-bold flex items-center gap-1">
              <AlertTriangle className="w-4 h-4 text-amber-600" /> Automated Care Trigger
            </p>
            <p className="text-[11px] text-amber-800 dark:text-amber-300">
              High-risk members are automatically assigned to the Pastoral Care & Visitation team for follow-up outreach.
            </p>
          </div>
        </div>
      </div>

      {/* High Risk Member Intervention List */}
      <div className="p-4 sm:p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />
          Members Flagged for Pastoral Intervention (Low Attendance Score)
        </h3>

        <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-200/80 dark:border-slate-800">
          <table className="cmms-data-table w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold bg-slate-50 dark:bg-slate-800/50">
                <th className="p-3 min-w-[150px]">Member Name</th>
                <th className="p-3 whitespace-nowrap">ID Number</th>
                <th className="p-3 whitespace-nowrap">Phone / Contact</th>
                <th className="p-3 whitespace-nowrap">Attendance Score</th>
                <th className="p-3 whitespace-nowrap">Status</th>
                <th className="p-3 text-right whitespace-nowrap sticky right-0 bg-slate-50 dark:bg-slate-800/95 z-10">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {highRiskMembers.map((m) => (
                <tr key={m.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-semibold text-slate-900 dark:text-white">
                    {m.firstName} {m.lastName}
                  </td>
                  <td className="p-3 font-mono text-slate-500 whitespace-nowrap tabular-nums">{m.memberIdNumber}</td>
                  <td className="p-3 text-slate-600 dark:text-slate-300 whitespace-nowrap tabular-nums">{m.primaryPhone}</td>
                  <td className="p-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded-full font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200 tabular-nums whitespace-nowrap">
                      {m.attendanceScore}%
                    </span>
                  </td>
                  <td className="p-3 text-slate-500 whitespace-nowrap">{m.membershipStatus}</td>
                  <td className="p-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/90 z-10">
                    <button
                      type="button"
                      className="min-h-[32px] px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[11px] font-bold inline-flex items-center justify-center whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Assign Pastoral Visit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
