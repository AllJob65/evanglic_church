import React, { useState, useEffect } from 'react';
import { Video, Radio, PhoneOff, ExternalLink, Copy, Check, MessageSquare, Sparkles, Users } from 'lucide-react';
import { VideoConference, GroupChatSession } from '../../types';
import { supabaseMinistryService } from '../../services/supabaseMinistryService';
import { io } from 'socket.io-client';

interface StartConferenceProps {
  groupId: string;
  leaderId: string;
  groupName?: string;
  onConferenceStarted?: (conf: VideoConference) => void;
  onOpenLiveChat?: () => void;
  className?: string;
}

export const StartConference: React.FC<StartConferenceProps> = ({
  groupId,
  leaderId,
  groupName = 'Ministry Group',
  onConferenceStarted,
  onOpenLiveChat,
  className = '',
}) => {
  const [loading, setLoading] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const [activeCall, setActiveCall] = useState<VideoConference | null>(null);
  const [activeChat, setActiveChat] = useState<GroupChatSession | null>(null);
  const [copied, setCopied] = useState(false);
  const [customTitle, setCustomTitle] = useState(`${groupName} Live Fellowship`);

  // Fetch initial active call & chat session
  useEffect(() => {
    let isMounted = true;

    const checkActiveSessions = async () => {
      try {
        const [resConf, resChat] = await Promise.all([
          fetch(`/api/video-conferences/active?groupId=${encodeURIComponent(groupId)}`),
          fetch(`/api/group-chats/active?groupId=${encodeURIComponent(groupId)}`),
        ]);

        if (resConf.ok) {
          const dataConf = await resConf.json();
          if (isMounted && dataConf.activeCall) {
            setActiveCall(dataConf.activeCall);
          }
        }

        if (resChat.ok) {
          const dataChat = await resChat.json();
          if (isMounted && dataChat.activeSession) {
            setActiveChat(dataChat.activeSession);
          }
        }
      } catch (err) {
        console.warn('Could not fetch active group sessions:', err);
      }
    };

    checkActiveSessions();

    // Listen to real-time socket updates
    const socket = io({ path: '/socket.io' });
    socket.emit('join_group_channel', { groupId, userId: leaderId });

    socket.on('video_conference_started', (conf: VideoConference) => {
      if (isMounted && conf.groupId === groupId) {
        setActiveCall(conf);
      }
    });

    socket.on('video_conference_ended', (data: { id: string; groupId: string }) => {
      if (isMounted && data.groupId === groupId) {
        setActiveCall(null);
      }
    });

    socket.on('chat_session_started', (session: GroupChatSession) => {
      if (isMounted && session.groupId === groupId) {
        setActiveChat(session);
      }
    });

    socket.on('chat_session_ended', (data: { sessionId: string; groupId: string }) => {
      if (isMounted && data.groupId === groupId) {
        setActiveChat(null);
      }
    });

    // Also listen to Supabase Realtime postgres_changes
    const unsubConf = supabaseMinistryService.subscribeToVideoConferences(groupId, {
      onStarted: (conf) => {
        if (isMounted) {
          setActiveCall({
            id: conf.id,
            groupId: conf.ministry_id,
            leaderId: conf.leader_profile_id,
            title: conf.title,
            roomUrl: conf.room_url,
            status: conf.status,
            createdAt: conf.created_at,
          });
        }
      },
      onEnded: () => {
        if (isMounted) setActiveCall(null);
      },
    });

    const unsubChat = supabaseMinistryService.subscribeToGroupChats(groupId, {
      onStarted: (session) => {
        if (isMounted) {
          setActiveChat({
            id: session.id,
            groupId: session.ministry_id,
            leaderId: session.leader_profile_id,
            isActive: session.is_active,
            startedAt: session.created_at,
          });
        }
      },
      onEnded: () => {
        if (isMounted) setActiveChat(null);
      },
    });

    return () => {
      isMounted = false;
      socket.disconnect();
      unsubConf.unsubscribe();
      unsubChat.unsubscribe();
    };
  }, [groupId, leaderId]);

  const handleStartCall = async () => {
    setLoading(true);
    // Unique dynamic WebRTC room URL (Jitsi Meet open instance with domain-scoped room identifier)
    const roomName = `CMMS-Group-${groupId.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`;
    const roomUrl = `https://meet.jit.si/${roomName}#config.prejoinPageEnabled=false&config.startWithAudioMuted=false`;

    try {
      // 1. Direct Supabase insert
      await supabaseMinistryService.startVideoConference({
        ministryId: groupId,
        leaderProfileId: leaderId,
        title: customTitle.trim() || `${groupName} Live Fellowship`,
        roomUrl,
      });

      // 2. Server socket/api broadcast
      const res = await fetch('/api/video-conferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          groupId,
          leaderId,
          title: customTitle.trim() || `${groupName} Live Fellowship`,
          roomUrl,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.conference) {
          setActiveCall(data.conference);
          if (onConferenceStarted) {
            onConferenceStarted(data.conference);
          }
        }
      }
    } catch (err) {
      console.error('Failed to start video conference:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEndCall = async () => {
    if (!activeCall) return;
    setLoading(true);
    try {
      await supabaseMinistryService.endVideoConference(activeCall.id);
      await fetch(`/api/video-conferences/${encodeURIComponent(activeCall.id)}/end`, {
        method: 'POST',
      });
      setActiveCall(null);
    } catch (err) {
      console.error('Failed to end video conference:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartChatSession = async () => {
    setChatLoading(true);
    try {
      await supabaseMinistryService.startGroupChatSession({
        ministryId: groupId,
        leaderProfileId: leaderId,
      });

      const res = await fetch('/api/group-chats/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groupId, leaderId }),
      });
      if (res.ok) {
        const data = await res.json();
        setActiveChat(data.session);
        if (onOpenLiveChat) {
          onOpenLiveChat();
        }
      }
    } catch (err) {
      console.error('Failed to start group chat session:', err);
    } finally {
      setChatLoading(false);
    }
  };

  const copyRoomLink = () => {
    if (!activeCall) return;
    navigator.clipboard.writeText(activeCall.roomUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`rounded-2xl border border-purple-200 dark:border-purple-900/60 bg-gradient-to-br from-purple-50/70 via-white to-indigo-50/40 dark:from-purple-950/40 dark:via-slate-900 dark:to-indigo-950/30 p-5 shadow-xs ${className}`}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-600/10 text-purple-700 dark:text-purple-300 border border-purple-300 dark:border-purple-800">
              Leader Control Center
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {groupName}
            </span>
          </div>
          <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Video className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            Live Video Call & Fellowship Broadcast
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Instantly create a dynamic WebRTC meeting room and notify all group members in real-time.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {activeCall ? (
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5 animate-pulse">
              <Radio className="w-3.5 h-3.5" />
              Room Live
            </span>
          ) : (
            <span className="px-3 py-1 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">
              Idle
            </span>
          )}
        </div>
      </div>

      {activeCall ? (
        <div className="p-4 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800/80 space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <span className="font-bold text-sm text-emerald-900 dark:text-emerald-200">
                  {activeCall.title}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 font-mono truncate max-w-md">
                {activeCall.roomUrl}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={copyRoomLink}
                className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 hover:bg-slate-50 cursor-pointer shadow-2xs"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Link'}
              </button>

              <a
                href={activeCall.roomUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Launch WebRTC Room
              </a>

              <button
                type="button"
                onClick={handleEndCall}
                disabled={loading}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer disabled:opacity-50"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                End Call
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              placeholder="Meeting Topic / Service Title"
              className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
            />
            <button
              type="button"
              onClick={handleStartCall}
              disabled={loading}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer disabled:opacity-50"
            >
              <Video className="w-4 h-4" />
              {loading ? 'Starting Call...' : 'Start Video Conference'}
            </button>

            <button
              type="button"
              onClick={handleStartChatSession}
              disabled={chatLoading}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer shadow-xs"
              title="Broadcast live chat listener trigger to group members"
            >
              <MessageSquare className="w-4 h-4 text-purple-400" />
              {chatLoading ? 'Triggering...' : 'Trigger Live Chat'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
