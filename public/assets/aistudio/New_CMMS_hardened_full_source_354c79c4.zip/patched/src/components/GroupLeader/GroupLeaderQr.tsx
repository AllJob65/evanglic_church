import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useCMMS } from '../../context/CMMSContext';
import { AttendanceSession, AttendanceRecord } from '../../types';
import {
  QrCode,
  Sparkles,
  Copy,
  Check,
  Maximize2,
  Minimize2,
  ShieldCheck,
  Calendar,
  Layers,
  Play,
  Square,
  RefreshCw,
  Users,
  Clock,
  MapPin,
  Radio,
  CheckCircle2,
  Download,
  AlertCircle,
} from 'lucide-react';

interface GroupLeaderQrProps {
  ministryId?: string;
  ministryName?: string;
  serviceType?: string;
  className?: string;
}

export const GroupLeaderQr: React.FC<GroupLeaderQrProps> = ({
  ministryId: propMinistryId,
  ministryName: propMinistryName,
  serviceType = 'Group Session',
  className = '',
}) => {
  const {
    ministries,
    activeAttendanceSessions,
    activateAttendanceSession,
    closeAttendanceSession,
    rotateSessionToken,
    attendanceRecords,
    currentUser,
  } = useCMMS();

  // Selected ministry for this leader view
  const defaultMinistryId = propMinistryId || ministries[0]?.id || 'min-001';
  const [selectedMinistryId, setSelectedMinistryId] = useState<string>(defaultMinistryId);

  const activeMinistry =
    ministries.find((m) => m.id === selectedMinistryId) ||
    ministries[0] || {
      id: 'min-001',
      name: propMinistryName || 'Worship & Praise Ministry',
    };

  // Find if there's already an active session for this ministry or branch
  const existingActiveSession = activeAttendanceSessions.find(
    (s) => s.groupId === selectedMinistryId && s.status === 'active'
  );

  const [currentSession, setCurrentSession] = useState<AttendanceSession | null>(
    existingActiveSession || null
  );

  // Form controls for new session
  const [sessionType, setSessionType] = useState<'instant' | 'scheduled'>('instant');
  const [eventName, setEventName] = useState(
    `${activeMinistry.name} Weekly Fellowship`
  );
  const [selectedServiceType, setSelectedServiceType] = useState(serviceType);
  const [sessionLocation, setSessionLocation] = useState('Sanctuary - Room 204');
  
  // Security & Dynamic Rotation (15s timer)
  const [autoRotate, setAutoRotate] = useState(true);
  const [timeLeft, setTimeLeft] = useState(15);
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Keep state in sync with context
  useEffect(() => {
    if (existingActiveSession) {
      setCurrentSession(existingActiveSession);
    } else if (currentSession?.status === 'closed') {
      setCurrentSession(null);
    }
  }, [existingActiveSession, currentSession?.status]);

  // Update default event name when ministry changes
  useEffect(() => {
    if (!currentSession) {
      setEventName(`${activeMinistry.name} Gathering`);
    }
  }, [activeMinistry.name, currentSession]);

  const rotateSessionTokenRef = useRef(rotateSessionToken);
  rotateSessionTokenRef.current = rotateSessionToken;

  const currentSessionId = currentSession?.sessionId;
  const isSessionActive = currentSession?.status === 'active';

  // Automatic token rotation timer (every 15s when session is active)
  useEffect(() => {
    if (!isSessionActive || !currentSessionId || !autoRotate) {
      setTimeLeft(15);
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Defer rotation outside this state updater function to avoid updating CMMSProvider while rendering GroupLeaderQr
          setTimeout(() => {
            if (rotateSessionTokenRef.current) {
              rotateSessionTokenRef.current(currentSessionId);
            }
          }, 0);
          return 15;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isSessionActive, currentSessionId, autoRotate]);

  // Handle Session Start
  const handleStartSession = () => {
    const session = activateAttendanceSession({
      groupId: activeMinistry.id,
      groupName: activeMinistry.name,
      leaderId: currentUser?.memberId || 'mem-101',
      leaderName: currentUser?.name || 'Group Leader',
      type: sessionType,
      title: eventName.trim() || `${activeMinistry.name} Fellowship`,
      serviceType: selectedServiceType,
      location: sessionLocation,
    });
    setCurrentSession(session);
    setTimeLeft(15);
  };

  // Handle Session End
  const handleEndSession = () => {
    if (currentSession) {
      closeAttendanceSession(currentSession.sessionId);
      setCurrentSession(null);
    }
  };

  // Manual token rotate
  const handleManualRotate = () => {
    if (currentSession) {
      rotateSessionToken(currentSession.sessionId);
      setTimeLeft(15);
    }
  };

  // Construct official leader QR payload
  const qrPayload = currentSession
    ? JSON.stringify({
        leaderGenerated: true,
        sessionId: currentSession.sessionId,
        ministryId: currentSession.groupId,
        ministryName: currentSession.groupName,
        eventName: currentSession.title,
        serviceType: currentSession.serviceType,
        token: currentSession.qrPayloadToken,
        timestamp: new Date().toISOString(),
      })
    : JSON.stringify({
        leaderGenerated: true,
        ministryId: activeMinistry.id,
        eventName: eventName,
        serviceType: selectedServiceType,
        timestamp: new Date().toISOString(),
      });

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(qrPayload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filter attendees checked in for this active session
  const sessionAttendees = currentSession
    ? attendanceRecords.filter(
        (r) =>
          r.sessionId === currentSession.sessionId ||
          (r.serviceName === currentSession.title &&
            r.date === new Date().toISOString().substring(0, 10))
      )
    : [];

  return (
    <div
      className={`p-6 rounded-2xl bg-slate-900 border border-purple-500/30 text-white shadow-2xl ${className}`}
      id="group-leader-qr-station"
    >
      {/* Station Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-black text-base sm:text-lg text-white">
                Leader Live Attendance Terminal
              </h3>
              {currentSession?.status === 'active' ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 animate-pulse">
                  <Radio className="w-2.5 h-2.5 text-emerald-400" />
                  Live Active Session
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-800 text-slate-400 border border-slate-700">
                  Ready to Launch
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              Launch instant or scheduled sessions with dynamic rotating QR verification and 1-Click web sync.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {currentSession?.status === 'active' ? (
            <button
              type="button"
              onClick={handleEndSession}
              className="px-3.5 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-2 cursor-pointer transition-all"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              Close Session
            </button>
          ) : (
            <button
              type="button"
              onClick={handleStartSession}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/25 cursor-pointer transition-all"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Start Live Session
            </button>
          )}
        </div>
      </div>

      {/* Main Grid */}
      <div className="mt-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: QR Code Display & Dynamic Rotation controls (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center p-5 bg-slate-950 rounded-2xl border border-slate-800 relative">
          {currentSession?.status === 'active' ? (
            <>
              {/* Dynamic QR Display */}
              <div className="p-4 bg-white rounded-2xl shadow-2xl inline-block border-4 border-purple-500/30 relative">
                <QRCodeSVG
                  value={qrPayload}
                  size={200}
                  level="H"
                  marginSize={2}
                  className="rounded-lg"
                />
              </div>

              {/* Security Rotation Info */}
              <div className="mt-4 w-full flex items-center justify-between px-2 text-xs">
                <div className="flex items-center gap-1.5 text-slate-300 font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Dynamic Rotation:</span>
                  <span className="font-mono font-bold text-purple-400">{timeLeft}s</span>
                </div>
                <button
                  type="button"
                  onClick={handleManualRotate}
                  title="Rotate QR Code Token immediately"
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 hover:text-white transition-all cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Action Buttons */}
              <div className="mt-3 w-full grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setIsFullscreen(true)}
                  className="py-2 px-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  Kiosk Mode
                </button>
                <button
                  type="button"
                  onClick={handleCopyPayload}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied' : 'Copy Payload'}
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-10 px-4">
              <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mx-auto text-purple-400 mb-3">
                <QrCode className="w-8 h-8 opacity-60" />
              </div>
              <h4 className="font-bold text-sm text-white mb-1">Session Inactive</h4>
              <p className="text-xs text-slate-400 max-w-xs mx-auto mb-4">
                Configure details on the right and click <strong>"Start Live Session"</strong> to activate the secure QR code and 1-Click web portal.
              </p>
              <button
                type="button"
                onClick={handleStartSession}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 mx-auto shadow-md cursor-pointer transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                Launch Instant Session
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Session Configuration & Live Stream (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
          {/* Configuration Form */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Ministry selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Users className="w-3 h-3 text-purple-400" />
                  Ministry Group
                </label>
                <select
                  value={selectedMinistryId}
                  onChange={(e) => setSelectedMinistryId(e.target.value)}
                  disabled={currentSession?.status === 'active'}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-hidden focus:ring-1 focus:ring-purple-500 disabled:opacity-50 cursor-pointer"
                >
                  {ministries.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Session Type */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Layers className="w-3 h-3 text-purple-400" />
                  Session Mode
                </label>
                <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-800 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setSessionType('instant')}
                    disabled={currentSession?.status === 'active'}
                    className={`py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      sessionType === 'instant'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Instant
                  </button>
                  <button
                    type="button"
                    onClick={() => setSessionType('scheduled')}
                    disabled={currentSession?.status === 'active'}
                    className={`py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      sessionType === 'scheduled'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Scheduled
                  </button>
                </div>
              </div>
            </div>

            {/* Event Name */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-purple-400" />
                Session Title / Gathering
              </label>
              <input
                type="text"
                value={eventName}
                onChange={(e) => setEventName(e.target.value)}
                disabled={currentSession?.status === 'active'}
                placeholder="e.g., Youth Fellowship Weekly Service"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-hidden focus:ring-1 focus:ring-purple-500 disabled:opacity-50"
              />
            </div>

            {/* Location & Service Type */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Layers className="w-3 h-3 text-purple-400" />
                  Service Type
                </label>
                <select
                  value={selectedServiceType}
                  onChange={(e) => setSelectedServiceType(e.target.value)}
                  disabled={currentSession?.status === 'active'}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-hidden focus:ring-1 focus:ring-purple-500 disabled:opacity-50 cursor-pointer"
                >
                  <option value="Group Session">Group Session</option>
                  <option value="Bible Study">Bible Study</option>
                  <option value="Prayer Vigil">Prayer Vigil</option>
                  <option value="Rehearsal / Practice">Rehearsal / Practice</option>
                  <option value="Youth Service">Youth Service</option>
                  <option value="Outreach / Evangelism">Outreach / Evangelism</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-purple-400" />
                  Room / Location
                </label>
                <input
                  type="text"
                  value={sessionLocation}
                  onChange={(e) => setSessionLocation(e.target.value)}
                  disabled={currentSession?.status === 'active'}
                  placeholder="e.g., Main Hall B"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white font-medium focus:outline-hidden focus:ring-1 focus:ring-purple-500 disabled:opacity-50"
                />
              </div>
            </div>
          </div>

          {/* Live Check-In Stream & Real-Time Count */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex-1 flex flex-col justify-between">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-black text-white">Live Attendance Stream</h4>
              </div>
              <span className="px-2 py-0.5 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {sessionAttendees.length} Verified Check-In{sessionAttendees.length === 1 ? '' : 's'}
              </span>
            </div>

            {sessionAttendees.length > 0 ? (
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {sessionAttendees.slice(0, 6).map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-slate-800 text-xs animate-in fade-in"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-indigo-600/30 border border-indigo-500/30 flex items-center justify-center font-black text-[10px] text-indigo-300">
                        {att.memberName?.charAt(0) || 'M'}
                      </div>
                      <div>
                        <p className="font-bold text-white leading-none">{att.memberName}</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">{att.checkInMethod}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5 text-slate-500" />
                      {att.time || att.checkInTime}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-xs text-slate-500">
                {currentSession?.status === 'active'
                  ? 'Awaiting members to scan or check in via portal...'
                  : 'Start session to stream live attendee check-ins.'}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fullscreen Kiosk Mode Modal */}
      {isFullscreen && currentSession && (
        <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-center p-6 animate-in fade-in">
          <div className="max-w-md w-full text-center space-y-5">
            <div className="flex justify-between items-center">
              <span className="text-xs font-black uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
                Live Attendance Check-In Kiosk
              </span>
              <button
                type="button"
                onClick={() => setIsFullscreen(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Minimize2 className="w-3.5 h-3.5" />
                Exit Kiosk Mode
              </button>
            </div>

            <div className="p-6 bg-white rounded-3xl shadow-2xl inline-block border-4 border-purple-500/40">
              <QRCodeSVG
                value={qrPayload}
                size={280}
                level="H"
                marginSize={2}
                className="mx-auto"
              />
            </div>

            <div className="space-y-1">
              <h2 className="text-2xl font-black text-white">{currentSession.title}</h2>
              <p className="text-sm text-purple-300 font-semibold">
                {currentSession.groupName} • {currentSession.serviceType}
              </p>
              <div className="pt-2 flex items-center justify-center gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {sessionAttendees.length} Checked In
                </span>
                <span className="font-mono">Auto-refreshes in {timeLeft}s</span>
              </div>
              <p className="text-xs text-slate-500 pt-2">
                Open Church App / Member Portal &rarr; 1-Click Check In or Scan QR
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
