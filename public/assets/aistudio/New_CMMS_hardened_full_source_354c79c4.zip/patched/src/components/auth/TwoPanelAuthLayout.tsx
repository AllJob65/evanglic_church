import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCMMS } from '../../context/CMMSContext';
import { useTranslation } from '../../i18n/LanguageContext';
import {
  Church,
  ShieldCheck,
  Lock,
  Globe,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Shield,
  Heart,
  CalendarCheck,
  UserCheck,
  KeyRound,
  X,
} from 'lucide-react';

export interface TwoPanelAuthLayoutProps {
  portalType: 'member' | 'staff';
  title: string;
  subtitle?: string;
  activeTab?: 'member' | 'staff';
  onTabChange?: (tab: 'member' | 'staff') => void;
  children: React.ReactNode;
  errorMessage?: string;
  successMessage?: string;
  footerSwitchLink?: {
    prompt: string;
    actionText: string;
    to?: string;
    onClick?: () => void;
  };
}

export const TwoPanelAuthLayout: React.FC<TwoPanelAuthLayoutProps> = ({
  portalType,
  title,
  subtitle,
  activeTab,
  onTabChange,
  children,
  errorMessage,
  successMessage,
  footerSwitchLink,
}) => {
  const {
    churchName,
    churchMotto,
    churchLogoUrl,
    systemName,
    primaryColorHex,
    accentColorHex,
  } = useCMMS();

  const { t, language, setLanguage } = useTranslation();
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);

  // Dynamic CSS-safe brand colors with fallbacks
  const primaryColor = primaryColorHex && primaryColorHex.startsWith('#') ? primaryColorHex : '#2563eb';
  const accentColor = accentColorHex && accentColorHex.startsWith('#') ? accentColorHex : '#7c3aed';
  const effectiveChurchName = churchName || 'Church Management System';
  const effectiveTagline = churchMotto || 'Reaching the Lost, Discipling the Found, Transforming Nations';

  const isStaff = portalType === 'staff';

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col lg:flex-row overflow-x-hidden selection:bg-amber-500/30 selection:text-white">
      {/* ========================================================= */}
      {/* LEFT PANEL: Clean Responsive Form Area (100% on <1024px)   */}
      {/* ========================================================= */}
      <section
        aria-label="Authentication Form"
        className="w-full lg:w-1/2 xl:w-[50%] min-h-screen flex flex-col justify-between p-4 sm:p-8 lg:p-12 xl:p-16 max-w-full overflow-y-auto"
      >
        {/* Top Header Bar */}
        <header className="w-full max-w-md mx-auto flex items-center justify-between pb-6 border-b border-slate-800/60">
          <Link
            to="/"
            className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-amber-500 rounded-xl p-1"
            title="Return to Home"
          >
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center p-2 border border-slate-700/80 shadow-md transition-transform group-hover:scale-105 shrink-0"
              style={{
                background: `linear-gradient(135deg, ${primaryColor}33, ${accentColor}22)`,
              }}
            >
              {churchLogoUrl ? (
                <img
                  src={churchLogoUrl}
                  alt={effectiveChurchName}
                  className="w-full h-full object-contain"
                />
              ) : (
                <Church className="w-5 h-5 text-amber-400 shrink-0" />
              )}
            </div>
            <div className="flex flex-col text-left">
              <span className="text-xs sm:text-sm font-bold text-white tracking-tight group-hover:text-amber-400 transition-colors line-clamp-1">
                {effectiveChurchName}
              </span>
              <span className="text-[10px] text-slate-400 flex items-center gap-1 font-medium">
                {systemName || 'Church CMMS'}
                <span className="text-slate-600">•</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Online
                </span>
              </span>
            </div>
          </Link>

          {/* Language Switcher */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5 shrink-0" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-transparent text-slate-300 font-medium text-xs px-2 py-1 focus:outline-none cursor-pointer"
              aria-label="Select Language"
            >
              <option value="English" className="bg-slate-900 text-white">English</option>
              <option value="Amharic" className="bg-slate-900 text-white">አማርኛ (Amharic)</option>
              <option value="Tigrigna" className="bg-slate-900 text-white">ትግርኛ (Tigrigna)</option>
              <option value="Afaan Oromoo" className="bg-slate-900 text-white">Oromoo</option>
            </select>
          </div>
        </header>

        {/* Center Content / Form Container */}
        <main className="w-full max-w-md mx-auto my-auto py-8 sm:py-10">
          {/* Portal Switcher Tabs */}
          {onTabChange && activeTab && (
            <div
              role="tablist"
              aria-label="Portal Selection"
              className="mb-6 p-1 bg-slate-900/90 border border-slate-800 rounded-2xl flex items-center shadow-inner"
            >
              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'member'}
                onClick={() => onTabChange('member')}
                className={`flex-1 min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'member'
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Church className="w-4 h-4 shrink-0" />
                <span>{t('auth.member_tab', 'Member Portal')}</span>
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'staff'}
                onClick={() => onTabChange('staff')}
                className={`flex-1 min-h-[44px] py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  activeTab === 'staff'
                    ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-md shadow-indigo-600/25'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>{t('auth.staff_tab', 'Staff & Leadership')}</span>
              </button>
            </div>
          )}

          {/* Heading */}
          <div className="space-y-1.5 mb-6 text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide uppercase border mb-1"
              style={{
                backgroundColor: isStaff ? `${accentColor}18` : `${primaryColor}18`,
                borderColor: isStaff ? `${accentColor}44` : `${primaryColor}44`,
                color: isStaff ? '#c7d2fe' : '#fde68a',
              }}
            >
              {isStaff ? (
                <>
                  <Lock className="w-3 h-3 text-indigo-400" />
                  <span>Authorized Personnel Only</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>Church Flock & Covenant Fellowship</span>
                </>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {title}
            </h1>
            {subtitle && (
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                {subtitle}
              </p>
            )}
          </div>

          {/* Global Alert Messages */}
          {errorMessage && (
            <div
              role="alert"
              className="mb-5 p-3.5 sm:p-4 rounded-2xl bg-rose-950/70 border border-rose-800/80 flex items-start gap-3 text-rose-200 text-xs sm:text-sm animate-in fade-in duration-200"
            >
              <div className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                ✕
              </div>
              <p className="font-medium leading-relaxed">{errorMessage}</p>
            </div>
          )}

          {successMessage && (
            <div
              role="status"
              className="mb-5 p-3.5 sm:p-4 rounded-2xl bg-emerald-950/70 border border-emerald-800/80 flex items-start gap-3 text-emerald-200 text-xs sm:text-sm animate-in fade-in duration-200"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <p className="font-medium leading-relaxed">{successMessage}</p>
            </div>
          )}

          {/* Form Content / Children */}
          <div className="w-full">{children}</div>

          {/* Footer Portal Switcher Link */}
          {footerSwitchLink && (
            <div className="mt-8 pt-6 border-t border-slate-800/80 flex items-center justify-between text-xs">
              <span className="text-slate-400">{footerSwitchLink.prompt}</span>
              {footerSwitchLink.to ? (
                <Link
                  to={footerSwitchLink.to}
                  className="font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
                >
                  <span>{footerSwitchLink.actionText}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              ) : (
                <button
                  type="button"
                  onClick={footerSwitchLink.onClick}
                  className="font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>{footerSwitchLink.actionText}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </main>

        {/* Bottom Footer Section */}
        <footer className="w-full max-w-md mx-auto pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} {effectiveChurchName}. All rights reserved.</p>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowPrivacyModal(true)}
              className="hover:text-slate-300 transition-colors underline underline-offset-2 cursor-pointer"
            >
              Privacy &amp; Governance
            </button>
            <span>&bull;</span>
            <span className="text-slate-600">v3.4.1 Sovereign</span>
          </div>
        </footer>
      </section>

      {/* ========================================================= */}
      {/* RIGHT PANEL: Branded Dynamic CSS Gradient & Church Art    */}
      {/* Hidden on <1024px, Visible on >=1024px (~50% viewport)   */}
      {/* ========================================================= */}
      <aside
        aria-label="Church Identity Showcase"
        className="hidden lg:flex lg:w-1/2 xl:w-[50%] min-h-screen relative p-12 xl:p-20 flex-col justify-between overflow-hidden border-l border-slate-800/60"
        style={{
          background: `radial-gradient(ellipse at 80% 20%, ${primaryColor}25 0%, transparent 55%), radial-gradient(ellipse at 20% 80%, ${accentColor}28 0%, transparent 60%), #070a12`,
        }}
      >
        {/* Decorative Blurred Ambient Circles (CSS-only) */}
        <div
          aria-hidden="true"
          className="absolute -top-32 -right-32 w-96 h-96 rounded-full blur-3xl opacity-35 pointer-events-none animate-pulse"
          style={{ backgroundColor: primaryColor }}
        />
        <div
          aria-hidden="true"
          className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full blur-3xl opacity-30 pointer-events-none"
          style={{ backgroundColor: accentColor }}
        />
        <div
          aria-hidden="true"
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full blur-[100px] opacity-20 pointer-events-none"
          style={{ backgroundColor: primaryColor }}
        />

        {/* Subtle Geometric Background Pattern (CSS-only radial dot grid) */}
        <div
          aria-hidden="true"
          className="absolute inset-0 opacity-[0.06] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #ffffff 1px, transparent 0)`,
            backgroundSize: '28px 28px',
          }}
        />

        {/* Right Top Header Badge */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 backdrop-blur-md shadow-lg">
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: isStaff ? '#818cf8' : '#fbbf24' }}
            />
            <span className="text-xs font-semibold text-slate-300">
              {isStaff ? 'Sovereign Security Gateway' : 'Covenant Member Access'}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800/80 backdrop-blur-md">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="font-mono text-[11px] text-slate-300">256-Bit SSL Encrypted</span>
          </div>
        </div>

        {/* Right Center Brand Showcase Card */}
        <div className="relative z-10 my-auto py-8 space-y-8 max-w-lg">
          {/* Main Church Identity Icon & Motto */}
          <div className="space-y-4">
            <div
              className="w-16 h-16 rounded-3xl flex items-center justify-center p-3 border border-white/10 shadow-2xl backdrop-blur-xl"
              style={{
                background: `linear-gradient(135deg, ${primaryColor}40, ${accentColor}30)`,
                boxShadow: `0 20px 40px -10px ${primaryColor}40`,
              }}
            >
              {churchLogoUrl ? (
                <img
                  src={churchLogoUrl}
                  alt={effectiveChurchName}
                  className="w-full h-full object-contain"
                />
              ) : (
                <Church className="w-8 h-8 text-white" />
              )}
            </div>

            <div className="space-y-2">
              <h2 className="text-3xl xl:text-4xl font-extrabold text-white tracking-tight leading-tight">
                {isStaff ? 'Leadership & Flock Governance' : 'Welcome to Your Church Home'}
              </h2>
              <p
                className="text-sm font-semibold tracking-wide"
                style={{ color: isStaff ? '#a5b4fc' : '#fde68a' }}
              >
                “{effectiveTagline}”
              </p>
            </div>

            <p className="text-xs xl:text-sm text-slate-300 leading-relaxed font-normal">
              {isStaff
                ? 'Comprehensive multi-campus management, pastoral visitations, financial stewardship oversight, and member discipleship records — protected under strict role-based access control.'
                : 'Stay engaged with your spiritual community. Access your discipleship records, daily devotions, church attendance, prayer requests, and small groups anytime, anywhere.'}
            </p>
          </div>

          {/* Three Feature Highlight Cards */}
          <div className="grid grid-cols-1 gap-3 pt-2">
            {isStaff ? (
              <>
                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md flex items-center gap-3.5 hover:border-indigo-500/40 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Granular Role-Based Access Control</h4>
                    <p className="text-[11px] text-slate-400">Strict separation between Pastors, Administrators, Managers, and Ministry Heads.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md flex items-center gap-3.5 hover:border-indigo-500/40 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">RFC 6238 TOTP Multi-Factor Protection</h4>
                    <p className="text-[11px] text-slate-400">Mandatory authenticator code verification and 30-day session security protocols.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md flex items-center gap-3.5 hover:border-indigo-500/40 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Pastoral Membership Approval Pipeline</h4>
                    <p className="text-[11px] text-slate-400">Review pending member self-registrations with one-click covenant activation.</p>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md flex items-center gap-3.5 hover:border-amber-500/40 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Heart className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Daily Devotions &amp; Spiritual Growth</h4>
                    <p className="text-[11px] text-slate-400">Multi-lingual scriptures, uplifting daily devotions, and prayer requests.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md flex items-center gap-3.5 hover:border-amber-500/40 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <CalendarCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Instant Attendance Self Check-In</h4>
                    <p className="text-[11px] text-slate-400">Fast QR check-in and attendance history tracking for services and classes.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md flex items-center gap-3.5 hover:border-amber-500/40 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Family Household Profiles</h4>
                    <p className="text-[11px] text-slate-400">Keep emergency contacts and family relationships up to date.</p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Right Bottom Footer Note */}
        <div className="relative z-10 pt-4 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60">
          <span>{effectiveChurchName}</span>
          <span className="font-mono text-slate-500">ISO/IEC 27001 Security Aligned</span>
        </div>
      </aside>

      {/* Privacy & Governance Modal */}
      {showPrivacyModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
        >
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative space-y-4">
            <button
              type="button"
              onClick={() => setShowPrivacyModal(false)}
              className="absolute right-4 top-4 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 pb-2 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Privacy &amp; Data Protection Policy</h3>
                <p className="text-xs text-slate-400">{effectiveChurchName}</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed max-h-80 overflow-y-auto pr-2">
              <p>
                <strong>1. Sacred Stewardship of Member Data:</strong> All member contact information, pastoral counseling notes, prayer requests, and attendance records are strictly confidential and stored securely in compliance with international privacy protocols.
              </p>
              <p>
                <strong>2. Role-Based Access Isolation:</strong> Pastoral counseling notes and financial tithe records are accessible strictly by authorized ordained clergy and financial trustees, never exposed to unauthorized personnel.
              </p>
              <p>
                <strong>3. Authentication &amp; Encryption:</strong> All sessions are protected using TLS 1.3 encryption, RFC 6238 time-based two-factor authentication, and audited session expiration.
              </p>
              <p>
                <strong>4. Session Management:</strong> By selecting "Remember Credentials", your authenticated token persists securely on this trusted device until explicit sign-out. Unchecking the box ensures sessions are terminated immediately upon closing the browser.
              </p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all cursor-pointer"
              >
                Understood &amp; Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
