import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { getStoredAuthToken } from '../lib/supabase';
import {
  ShieldCheck,
  ShieldAlert,
  Download,
  Search,
  Filter,
  Lock,
  Key,
  UserCheck,
  Terminal,
  X,
  Code,
  Globe,
  Clock,
  Laptop,
  Activity,
  RefreshCw,
  Server,
  Fingerprint,
  CheckCircle2,
  AlertTriangle,
  Users,
  Settings,
  LogOut,
  FileCheck,
  AlertOctagon,
  ChevronLeft,
  ChevronRight,
  Sliders,
} from 'lucide-react';
import { AuditLog, UserRole } from '../types';
import { ActionMenu } from './ui/ActionMenu';

type DashboardTab =
  | 'overview'
  | 'rbac'
  | 'sessions'
  | 'audit'
  | 'alerts'
  | 'config';

export const SecurityAuditModule: React.FC = () => {
  const {
    auditLogs,
    systemUsers,
    activeRole,
    getAuthHeaders: contextGetAuthHeaders,
    updateUserRole,
    refreshFromBackend: contextRefreshFromBackend,
    reloadFromBackend,
  } = useCMMS();

  const getAuthHeaders = useCallback(
    (extraHeaders: Record<string, string> = {}): Record<string, string> => {
      if (typeof contextGetAuthHeaders === 'function') {
        return contextGetAuthHeaders(extraHeaders);
      }
      const token = getStoredAuthToken();
      const tenantId =
        typeof window !== 'undefined'
          ? localStorage.getItem('cmms_tenant_id') || 'tenant-grace-main'
          : 'tenant-grace-main';
      const headers: Record<string, string> = {
        Accept: 'application/json',
        'x-tenant-id': tenantId,
        ...extraHeaders,
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      return headers;
    },
    [contextGetAuthHeaders]
  );

  const refreshFromBackend = useCallback(async () => {
    if (typeof contextRefreshFromBackend === 'function') {
      await contextRefreshFromBackend();
    } else if (typeof reloadFromBackend === 'function') {
      await reloadFromBackend();
    }
  }, [contextRefreshFromBackend, reloadFromBackend]);

  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [loading, setLoading] = useState(false);
  const [bannerMessage, setBannerMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Real backend dashboard state
  const [dashboardData, setDashboardData] = useState<any>(null);

  // Audit Trail Filter & Pagination State
  const [filterQuery, setFilterQuery] = useState('');
  const [userFilter, setUserFilter] = useState('ALL');
  const [eventTypeFilter, setEventTypeFilter] = useState('ALL');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [outcomeFilter, setOutcomeFilter] = useState('ALL');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  // Session Filters & Revocation Confirmation Modal
  const [sessionStatusFilter, setSessionStatusFilter] = useState('ALL');
  const [sessionSearch, setSessionSearch] = useState('');
  const [confirmRevokeSession, setConfirmRevokeSession] = useState<any | null>(null);
  const [revokeReason, setRevokeReason] = useState('Administrative security revocation');
  const [revokingSessionId, setRevokingSessionId] = useState<string | null>(null);

  // RBAC Role Change State
  const [updatingUserId, setUpdatingUserId] = useState<string | null>(null);
  const [selectedRoleMap, setSelectedRoleMap] = useState<Record<string, UserRole>>({});

  // Security Config Form State
  const [configForm, setConfigForm] = useState({
    jwtLifespanHours: 24,
    lockoutMaxAttempts: 5,
    lockoutDurationMinutes: 15,
    mfaEnforcementMode: 'enforced' as 'enforced' | 'optional',
  });
  const [savingConfig, setSavingConfig] = useState(false);
  const [verifyingIntegrity, setVerifyingIntegrity] = useState(false);

  const isSystemAdmin = activeRole === 'SYSTEM_ADMIN';

  const fetchSecurityDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const headers = getAuthHeaders();
      const res = await fetch('/api/audit/security-dashboard', { headers });
      if (res.ok) {
        const data = await res.json();
        setDashboardData(data);
        if (data.securityConfig) {
          setConfigForm({
            jwtLifespanHours: data.securityConfig.jwtLifespanHours || 24,
            lockoutMaxAttempts: data.securityConfig.lockoutMaxAttempts || 5,
            lockoutDurationMinutes: data.securityConfig.lockoutDurationMinutes || 15,
            mfaEnforcementMode: data.securityConfig.mfaEnforcementMode || 'enforced',
          });
        }
      } else {
        const errBody = await res.json().catch(() => ({}));
        setBannerMessage({
          type: 'error',
          text: errBody.message || errBody.error || `Failed to load verified security telemetry (HTTP ${res.status}).`,
        });
      }
    } catch (err: any) {
      console.warn('[SecurityDashboard] Failed to load telemetry:', err);
      setBannerMessage({
        type: 'error',
        text: err?.message || 'Unable to reach security telemetry backend. Displaying unverified state.',
      });
    } finally {
      setLoading(false);
    }
  }, [getAuthHeaders]);

  useEffect(() => {
    fetchSecurityDashboard();
  }, [fetchSecurityDashboard]);

  // Combine audit logs from context and backend dashboard
  const allAuditLogs: AuditLog[] = useMemo(() => {
    return auditLogs && auditLogs.length > 0 ? auditLogs : [];
  }, [auditLogs]);

  const distinctEventTypes = useMemo(() => {
    const types = new Set<string>();
    for (const l of allAuditLogs) {
      if (l.eventType) types.add(l.eventType);
    }
    return Array.from(types).sort();
  }, [allAuditLogs]);

  const filteredLogs = useMemo(() => {
    return allAuditLogs.filter((log) => {
      if (filterQuery.trim()) {
        const q = filterQuery.toLowerCase();
        const matchesSearch =
          (log.action || '').toLowerCase().includes(q) ||
          (log.userEmail || '').toLowerCase().includes(q) ||
          (log.userName || '').toLowerCase().includes(q) ||
          (log.details || '').toLowerCase().includes(q) ||
          (log.ipAddress || '').toLowerCase().includes(q) ||
          (log.eventType || '').toLowerCase().includes(q) ||
          (log.correlationId || '').toLowerCase().includes(q) ||
          (log.sessionId || '').toLowerCase().includes(q);
        if (!matchesSearch) return false;
      }
      if (userFilter !== 'ALL') {
        const uq = userFilter.toLowerCase();
        if (
          (log.userEmail || '').toLowerCase() !== uq &&
          (log.actorId || '').toLowerCase() !== uq
        ) {
          return false;
        }
      }
      if (eventTypeFilter !== 'ALL') {
        if ((log.eventType || log.action) !== eventTypeFilter) return false;
      }
      if (severityFilter !== 'ALL') {
        if ((log.severity || 'LOW').toUpperCase() !== severityFilter) return false;
      }
      if (outcomeFilter !== 'ALL') {
        if ((log.outcome || 'SUCCESS').toUpperCase() !== outcomeFilter) return false;
      }
      if (dateFrom) {
        const fromMs = new Date(dateFrom).getTime();
        if (!isNaN(fromMs) && new Date(log.timestamp).getTime() < fromMs) return false;
      }
      if (dateTo) {
        const toMs = new Date(dateTo).getTime() + 86399999;
        if (!isNaN(toMs) && new Date(log.timestamp).getTime() > toMs) return false;
      }
      return true;
    });
  }, [allAuditLogs, filterQuery, userFilter, eventTypeFilter, severityFilter, outcomeFilter, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filteredLogs.length / pageSize));
  const paginatedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredLogs.slice(start, start + pageSize);
  }, [filteredLogs, currentPage, pageSize]);

  // Reset pagination when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filterQuery, userFilter, eventTypeFilter, severityFilter, outcomeFilter, dateFrom, dateTo]);

  const handleExportLogs = () => {
    const headers = [
      'Timestamp',
      'Event Type',
      'Severity',
      'Outcome',
      'Actor Email',
      'Actor Name',
      'Role',
      'Action',
      'Module',
      'IP Address',
      'Safe Session ID',
      'Correlation ID',
      'Integrity Hash',
      'Details',
    ];
    const rows = filteredLogs.map((l) => [
      `"${l.timestamp}"`,
      `"${l.eventType || l.action}"`,
      `"${l.severity || 'LOW'}"`,
      `"${l.outcome || 'SUCCESS'}"`,
      `"${l.userEmail || ''}"`,
      `"${(l.userName || '').replace(/"/g, '""')}"`,
      `"${l.userRole || ''}"`,
      `"${(l.action || '').replace(/"/g, '""')}"`,
      `"${(l.module || '').replace(/"/g, '""')}"`,
      `"${l.ipAddress || ''}"`,
      `"${l.sessionId || ''}"`,
      `"${l.correlationId || ''}"`,
      `"${l.integrityHash || ''}"`,
      `"${(l.details || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `CMMS_Security_Audit_Trail_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleRevokeSingleSession = async () => {
    if (!confirmRevokeSession) return;
    setRevokingSessionId(confirmRevokeSession.sessionId);
    setBannerMessage(null);
    try {
      const res = await fetch(`/api/audit/sessions/${encodeURIComponent(confirmRevokeSession.sessionId)}/revoke`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ reason: revokeReason }),
      });
      const data = await res.json();
      if (!res.ok) {
        setBannerMessage({ type: 'error', text: data.message || data.error || 'Failed to revoke session.' });
      } else {
        setBannerMessage({ type: 'success', text: data.message || 'Session revoked immediately.' });
        setConfirmRevokeSession(null);
        await fetchSecurityDashboard();
        await refreshFromBackend();
      }
    } catch (err: any) {
      setBannerMessage({ type: 'error', text: err?.message || 'Network error while revoking session.' });
    } finally {
      setRevokingSessionId(null);
    }
  };

  const handleRevokeAllUserSessions = async (userId: string, userEmail: string) => {
    setRevokingSessionId(userId);
    setBannerMessage(null);
    try {
      const res = await fetch(`/api/auth/users/${encodeURIComponent(userId)}/revoke-sessions`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json();
      if (!res.ok) {
        setBannerMessage({ type: 'error', text: data.message || data.error || 'Failed to revoke user sessions.' });
      } else {
        setBannerMessage({
          type: 'success',
          text: data.message || `All active sessions for ${userEmail} have been revoked.`,
        });
        await fetchSecurityDashboard();
        await refreshFromBackend();
      }
    } catch (err: any) {
      setBannerMessage({ type: 'error', text: err?.message || 'Error revoking user sessions.' });
    } finally {
      setRevokingSessionId(null);
    }
  };

  const handleUpdateAlertStatus = async (alertId: string, status: 'ACKNOWLEDGED' | 'RESOLVED') => {
    setBannerMessage(null);
    try {
      const res = await fetch(`/api/audit/alerts/${encodeURIComponent(alertId)}/status`, {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (res.ok) {
        setBannerMessage({ type: 'success', text: `Security alert marked as ${status}.` });
        await fetchSecurityDashboard();
        await refreshFromBackend();
      } else {
        setBannerMessage({ type: 'error', text: data.message || 'Failed to update alert status.' });
      }
    } catch (err: any) {
      setBannerMessage({ type: 'error', text: err?.message || 'Error updating alert.' });
    }
  };

  const handleVerifyIntegrity = async () => {
    setVerifyingIntegrity(true);
    setBannerMessage(null);
    try {
      const res = await fetch('/api/audit/verify-integrity', {
        method: 'POST',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json();
      if (res.ok && data.integrity) {
        setBannerMessage({
          type: data.integrity.verified ? 'success' : 'error',
          text: data.integrity.verified
            ? `SHA-256 Tamper-Evident Audit Chain Verified Intact (${data.integrity.chainedRecords} chained records across ${data.integrity.totalRecords} total entries).`
            : `Audit chain verification failed at record ${data.integrity.brokenAtRecordId}.`,
        });
        await fetchSecurityDashboard();
        await refreshFromBackend();
      }
    } catch (err: any) {
      setBannerMessage({ type: 'error', text: err?.message || 'Failed to verify audit integrity.' });
    } finally {
      setVerifyingIntegrity(false);
    }
  };

  const handleSaveSecurityConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isSystemAdmin) return;
    setSavingConfig(true);
    setBannerMessage(null);
    try {
      const res = await fetch('/api/system/security-governance', {
        method: 'PUT',
        headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(configForm),
      });
      const data = await res.json();
      if (res.ok) {
        setBannerMessage({ type: 'success', text: data.message || 'Security configuration saved and enforced.' });
        await fetchSecurityDashboard();
        await refreshFromBackend();
      } else {
        setBannerMessage({ type: 'error', text: data.error || data.message || 'Failed to update security configuration.' });
      }
    } catch (err: any) {
      setBannerMessage({ type: 'error', text: err?.message || 'Error saving security policy.' });
    } finally {
      setSavingConfig(false);
    }
  };

  const handleAuthorizedRoleChange = async (userId: string, userEmail: string, nextRole: UserRole) => {
    setUpdatingUserId(userId);
    setBannerMessage(null);
    try {
      await updateUserRole(userId, nextRole);
      setBannerMessage({
        type: 'success',
        text: `Role updated to ${nextRole} for ${userEmail} and recorded in security audit trail.`,
      });
      await fetchSecurityDashboard();
      await refreshFromBackend();
    } catch (err: any) {
      setBannerMessage({
        type: 'error',
        text: err?.message || 'Failed to update role.',
      });
    } finally {
      setUpdatingUserId(null);
    }
  };

  const overview = dashboardData?.overview || {
    totalAuditEvents: allAuditLogs.length,
    failedLogins24h: 0,
    failedLogins7d: 0,
    successfulLogins24h: 0,
    blockedRequests24h: 0,
    activeSessionsCount: 0,
    revokedSessionsCount: 0,
    openAlertsCount: 0,
    privilegedAccountsCount: systemUsers.length,
    staffMfaCoveragePercent: 0,
    configWarnings: [],
  };

  const sessionsList: any[] = useMemo(() => {
    const raw = dashboardData?.sessions || [];
    return raw.filter((s: any) => {
      if (sessionStatusFilter !== 'ALL' && s.status !== sessionStatusFilter) return false;
      if (sessionSearch.trim()) {
        const q = sessionSearch.toLowerCase();
        const match =
          (s.userEmail || '').toLowerCase().includes(q) ||
          (s.userName || '').toLowerCase().includes(q) ||
          (s.sessionId || '').toLowerCase().includes(q) ||
          (s.ipAddress || '').toLowerCase().includes(q) ||
          (s.device || '').toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [dashboardData?.sessions, sessionStatusFilter, sessionSearch]);

  const alertsList: any[] = dashboardData?.alerts || [];
  const rolesCatalog: any[] = dashboardData?.rbac?.rolesCatalog || [];
  const privilegedAccounts: any[] = dashboardData?.rbac?.privilegedAccounts || systemUsers;
  const secConfig = dashboardData?.securityConfig || {};
  // Never default integrity.verified to true before backend verification responds
  const integrity = dashboardData?.integrity || {
    verified: false,
    unverifiedLoad: true,
    totalRecords: allAuditLogs.length,
    chainedRecords: 0,
    legacyUnchainedRecords: 0,
  };

  const getSeverityBadge = (sev?: string) => {
    const s = (sev || 'LOW').toUpperCase();
    if (s === 'CRITICAL')
      return 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 border border-rose-300 dark:border-rose-800';
    if (s === 'HIGH')
      return 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800';
    if (s === 'MEDIUM')
      return 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300 border border-blue-300 dark:border-blue-800';
    return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300';
  };

  const getOutcomeBadge = (out?: string) => {
    const o = (out || 'SUCCESS').toUpperCase();
    if (o === 'BLOCKED') return 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300';
    if (o === 'FAILURE') return 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300';
    if (o === 'WARNING') return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-950/80 dark:text-yellow-300';
    return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300';
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <ShieldCheck className="w-6 h-6 text-emerald-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Centralized Security, Session Governance & Tamper-Evident Audit Center
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200">
              Backend-Enforced RBAC
            </span>
            {integrity.verified ? (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-200 flex items-center gap-1">
                <FileCheck className="w-3.5 h-3.5" />
                SHA-256 Chain Verified ({integrity.chainedRecords} chained
                {integrity.legacyUnchainedRecords > 0 ? `, ${integrity.legacyUnchainedRecords} legacy flagged` : ''})
              </span>
            ) : integrity.unverifiedLoad ? (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Integrity Pending Backend Verification
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200 flex items-center gap-1">
                <AlertOctagon className="w-3.5 h-3.5" />
                Audit Chain Integrity Failed ({integrity.brokenAtRecordId || 'Tamper Detected'})
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time backend security telemetry, active session revocation, multi-role RBAC enforcement, anomaly alerts, and append-only audit logs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <ActionMenu
            primaryAction={{
              id: 'verify-chain',
              label: verifyingIntegrity ? 'Verifying Chain...' : 'Verify Audit Integrity',
              icon: <Fingerprint className="w-3.5 h-3.5" />,
              disabled: verifyingIntegrity,
              onClick: handleVerifyIntegrity,
            }}
            secondaryActions={[
              {
                id: 'refresh-telemetry',
                label: 'Refresh Telemetry',
                icon: <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />,
                disabled: loading,
                onClick: fetchSecurityDashboard,
              },
              {
                id: 'export-audit-csv',
                label: 'Export Audit CSV',
                icon: <Download className="w-3.5 h-3.5 text-emerald-600" />,
                onClick: handleExportLogs,
              },
            ]}
          />
        </div>
      </div>

      {/* Status Notification Banner */}
      {bannerMessage && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between text-xs font-semibold ${
            bannerMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/60 dark:border-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 border-rose-200 text-rose-800 dark:bg-rose-950/60 dark:border-rose-800 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {bannerMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0" />
            )}
            <span>{bannerMessage.text}</span>
          </div>
          <button onClick={() => setBannerMessage(null)} className="p-1 hover:opacity-75">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800">
        {[
          { id: 'overview', label: 'Security Overview', icon: Activity },
          { id: 'rbac', label: 'User Access & RBAC', icon: Users },
          { id: 'sessions', label: `Sessions & Devices (${overview.activeSessionsCount})`, icon: Laptop },
          { id: 'audit', label: `Security Audit Trail (${allAuditLogs.length})`, icon: Terminal },
          { id: 'alerts', label: `Security Alerts (${overview.openAlertsCount})`, icon: ShieldAlert },
          { id: 'config', label: 'Security Configuration', icon: Sliders },
        ].map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as DashboardTab)}
              className={`min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* =====================================================================
          TAB 1: SECURITY OVERVIEW
         ===================================================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Top KPI Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Failed Logins (24h / 7d)
                </span>
                <AlertOctagon className="w-4 h-4 text-rose-500" />
              </div>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {overview.failedLogins24h}{' '}
                <span className="text-xs font-normal text-slate-400">/ {overview.failedLogins7d} (7d)</span>
              </p>
              <p className="text-[11px] text-slate-500">
                Successful logins (24h): <strong className="text-emerald-600">{overview.successfulLogins24h}</strong>
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Active / Revoked Sessions
                </span>
                <Laptop className="w-4 h-4 text-blue-500" />
              </div>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {overview.activeSessionsCount}{' '}
                <span className="text-xs font-normal text-slate-400">
                  active ({overview.revokedSessionsCount} revoked)
                </span>
              </p>
              <p className="text-[11px] text-slate-500">
                Tracked via non-reversible SHA-256 session fingerprints
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Blocked Requests & Alerts
                </span>
                <ShieldAlert className="w-4 h-4 text-amber-500" />
              </div>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {overview.blockedRequests24h}{' '}
                <span className="text-xs font-normal text-amber-600">
                  ({overview.openAlertsCount} open alerts)
                </span>
              </p>
              <p className="text-[11px] text-slate-500">
                Unauthorized RBAC, invalid tokens & rate-limit blocks
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  Privileged Staff 2FA Coverage
                </span>
                <Key className="w-4 h-4 text-emerald-500" />
              </div>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {overview.staffMfaCoveragePercent}%
              </p>
              <p className="text-[11px] text-slate-500">
                Across {overview.privilegedAccountsCount} staff & leadership accounts
              </p>
            </div>
          </div>

          {/* Authentication Status & Architecture Card */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                <Server className="w-4 h-4 text-blue-600" />
                <span>Authentication & Session Enforcement Architecture</span>
              </div>
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Primary Auth Provider:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {overview.authArchitecture?.provider || 'Supabase Auth + Authoritative Backend RBAC'}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Audit & Session Storage:</span>
                  <span className="font-bold text-blue-600 dark:text-blue-400">
                    {overview.authArchitecture?.storageEngine || 'Durable Atomic Snapshot + PostgreSQL Migration 024'}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Session Transport:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {overview.authArchitecture?.tokenTransport || 'Bearer Token + HttpOnly SameSite=Lax Cookies'}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">CSRF Protection:</span>
                  <span className="font-bold text-emerald-600">
                    {overview.authArchitecture?.csrfProtection || 'Double-Submit X-CSRF-Token Verified'}
                  </span>
                </div>
                <div className="py-2">
                  <span className="text-slate-500 block mb-1">Revocation Guarantee:</span>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl">
                    {overview.authArchitecture?.sessionRevocationMechanism ||
                      'Immediate server-side SHA-256 token hash revocation list combined with per-user session_revoked_at timestamp validation.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Configuration Warnings */}
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <span>Live Security Configuration Warnings</span>
                </div>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  {(overview.configWarnings || []).length} Warning(s)
                </span>
              </div>

              {(overview.configWarnings || []).length === 0 ? (
                <div className="p-6 text-center bg-emerald-50/50 dark:bg-emerald-950/20 rounded-xl border border-emerald-200/60 dark:border-emerald-900/40">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                  <p className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                    All Security Policies & Audit Integrity Checks Passed
                  </p>
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-1">
                    No active configuration warnings detected across authentication, cookies, or audit retention.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {(overview.configWarnings || []).map((w: any) => (
                    <div
                      key={w.id}
                      className="p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/60 dark:bg-amber-950/30 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-900 dark:text-amber-200">{w.title}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${getSeverityBadge(w.severity)}`}>
                          {w.severity}
                        </span>
                      </div>
                      <p className="text-[11px] text-amber-800 dark:text-amber-300/90">{w.recommendation}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recent Security Events & Alerts */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-600" />
                Recent Security Events (Live Stream)
              </h2>
              <button
                onClick={() => setActiveTab('audit')}
                className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
              >
                View Full Audit Trail →
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 bg-slate-50 dark:bg-slate-800/50">
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Event / Action</th>
                    <th className="p-3">Actor</th>
                    <th className="p-3">Severity</th>
                    <th className="p-3">Outcome</th>
                    <th className="p-3">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {allAuditLogs.slice(0, 8).map((log, i) => (
                    <tr key={log.id || i} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">{log.timestamp}</td>
                      <td className="p-3">
                        <span className="font-bold text-slate-900 dark:text-white block">{log.action}</span>
                        <span className="text-[10px] font-mono text-slate-400">{log.eventType || log.module}</span>
                      </td>
                      <td className="p-3">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 block">{log.userName}</span>
                        <span className="text-[10px] font-mono text-slate-400">{log.userEmail}</span>
                      </td>
                      <td className="p-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${getSeverityBadge(log.severity)}`}>
                          {log.severity || 'LOW'}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${getOutcomeBadge(log.outcome)}`}>
                          {log.outcome || 'SUCCESS'}
                        </span>
                      </td>
                      <td className="p-3 max-w-md truncate text-slate-600 dark:text-slate-300">{log.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 2: USER ACCESS & RBAC
         ===================================================================== */}
      {activeTab === 'rbac' && (
        <div className="space-y-6">
          {/* Role Definitions & Permission Matrix */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-blue-600" />
              Authoritative Role Hierarchy & Server-Enforced Permissions
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {(rolesCatalog.length > 0
                ? rolesCatalog
                : [
                    { code: 'SYSTEM_ADMIN', name: 'System Admin', level: 100, description: 'Full multi-campus & security authority' },
                    { code: 'MANAGER', name: 'Executive Manager', level: 80, description: 'Operations, HR, branches & workflows' },
                    { code: 'PASTOR', name: 'Ordained Pastor', level: 70, description: 'Pastoral counseling, care & visitations' },
                    { code: 'MINISTRY_LEADER', name: 'Ministry Leader', level: 50, description: 'Departmental events, attendance & groups' },
                    { code: 'REGULAR_MEMBER', name: 'Regular Member', level: 10, description: 'Personal profile, Bible & devotions' },
                  ]
              ).map((r: any) => {
                const perms: string[] = dashboardData?.rbac?.rolePermissions?.[r.code] || [];
                return (
                  <div
                    key={r.code}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold text-blue-600 dark:text-blue-400">{r.code}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                        Lvl {r.level}
                      </span>
                    </div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">{r.name}</p>
                    <p className="text-[11px] text-slate-500 leading-snug">{r.description}</p>
                    <div className="pt-2 border-t border-slate-200/70 dark:border-slate-700/70">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1">
                        {perms.length} Granted Permissions
                      </span>
                      <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                        {perms.slice(0, 8).map((p) => (
                          <span
                            key={p}
                            className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                          >
                            {p}
                          </span>
                        ))}
                        {perms.length > 8 && (
                          <span className="text-[9px] font-bold text-blue-600">+{perms.length - 8} more</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Privileged Accounts & Authorized Role Changes */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  Privileged Accounts & Authorized Role Governance
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Role changes are validated on the server against privilege escalation and recorded in the security audit trail.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 bg-slate-50 dark:bg-slate-800/50">
                    <th className="p-3">Account</th>
                    <th className="p-3">Primary & Additional Roles</th>
                    <th className="p-3">Campus Scope</th>
                    <th className="p-3">2FA / MFA Status</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Authorized Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {privilegedAccounts.map((u: any) => {
                    const currentRole: UserRole = selectedRoleMap[u.id] || u.role;
                    const mfaActive = Boolean(u.mfaEnabled || u.isMfaEnabled || u.mfa_enabled);
                    return (
                      <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="p-3">
                          <p className="font-bold text-slate-900 dark:text-white">{u.name}</p>
                          <p className="text-[11px] font-mono text-slate-400">{u.email}</p>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-200 font-bold text-[10px]">
                            {u.role}
                          </span>
                          {Array.isArray(u.additionalRoles) &&
                            u.additionalRoles.map((ar: string) => (
                              <span
                                key={ar}
                                className="ml-1 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-[10px]"
                              >
                                +{ar}
                              </span>
                            ))}
                        </td>
                        <td className="p-3 text-slate-600 dark:text-slate-300">
                          {(u.assignedCampuses || [u.branchName || 'Headquarters Campus']).join(', ')}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              mfaActive
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            }`}
                          >
                            {mfaActive ? 'AAL2 TOTP Enabled' : 'MFA Disabled'}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                            {u.status || 'Active'}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          {isSystemAdmin ? (
                            <div className="inline-flex items-center gap-2">
                              <select
                                value={currentRole}
                                onChange={(e) =>
                                  setSelectedRoleMap((prev) => ({
                                    ...prev,
                                    [u.id]: e.target.value as UserRole,
                                  }))
                                }
                                className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                              >
                                <option value="SYSTEM_ADMIN">SYSTEM_ADMIN</option>
                                <option value="MANAGER">MANAGER</option>
                                <option value="PASTOR">PASTOR</option>
                                <option value="MINISTRY_LEADER">MINISTRY_LEADER</option>
                                <option value="REGULAR_MEMBER">REGULAR_MEMBER</option>
                              </select>
                              <button
                                onClick={() => handleAuthorizedRoleChange(u.id, u.email, currentRole)}
                                disabled={updatingUserId === u.id || currentRole === u.role}
                                className="px-3 py-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-lg text-[11px] font-bold cursor-pointer"
                              >
                                {updatingUserId === u.id ? 'Saving...' : 'Update Role'}
                              </button>
                              <button
                                onClick={() => handleRevokeAllUserSessions(u.id, u.email)}
                                disabled={revokingSessionId === u.id}
                                className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 rounded-lg text-[11px] font-bold cursor-pointer"
                                title="Revoke all sessions for this user"
                              >
                                Revoke Sessions
                              </button>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400">Read-Only (SYSTEM_ADMIN required)</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: SESSIONS & DEVICES
         ===================================================================== */}
      {activeTab === 'sessions' && (
        <div className="space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-blue-600" />
                  Tracked Sessions & Device Fingerprints
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Revoking a session immediately blacklists its SHA-256 token hash on the backend and invalidates the user session.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="text"
                  value={sessionSearch}
                  onChange={(e) => setSessionSearch(e.target.value)}
                  placeholder="Search user, IP, device, session ID..."
                  className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
                <select
                  value={sessionStatusFilter}
                  onChange={(e) => setSessionStatusFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="ACTIVE">Active Only</option>
                  <option value="REVOKED">Revoked Only</option>
                  <option value="EXPIRED">Expired Only</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 bg-slate-50 dark:bg-slate-800/50">
                    <th className="p-3">Safe Session ID</th>
                    <th className="p-3">User & Role</th>
                    <th className="p-3">Device & IP</th>
                    <th className="p-3">Login Time</th>
                    <th className="p-3">Last Activity</th>
                    <th className="p-3">Expires At</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {sessionsList.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-400">
                        No tracked sessions match the current filter.
                      </td>
                    </tr>
                  ) : (
                    sessionsList.map((s: any) => (
                      <tr key={s.sessionId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-mono text-[11px] text-blue-600 dark:text-blue-400 font-bold">
                          {s.sessionId}
                          <span className="block text-[9px] text-slate-400 uppercase">{s.aal || 'aal1'}</span>
                        </td>
                        <td className="p-3">
                          <span className="font-bold text-slate-900 dark:text-white block">{s.userName}</span>
                          <span className="text-[10px] font-mono text-slate-400">{s.userEmail}</span>
                          <span className="ml-1 text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-bold">
                            {s.userRole}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="font-semibold text-slate-700 dark:text-slate-300 block">{s.device}</span>
                          <span className="text-[10px] font-mono text-slate-400">IP: {s.ipAddress}</span>
                        </td>
                        <td className="p-3 font-mono text-[11px] text-slate-500">{s.loginTime}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-500">{s.lastActivity}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-500">{s.expiresAt}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              s.status === 'ACTIVE'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : s.status === 'REVOKED'
                                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                  : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                            }`}
                          >
                            {s.status}
                          </span>
                          {s.revokedBy && (
                            <span className="block text-[9px] text-rose-500 mt-0.5">
                              by {s.revokedBy}
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right">
                          {s.status === 'ACTIVE' && isSystemAdmin ? (
                            <button
                              onClick={() => setConfirmRevokeSession(s)}
                              className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <LogOut className="w-3 h-3" />
                              Revoke
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-400">—</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 4: SECURITY AUDIT TRAIL
         ===================================================================== */}
      {activeTab === 'audit' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          {/* Multi-Dimension Search & Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
            <div className="relative lg:col-span-2">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="Search actor, action, IP, session ID, correlation ID..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <select
              value={eventTypeFilter}
              onChange={(e) => setEventTypeFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            >
              <option value="ALL">All Event Types</option>
              {distinctEventTypes.map((et) => (
                <option key={et} value={et}>
                  {et}
                </option>
              ))}
            </select>

            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            >
              <option value="ALL">All Severities</option>
              <option value="CRITICAL">CRITICAL</option>
              <option value="HIGH">HIGH</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="LOW">LOW</option>
            </select>

            <select
              value={outcomeFilter}
              onChange={(e) => setOutcomeFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            >
              <option value="ALL">All Outcomes</option>
              <option value="SUCCESS">SUCCESS</option>
              <option value="FAILURE">FAILURE</option>
              <option value="BLOCKED">BLOCKED</option>
              <option value="WARNING">WARNING</option>
            </select>

            <div className="flex items-center gap-1">
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-full px-2 py-2 text-[11px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                title="From Date"
              />
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-full px-2 py-2 text-[11px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                title="To Date"
              />
            </div>
          </div>

          {/* Audit Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 bg-slate-50 dark:bg-slate-800/50">
                  <th className="p-3">Timestamp (UTC)</th>
                  <th className="p-3">Actor / Role</th>
                  <th className="p-3">Event & Module</th>
                  <th className="p-3">Severity & Outcome</th>
                  <th className="p-3">Session / IP</th>
                  <th className="p-3">Redacted Audit Details</th>
                  <th className="p-3 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {paginatedLogs.map((log, idx) => (
                  <tr key={log.id ? `${log.id}-${idx}` : `log-${idx}`} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="p-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">{log.timestamp}</td>
                    <td className="p-3">
                      <p className="font-semibold text-slate-900 dark:text-white">{log.userName || log.userEmail}</p>
                      <p className="text-[10px] font-mono text-slate-400">{log.userEmail}</p>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 font-bold inline-block mt-0.5">
                        {log.userRole}
                      </span>
                    </td>
                    <td className="p-3">
                      <p className="font-bold text-slate-900 dark:text-white">{log.action}</p>
                      <p className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400">
                        {log.eventType || log.module}
                      </p>
                    </td>
                    <td className="p-3 space-y-1">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded inline-block mr-1 ${getSeverityBadge(log.severity)}`}>
                        {log.severity || 'LOW'}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded inline-block ${getOutcomeBadge(log.outcome)}`}>
                        {log.outcome || 'SUCCESS'}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-[10px] text-slate-500">
                      <span className="block text-slate-700 dark:text-slate-300">{log.sessionId || 'sess_system'}</span>
                      <span>IP: {log.ipAddress}</span>
                    </td>
                    <td className="p-3 max-w-xs text-slate-700 dark:text-slate-300">
                      <p className="line-clamp-2">{log.details}</p>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => setSelectedLog(log)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg text-[11px] font-bold text-slate-700 dark:text-slate-300 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Code className="w-3 h-3 text-blue-500" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500">
            <span>
              Showing {paginatedLogs.length} of {filteredLogs.length} matching security events
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 5: SECURITY ALERTS
         ===================================================================== */}
      {activeTab === 'alerts' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600" />
              Real-Time Anomaly & Security Alert Detection
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Automatically triggered by repeated failed logins, multi-IP credential stuffing, invalid token spikes, refresh-token reuse, and privileged account modifications.
            </p>
          </div>

          {alertsList.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200/70 dark:border-slate-800">
              <ShieldCheck className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-900 dark:text-white">No Active Security Alerts</p>
              <p className="text-xs text-slate-500 mt-1">
                Real-time detectors for brute-force logins, token replay, and unauthorized privilege escalation are active and clear.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {alertsList.map((alert: any) => (
                <div
                  key={alert.id}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${getSeverityBadge(alert.severity)}`}>
                        {alert.severity}
                      </span>
                      <span className="text-xs font-bold text-slate-900 dark:text-white">{alert.title}</span>
                      <span className="text-[10px] font-mono text-slate-400">{alert.timestamp}</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          alert.status === 'OPEN'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}
                      >
                        {alert.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{alert.description}</p>
                    <div className="flex flex-wrap gap-3 text-[10px] font-mono text-slate-400">
                      {alert.actorEmail && <span>Actor: {alert.actorEmail}</span>}
                      {alert.ipAddress && <span>IP: {alert.ipAddress}</span>}
                      <span>Correlation: {alert.correlationId}</span>
                    </div>
                  </div>

                  {isSystemAdmin && alert.status !== 'RESOLVED' && (
                    <div className="flex items-center gap-2 shrink-0">
                      {alert.status === 'OPEN' && (
                        <button
                          onClick={() => handleUpdateAlertStatus(alert.id, 'ACKNOWLEDGED')}
                          className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold cursor-pointer"
                        >
                          Acknowledge
                        </button>
                      )}
                      <button
                        onClick={() => handleUpdateAlertStatus(alert.id, 'RESOLVED')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold cursor-pointer"
                      >
                        Resolve
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          TAB 6: SECURITY CONFIGURATION
         ===================================================================== */}
      {activeTab === 'config' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Editable Session, Lockout & MFA Governance Policy */}
          <form
            onSubmit={handleSaveSecurityConfig}
            className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4"
          >
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
              <Settings className="w-4 h-4 text-blue-600" />
              <span>Session Lifespan, Lockout & MFA Policy</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Session / JWT Lifespan (Hours)
                </label>
                <input
                  type="number"
                  min={1}
                  max={720}
                  value={configForm.jwtLifespanHours}
                  onChange={(e) => setConfigForm({ ...configForm, jwtLifespanHours: Number(e.target.value) })}
                  disabled={!isSystemAdmin}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Max Failed Login Attempts Before Lockout
                </label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={configForm.lockoutMaxAttempts}
                  onChange={(e) => setConfigForm({ ...configForm, lockoutMaxAttempts: Number(e.target.value) })}
                  disabled={!isSystemAdmin}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Account Lockout Duration (Minutes)
                </label>
                <input
                  type="number"
                  min={1}
                  max={1440}
                  value={configForm.lockoutDurationMinutes}
                  onChange={(e) => setConfigForm({ ...configForm, lockoutDurationMinutes: Number(e.target.value) })}
                  disabled={!isSystemAdmin}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Staff MFA / 2FA Enforcement Mode
                </label>
                <select
                  value={configForm.mfaEnforcementMode}
                  onChange={(e) =>
                    setConfigForm({ ...configForm, mfaEnforcementMode: e.target.value as 'enforced' | 'optional' })
                  }
                  disabled={!isSystemAdmin}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="enforced">Enforced (Require AAL2 TOTP for Staff Roles)</option>
                  <option value="optional">Optional (Per-Account MFA Toggle)</option>
                </select>
              </div>
            </div>

            {isSystemAdmin && (
              <button
                type="submit"
                disabled={savingConfig}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                {savingConfig ? 'Saving Policy...' : 'Save & Enforce Security Policy'}
              </button>
            )}
          </form>

          {/* Cookie Security, Rate Limit Tiers & Audit Retention Status */}
          <div className="space-y-6">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 text-xs">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-600" />
                Cookie Security, Rate-Limit Tiers & Audit Retention
              </h3>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                  <span className="text-[10px] text-slate-400 block">HttpOnly Auth Cookies</span>
                  <span className="font-bold text-emerald-600">Enabled (cmms_access_token)</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                  <span className="text-[10px] text-slate-400 block">SameSite & Secure Policy</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    SameSite=Lax | Secure={secConfig.cookieSecurity?.secureInCurrentEnv ? 'true' : 'Prod-Enforced'}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                  <span className="text-[10px] text-slate-400 block">Audit Trail Retention</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {secConfig.auditRetentionPolicy?.retentionDays || 2555} Days (7 Years Append-Only)
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                  <span className="text-[10px] text-slate-400 block">Tamper Evidence</span>
                  <span className="font-bold text-blue-600">SHA-256 Cryptographic Hash Chain</span>
                </div>
              </div>

              <div className="pt-2">
                <span className="font-bold text-slate-700 dark:text-slate-300 block mb-2">
                  Active Backend Rate-Limiting Policies
                </span>
                <div className="space-y-1.5">
                  {(secConfig.rateLimits || []).map((rl: any) => (
                    <div
                      key={rl.category}
                      className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60"
                    >
                      <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{rl.category}</span>
                      <span className="text-slate-500">
                        Max <strong>{rl.maxRequests}</strong> req / {rl.windowMinutes}m ({rl.scope})
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Session Revocation Confirmation Modal */}
      {confirmRevokeSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-rose-600">
                <ShieldAlert className="w-5 h-5" />
                <h3 className="font-bold text-sm">Confirm Immediate Session Revocation</h3>
              </div>
              <button onClick={() => setConfirmRevokeSession(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs space-y-2 text-slate-600 dark:text-slate-300">
              <p>
                You are about to revoke session{' '}
                <strong className="font-mono text-slate-900 dark:text-white">{confirmRevokeSession.sessionId}</strong> for{' '}
                <strong>{confirmRevokeSession.userEmail}</strong>.
              </p>
              <label className="block font-bold text-slate-700 dark:text-slate-300 pt-2">
                Revocation Reason (Recorded in Audit Trail)
              </label>
              <input
                type="text"
                value={revokeReason}
                onChange={(e) => setRevokeReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmRevokeSession(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleRevokeSingleSession}
                disabled={revokingSessionId === confirmRevokeSession.sessionId}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                {revokingSessionId === confirmRevokeSession.sessionId ? 'Revoking...' : 'Confirm Revocation'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Redacted Audit Event Detail Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Redacted Security Event & Hash Chain Inspection
                </h3>
              </div>
              <button onClick={() => setSelectedLog(null)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Event Type</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">
                  {selectedLog.eventType || selectedLog.action}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Severity & Outcome</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedLog.severity || 'LOW'} / {selectedLog.outcome || 'SUCCESS'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Safe Session ID</span>
                <span className="font-mono text-slate-900 dark:text-white">
                  {selectedLog.sessionId || 'sess_system'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Actor & Role</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedLog.userEmail} ({selectedLog.userRole})
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Correlation ID</span>
                <span className="font-mono text-slate-900 dark:text-white">
                  {selectedLog.correlationId || 'N/A'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <span className="text-slate-400 block text-[10px]">Client IP</span>
                <span className="font-mono text-slate-900 dark:text-white">{selectedLog.ipAddress}</span>
              </div>
            </div>

            {selectedLog.integrityHash && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-[11px] font-mono space-y-1">
                <div>
                  <span className="text-slate-400">Prev Chain Hash: </span>
                  <span className="text-slate-600 dark:text-slate-300 break-all">{selectedLog.prevHash}</span>
                </div>
                <div>
                  <span className="text-slate-400">SHA-256 Integrity Hash: </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold break-all">
                    {selectedLog.integrityHash}
                  </span>
                </div>
              </div>
            )}

            <div>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Sanitized Event Metadata (Credentials & Tokens Redacted)
              </span>
              <pre className="p-4 bg-slate-950 text-emerald-400 rounded-xl text-xs font-mono overflow-x-auto max-h-60">
                {selectedLog.commitData ||
                  JSON.stringify(
                    {
                      id: selectedLog.id,
                      timestamp: selectedLog.timestamp,
                      eventType: selectedLog.eventType || selectedLog.action,
                      actorEmail: selectedLog.userEmail,
                      role: selectedLog.userRole,
                      outcome: selectedLog.outcome || 'SUCCESS',
                      severity: selectedLog.severity || 'LOW',
                      sessionId: selectedLog.sessionId || 'sess_system',
                      details: selectedLog.details,
                    },
                    null,
                    2
                  )}
              </pre>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedLog(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 cursor-pointer"
              >
                Close Inspection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
