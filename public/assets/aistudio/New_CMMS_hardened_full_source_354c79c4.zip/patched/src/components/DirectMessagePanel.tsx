import React, { useState, useEffect, useRef } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useTranslation } from '../i18n/LanguageContext';
import { Conversation, ConversationMessage, Member } from '../types';
import { apiService } from '../services/api';
import { getClientSocket } from '../services/clientSocket';
import { normalizeUserRole } from '../utils/rbac';
import {
  MessageSquare,
  Send,
  Video,
  User,
  Shield,
  Search,
  Lock,
  Phone,
  Clock,
  AlertCircle,
  CheckCircle2,
  X,
} from 'lucide-react';

export interface DirectMessagePanelProps {
  initialMemberId?: string;
  onStartVideoCall?: (conversationId: string, member: Member, roomUrl: string) => void;
}

export const DirectMessagePanel: React.FC<DirectMessagePanelProps> = ({
  initialMemberId,
  onStartVideoCall,
}) => {
  const { currentUser, activeRole, members, ministries } = useCMMS();
  const { t } = useTranslation();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusNotice, setStatusNotice] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentRole = normalizeUserRole(activeRole || currentUser?.role || 'REGULAR_MEMBER');
  const isExecutiveStaff = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'].includes(currentRole);
  const isMinistryLeader = currentRole === 'MINISTRY_LEADER';
  const isStaffTier = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'].includes(currentRole);

  // Determine ministries led by this user
  const myMemberId =
    currentUser?.memberId ||
    members.find((m) => m.email?.toLowerCase() === currentUser?.email?.toLowerCase())?.id;

  const myLedMinistries = ministries.filter(
    (m) =>
      (myMemberId && m.leaderMemberId === myMemberId) ||
      m.leaderMemberId === (currentUser as any)?.id ||
      (Array.isArray((m as any).leaderMemberIds) && (
        (myMemberId && (m as any).leaderMemberIds.includes(myMemberId)) ||
        (m as any).leaderMemberIds.includes((currentUser as any)?.id)
      ))
  );

  // Set of member IDs in led ministries
  const myLedMinistryMemberIds = new Set<string>();
  for (const m of myLedMinistries) {
    if (Array.isArray(m.memberIds)) {
      for (const mid of m.memberIds) {
        if (mid) myLedMinistryMemberIds.add(mid);
      }
    }
  }

  const canStartVideoWithSelectedMember = Boolean(
    selectedMember &&
      selectedMember.id !== myMemberId &&
      selectedMember.id !== (currentUser as any)?.id &&
      (isExecutiveStaff || (isMinistryLeader && myLedMinistryMemberIds.has(selectedMember.id)))
  );

  // Load conversations
  useEffect(() => {
    loadConversations();
  }, []);

  const loadConversations = async () => {
    try {
      setIsLoading(true);
      const res = await apiService.getConversations();
      if (res.success && res.conversations) {
        const directOnly = res.conversations.filter((c) => c.type === 'direct');
        setConversations(directOnly);

        // If initialMemberId provided, find or select
        if (initialMemberId) {
          const target = members.find((m) => m.id === initialMemberId);
          if (target) {
            handleSelectMember(target, directOnly);
          }
        } else if (directOnly.length > 0 && !selectedConversation) {
          handleSelectConversation(directOnly[0]);
        }
      }
    } catch (err) {
      console.warn('Could not load direct conversations:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectMember = async (member: Member, existingConvs = conversations) => {
    setSelectedMember(member);
    setStatusNotice(null);

    // Look for existing conversation with this member
    const existing = existingConvs.find((c) => {
      const parts = c.participants || [];
      return parts.some((p) => p.userId === member.id);
    });

    if (existing) {
      setSelectedConversation(existing);
      loadMessages(existing.id);
    } else {
      // Create new direct conversation if caller is allowed
      try {
        const res = await apiService.createConversation({
          type: 'direct',
          participantIds: [member.id],
        });
        if (res.success && res.conversation) {
          setSelectedConversation(res.conversation);
          setConversations((prev) => [res.conversation, ...prev.filter((c) => c.id !== res.conversation.id)]);
          loadMessages(res.conversation.id);
        }
      } catch (err: any) {
        if (err?.code === 'MEMBER_TO_MEMBER_BLOCKED') {
          setStatusNotice({
            type: 'error',
            text: t(
              'member_to_member_blocked_notice',
              'Direct messaging between regular members is restricted. One participant must be church leadership or pastoral staff.'
            ),
          });
        } else if (err?.code === 'OUTSIDE_LED_MINISTRY') {
          setStatusNotice({
            type: 'error',
            text: t(
              'outside_led_ministry_notice',
              'Ministry leaders may only direct-message or call members of ministries they lead.'
            ),
          });
        } else {
          setStatusNotice({
            type: 'error',
            text: err?.error || t('failed_to_start_conversation', 'Could not open conversation.'),
          });
        }
      }
    }
  };

  const handleSelectConversation = (conv: Conversation) => {
    setSelectedConversation(conv);
    setStatusNotice(null);

    // Find remote participant
    const remotePart = (conv.participants || []).find((p) => p.userId !== currentUser?.memberId);
    if (remotePart) {
      const mem = members.find((m) => m.id === remotePart.userId);
      setSelectedMember(mem || null);
    }
    loadMessages(conv.id);
  };

  const loadMessages = async (convId: string) => {
    try {
      const res = await apiService.getConversationMessages(convId);
      if (res.success && res.messages) {
        setMessages(res.messages);
      }
    } catch (err) {
      console.warn('Could not load messages:', err);
    }
  };

  // Socket listener for new messages
  useEffect(() => {
    const socket = getClientSocket();
    const handleNewMessage = (payload: { conversationId: string; message: ConversationMessage }) => {
      if (selectedConversation && payload.conversationId === selectedConversation.id) {
        setMessages((prev) => [...prev, payload.message]);
      }
    };

    socket.on('conversation:message_received', handleNewMessage);
    return () => {
      socket.off('conversation:message_received', handleNewMessage);
    };
  }, [selectedConversation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !selectedConversation) return;

    const text = messageInput.trim();
    setMessageInput('');
    setIsSending(true);

    try {
      const res = await apiService.sendConversationMessage(selectedConversation.id, text);
      if (res.success && res.message) {
        setMessages((prev) => [...prev, res.message]);
      }
    } catch (err: any) {
      if (err?.code === 'MEMBER_TO_MEMBER_BLOCKED') {
        setStatusNotice({
          type: 'error',
          text: t('member_to_member_blocked_notice', 'Direct messaging between regular members is restricted.'),
        });
      } else if (err?.code === 'OUTSIDE_LED_MINISTRY') {
        setStatusNotice({
          type: 'error',
          text: t(
            'outside_led_ministry_notice',
            'Ministry leaders may only direct-message or call members of ministries they lead.'
          ),
        });
      } else {
        setStatusNotice({
          type: 'error',
          text: err?.error || t('failed_to_send', 'Message sending failed.'),
        });
      }
    } finally {
      setIsSending(false);
    }
  };

  const handleStartVideo = async () => {
    if (!selectedConversation) return;
    setStatusNotice(null);

    try {
      const res = await apiService.startDirectVideoCall(selectedConversation.id);
      if (res.success && res.roomUrl && onStartVideoCall && selectedMember) {
        onStartVideoCall(selectedConversation.id, selectedMember, res.roomUrl);
      }
    } catch (err: any) {
      if (err?.code === 'MEMBER_TO_MEMBER_BLOCKED') {
        setStatusNotice({
          type: 'error',
          text: t(
            'member_to_member_blocked_video',
            'Direct video calls between regular members are restricted. One participant must be a staff member or ministry leader.'
          ),
        });
      } else if (err?.code === 'OUTSIDE_LED_MINISTRY') {
        setStatusNotice({
          type: 'error',
          text: t(
            'outside_led_ministry_video',
            'Ministry leaders may only direct-message or call members of ministries they lead.'
          ),
        });
      } else {
        setStatusNotice({
          type: 'error',
          text: err?.error || t('failed_to_start_video', 'Could not initiate video call.'),
        });
      }
    }
  };

  const filteredMembers = members.filter((m) => {
    if (m.id === myMemberId || m.id === currentUser?.memberId || m.id === (currentUser as any)?.id) return false;

    // For MINISTRY_LEADER: only show members who appear in memberIds of a led Ministry
    if (isMinistryLeader && !myLedMinistryMemberIds.has(m.id)) {
      return false;
    }

    const name = `${m.firstName} ${m.lastName}`.toLowerCase();
    const q = searchQuery.toLowerCase();
    return name.includes(q) || (m.email && m.email.toLowerCase().includes(q));
  });

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col md:flex-row h-[720px]">
      {/* Sidebar: Conversations & Member Directory */}
      <div className="w-full md:w-80 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800 flex flex-col bg-slate-50/50 dark:bg-slate-900/50">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>{t('direct_chats', '1:1 Direct Messages')}</span>
            </h3>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300">
              {conversations.length}
            </span>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t('search_members', 'Search member directory...')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8.5 pr-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Member Directory / Conversation List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 p-2 space-y-1">
          {searchQuery ? (
            <div>
              <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {t('directory_results', 'Directory Results')}
              </div>
              {filteredMembers.slice(0, 10).map((mem) => (
                <button
                  key={mem.id}
                  onClick={() => handleSelectMember(mem)}
                  className="w-full min-h-[44px] p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-3 transition-all text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0 font-bold text-xs">
                    {mem.firstName[0]}
                    {mem.lastName[0]}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {mem.firstName} {mem.lastName}
                    </p>
                    <p className="text-[10px] text-slate-500 truncate">{mem.membershipStatus || 'Member'}</p>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div>
              {conversations.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 space-y-1">
                  <p>{t('no_direct_chats', 'No direct conversations yet.')}</p>
                  <p className="text-[11px] text-slate-500">
                    {t('search_above', 'Search directory above to start messaging.')}
                  </p>
                </div>
              ) : (
                conversations.map((conv) => {
                  const isSelected = selectedConversation?.id === conv.id;
                  const remote = (conv.participants || []).find((p) => p.userId !== currentUser?.memberId);
                  const mem = members.find((m) => m.id === remote?.userId);
                  const name = mem ? `${mem.firstName} ${mem.lastName}` : remote?.userName || t('member', 'Member');

                  return (
                    <button
                      key={conv.id}
                      onClick={() => handleSelectConversation(conv)}
                      className={`w-full min-h-[44px] p-3 rounded-2xl flex items-center gap-3 transition-all text-left cursor-pointer ${
                        isSelected
                          ? 'bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800'
                          : 'hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent'
                      }`}
                    >
                      <div className="w-10 h-10 rounded-2xl bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 font-bold text-xs shrink-0">
                        {name.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{name}</p>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate">
                          {conv.lastMessage?.body || t('start_chatting', 'Click to chat')}
                        </p>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Conversation Thread */}
      <div className="flex-1 flex flex-col bg-white dark:bg-slate-900">
        {selectedConversation ? (
          <>
            {/* Conversation Header */}
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-600/10 dark:bg-blue-600/20 text-blue-600 flex items-center justify-center font-bold text-sm">
                  {selectedMember
                    ? `${selectedMember.firstName[0]}${selectedMember.lastName[0]}`
                    : '1:1'}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>
                      {selectedMember
                        ? `${selectedMember.title || ''} ${selectedMember.firstName} ${selectedMember.lastName}`
                        : t('direct_chat', 'Direct Conversation')}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {selectedMember?.membershipStatus || 'Verified Member'}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                    <Lock className="w-3 h-3 text-emerald-500" />
                    <span>{t('staff_member_confidential', 'Confidential staff-member channel')}</span>
                  </p>
                </div>
              </div>

              {/* Action: Start Private Video Call (44px touch target) */}
              {canStartVideoWithSelectedMember && (
                <button
                  onClick={handleStartVideo}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
                  title={t('start_private_video_call', 'Start Private Video Call')}
                >
                  <Video className="w-4 h-4" />
                  <span className="hidden sm:inline">{t('start_private_video_call', 'Start Private Video Call')}</span>
                </button>
              )}
            </div>

            {/* Error / Notice Banner */}
            {statusNotice && (
              <div
                className={`px-4 py-3 text-xs flex items-center justify-between gap-2 border-b ${
                  statusNotice.type === 'error'
                    ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{statusNotice.text}</span>
                </div>
                <button
                  onClick={() => setStatusNotice(null)}
                  className="min-h-[32px] min-w-[32px] p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Message Thread History */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400 space-y-2">
                  <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-semibold text-slate-500">
                    {t('no_messages_yet', 'No messages in this direct conversation yet.')}
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-xs">
                    {t(
                      'direct_messaging_help',
                      'Direct messages and 1:1 video counseling are private between staff and this member.'
                    )}
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isOwn =
                    msg.senderId === currentUser?.memberId ||
                    msg.senderId === (currentUser as any)?.id ||
                    msg.senderId === currentUser?.email;
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}
                    >
                      <div className="flex items-center gap-1.5 mb-1 px-1">
                        <span className="text-[10px] font-bold text-slate-500">
                          {isOwn ? t('you', 'You') : msg.senderName}
                        </span>
                        {msg.senderRole && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                            {msg.senderRole}
                          </span>
                        )}
                        <span className="text-[9px] text-slate-400">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div
                        className={`max-w-md px-4 py-2.5 rounded-2xl text-xs ${
                          isOwn
                            ? 'bg-blue-600 text-white rounded-tr-none'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-tl-none border border-slate-200 dark:border-slate-700/60'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.body}</p>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input Footer */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder={t('type_direct_message', 'Type confidential direct message...')}
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none min-h-[44px]"
              />
              <button
                type="submit"
                disabled={isSending || !messageInput.trim()}
                className="min-h-[44px] min-w-[44px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">{t('send', 'Send')}</span>
              </button>
            </form>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400 space-y-3">
            <div className="w-16 h-16 rounded-3xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center">
              <MessageSquare className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {t('select_or_start_chat', 'Select or Start a Direct Conversation')}
              </h4>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                {t(
                  'select_chat_instruction',
                  'Pick an existing conversation from the left or search the member directory to begin confidential 1:1 chat or initiate video counseling.'
                )}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
