import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Radio, RefreshCw, AlertCircle, CheckCircle2, Wifi, WifiOff } from 'lucide-react';

export type RealtimeHealthStatus = 'CONNECTING' | 'SUBSCRIBED' | 'TIMED_OUT' | 'CLOSED' | 'CHANNEL_ERROR' | string;

export interface RealtimeConnectionIndicatorProps {
  variant?: 'inline' | 'badge' | 'detailed' | 'pill' | 'text-only';
  showDetails?: boolean;
  className?: string;
  channelName?: string;
  tableName?: string;
}

/**
 * Custom hook to monitor Supabase Realtime Database channel health
 */
export function useRealtimeConnectionStatus(channelName = 'system-realtime-health', tableName = 'notifications') {
  const [realtimeStatus, setRealtimeStatus] = useState<RealtimeHealthStatus>('CONNECTING');
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [retryKey, setRetryKey] = useState<number>(0);

  useEffect(() => {
    let isSubscribed = true;
    setRealtimeStatus('CONNECTING');

    const uniqueChannel = `${channelName}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase
      .channel(uniqueChannel)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: tableName,
        },
        () => {
          // Heartbeat / event trigger handler
          if (isSubscribed) {
            setLastUpdated(new Date());
          }
        }
      )
      .subscribe((status) => {
        if (isSubscribed) {
          setRealtimeStatus(status);
          setLastUpdated(new Date());
        }
      });

    return () => {
      isSubscribed = false;
      supabase.removeChannel(channel);
    };
  }, [channelName, tableName, retryKey]);

  const reconnect = () => {
    setRealtimeStatus('CONNECTING');
    setRetryKey((k) => k + 1);
  };

  return { realtimeStatus, lastUpdated, reconnect };
}

/**
 * RealtimeConnectionIndicator Component
 * Displays live Supabase connection health status with visual indicators
 */
export const RealtimeConnectionIndicator: React.FC<RealtimeConnectionIndicatorProps> = ({
  variant = 'badge',
  showDetails = false,
  className = '',
  channelName = 'system-realtime-health',
  tableName = 'notifications',
}) => {
  const { realtimeStatus, lastUpdated, reconnect } = useRealtimeConnectionStatus(channelName, tableName);

  // Variant: text-only (Exact literal requested span output)
  if (variant === 'text-only') {
    return (
      <span className={`inline-flex items-center gap-1 text-xs font-semibold ${className}`}>
        {realtimeStatus === 'SUBSCRIBED' && <span>🟢 Realtime Connected</span>}
        {realtimeStatus === 'CONNECTING' && <span>🟡 Connecting...</span>}
        {(realtimeStatus === 'CHANNEL_ERROR' || realtimeStatus === 'TIMED_OUT' || realtimeStatus === 'CLOSED') && (
          <span>🔴 Realtime Error</span>
        )}
      </span>
    );
  }

  // Variant: pill (Compact rounded badge with emoji indicator)
  if (variant === 'pill') {
    return (
      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold transition-all shadow-2xs ${className} ${
        realtimeStatus === 'SUBSCRIBED'
          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/80'
          : realtimeStatus === 'CONNECTING'
          ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/80'
          : 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800/80'
      }`}>
        {realtimeStatus === 'SUBSCRIBED' && (
          <>
            <span className="text-xs">🟢</span>
            <span className="whitespace-nowrap">Realtime Connected</span>
          </>
        )}
        {realtimeStatus === 'CONNECTING' && (
          <>
            <span className="text-xs animate-pulse">🟡</span>
            <span className="whitespace-nowrap">Connecting...</span>
          </>
        )}
        {(realtimeStatus === 'CHANNEL_ERROR' || realtimeStatus === 'TIMED_OUT' || realtimeStatus === 'CLOSED') && (
          <>
            <span className="text-xs">🔴</span>
            <span className="whitespace-nowrap">Realtime Error</span>
            <button
              onClick={reconnect}
              title="Click to reconnect"
              className="ml-1 p-0.5 hover:bg-rose-200 dark:hover:bg-rose-900 rounded cursor-pointer"
            >
              <RefreshCw className="w-3 h-3 text-rose-600 dark:text-rose-400" />
            </button>
          </>
        )}
      </div>
    );
  }

  // Variant: detailed (Card with status, last sync timestamp, and reconnect trigger)
  if (variant === 'detailed') {
    return (
      <div className={`p-3.5 rounded-2xl border transition-all ${className} ${
        realtimeStatus === 'SUBSCRIBED'
          ? 'bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/80 text-emerald-900 dark:text-emerald-100'
          : realtimeStatus === 'CONNECTING'
          ? 'bg-amber-50/70 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/80 text-amber-900 dark:text-amber-100'
          : 'bg-rose-50/70 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/80 text-rose-900 dark:text-rose-100'
      }`}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {realtimeStatus === 'SUBSCRIBED' ? (
              <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-600 dark:text-emerald-400 shrink-0">
                <Wifi className="w-4 h-4" />
              </div>
            ) : realtimeStatus === 'CONNECTING' ? (
              <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-600 dark:text-amber-400 shrink-0">
                <Radio className="w-4 h-4 animate-spin" />
              </div>
            ) : (
              <div className="p-2 rounded-xl bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 shrink-0">
                <WifiOff className="w-4 h-4" />
              </div>
            )}

            <div>
              <div className="flex items-center gap-1.5">
                {realtimeStatus === 'SUBSCRIBED' && <span className="text-xs font-bold">🟢 Realtime Connected</span>}
                {realtimeStatus === 'CONNECTING' && <span className="text-xs font-bold">🟡 Connecting...</span>}
                {(realtimeStatus === 'CHANNEL_ERROR' || realtimeStatus === 'TIMED_OUT' || realtimeStatus === 'CLOSED') && (
                  <span className="text-xs font-bold">🔴 Realtime Error</span>
                )}
                <span className="text-[10px] opacity-75 font-mono">({realtimeStatus})</span>
              </div>
              <p className="text-[11px] opacity-80 mt-0.5">
                Channel: <span className="font-mono">{channelName}</span> • Table: <span className="font-mono">{tableName}</span>
              </p>
            </div>
          </div>

          <button
            onClick={reconnect}
            className="px-2.5 py-1.5 rounded-xl bg-white/80 dark:bg-slate-900/80 hover:bg-white dark:hover:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer transition-all shrink-0"
            title="Refresh Realtime Channel Subscription"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reconnect</span>
          </button>
        </div>
      </div>
    );
  }

  // Default: variant === 'badge' (Modern interactive header badge)
  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold border transition-all cursor-default select-none ${className} ${
        realtimeStatus === 'SUBSCRIBED'
          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 border-emerald-200 dark:border-emerald-800/80'
          : realtimeStatus === 'CONNECTING'
          ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-200 dark:border-amber-800/80'
          : 'bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 border-rose-200 dark:border-rose-800/80'
      }`}
      title={`Supabase Realtime Channel: ${channelName} (Status: ${realtimeStatus})`}
    >
      {realtimeStatus === 'SUBSCRIBED' && (
        <>
          <span>🟢</span>
          <span className="font-bold">Realtime Connected</span>
        </>
      )}

      {realtimeStatus === 'CONNECTING' && (
        <>
          <span className="animate-pulse">🟡</span>
          <span className="font-bold">Connecting...</span>
        </>
      )}

      {(realtimeStatus === 'CHANNEL_ERROR' || realtimeStatus === 'TIMED_OUT' || realtimeStatus === 'CLOSED') && (
        <>
          <span>🔴</span>
          <span className="font-bold">Realtime Error</span>
          <button
            type="button"
            onClick={reconnect}
            className="p-1 hover:bg-rose-200 dark:hover:bg-rose-900 rounded-md cursor-pointer transition-all ml-0.5"
            title="Reconnect Supabase Channel"
          >
            <RefreshCw className="w-3 h-3 text-rose-600 dark:text-rose-300" />
          </button>
        </>
      )}

      {showDetails && (
        <span className="text-[10px] opacity-70 font-mono ml-1">
          {lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
        </span>
      )}
    </div>
  );
};
