import React, { useState, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { apiService } from '../services/api';
import { Member } from '../types';
import { EthiopianPhoneInput } from './EthiopianPhoneInput';
import { validateEthiopianPhone, formatToE164 } from '../schemas/phone.schema';
import {
  Church,
  Lock,
  Mail,
  User,
  Phone,
  MapPin,
  Building,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Calendar,
  Sparkles,
  ShieldCheck,
  Globe,
  HeartHandshake,
  Users,
  Eye,
  EyeOff,
  Clock,
  Shield
} from 'lucide-react';

interface RegistrationPageProps {
  onSwitchToLogin: () => void;
}

export const RegistrationPage: React.FC<RegistrationPageProps> = ({ onSwitchToLogin }) => {
  const { language, setLanguage, systemName, churchLogoUrl, t } = useCMMS();

  // Multi-step Registration Wizard: 1 = Personal, 2 = Contact & Campus, 3 = Church & Ministries, 4 = Security
  const [step, setStep] = useState<number>(1);

  // Form Fields
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [dob, setDob] = useState('');
  const [maritalStatus, setMaritalStatus] = useState<'Single' | 'Married' | 'Widowed' | 'Divorced'>('Single');
  const [spouseName, setSpouseName] = useState('');
  const [spousePhone, setSpousePhone] = useState('');
  const [occupation, setOccupation] = useState('');

  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Addis Ababa');
  const [selectedBranchId, setSelectedBranchId] = useState('');
  const [registrationBranches, setRegistrationBranches] = useState<{ id: string; name: string; location?: string }[]>([]);

  useEffect(() => {
    let mounted = true;
    apiService.getPublicRegistrationOptions().then((result) => {
      if (!mounted) return;
      const options = Array.isArray(result?.branches) ? result.branches : [];
      setRegistrationBranches(options);
      setSelectedBranchId((current) => options.some((branch) => branch.id === current) ? current : options[0]?.id || '');
    }).catch((error) => {
      console.error('[Registration] Could not load active church campuses:', error);
      if (mounted) setErrorMsg('Unable to load church campuses. Please refresh the page or contact the church office.');
    });
    return () => { mounted = false; };
  }, []);

  const registrationToken = (() => {
  if (typeof window === 'undefined') return '';

      const match = window.location.pathname.match(
        /^\/register\/([^/]+)\/?$/
      );

      if (!match?.[1]) return '';

      try {
        return decodeURIComponent(match[1]);
      } catch {
        return '';
      }
    })();

  const [isBaptized, setIsBaptized] = useState(true);
  const [salvationDate, setSalvationDate] = useState('');
  const [selectedMinistries, setSelectedMinistries] = useState<string[]>(['Worship & Choir']);

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(true);

  // Feedback states
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registeredMember, setRegisteredMember] = useState<Member | null>(null);
  const [applicationRef, setApplicationRef] = useState<string>('');

  const availableMinistries = [
    'Worship & Choir',
    'Ushering & Protocol',
    'Youth & Campus Fellowship',
    'Media, Audio & Live Stream',
    'Intercessory & Prayer Warfare',
    'Sunday School & Children Care',
    'Evangelism & Community Outreach',
    'Hospitality & Fellowship'
  ];

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (step === 1) {
      if (!firstName.trim() || !lastName.trim()) {
        setErrorMsg('Please enter both your first and last name.');
        return;
      }
      if (maritalStatus === 'Married' && spousePhone.trim()) {
        const spouseCheck = validateEthiopianPhone(spousePhone);
        if (!spouseCheck.isValid) {
          setErrorMsg(spouseCheck.error || 'Invalid Ethiopian phone format for spouse');
          return;
        }
      }
      setStep(2);
    } else if (step === 2) {
      if (!email.includes('@')) {
        setErrorMsg('Please enter a valid email address.');
        return;
      }
      if (!phone.trim()) {
        setErrorMsg('Please enter a contact phone number.');
        return;
      }
      const phoneValidation = validateEthiopianPhone(phone);
      if (!phoneValidation.isValid) {
        setErrorMsg(phoneValidation.error || 'Invalid Ethiopian phone format (+2519/7... or 09/07...)');
        return;
      }
      setStep(3);
    } else if (step === 3) {
      setStep(4);
    }
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (emergencyPhone.trim()) {
      const emValidation = validateEthiopianPhone(emergencyPhone);
      if (!emValidation.isValid) {
        setErrorMsg(emValidation.error || 'Invalid emergency contact phone number');
        return;
      }
    }

    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }
    if (!agreeTerms) {
      setErrorMsg('Please accept the Church Fellowship terms & data policy.');
      return;
    }

    if (!selectedBranchId || !registrationBranches.some((branch) => branch.id === selectedBranchId)) {
      setErrorMsg('Please select an available church campus. Refresh the page if no campus is listed.');
      return;
    }

    setIsSubmitting(true);

    const normalizedPhone = formatToE164(phone);
    const normalizedEmergencyPhone = emergencyPhone.trim() ? formatToE164(emergencyPhone) : normalizedPhone;

    async function submitRegistration() {
      setErrorMsg('');
      try {
        const res = await fetch('/api/auth/register-public', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            firstName: firstName.trim(),
            lastName: lastName.trim(),
            email: email.trim().toLowerCase(),
            phone: normalizedPhone,
            password,
            gender,
            dateOfBirth: dob || '1995-05-15',
            maritalStatus,
            spouseName: maritalStatus === 'Married' ? spouseName.trim() : undefined,
            spousePhone: maritalStatus === 'Married' && spousePhone.trim() ? formatToE164(spousePhone) : undefined,
            address: address || 'Bole Subcity',
            city: city || 'Addis Ababa',
            branchId: selectedBranchId,
            registrationToken: registrationToken || undefined,
            selectedMinistries,
            isBaptized,
            emergencyName: emergencyName || 'Next of Kin',
            emergencyPhone: normalizedEmergencyPhone,
          }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || errData.message || 'Failed to submit registration. Please check your information and try again.');
        }

        const apiData = await res.json();
        const appRefCode = apiData.applicationReference || `MEM-APP-${Math.floor(100000 + Math.random() * 900000)}`;
        const serverMemberId = apiData.memberIdNumber || `CMMS-2026-${Math.floor(1000 + Math.random() * 9000)}`;

        // Summary representation for the receipt display (backend /api/auth/register-public has already created and persisted the member and workflow)
        const newMemberSummary: Member = {
          id: `mem-${Date.now()}`,
          memberIdNumber: serverMemberId,
          title: gender === 'Male' ? 'Brother' : 'Sister',
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          gender,
          dateOfBirth: dob || '',
          age: dob ? Math.max(0, new Date().getFullYear() - new Date(dob).getFullYear()) : 0,
          maritalStatus,
          spouseName: maritalStatus === 'Married' ? spouseName.trim() : undefined,
          spousePhone: maritalStatus === 'Married' && spousePhone.trim() ? formatToE164(spousePhone) : undefined,
          photoUrl: '',
          primaryPhone: normalizedPhone,
          email: email || '',
          preferredCommChannel: 'Email',
          streetAddress: address || '',
          city: city || '',
          region: '',
          branchId: selectedBranchId,
          ministryIds: selectedMinistries && selectedMinistries.length > 0 ? selectedMinistries : [],
          isWaterBaptized: isBaptized,
          salvationDate: salvationDate || new Date().toISOString().split('T')[0],
          membershipDate: new Date().toISOString().split('T')[0],
          membershipStatus: 'Pending',
          membershipType: 'Full Member',
          discipleshipStatus: 'New Convert',
          foundationCourseCompleted: false,
          attendanceScore: 100,
          createdAt: new Date().toISOString().split('T')[0],
          lastActive: 'Just now',
          emergencyContact: {
            name: emergencyName || '',
            relationship: '',
            phone: normalizedEmergencyPhone
          }
        };

        setApplicationRef(appRefCode);
        setRegisteredMember(newMemberSummary);
      } catch (err: any) {
        console.error('[Registration] Submit error:', err);
        setErrorMsg(err.message || 'Registration failed. Please check network connection and try again.');
      } finally {
        setIsSubmitting(false);
      }
    }

    submitRegistration();
  };

  return (
    <div className={`min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between relative overflow-hidden font-sans ${language === 'Amharic' || language === 'Tigrigna' ? 'font-amharic' : ''}`}>
      {/* Background Gradients */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 flex items-center justify-between border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md">
        <div className="flex items-center gap-3">
          {churchLogoUrl ? (
            <div className="w-10 h-10 rounded-2xl overflow-hidden border border-slate-700 bg-white flex items-center justify-center shrink-0">
              <img src={churchLogoUrl} alt="Logo" className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="p-2.5 bg-gradient-to-tr from-blue-600 to-indigo-600 text-white rounded-2xl shadow-lg shadow-blue-500/20">
              <Church className="w-6 h-6" />
            </div>
          )}
          <div>
            <h1 className="font-black text-lg sm:text-xl text-white tracking-tight flex items-center gap-2">
              {systemName || 'CMMS'}
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full bg-blue-950 text-blue-300 border border-blue-800">
                Member Registration
              </span>
            </h1>
            <p className="text-xs text-slate-400 font-medium hidden sm:block">
              {t('app.subtitle') || 'Church Member Management & Digital Sanctuary'}
            </p>
          </div>
        </div>

        {/* Language Switcher & Login Link */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-slate-800/80 rounded-xl px-2.5 py-1.5 border border-slate-700/80">
            <Globe className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-transparent text-slate-200 text-xs font-bold cursor-pointer border-0 py-0.5 focus:outline-hidden"
            >
              <option value="English" className="bg-slate-900 text-white">English (EN)</option>
              <option value="Amharic" className="bg-slate-900 text-white font-amharic">አማርኛ (Amharic)</option>
              <option value="Tigrigna" className="bg-slate-900 text-white font-amharic">ትግርኛ (Tigrigna)</option>
              <option value="Afaan Oromoo" className="bg-slate-900 text-white">Afaan Oromoo (OM)</option>
            </select>
          </div>

          <button
            onClick={onSwitchToLogin}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 rounded-xl text-xs font-bold border border-slate-700 transition-all cursor-pointer"
          >
            Sign In Instead
          </button>
        </div>
      </header>

      {/* Main Form Content */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="max-w-2xl w-full bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          
          {registeredMember ? (
            /* SUCCESS CONFIRMATION VIEW - STRICTLY PENDING APPROVAL */
            <div className="text-center space-y-5 py-4 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-full flex items-center justify-center mx-auto">
                <Clock className="w-9 h-9" />
              </div>

              <div>
                <h2 className="text-2xl font-black text-white">Application Submitted!</h2>
                <p className="text-xs text-slate-300 mt-1">
                  Thank you, <span className="font-bold text-white">{registeredMember.firstName} {registeredMember.lastName}</span>. Your membership registration has been received and is pending review.
                </p>
              </div>

              {/* Status Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold">
                <Clock className="w-3.5 h-3.5 animate-pulse" />
                <span>Pending Pastoral & Administrative Approval</span>
              </div>

              {/* Member Application Snapshot */}
              <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-700 max-w-md mx-auto text-left space-y-2.5">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Application Reference</span>
                  <span className="font-mono font-bold text-amber-400 text-sm">{applicationRef || registeredMember.memberIdNumber}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Assigned Campus:</span>
                  <span className="font-semibold text-white">{registrationBranches.find(b => b.id === registeredMember.branchId)?.name || 'Main Cathedral HQ'}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Registered Email:</span>
                  <span className="font-semibold text-white">{registeredMember.email}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Phone Contact:</span>
                  <span className="font-semibold text-white">{registeredMember.primaryPhone}</span>
                </div>
                <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-800">
                  <span className="text-slate-400">Account Status:</span>
                  <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-bold text-[10px] border border-amber-800">
                    Pending Review
                  </span>
                </div>
              </div>

              {/* Informational Guidance Box */}
              <div className="p-4 bg-emerald-950/40 border border-emerald-800/60 rounded-2xl text-xs text-slate-300 max-w-md mx-auto text-left flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs font-bold text-white">Placed in Pastoral Approval Page Queue</p>
                  <p className="text-[11px] leading-relaxed text-slate-300">
                    Your membership registration has been added to the Church Approvals Page for elder & pastor verification. Application Reference: <strong className="font-mono text-emerald-300">{applicationRef}</strong>.
                  </p>
                </div>
              </div>

              {/* Navigation Actions */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={onSwitchToLogin}
                  className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-2xl font-bold text-xs shadow-lg shadow-blue-500/25 cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Return to Sign In
                </button>
                <a
                  href="/approvals"
                  className="w-full sm:w-auto px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 rounded-2xl font-bold text-xs cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <Eye className="w-4 h-4 text-emerald-400" />
                  View in Pastoral Approval Board
                </a>
              </div>
            </div>
          ) : (
            /* WIZARD REGISTRATION FORM */
            <div className="space-y-5">
              {/* Wizard Steps Header */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" /> Step {step} of 4: {
                      step === 1 ? 'Personal Profile' :
                      step === 2 ? 'Contact & Campus' :
                      step === 3 ? 'Church & Ministries' : 'Account Security'
                    }
                  </span>
                  <span className="text-xs text-slate-400 font-semibold">{step * 25}% Complete</span>
                </div>

                {/* Progress Bar */}
                <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-300"
                    style={{ width: `${step * 25}%` }}
                  />
                </div>
              </div>

              {/* Error Message */}
              {errorMsg && (
                <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-2xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* STEP 1: Personal Profile */}
              {step === 1 && (
                <form onSubmit={handleNextStep} className="space-y-4 animate-in fade-in">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">First Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Dawit"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Last Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Wolde"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Gender</label>
                      <select
                        value={gender}
                        onChange={(e) => setGender(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Date of Birth</label>
                      <input
                        type="date"
                        value={dob}
                        onChange={(e) => setDob(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Marital Status</label>
                      <select
                        value={maritalStatus}
                        onChange={(e) => setMaritalStatus(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                        <option value="Widowed">Widowed</option>
                        <option value="Divorced">Divorced</option>
                      </select>
                    </div>
                  </div>

                  {maritalStatus === 'Married' && (
                    <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-purple-500/40 grid grid-cols-1 sm:grid-cols-2 gap-3 animate-in fade-in">
                      <div>
                        <label className="block text-xs font-bold text-purple-300 mb-1">Spouse Full Name</label>
                        <input
                          type="text"
                          placeholder="e.g. Almaz Bekele"
                          value={spouseName}
                          onChange={(e) => setSpouseName(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-purple-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-purple-300 mb-1">Spouse Ethiopian Phone</label>
                        <EthiopianPhoneInput
                          value={spousePhone}
                          onChange={(e) => setSpousePhone(e.target.value)}
                          placeholder="0911223344 or +251911223344"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Occupation / Profession</label>
                    <input
                      type="text"
                      placeholder="e.g. Software Engineer, Teacher, Business Owner"
                      value={occupation}
                      onChange={(e) => setOccupation(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="pt-3 flex justify-end">
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
                    >
                      Next: Contact Details <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 2: Contact Details & Campus Selection */}
              {step === 2 && (
                <form onSubmit={handleNextStep} className="space-y-4 animate-in fade-in">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="dawit.wolde@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <EthiopianPhoneInput
                        label="Phone Number"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="0911234567 or +251911234567"
                        helperText="Ethiopian mobile for login & SMS alerts."
                        showQuickPrefixes={true}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Residential Address</label>
                      <input
                        type="text"
                        placeholder="e.g. Bole Medhanialem, House 452"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">City / Sub-City</label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Primary Church Campus *</label>
                    <select
                      value={selectedBranchId}
                      onChange={(e) => setSelectedBranchId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs font-bold focus:ring-2 focus:ring-blue-500"
                    >
                      {registrationBranches.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name} ({b.location || 'Ethiopia'})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" /> Back
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                    >
                      Next: Ministries <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 3: Church & Ministries */}
              {step === 3 && (
                <form onSubmit={handleNextStep} className="space-y-4 animate-in fade-in">
                  <div className="p-3 bg-slate-900/70 rounded-2xl border border-slate-700/80 space-y-2">
                    <span className="font-bold text-xs text-white block">Spiritual Background</span>
                    <div className="flex flex-wrap gap-4 text-xs">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isBaptized}
                          onChange={(e) => setIsBaptized(e.target.checked)}
                          className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                        />
                        <span>Water Baptized</span>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300">
                      Ministry Interests & Volunteering (Select all that apply)
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {availableMinistries.map((min) => {
                        const isSelected = selectedMinistries.includes(min);
                        return (
                          <button
                            key={min}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setSelectedMinistries(selectedMinistries.filter((m) => m !== min));
                              } else {
                                setSelectedMinistries([...selectedMinistries, min]);
                              }
                            }}
                            className={`p-2.5 rounded-xl border text-left text-xs font-semibold cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-blue-600/30 border-blue-500 text-blue-200 font-bold'
                                : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-blue-400' : 'bg-slate-600'}`} />
                              <span>{min}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" /> Back
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                    >
                      Next: Account Password <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 4: Security Password & Emergency Contact */}
              {step === 4 && (
                <form onSubmit={handleFinalSubmit} className="space-y-4 animate-in fade-in">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Create Password *</label>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          placeholder="••••••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs pr-10 focus:ring-2 focus:ring-blue-500"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Confirm Password *</label>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        placeholder="••••••••••••"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Emergency Contact Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Almaz Wolde (Spouse/Parent)"
                        value={emergencyName}
                        onChange={(e) => setEmergencyName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <EthiopianPhoneInput
                        label="Emergency Contact Phone"
                        value={emergencyPhone}
                        onChange={(e) => setEmergencyPhone(e.target.value)}
                        placeholder="0912345678 or +251912345678"
                        showQuickPrefixes={false}
                      />
                    </div>
                  </div>

                  {/* Terms & Conditions */}
                  <div className="p-3 bg-slate-900/60 rounded-2xl border border-slate-700 text-xs">
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={agreeTerms}
                        onChange={(e) => setAgreeTerms(e.target.checked)}
                        className="w-4 h-4 mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-slate-300">
                        I agree to the Statement of Faith, Member Fellowship Covenant, and data privacy policy.
                      </span>
                    </label>
                  </div>

                  <div className="pt-3 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" /> Back
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/25 cursor-pointer transition-all disabled:opacity-50"
                    >
                      {isSubmitting ? 'Creating Member Account...' : 'Complete Member Registration'}
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-4 px-6 border-t border-slate-800/80 bg-slate-900/60 text-center text-xs text-slate-500">
        <p>© 2026 CMMS. All Rights Reserved.</p>
      </footer>
    </div>
  );
};
