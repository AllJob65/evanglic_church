import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCMMS } from '../context/CMMSContext';
import {
  Smartphone,
  Tablet,
  RotateCw,
  Church,
  Heart,
  QrCode,
  BookOpen,
  CheckCircle2,
  Video,
  Award,
  Users,
  CreditCard,
  Calendar,
  Sparkles,
  Volume2,
  VolumeX,
  Check,
  Send,
  ArrowRight,
  ShieldCheck,
  Zap,
  Wifi,
  Battery,
  BatteryCharging,
  Signal,
  Radio,
  Share2,
  MessageCircle,
  Flame,
  ThumbsUp,
  Music,
  Maximize2,
  Sliders,
  CheckCheck,
  Play,
  Pause,
} from 'lucide-react';

export type DeviceModelType = 'iphone15' | 'samsung24' | 'pixel8' | 'ipadpro';
export type OrientationType = 'portrait' | 'landscape';

export const MobilePreviewModule: React.FC = () => {
  const {
    members,
    ministries,
    events,
    addPrayerRequest,
    markAttendance,
    currency,
    addAuditLog,
  } = useCMMS();

  // Selected Member for Live Companion Portal
  const [selectedMemberId, setSelectedMemberId] = useState<string>(members[0]?.id || '');
  const activeMember = members.find((m) => m.id === selectedMemberId) || members[0] || {
    id: '',
    firstName: 'Member',
    lastName: '',
    title: '',
    email: '',
    primaryPhone: '',
    branchId: '',
    membershipStatus: 'Active',
    attendanceScore: 0,
    memberIdNumber: 'Unassigned',
  };

  // Hardware Simulator Controls
  const [deviceModel, setDeviceModel] = useState<DeviceModelType>('iphone15');
  const [orientation, setOrientation] = useState<OrientationType>('portrait');
  const [isDynamicIslandExpanded, setIsDynamicIslandExpanded] = useState<boolean>(false);
  const [isPlayingSermonAudio, setIsPlayingSermonAudio] = useState<boolean>(false);

  // Mobile App Internal Navigation Tab
  const [mobileTab, setMobileTab] = useState<'home' | 'live' | 'pass' | 'devotion' | 'prayer'>('home');

  // Interactive Form States
  const [prayerTitle, setPrayerTitle] = useState('');
  const [prayerCategory, setPrayerCategory] = useState('Healing & Health');
  const [prayerDetail, setPrayerDetail] = useState('');
  const [submittedMessage, setSubmittedMessage] = useState('');
  const [devotionCompleted, setDevotionCompleted] = useState(false);
  const [checkedInSuccess, setCheckedInSuccess] = useState(false);

  // Live Stream Simulator Reactions
  const [streamReactions, setStreamReactions] = useState<{ id: number; emoji: string }[]>([]);
  const [liveChatMessages, setLiveChatMessages] = useState<string[]>([]);
  const [newChatInput, setNewChatInput] = useState('');

  const handleSendReaction = (emoji: string) => {
    const newReaction = { id: Date.now() + Math.random(), emoji };
    setStreamReactions((prev) => [...prev.slice(-12), newReaction]);
  };

  const handleSendLiveChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatInput.trim()) return;
    setLiveChatMessages((prev) => [...prev, `${activeMember.firstName}: ${newChatInput}`]);
    setNewChatInput('');
  };

  const handleMobilePrayerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerTitle.trim()) return;

    addPrayerRequest({
      id: `pr-${Date.now()}`,
      requestNumber: `PR-M-${Math.floor(100 + Math.random() * 900)}`,
      memberId: activeMember.id,
      memberName: `${activeMember.title ? activeMember.title + ' ' : ''}${activeMember.firstName} ${activeMember.lastName}`.trim(),
      requesterName: `${activeMember.title ? activeMember.title + ' ' : ''}${activeMember.firstName} ${activeMember.lastName}`.trim(),
      title: prayerTitle,
      topic: prayerTitle,
      details: prayerDetail,
      description: prayerDetail || prayerTitle,
      category: prayerCategory as any,
      urgency: 'Medium',
      urgencyLevel: 'Normal',
      isConfidential: true,
      confidentialityLevel: 'Pastors Only',
      status: 'Pending',
      submittedDate: new Date().toISOString().substring(0, 10),
      submittedAt: new Date().toISOString().substring(0, 10),
    });

    addAuditLog(
      'Mobile Prayer Request Submitted',
      'Mobile App Simulator',
      `Member ${activeMember.firstName} submitted prayer: "${prayerTitle}" (${prayerCategory})`,
      undefined,
      'Addis Ababa, Mobile Device'
    );

    setPrayerTitle('');
    setPrayerDetail('');
    setSubmittedMessage('Prayer request recorded live in Church database! Pastors notified.');
    setTimeout(() => setSubmittedMessage(''), 4000);
  };

  const handleLiveQrCheckIn = () => {
    markAttendance({
      id: `att-${Date.now()}`,
      memberId: activeMember.id,
      memberName: `${activeMember.firstName} ${activeMember.lastName}`,
      eventId: 'ev1',
      eventName: 'Sunday Divine Worship Service',
      serviceSession: 'Sunday Morning Main Service',
      branchId: activeMember.branchId,
      date: new Date().toISOString().substring(0, 10),
      status: 'Present',
      checkedInTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      checkInMethod: 'Self QR Scan',
    });

    setCheckedInSuccess(true);
    setSubmittedMessage(`Live Check-In Confirmed for ${activeMember.firstName}! Attendance ledger updated.`);
    setTimeout(() => {
      setCheckedInSuccess(false);
      setSubmittedMessage('');
    }, 4500);
  };

  // Device Presets Dimensions & Styling Specs
  const getDeviceDimensions = () => {
    if (orientation === 'landscape') {
      switch (deviceModel) {
        case 'iphone15':
          return { outerW: 'w-[760px]', outerH: 'h-[400px]', screenW: 'w-[720px]', screenH: 'h-[360px]' };
        case 'samsung24':
          return { outerW: 'w-[780px]', outerH: 'h-[390px]', screenW: 'w-[740px]', screenH: 'h-[350px]' };
        case 'pixel8':
          return { outerW: 'w-[750px]', outerH: 'h-[395px]', screenW: 'w-[710px]', screenH: 'h-[355px]' };
        case 'ipadpro':
          return { outerW: 'w-[840px]', outerH: 'h-[580px]', screenW: 'w-[800px]', screenH: 'h-[540px]' };
      }
    } else {
      switch (deviceModel) {
        case 'iphone15':
          return { outerW: 'w-[390px]', outerH: 'h-[780px]', screenW: 'w-[350px]', screenH: 'h-[740px]' };
        case 'samsung24':
          return { outerW: 'w-[395px]', outerH: 'h-[800px]', screenW: 'w-[355px]', screenH: 'h-[760px]' };
        case 'pixel8':
          return { outerW: 'w-[390px]', outerH: 'h-[775px]', screenW: 'w-[350px]', screenH: 'h-[735px]' };
        case 'ipadpro':
          return { outerW: 'w-[580px]', outerH: 'h-[820px]', screenW: 'w-[540px]', screenH: 'h-[780px]' };
      }
    }
  };

  const dims = getDeviceDimensions();

  return (
    <div className="space-y-6">
      {/* HEADER CONTROL BAR */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 sm:p-6 rounded-3xl text-white shadow-2xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-600/30 rounded-xl border border-indigo-500/30 text-indigo-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black tracking-tight">High-Fidelity Hardware Device Simulator</h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                  ● LIVE DATABASE
                </span>
              </div>
              <p className="text-xs text-indigo-200/80 mt-0.5">
                Physical bezel rendering, hardware buttons, Dynamic Island/camera notch, and real-time CMMS synchronization.
              </p>
            </div>
          </div>
        </div>

        {/* CONTROLS: Member Selector, Device Presets, Orientation */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Member Switcher */}
          <div className="bg-slate-800/90 p-1.5 rounded-2xl border border-slate-700/80 flex items-center gap-2 text-xs">
            <span className="text-slate-400 pl-2 font-bold text-[11px]">Member:</span>
            <select
              value={selectedMemberId}
              onChange={(e) => setSelectedMemberId(e.target.value)}
              className="bg-slate-900 text-white font-bold px-3 py-1.5 rounded-xl border border-slate-700 focus:outline-hidden text-xs cursor-pointer"
            >
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.title ? `${m.title} ` : ''}{m.firstName} {m.lastName} ({m.memberIdNumber || m.id})
                </option>
              ))}
            </select>
          </div>

          {/* Device Model Selector */}
          <div className="bg-slate-800/90 p-1 rounded-2xl border border-slate-700/80 flex items-center gap-1 text-xs font-bold">
            <button
              onClick={() => setDeviceModel('iphone15')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer text-xs ${
                deviceModel === 'iphone15' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-300 hover:text-white'
              }`}
            >
              iPhone 15 Pro
            </button>
            <button
              onClick={() => setDeviceModel('samsung24')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer text-xs ${
                deviceModel === 'samsung24' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-300 hover:text-white'
              }`}
            >
              Galaxy S24 Ultra
            </button>
            <button
              onClick={() => setDeviceModel('pixel8')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer text-xs ${
                deviceModel === 'pixel8' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-300 hover:text-white'
              }`}
            >
              Pixel 8
            </button>
            <button
              onClick={() => setDeviceModel('ipadpro')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer text-xs ${
                deviceModel === 'ipadpro' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-300 hover:text-white'
              }`}
            >
              iPad Pro 11"
            </button>
          </div>

          {/* Orientation Toggle Button */}
          <button
            onClick={() => setOrientation((prev) => (prev === 'portrait' ? 'landscape' : 'portrait'))}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-2xl text-xs shadow-md transition-all cursor-pointer active:scale-95"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>{orientation === 'portrait' ? 'Rotate Landscape' : 'Rotate Portrait'}</span>
          </button>
        </div>
      </div>

      {/* FEEDBACK BANNER */}
      {submittedMessage && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3.5 bg-emerald-500/15 border border-emerald-500/40 rounded-2xl text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{submittedMessage}</span>
          </div>
          <button onClick={() => setSubmittedMessage('')} className="text-emerald-500 hover:text-emerald-700 text-xs cursor-pointer font-bold">
            Dismiss
          </button>
        </motion.div>
      )}

      {/* HARDWARE DEVICE STAGE */}
      <div className="flex justify-center items-center py-6 px-2 bg-slate-900/60 dark:bg-slate-950/80 rounded-3xl border border-slate-800 shadow-inner overflow-x-auto min-h-[820px]">
        <div className="relative select-none transition-all duration-300">
          
          {/* HARDWARE SIDE BUTTONS (Rendered outside the frame) */}
          {/* Left Buttons: Action Button, Volume Up, Volume Down for iPhone / iPad */}
          {orientation === 'portrait' && (
            <>
              {deviceModel === 'iphone15' && (
                <>
                  {/* Action Button (Top Left) */}
                  <div className="absolute -left-2.5 top-28 w-1.5 h-7 bg-slate-700 rounded-l-xs shadow-md border border-slate-600/50" />
                  {/* Volume Up */}
                  <div className="absolute -left-2.5 top-40 w-1.5 h-12 bg-slate-700 rounded-l-xs shadow-md border border-slate-600/50" />
                  {/* Volume Down */}
                  <div className="absolute -left-2.5 top-56 w-1.5 h-12 bg-slate-700 rounded-l-xs shadow-md border border-slate-600/50" />
                  {/* Power Button (Right) */}
                  <div className="absolute -right-2.5 top-36 w-1.5 h-16 bg-slate-700 rounded-r-xs shadow-md border border-slate-600/50" />
                </>
              )}

              {deviceModel === 'samsung24' && (
                <>
                  {/* Volume Rocker (Right Top) */}
                  <div className="absolute -right-2 top-32 w-1.5 h-20 bg-zinc-700 rounded-r-xs shadow-md border border-zinc-600/60" />
                  {/* Power Button (Right Mid) */}
                  <div className="absolute -right-2 top-56 w-1.5 h-12 bg-zinc-700 rounded-r-xs shadow-md border border-zinc-600/60" />
                </>
              )}

              {deviceModel === 'pixel8' && (
                <>
                  {/* Power Button (Right Top) */}
                  <div className="absolute -right-2 top-28 w-1.5 h-10 bg-slate-700 rounded-r-xs shadow-md border border-slate-600/50" />
                  {/* Volume Rocker (Right Mid) */}
                  <div className="absolute -right-2 top-42 w-1.5 h-20 bg-slate-700 rounded-r-xs shadow-md border border-slate-600/50" />
                </>
              )}

              {deviceModel === 'ipadpro' && (
                <>
                  {/* Top Power Button with Touch ID */}
                  <div className="absolute top-0 right-16 -mt-2 w-14 h-1.5 bg-slate-700 rounded-t-xs shadow-md border border-slate-600/50" />
                  {/* Volume Buttons (Right Top) */}
                  <div className="absolute -right-2 top-20 w-1.5 h-10 bg-slate-700 rounded-r-xs shadow-md border border-slate-600/50" />
                  <div className="absolute -right-2 top-34 w-1.5 h-10 bg-slate-700 rounded-r-xs shadow-md border border-slate-600/50" />
                  {/* Magnetic Apple Pencil Strip (Left) */}
                  <div className="absolute -left-1 top-44 w-1 h-32 bg-slate-600/40 rounded-l-xs border border-slate-500/30" />
                </>
              )}
            </>
          )}

          {/* LANDSCAPE HARDWARE BUTTONS */}
          {orientation === 'landscape' && (
            <>
              {/* Top buttons in landscape */}
              <div className="absolute -top-2 left-28 w-14 h-1.5 bg-slate-700 rounded-t-xs shadow-md border border-slate-600/50" />
              <div className="absolute -top-2 left-48 w-14 h-1.5 bg-slate-700 rounded-t-xs shadow-md border border-slate-600/50" />
              <div className="absolute -bottom-2 right-28 w-16 h-1.5 bg-slate-700 rounded-b-xs shadow-md border border-slate-600/50" />
            </>
          )}

          {/* HARDWARE OUTER BEZEL CONTAINER */}
          <div
            className={`transition-all duration-300 relative overflow-hidden flex flex-col ${
              deviceModel === 'iphone15'
                ? 'rounded-[52px] bg-slate-950 p-3.5 border-[8px] border-slate-700/90 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-slate-600/40'
                : deviceModel === 'samsung24'
                ? 'rounded-[20px] bg-zinc-950 p-2.5 border-[6px] border-zinc-700 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-zinc-600/40'
                : deviceModel === 'pixel8'
                ? 'rounded-[46px] bg-slate-950 p-3 border-[7px] border-slate-700/80 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-slate-600/40'
                : 'rounded-[36px] bg-slate-950 p-4 border-[10px] border-slate-700 shadow-[0_30px_70px_-15px_rgba(0,0,0,0.95)] ring-1 ring-slate-600/40'
            } ${dims.outerW} ${dims.outerH}`}
          >
            {/* INNER SCREEN DISPLAY */}
            <div
              className={`w-full h-full bg-slate-900 text-slate-100 flex flex-col relative overflow-hidden select-text ${
                deviceModel === 'iphone15'
                  ? 'rounded-[40px]'
                  : deviceModel === 'samsung24'
                  ? 'rounded-[14px]'
                  : deviceModel === 'pixel8'
                  ? 'rounded-[36px]'
                  : 'rounded-[24px]'
              }`}
            >
              {/* 1. TOP HARDWARE STATUS BAR & CAMERA NOTCHES */}
              <div className="w-full shrink-0 z-30 pt-2 px-5 flex items-center justify-between text-[11px] font-semibold text-white/90 bg-slate-950/40 backdrop-blur-md">
                {/* Left: Time & Location Indicator */}
                <div className="flex items-center gap-1 font-mono tracking-tight font-bold">
                  <span>9:41</span>
                  {deviceModel === 'pixel8' && <span className="text-[9px] text-amber-400 font-sans">☀️ 24°C</span>}
                </div>

                {/* Center: NOTCH / DYNAMIC ISLAND / PUNCH-HOLE */}
                <div className="flex items-center justify-center">
                  {deviceModel === 'iphone15' && (
                    <motion.div
                      layout
                      onClick={() => setIsDynamicIslandExpanded(!isDynamicIslandExpanded)}
                      className={`bg-black text-white rounded-full flex items-center justify-between px-3 cursor-pointer shadow-lg transition-all border border-slate-800 ${
                        isDynamicIslandExpanded ? 'w-56 h-9' : 'w-26 h-5.5'
                      }`}
                    >
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
                      {isDynamicIslandExpanded ? (
                        <div className="flex items-center gap-2 text-[9px] font-bold text-amber-300">
                          <Church className="w-3 h-3 text-indigo-400" />
                          <span>Sunday Live Worship</span>
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <div className="w-2 h-2 rounded-full bg-slate-800" />
                        </div>
                      )}
                    </motion.div>
                  )}

                  {deviceModel === 'samsung24' && (
                    <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-800 shadow-inner flex items-center justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
                    </div>
                  )}

                  {deviceModel === 'pixel8' && (
                    <div className="w-4 h-4 rounded-full bg-black border border-slate-800 shadow-inner flex items-center justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
                    </div>
                  )}

                  {deviceModel === 'ipadpro' && (
                    <div className="flex items-center gap-1 text-[10px] text-slate-400">
                      <div className="w-2.5 h-2.5 rounded-full bg-black border border-slate-700" />
                      <span>Face ID Active</span>
                    </div>
                  )}
                </div>

                {/* Right: Network, 5G, Wi-Fi, Battery Indicator */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-black tracking-tighter">5G</span>
                  <Signal className="w-3.5 h-3.5" />
                  <Wifi className="w-3.5 h-3.5" />
                  <div className="flex items-center gap-0.5">
                    <div className="w-5 h-2.5 rounded-xs border border-white/80 p-0.5 flex items-center">
                      <div className="w-full h-full bg-emerald-400 rounded-2xs" />
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. COMPANION APP INNER VIEWPORT */}
              <div className="flex-1 min-h-0 overflow-y-auto flex flex-col p-3.5 space-y-3.5">
                
                {/* Companion App Branding Card */}
                <div className="p-3.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white rounded-2xl flex items-center justify-between shadow-lg shrink-0">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-white/10 border border-white/20 flex items-center justify-center font-black text-xs text-white shadow-inner">
                      {activeMember.firstName[0]}
                      {activeMember.lastName[0]}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h2 className="text-xs font-black tracking-tight">CMMS Mobile</h2>
                        <span className="px-1.5 py-0.5 rounded text-[8px] font-black bg-amber-400 text-slate-950">
                          v3.8
                        </span>
                      </div>
                      <p className="text-[11px] text-blue-100 font-semibold">
                        {activeMember.title ? `${activeMember.title} ` : ''}{activeMember.firstName} {activeMember.lastName}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-[9px] font-bold text-blue-200">Campus Pass</span>
                    <span className="text-[10px] font-mono font-black text-amber-300">
                      {activeMember.memberIdNumber || 'GC-2026-1049'}
                    </span>
                  </div>
                </div>

                {/* TAB CONTENT: HOME */}
                {mobileTab === 'home' && (
                  <div className="space-y-3">
                    {/* Live Sunday Sanctuary Stream Card */}
                    <div className="p-3.5 bg-slate-800/90 border border-slate-700 rounded-2xl space-y-2.5 shadow-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                          <span className="text-xs font-bold text-white">Live Broadcast: Divine Worship</span>
                        </div>
                        <span className="text-[10px] font-bold bg-red-600/30 text-red-300 px-2 py-0.5 rounded-full border border-red-500/40">
                          1,420 Watching
                        </span>
                      </div>

                      {/* Video Player Simulator */}
                      <div className="relative w-full h-32 bg-slate-950 rounded-xl overflow-hidden flex items-center justify-center border border-slate-800">
                        <img
                          src="https://images.unsplash.com/photo-1544427920-c49ccfb85579?w=600&auto=format&fit=crop&q=80"
                          alt="Sanctuary Live"
                          className="w-full h-full object-cover opacity-60"
                        />
                        <button
                          onClick={() => setMobileTab('live')}
                          className="absolute w-11 h-11 bg-red-600 hover:bg-red-500 text-white rounded-full flex items-center justify-center shadow-xl cursor-pointer active:scale-95 transition-all"
                        >
                          <Play className="w-5 h-5 ml-0.5" />
                        </button>
                        <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/70 rounded text-[9px] text-white font-mono">
                          LIVE • 1080p HD
                        </div>
                      </div>
                    </div>

                    {/* Quick Action Center */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setMobileTab('pass')}
                        className="p-3 bg-slate-800/80 hover:bg-slate-700/80 rounded-2xl border border-slate-700 flex flex-col items-start gap-1.5 transition-all text-left cursor-pointer"
                      >
                        <div className="p-2 bg-purple-500/20 text-purple-400 rounded-xl">
                          <QrCode className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">Digital Pass</p>
                          <p className="text-[10px] text-slate-400">1-Tap Sunday Check-in</p>
                        </div>
                      </button>

                      <button
                        onClick={() => setMobileTab('live')}
                        className="p-3 bg-slate-800/80 hover:bg-slate-700/80 rounded-2xl border border-slate-700 flex flex-col items-start gap-1.5 transition-all text-left cursor-pointer"
                      >
                        <div className="p-2 bg-red-500/20 text-red-400 rounded-xl">
                          <Video className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">Live Stream</p>
                          <p className="text-[10px] text-slate-400">Online Worship</p>
                        </div>
                      </button>

                      <button
                        onClick={() => setMobileTab('devotion')}
                        className="p-3 bg-slate-800/80 hover:bg-slate-700/80 rounded-2xl border border-slate-700 flex flex-col items-start gap-1.5 transition-all text-left cursor-pointer"
                      >
                        <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl">
                          <BookOpen className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">Daily Devotion</p>
                          <p className="text-[10px] text-slate-400">Scripture & Notes</p>
                        </div>
                      </button>

                      <button
                        onClick={() => setMobileTab('prayer')}
                        className="p-3 bg-slate-800/80 hover:bg-slate-700/80 rounded-2xl border border-slate-700 flex flex-col items-start gap-1.5 transition-all text-left cursor-pointer"
                      >
                        <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl">
                          <Heart className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white">Prayer Request</p>
                          <p className="text-[10px] text-slate-400">Direct Pastoral Care</p>
                        </div>
                      </button>
                    </div>

                    {/* Member Stats & Ministries Badges */}
                    <div className="p-3.5 bg-slate-800/80 border border-slate-700 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-300">My Ministries & Teams</span>
                        <span className="text-[10px] text-indigo-400 font-semibold">Active</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        <span className="px-2.5 py-1 bg-indigo-900/50 text-indigo-300 border border-indigo-700/50 rounded-lg text-[10px] font-bold">
                          Worship & Choir
                        </span>
                        <span className="px-2.5 py-1 bg-blue-900/50 text-blue-300 border border-blue-700/50 rounded-lg text-[10px] font-bold">
                          Youth Fellowship
                        </span>
                        <span className="px-2.5 py-1 bg-emerald-900/50 text-emerald-300 border border-emerald-700/50 rounded-lg text-[10px] font-bold">
                          Attendance: {activeMember.attendanceScore || 98}%
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB CONTENT: LIVE SANCTUARY STREAM */}
                {mobileTab === 'live' && (
                  <div className="space-y-3 flex-1 flex flex-col">
                    <div className="relative w-full h-44 bg-black rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center shrink-0">
                      <img
                        src="https://images.unsplash.com/photo-1544427920-c49ccfb85579?w=600&auto=format&fit=crop&q=80"
                        alt="Sanctuary Stream"
                        className="w-full h-full object-cover opacity-70"
                      />
                      {/* Floating Emojis Reaction Layer */}
                      <div className="absolute inset-0 pointer-events-none overflow-hidden">
                        <AnimatePresence>
                          {streamReactions.map((r) => (
                            <motion.span
                              key={r.id}
                              initial={{ opacity: 1, y: 120, x: Math.random() * 200 + 40, scale: 0.8 }}
                              animate={{ opacity: 0, y: -40, scale: 1.4 }}
                              exit={{ opacity: 0 }}
                              transition={{ duration: 1.8, ease: 'easeOut' }}
                              className="absolute text-xl font-bold"
                            >
                              {r.emoji}
                            </motion.span>
                          ))}
                        </AnimatePresence>
                      </div>

                      <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-red-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow-md">
                        <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                        <span>LIVE SANCTUARY</span>
                      </div>
                    </div>

                    {/* Reaction Buttons */}
                    <div className="flex items-center justify-around py-1.5 bg-slate-800/80 rounded-xl border border-slate-700">
                      <button onClick={() => handleSendReaction('🙏')} className="text-base hover:scale-125 transition-transform cursor-pointer">
                        🙏 Amen
                      </button>
                      <button onClick={() => handleSendReaction('🔥')} className="text-base hover:scale-125 transition-transform cursor-pointer">
                        🔥 Fire
                      </button>
                      <button onClick={() => handleSendReaction('❤️')} className="text-base hover:scale-125 transition-transform cursor-pointer">
                        ❤️ Love
                      </button>
                      <button onClick={() => handleSendReaction('🙌')} className="text-base hover:scale-125 transition-transform cursor-pointer">
                        🙌 Praise
                      </button>
                    </div>

                    {/* Live Chat Messages */}
                    <div className="flex-1 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 flex flex-col justify-between space-y-2 min-h-[140px]">
                      <div className="space-y-1.5 max-h-28 overflow-y-auto text-[10px]">
                        {liveChatMessages.map((msg, i) => (
                          <p key={i} className="text-slate-300 font-medium">
                            {msg}
                          </p>
                        ))}
                      </div>
                      <form onSubmit={handleSendLiveChat} className="flex gap-1.5 pt-1">
                        <input
                          type="text"
                          value={newChatInput}
                          onChange={(e) => setNewChatInput(e.target.value)}
                          placeholder="Send comment..."
                          className="flex-1 bg-slate-900 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 text-white"
                        />
                        <button type="submit" className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold cursor-pointer">
                          Send
                        </button>
                      </form>
                    </div>
                  </div>
                )}

                {/* TAB CONTENT: DIGITAL PASS */}
                {mobileTab === 'pass' && (
                  <div className="p-4 bg-slate-800/90 rounded-2xl border border-slate-700 text-center space-y-3.5 shadow-xl">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-xs text-white">Sunday Attendance QR Pass</h3>
                      <span className="text-[9px] font-bold bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30">
                        Live Scanner Pass
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-300">
                      Scan at sanctuary gate entrance or tap button below to simulate 1-tap live check-in.
                    </p>

                    <div className="p-4 bg-white rounded-2xl inline-block shadow-lg">
                      <QrCode className="w-32 h-32 mx-auto text-slate-950" />
                    </div>

                    <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-700/80">
                      <p className="text-[10px] text-slate-400">Member Pass Reference</p>
                      <p className="text-xs font-mono font-black text-amber-400">{activeMember.memberIdNumber || activeMember.id}</p>
                    </div>

                    <button
                      onClick={handleLiveQrCheckIn}
                      className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer active:scale-95 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Simulate 1-Tap Attendance Check-In
                    </button>
                  </div>
                )}

                {/* TAB CONTENT: DAILY DEVOTION */}
                {mobileTab === 'devotion' && (
                  <div className="p-4 bg-slate-800/90 rounded-2xl border border-slate-700 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-xs text-white flex items-center gap-1.5">
                        <BookOpen className="w-4 h-4 text-amber-400" /> Daily Devotional
                      </h3>
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Day 218 • Grace Walk
                      </span>
                    </div>

                    <div className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 space-y-1.5">
                      <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-wider">Scripture of the Day</span>
                      <p className="font-bold text-xs text-white">Psalm 23:1-6</p>
                      <p className="text-[11px] text-slate-300 leading-relaxed italic">
                        "The Lord is my shepherd; I shall not want. He makes me lie down in green pastures; He leads me beside still waters."
                      </p>
                    </div>

                    <div className="p-2.5 bg-slate-900/60 rounded-xl text-[11px] text-slate-400 space-y-1">
                      <span className="font-bold text-slate-300 text-[10px]">Pastoral Reflection:</span>
                      <p>Walk in full faith today knowing divine provision never fails.</p>
                    </div>

                    <button
                      onClick={() => {
                        setDevotionCompleted(true);
                        setSubmittedMessage('Devotional Completed! Daily Streak Updated.');
                        setTimeout(() => setSubmittedMessage(''), 3500);
                      }}
                      className={`w-full py-2.5 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-all ${
                        devotionCompleted
                          ? 'bg-emerald-600 text-white'
                          : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950'
                      }`}
                    >
                      <Award className="w-4 h-4" />
                      {devotionCompleted ? 'Completed Today ✓' : 'Mark Devotion Complete'}
                    </button>
                  </div>
                )}

                {/* TAB CONTENT: PRAYER REQUESTS */}
                {mobileTab === 'prayer' && (
                  <form onSubmit={handleMobilePrayerSubmit} className="p-4 bg-slate-800/90 rounded-2xl border border-slate-700 space-y-3 shadow-xl">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-xs text-white flex items-center gap-1.5">
                        <Heart className="w-4 h-4 text-rose-400" /> Pastoral Prayer Request
                      </h3>
                      <span className="text-[9px] font-bold bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/30">
                        Pastors Only
                      </span>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Prayer Title / Topic</label>
                      <input
                        type="text"
                        placeholder="e.g. Healing for Family, University Visa"
                        value={prayerTitle}
                        onChange={(e) => setPrayerTitle(e.target.value)}
                        required
                        className="w-full p-2 text-xs rounded-xl border border-slate-700 bg-slate-900 text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Category</label>
                      <select
                        value={prayerCategory}
                        onChange={(e) => setPrayerCategory(e.target.value)}
                        className="w-full p-2 text-xs rounded-xl border border-slate-700 bg-slate-900 text-white font-bold cursor-pointer"
                      >
                        <option value="Healing & Health">Healing & Health</option>
                        <option value="Family & Marriage">Family & Marriage</option>
                        <option value="Financial Breakthrough">Financial Breakthrough</option>
                        <option value="Spiritual Growth & Ministry">Spiritual Growth & Ministry</option>
                        <option value="Travel & Visa">Travel & Visa</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Prayer Details</label>
                      <textarea
                        rows={3}
                        placeholder="Describe your situation in confidence..."
                        value={prayerDetail}
                        onChange={(e) => setPrayerDetail(e.target.value)}
                        className="w-full p-2 text-xs rounded-xl border border-slate-700 bg-slate-900 text-white"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer active:scale-95 transition-all"
                    >
                      <Send className="w-3.5 h-3.5" /> Submit to Pastoral Intercessory Team
                    </button>
                  </form>
                )}

              </div>

              {/* 3. MOBILE BOTTOM NAVIGATION BAR */}
              <div className="p-2 bg-slate-950 border-t border-slate-800 flex justify-around text-[10px] shrink-0 z-20">
                <button
                  onClick={() => setMobileTab('home')}
                  className={`flex flex-col items-center gap-0.5 cursor-pointer transition-colors ${
                    mobileTab === 'home' ? 'text-indigo-400 font-bold' : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  <Church className="w-4 h-4" />
                  <span>Home</span>
                </button>
                <button
                  onClick={() => setMobileTab('live')}
                  className={`flex flex-col items-center gap-0.5 cursor-pointer transition-colors ${
                    mobileTab === 'live' ? 'text-red-400 font-bold' : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  <span>Live</span>
                </button>
                <button
                  onClick={() => setMobileTab('pass')}
                  className={`flex flex-col items-center gap-0.5 cursor-pointer transition-colors ${
                    mobileTab === 'pass' ? 'text-purple-400 font-bold' : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span>Pass</span>
                </button>
                <button
                  onClick={() => setMobileTab('devotion')}
                  className={`flex flex-col items-center gap-0.5 cursor-pointer transition-colors ${
                    mobileTab === 'devotion' ? 'text-amber-400 font-bold' : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Devotion</span>
                </button>
                <button
                  onClick={() => setMobileTab('prayer')}
                  className={`flex flex-col items-center gap-0.5 cursor-pointer transition-colors ${
                    mobileTab === 'prayer' ? 'text-rose-400 font-bold' : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  <Heart className="w-4 h-4" />
                  <span>Prayer</span>
                </button>
              </div>

              {/* 4. BOTTOM HARDWARE SWIPE HOME BAR */}
              <div className="w-full shrink-0 h-3.5 bg-slate-950 flex items-center justify-center">
                <div className="w-32 h-1 bg-white/40 rounded-full hover:bg-white/70 transition-colors" />
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
