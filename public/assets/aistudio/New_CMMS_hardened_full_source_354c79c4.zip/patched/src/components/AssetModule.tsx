import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Asset } from '../types';
import {
  Package,
  Plus,
  Wrench,
  DollarSign,
  UserCheck,
  Calendar,
  X,
  CheckCircle2,
} from 'lucide-react';

export const AssetModule: React.FC = () => {
  const { assets, addAsset, permissions, branches } = useCMMS();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const [name, setName] = useState('');
  const [category, setCategory] = useState<Asset['category']>('Musical Instrument');
  const [custodian, setCustodian] = useState('A/V Tech Team');
  const [price, setPrice] = useState(2500);

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    const newAst: Asset = {
      id: `ast-${Date.now().toString().slice(-4)}`,
      assetCode: `AST-${Math.floor(100 + Math.random() * 900)}`,
      name,
      category,
      branchId: branches[0]?.id || 'br-001',
      custodianMemberName: custodian,
      purchaseDate: new Date().toISOString().split('T')[0],
      purchasePrice: price,
      currentValue: Math.round(price * 0.85),
      condition: 'Excellent',
      nextMaintenanceDate: '2026-12-01',
    };

    addAsset(newAst);
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Package className="w-6 h-6 text-slate-700 dark:text-slate-200" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Church Asset & Equipment Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200">
              {assets.length} Inventory Items
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Instruments, sound mixers, vehicles, building maintenance schedules, and valuation depreciation.
          </p>
        </div>

        {permissions.canManageBranches && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Register Church Asset
          </button>
        )}
      </div>

      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">Registered Asset Inventory Ledger</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {assets.map((ast) => (
            <div
              key={ast.id}
              className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-slate-600 dark:text-slate-300">{ast.assetCode}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                  {ast.category}
                </span>
              </div>

              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">{ast.name}</h4>
                <p className="text-slate-500 mt-0.5">Custodian: {ast.custodianMemberName}</p>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 block text-[10px]">Purchase / Current Value</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    ${ast.purchasePrice.toLocaleString()} &rarr; ${ast.currentValue.toLocaleString()}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                  {ast.condition} Condition
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Asset Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Register Church Asset</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAsset} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1">Asset Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Panasonic 4K Camera"
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Asset Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Musical Instrument">Musical Instrument</option>
                  <option value="Sound & Audio">Sound & Audio</option>
                  <option value="Electronics & Displays">Electronics & Displays</option>
                  <option value="Vehicles">Vehicles</option>
                  <option value="Furniture">Furniture</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Custodian / Person Responsible</label>
                <input
                  type="text"
                  required
                  value={custodian}
                  onChange={(e) => setCustodian(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Purchase Price ($)</label>
                <input
                  type="number"
                  required
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-slate-900 dark:bg-slate-800 text-white rounded-xl font-semibold">
                  Save Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
