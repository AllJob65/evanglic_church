import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useCMMS } from '../context/CMMSContext';
import { useMinistryRealtime } from '../hooks/useMinistryRealtime';
import { supabaseMinistryService } from '../services/supabaseMinistryService';
import { RealtimeConnectionIndicator } from './RealtimeConnectionIndicator';
import {
  MessageSquare,
  Send,
  X,
  Smile,
  BookOpen,
  Users,
  Paperclip,
  Check,
  Heart,
  Flame,
  Sparkles,
  Maximize2,
  Minimize2,
  Trash2,
  UserPlus,
  Shield,
  ShieldAlert,
  Radio,
  CheckCircle2,
} from 'lucide-react';

interface MinistryLiveChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMinistryId?: string;
  onSwitchToVideo?: (ministryId: string) => void;
}

const QUICK_SCRIPTURES = [
  { ref: 'Psalm 100:1-2', text: 'Make a joyful noise unto the Lord, all ye lands. Serve the Lord with gladness.' },
  { ref: 'John 13:34-35', text: 'A new command I give you: Love one another. As I have loved you, so you must love one another.' },
  { ref: 'Philippians 4:13', text: 'I can do all things through Christ who strengthens me.' },
  { ref: 'Colossians 3:16', text: 'Let the message of Christ dwell among you richly as you teach and admonish one another.' },
  { ref: '1 Thessalonians 5:11', text: 'Therefore encourage one another and build each other up, just as in fact you are doing.' },
  { ref: 'Proverbs 3:5-6', text: 'Trust in the Lord with all your heart and lean not on your own understanding.' },
];

const EMOJI_LIST = ['🙏', '❤️', '🙌', '🔥', '✨', '👏', '🕊️', '📖'];

export const MinistryLiveChatModal: React.FC<MinistryLiveChatModalProps> = ({
  isOpen,
  onClose,
  initialMinistryId,
  onSwitchToVideo,
}) => {
  const { currentUser, ministries, activeRole } = useCMMS();
  const [activeMinistryId, setActiveMinistryId] = useState<string>(initialMinistryId || ministries[0]?.id || 'min-1');
  const [inputText, setInputText] = useState('');
  const [selectedScripture, setSelectedScripture] = useState('');
  const [showScripturePicker, setShowScripturePicker] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showParticipantsList, setShowParticipantsList] = useState(false);
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState<'Member' | 'Volunteer' | 'CoLeader'>('Member');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [membershipError, setMembershipError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);
  const activeMinistry = ministries.find((m) => m.id === activeMinistryId) || ministries[0];

  // Sync initialMinistryId when opened
  useEffect(() => {
    if (initialMinistryId) {
      setActiveMinistryId(initialMinistryId);
    }
  }, [initialMinistryId, isOpen]);

  // Connect to socket to verify ministry membership and handle real-time membership denial
  useEffect(() => {
    if (!isOpen || !activeMinistryId) return;

    setMembershipError(null);

    const socket = io({
      path: '/socket.io',
      transports: ['websocket', 'polling'],
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      socket.emit('chat:join_ministry', { ministryId: activeMinistryId });
    });

    socket.on('error', (err: any) => {
      if (
        err?.code === 'FORBIDDEN_GROUP' ||
        err?.code === 'FORBIDDEN_MINISTRY' ||
        err?.code === 'FORBIDDEN'
      ) {
        setMembershipError(
          err.message ||
            'You are not an enrolled member of this fellowship group. Please contact your ministry leader.'
        );
      }
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [isOpen, activeMinistryId]);

  // Current user info for realtime chat
  const currentUserInfo = {
    id: currentUser?.memberId || currentUser?.email || 'usr-current',
    name: currentUser?.name || 'Authenticated User',
    email: currentUser?.email || '',
    role: activeRole || 'Member',
    avatar: currentUser?.photoUrl || '',
  };

  const {
    messages,
    members,
    typingUsers,
    isLoading,
    isConnected,
    sendMessage,
    addReaction,
    deleteMessage,
    sendTyping,
  } = useMinistryRealtime(activeMinistryId, currentUserInfo);

  // Auto scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const isLeaderOrAdmin =
    activeRole === 'SYSTEM_ADMIN' ||
    activeRole === 'MANAGER' ||
    activeRole === 'PASTOR' ||
    activeRole === 'MINISTRY_LEADER';

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (membershipError) return;
    if (!inputText.trim() && !selectedScripture) return;

    const textToSend = inputText.trim() || 'Shared scripture encouragement';
    const scripture = selectedScripture;

    setInputText('');
    setSelectedScripture('');
    setShowScripturePicker(false);
    setShowEmojiPicker(false);

    await sendMessage(textToSend, scripture || undefined);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (membershipError) return;
    setInputText(e.target.value);
    sendTyping(e.target.value.length > 0);
  };

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    await supabaseMinistryService.addMinistryMember(
      activeMinistryId,
      `usr-${Date.now()}`,
      newMemberRole,
      newMemberName.trim()
    );

    setNewMemberName('');
    setShowAddMemberModal(false);
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150"
    >
      <div
        className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col transition-all duration-200 ${
          isFullscreen
            ? 'fixed inset-2 sm:inset-4 rounded-3xl w-auto h-auto'
            : 'rounded-3xl max-w-4xl w-full h-[85vh] max-h-[750px]'
        }`}
      >
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">
                  {activeMinistry?.name || 'Ministry Live Fellowship Chat'}
                </h2>
                <RealtimeConnectionIndicator
                  channelName={`ministry-chat-health-${activeMinistryId}`}
                  tableName="ministry_chat_messages"
                  variant="pill"
                />
              </div>
              <p className="text-xs text-indigo-200">
                Live sync active • Department: {activeMinistry?.category || 'Service & Worship'} • {members.length || 1} Registered Members
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onSwitchToVideo && (
              <button
                onClick={() => onSwitchToVideo(activeMinistryId)}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                title="Launch Video Conference for this Ministry"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                Join Video Meeting
              </button>
            )}

            <button
              onClick={() => setShowParticipantsList(!showParticipantsList)}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                showParticipantsList
                  ? 'bg-white/20 text-white border-white/30'
                  : 'bg-white/5 text-slate-300 hover:text-white border-white/10'
              }`}
              title="Toggle Roster / Members"
            >
              <Users className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-white/5 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer hidden sm:block"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Channels Tab Bar */}
        <div className="px-4 py-2 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto shrink-0">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 shrink-0">
            Ministries:
          </span>
          {ministries.map((min) => {
            const isCurrent = min.id === activeMinistryId;
            return (
              <button
                key={min.id}
                onClick={() => setActiveMinistryId(min.id)}
                className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                  isCurrent
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700'
                }`}
              >
                <span>{min.name}</span>
                {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />}
              </button>
            );
          })}
        </div>

        {/* Main Content Layout */}
        <div className="flex-1 flex overflow-hidden">
          {/* Chat Messages Feed */}
          <div className="flex-1 flex flex-col min-w-0 bg-slate-50 dark:bg-slate-950">
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
              {membershipError ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-rose-100 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 flex items-center justify-center text-rose-600 dark:text-rose-400 shadow-sm">
                    <ShieldAlert className="w-7 h-7" />
                  </div>
                  <div className="space-y-1.5 max-w-sm">
                    <h4 className="text-sm font-bold text-rose-900 dark:text-rose-200">
                      Channel Membership Required
                    </h4>
                    <p className="text-xs text-rose-700 dark:text-rose-400 leading-relaxed font-medium">
                      {membershipError}
                    </p>
                  </div>
                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 max-w-xs">
                    To join conversations in #{activeMinistry?.name || 'this ministry'}, request enrollment from the ministry director or church leadership.
                  </div>
                </div>
              ) : isLoading ? (
                <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                  <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mr-2" />
                  Connecting to Supabase Realtime channel...
                </div>
              ) : messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-2">
                  <MessageSquare className="w-10 h-10 text-slate-300 dark:text-slate-700" />
                  <p className="text-xs font-semibold">No fellowship messages in this channel yet.</p>
                  <p className="text-[11px] text-slate-400 max-w-sm">
                    Be the first to share an encouragement, prayer note, or rehearsal update with your ministry team!
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isMe = msg.senderEmail === currentUserInfo.email || msg.senderName === currentUserInfo.name;
                  const canDelete = isMe || isLeaderOrAdmin;

                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-2.5 max-w-[85%] group ${isMe ? 'ml-auto flex-row-reverse' : ''}`}
                    >
                      <img
                        src={msg.senderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'}
                        alt={msg.senderName}
                        className="w-8 h-8 rounded-full object-cover shrink-0 ring-2 ring-indigo-500/20"
                      />

                      <div className="space-y-1">
                        <div className={`flex items-center gap-2 text-[11px] ${isMe ? 'justify-end' : ''}`}>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{msg.senderName}</span>
                          <span className="px-1.5 py-0.2 rounded-md text-[9px] font-extrabold uppercase tracking-wider bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                            {msg.senderRole}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          {canDelete && (
                            <button
                              onClick={() => deleteMessage(msg.id)}
                              className="opacity-0 group-hover:opacity-100 text-rose-400 hover:text-rose-600 p-0.5 rounded transition-opacity"
                              title="Delete message"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>

                        <div
                          className={`p-3 rounded-2xl text-xs space-y-2 shadow-xs ${
                            isMe
                              ? 'bg-indigo-600 text-white rounded-tr-xs'
                              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-tl-xs'
                          }`}
                        >
                          {/* Scripture Reference Quote if attached */}
                          {msg.scriptureRef && (
                            <div
                              className={`p-2.5 rounded-xl border text-[11px] font-serif leading-relaxed ${
                                isMe
                                  ? 'bg-indigo-700/60 border-indigo-400/40 text-indigo-100'
                                  : 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200'
                              }`}
                            >
                              <div className="flex items-center gap-1 font-sans font-bold text-[10px] uppercase tracking-wider opacity-90 mb-0.5">
                                <BookOpen className="w-3 h-3" />
                                Scripture Reference
                              </div>
                              {msg.scriptureRef}
                            </div>
                          )}

                          <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                        </div>

                        {/* Reaction Bar */}
                        <div className={`flex items-center gap-1 text-[11px] ${isMe ? 'justify-end' : ''}`}>
                          {msg.reactions?.map((r, i) => (
                            <button
                              key={i}
                              onClick={() => addReaction(msg.id, r.emoji)}
                              className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                            >
                              <span>{r.emoji}</span>
                              <span>{r.count}</span>
                            </button>
                          ))}

                          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                            {['🙏', '❤️', '🙌'].map((em) => (
                              <button
                                key={em}
                                onClick={() => addReaction(msg.id, em)}
                                className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-800 text-[11px] cursor-pointer"
                              >
                                {em}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Typing Indicator */}
            {typingUsers.length > 0 && (
              <div className="px-4 py-1 text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold italic animate-pulse">
                {typingUsers.join(', ')} is typing...
              </div>
            )}

            {/* Scripture Selector Drawer */}
            {showScripturePicker && (
              <div className="p-3 bg-amber-50 dark:bg-slate-900 border-t border-amber-200 dark:border-slate-800 space-y-2 animate-in slide-in-from-bottom-3 duration-150">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    Quick Scripture Insertion
                  </span>
                  <button
                    onClick={() => setShowScripturePicker(false)}
                    className="text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-32 overflow-y-auto">
                  {QUICK_SCRIPTURES.map((sc, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setSelectedScripture(`${sc.ref} — "${sc.text}"`);
                        setShowScripturePicker(false);
                      }}
                      className="p-2 text-left rounded-xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-slate-700 hover:border-amber-400 text-xs transition-all cursor-pointer space-y-0.5"
                    >
                      <p className="font-bold text-amber-800 dark:text-amber-300 text-[11px]">{sc.ref}</p>
                      <p className="text-[10px] text-slate-600 dark:text-slate-400 line-clamp-1">{sc.text}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Selected Scripture Attachment Badge */}
            {selectedScripture && (
              <div className="px-4 py-2 bg-amber-100/70 dark:bg-amber-950/40 border-t border-amber-300 dark:border-amber-900/60 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200 font-medium">
                <span className="truncate pr-2 font-serif">📖 {selectedScripture}</span>
                <button
                  onClick={() => setSelectedScripture('')}
                  className="text-amber-700 hover:text-amber-900 dark:text-amber-300 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Input Bar */}
            <form onSubmit={handleSendMessage} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setShowScripturePicker(!showScripturePicker)}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  showScripturePicker
                    ? 'bg-amber-100 border-amber-400 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                    : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-indigo-600'
                }`}
                title="Insert Holy Scripture"
              >
                <BookOpen className="w-4 h-4" />
              </button>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-indigo-600 cursor-pointer"
                >
                  <Smile className="w-4 h-4" />
                </button>

                {showEmojiPicker && (
                  <div className="absolute bottom-12 left-0 z-10 p-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xl grid grid-cols-4 gap-1.5 animate-in fade-in zoom-in-95">
                    {EMOJI_LIST.map((em) => (
                      <button
                        key={em}
                        type="button"
                        onClick={() => {
                          setInputText((prev) => prev + em);
                          setShowEmojiPicker(false);
                        }}
                        className="p-2 text-lg hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl cursor-pointer"
                      >
                        {em}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <input
                type="text"
                value={inputText}
                onChange={handleInputChange}
                disabled={!!membershipError}
                placeholder={
                  membershipError
                    ? 'Channel access restricted to enrolled members'
                    : `Message #${activeMinistry?.name || 'ministry-team'} in realtime...`
                }
                className="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:bg-slate-100 dark:disabled:bg-slate-900 disabled:cursor-not-allowed"
              />

              <button
                type="submit"
                disabled={!!membershipError || (!inputText.trim() && !selectedScripture)}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Send</span>
              </button>
            </form>
          </div>

          {/* Right Drawer: Ministry Members Roster & Management */}
          {showParticipantsList && (
            <div className="w-72 border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4 overflow-y-auto shrink-0 animate-in slide-in-from-right-4 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                    Ministry Roster ({members.length})
                  </span>
                  <p className="text-[10px] text-slate-400">Persistent Supabase storage</p>
                </div>
                <button
                  onClick={() => setShowParticipantsList(false)}
                  className="text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {isLeaderOrAdmin && (
                <button
                  onClick={() => setShowAddMemberModal(true)}
                  className="w-full py-2 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 text-xs font-bold border border-indigo-200 dark:border-indigo-800/60 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  Add Member to Ministry
                </button>
              )}

              {/* Members List */}
              <div className="space-y-2 text-xs">
                {members.length === 0 ? (
                  <p className="text-[11px] text-slate-400 italic">No registered members found.</p>
                ) : (
                  members.map((mem) => (
                    <div
                      key={mem.id}
                      className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-800/80"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={mem.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'}
                          className="w-7 h-7 rounded-full object-cover"
                          alt={mem.userName}
                        />
                        <div>
                          <p className="font-bold text-[11px] text-slate-900 dark:text-white leading-tight">
                            {mem.userName}
                          </p>
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded-md ${
                              mem.role === 'Leader'
                                ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                                : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                            }`}
                          >
                            {mem.role}
                          </span>
                        </div>
                      </div>
                      <span className="w-2 h-2 rounded-full bg-emerald-500" title="Active" />
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal: Add Member to Ministry */}
        {showAddMemberModal && (
          <div className="fixed inset-0 z-60 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-4 animate-in zoom-in-95">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-indigo-600" />
                  Add Ministry Member
                </h3>
                <button onClick={() => setShowAddMemberModal(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleAddMember} className="space-y-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                    Member Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    placeholder="e.g. Samuel Yohannes"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                    Ministry Role
                  </label>
                  <select
                    value={newMemberRole}
                    onChange={(e) => setNewMemberRole(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    <option value="Member">Regular Member</option>
                    <option value="Volunteer">Volunteer / Assistant</option>
                    <option value="CoLeader">Co-Leader</option>
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddMemberModal(false)}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xs cursor-pointer"
                  >
                    Add Member
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
