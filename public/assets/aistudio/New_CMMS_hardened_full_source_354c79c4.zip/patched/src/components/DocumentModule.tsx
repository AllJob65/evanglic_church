import React, { useState, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { DocumentItem } from '../types';
import { ActionMenu } from './ui/ActionMenu';
import {
  FileText,
  Plus,
  Download,
  X,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Maximize,
  Printer,
  RotateCcw,
  Eye,
  Trash2,
  FolderPlus,
} from 'lucide-react';
const dataURLtoBlobUrl = (dataUrl: string): string => {
  if (!dataUrl || !dataUrl.includes(',')) return '';
  try {
    const arr = dataUrl.split(',');
    const mime = arr[0]?.match(/:(.*?);/)?.[1] || 'application/pdf';
    const bstr = atob(arr[1] || '');
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    const blob = new Blob([u8arr], { type: mime });
    return URL.createObjectURL(blob);
  } catch {
    return '';
  }
};

export const PdfViewer = ({ fileUrl }: { fileUrl: string }) => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);

  useEffect(() => {
    if (fileUrl.startsWith('data:application/pdf')) {
      const url = dataURLtoBlobUrl(fileUrl);
      setBlobUrl(url);

      // Clean up memory when component unmounts
      return () => URL.revokeObjectURL(url);
    } else {
      setBlobUrl(fileUrl);
    }
  }, [fileUrl]);

  if (!blobUrl) return <div>Loading PDF...</div>;

  return (
    <iframe
      src={blobUrl}
      className="w-full h-[600px] border-0 rounded-lg shadow"
      title="PDF Viewer"
    />
  );
};
export const DocumentPreviewer = ({ fileUrl, fileType }: { fileUrl: string; fileType: string }) => {
  const normalizedType = fileType.toLowerCase();

  // Universal Google Docs Embed Viewer for PPTX, PPT, DOC, DOCX
  if (['pptx', 'ppt', 'doc', 'docx'].includes(normalizedType)) {
    // If it's a base64 data URL, render message to download or use local preview
    if (fileUrl.startsWith('data:')) {
      return (
        <div className="flex flex-col items-center justify-center h-[600px] bg-slate-900 text-white rounded-lg p-6 text-center space-y-4">
          <FileText className="w-16 h-16 text-blue-400 animate-pulse" />
          <h3 className="text-lg font-bold">Office Document Selected ({fileType.toUpperCase()})</h3>
          <p className="text-sm text-slate-400 max-w-md">
            Direct browser preview for local base64 Office files is restricted. Please use public file URLs or click below to download and view.
          </p>
          <a
            href={fileUrl}
            download={`document.${normalizedType}`}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-white font-semibold shadow-md transition"
          >
            Download File
          </a>
        </div>
      );
    }

    const embedUrl = `https://docs.google.com/gview?url=${encodeURIComponent(fileUrl)}&embedded=true`;
    return (
      <iframe
        src={embedUrl}
        className="w-full h-[600px] border-0 rounded-lg shadow"
        title="Document Presentation Preview"
      />
    );
  }

  // Image preview fallback
  if (['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(normalizedType)) {
    return (
      <div className="w-full h-[600px] flex items-center justify-center bg-slate-950 rounded-lg overflow-hidden">
        <img src={fileUrl} alt="Document Preview" className="max-w-full max-h-full object-contain" />
      </div>
    );
  }

  // PDF or native browser supported renderers
  return (
    <iframe
      src={fileUrl}
      className="w-full h-[600px] border-0 rounded-lg shadow"
      title="Standard Document Preview"
    />
  );
};

export const DocumentModule: React.FC = () => {
  const { documents, addDocument, deleteDocument, permissions } = useCMMS();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [categories, setCategories] = useState<string[]>([
    'All',
    'Sermon Archive',
    'Constitution & Bylaws',
    'Financial Audit',
    'Policy Manual',
    'Certificate Template',
  ]);
  const [newCatName, setNewCatName] = useState('');
  const [isAddingCategory, setIsAddingCategory] = useState(false);

  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Document Reader & Viewer State
  const [activeDoc, setActiveDoc] = useState<DocumentItem | null>(null);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);

  // Upload Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string>('Sermon Archive');
  const [fileUrl, setFileUrl] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [fileFormat, setFileFormat] = useState<string>('PDF');
  const [fileSizeMb, setFileSizeMb] = useState<number>(1.5);

  const filteredDocs =
    selectedCategory === 'All'
      ? documents
      : documents.filter((d) => d.category === selectedCategory);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      setFileSizeMb(parseFloat((file.size / (1024 * 1024)).toFixed(2)));
      const ext = file.name.split('.').pop()?.toUpperCase() || 'PDF';
      if (['JPG', 'JPEG', 'PNG', 'WEBP'].includes(ext)) {
        setFileFormat('JPEG');
      } else if (['PPTX', 'PPT'].includes(ext)) {
        setFileFormat('PPTX');
      } else if (['DOCX', 'DOC'].includes(ext)) {
        setFileFormat('DOCX');
      } else {
        setFileFormat(ext);
      }

      const reader = new FileReader();
      reader.onload = (evt) => {
        setFileUrl(evt.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    const newDoc: DocumentItem = {
      id: `doc-${Date.now().toString().slice(-4)}`,
      title,
      category: category as any,
      fileFormat: fileFormat as any,
      fileSizeMb: fileSizeMb || 2.4,
      uploadedBy: 'Church Admin',
      uploadDate: new Date().toISOString().split('T')[0],
      isConfidential: false,
      version: 'v1.0',
      tags: [category],
      downloadCount: 0,
      fileUrl: fileUrl || undefined,
    };

    addDocument(newDoc);
    setIsUploadModalOpen(false);
    setTitle('');
    setFileUrl('');
    setFileName('');
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCatName && !categories.includes(newCatName)) {
      setCategories([...categories, newCatName]);
      setNewCatName('');
      setIsAddingCategory(false);
    }
  };

  const handleRemoveCategory = (catToRemove: string) => {
    if (catToRemove === 'All') return;
    setCategories(categories.filter((c) => c !== catToRemove));
    if (selectedCategory === catToRemove) {
      setSelectedCategory('All');
    }
  };

  const handleResetViewer = () => {
    setZoomLevel(100);
    setRotation(0);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Document Vault & Official Paper Records</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
              {documents.length} Archived Files
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Store, view, and download church documents (PDF, PPTX, DOCX, JPEG/JPG) securely from your device.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {permissions.canEditMembers && (
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Upload Church Document
            </button>
          )}
        </div>
      </div>

      {/* Document Ledger & Categories */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <h3 className="font-bold text-base text-slate-900 dark:text-white">Document Ledger</h3>

          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl text-[11px]">
            {categories.map((cat) => (
              <div key={cat} className="flex items-center gap-1">
                <button
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {cat}
                </button>
                {cat !== 'All' && permissions.canEditMembers && (
                  <button
                    onClick={() => handleRemoveCategory(cat)}
                    className="p-1 text-slate-400 hover:text-rose-500 rounded-md transition-colors"
                    title={`Remove ${cat} category`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}

            {permissions.canEditMembers && !isAddingCategory && (
              <button
                onClick={() => setIsAddingCategory(true)}
                className="px-2.5 py-1 bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 rounded-lg font-bold flex items-center gap-1 hover:bg-blue-200 cursor-pointer"
              >
                <FolderPlus className="w-3.5 h-3.5" /> + Add Category
              </button>
            )}

            {isAddingCategory && (
              <form onSubmit={handleAddCategory} className="flex items-center gap-1">
                <input
                  type="text"
                  placeholder="Category Name"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="px-2 py-0.5 rounded-md border border-blue-400 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white"
                  autoFocus
                />
                <button type="submit" className="px-2 py-0.5 bg-blue-600 text-white rounded-md font-bold text-[10px]">
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddingCategory(false)}
                  className="p-0.5 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Document Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredDocs.map((doc) => (
            <div
              key={doc.id}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                    doc.fileFormat === 'PDF'
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                      : doc.fileFormat === 'PPTX'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      : doc.fileFormat === 'DOCX'
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                      : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                  }`}
                >
                  {doc.fileFormat}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">{doc.title}</h4>
                  <p className="text-slate-500">
                    {doc.category} • {doc.fileSizeMb} MB • {doc.version}
                  </p>
                  <p className="text-[10px] text-slate-400">Uploaded: {doc.uploadDate}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <ActionMenu
                  recordTitle={doc.title}
                  primaryAction={{
                    id: 'view-doc',
                    label: 'View',
                    icon: <Eye className="w-3.5 h-3.5" />,
                    onClick: () => setActiveDoc(doc),
                  }}
                  secondaryActions={[
                    {
                      id: 'download-doc',
                      label: 'Download File',
                      icon: <Download className="w-3.5 h-3.5 text-emerald-600" />,
                      onClick: () => {
                        if (doc.fileUrl) {
                          const link = document.createElement('a');
                          link.href = doc.fileUrl;
                          link.download = `${doc.title}.${doc.fileFormat.toLowerCase()}`;
                          document.body.appendChild(link);
                          link.click();
                          document.body.removeChild(link);
                        } else {
                          alert(`Downloading ${doc.title} file...`);
                        }
                      },
                    },
                    ...(permissions.canEditMembers
                      ? [
                          {
                            id: 'delete-doc',
                            label: 'Delete Document',
                            icon: <Trash2 className="w-3.5 h-3.5" />,
                            variant: 'danger' as const,
                            dividerBefore: true,
                            onClick: () => deleteDocument(doc.id),
                          },
                        ]
                      : []),
                  ]}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* DOCUMENT READER & VIEWER MODAL */}
      {activeDoc && (
        <div className={`fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex flex-col ${isFullScreen ? 'p-0' : 'p-4 sm:p-8'}`}>
          <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-2xl flex flex-col flex-1 overflow-hidden">
            {/* Viewer Header Toolbar */}
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-500" />
                <div>
                  <h3 className="font-extrabold text-sm text-white truncate max-w-md">{activeDoc.title}</h3>
                  <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                    {activeDoc.fileFormat} Reader • {activeDoc.category}
                  </span>
                </div>
              </div>

              {/* Transformation Controls Toolbar */}
              <div className="flex flex-wrap items-center gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
                <button
                  onClick={() => setZoomLevel((z) => Math.min(z + 25, 300))}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                  title="Zoom In"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>

                <span className="text-[11px] font-bold font-mono px-1.5 text-blue-400">{zoomLevel}%</span>

                <button
                  onClick={() => setZoomLevel((z) => Math.max(z - 25, 25))}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>

                <div className="h-4 w-px bg-slate-800 my-auto" />

                <button
                  onClick={() => setRotation((r) => (r + 90) % 360)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                  title="Rotate 90 Clockwise"
                >
                  <RotateCw className="w-4 h-4" />
                </button>

                <button
                  onClick={handleResetViewer}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                  title="Reset Transform"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <div className="h-4 w-px bg-slate-800 my-auto" />

                <button
                  onClick={() => setIsFullScreen(!isFullScreen)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                  title="Toggle Fullscreen"
                >
                  <Maximize className="w-4 h-4" />
                </button>

                <button
                  onClick={handlePrint}
                  className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer"
                  title="Print Paper Document"
                >
                  <Printer className="w-4 h-4" />
                </button>

                {activeDoc.fileUrl && (
                  <a
                    href={activeDoc.fileUrl}
                    download={`${activeDoc.title}.${activeDoc.fileFormat.toLowerCase()}`}
                    className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold cursor-pointer flex items-center gap-1 px-2.5 text-xs"
                  >
                    <Download className="w-3.5 h-3.5" /> Download
                  </a>
                )}
              </div>

              <button
                onClick={() => setActiveDoc(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Render Stage Area */}
            <div className="flex-1 overflow-auto p-4 sm:p-8 bg-slate-950 flex items-center justify-center relative select-none">
              <div
                style={{
                  transform: `scale(${zoomLevel / 100}) rotate(${rotation}deg)`,
                  transition: 'transform 0.2s ease-out',
                }}
                className="w-full h-full max-w-5xl flex justify-center items-center"
              >
                {activeDoc.fileUrl ? (
                  <DocumentPreviewer fileUrl={activeDoc.fileUrl} fileType={activeDoc.fileFormat} />
                ) : (
                  <div className="bg-white text-slate-900 rounded-xl p-10 sm:p-14 shadow-2xl border border-slate-200 font-sans max-w-2xl w-full space-y-6">
                    <div className="flex items-center justify-between border-b pb-4">
                      <span
                        className={`px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider ${
                          activeDoc.fileFormat === 'PPTX'
                            ? 'bg-amber-100 text-amber-800'
                            : activeDoc.fileFormat === 'DOCX'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {activeDoc.fileFormat} Document Presentation
                      </span>
                      <span className="text-xs font-bold text-slate-500">{activeDoc.version}</span>
                    </div>

                    <div className="text-center space-y-2 py-4">
                      <h1 className="text-2xl font-black text-slate-900">{activeDoc.title}</h1>
                      <p className="text-xs font-semibold text-slate-500">
                        Category: {activeDoc.category} • Uploaded on {activeDoc.uploadDate}
                      </p>
                    </div>

                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs leading-relaxed">
                      <h3 className="font-extrabold text-slate-800 text-sm">Official Document Content Summary:</h3>
                      <p className="text-slate-700">
                        This document record ({activeDoc.title}) is registered in the Document Vault.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Document Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Upload Church Document</h3>
              <button onClick={() => setIsUploadModalOpen(false)} className="text-slate-400 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadDoc} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 2026 Annual Ministry Plan"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {categories
                    .filter((c) => c !== 'All')
                    .map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Select File from Device (pptx, pdf, docx, jpeg, jpg, png)</label>
                <input
                  type="file"
                  accept=".pdf,.pptx,.ppt,.docx,.doc,.jpg,.jpeg,.png"
                  required
                  onChange={handleFileChange}
                  className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
                {fileName && (
                  <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
                    Selected: {fileName} ({fileFormat} • {fileSizeMb} MB)
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-semibold shadow-md cursor-pointer"
                >
                  Upload File
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};