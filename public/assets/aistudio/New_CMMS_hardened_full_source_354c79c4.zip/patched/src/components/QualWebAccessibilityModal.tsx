import React, { useState, useEffect } from 'react';
import { qualWeb, QualWebReport, QualWebRuleResult } from '../services/qualweb';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Download,
  Filter,
  Eye,
  Wrench,
  HelpCircle,
  Check,
  X,
  Layers,
  Code,
  ExternalLink,
  Zap,
} from 'lucide-react';

interface QualWebModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QualWebAccessibilityModal: React.FC<QualWebModalProps> = ({ isOpen, onClose }) => {
  const [report, setReport] = useState<QualWebReport | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedPrinciple, setSelectedPrinciple] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedRule, setSelectedRule] = useState<QualWebRuleResult | null>(null);
  const [fixSuccessMsg, setFixSuccessMsg] = useState('');

  const runAudit = () => {
    setIsScanning(true);
    setTimeout(() => {
      const result = qualWeb.evaluateCurrentDOM();
      setReport(result);
      if (result.rules.length > 0) {
        setSelectedRule(result.rules[0]);
      }
      setIsScanning(false);
    }, 400);
  };

  useEffect(() => {
    if (isOpen) {
      runAudit();
    }
  }, [isOpen]);

  const handleAutoFix = (ruleCode: string) => {
    qualWeb.autoFixIssue(ruleCode);
    setFixSuccessMsg(`Auto-fix applied for rule ${ruleCode}! Rescanning DOM...`);
    setTimeout(() => {
      runAudit();
      setFixSuccessMsg('');
    }, 800);
  };

  const handleExportJson = () => {
    if (!report) return;
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `QualWeb_WCAG_Audit_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  if (!isOpen) return null;

  const filteredRules = report?.rules.filter((rule) => {
    const matchesPrinciple = selectedPrinciple === 'All' ? true : rule.principle === selectedPrinciple;
    const matchesStatus = statusFilter === 'All' ? true : rule.status === statusFilter;
    return matchesPrinciple && matchesStatus;
  }) || [];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="qualweb-title"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-5xl w-full h-[90vh] border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-950 text-white flex items-center justify-between border-b border-emerald-800/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-inner">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="qualweb-title" className="text-lg sm:text-xl font-black tracking-tight">
                  QualWeb WCAG 2.1 / 2.2 Accessibility Engine
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/30 text-emerald-200 border border-emerald-400/40">
                  ACT-Rules Official Spec
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                Automated accessibility compliance testing for perceivability, operability, understandability, and robustness.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runAudit}
              disabled={isScanning}
              aria-label="Re-run QualWeb accessibility audit"
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Rescan Page</span>
            </button>

            <button
              onClick={handleExportJson}
              aria-label="Export QualWeb EARL Audit JSON"
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export EARL</span>
            </button>

            <button
              onClick={onClose}
              aria-label="Close QualWeb Modal"
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Score & Summary Metrics Bar */}
        {report && (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 p-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-xs">
            {/* Overall Score */}
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-base shadow-xs ${
                  report.score >= 90
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                }`}
              >
                {report.score}%
              </div>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">QualWeb Score</p>
                <p className="font-extrabold text-sm text-slate-900 dark:text-white">{report.wcagLevel}</p>
              </div>
            </div>

            {/* Passed Rules */}
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Passed Tests</p>
                <p className="font-extrabold text-base text-emerald-600 dark:text-emerald-400">
                  {report.passedCount} Rules
                </p>
              </div>
            </div>

            {/* Failed Rules */}
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400">
                <XCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Violations</p>
                <p className="font-extrabold text-base text-rose-600 dark:text-rose-400">
                  {report.failedCount} Issues
                </p>
              </div>
            </div>

            {/* Warnings */}
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Warnings</p>
                <p className="font-extrabold text-base text-amber-600 dark:text-amber-400">
                  {report.warningCount} Items
                </p>
              </div>
            </div>

            {/* Total Evaluated */}
            <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-3 col-span-2 sm:col-span-1">
              <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Evaluated</p>
                <p className="font-extrabold text-base text-indigo-600 dark:text-indigo-400">
                  {report.totalRules} ACT Rules
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Feedback Alert if Auto-Fix applied */}
        {fixSuccessMsg && (
          <div className="mx-4 mt-3 p-3 bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-600 animate-bounce" />
            <span>{fixSuccessMsg}</span>
          </div>
        )}

        {/* Filter Controls Bar */}
        <div className="px-4 py-2.5 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Principle Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            {['All', 'Perceivable', 'Operable', 'Understandable', 'Robust'].map((principle) => (
              <button
                key={principle}
                onClick={() => setSelectedPrinciple(principle)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  selectedPrinciple === principle
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {principle}
              </button>
            ))}
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-semibold">Filter:</span>
            {['All', 'passed', 'failed', 'warning'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 rounded-lg font-bold capitalize cursor-pointer ${
                  statusFilter === status
                    ? 'bg-slate-800 text-white dark:bg-white dark:text-slate-900'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content Split View: Rules List & Rule Detail */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Left Column: Rules List */}
          <div className="md:col-span-5 border-r border-slate-200 dark:border-slate-800 overflow-y-auto p-3 space-y-2">
            {filteredRules.map((rule) => {
              const isSelected = selectedRule?.code === rule.code;
              return (
                <div
                  key={rule.code}
                  onClick={() => setSelectedRule(rule)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-500 shadow-xs'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-black text-emerald-600 dark:text-emerald-400">
                        {rule.code}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded font-bold uppercase bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        Level {rule.level}
                      </span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                        rule.status === 'passed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : rule.status === 'failed'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {rule.status === 'passed' && <CheckCircle2 className="w-3 h-3" />}
                      {rule.status === 'failed' && <XCircle className="w-3 h-3" />}
                      {rule.status === 'warning' && <AlertTriangle className="w-3 h-3" />}
                      {rule.status}
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-slate-900 dark:text-white mt-1.5 truncate">
                    {rule.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                    {rule.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Right Column: Rule Deep-Dive & Auto-Fix */}
          <div className="md:col-span-7 overflow-y-auto p-4 sm:p-6 bg-slate-50/50 dark:bg-slate-900/50">
            {selectedRule ? (
              <div className="space-y-5">
                {/* Rule Header */}
                <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-sm font-black text-emerald-600 dark:text-emerald-400">
                      {selectedRule.code} • {selectedRule.name}
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      Principle: {selectedRule.principle}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    {selectedRule.description}
                  </p>
                </div>

                {/* Failed Elements or Success State */}
                {selectedRule.status === 'passed' ? (
                  <div className="p-6 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 flex items-center gap-4">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <div>
                      <h4 className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                        Rule Conformance Verified
                      </h4>
                      <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-0.5">
                        All {selectedRule.elementsCount} tested elements strictly satisfy WCAG 2.1 Level {selectedRule.level} criteria.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                        Detected Element Violations ({selectedRule.failedElements.length})
                      </h4>

                      <button
                        onClick={() => handleAutoFix(selectedRule.code)}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Wrench className="w-3.5 h-3.5" />
                        <span>Apply Auto-Fix</span>
                      </button>
                    </div>

                    {selectedRule.failedElements.map((elem, idx) => (
                      <div
                        key={idx}
                        className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900/60 shadow-xs space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xs font-bold text-rose-600 dark:text-rose-400">
                            {elem.selector}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 rounded-full">
                            Violation
                          </span>
                        </div>

                        <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                          {elem.issue}
                        </p>

                        <div className="p-2.5 bg-slate-950 text-slate-200 rounded-xl font-mono text-[11px] overflow-x-auto">
                          <code>{elem.html}</code>
                        </div>

                        <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900/50 text-xs text-blue-800 dark:text-blue-300">
                          <strong>W3C Recommendation:</strong> {elem.recommendation}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                Select a rule from the left panel to inspect details.
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-500 dark:text-slate-400">
            Evaluation Engine: QualWeb Core v3.4 • Conformance: WCAG 2.1 / 2.2 ACT Rules
          </span>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold shadow-md cursor-pointer"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};
