import React, { useState, useEffect, useCallback } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { apiService } from '../services/api';
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Clock,
  ShieldCheck,
  HardDrive,
  FileCheck,
  Trash2,
  Lock,
  Layers,
  FileText,
  Calendar,
  Save,
} from 'lucide-react';

interface BackupRecord {
  id: string;
  filename: string;
  date: string;
  size: string;
  bytes: number;
  type: 'Full System' | 'Incremental' | 'Differential' | 'Pre-Restore Auto Snapshot' | 'Pre-Reset Auto Snapshot' | 'Scheduled';
  destination: 'Local Storage';
  status: 'Completed' | 'Verified' | 'Failed';
  triggeredBy: string;
  checksum?: string;
}

export const BackupModule: React.FC = () => {
  const { language } = useCMMS();
  const { userRole } = useAuth();
  const { activeRole, reloadFromBackend } = useCMMS() as any;

  // SYSTEM_ADMIN RBAC enforcement
  const isSystemAdmin = userRole === 'SYSTEM_ADMIN' || activeRole === 'SYSTEM_ADMIN';

  // Backup Execution History state
  const [backupHistory, setBackupHistory] = useState<BackupRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(true);

  // Scheduled Policy Settings state
  const [isScheduleEnabled, setIsScheduleEnabled] = useState<boolean>(true);
  const [scheduleFrequency, setScheduleFrequency] = useState<'Daily' | 'Weekly' | 'Monthly'>('Daily');
  const [scheduleTime, setScheduleTime] = useState<string>('02:00');
  const [storageDestination] = useState<'Local Storage'>('Local Storage');
  const [lastRunAt, setLastRunAt] = useState<string | null>(null);
  const [isSavingSchedule, setIsSavingSchedule] = useState<boolean>(false);

  // Operation States
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [isRestoring, setIsRestoring] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
    details?: string[];
  } | null>(null);

  // Restore Modal & Validation Preview States
  const [isRestoreModalOpen, setIsRestoreModalOpen] = useState<boolean>(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [validationStats, setValidationStats] = useState<Record<string, number> | null>(null);
  const [isValidatingFile, setIsValidatingFile] = useState<boolean>(false);

  // Factory Reset Confirmation Modal
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);

  // Load schedule configuration and execution logs from server
  const loadScheduleAndHistory = useCallback(async () => {
    if (!isSystemAdmin) {
      setIsLoadingHistory(false);
      return;
    }
    setIsLoadingHistory(true);
    try {
      const [historyRes, scheduleRes] = await Promise.all([
        apiService.getBackupHistory().catch(() => ({ success: false, history: [] })),
        apiService.getBackupSchedule().catch(() => ({ success: false, schedule: null })),
      ]);

      if (historyRes.success && Array.isArray(historyRes.history)) {
        setBackupHistory(historyRes.history);
      }
      if (scheduleRes.success && scheduleRes.schedule) {
        setIsScheduleEnabled(Boolean(scheduleRes.schedule.enabled));
        setScheduleFrequency(scheduleRes.schedule.frequency || 'Daily');
        setScheduleTime(scheduleRes.schedule.time || '02:00');
        if (scheduleRes.schedule.lastRunAt) {
          setLastRunAt(scheduleRes.schedule.lastRunAt);
        }
      }
    } catch (err: any) {
      console.warn('Failed to load backup data from server:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  }, [isSystemAdmin]);

  useEffect(() => {
    loadScheduleAndHistory();
  }, [loadScheduleAndHistory]);

  // Save Automated Schedule Policy to Server
  const handleSaveSchedule = async () => {
    if (!isSystemAdmin) return;
    setIsSavingSchedule(true);
    setStatusMessage(null);
    try {
      const res = await apiService.updateBackupSchedule({
        enabled: isScheduleEnabled,
        frequency: scheduleFrequency,
        time: scheduleTime,
        destination: 'Local Storage',
      });
      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: `Automated backup policy updated successfully: ${scheduleFrequency} at ${scheduleTime} to Local Server Disk.`,
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `Failed to update schedule: ${err.message || 'Server error'}`,
      });
    } finally {
      setIsSavingSchedule(false);
    }
  };

  // Trigger Real Server-Side Snapshot Creation & Client Download
  const handleTriggerBackup = async (type: 'Full System' | 'Incremental' | 'Differential' = 'Full System') => {
    if (!isSystemAdmin) return;
    setIsExporting(true);
    setStatusMessage(null);
    try {
      const payload = await apiService.triggerServerBackup(type);
      
      // Generate immediate browser download from the server-returned payload
      const jsonStr = JSON.stringify(payload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const filename = `cmms_backup_${type.toLowerCase().replace(/[\s-]+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;

      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setStatusMessage({
        type: 'success',
        text: `Server-side ${type} snapshot archived in backups/ and downloaded successfully.`,
      });

      // Reload real server backup logs
      loadScheduleAndHistory();
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `Server backup creation failed: ${err.message || 'An unexpected error occurred.'}`,
      });
    } finally {
      setIsExporting(false);
    }
  };

  // Step 1 of Restore: Select file & perform server-side dry-run validation against DatabaseSchema
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isSystemAdmin) {
      setStatusMessage({
        type: 'error',
        text: 'Access Denied: Only SYSTEM_ADMIN may perform database restores.',
      });
      return;
    }

    setIsValidatingFile(true);
    setStatusMessage(null);
    setPendingFile(file);

    try {
      // Dry-run validation (confirm = false)
      const previewRes = await apiService.restoreServerBackupFile(file, false);
      if (!previewRes.success) {
        setStatusMessage({
          type: 'error',
          text: previewRes.message || 'Backup file validation failed.',
          details: previewRes.errors,
        });
        setPendingFile(null);
      } else {
        // Validation passed! Open confirmation modal with statistical breakdown
        setValidationStats(previewRes.stats || null);
        setIsRestoreModalOpen(true);
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `Backup verification error: ${err.message || 'Could not validate file.'}`,
      });
      setPendingFile(null);
    } finally {
      setIsValidatingFile(false);
      // Reset input value so re-selecting same file triggers event
      e.target.value = '';
    }
  };

  // Step 2 of Restore: User confirms destructive overwrite -> Real server-side restore
  const handleConfirmRestore = async () => {
    if (!pendingFile || !isSystemAdmin) return;
    setIsRestoring(true);
    try {
      const result = await apiService.restoreServerBackupFile(pendingFile, true);
      if (result.success) {
        setIsRestoreModalOpen(false);
        setPendingFile(null);
        setValidationStats(null);

        // Reload all app collections from server database
        if (typeof reloadFromBackend === 'function') {
          await reloadFromBackend();
        }

        setStatusMessage({
          type: 'success',
          text: `Database state restored successfully! Pre-restore safety snapshot archived: ${result.preRestoreSnapshot}`,
        });

        loadScheduleAndHistory();
      } else {
        setStatusMessage({
          type: 'error',
          text: result.message || 'Restore execution failed.',
          details: result.errors,
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `Server restore failed: ${err.message || 'Unknown server error.'}`,
      });
    } finally {
      setIsRestoring(false);
    }
  };

  // Factory Data Reset with Real Server Pre-Reset Snapshot
  const handleConfirmReset = async () => {
    if (!isSystemAdmin) return;
    setIsResetting(true);
    setStatusMessage(null);
    try {
      const result = await apiService.resetServerDatabase(true);
      if (result.success) {
        setIsResetConfirmOpen(false);

        // Reload all app collections from server database
        if (typeof reloadFromBackend === 'function') {
          await reloadFromBackend();
        }

        setStatusMessage({
          type: 'success',
          text: `Database reset to factory defaults. Pre-reset safety snapshot archived: ${result.preResetSnapshot}`,
        });

        loadScheduleAndHistory();
      } else {
        setStatusMessage({
          type: 'error',
          text: result.message || 'Database reset failed.',
        });
      }
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `Factory reset failed: ${err.message || 'Server error'}`,
      });
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className={`space-y-6 ${language === 'Amharic' || language === 'Tigrigna' ? 'font-amharic' : ''}`}>
      
      {/* HEADER BANNER */}
      <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            Server-Authoritative Disaster Recovery & Data Integrity Engine
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Backup & Disaster Recovery Management
          </h2>
          <p className="text-xs sm:text-sm text-blue-100/80 max-w-2xl">
            Real server-side database snapshots, schema-validated restorations, automated cron scheduling, and atomic file-lock protection.
          </p>
        </div>

        {isSystemAdmin ? (
          <button
            onClick={() => handleTriggerBackup('Full System')}
            disabled={isExporting}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-xl shadow-blue-500/25 flex items-center gap-2 cursor-pointer shrink-0 disabled:opacity-50"
          >
            {isExporting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            <span>{isExporting ? 'Creating Snapshot...' : 'Instant Full Backup'}</span>
          </button>
        ) : (
          <div className="px-4 py-2 bg-amber-500/20 text-amber-200 border border-amber-500/30 rounded-2xl text-xs font-bold flex items-center gap-2">
            <Lock className="w-4 h-4" />
            <span>Read-Only View</span>
          </div>
        )}
      </div>

      {/* RBAC WARNING FOR NON-SYSTEM_ADMINS */}
      {!isSystemAdmin && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs font-semibold flex items-center gap-2.5 shadow-sm">
          <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
          <span>
            Restricted Administrative Access: Database backup triggers, file restorations, automated scheduling, and factory data resets strictly require the <strong>SYSTEM_ADMIN</strong> role.
          </span>
        </div>
      )}

      {/* STATUS ALERT NOTIFICATION */}
      {statusMessage && (
        <div
          className={`p-4 rounded-2xl border text-xs font-bold shadow-md animate-in fade-in space-y-1.5 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/80 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
          {statusMessage.details && statusMessage.details.length > 0 && (
            <ul className="list-disc list-inside pl-6 text-[11px] font-normal text-rose-700 dark:text-rose-300 space-y-0.5">
              {statusMessage.details.slice(0, 5).map((detail, idx) => (
                <li key={idx}>{detail}</li>
              ))}
              {statusMessage.details.length > 5 && (
                <li>...and {statusMessage.details.length - 5} more schema discrepancies.</li>
              )}
            </ul>
          )}
        </div>
      )}

      {/* ACTION GRID: MANUAL BACKUP & RESTORE */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* MANUAL BACKUP CARD */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-md space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="p-2 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded-xl">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Server-Side Backup Triggers
              </h3>
              <p className="text-xs text-slate-500">
                Generate atomic JSON snapshots archived to server disk and stream for local download.
              </p>
            </div>
          </div>

          <div className="space-y-3 pt-1">
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Full System Backup</p>
                <p className="text-[11px] text-slate-500">Includes all 35+ database collections, security configurations, and audit trails</p>
              </div>
              <button
                onClick={() => handleTriggerBackup('Full System')}
                disabled={isExporting || !isSystemAdmin}
                className="px-3.5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 cursor-pointer shadow-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {isExporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                <span>Create & Download</span>
              </button>
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Differential Snapshot</p>
                <p className="text-[11px] text-slate-500">Core operational records (members, attendance, financials, and workflows)</p>
              </div>
              <button
                onClick={() => handleTriggerBackup('Differential')}
                disabled={isExporting || !isSystemAdmin}
                className="px-3.5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 cursor-pointer shadow-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {isExporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                <span>Create & Download</span>
              </button>
            </div>
          </div>
        </div>

        {/* RESTORE BACKUP CARD */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-md space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Restore Database State
              </h3>
              <p className="text-xs text-slate-500">
                Upload and verify a backup file with automatic pre-restore safety snapshot.
              </p>
            </div>
          </div>

          <div className="p-6 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl text-center space-y-3 bg-slate-50/50 dark:bg-slate-800/50">
            <FileCheck className="w-8 h-8 text-emerald-500 mx-auto" />
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Upload Backup JSON Archive
              </p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Validated against full 35+ collection DatabaseSchema before applying
              </p>
            </div>

            {isSystemAdmin ? (
              <label className={`inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all ${isValidatingFile ? 'opacity-50 cursor-wait' : 'cursor-pointer'}`}>
                {isValidatingFile ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                <span>{isValidatingFile ? 'Validating Schema...' : 'Select File to Verify & Restore'}</span>
                <input
                  type="file"
                  accept=".json"
                  disabled={isValidatingFile}
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </label>
            ) : (
              <button
                disabled
                className="inline-flex items-center gap-2 px-4 py-2 bg-slate-300 dark:bg-slate-700 text-slate-500 dark:text-slate-400 font-bold text-xs rounded-xl cursor-not-allowed"
              >
                <Lock className="w-4 h-4" />
                <span>Restricted to SYSTEM_ADMIN</span>
              </button>
            )}
          </div>
        </div>

      </div>

      {/* SCHEDULED BACKUP SETTINGS & FACTORY RESET */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* SCHEDULE CONFIG (8 Cols) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                Automated Background Backup Scheduler
              </h3>
              <p className="text-xs text-slate-500">
                Server-side cron job running independently in background process
              </p>
            </div>
            {isSystemAdmin && (
              <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isScheduleEnabled}
                  onChange={(e) => setIsScheduleEnabled(e.target.checked)}
                  className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                />
                Enable Cron Job
              </label>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Backup Frequency
              </label>
              <select
                value={scheduleFrequency}
                disabled={!isSystemAdmin || !isScheduleEnabled}
                onChange={(e) => setScheduleFrequency(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold disabled:opacity-50"
              >
                <option value="Daily">Daily (Every Midnight)</option>
                <option value="Weekly">Weekly (Sunday Night)</option>
                <option value="Monthly">Monthly (1st Day of Month)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Execution Time (24h)
              </label>
              <input
                type="time"
                value={scheduleTime}
                disabled={!isSystemAdmin || !isScheduleEnabled}
                onChange={(e) => setScheduleTime(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Storage Destination
              </label>
              <select
                value={storageDestination}
                disabled
                className="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300"
              >
                <option value="Local Storage">Local Server Disk (backups/)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
            <div>
              {lastRunAt ? (
                <span>Last automated run: {new Date(lastRunAt).toLocaleString()}</span>
              ) : (
                <span>No automated backups logged yet this session.</span>
              )}
            </div>

            {isSystemAdmin && (
              <button
                onClick={handleSaveSchedule}
                disabled={isSavingSchedule}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
              >
                {isSavingSchedule ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                <span>Save Schedule</span>
              </button>
            )}
          </div>
        </div>

        {/* FACTORY RESET DANGER ZONE (4 Cols) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-rose-200 dark:border-rose-900/50 shadow-md space-y-4">
          <div>
            <h3 className="text-base font-extrabold text-rose-600 dark:text-rose-400 flex items-center gap-2">
              <Trash2 className="w-4 h-4" />
              Factory Reset & Baseline
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Reset database collections back to factory seed dataset with automatic pre-reset snapshot.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={() => setIsResetConfirmOpen(true)}
              disabled={!isSystemAdmin || isResetting}
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-md shadow-rose-500/20 flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Trash2 className="w-4 h-4" />
              <span>Reset System to Defaults</span>
            </button>
          </div>
        </div>

      </div>

      {/* REAL BACKUP EXECUTION HISTORY LOGS TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
              Backup Execution History & Verification Audit
            </h3>
            <p className="text-xs text-slate-500">
              Immutable server-side logs recording every backup, scheduled run, and safety snapshot
            </p>
          </div>

          <button
            type="button"
            onClick={loadScheduleAndHistory}
            disabled={isLoadingHistory}
            aria-label="Refresh history"
            className="min-h-[38px] min-w-[38px] p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer inline-flex items-center justify-center shrink-0"
            title="Refresh history"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingHistory ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-200/80 dark:border-slate-800">
          <table className="cmms-data-table w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 bg-slate-50 dark:bg-slate-800/50 uppercase tracking-wider text-[10px] font-bold">
                <th className="py-2.5 px-3 min-w-[180px]">Filename / Identifier</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Date & Time</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Type</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Destination</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Size</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Triggered By</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Status</th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap sticky right-0 bg-slate-50 dark:bg-slate-800/95 z-10">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-semibold text-slate-800 dark:text-slate-200">
              {backupHistory.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 font-normal">
                    {isLoadingHistory ? 'Loading server backup logs...' : 'No server backups executed yet. Click "Instant Full Backup" above to generate your first snapshot.'}
                  </td>
                </tr>
              ) : (
                backupHistory.map((item) => (
                  <tr key={item.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-3 font-mono font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap">
                      {item.filename}
                    </td>
                    <td className="py-3 px-3 text-slate-500 whitespace-nowrap tabular-nums">{item.date}</td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${
                        item.type.includes('Snapshot')
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : item.type === 'Scheduled'
                          ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      }`}>
                        {item.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400 whitespace-nowrap">{item.destination}</td>
                    <td className="py-3 px-3 text-slate-500 font-mono whitespace-nowrap tabular-nums">{item.size}</td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400 font-normal whitespace-nowrap">{item.triggeredBy}</td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border whitespace-nowrap ${
                        item.status === 'Verified' || item.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-200 dark:border-rose-800'
                      }`}>
                        ✓ {item.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/90 z-10">
                      {item.filename.startsWith('cmms_backup_') && (
                        <a
                          href={`/api/system/backup/download/${encodeURIComponent(item.filename)}`}
                          download={item.filename}
                          className="min-h-[32px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-blue-600 dark:text-blue-400 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Download className="w-3 h-3 shrink-0" />
                          <span>Get</span>
                        </a>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CONFIRM RESTORE MODAL (WITH DETAILED SCHEMA VALIDATION PREVIEW) */}
      {isRestoreModalOpen && validationStats && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 rounded-3xl border border-emerald-800 max-w-lg w-full p-6 space-y-4 text-left animate-in zoom-in-95 duration-150 text-white">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 bg-emerald-950 text-emerald-400 rounded-full flex items-center justify-center border border-emerald-800 shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black">
                  Confirm Database Restoration
                </h3>
                <p className="text-xs text-slate-400">
                  File verified successfully against full 35+ collection DatabaseSchema
                </p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-amber-950/50 border border-amber-800/80 text-amber-200 text-xs space-y-1">
              <p className="font-bold flex items-center gap-1.5 text-amber-300">
                <AlertCircle className="w-4 h-4 shrink-0" />
                Destructive Action Confirmation Required
              </p>
              <p className="text-[11px] text-amber-200/90 font-normal">
                Applying this restore will overwrite your current active database collections. A server-side pre-restore safety snapshot will automatically be archived before applying.
              </p>
            </div>

            <div>
              <p className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                Collections & Records in Backup:
              </p>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-slate-950/70 p-3 rounded-2xl border border-slate-800 max-h-48 overflow-y-auto">
                {Object.entries(validationStats).map(([key, count]) => (
                  <div key={key} className="flex justify-between py-0.5 border-b border-slate-800/60">
                    <span className="text-slate-400">{key}:</span>
                    <span className="text-emerald-400 font-bold">{count}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  setIsRestoreModalOpen(false);
                  setPendingFile(null);
                  setValidationStats(null);
                }}
                disabled={isRestoring}
                className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-bold text-xs hover:bg-slate-800 cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmRestore}
                disabled={isRestoring}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isRestoring ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                <span>{isRestoring ? 'Applying Restore...' : 'Confirm & Restore'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FACTORY RESET CONFIRMATION MODAL */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 rounded-3xl border border-rose-800 max-w-md w-full p-6 space-y-4 text-center animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 bg-rose-950 text-rose-500 rounded-full flex items-center justify-center mx-auto border border-rose-800">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                Confirm Factory Data Reset
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Are you sure you want to reset all current members, attendance, and transactions back to factory default values? An automatic pre-reset snapshot will be saved in backups/ first.
              </p>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setIsResetConfirmOpen(false)}
                disabled={isResetting}
                className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-bold text-xs hover:bg-slate-800 cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReset}
                disabled={isResetting}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs hover:bg-rose-500 shadow-lg shadow-rose-500/20 cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isResetting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                <span>{isResetting ? 'Resetting...' : 'Reset Data'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
