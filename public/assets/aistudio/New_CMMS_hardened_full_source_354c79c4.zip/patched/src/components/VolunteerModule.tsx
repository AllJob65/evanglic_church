import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { VolunteerShift } from '../types';
import {
  Sparkles,
  Plus,
  Award,
  Clock,
  Calendar,
  CheckCircle2,
  X,
  UserCheck,
} from 'lucide-react';

export const VolunteerModule: React.FC = () => {
  const { volunteerShifts, addVolunteerShift, members, ministries, permissions } = useCMMS();
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);

  const [volunteerMemberId, setVolunteerMemberId] = useState(members[0]?.id || '');
  const [ministryId, setMinistryId] = useState(ministries[0]?.id || '');
  const [roleTitle, setRoleTitle] = useState('Sanctuary Usher / Hospitality');
  const [shiftDate, setShiftDate] = useState('2026-08-09');

  const handleCreateShift = (e: React.FormEvent) => {
    e.preventDefault();
    const mem = members.find((m) => m.id === volunteerMemberId);
    const min = ministries.find((m) => m.id === ministryId);

    const newShift: VolunteerShift = {
      id: `vs-${Date.now().toString().slice(-4)}`,
      volunteerMemberId: mem?.id || 'mem-101',
      volunteerName: mem ? `${mem.firstName} ${mem.lastName}` : 'Volunteer Member',
      ministryId: min?.id || 'min-001',
      ministryName: min?.name || 'Worship Ministry',
      roleTitle,
      shiftDate,
      startTime: '08:00 AM',
      endTime: '01:00 PM',
      status: 'Confirmed',
      hoursLogged: 5,
    };

    addVolunteerShift(newShift);
    setIsScheduleModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Volunteer & Workforce Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200">
              {volunteerShifts.length} Scheduled Shifts
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Skills inventory, Sunday duty rosters, substitute replacements, and volunteer milestone hours recognition.
          </p>
        </div>

        {permissions.canEditMembers && (
          <button
            onClick={() => setIsScheduleModalOpen(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Schedule Duty Roster Shift
          </button>
        )}
      </div>

      {/* Roster Table */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">Scheduled Duty Roster</h3>

        <div className="space-y-3">
          {volunteerShifts.map((vs) => (
            <div
              key={vs.id}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{vs.volunteerName}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200">
                    {vs.roleTitle}
                  </span>
                </div>
                <p className="text-slate-500">Ministry: {vs.ministryName}</p>
                <p className="text-[11px] text-slate-400">
                  Shift: {vs.shiftDate} ({vs.startTime} - {vs.endTime})
                </p>
              </div>

              <div className="text-right shrink-0">
                <span className="px-2 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 block">
                  {vs.status}
                </span>
                <span className="text-[10px] text-slate-400 mt-1 block">Logged: {vs.hoursLogged} Hours</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Milestone Recognition Section */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
          <Award className="w-5 h-5 text-amber-500" />
          Volunteer Milestone Service Badges
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-center gap-3">
            <Award className="w-8 h-8 text-amber-500 shrink-0" />
            <div>
              <h4 className="font-bold text-slate-900 dark:text-white">100+ Hours Milestone</h4>
              <p className="text-amber-700 dark:text-amber-300 font-semibold">
                {volunteerShifts.find((v) => (v.hoursLogged || 0) >= 100)?.volunteerName || 'No volunteer yet'}
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 flex items-center gap-3">
            <Award className="w-8 h-8 text-purple-500 shrink-0" />
            <div>
              <h4 className="font-bold text-slate-900 dark:text-white">50+ Hours Milestone</h4>
              <p className="text-purple-700 dark:text-purple-300 font-semibold">
                {volunteerShifts.find((v) => (v.hoursLogged || 0) >= 50)?.volunteerName || 'No volunteer yet'}
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 flex items-center gap-3">
            <Award className="w-8 h-8 text-blue-500 shrink-0" />
            <div>
              <h4 className="font-bold text-slate-900 dark:text-white">25+ Hours Milestone</h4>
              <p className="text-blue-700 dark:text-blue-300 font-semibold">
                {volunteerShifts.find((v) => (v.hoursLogged || 0) >= 25)?.volunteerName || 'No volunteer yet'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Shift Modal */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Schedule Duty Roster Shift</h3>
              <button onClick={() => setIsScheduleModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateShift} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1">Select Volunteer</label>
                <select
                  value={volunteerMemberId}
                  onChange={(e) => setVolunteerMemberId(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Ministry Department</label>
                <select
                  value={ministryId}
                  onChange={(e) => setMinistryId(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {ministries.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Role Title</label>
                <input
                  type="text"
                  required
                  value={roleTitle}
                  onChange={(e) => setRoleTitle(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Shift Date</label>
                <input
                  type="date"
                  required
                  value={shiftDate}
                  onChange={(e) => setShiftDate(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-semibold">
                  Assign Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
