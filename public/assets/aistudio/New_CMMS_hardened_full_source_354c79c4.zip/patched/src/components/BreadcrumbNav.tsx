import React from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  ChevronRight,
  Home,
  LayoutDashboard,
  Shield,
  Database,
  Settings,
  Activity,
  BookOpen,
  Users,
  FileText,
  Smartphone,
  CheckCircle2,
  Sparkles,
  Building2,
  UsersRound,
  Calendar,
  Send,
  HeartHandshake,
  UserMinus,
  TrendingUp,
  ShieldCheck,
  ShieldAlert,
  Heart,
  Layers,
  FolderTree,
  UserCheck,
  Crown,
} from 'lucide-react';

interface Props {
  customPath?: string[];
}

export const BreadcrumbNav: React.FC<Props> = ({ customPath }) => {
  const { activeModule, dashboardSubTab, backupSubTab, setActiveModule, setDashboardSubTab, activeRole, t } = useCMMS();

  // Helper mapping from module to readable breadcrumbs
  const getBreadcrumbs = (): { label: string; icon?: React.ComponentType<{ className?: string }>; action?: () => void }[] => {
    if (customPath && customPath.length > 0) {
      return customPath.map((item) => ({
        label: item,
      }));
    }

    switch (activeModule) {
      case 'dashboard': {
        const subTabLabels: Record<string, string> = {
          overview: 'Overview KPIs',
          backup_restore: 'Backup & Restore Insights',
          system_health: 'System Health & Telemetry',
          readiness: 'Readiness Overview',
        };
        const subLabel = subTabLabels[dashboardSubTab] || 'Overview KPIs';
        if (dashboardSubTab === 'backup_restore' && backupSubTab) {
          return [
            { label: 'CMMS Dashboard', icon: LayoutDashboard, action: () => setActiveModule('dashboard') },
            { label: 'Backup & Recovery', icon: Database, action: () => setDashboardSubTab('backup_restore') },
            { label: backupSubTab === 'scheduled' ? 'Scheduled Backups' : backupSubTab === 'history' ? 'Backup History' : 'Insights' },
          ];
        }
        return [
          { label: 'CMMS Dashboard', icon: LayoutDashboard, action: () => setActiveModule('dashboard') },
          { label: subLabel },
        ];
      }
      case 'my_profile':
        return [{ label: 'Account & Security', icon: Shield }, { label: 'My User Profile' }];
      case 'approvals':
        return [{ label: 'Pastoral Governance', icon: ShieldAlert }, { label: 'Approval Queue & Review' }];
      case 'members':
        return [{ label: 'Core Administration', icon: Users }, { label: 'Member Directory & Profile' }];
      case 'families':
        return [{ label: 'Core Administration', icon: Heart }, { label: 'Households & Families' }];
      case 'branches':
        return [{ label: 'Core Administration', icon: Building2 }, { label: 'Multi-Campus Branches' }];
      case 'ministries':
        return [{ label: 'Core Administration', icon: UsersRound }, { label: 'Ministry & Groups' }];
      case 'attendance':
        return [{ label: 'Operations', icon: UserCheck }, { label: 'Attendance & Check-in' }];
      case 'devotions':
        return [{ label: 'Operations & Engagement', icon: BookOpen }, { label: 'Daily Devotion & Holy Bible' }];
      case 'events':
        return [{ label: 'Operations & Engagement', icon: Calendar }, { label: 'Event Ticketing & Planning' }];
      case 'communications':
        return [{ label: 'Operations & Engagement', icon: Send }, { label: 'Multi-Channel Communications' }];
      case 'prayer_counseling':
        return [{ label: 'Pastoral Care & Service', icon: HeartHandshake }, { label: 'Prayer & Counseling Portal' }];
      case 'visitations':
        return [{ label: 'Pastoral Care & Service', icon: UserMinus }, { label: 'Visitations & Shepherd Care' }];
      case 'assets':
        return [{ label: 'Documents & Archives', icon: Layers }, { label: 'Asset & Facilities Registry' }];
      case 'documents':
        return [{ label: 'Documents & Archives', icon: FolderTree }, { label: 'Document Vault & Archive' }];
      case 'lms':
        return [{ label: 'Documents & Archives', icon: BookOpen }, { label: 'LMS Discipleship Academy' }];
      case 'reports':
        return [{ label: 'Intelligence & Analytics', icon: Activity }, { label: 'Executive Reports & Analytics' }];
      case 'predictive':
        return [{ label: 'Intelligence & Analytics', icon: TrendingUp }, { label: 'Predictive Growth Engine' }];
      case 'backup':
        return [{ label: 'Intelligence & Governance', icon: Database }, { label: 'Backup & PostgreSQL Engine' }];
      case 'security_audit':
        return [{ label: 'Intelligence & Governance', icon: ShieldCheck }, { label: 'Security & 2FA Governance' }];
      case 'settings':
        return [{ label: 'System Settings', icon: Settings }, { label: 'Branding & Configuration' }];
      case 'mobile_preview':
        return [{ label: 'System Tools', icon: Smartphone }, { label: 'Mobile App Live Preview' }];
      default:
        return [{ label: 'CMMS System', icon: LayoutDashboard }, { label: 'Active Workspace' }];
    }
  };

  const crumbs = getBreadcrumbs();

  return (
    <nav
      aria-label="Breadcrumb Navigation"
      className="mb-3 sm:mb-4 bg-transparent px-1 sm:px-2 py-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-400 flex items-center justify-between flex-wrap gap-2 transition-all min-w-0 max-w-full overflow-x-auto scrollbar-none"
    >
      <div className="flex items-center flex-wrap sm:flex-nowrap gap-1 sm:gap-1.5 min-w-0 max-w-full">
        <button
          onClick={() => setActiveModule('dashboard')}
          className="inline-flex items-center gap-1.5 min-h-[36px] sm:min-h-[32px] px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white font-semibold cursor-pointer transition-colors shrink-0 text-xs sm:text-sm"
          title="Go to Dashboard Home"
        >
          <Home className="w-4 h-4 text-slate-500 dark:text-slate-400" />
          <span className="hidden xs:inline">{t('breadcrumb.home', 'Home')}</span>
        </button>

        {crumbs.map((crumb, idx) => {
          const isLast = idx === crumbs.length - 1;
          const Icon = crumb.icon;

          return (
            <React.Fragment key={idx}>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 dark:text-slate-600 shrink-0" />
              {crumb.action && !isLast ? (
                <button
                  onClick={crumb.action}
                  className="min-h-[36px] sm:min-h-[32px] px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-medium cursor-pointer truncate max-w-[140px] sm:max-w-[220px] flex items-center gap-1.5 transition-colors text-xs sm:text-sm"
                >
                  {Icon && <Icon className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />}
                  <span className="truncate">{t(crumb.label, crumb.label)}</span>
                </button>
              ) : (
                <span
                  className={`truncate max-w-[160px] sm:max-w-[300px] flex items-center gap-1.5 ${
                    isLast
                      ? 'font-bold text-slate-900 dark:text-slate-100 px-2 py-1 rounded-lg text-xs sm:text-sm'
                      : 'font-medium text-slate-600 dark:text-slate-400 text-xs sm:text-sm'
                  }`}
                >
                  {Icon && <Icon className={`w-3.5 h-3.5 shrink-0 ${isLast ? 'text-slate-700 dark:text-slate-300' : 'text-slate-400 dark:text-slate-500'}`} />}
                  <span className="truncate">{t(crumb.label, crumb.label)}</span>
                </span>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Role & Live Context Indicator in Breadcrumb right side */}
      <div className="hidden md:flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 shrink-0 ml-auto">
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-400 text-xs font-semibold border border-slate-200 dark:border-slate-800">
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400 dark:bg-slate-500" />
          <span>{t('breadcrumb.active_role', 'Active Role')}: <strong className="text-slate-800 dark:text-slate-200">{t(activeRole, activeRole)}</strong></span>
        </span>
      </div>
    </nav>
  );
};

