import React, { useState, useRef, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Settings,
  Building,
  Globe,
  Save,
  CheckCircle2,
  Users,
  UserPlus,
  Trash2,
  KeyRound,
  Download,
  Upload,
  RefreshCw,
  AlertTriangle,
  Image as ImageIcon,
  Church,
  Crown,
  Database,
  ShieldCheck,
  Sparkles,
  Sun,
  Moon,
  ExternalLink,
  Lock,
  Flame,
  BookOpen,
  Heart,
  FileCode,
  Layers,
  Copy,
  Check,
  Edit3,
  Sliders,
  DollarSign,
  CheckSquare,
  Search,
  Filter,
  Building2,
  Phone,
  ShieldAlert,
  ShieldOff,
  Info,
  Eye,
  EyeOff,
  Clock,
  Activity,
  UserCheck,
  UserX,
  Ban,
  LogOut,
  QrCode,
  History,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { UserRole, SystemUser, AuditLog } from '../types';
import { normalizeUserRole, computeEffectivePermissions, ROLES_CATALOG, ROLE_PERMISSIONS } from '../utils/rbac';
import { apiService } from '../services/api';
import { triggerGoogleTranslate } from '../utils/googleTranslate';
import { ApiHubModule } from './ApiHubModule';
import { SecurityAuditModule } from './SecurityAuditModule';
import { RealtimeConnectionIndicator } from './RealtimeConnectionIndicator';
import { ActionMenu } from './ui/ActionMenu';
import { Terminal } from 'lucide-react';

const ALL_SYSTEM_ROLES: UserRole[] = [
  'SYSTEM_ADMIN',
  'MANAGER',
  'PASTOR',
  'MINISTRY_LEADER',
  'REGULAR_MEMBER',
];

const ROLE_DISPLAY_LABELS: Record<UserRole, string> = {
  SYSTEM_ADMIN: 'Super Administrator',
  MANAGER: 'Branch Manager',
  PASTOR: 'Pastor & Counselor',
  MINISTRY_LEADER: 'Ministry Leader',
  REGULAR_MEMBER: 'Regular Member',
};

const formatLastLogin = (val?: string | null): string => {
  if (!val || val === 'Never') return 'Never';
  const d = new Date(val);
  if (isNaN(d.getTime())) return val;
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};



export const SettingsModule: React.FC = () => {
  const {
    language,
    setLanguage,
    themeMode,
    setThemeMode,
    addAuditLog,
    systemUsers,
    addSystemUser,
    updateSystemUser,
    removeSystemUser,
    resetUserPassword,
    updateUserRole,
    toggleUserMfa,
    exportSystemBackupJSON,
    restoreSystemBackupJSON,
    resetToDefaultData,
    reloadFromBackend,
    branches,
    churchLogoUrl,
    setChurchLogoUrl,
    systemName,
    setSystemName,
    churchMotto,
    setChurchMotto,
    faviconUrl,
    setFaviconUrl,
    titleBadge,
    setTitleBadge,
    primaryColorHex,
    accentColorHex,
    loginPanelColorHex,
    updateFullBranding,
    permissions,
    activeRole,
  } = useCMMS();

  const isSuperAdmin = normalizeUserRole(activeRole) === 'SYSTEM_ADMIN';

  // Sub-tabs for clean organization (default to 'users' so the System User Accounts table is visible immediately)
  type SettingsSubTabId = 'branding' | 'postgres' | 'api_hub' | 'users' | 'security' | 'backup' | 'localization';
  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTabId>('users');
  const [swapDirection, setSwapDirection] = useState<'left' | 'right'>('right');
  const [isSwapping, setIsSwapping] = useState(false);
  const tabButtonRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  const settingsSubTabs: Array<{
    id: SettingsSubTabId;
    label: string;
    shortLabel: string;
    icon: React.ReactNode;
    superAdminOnly?: boolean;
  }> = [
    {
      id: 'branding',
      label: 'Favicon & System Branding',
      shortLabel: 'Branding',
      icon: <Sparkles className="w-4 h-4 shrink-0" />,
      superAdminOnly: true,
    },
    {
      id: 'postgres',
      label: 'PostgreSQL Production Engine',
      shortLabel: 'DB Engine',
      icon: <Database className="w-4 h-4 shrink-0" />,
      superAdminOnly: true,
    },
    {
      id: 'api_hub',
      label: 'API & Integrations Hub',
      shortLabel: 'API Hub',
      icon: <Terminal className="w-4 h-4 shrink-0" />,
      superAdminOnly: true,
    },
    {
      id: 'users',
      label: 'System User Accounts & RBAC',
      shortLabel: 'Users & RBAC',
      icon: <Users className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'security',
      label: '2FA & Security Governance',
      shortLabel: '2FA & Security',
      icon: <ShieldCheck className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'backup',
      label: 'JSON Backup & Restore',
      shortLabel: 'Backup & Restore',
      icon: <Download className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'localization',
      label: 'Language & Regional Localization',
      shortLabel: 'Localization',
      icon: <Globe className="w-4 h-4 shrink-0" />,
    },
  ];

  const visibleSettingsSubTabs = settingsSubTabs.filter((tab) => !tab.superAdminOnly || isSuperAdmin);
  const currentSubTabIndex = Math.max(
    0,
    visibleSettingsSubTabs.findIndex((tab) => tab.id === activeSubTab)
  );
  const currentSubTabObj = visibleSettingsSubTabs[currentSubTabIndex] || visibleSettingsSubTabs[0];

  const handleSwapSubTab = (nextId: SettingsSubTabId) => {
    if (nextId === activeSubTab) return;
    const oldIdx = visibleSettingsSubTabs.findIndex((t) => t.id === activeSubTab);
    const newIdx = visibleSettingsSubTabs.findIndex((t) => t.id === nextId);
    setSwapDirection(newIdx >= oldIdx ? 'right' : 'left');
    setIsSwapping(true);
    setActiveSubTab(nextId);

    requestAnimationFrame(() => {
      const btn = tabButtonRefs.current[nextId];
      if (btn && typeof btn.scrollIntoView === 'function') {
        btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    });
    setTimeout(() => setIsSwapping(false), 280);
  };

  useEffect(() => {
    const btn = tabButtonRefs.current[activeSubTab];
    if (btn && typeof btn.scrollIntoView === 'function') {
      btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }, [activeSubTab]);

  const handleSelectLanguage = (langName: string) => {
    setLanguage(langName);
    const l = langName.toLowerCase().trim();
    const isInternal = (
      l === 'en' || l === 'english' ||
      l === 'am' || l === 'amharic' || l === 'አማርኛ' ||
      l === 'ti' || l === 'tigrigna' || l === 'ትግርኛ' ||
      l === 'om' || l === 'afaan oromoo' || l === 'oromo'
    );
    if (!isInternal) {
      triggerGoogleTranslate(langName);
    }
    setActionMessage(`System language updated to ${langName}`);
    setTimeout(() => setActionMessage(''), 2500);
  };

  // Branding Form State
  const [brandingSystemName, setBrandingSystemName] = useState(systemName || 'CMMS');
  const [brandingMotto, setBrandingMotto] = useState(churchMotto || 'Equipping Believers • Empowering Generations');
  const [brandingTitleBadge, setBrandingTitleBadge] = useState(titleBadge || 'Sovereign Portal');
  const [brandingPrimaryColor, setBrandingPrimaryColor] = useState(primaryColorHex || '#2563eb');
  const [brandingAccentColor, setBrandingAccentColor] = useState(accentColorHex || '#7c3aed');
  const [brandingLoginPanelColor, setBrandingLoginPanelColor] = useState(loginPanelColorHex || '#0f172a');
  const [logoInputUrl, setLogoInputUrl] = useState(churchLogoUrl || '');
  const [faviconInputUrl, setFaviconInputUrl] = useState(faviconUrl || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Sync branding form inputs if context values load asynchronously from backend
  useEffect(() => {
    if (systemName) setBrandingSystemName(systemName);
    if (churchMotto) setBrandingMotto(churchMotto);
    if (titleBadge) setBrandingTitleBadge(titleBadge);
    if (primaryColorHex) setBrandingPrimaryColor(primaryColorHex);
    if (accentColorHex) setBrandingAccentColor(accentColorHex);
    if (loginPanelColorHex) setBrandingLoginPanelColor(loginPanelColorHex);
    if (churchLogoUrl !== undefined) setLogoInputUrl(churchLogoUrl);
    if (faviconUrl) setFaviconInputUrl(faviconUrl);
  }, [systemName, churchMotto, titleBadge, primaryColorHex, accentColorHex, loginPanelColorHex, churchLogoUrl, faviconUrl]);
  const [actionMessage, setActionMessage] = useState('');
  const [copiedSql, setCopiedSql] = useState(false);

  // Church Profile
  const [churchLegalName, setChurchLegalName] = useState('Church Management System');
  const [taxId, setTaxId] = useState('501-C3-9823419');
  const [address, setAddress] = useState('777 Grace Boulevard, Suite 100, Atlanta, GA 30301');
  const [phone, setPhone] = useState('+1 (404) 555-0199');

  // Users Filter & Search
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('ALL');
  const [userStatusFilter, setUserStatusFilter] = useState('ALL');
  const [userCampusFilter, setUserCampusFilter] = useState('ALL');
  const [isRefreshingUsers, setIsRefreshingUsers] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // Add User State
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [createUserError, setCreateUserError] = useState<string | null>(null);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userPhone, setUserPhone] = useState('');
  const [userRole, setUserRole] = useState<UserRole>('MANAGER');
  const [userAdditionalRoles, setUserAdditionalRoles] = useState<UserRole[]>([]);
  const [userBranch, setUserBranch] = useState(branches[0]?.name || 'Grace Cathedral Headquarters');
  const [userBranches, setUserBranches] = useState<string[]>([branches[0]?.name || 'Grace Cathedral Headquarters']);
  const [userMinistry, setUserMinistry] = useState('Pastoral & Counseling');
  const [userTempPassword, setUserTempPassword] = useState('');
  const [showUserTempPassword, setShowUserTempPassword] = useState(false);
  const [createdUserModal, setCreatedUserModal] = useState<{
    isOpen: boolean;
    email: string;
    name: string;
    role: string;
    tempPassword: string;
    expiresAt?: string;
    isCopied?: boolean;
  } | null>(null);

  const [resetModal, setResetModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    tempPassword: string;
    isCopied: boolean;
    isConfirmed: boolean;
    error?: string | null;
  } | null>(null);
  const [resetModalPasswordInput, setResetModalPasswordInput] = useState('');
  const [isResetting, setIsResetting] = useState(false);

  // Two-Factor Authentication Modal State (Enable with TOTP QR enrollment + verification / Disable 2FA)
  const [twoFaModal, setTwoFaModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    action: 'enable' | 'disable';
    step: 'confirm' | 'verify' | 'enroll_verify' | 'completed';
    enrollment?: {
      factorId: string;
      challengeId: string;
      secret: string;
      uri: string;
      issuer: string;
      accountName: string;
      verified: boolean;
    };
    secret?: string;
    qrUrl?: string;
    disableReason?: string;
    totpCode: string;
    secretCopied?: boolean;
    isProcessing?: boolean;
    error?: string | null;
  } | null>(null);

  // Account Status / Force Password Change / Revoke Sessions / Delete Confirmation Modal
  const [securityActionModal, setSecurityActionModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    type: 'activate' | 'disable' | 'suspend' | 'force_password' | 'clear_force_password' | 'revoke_sessions' | 'delete_user';
    reason: string;
    isProcessing: boolean;
    error: string | null;
  } | null>(null);

  // Dedicated Status Lifecycle Modal
  const [statusModal, setStatusModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    targetStatus: 'Active' | 'Disabled' | 'Suspended' | 'Pending';
    reason: string;
    isProcessing: boolean;
    error: string | null;
  } | null>(null);

  // Dedicated Role Assignment Modal
  const [roleModal, setRoleModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    primaryRole: UserRole;
    additionalRoles: UserRole[];
    isProcessing: boolean;
    error: string | null;
  } | null>(null);

  // Dedicated Force Password Change Modal
  const [forcePwdModal, setForcePwdModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    isProcessing: boolean;
    error: string | null;
  } | null>(null);

  // Dedicated Revoke Active Sessions Modal
  const [revokeSessionsModal, setRevokeSessionsModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    isProcessing: boolean;
    error: string | null;
  } | null>(null);

  // Security Events Modal State
  const [securityEventsModal, setSecurityEventsModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    events: AuditLog[];
    isLoading: boolean;
    error: string | null;
  } | null>(null);

  // Effective Permissions & RBAC Inspector Modal State
  const [effectivePermissionsModal, setEffectivePermissionsModal] = useState<{
    isOpen: boolean;
    user: SystemUser | null;
    isLoading: boolean;
    error: string | null;
    data: {
      primaryRole: UserRole;
      additionalRoles: UserRole[];
      roles: UserRole[];
      userRoles: Array<{ role: UserRole; isPrimary: boolean; assignedAt?: string; assignedBy?: string }>;
      roleDetails?: Array<{ role: UserRole; label: string; isPrimary: boolean; permissions: string[]; explicitDenyRules: string[] }>;
      effectivePermissions: string[];
      deniedPermissions: string[];
      branchId?: string;
      branchName?: string;
      branchIds?: string[];
      assignedCampuses?: string[];
    } | null;
  } | null>(null);

  const [rbacBusyUserId, setRbacBusyUserId] = useState<string | null>(null);

  const handleOpenEffectivePermissionsModal = async (usr: SystemUser) => {
    const localComputed = computeEffectivePermissions(
      usr.role,
      usr.additionalRoles || [],
      usr.deniedPermissions || []
    );
    setEffectivePermissionsModal({
      isOpen: true,
      user: usr,
      isLoading: true,
      error: null,
      data: {
        primaryRole: localComputed.primaryRole,
        additionalRoles: localComputed.additionalRoles,
        roles: localComputed.allRoles,
        userRoles: localComputed.userRoles,
        effectivePermissions: usr.effectivePermissions || localComputed.effectivePermissions,
        deniedPermissions: localComputed.deniedPermissions,
        branchId: usr.branchId,
        branchName: usr.branchName,
        branchIds: usr.branchIds,
        assignedCampuses: usr.assignedCampuses,
      },
    });
    try {
      const res = await apiService.getUserEffectivePermissions(usr.id);
      setEffectivePermissionsModal((prev) =>
        prev
          ? {
              ...prev,
              isLoading: false,
              data: {
                primaryRole: res.primaryRole,
                additionalRoles: res.additionalRoles,
                roles: res.roles,
                userRoles: res.userRoles,
                roleDetails: res.roleDetails,
                effectivePermissions: res.effectivePermissions,
                deniedPermissions: res.deniedPermissions,
                branchId: res.branchId,
                branchName: res.branchName,
                branchIds: res.branchIds,
                assignedCampuses: res.assignedCampuses,
              },
            }
          : null
      );
    } catch (err: any) {
      setEffectivePermissionsModal((prev) =>
        prev
          ? {
              ...prev,
              isLoading: false,
              error: err?.message || null,
            }
          : null
      );
    }
  };

  const handleAddRoleToUser = async (usr: SystemUser, roleToAdd: UserRole) => {
    if (!roleToAdd || rbacBusyUserId === usr.id) return;
    setRbacBusyUserId(usr.id);
    setErrorBanner(null);
    try {
      const res = await apiService.addUserRole(usr.id, roleToAdd);
      if (res.user) {
        updateSystemUser({
          ...usr,
          ...res.user,
        });
      }
      setActionMessage(res.message || `Added role ${roleToAdd} to ${usr.name} without overwriting primary role.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setErrorBanner(err?.message || `Failed to add role ${roleToAdd}.`);
    } finally {
      setRbacBusyUserId(null);
    }
  };

  const handleRemoveRoleFromUser = async (usr: SystemUser, roleToRemove: UserRole) => {
    if (!roleToRemove || rbacBusyUserId === usr.id) return;
    setRbacBusyUserId(usr.id);
    setErrorBanner(null);
    try {
      const res = await apiService.removeUserRole(usr.id, roleToRemove);
      if (res.user) {
        updateSystemUser({
          ...usr,
          ...res.user,
        });
      }
      setActionMessage(res.message || `Removed additional role ${roleToRemove} from ${usr.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setErrorBanner(err?.message || `Failed to remove role ${roleToRemove}.`);
    } finally {
      setRbacBusyUserId(null);
    }
  };

  const handleAddCampusToUser = async (usr: SystemUser, campusName: string) => {
    if (!campusName || rbacBusyUserId === usr.id) return;
    setRbacBusyUserId(usr.id);
    setErrorBanner(null);
    try {
      const branchObj = branches.find((b) => b.name === campusName);
      const res = await apiService.addUserCampus(usr.id, {
        campusName,
        branchId: branchObj?.id,
      });
      if (res.user) {
        updateSystemUser({
          ...usr,
          ...res.user,
        });
      }
      setActionMessage(res.message || `Assigned campus ${campusName} to ${usr.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setErrorBanner(err?.message || `Failed to assign campus ${campusName}.`);
    } finally {
      setRbacBusyUserId(null);
    }
  };

  const handleRemoveCampusFromUser = async (usr: SystemUser, campusName: string) => {
    if (!campusName || rbacBusyUserId === usr.id) return;
    setRbacBusyUserId(usr.id);
    setErrorBanner(null);
    try {
      const res = await apiService.removeUserCampus(usr.id, campusName);
      if (res.user) {
        updateSystemUser({
          ...usr,
          ...res.user,
        });
      }
      setActionMessage(res.message || `Removed campus ${campusName} from ${usr.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setErrorBanner(err?.message || `Failed to remove campus ${campusName}.`);
    } finally {
      setRbacBusyUserId(null);
    }
  };

  const handleOpenStatusModal = (
    usr: SystemUser,
    targetStatus: 'Active' | 'Disabled' | 'Suspended' | 'Pending'
  ) => {
    setStatusModal({
      isOpen: true,
      user: usr,
      targetStatus,
      reason: '',
      isProcessing: false,
      error: null,
    });
  };

  const handleConfirmStatusChange = async () => {
    if (!statusModal?.user || statusModal.isProcessing) return;
    const { user, targetStatus, reason } = statusModal;
    setStatusModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));
    try {
      const apiStatus: 'Active' | 'Inactive' | 'Suspended' | 'Pending' =
        targetStatus === 'Disabled' ? 'Inactive' : targetStatus;
      const res = await apiService.updateUserStatus(user.id, apiStatus, reason);
      updateSystemUser({
        ...user,
        ...(res.user || {}),
        status: targetStatus as any,
      });
      setStatusModal(null);
      setActionMessage(res.message || `Account status for ${user.name} updated to ${targetStatus}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setStatusModal((prev) =>
        prev
          ? {
              ...prev,
              isProcessing: false,
              error: err?.message || 'Failed to update account status.',
            }
          : null
      );
    }
  };

  const handleRequestInlineRoleChange = (usr: SystemUser, newRole: UserRole) => {
    setRoleModal({
      isOpen: true,
      user: usr,
      primaryRole: newRole,
      additionalRoles: (usr.additionalRoles || []).filter((r) => r !== newRole),
      isProcessing: false,
      error: null,
    });
  };

  const handleConfirmRoleChange = async () => {
    if (!roleModal?.user || roleModal.isProcessing) return;
    const { user, primaryRole, additionalRoles } = roleModal;
    setRoleModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));
    try {
      const updated = await apiService.updateUserRole(user.id, primaryRole, additionalRoles);
      updateSystemUser({
        ...user,
        ...updated,
        role: primaryRole,
        additionalRoles,
      });
      setRoleModal(null);
      setActionMessage(`Assigned role ${primaryRole} to ${user.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setRoleModal((prev) =>
        prev
          ? {
              ...prev,
              isProcessing: false,
              error: err?.message || 'Failed to assign role on server.',
            }
          : null
      );
    }
  };

  const handleOpenForcePwdModal = (usr: SystemUser) => {
    setForcePwdModal({
      isOpen: true,
      user: usr,
      isProcessing: false,
      error: null,
    });
  };

  const handleConfirmForcePasswordChange = async () => {
    if (!forcePwdModal?.user || forcePwdModal.isProcessing) return;
    const { user } = forcePwdModal;
    setForcePwdModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));
    try {
      const res = await apiService.forceUserPasswordChange(user.id, true);
      updateSystemUser({
        ...user,
        ...(res.user || {}),
        must_change_password: true,
        mustChangePassword: true,
      });
      setForcePwdModal(null);
      setActionMessage(res.message || `Forced password change enabled for ${user.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setForcePwdModal((prev) =>
        prev
          ? {
              ...prev,
              isProcessing: false,
              error: err?.message || 'Failed to require password change.',
            }
          : null
      );
    }
  };

  const handleOpenRevokeSessionsModal = (usr: SystemUser) => {
    setRevokeSessionsModal({
      isOpen: true,
      user: usr,
      isProcessing: false,
      error: null,
    });
  };

  const handleConfirmRevokeSessions = async () => {
    if (!revokeSessionsModal?.user || revokeSessionsModal.isProcessing) return;
    const { user } = revokeSessionsModal;
    setRevokeSessionsModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));
    try {
      const res = await apiService.revokeUserSessions(user.id);
      updateSystemUser({
        ...user,
        ...(res.user || {}),
        session_revoked_at: res.sessionRevokedAt,
      });
      setRevokeSessionsModal(null);
      setActionMessage(res.message || `Revoked all active sessions for ${user.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setRevokeSessionsModal((prev) =>
        prev
          ? {
              ...prev,
              isProcessing: false,
              error: err?.message || 'Failed to revoke user sessions.',
            }
          : null
      );
    }
  };

  const [userApprovalRoleLevel, setUserApprovalRoleLevel] = useState('Senior Approver');
  const [userAllowedApprovals, setUserAllowedApprovals] = useState<string[]>([
    'Budget Requests',
    'Purchase Vouchers',
    'Event Grants',
  ]);

  // Edit User State
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [isSavingEditUser, setIsSavingEditUser] = useState(false);
  const [editUserError, setEditUserError] = useState<string | null>(null);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editUserName, setEditUserName] = useState('');
  const [editUserEmail, setEditUserEmail] = useState('');
  const [editUserPhone, setEditUserPhone] = useState('');
  const [editUserRole, setEditUserRole] = useState<UserRole>('MANAGER');
  const [editUserAdditionalRoles, setEditUserAdditionalRoles] = useState<UserRole[]>([]);
  const [editUserStatus, setEditUserStatus] = useState<'Active' | 'Inactive' | 'Suspended' | 'Pending'>('Active');
  const [editUserMfa, setEditUserMfa] = useState(false);
  const [editUserForcePasswordChange, setEditUserForcePasswordChange] = useState(false);
  const [editUserPrimaryBranch, setEditUserPrimaryBranch] = useState('');
  const [editUserBranches, setEditUserBranches] = useState<string[]>([]);
  const [editUserApprovalRoleLevel, setEditUserApprovalRoleLevel] = useState('Standard Staff');
  const [editUserAllowedApprovals, setEditUserAllowedApprovals] = useState<string[]>([]);
  const [editUserNotes, setEditUserNotes] = useState('');

  // File Inputs
  const logoFileInputRef = useRef<HTMLInputElement>(null);
  const faviconFileInputRef = useRef<HTMLInputElement>(null);
  const backupFileInputRef = useRef<HTMLInputElement>(null);

  const handleRefreshUsersFromBackend = async () => {
    setIsRefreshingUsers(true);
    setErrorBanner(null);
    try {
      const freshUsers = await apiService.getUsers();
      if (Array.isArray(freshUsers)) {
        freshUsers.forEach((u) => updateSystemUser(u));
      }
      await reloadFromBackend();
      setActionMessage('Synchronized authoritative user accounts from database.');
      setTimeout(() => setActionMessage(''), 3000);
    } catch (err: any) {
      setErrorBanner(err?.message || 'Failed to refresh system users from backend.');
    } finally {
      setIsRefreshingUsers(false);
    }
  };

  useEffect(() => {
    if (activeSubTab === 'users') {
      apiService
        .getUsers()
        .then((users) => {
          if (Array.isArray(users)) {
            users.forEach((u) => updateSystemUser(u));
          }
        })
        .catch(() => {});
    }
  }, [activeSubTab]);

  const openEditUserModal = (usr: SystemUser) => {
    setEditingUserId(usr.id);
    setEditUserName(usr.name);
    setEditUserEmail(usr.email);
    setEditUserPhone(usr.phone || '+251 91 123 4567');
    setEditUserRole(normalizeUserRole(usr.role));
    setEditUserAdditionalRoles(
      Array.isArray(usr.additionalRoles)
        ? usr.additionalRoles.map((r) => normalizeUserRole(r)).filter((r) => r !== normalizeUserRole(usr.role))
        : []
    );
    setEditUserStatus((usr.status as any) || 'Active');
    setEditUserMfa(Boolean(usr.mfaEnabled ?? usr.isMfaEnabled));
    setEditUserForcePasswordChange(Boolean(usr.must_change_password ?? usr.mustChangePassword));
    const defaultCampuses =
      usr.assignedCampuses && usr.assignedCampuses.length > 0
        ? usr.assignedCampuses
        : [usr.branchName || branches[0]?.name || 'Grace Cathedral Headquarters'];
    setEditUserPrimaryBranch(usr.branchName || defaultCampuses[0] || 'Grace Cathedral Headquarters');
    setEditUserBranches(defaultCampuses);
    setEditUserApprovalRoleLevel(usr.approvalRoleLevel || 'Senior Approver');
    setEditUserAllowedApprovals(
      usr.allowedApprovalTypes || ['Budget Requests', 'Purchase Vouchers', 'Event Grants']
    );
    setEditUserNotes(usr.notes || '');
    setEditUserError(null);
    setIsEditUserModalOpen(true);
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUserId || !editUserName || !editUserEmail || isSavingEditUser) return;

    setIsSavingEditUser(true);
    setEditUserError(null);

    const existingUser = systemUsers.find((u) => u.id === editingUserId);
    const assignedCampuses =
      editUserBranches.length > 0
        ? editUserBranches
        : [editUserPrimaryBranch || branches[0]?.name || 'Grace Cathedral Headquarters'];
    const primaryCampus = editUserPrimaryBranch || assignedCampuses[0] || 'Grace Cathedral Headquarters';

    const payload: Partial<SystemUser> = {
      ...(existingUser || {}),
      id: editingUserId,
      name: editUserName.trim(),
      email: editUserEmail.trim().toLowerCase(),
      phone: editUserPhone.trim(),
      role: editUserRole,
      additionalRoles: editUserAdditionalRoles.filter((r) => r !== editUserRole),
      roles: [editUserRole, ...editUserAdditionalRoles.filter((r) => r !== editUserRole)],
      status: editUserStatus,
      mfaEnabled: editUserMfa,
      isMfaEnabled: editUserMfa,
      must_change_password: editUserForcePasswordChange,
      mustChangePassword: editUserForcePasswordChange,
      branchName: primaryCampus,
      assignedCampuses,
      approvalRoleLevel: editUserApprovalRoleLevel,
      allowedApprovalTypes: editUserAllowedApprovals,
      notes: editUserNotes,
    };

    try {
      const res = await apiService.updateUser(editingUserId, payload);
      const updatedFromServer: SystemUser = res.user || (payload as SystemUser);
      updateSystemUser(updatedFromServer);
      setIsSavingEditUser(false);
      setIsEditUserModalOpen(false);
      setActionMessage(`Saved account, roles, and campus assignments for ${updatedFromServer.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setIsSavingEditUser(false);
      setEditUserError(err?.message || 'Failed to update user account on server.');
    }
  };

  // Generate temporary password helper for staff onboarding
  const generateClientTempPassword = (): string => {
    const uppers = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lowers = 'abcdefghijkmnpqrstuvwxyz';
    const digits = '23456789';
    const specials = '!@#$%^&*';
    const all = uppers + lowers + digits + specials;
    let rand = '';
    rand += uppers[Math.floor(Math.random() * uppers.length)];
    rand += lowers[Math.floor(Math.random() * lowers.length)];
    rand += digits[Math.floor(Math.random() * digits.length)];
    rand += specials[Math.floor(Math.random() * specials.length)];
    for (let i = 0; i < 4; i++) {
      rand += all[Math.floor(Math.random() * all.length)];
    }
    return `CMMS-${rand.split('').sort(() => 0.5 - Math.random()).join('')}`;
  };

  const isAddingUser = isCreatingUser;
  const addUserError = createUserError;
  const setAddUserError = setCreateUserError;
  const isUpdatingUser = isSavingEditUser;
  const updateUserError = editUserError;
  const isUsersLoading = isRefreshingUsers;
  const handleRefreshUsers = handleRefreshUsersFromBackend;
  const refreshAuthoritativeUsers = handleRefreshUsersFromBackend;
  const userPrimaryBranch = userBranch;
  const setUserPrimaryBranch = setUserBranch;
  const generateStrongPassword = () => {
    setUserTempPassword(generateClientTempPassword());
  };

  // Create User with Temporary Password & Mandatory First-Login Change
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName || !userEmail || isCreatingUser) return;
    setIsCreatingUser(true);
    setCreateUserError(null);

    const assigned = userBranches.length > 0 ? userBranches : [userBranch];
    const primaryBranch = userBranch || assigned[0] || 'Grace Cathedral Headquarters';
    const optionalCustomTemp = userTempPassword.trim() || undefined;

    try {
      const created = await apiService.createUser({
        name: userName.trim(),
        email: userEmail.trim().toLowerCase(),
        phone: userPhone.trim() || '+251 91 100 0000',
        role: userRole,
        additionalRoles: userAdditionalRoles.filter((r) => r !== userRole),
        roles: [userRole, ...userAdditionalRoles.filter((r) => r !== userRole)],
        branchName: primaryBranch,
        assignedCampuses: assigned,
        approvalRoleLevel: userApprovalRoleLevel,
        allowedApprovalTypes: userAllowedApprovals,
        mfaEnabled: false,
        isMfaEnabled: false,
        status: 'Active',
        notes: `Ministry: ${userMinistry}`,
        ...(optionalCustomTemp ? { temporaryPassword: optionalCustomTemp } : {}),
        must_change_password: true,
        mustChangePassword: true,
      });

      const { temporaryPassword: returnedTempPassword, ...safeCreatedUser } = created as any;
      addSystemUser(safeCreatedUser);

      setCreatedUserModal({
        isOpen: true,
        email: safeCreatedUser.email || userEmail,
        name: safeCreatedUser.name || userName,
        role: safeCreatedUser.role || userRole,
        tempPassword: returnedTempPassword || optionalCustomTemp || '',
        expiresAt: created.temp_password_expires_at || '24 hours',
        isCopied: false,
      });

      setUserName('');
      setUserEmail('');
      setUserPhone('');
      setUserTempPassword('');
      setUserAdditionalRoles([]);
      setUserBranches([branches[0]?.name || 'Grace Cathedral Headquarters']);
      setIsCreatingUser(false);
      setIsAddUserModalOpen(false);
      setActionMessage('User account provisioned in database with one-time temporary password.');
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setIsCreatingUser(false);
      setCreateUserError(err?.message || 'Failed to create user account on server.');
    }
  };

  const handleInlineRoleChange = async (usr: SystemUser, newRole: UserRole) => {
    try {
      const updated = await apiService.updateUserRole(usr.id, newRole, usr.additionalRoles);
      updateSystemUser({
        ...usr,
        ...updated,
        role: newRole,
      });
      setActionMessage(`Assigned role ${newRole} to ${usr.name}.`);
      setTimeout(() => setActionMessage(''), 3500);
    } catch (err: any) {
      setErrorBanner(err?.message || `Failed to update role for ${usr.name}.`);
    }
  };

  const handleOpenSecurityActionModal = (
    usr: SystemUser,
    type: 'activate' | 'disable' | 'suspend' | 'force_password' | 'clear_force_password' | 'revoke_sessions' | 'delete_user'
  ) => {
    setSecurityActionModal({
      isOpen: true,
      user: usr,
      type,
      reason: '',
      isProcessing: false,
      error: null,
    });
  };

  const handleConfirmSecurityAction = async () => {
    if (!securityActionModal?.user || securityActionModal.isProcessing) return;
    const { user, type, reason } = securityActionModal;
    setSecurityActionModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));

    try {
      if (type === 'activate' || type === 'disable' || type === 'suspend') {
        const targetStatus =
          type === 'activate' ? 'Active' : type === 'disable' ? 'Inactive' : 'Suspended';
        const res = await apiService.updateUserStatus(user.id, targetStatus, reason);
        updateSystemUser({ ...user, ...(res.user || {}), status: targetStatus });
        setActionMessage(res.message || `Account status for ${user.name} set to ${targetStatus}.`);
      } else if (type === 'force_password' || type === 'clear_force_password') {
        const forceFlag = type === 'force_password';
        const res = await apiService.forceUserPasswordChange(user.id, forceFlag);
        updateSystemUser({
          ...user,
          ...(res.user || {}),
          must_change_password: forceFlag,
          mustChangePassword: forceFlag,
        });
        setActionMessage(res.message);
      } else if (type === 'revoke_sessions') {
        const res = await apiService.revokeUserSessions(user.id);
        updateSystemUser({
          ...user,
          ...(res.user || {}),
          session_revoked_at: res.sessionRevokedAt,
        });
        setActionMessage(res.message);
      } else if (type === 'delete_user') {
        await apiService.deleteUser(user.id);
        removeSystemUser(user.id);
        setActionMessage(`User account ${user.email} permanently removed.`);
      }

      setSecurityActionModal(null);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setSecurityActionModal((prev) =>
        prev
          ? {
              ...prev,
              isProcessing: false,
              error: err?.message || 'Operation failed. Please verify administrator permissions.',
            }
          : null
      );
    }
  };

  const handleOpenSecurityEventsModal = async (usr: SystemUser) => {
    setSecurityEventsModal({
      isOpen: true,
      user: usr,
      events: [],
      isLoading: true,
      error: null,
    });
    try {
      const res = await apiService.getUserSecurityEvents(usr.id);
      setSecurityEventsModal({
        isOpen: true,
        user: usr,
        events: res.events || [],
        isLoading: false,
        error: null,
      });
    } catch (err: any) {
      setSecurityEventsModal({
        isOpen: true,
        user: usr,
        events: [],
        isLoading: false,
        error: err?.message || 'Failed to load security audit events for this user.',
      });
    }
  };

  const handleOpenResetModal = (usr: SystemUser) => {
    setResetModal({
      isOpen: true,
      user: usr,
      tempPassword: '',
      isCopied: false,
      isConfirmed: false,
      error: null,
    });
    setResetModalPasswordInput('');
  };

  const handleConfirmResetPassword = async () => {
    if (!resetModal?.user || isResetting) return;
    setIsResetting(true);
    setResetModal((prev) => (prev ? { ...prev, error: null } : null));

    const optionalCustomTemp = resetModalPasswordInput.trim() || undefined;

    try {
      const res = await apiService.adminResetPassword(
        resetModal.user.id,
        optionalCustomTemp,
        resetModal.user.email
      );
      const generatedTemp = res.temporaryPassword;
      const updatedUser: SystemUser = {
        ...resetModal.user,
        ...(res.user || {}),
        must_change_password: true,
        mustChangePassword: true,
        password_changed_at: undefined,
        password_reset_at: new Date().toISOString(),
        temp_password_expires_at: res.temp_password_expires_at || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        temporaryPassword: undefined,
      };
      updateSystemUser(updatedUser);

      setResetModal({
        ...resetModal,
        tempPassword: generatedTemp,
        isCopied: false,
        isConfirmed: true,
        error: null,
      });
      setIsResetting(false);
      setActionMessage(`Temporary password issued for ${resetModal.user.email}. Existing sessions invalidated.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setIsResetting(false);
      const rawMsg = String(err?.message || err?.error || '');
      const errorMsg = rawMsg || 'Unable to reset password. Please verify administrator permissions.';
      setResetModal((prev) => (prev ? { ...prev, error: errorMsg } : null));
    }
  };

  const handleOpen2FaModal = (usr: SystemUser, action: 'enable' | 'disable') => {
    setTwoFaModal({
      isOpen: true,
      user: usr,
      action,
      step: 'confirm',
      totpCode: '',
      isProcessing: false,
      error: null,
    });
  };

  const handleConfirm2FaAction = async () => {
    if (!twoFaModal?.user || twoFaModal.isProcessing) return;
    const { user, action, step } = twoFaModal;

    if (action === 'enable' && (step === 'verify' || step === 'enroll_verify')) {
      const cleanCode = twoFaModal.totpCode.trim();
      if (cleanCode.length !== 6) {
        setTwoFaModal((prev) =>
          prev ? { ...prev, error: 'Please enter the 6-digit code from your authenticator app.' } : null
        );
        return;
      }

      setTwoFaModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));
      try {
        const res = await apiService.adminVerify2Fa(user.id, {
          code: cleanCode,
          challengeId: twoFaModal.enrollment?.challengeId,
          secret: twoFaModal.secret || twoFaModal.enrollment?.secret,
        });

        const updatedUser: SystemUser = {
          ...user,
          ...(res.user || {}),
          mfaEnabled: true,
          isMfaEnabled: true,
          mfa_enabled: true,
          mfaEnrolled: true,
          mfa_enrolled: true,
        };
        updateSystemUser(updatedUser);
        setTwoFaModal(null);
        setActionMessage(`2FA TOTP enrollment verified and active for ${updatedUser.name}.`);
        setTimeout(() => setActionMessage(''), 4000);
      } catch (err: any) {
        setTwoFaModal((prev) =>
          prev
            ? {
                ...prev,
                isProcessing: false,
                error: err?.message || 'Invalid 6-digit verification code. Please check your authenticator app.',
              }
            : null
        );
      }
      return;
    }

    setTwoFaModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));

    try {
      if (action === 'enable') {
        const res = await apiService.adminEnable2Fa(user.id);
        const updatedUser: SystemUser = {
          ...user,
          ...(res.user || {}),
          mfaEnabled: true,
          isMfaEnabled: true,
          mfa_enabled: true,
        };
        updateSystemUser(updatedUser);

        if (res.enrollment) {
          const otpUri = res.enrollment.uri || '';
          const qrUrl = otpUri
            ? `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(otpUri)}`
            : undefined;
          setTwoFaModal({
            ...twoFaModal,
            user: updatedUser,
            step: 'verify',
            enrollment: res.enrollment,
            secret: res.enrollment.secret,
            qrUrl,
            totpCode: '',
            isProcessing: false,
            error: null,
          });
        } else {
          setTwoFaModal(null);
          setActionMessage(`Two-factor authentication enabled for ${user.name} (${user.email}).`);
          setTimeout(() => setActionMessage(''), 4000);
        }
      } else {
        const res = await apiService.adminDisable2Fa(user.id);
        const updatedUser: SystemUser = {
          ...user,
          ...(res.user || {}),
          mfaEnabled: false,
          isMfaEnabled: false,
          mfa_enabled: false,
          mfaEnrolled: false,
          mfa_enrolled: false,
        };
        updateSystemUser(updatedUser);
        setTwoFaModal(null);
        setActionMessage(`Two-factor authentication disabled and factor removed for ${user.name} (${user.email}).`);
        setTimeout(() => setActionMessage(''), 4000);
      }
    } catch (err: any) {
      const errorMsg = err?.message || err?.error || `Failed to ${action} two-factor authentication.`;
      setTwoFaModal((prev) => (prev ? { ...prev, isProcessing: false, error: errorMsg } : null));
    }
  };

  const handleVerify2FaEnrollmentCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!twoFaModal?.user || !twoFaModal.enrollment || twoFaModal.isProcessing) return;
    const cleanCode = twoFaModal.totpCode.trim();
    if (cleanCode.length !== 6) {
      setTwoFaModal((prev) => (prev ? { ...prev, error: 'Please enter the 6-digit code from your authenticator app.' } : null));
      return;
    }

    setTwoFaModal((prev) => (prev ? { ...prev, isProcessing: true, error: null } : null));

    try {
      const res = await apiService.adminVerify2Fa(twoFaModal.user.id, {
        code: cleanCode,
        challengeId: twoFaModal.enrollment.challengeId,
        secret: twoFaModal.enrollment.secret,
      });

      const updatedUser: SystemUser = {
        ...twoFaModal.user,
        ...(res.user || {}),
        mfaEnabled: true,
        isMfaEnabled: true,
        mfa_enabled: true,
        mfaEnrolled: true,
        mfa_enrolled: true,
      };
      updateSystemUser(updatedUser);

      setTwoFaModal({
        ...twoFaModal,
        user: updatedUser,
        step: 'completed',
        isProcessing: false,
        error: null,
      });
      setActionMessage(`2FA TOTP enrollment verified and active for ${updatedUser.name}.`);
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err: any) {
      setTwoFaModal((prev) =>
        prev
          ? {
              ...prev,
              isProcessing: false,
              error: err?.message || 'Invalid 6-digit verification code. Please check your authenticator app.',
            }
          : null
      );
    }
  };

  // Handle Logo Upload
  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const dataUrl = evt.target?.result as string;
      setChurchLogoUrl(dataUrl);
      setLogoInputUrl(dataUrl);
      setActionMessage('Church Logo updated successfully!');
      setTimeout(() => setActionMessage(''), 3000);
    };
    reader.readAsDataURL(file);
  };

  // Handle Favicon Upload
  const handleFaviconFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const dataUrl = evt.target?.result as string;
      setFaviconInputUrl(dataUrl);
      setFaviconUrl(dataUrl);
      setActionMessage('Favicon updated successfully!');
      setTimeout(() => setActionMessage(''), 3000);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPresetFavicon = (svgData: string) => {
    const dataUrl = `data:image/svg+xml;utf8,${encodeURIComponent(svgData)}`;
    setFaviconInputUrl(dataUrl);
    setFaviconUrl(dataUrl);
    setActionMessage('Preset Favicon applied globally!');
    setTimeout(() => setActionMessage(''), 3000);
  };

  // Save Branding
  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    updateFullBranding({
      systemName: brandingSystemName,
      churchLogoUrl: logoInputUrl,
      faviconUrl: faviconInputUrl,
      titleBadge: brandingTitleBadge,
      churchMotto: brandingMotto,
      primaryColorHex: brandingPrimaryColor,
      accentColorHex: brandingAccentColor,
      loginPanelColorHex: brandingLoginPanelColor,
      defaultThemeMode: themeMode === 'dark' || themeMode === 'advanced-dark' ? 'dark' : 'light',
    });
    addAuditLog('Updated System Branding & Favicon', 'Settings', `Updated system name to "${brandingSystemName}" with custom colors, login panel color, favicon, and motto.`);
    setSavedSuccess(true);
    setActionMessage('Super Admin Branding, System Theme & Split-Panel Login Colors published live!');
    setTimeout(() => {
      setSavedSuccess(false);
      setActionMessage('');
    }, 3000);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    const jsonStr = exportSystemBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CMMS_Database_Backup_${new Date().toISOString().substring(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setActionMessage('Database backup JSON exported and downloaded!');
    setTimeout(() => setActionMessage(''), 3000);
  };

  // Restore JSON Backup
  const handleRestoreBackupFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      const success = restoreSystemBackupJSON(content);
      if (success) {
        setActionMessage('Database successfully restored from JSON backup!');
      } else {
        setActionMessage('Failed to parse backup JSON file.');
      }
      setTimeout(() => setActionMessage(''), 4000);
    };
    reader.readAsText(file);
  };

  const [isCleaningDemo, setIsCleaningDemo] = useState<boolean>(false);
  const [isRetrievingAllData, setIsRetrievingAllData] = useState<boolean>(false);

  // Retrieve All Data directly from system database
  const handleRetrieveAllData = async () => {
    setIsRetrievingAllData(true);
    try {
      const data = await apiService.fetchAllData();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `CMMS_Database_All_Data_${new Date().toISOString().substring(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setActionMessage('All database data retrieved and snapshot downloaded successfully!');
    } catch (err: any) {
      setActionMessage(`Failed to retrieve database data: ${err.message || 'Unknown error'}`);
    } finally {
      setIsRetrievingAllData(false);
      setTimeout(() => setActionMessage(''), 4000);
    }
  };

  // Cleanup Demo and Autofill Data from database
  const handleCleanupDemo = async () => {
    if (!window.confirm('Are you sure you want to purge all demo and autofill data from the database?')) {
      return;
    }
    setIsCleaningDemo(true);
    try {
      const result = await apiService.cleanupDemoData();
      await reloadFromBackend();
      setActionMessage(result.message || 'Demo and autofill records purged successfully!');
    } catch (err: any) {
      setActionMessage(`Cleanup failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsCleaningDemo(false);
      setTimeout(() => setActionMessage(''), 4000);
    }
  };

  const postgresDDL = `-- ==========================================================
-- PostgreSQL Production Schema for Church Member Management System
-- Generated for Sovereign Production Migration
-- ==========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Branches / Campuses Table
CREATE TABLE IF NOT EXISTS branches (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    city VARCHAR(128) NOT NULL,
    address TEXT,
    phone VARCHAR(64),
    lead_pastor VARCHAR(255),
    is_headquarters BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Households / Families Table
CREATE TABLE IF NOT EXISTS households (
    id VARCHAR(64) PRIMARY KEY,
    family_name VARCHAR(255) NOT NULL,
    head_member_id VARCHAR(64),
    address TEXT,
    phone VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Members Table
CREATE TABLE IF NOT EXISTS members (
    id VARCHAR(64) PRIMARY KEY,
    member_code VARCHAR(32) UNIQUE NOT NULL,
    first_name VARCHAR(128) NOT NULL,
    last_name VARCHAR(128) NOT NULL,
    amharic_name VARCHAR(255),
    gender VARCHAR(16) NOT NULL,
    phone VARCHAR(64),
    email VARCHAR(255),
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    family_id VARCHAR(64) REFERENCES households(id) ON DELETE SET NULL,
    status VARCHAR(32) DEFAULT 'Active',
    spiritual_status VARCHAR(64) DEFAULT 'Full Communicant',
    joined_date DATE DEFAULT CURRENT_DATE,
    departure_reason TEXT,
    departure_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Ministries & Small Groups
CREATE TABLE IF NOT EXISTS ministries (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(64),
    leader_name VARCHAR(255),
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE CASCADE,
    meeting_schedule VARCHAR(255),
    member_count INT DEFAULT 0
);

-- 5. Attendance Records
CREATE TABLE IF NOT EXISTS attendance (
    id VARCHAR(64) PRIMARY KEY,
    event_id VARCHAR(64) NOT NULL,
    member_id VARCHAR(64) REFERENCES members(id) ON DELETE CASCADE,
    check_in_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    service_type VARCHAR(64),
    verified_by VARCHAR(64),
    method VARCHAR(32) DEFAULT 'QR_CODE'
);

-- 6. Financial Donations & Tithes
CREATE TABLE IF NOT EXISTS donations (
    id VARCHAR(64) PRIMARY KEY,
    member_id VARCHAR(64) REFERENCES members(id) ON DELETE SET NULL,
    amount NUMERIC(12, 2) NOT NULL,
    currency VARCHAR(8) DEFAULT 'ETB',
    category VARCHAR(64) NOT NULL,
    payment_method VARCHAR(64) NOT NULL,
    gateway_reference VARCHAR(128),
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    status VARCHAR(32) DEFAULT 'Completed',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. System Profiles & RBAC (Credentials managed via Supabase Auth)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(64) NOT NULL,
    branch_id VARCHAR(64) REFERENCES branches(id) ON DELETE SET NULL,
    must_change_password BOOLEAN DEFAULT FALSE,
    mfa_enabled BOOLEAN DEFAULT TRUE,
    account_locked BOOLEAN DEFAULT FALSE,
    failed_login_attempts INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGSERIAL PRIMARY KEY,
    action VARCHAR(255) NOT NULL,
    module VARCHAR(128) NOT NULL,
    details TEXT,
    user_email VARCHAR(255),
    ip_address VARCHAR(64),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* HEADER CARD */}
      <div
        className={`p-4 sm:p-5 rounded-2xl border border-[var(--color-border)] dark:border-slate-800 bg-[var(--color-surface)] dark:bg-[var(--color-secondary)] shadow-xs transition-all duration-300 ease-out min-w-0 ${
          isSwapping ? 'scale-[0.985] ring-2 ring-[var(--cmms-primary-color)]/25' : 'scale-100'
        }`}
      >
        <div className="flex items-center justify-between gap-3 min-w-0">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div
              key={`header-icon-${activeSubTab}`}
              className={`p-2.5 rounded-xl bg-[var(--cmms-primary-color)]/10 text-[var(--cmms-primary-color)] shrink-0 ${
                swapDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
              }`}
            >
              {currentSubTabObj?.icon || (isSuperAdmin ? <Crown className="w-5 h-5" /> : <Settings className="w-5 h-5" />)}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2 min-w-0">
                <h1 className="text-sm sm:text-lg font-extrabold text-[var(--color-secondary)] dark:text-white truncate">
                  {isSuperAdmin ? 'Main Control & Settings' : 'Branch System Settings'}
                </h1>
                {isSuperAdmin && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-[var(--color-secondary)] text-white dark:bg-[var(--cmms-primary-color)]/20 dark:text-[var(--cmms-primary-color)] shrink-0">
                    Root
                  </span>
                )}
                {/* Tablet & Desktop Active Section Status Pill with Directional Slide & Fade Swap Animation */}
                <span
                  key={`desktop-pill-${activeSubTab}`}
                  className={`hidden md:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[var(--cmms-primary-color)]/10 text-[var(--cmms-primary-color)] border border-[var(--cmms-primary-color)]/25 shrink-0 ${
                    swapDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[var(--cmms-primary-color)] animate-pulse" />
                  <span>{currentSubTabObj?.shortLabel}</span>
                  <span className="opacity-70 font-mono text-[10px]">
                    ({currentSubTabIndex + 1}/{visibleSettingsSubTabs.length})
                  </span>
                </span>
              </div>
              <p className="hidden sm:block text-xs text-[var(--color-text-muted)] dark:text-slate-400 truncate mt-0.5">
                {isSuperAdmin
                  ? 'Manage Global System Name, Live Favicon, PostgreSQL Production Engine, and RBAC Security.'
                  : 'Manage local branch profile, language preferences, and user accounts.'}
              </p>
            </div>
          </div>

          {/* Mobile View (< 768px): Active Tab Indicator + Three Dots (⋮) Sub-Tab Switcher */}
          <div className="flex md:hidden items-center gap-2 shrink-0">
            <span
              key={`mobile-pill-${activeSubTab}`}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[var(--cmms-primary-color)]/10 text-[var(--cmms-primary-color)] border border-[var(--cmms-primary-color)]/25 text-xs font-bold truncate max-w-[148px] transition-all ${
                swapDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--cmms-primary-color)] animate-pulse shrink-0" />
              {currentSubTabObj?.icon}
              <span className="truncate">{currentSubTabObj?.shortLabel}</span>
            </span>
            <ActionMenu
              recordTitle="System Settings Modules"
              recordSubtitle={isSuperAdmin ? 'Super Admin Master Control' : 'Branch System Settings'}
              triggerTitle="Switch Settings Section"
              items={visibleSettingsSubTabs.map((tab) => ({
                id: tab.id,
                label: tab.label,
                icon: tab.icon,
                variant: activeSubTab === tab.id ? 'primary' : 'default',
                badge: activeSubTab === tab.id ? 'Active' : undefined,
                onClick: () => handleSwapSubTab(tab.id),
              }))}
            />
          </div>
        </div>

        {actionMessage && (
          <div className="mt-3 px-3.5 py-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span className="min-w-0 break-words">{actionMessage}</span>
          </div>
        )}

        {/* TABLET & DESKTOP ANIMATED SWAP / SWIPE SEGMENTED SUB-TABS NAVIGATION (md+) */}
        <div className="hidden md:flex flex-col gap-2.5 mt-4 pt-3.5 border-t border-[var(--color-border)] dark:border-slate-800/80 min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            {/* Previous Tab Swap Button */}
            <button
              type="button"
              onClick={() => {
                const idx = visibleSettingsSubTabs.findIndex((t) => t.id === activeSubTab);
                const prevIdx = idx <= 0 ? visibleSettingsSubTabs.length - 1 : idx - 1;
                handleSwapSubTab(visibleSettingsSubTabs[prevIdx].id);
              }}
              title="Swap to Previous Settings Module"
              aria-label="Swap to Previous Settings Module"
              className="min-h-[40px] min-w-[40px] rounded-xl border border-[var(--color-border)] dark:border-slate-700/70 bg-slate-100/90 dark:bg-slate-800/80 hover:bg-[var(--cmms-primary-color)] hover:text-white hover:border-[var(--cmms-primary-color)] active:scale-95 text-[var(--color-secondary)] dark:text-slate-200 flex items-center justify-center shrink-0 transition-all duration-200 cursor-pointer shadow-2xs"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Segmented Swap Track (Swipeable on Tablet, Distributed on Desktop) */}
            <div
              role="tablist"
              aria-label="System Settings Sections"
              className="flex-1 min-w-0 flex items-center gap-1.5 overflow-x-auto scrollbar-none snap-x snap-mandatory scroll-smooth rounded-xl p-1.5 bg-slate-100 dark:bg-slate-800/90 border border-[var(--color-border)] dark:border-slate-700/70"
            >
              {visibleSettingsSubTabs.map((tab) => {
                const isActive = activeSubTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    ref={(el) => {
                      tabButtonRefs.current[tab.id] = el;
                    }}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => handleSwapSubTab(tab.id)}
                    className={`group relative snap-center xl:flex-1 min-h-[38px] px-3.5 py-2 rounded-lg text-xs flex items-center justify-center gap-2 transition-all duration-300 ease-out cursor-pointer whitespace-nowrap shrink-0 active:scale-[0.985] ${
                      isActive
                        ? `bg-[var(--cmms-primary-color)] text-white shadow-md font-bold ring-2 ring-[var(--cmms-primary-color)]/25 -translate-y-[0.5px] ${
                            swapDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
                          }`
                        : 'font-semibold text-[var(--color-secondary)] dark:text-slate-300 hover:bg-white/80 dark:hover:bg-slate-700/60 scale-[0.985] hover:scale-100'
                    }`}
                  >
                    <span
                      className={`transition-transform duration-300 ${
                        isActive ? 'scale-110' : 'group-hover:scale-110'
                      }`}
                    >
                      {tab.icon}
                    </span>
                    <span className="hidden 2xl:inline">{tab.label}</span>
                    <span className="2xl:hidden">{tab.shortLabel}</span>
                    {isActive && (
                      <span
                        aria-hidden="true"
                        className="w-1.5 h-1.5 rounded-full bg-white shadow-xs animate-pulse shrink-0"
                      />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Next Tab Swap Button */}
            <button
              type="button"
              onClick={() => {
                const idx = visibleSettingsSubTabs.findIndex((t) => t.id === activeSubTab);
                const nextIdx = idx >= visibleSettingsSubTabs.length - 1 ? 0 : idx + 1;
                handleSwapSubTab(visibleSettingsSubTabs[nextIdx].id);
              }}
              title="Swap to Next Settings Module"
              aria-label="Swap to Next Settings Module"
              className="min-h-[40px] min-w-[40px] rounded-xl border border-[var(--color-border)] dark:border-slate-700/70 bg-slate-100/90 dark:bg-slate-800/80 hover:bg-[var(--cmms-primary-color)] hover:text-white hover:border-[var(--cmms-primary-color)] active:scale-95 text-[var(--color-secondary)] dark:text-slate-200 flex items-center justify-center shrink-0 transition-all duration-200 cursor-pointer shadow-2xs"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Animated Swap Position Indicator Dots */}
          <div className="flex items-center justify-center gap-1.5" aria-hidden="true">
            {visibleSettingsSubTabs.map((tab) => {
              const isActive = activeSubTab === tab.id;
              return (
                <button
                  key={`dot-${tab.id}`}
                  type="button"
                  tabIndex={-1}
                  onClick={() => handleSwapSubTab(tab.id)}
                  title={tab.label}
                  className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                    isActive
                      ? 'w-6 bg-[var(--cmms-primary-color)]'
                      : 'w-1.5 bg-slate-300 dark:bg-slate-700 hover:bg-slate-400'
                  }`}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* ANIMATED SUB-TAB CONTENT CONTAINER */}
      <div
        key={activeSubTab}
        className={`transition-all duration-300 ease-out will-change-transform ${
          swapDirection === 'right'
            ? 'slide-in-from-right slide-in-from-right-4'
            : 'slide-in-from-left slide-in-from-left-4'
        } ${isSwapping ? 'scale-[0.985] opacity-95' : 'scale-100 opacity-100'}`}
      >

      {/* SUB-TAB 1: SUPER ADMIN BRANDING & FAVICON */}
      {activeSubTab === 'branding' && isSuperAdmin && (
        <div className="space-y-6">
          <form onSubmit={handleSaveBranding} className="space-y-6">
            {/* Live Browser Tab Preview Bar */}
            <div className="p-5 bg-slate-900 rounded-3xl text-white shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Live Browser Tab & Title Simulation
                </span>
                <span className="text-[10px] font-mono bg-slate-800 px-2 py-0.5 rounded text-amber-300">
                  DOM Live Sync
                </span>
              </div>

              {/* Browser Window Mockup */}
              <div className="bg-slate-800 rounded-2xl p-2.5 border border-slate-700 max-w-xl">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                  </div>
                  <div className="flex-1 bg-slate-900 rounded-xl px-3 py-1.5 flex items-center gap-2 border border-slate-700/60 shadow-inner">
                    {/* Favicon in tab */}
                    <div className="w-4 h-4 rounded-xs overflow-hidden shrink-0 flex items-center justify-center bg-slate-800">
                      {faviconInputUrl ? (
                        <img src={faviconInputUrl} alt="Favicon" className="w-full h-full object-contain" />
                      ) : (
                        <span className="text-xs">⛪</span>
                      )}
                    </div>
                    <span className="text-xs font-bold text-slate-200 truncate">
                      {brandingSystemName} • {brandingTitleBadge}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Favicon Configuration Section */}
            <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-amber-500" /> Favicon & Browser Icon Manager
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Select a predefined theological icon or upload a custom .png / .ico / .svg favicon to update the browser tab icon in real-time.
                </p>
              </div>

              {/* Preset Favicon Picker */}
              

              {/* Custom Favicon URL & Upload */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    Custom Favicon Image URL
                  </label>
                  <input
                    type="text"
                    value={faviconInputUrl}
                    onChange={(e) => {
                      setFaviconInputUrl(e.target.value);
                      setFaviconUrl(e.target.value);
                    }}
                    placeholder="https://example.org/favicon.png"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    Upload Custom Favicon File (.ico / .png / .svg)
                  </label>
                  <input
                    type="file"
                    ref={faviconFileInputRef}
                    onChange={handleFaviconFileUpload}
                    accept="image/*,.ico"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => faviconFileInputRef.current?.click()}
                    className="w-full py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-amber-500" /> Upload Favicon from Device
                  </button>
                </div>
              </div>
            </div>

            {/* System Name, Badge & Motto Controls */}
            <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-500" /> System Name, Header Badge & Church Motto
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    Global System / Church Name
                  </label>
                  <input
                    type="text"
                    value={brandingSystemName}
                    onChange={(e) => setBrandingSystemName(e.target.value)}
                    placeholder="e.g. CMMS"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-amber-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Displayed in Navbar, document titles, and exported certificates.</p>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    Navbar Title Badge
                  </label>
                  <input
                    type="text"
                    value={brandingTitleBadge}
                    onChange={(e) => setBrandingTitleBadge(e.target.value)}
                    placeholder="e.g. Sovereign Portal"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-amber-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Pill badge shown next to the name in the header.</p>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    Official Church Motto / Slogan
                  </label>
                  <input
                    type="text"
                    value={brandingMotto}
                    onChange={(e) => setBrandingMotto(e.target.value)}
                    placeholder="e.g. Equipping Believers • Empowering Generations"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-amber-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Included on bulletin headers and member certificates.</p>
                </div>
              </div>

              {/* Church Header Logo Section */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-2">
                  Main Cathedral / Church Header Logo
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="w-20 h-20 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 flex items-center justify-center p-2 shrink-0">
                    {logoInputUrl ? (
                      <img src={logoInputUrl} alt="Logo" className="w-full h-full object-contain" />
                    ) : (
                      <Church className="w-8 h-8 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 space-y-2 w-full text-xs">
                    <input
                      type="text"
                      value={logoInputUrl}
                      onChange={(e) => {
                        setLogoInputUrl(e.target.value);
                        setChurchLogoUrl(e.target.value);
                      }}
                      placeholder="https://example.org/logo.png"
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500"
                    />
                    <input
                      type="file"
                      ref={logoFileInputRef}
                      onChange={handleLogoFileUpload}
                      accept="image/*"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => logoFileInputRef.current?.click()}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" /> Upload Header Logo (PNG/SVG)
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* System Theme & Split-Panel Login Colors */}
            <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-500" /> System Theme &amp; Split-Panel Login Brand Colors
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Configure the active system visual theme and dynamic CSS variables (<code className="font-mono text-[11px] text-blue-600 dark:text-blue-400">--cmms-primary-color</code>, <code className="font-mono text-[11px] text-purple-600 dark:text-purple-400">--cmms-accent-color</code>, <code className="font-mono text-[11px] text-slate-600 dark:text-slate-300">--cmms-login-panel-color</code>) applied across the Landing Page and Split-Panel Login Page.
                  </p>
                </div>

                {/* System Theme Light / Dark Toggle */}
                <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 self-start">
                  <button
                    type="button"
                    onClick={() => setThemeMode('light')}
                    aria-label="Switch to light mode"
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      themeMode === 'light' || themeMode === 'system'
                        ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                        : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5 text-amber-500" />
                    <span>☀️ Light</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setThemeMode('dark')}
                    aria-label="Switch to dark mode"
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      themeMode === 'dark' || themeMode === 'advanced-dark'
                        ? 'bg-slate-900 text-white shadow-xs border border-slate-700'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Moon className="w-3.5 h-3.5 text-blue-400" />
                    <span>🌙 Dark</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                {/* 1. Primary Brand Color */}
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5">
                    Primary Brand Color (Hex)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={brandingPrimaryColor}
                      onChange={(e) => {
                        setBrandingPrimaryColor(e.target.value);
                        document.documentElement.style.setProperty('--cmms-primary-color', e.target.value);
                      }}
                      className="w-10 h-10 rounded-xl border border-slate-300 dark:border-slate-700 cursor-pointer bg-transparent p-0.5 shrink-0"
                    />
                    <input
                      type="text"
                      value={brandingPrimaryColor}
                      onChange={(e) => {
                        setBrandingPrimaryColor(e.target.value);
                        document.documentElement.style.setProperty('--cmms-primary-color', e.target.value);
                      }}
                      placeholder="#2563eb"
                      className="flex-1 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Used for Sign In buttons, active tabs, and primary brand accents (<code className="font-mono">--cmms-primary-color</code>).
                  </p>
                </div>

                {/* 2. Secondary / Accent Brand Color */}
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5">
                    Secondary / Accent Color (Hex)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={brandingAccentColor}
                      onChange={(e) => {
                        setBrandingAccentColor(e.target.value);
                        document.documentElement.style.setProperty('--cmms-accent-color', e.target.value);
                      }}
                      className="w-10 h-10 rounded-xl border border-slate-300 dark:border-slate-700 cursor-pointer bg-transparent p-0.5 shrink-0"
                    />
                    <input
                      type="text"
                      value={brandingAccentColor}
                      onChange={(e) => {
                        setBrandingAccentColor(e.target.value);
                        document.documentElement.style.setProperty('--cmms-accent-color', e.target.value);
                      }}
                      placeholder="#7c3aed"
                      className="flex-1 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Used for secondary gradients, badges, and ambient highlights (<code className="font-mono">--cmms-accent-color</code>).
                  </p>
                </div>

                {/* 3. Login Split Panel Color */}
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5">
                    Login Split Panel Color (Hex)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={brandingLoginPanelColor}
                      onChange={(e) => {
                        setBrandingLoginPanelColor(e.target.value);
                        document.documentElement.style.setProperty('--cmms-login-panel-color', e.target.value);
                      }}
                      className="w-10 h-10 rounded-xl border border-slate-300 dark:border-slate-700 cursor-pointer bg-transparent p-0.5 shrink-0"
                    />
                    <input
                      type="text"
                      value={brandingLoginPanelColor}
                      onChange={(e) => {
                        setBrandingLoginPanelColor(e.target.value);
                        document.documentElement.style.setProperty('--cmms-login-panel-color', e.target.value);
                      }}
                      placeholder="#0f172a"
                      className="flex-1 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Used for the left church branding split-panel on the Login Page (<code className="font-mono">--cmms-login-panel-color</code>).
                  </p>
                </div>
              </div>

              {/* Live Split-Panel Login Preview & Active Token Breakdown */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Live Split-Panel Login Preview &amp; Active Customization Tokens ({themeMode === 'dark' || themeMode === 'advanced-dark' ? 'Dark Mode' : 'Light Mode'})
                  </span>
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                    Divider Token: #E5E7EB (Light) / #1E293B (Dark)
                  </span>
                </div>

                {/* Split-Panel Interactive Preview */}
                <div className="grid grid-cols-1 sm:grid-cols-2 rounded-2xl overflow-hidden border border-[#E5E7EB] dark:border-slate-700 shadow-sm min-h-[175px]">
                  {/* 1. Left Brand Panel (Over-Brand Contrast Adaptive) */}
                  {(() => {
                    const cleanPanel = (brandingLoginPanelColor || '#0f172a').replace('#', '');
                    const pr = cleanPanel.length === 6 ? parseInt(cleanPanel.slice(0, 2), 16) : 15;
                    const pg = cleanPanel.length === 6 ? parseInt(cleanPanel.slice(2, 4), 16) : 23;
                    const pb = cleanPanel.length === 6 ? parseInt(cleanPanel.slice(4, 6), 16) : 42;
                    const panelYiq = (pr * 299 + pg * 587 + pb * 114) / 1000;
                    const isLightPanel = panelYiq >= 150;
                    const overBrandTextColor = isLightPanel ? '#0f172a' : '#ffffff';
                    const overBrandMutedColor = isLightPanel ? '#475569' : '#cbd5e1';

                    return (
                      <div
                        className="p-5 flex flex-col justify-between relative overflow-hidden border-b sm:border-b-0 sm:border-r border-[#E5E7EB] dark:border-slate-800"
                        style={{
                          backgroundColor: brandingLoginPanelColor || '#0f172a',
                          color: overBrandTextColor,
                        }}
                      >
                        <div
                          className="absolute -top-10 -left-10 w-32 h-32 rounded-full blur-2xl opacity-30 pointer-events-none"
                          style={{ backgroundColor: brandingPrimaryColor }}
                        />
                        <div
                          className="absolute -bottom-10 -right-10 w-32 h-32 rounded-full blur-2xl opacity-25 pointer-events-none"
                          style={{ backgroundColor: brandingAccentColor }}
                        />
                        <div className="relative z-10 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-7 h-7 rounded-lg flex items-center justify-center text-white shadow-xs shrink-0"
                              style={{ background: `linear-gradient(135deg, ${brandingPrimaryColor}, ${brandingAccentColor})` }}
                            >
                              <Church className="w-4 h-4" />
                            </div>
                            <span className="font-bold text-xs truncate" style={{ color: overBrandTextColor }}>
                              {brandingSystemName}
                            </span>
                          </div>
                          <span
                            className="text-[9px] font-mono px-2 py-0.5 rounded-md border"
                            style={{
                              color: overBrandMutedColor,
                              borderColor: isLightPanel ? 'rgba(15,23,42,0.15)' : 'rgba(255,255,255,0.18)',
                              backgroundColor: isLightPanel ? 'rgba(15,23,42,0.05)' : 'rgba(255,255,255,0.08)',
                            }}
                          >
                            {isLightPanel ? 'Dark Text Contrast' : 'White Text Contrast'}
                          </span>
                        </div>

                        <div className="relative z-10 my-3 space-y-1">
                          <p className="text-xs font-extrabold tracking-tight" style={{ color: overBrandTextColor }}>
                            Manage Your Church. Connect Your People.
                          </p>
                          <p className="text-[11px] font-medium line-clamp-2" style={{ color: overBrandMutedColor }}>
                            {brandingMotto || 'A modern, trustworthy administrative platform bringing pastors, leaders, and members together.'}
                          </p>
                        </div>

                        <div
                          className="relative z-10 pt-2 border-t flex items-center justify-between text-[10px]"
                          style={{
                            color: overBrandMutedColor,
                            borderColor: isLightPanel ? 'rgba(15,23,42,0.12)' : 'rgba(255,255,255,0.12)',
                          }}
                        >
                          <span>Brand Panel ({brandingLoginPanelColor})</span>
                          <span>Over-Brand Token: {overBrandTextColor}</span>
                        </div>
                      </div>
                    );
                  })()}

                  {/* 2. Right Neutral Form Panel */}
                  <div className="p-5 bg-white dark:bg-slate-950 text-slate-900 dark:text-white flex flex-col justify-between space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-extrabold block text-slate-900 dark:text-white">Welcome Back</span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400">Neutral Form Panel (#FFFFFF / #020617)</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold border border-slate-200 dark:border-slate-700">
                        {themeMode === 'dark' || themeMode === 'advanced-dark' ? '🌙 Dark' : '☀️ Light'}
                      </span>
                    </div>

                    {/* Crisp Label vs Lighter Gray Placeholder Preview */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-slate-900 dark:text-slate-100">Email Address (Crisp Label)</span>
                        <span className="font-semibold underline" style={{ color: brandingAccentColor }}>
                          Forgot password?
                        </span>
                      </div>
                      <div
                        className="h-7 rounded-lg bg-white dark:bg-slate-900 border px-2.5 flex items-center text-[10px] text-slate-400 dark:text-slate-500"
                        style={{
                          borderColor: brandingPrimaryColor,
                          boxShadow: `0 0 0 2px ${brandingPrimaryColor}26`,
                        }}
                      >
                        e.g., name@company.com (Distinct Placeholder)
                      </div>
                    </div>

                    {/* Interactive Button States Preview (Default, Hover, Disabled) */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div
                        className="h-7 rounded-lg text-white text-[10px] font-bold flex items-center justify-center shadow-xs transition-all"
                        style={{ backgroundColor: brandingPrimaryColor }}
                      >
                        Sign In (Default)
                      </div>
                      <div className="h-7 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 text-[10px] font-bold flex items-center justify-center border border-slate-300/60 dark:border-slate-700/60 cursor-not-allowed">
                        Disabled State
                      </div>
                    </div>

                    {/* Secondary Action Links Preview */}
                    <div className="pt-1 border-t border-slate-100 dark:border-slate-900 flex items-center justify-between text-[10px]">
                      <span className="text-slate-500">Secondary Action Link:</span>
                      <span className="font-bold underline" style={{ color: brandingAccentColor }}>
                        Create an Account
                      </span>
                    </div>
                  </div>
                </div>

                {/* 4-Pillar Customization Token Reference Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-[11px]">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">1. Panel Balance &amp; Hierarchy</span>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      Brand Panel (<code className="font-mono">{brandingLoginPanelColor}</code>), Neutral Form Panel, and <code className="font-mono">#E5E7EB</code> divider.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">2. Interactive Component States</span>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      Primary (<code className="font-mono">{brandingPrimaryColor}</code>), auto-hover shade, focus ring outline, and muted gray disabled state.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">3. Accessible Typography</span>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      Auto-contrasted over-brand text, crisp dark labels (<code className="font-mono">#0F172A</code>), and distinct gray placeholders.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 space-y-1">
                    <span className="font-bold text-slate-900 dark:text-white block">4. Interactive Links &amp; Actions</span>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                      Secondary brand color (<code className="font-mono">{brandingAccentColor}</code>) for &ldquo;Forgot Password?&rdquo; &amp; &ldquo;Create an Account&rdquo;.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-8 py-3 font-black rounded-2xl text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer cmms-btn-primary"
              >
                <Save className="w-4 h-4" /> Publish Super Admin Branding & Favicon Live
              </button>
            </div>
          </form>
        </div>
      )}

      {/* SUB-TAB 2: POSTGRESQL PRODUCTION ENGINE */}
      {activeSubTab === 'postgres' && isSuperAdmin && (
        <div className="space-y-6">
          <div className="p-6 bg-slate-900 rounded-3xl text-white border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/30">
                  <Database className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    PostgreSQL Production Schema & Migration Hub
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Production-grade relational schema with UUID primary keys, foreign key constraints, and multi-tenant branch indexing.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyToClipboard(postgresDDL)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
                >
                  {copiedSql ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                  {copiedSql ? 'SQL Copied!' : 'Copy PostgreSQL DDL'}
                </button>
              </div>
            </div>

            {/* Realtime Supabase Health Indicator */}
            <div className="pt-2">
              <RealtimeConnectionIndicator
                variant="detailed"
                channelName="system-realtime-health"
                tableName="notifications"
                className="bg-slate-800/80 border-slate-700 text-white"
              />
            </div>

            {/* Target Cloud Databases Status */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
              <div className="p-3 bg-slate-800/80 rounded-2xl border border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Supported Target</span>
                  <p className="text-xs font-bold text-white">Supabase / Neon</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <div className="p-3 bg-slate-800/80 rounded-2xl border border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Relational Engine</span>
                  <p className="text-xs font-bold text-white">PostgreSQL 15+</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <div className="p-3 bg-slate-800/80 rounded-2xl border border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Migration Mode</span>
                  <p className="text-xs font-bold text-white">Zero-Downtime DDL</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <div className="p-3 bg-slate-800/80 rounded-2xl border border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold">API Connectors</span>
                  <p className="text-xs font-bold text-white">REST & SMS Gateway</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
            </div>

            {/* SQL Editor / Viewer */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span className="flex items-center gap-1.5">
                  <FileCode className="w-4 h-4 text-indigo-400" /> schema.postgres.sql
                </span>
                <span>8 Core Relational Tables</span>
              </div>
              <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 overflow-x-auto max-h-96 scrollbar-thin">
                <pre className="text-[11px] font-mono text-indigo-200 whitespace-pre leading-relaxed">
                  {postgresDDL}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB: API & INTEGRATIONS HUB */}
      {activeSubTab === 'api_hub' && isSuperAdmin && (
        <div>
          <ApiHubModule />
        </div>
      )}

      {/* SUB-TAB 3: SYSTEM USERS & RBAC */}
      {activeSubTab === 'users' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" /> System User Accounts & Multi-Campus Access
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Manage administrator logins, assign multi-role & multi-campus permissions, enforce TOTP 2FA enrollment, revoke sessions, and audit security events.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
              <button
                type="button"
                onClick={() => refreshAuthoritativeUsers()}
                disabled={isUsersLoading}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all disabled:opacity-50"
                title="Refresh authoritative user list from database"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isUsersLoading ? 'animate-spin text-blue-600' : ''}`} />
                {isUsersLoading ? 'Syncing...' : 'Sync Users'}
              </button>
              <button
                type="button"
                onClick={() => handleOpenSecurityEventsModal(null)}
                className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/70 dark:hover:bg-indigo-900/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <History className="w-3.5 h-3.5" /> Security Events Log
              </button>
              <button
                type="button"
                onClick={() => {
                  setAddUserError(null);
                  setIsAddUserModalOpen(true);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
              >
                <UserPlus className="w-4 h-4" /> Add System User
              </button>
            </div>
          </div>

          {/* Account Status & Security Summary KPI Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700/60">
              <span className="text-[10px] font-bold uppercase text-slate-400">Total Accounts</span>
              <p className="text-lg font-black text-slate-900 dark:text-white mt-0.5">{systemUsers.length}</p>
            </div>
            <div className="p-3 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/70 dark:border-emerald-800/60">
              <span className="text-[10px] font-bold uppercase text-emerald-600 dark:text-emerald-400">Active Users</span>
              <p className="text-lg font-black text-emerald-700 dark:text-emerald-300 mt-0.5">
                {systemUsers.filter((u) => (u.status || 'Active') === 'Active').length}
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200/70 dark:border-rose-800/60">
              <span className="text-[10px] font-bold uppercase text-rose-600 dark:text-rose-400">Suspended / Disabled</span>
              <p className="text-lg font-black text-rose-700 dark:text-rose-300 mt-0.5">
                {systemUsers.filter((u) => u.status === 'Suspended' || u.status === 'Disabled' || u.status === 'Inactive').length}
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/70 dark:border-blue-800/60">
              <span className="text-[10px] font-bold uppercase text-blue-600 dark:text-blue-400">2FA Enforced</span>
              <p className="text-lg font-black text-blue-700 dark:text-blue-300 mt-0.5">
                {systemUsers.filter((u) => u.mfaEnabled === true).length}
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-800/60">
              <span className="text-[10px] font-bold uppercase text-amber-600 dark:text-amber-400">Pwd Change Req.</span>
              <p className="text-lg font-black text-amber-700 dark:text-amber-300 mt-0.5">
                {systemUsers.filter((u) => u.mustChangePassword === true).length}
              </p>
            </div>
          </div>

          {/* Quick Filter & Search Bar */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2 sm:gap-3 bg-slate-50 dark:bg-slate-800/60 p-2.5 sm:p-3 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 text-[11px] sm:text-xs">
            <div className="relative flex-1 min-w-0">
              <Search className="w-3 h-3 sm:w-3.5 sm:h-3.5 absolute left-2.5 sm:left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search user name, email, phone, role, or campus..."
                value={userSearchQuery}
                onChange={(e) => setUserSearchQuery(e.target.value)}
                className="w-full min-h-[34px] sm:min-h-[40px] pl-8 sm:pl-9 pr-2.5 sm:pr-3 py-1 sm:py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-[11px] sm:text-xs font-medium leading-tight text-slate-900 dark:text-white placeholder:text-slate-400 placeholder:text-[11px] sm:placeholder:text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 lg:flex lg:flex-wrap items-center gap-1.5 sm:gap-2">
              <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0 hidden lg:inline" />
              <select
                value={userRoleFilter}
                onChange={(e) => setUserRoleFilter(e.target.value)}
                aria-label="Filter by role"
                className="w-full lg:w-auto min-h-[34px] sm:min-h-[40px] px-2.5 sm:px-3 py-1 sm:py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-[11px] sm:text-xs font-semibold sm:font-bold leading-tight text-slate-700 dark:text-slate-200"
              >
                <option value="ALL">All Roles ({systemUsers.length})</option>
                <option value="SYSTEM_ADMIN">Super Administrator (SYSTEM_ADMIN)</option>
                <option value="MANAGER">Branch Manager (MANAGER)</option>
                <option value="PASTOR">Pastor & Counselor (PASTOR)</option>
                <option value="MINISTRY_LEADER">Ministry Leader (MINISTRY_LEADER)</option>
                <option value="REGULAR_MEMBER">Regular Member (REGULAR_MEMBER)</option>
              </select>

              <select
                value={userStatusFilter}
                onChange={(e) => setUserStatusFilter(e.target.value)}
                aria-label="Filter by account status"
                className="w-full lg:w-auto min-h-[34px] sm:min-h-[40px] px-2.5 sm:px-3 py-1 sm:py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-[11px] sm:text-xs font-semibold sm:font-bold leading-tight text-slate-700 dark:text-slate-200"
              >
                <option value="ALL">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Suspended">Suspended</option>
                <option value="Disabled">Disabled</option>
                <option value="Pending">Pending</option>
              </select>

              <select
                value={userCampusFilter}
                onChange={(e) => setUserCampusFilter(e.target.value)}
                aria-label="Filter by campus"
                className="w-full lg:w-auto min-h-[34px] sm:min-h-[40px] px-2.5 sm:px-3 py-1 sm:py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-[11px] sm:text-xs font-semibold sm:font-bold leading-tight text-slate-700 dark:text-slate-200"
              >
                <option value="ALL">All Campuses</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.name}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Users Table */}
          <div className="cmms-table-scroll overflow-x-auto rounded-2xl border border-[var(--color-border)] dark:border-slate-800 bg-[var(--color-surface)] dark:bg-slate-900 min-w-0 max-w-full">
            <table className="cmms-data-table w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 dark:bg-slate-800/80">
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-3 min-w-[180px] sm:min-w-[200px]">User, Contact & Last Login</th>
                  <th className="hidden md:table-cell py-3 px-3 whitespace-nowrap">Account Status</th>
                  <th className="hidden md:table-cell py-3 px-3 min-w-[210px]">Authoritative Role(s)</th>
                  <th className="hidden lg:table-cell py-3 px-3 min-w-[180px]">Multi-Campus Access</th>
                  <th className="hidden md:table-cell py-3 px-3 whitespace-nowrap">Two-Factor (TOTP)</th>
                  <th className="py-3 px-3 text-right whitespace-nowrap sticky right-0 bg-slate-50 dark:bg-slate-800/95 z-10">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {systemUsers
                  .filter((usr) => {
                    const q = userSearchQuery.toLowerCase().trim();
                    const campusList =
                      usr.assignedCampuses && usr.assignedCampuses.length > 0
                        ? usr.assignedCampuses
                        : [usr.branchName || 'Grace Cathedral Headquarters'];
                    const allRoles = Array.from(
                      new Set([normalizeUserRole(usr.role), ...((usr.additionalRoles || []).map((r) => normalizeUserRole(r)))])
                    );

                    const matchesSearch =
                      !q ||
                      (usr.name || '').toLowerCase().includes(q) ||
                      (usr.email || '').toLowerCase().includes(q) ||
                      (usr.phone || '').toLowerCase().includes(q) ||
                      (usr.branchName && usr.branchName.toLowerCase().includes(q)) ||
                      campusList.some((c) => c.toLowerCase().includes(q)) ||
                      allRoles.some((r) => r.toLowerCase().includes(q));

                    const matchesRole =
                      userRoleFilter === 'ALL' ||
                      normalizeUserRole(usr.role) === normalizeUserRole(userRoleFilter) ||
                      allRoles.includes(normalizeUserRole(userRoleFilter)) ||
                      usr.role === userRoleFilter;

                    const normalizedStatus = usr.status === 'Inactive' ? 'Disabled' : usr.status || 'Active';
                    const matchesStatus =
                      userStatusFilter === 'ALL' || normalizedStatus.toLowerCase() === userStatusFilter.toLowerCase();

                    const matchesCampus =
                      userCampusFilter === 'ALL' ||
                      usr.branchName === userCampusFilter ||
                      campusList.includes(userCampusFilter);

                    return matchesSearch && matchesRole && matchesStatus && matchesCampus;
                  })
                  .map((usr) => {
                    const primaryRoleCode = normalizeUserRole(usr.role);
                    const extraRoles = (usr.additionalRoles || [])
                      .map((r) => normalizeUserRole(r))
                      .filter((r) => r !== primaryRoleCode);
                    const campusList =
                      usr.assignedCampuses && usr.assignedCampuses.length > 0
                        ? usr.assignedCampuses
                        : [usr.branchName || 'Grace Cathedral Headquarters'];
                    const normalizedStatus = usr.status === 'Inactive' ? 'Disabled' : usr.status || 'Active';
                    const isMfaActive = usr.mfaEnabled === true;
                    const shortPrimaryCampus = (usr.branchName || campusList[0] || 'Headquarters')
                      .replace('Grace Cathedral ', '')
                      .replace('Branch', '')
                      .trim();

                    return (
                      <tr key={usr.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors align-top">
                        {/* 1. User, Contact & Last Login (Always Visible on Mobile, Tablet & Desktop) */}
                        <td className="py-3.5 px-3 min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap">
                            <span className="truncate max-w-[190px] sm:max-w-none">{usr.name}</span>
                            {usr.mustChangePassword && (
                              <span
                                className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300/60"
                                title="User is required to change password at next login"
                              >
                                Must Change Pwd
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 font-medium break-all sm:break-normal">{usr.email}</div>
                          {usr.phone && (
                            <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                              <Phone className="w-2.5 h-2.5 shrink-0" /> <span>{usr.phone}</span>
                            </div>
                          )}
                          <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-1" title="Last recorded login timestamp">
                            <Clock className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                            <span>Last login: {formatLastLogin(usr.lastLogin)}</span>
                          </div>

                          {/* Mobile Compact Breadcrumb Trail (Status › Role › Campus › 2FA) */}
                          <div className="flex md:hidden items-center flex-wrap gap-1 mt-2 pt-1.5 border-t border-slate-100 dark:border-slate-800/80 text-[10px] text-slate-500 dark:text-slate-400">
                            <span
                              className={`inline-flex items-center gap-1 font-bold ${
                                normalizedStatus === 'Active'
                                  ? 'text-emerald-600 dark:text-emerald-400'
                                  : normalizedStatus === 'Suspended'
                                  ? 'text-rose-600 dark:text-rose-400'
                                  : 'text-slate-500'
                              }`}
                            >
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  normalizedStatus === 'Active'
                                    ? 'bg-emerald-500'
                                    : normalizedStatus === 'Suspended'
                                    ? 'bg-rose-500'
                                    : 'bg-slate-400'
                                }`}
                              />
                              {normalizedStatus}
                            </span>
                            <ChevronRight className="w-3 h-3 text-slate-300 dark:text-slate-600 shrink-0" />
                            <span className="font-semibold text-slate-700 dark:text-slate-300">
                              {ROLE_DISPLAY_LABELS[primaryRoleCode] || usr.role}
                              {extraRoles.length > 0 ? ` (+${extraRoles.length})` : ''}
                            </span>
                            <ChevronRight className="w-3 h-3 text-slate-300 dark:text-slate-600 shrink-0" />
                            <span className="truncate max-w-[110px]">{shortPrimaryCampus}</span>
                            <ChevronRight className="w-3 h-3 text-slate-300 dark:text-slate-600 shrink-0" />
                            <span className={isMfaActive ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-slate-400'}>
                              {isMfaActive ? '2FA On' : '2FA Off'}
                            </span>
                          </div>
                        </td>

                        {/* 2. Account Status & Quick Status Toggles (Tablet & Desktop md+) */}
                        <td className="hidden md:table-cell py-3.5 px-3">
                          <div className="flex flex-col items-start gap-1.5">
                            <span
                              className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                                normalizedStatus === 'Active'
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-800'
                                  : normalizedStatus === 'Suspended'
                                  ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-800'
                                  : normalizedStatus === 'Disabled'
                                  ? 'bg-slate-100 text-slate-700 border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                                  : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-800'
                              }`}
                            >
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  normalizedStatus === 'Active'
                                    ? 'bg-emerald-500'
                                    : normalizedStatus === 'Suspended'
                                    ? 'bg-rose-500'
                                    : normalizedStatus === 'Disabled'
                                    ? 'bg-slate-400'
                                    : 'bg-amber-500'
                                }`}
                              />
                              {normalizedStatus}
                            </span>

                            {/* Quick Status Lifecycle Buttons */}
                            <div className="flex flex-wrap gap-1">
                              {normalizedStatus !== 'Active' && (
                                <button
                                  type="button"
                                  onClick={() => handleOpenStatusModal(usr, 'Active')}
                                  className="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 cursor-pointer transition-all"
                                  title="Activate user account"
                                >
                                  Activate
                                </button>
                              )}
                              {normalizedStatus !== 'Disabled' && (
                                <button
                                  type="button"
                                  onClick={() => handleOpenStatusModal(usr, 'Disabled')}
                                  className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700 cursor-pointer transition-all"
                                  title="Disable user account"
                                >
                                  Disable
                                </button>
                              )}
                              {normalizedStatus !== 'Suspended' && (
                                <button
                                  type="button"
                                  onClick={() => handleOpenStatusModal(usr, 'Suspended')}
                                  className="px-2 py-0.5 rounded text-[9px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800 cursor-pointer transition-all"
                                  title="Suspend user account immediately"
                                >
                                  Suspend
                                </button>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* 3. Authoritative Role, Additional Roles & Effective Permissions (Tablet & Desktop md+) */}
                        <td className="hidden md:table-cell py-3.5 px-3">
                          <div className="space-y-1.5 min-w-[200px]">
                            <div className="flex items-center gap-1 text-[9px] font-extrabold uppercase tracking-wider text-slate-400">
                              <span>Primary Role</span>
                            </div>
                            {permissions.canAssignRoles ? (
                              <select
                                value={primaryRoleCode}
                                disabled={rbacBusyUserId === usr.id}
                                onChange={(e) => handleRequestInlineRoleChange(usr, e.target.value as UserRole)}
                                aria-label={`Set primary role for ${usr.name}`}
                                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-bold text-blue-700 dark:text-blue-300 cursor-pointer shadow-xs"
                              >
                                <option value="SYSTEM_ADMIN">Super Administrator (SYSTEM_ADMIN)</option>
                                <option value="MANAGER">Branch / Operations Manager (MANAGER)</option>
                                <option value="PASTOR">Pastor & Counselor (PASTOR)</option>
                                <option value="MINISTRY_LEADER">Ministry Leader (MINISTRY_LEADER)</option>
                                <option value="REGULAR_MEMBER">Regular Member (REGULAR_MEMBER)</option>
                              </select>
                            ) : (
                              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-200 inline-block">
                                {ROLE_DISPLAY_LABELS[primaryRoleCode] || usr.role}
                              </span>
                            )}

                            {/* Additional Roles Section */}
                            <div className="pt-0.5 space-y-1">
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-[9px] font-extrabold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                                  Additional Roles ({extraRoles.length})
                                </span>
                              </div>
                              {extraRoles.length > 0 ? (
                                <div className="flex flex-wrap gap-1">
                                  {extraRoles.map((r) => (
                                    <span
                                      key={r}
                                      className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/70 dark:text-purple-300 border border-purple-200 dark:border-purple-800 inline-flex items-center gap-1"
                                      title={`Additional Assigned Role: ${r}`}
                                    >
                                      <span>+{ROLE_DISPLAY_LABELS[r] || r}</span>
                                      {permissions.canAssignRoles && (
                                        <button
                                          type="button"
                                          disabled={rbacBusyUserId === usr.id}
                                          onClick={() => handleRemoveRoleFromUser(usr, r)}
                                          className="hover:text-rose-600 dark:hover:text-rose-400 font-black cursor-pointer ml-0.5"
                                          title={`Remove ${r} role from ${usr.name}`}
                                          aria-label={`Remove ${r} role from ${usr.name}`}
                                        >
                                          ×
                                        </button>
                                      )}
                                    </span>
                                  ))}
                                </div>
                              ) : (
                                <div className="text-[10px] text-slate-400 italic">None assigned</div>
                              )}

                              {permissions.canAssignRoles && (
                                <div className="pt-0.5">
                                  <select
                                    value=""
                                    disabled={rbacBusyUserId === usr.id}
                                    onChange={(e) => {
                                      if (e.target.value) {
                                        handleAddRoleToUser(usr, e.target.value as UserRole);
                                      }
                                    }}
                                    aria-label={`Add additional role to ${usr.name}`}
                                    className="w-full p-1 rounded-md border border-dashed border-purple-300 dark:border-purple-800 bg-purple-50/40 dark:bg-purple-950/30 text-[10px] font-bold text-purple-700 dark:text-purple-300 cursor-pointer"
                                  >
                                    <option value="">+ Add Role (Keep Primary)...</option>
                                    {ALL_SYSTEM_ROLES.filter(
                                      (r) =>
                                        r !== primaryRoleCode &&
                                        !extraRoles.includes(r) &&
                                        (isSuperAdmin || r !== 'SYSTEM_ADMIN')
                                    ).map((r) => (
                                      <option key={r} value={r}>
                                        + {ROLE_DISPLAY_LABELS[r]} ({r})
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              )}
                            </div>

                            {/* Effective Permissions Summary & Inspector Button */}
                            {(() => {
                              const effPerms =
                                usr.effectivePermissions && usr.effectivePermissions.length > 0
                                  ? usr.effectivePermissions
                                  : computeEffectivePermissions(primaryRoleCode, extraRoles, usr.deniedPermissions || [])
                                      .effectivePermissions;
                              return (
                                <div className="pt-1 flex items-center justify-between gap-1.5 border-t border-slate-100 dark:border-slate-800/80">
                                  <span
                                    className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400"
                                    title={effPerms.join(', ')}
                                  >
                                    {effPerms.length} Effective Perm{effPerms.length === 1 ? '' : 's'}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleOpenEffectivePermissionsModal(usr)}
                                    className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 cursor-pointer transition-all inline-flex items-center gap-1"
                                    title="View Effective Permissions (union of all assigned roles + explicit deny rules)"
                                  >
                                    <ShieldCheck className="w-2.5 h-2.5" /> View Permissions
                                  </button>
                                </div>
                              );
                            })()}
                          </div>
                        </td>

                        {/* 4. Multi-Campus Access (Desktop lg+) */}
                        <td className="hidden lg:table-cell py-3.5 px-3">
                          <div className="space-y-1.5 min-w-[170px]">
                            <div className="text-[10px] font-bold text-slate-700 dark:text-slate-200">
                              Primary: {(usr.branchName || campusList[0] || 'Headquarters').replace('Grace Cathedral ', '')}
                            </div>
                            <div className="flex flex-wrap gap-1 max-w-[220px]">
                              {campusList.map((camp, idx) => (
                                <span
                                  key={idx}
                                  className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60 inline-flex items-center gap-1"
                                >
                                  <span>{camp.replace('Grace Cathedral ', '').replace('Branch', '').trim()}</span>
                                  {permissions.canAssignRoles && campusList.length > 1 && (
                                    <button
                                      type="button"
                                      disabled={rbacBusyUserId === usr.id}
                                      onClick={() => handleRemoveCampusFromUser(usr, camp)}
                                      className="hover:text-rose-600 dark:hover:text-rose-400 font-black cursor-pointer ml-0.5"
                                      title={`Remove campus ${camp} from ${usr.name}`}
                                      aria-label={`Remove campus ${camp} from ${usr.name}`}
                                    >
                                      ×
                                    </button>
                                  )}
                                </span>
                              ))}
                            </div>
                            {permissions.canAssignRoles &&
                              branches.some((b) => !campusList.includes(b.name)) && (
                                <select
                                  value=""
                                  disabled={rbacBusyUserId === usr.id}
                                  onChange={(e) => {
                                    if (e.target.value) {
                                      handleAddCampusToUser(usr, e.target.value);
                                    }
                                  }}
                                  aria-label={`Assign branch or campus to ${usr.name}`}
                                  className="w-full p-1 rounded-md border border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/40 dark:bg-indigo-950/30 text-[10px] font-bold text-indigo-700 dark:text-indigo-300 cursor-pointer"
                                >
                                  <option value="">+ Assign Campus...</option>
                                  {branches
                                    .filter((b) => !campusList.includes(b.name))
                                    .map((b) => (
                                      <option key={b.id} value={b.name}>
                                        + {b.name}
                                      </option>
                                    ))}
                                </select>
                              )}
                          </div>
                        </td>

                        {/* 5. Two-Factor Auth (Tablet & Desktop md+) */}
                        <td className="hidden md:table-cell py-3.5 px-3">
                          <div className="flex flex-col gap-1 items-start">
                            <span
                              className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isMfaActive
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                  : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  isMfaActive ? 'bg-emerald-500' : 'bg-slate-400'
                                }`}
                              />
                              {isMfaActive ? (usr.mfaEnrolled ? 'Enrolled & Active' : 'Enabled') : 'Disabled'}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleOpen2FaModal(usr, isMfaActive ? 'disable' : 'enable')}
                              className={`px-2.5 py-1 rounded-md text-[10px] font-bold inline-flex items-center gap-1 cursor-pointer transition-all border shadow-2xs ${
                                isMfaActive
                                  ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 dark:border-rose-800'
                                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/80 dark:text-emerald-300 dark:border-emerald-800'
                              }`}
                              title={isMfaActive ? 'Disable Two-Factor Authentication' : 'Enroll & Enable Two-Factor Authentication'}
                            >
                              {isMfaActive ? (
                                <>
                                  <ShieldOff className="w-3 h-3" /> Disable 2FA
                                </>
                              ) : (
                                <>
                                  <ShieldCheck className="w-3 h-3" /> Enable 2FA
                                </>
                              )}
                            </button>
                          </div>
                        </td>

                        {/* 6. Actions: Three Dots (⋮) on Mobile, Edit + More actions (⋮) on Desktop */}
                        <td className="py-3.5 px-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 z-10">
                          <ActionMenu
                            recordTitle={usr.name}
                            recordSubtitle={`${normalizedStatus} › ${ROLE_DISPLAY_LABELS[primaryRoleCode] || usr.role} › ${shortPrimaryCampus} › ${isMfaActive ? '2FA Active' : '2FA Off'}`}
                            secondaryDesktopActions={[
                              {
                                id: 'edit-desktop-inline',
                                label: 'Edit',
                                icon: <Edit3 className="w-3.5 h-3.5" />,
                                variant: 'primary',
                                onClick: () => openEditUserModal(usr),
                              },
                              {
                                id: 'reset-pwd-inline',
                                label: 'Reset Pwd',
                                icon: <KeyRound className="w-3.5 h-3.5" />,
                                variant: 'amber',
                                onClick: () => handleOpenResetModal(usr),
                              },
                            ]}
                            items={[
                              {
                                id: 'edit',
                                label: 'Edit User, Roles & Campuses',
                                icon: <Edit3 className="w-3.5 h-3.5 text-blue-500" />,
                                badge: `${campusList.length} Campus${campusList.length === 1 ? '' : 'es'}`,
                                onClick: () => openEditUserModal(usr),
                              },
                              {
                                id: 'view-permissions',
                                label: 'Role & Effective Permissions',
                                icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />,
                                badge: ROLE_DISPLAY_LABELS[primaryRoleCode] || usr.role,
                                onClick: () => handleOpenEffectivePermissionsModal(usr),
                              },
                              {
                                id: 'toggle-2fa',
                                label: isMfaActive ? 'Disable Two-Factor (2FA)' : 'Enable Two-Factor (2FA)',
                                icon: isMfaActive ? (
                                  <ShieldOff className="w-3.5 h-3.5 text-rose-500" />
                                ) : (
                                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                                ),
                                badge: isMfaActive ? '2FA Active' : '2FA Off',
                                onClick: () => handleOpen2FaModal(usr, isMfaActive ? 'disable' : 'enable'),
                              },
                              {
                                id: 'reset-password',
                                label: 'Reset Password',
                                icon: <KeyRound className="w-3.5 h-3.5 text-amber-500" />,
                                dividerBefore: true,
                                onClick: () => handleOpenResetModal(usr),
                              },
                              {
                                id: 'force-change',
                                label: 'Force Password Change',
                                icon: <Lock className="w-3.5 h-3.5 text-orange-500" />,
                                onClick: () => handleOpenForcePwdModal(usr),
                              },
                              {
                                id: 'revoke-sessions',
                                label: 'Revoke Active Sessions',
                                icon: <LogOut className="w-3.5 h-3.5 text-purple-500" />,
                                onClick: () => handleOpenRevokeSessionsModal(usr),
                              },
                              {
                                id: 'security-events',
                                label: 'Security & Audit Events',
                                icon: <History className="w-3.5 h-3.5 text-indigo-500" />,
                                onClick: () => handleOpenSecurityEventsModal(usr),
                              },
                              {
                                id: 'status-activate',
                                label: 'Activate Account',
                                icon: <UserCheck className="w-3.5 h-3.5 text-emerald-600" />,
                                variant: 'emerald',
                                badge: `Now: ${normalizedStatus}`,
                                dividerBefore: true,
                                hidden: normalizedStatus === 'Active',
                                onClick: () => handleOpenStatusModal(usr, 'Active'),
                              },
                              {
                                id: 'status-disable',
                                label: 'Disable Account',
                                icon: <UserX className="w-3.5 h-3.5 text-slate-500" />,
                                badge: `Now: ${normalizedStatus}`,
                                dividerBefore: normalizedStatus === 'Active',
                                hidden: normalizedStatus === 'Disabled',
                                onClick: () => handleOpenStatusModal(usr, 'Disabled'),
                              },
                              {
                                id: 'status-suspend',
                                label: 'Suspend Account',
                                icon: <Ban className="w-3.5 h-3.5 text-amber-600" />,
                                variant: 'amber',
                                hidden: normalizedStatus === 'Suspended',
                                onClick: () => handleOpenStatusModal(usr, 'Suspended'),
                              },
                              {
                                id: 'delete-user',
                                label: 'Delete System User',
                                icon: <Trash2 className="w-3.5 h-3.5" />,
                                variant: 'danger',
                                dividerBefore: true,
                                onClick: () => removeSystemUser(usr.id),
                              },
                            ]}
                          />
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: 2FA & SECURITY GOVERNANCE (Real Backend-Connected Security Dashboard) */}
      {activeSubTab === 'security' && (
        <div className="space-y-6">
          <SecurityAuditModule />
        </div>
      )}

      {/* SUB-TAB 5: BACKUP & RESTORE */}
      {activeSubTab === 'backup' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Download className="w-4 h-4 text-purple-600" /> Database Backup, Import & System Restore
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Export full system snapshot as JSON, restore previous database backups, or reset system data.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            {/* Export */}
            <div className="p-4 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-800 space-y-2 flex flex-col justify-between">
              <div className="space-y-1">
                <div className="font-bold text-purple-900 dark:text-purple-200 flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-purple-600" /> Export Backup
                </div>
                <p className="text-[11px] text-purple-700 dark:text-purple-300">
                  Download complete state including members, branches, transactions, and devotions.
                </p>
              </div>
              <button
                onClick={handleExportBackup}
                className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> Export JSON Snapshot
              </button>
            </div>

            {/* Restore */}
            <div className="p-4 bg-blue-50 dark:bg-blue-950/40 rounded-2xl border border-blue-200 dark:border-blue-800 space-y-2 flex flex-col justify-between">
              <div className="space-y-1">
                <div className="font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-blue-600" /> Restore Database
                </div>
                <p className="text-[11px] text-blue-700 dark:text-blue-300">
                  Upload a previously saved JSON backup file to overwrite or restore database state.
                </p>
              </div>
              <input
                type="file"
                ref={backupFileInputRef}
                accept=".json"
                onChange={handleRestoreBackupFile}
                className="hidden"
              />
              <button
                onClick={() => backupFileInputRef.current?.click()}
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" /> Import JSON Backup File
              </button>
            </div>

            {/* Retrieve All Database Data */}
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 space-y-2 flex flex-col justify-between">
              <div className="space-y-1">
                <div className="font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-emerald-600" /> Retrieve Database
                </div>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-300">
                  Retrieve and download all raw data directly from the persistent database.
                </p>
              </div>
              <button
                disabled={isRetrievingAllData}
                onClick={handleRetrieveAllData}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                {isRetrievingAllData ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Database className="w-3.5 h-3.5" />}
                {isRetrievingAllData ? 'Retrieving Data...' : 'Retrieve All Data'}
              </button>
            </div>

            {/* Purge Demo & Autofill Records */}
            <div className="p-4 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800 space-y-2 flex flex-col justify-between">
              <div className="space-y-1">
                <div className="font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <Trash2 className="w-4 h-4 text-amber-600" /> Purge Demo Data
                </div>
                <p className="text-[11px] text-amber-700 dark:text-amber-300">
                  Clean database by purging all mock, demo, and autofill test records.
                </p>
              </div>
              <button
                disabled={isCleaningDemo}
                onClick={handleCleanupDemo}
                className="w-full py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                {isCleaningDemo ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                {isCleaningDemo ? 'Purging Demo...' : 'Purge Demo & Autofill'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB: LANGUAGE & REGIONAL LOCALIZATION */}
      {activeSubTab === 'localization' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-600" /> System Language & Regional Localization
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Select the primary system language. Changing this applies instantly across all modules, navigation bars, tables, dialogs, and mobile views.
              </p>
            </div>
            <span className="self-start sm:self-auto px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
              Active: {language}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                id: 'English',
                name: 'English',
                native: 'English',
                desc: 'Universal International & Default Church Administration Language',
                flag: '🇬🇧',
                code: 'en',
              },
              {
                id: 'Amharic',
                name: 'Amharic',
                native: 'አማርኛ',
                desc: 'Ethiopian National Church Service & Liturgical Scripture Language',
                flag: '🇪🇹',
                code: 'am',
              },
              {
                id: 'Tigrigna',
                name: 'Tigrigna',
                native: 'ትግርኛ',
                desc: 'Northern Ethiopian & Eritrean Christian Fellowship Language',
                flag: '🇪🇹',
                code: 'ti',
              },
              {
                id: 'Afaan Oromoo',
                name: 'Afaan Oromoo',
                native: 'Afaan Oromoo',
                desc: 'Oromia Regional Fellowship & Evangelical Community Language',
                flag: '🇪🇹',
                code: 'om',
              },
            ].map((item) => {
              const isSelected = language === item.id || language === item.name;
              return (
                <div
                  key={item.id}
                  onClick={() => handleSelectLanguage(item.id)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer flex items-start gap-4 ${
                    isSelected
                      ? 'bg-blue-50/80 dark:bg-blue-950/40 border-blue-500 shadow-sm ring-1 ring-blue-500/30'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-700'
                  }`}
                >
                  <span className="text-3xl select-none">{item.flag}</span>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                        {item.native}
                      </span>
                      {isSelected ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-blue-600 text-white flex items-center gap-1">
                          <Check className="w-3 h-3" /> Active
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 font-medium">({item.name})</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {item.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      </div>

      {/* Modal: Add System User with Multi-Campus & Approval Detail */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-lg border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 text-xs max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-blue-600" /> Add New System User & Multi-Campus Access
              </h3>
              <button
                type="button"
                disabled={isAddingUser}
                onClick={() => setIsAddUserModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            {addUserError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{addUserError}</div>
              </div>
            )}

            <form onSubmit={handleCreateUser} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Deacon Solomon Tekle"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="solomon.t@church.org"
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+251 91 123 4567"
                    value={userPhone}
                    onChange={(e) => setUserPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Primary Authoritative Role *</label>
                  <select
                    value={userRole}
                    onChange={(e) => setUserRole(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                  >
                    <option value="SYSTEM_ADMIN">Super Administrator (Full System)</option>
                    <option value="MANAGER">Branch / Operations Manager</option>
                    <option value="PASTOR">Pastor & Counselor</option>
                    <option value="MINISTRY_LEADER">Ministry Leader</option>
                    <option value="REGULAR_MEMBER">Regular Member ($0 Limit / View Only)</option>
                  </select>
                </div>
              </div>

              {/* Additional Roles (Multi-Role Assignment) */}
              <div className="p-3 bg-purple-50/50 dark:bg-purple-950/30 rounded-2xl border border-purple-200/80 dark:border-purple-800/60 space-y-2">
                <label className="block font-bold text-purple-900 dark:text-purple-200">
                  Additional Roles (Multi-Role Permissions)
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_SYSTEM_ROLES.filter((r) => r !== normalizeUserRole(userRole)).map((roleCode) => {
                    const isChecked = userAdditionalRoles.includes(roleCode);
                    return (
                      <button
                        key={roleCode}
                        type="button"
                        onClick={() => {
                          if (isChecked) {
                            setUserAdditionalRoles(userAdditionalRoles.filter((r) => r !== roleCode));
                          } else {
                            setUserAdditionalRoles([...userAdditionalRoles, roleCode]);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
                          isChecked
                            ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {isChecked ? '✓ ' : '+ '}
                        {ROLE_DISPLAY_LABELS[roleCode]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Multi-Campus Checkboxes */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="block font-bold text-slate-700 dark:text-slate-300">
                    Primary & Multi-Campus Access
                  </label>
                  <select
                    value={userPrimaryBranch}
                    onChange={(e) => {
                      setUserPrimaryBranch(e.target.value);
                      if (!userBranches.includes(e.target.value)) {
                        setUserBranches([e.target.value, ...userBranches]);
                      }
                    }}
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold text-blue-700 dark:text-blue-300"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.name}>
                        Primary: {b.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                  {branches.map((b) => {
                    const isChecked = userBranches.includes(b.name);
                    return (
                      <label
                        key={b.id}
                        className={`flex items-center gap-2 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-blue-50/80 border-blue-300 dark:bg-blue-950/50 dark:border-blue-700 font-bold text-blue-900 dark:text-blue-200'
                            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setUserBranches([...userBranches, b.name]);
                            } else {
                              setUserBranches(userBranches.filter((name) => name !== b.name));
                            }
                          }}
                          className="rounded text-blue-600 focus:ring-blue-500"
                        />
                        <span className="truncate">{b.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Approval Detail Information */}
              <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200/80 dark:border-emerald-800/60 space-y-3">
                <div className="flex items-center gap-2 font-bold text-emerald-900 dark:text-emerald-200">
                  <Check className="w-4 h-4 text-emerald-600" /> Approval Authorization Tier
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Approver Role Level
                  </label>
                  <select
                    value={userApprovalRoleLevel}
                    onChange={(e) => setUserApprovalRoleLevel(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  >
                    <option value="Standard Staff">Standard Staff</option>
                    <option value="Ministry Lead">Ministry Lead</option>
                    <option value="Junior Approver">Junior Approver</option>
                    <option value="Senior Approver">Senior Approver</option>
                    <option value="Executive Sign-off">Executive Sign-off</option>
                    <option value="Board Trustee">Board Trustee</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Allowed Approval Workflows
                  </label>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {['Budget Requests', 'Purchase Vouchers', 'Event Grants', 'Member Excommunication', 'Leave Requests', 'Facility Bookings'].map(
                      (type) => {
                        const isSelected = userAllowedApprovals.includes(type);
                        return (
                          <button
                            key={type}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setUserAllowedApprovals(userAllowedApprovals.filter((t) => t !== type));
                              } else {
                                setUserAllowedApprovals([...userAllowedApprovals, type]);
                              }
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
                              isSelected
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {type}
                          </button>
                        );
                      }
                    )}
                  </div>
                </div>
              </div>

              {/* Temporary Password Configuration */}
              <div className="p-3.5 bg-blue-50/70 dark:bg-blue-950/40 rounded-2xl border border-blue-200/80 dark:border-blue-800/60 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-blue-900 dark:text-blue-200">
                    <KeyRound className="w-4 h-4 text-blue-600" /> Initial Temporary Password
                  </div>
                  <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-400">
                    Mandatory 1st-Login Change
                  </span>
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setUserTempPassword(generateClientTempPassword())}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400 transition-all"
                  >
                    Generate Crypto Random
                  </button>
                  <button
                    type="button"
                    onClick={() => setUserTempPassword('Pass@12345')}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400 transition-all"
                  >
                    Default (Pass@12345)
                  </button>
                </div>

                <div className="relative">
                  <input
                    type={showUserTempPassword ? 'text' : 'password'}
                    required
                    value={userTempPassword}
                    onChange={(e) => setUserTempPassword(e.target.value)}
                    placeholder="Enter or generate temporary password"
                    className="w-full pl-3 pr-10 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowUserTempPassword(!showUserTempPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                    aria-label={showUserTempPassword ? 'Hide password' : 'Show password'}
                  >
                    {showUserTempPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  disabled={isAddingUser}
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAddingUser}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-md cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
                >
                  {isAddingUser && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  {isAddingUser ? 'Creating Account...' : 'Create System Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit System User & Multi-Campus Access & Approval Detail */}
      {isEditUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-lg border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 text-xs max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-blue-600" /> Edit System User & Multi-Campus Access
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">Modify roles, campus permissions, and approval tiers for {editUserName}</p>
              </div>
              <button
                type="button"
                disabled={isSavingEditUser}
                onClick={() => setIsEditUserModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            {editUserError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{editUserError}</div>
              </div>
            )}

            <form onSubmit={handleSaveEditUser} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={editUserName}
                    onChange={(e) => setEditUserName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={editUserEmail}
                    onChange={(e) => setEditUserEmail(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={editUserPhone}
                    onChange={(e) => setEditUserPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Primary Role</label>
                  <select
                    value={editUserRole}
                    onChange={(e) => setEditUserRole(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                  >
                    <option value="SYSTEM_ADMIN">Super Administrator (Full System)</option>
                    <option value="MANAGER">Branch / Operations Manager</option>
                    <option value="PASTOR">Pastor & Counselor</option>
                    <option value="MINISTRY_LEADER">Ministry Leader</option>
                    <option value="REGULAR_MEMBER">Regular Member ($0 Limit / View Only)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Account Status</label>
                  <select
                    value={editUserStatus}
                    onChange={(e) => setEditUserStatus(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                  >
                    <option value="Active">Active</option>
                    <option value="Disabled">Disabled</option>
                    <option value="Suspended">Suspended</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>

              {/* Multi-Role Checkboxes */}
              <div className="p-3 bg-purple-50/50 dark:bg-purple-950/30 rounded-2xl border border-purple-200/80 dark:border-purple-800/60 space-y-2">
                <label className="block font-bold text-purple-900 dark:text-purple-200">
                  Additional Assigned Roles (Multi-Role Support)
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_SYSTEM_ROLES.filter((r) => r !== normalizeUserRole(editUserRole)).map((roleCode) => {
                    const isChecked = editUserAdditionalRoles.includes(roleCode);
                    return (
                      <button
                        key={roleCode}
                        type="button"
                        onClick={() => {
                          if (isChecked) {
                            setEditUserAdditionalRoles(editUserAdditionalRoles.filter((r) => r !== roleCode));
                          } else {
                            setEditUserAdditionalRoles([...editUserAdditionalRoles, roleCode]);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
                          isChecked
                            ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {isChecked ? '✓ ' : '+ '}
                        {ROLE_DISPLAY_LABELS[roleCode]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Multi-Campus Checkboxes */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="block font-bold text-slate-700 dark:text-slate-300">
                    Authorized Campus Branches (Multi-Campus Access)
                  </label>
                  <select
                    value={editUserPrimaryBranch}
                    onChange={(e) => {
                      setEditUserPrimaryBranch(e.target.value);
                      if (!editUserBranches.includes(e.target.value)) {
                        setEditUserBranches([e.target.value, ...editUserBranches]);
                      }
                    }}
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold text-blue-700 dark:text-blue-300"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.name}>
                        Primary: {b.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                  {branches.map((b) => {
                    const isChecked = editUserBranches.includes(b.name);
                    return (
                      <label
                        key={b.id}
                        className={`flex items-center gap-2 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-blue-50/80 border-blue-300 dark:bg-blue-950/50 dark:border-blue-700 font-bold text-blue-900 dark:text-blue-200'
                            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setEditUserBranches([...editUserBranches, b.name]);
                            } else {
                              setEditUserBranches(editUserBranches.filter((name) => name !== b.name));
                            }
                          }}
                          className="rounded text-blue-600 focus:ring-blue-500"
                        />
                        <span className="truncate">{b.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Approval Detail Information */}
              <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200/80 dark:border-emerald-800/60 space-y-3">
                <div className="flex items-center gap-2 font-bold text-emerald-900 dark:text-emerald-200">
                  <Check className="w-4 h-4 text-emerald-600" /> Approval Authorization Limits
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Approver Role Level
                  </label>
                  <select
                    value={editUserApprovalRoleLevel}
                    onChange={(e) => setEditUserApprovalRoleLevel(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  >
                    <option value="Standard Staff">Standard Staff</option>
                    <option value="Ministry Lead">Ministry Lead</option>
                    <option value="Junior Approver">Junior Approver (Up to $5,000)</option>
                    <option value="Senior Approver">Senior Approver (Up to $50,000)</option>
                    <option value="Finance Auditor">Finance Auditor</option>
                    <option value="Executive Sign-off">Executive Sign-off (Unlimited)</option>
                    <option value="Board Trustee">Board Trustee</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Allowed Approval Workflows
                  </label>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {['Budget Requests', 'Purchase Vouchers', 'Event Grants', 'Member Excommunication', 'Leave Requests', 'Facility Bookings'].map(
                      (type) => {
                        const isSelected = editUserAllowedApprovals.includes(type);
                        return (
                          <button
                            key={type}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setEditUserAllowedApprovals(editUserAllowedApprovals.filter((t) => t !== type));
                              } else {
                                setEditUserAllowedApprovals([...editUserAllowedApprovals, type]);
                              }
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
                              isSelected
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {type}
                          </button>
                        );
                      }
                    )}
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Administrative & Delegation Notes
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Authorized for Bole & HQ capital expenditure and youth budget"
                    value={editUserNotes}
                    onChange={(e) => setEditUserNotes(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  disabled={isSavingEditUser}
                  onClick={() => setIsEditUserModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingEditUser}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-md cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
                >
                  {isSavingEditUser && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  {isSavingEditUser ? 'Saving Changes...' : 'Save Changes & Authorizations'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Created User Temporary Password Confirmation */}
      {createdUserModal?.isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-md border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-in zoom-in-95 duration-150">
            <div className="text-center space-y-1.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center font-bold">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Staff Account Created Successfully
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                A temporary credential has been generated for {createdUserModal.name} ({createdUserModal.email}).
              </p>
            </div>

            {/* Temporary Password Box */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold">
                <span>Temporary Password</span>
                <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold uppercase">
                  Expires in 24 hours
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 font-mono text-sm font-bold text-slate-900 dark:text-white select-all">
                <span className="tracking-wider">{createdUserModal.tempPassword}</span>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(createdUserModal.tempPassword);
                    setCreatedUserModal({ ...createdUserModal, isCopied: true });
                    setTimeout(() => {
                      if (createdUserModal) {
                        setCreatedUserModal((prev) => (prev ? { ...prev, isCopied: false } : null));
                      }
                    }, 2500);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    createdUserModal.isCopied
                      ? 'bg-emerald-600 text-white'
                      : 'bg-blue-600 hover:bg-blue-500 text-white'
                  }`}
                >
                  {createdUserModal.isCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5" /> Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Copy
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Security Warning Notice */}
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 text-xs flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="space-y-0.5 leading-relaxed">
                <p className="font-bold">Mandatory First-Login Password Change</p>
                <p className="text-[11px] text-amber-700 dark:text-amber-400 font-normal">
                  The staff member must change this temporary password upon initial login before they can access any CMMS dashboard or records.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setCreatedUserModal(null)}
              className="w-full py-2.5 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all"
            >
              Done & Close
            </button>
          </div>
        </div>
      )}

      {/* Modal: Admin Reset Staff Temporary Password */}
      {resetModal?.isOpen && resetModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-md border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-500" />
                {!resetModal.isConfirmed
                  ? `Reset password for ${resetModal.user.name}?`
                  : 'Password reset successfully.'}
              </h3>
              <button
                type="button"
                disabled={isResetting}
                onClick={() => setResetModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-50 cursor-pointer"
                aria-label="Close dialog"
              >
                ✕
              </button>
            </div>

            {!resetModal.isConfirmed ? (
              <div className="space-y-4 text-xs">
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  Continuing will generate a temporary one-time password. The user will be required to create a new password at their next login.
                </p>

                {/* Target User Summary Card */}
                <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">{resetModal.user.name}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">{resetModal.user.email}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Campus: {resetModal.user.branchName || 'Headquarters Campus'}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded-lg bg-blue-500/10 text-blue-600 dark:text-blue-400 text-[10px] font-mono font-bold uppercase">
                    {resetModal.user.role}
                  </span>
                </div>

                {/* Error Banner */}
                {resetModal.error && (
                  <div
                    role="alert"
                    className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2"
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <div className="font-medium">{resetModal.error}</div>
                  </div>
                )}

                {/* Optional Custom Password vs Random Generation */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-slate-700 dark:text-slate-300">
                      Temporary Password (Optional)
                    </label>
                    <span className="text-[10px] text-slate-400">Leave blank for crypto generation</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setResetModalPasswordInput('Pass@12345')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer border transition-all ${
                        resetModalPasswordInput === 'Pass@12345'
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400'
                      }`}
                    >
                      Default (Pass@12345)
                    </button>
                    <button
                      type="button"
                      onClick={() => setResetModalPasswordInput(generateClientTempPassword())}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer border bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400 transition-all"
                    >
                      Generate Random
                    </button>
                    {resetModalPasswordInput && (
                      <button
                        type="button"
                        onClick={() => setResetModalPasswordInput('')}
                        className="px-2 py-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    value={resetModalPasswordInput}
                    onChange={(e) => setResetModalPasswordInput(e.target.value)}
                    placeholder="Auto-generated cryptographically secure temporary password"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>

                <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 text-[11px] leading-relaxed space-y-1">
                  <div className="flex items-center gap-1.5 font-bold">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0" /> Security Impact:
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-amber-700 dark:text-amber-400">
                    <li>Previous temporary passwords and active sessions will be invalidated immediately.</li>
                    <li>Temporary password is valid for 24 hours.</li>
                    <li>The staff member is forced to create a new password upon login.</li>
                  </ul>
                </div>

                <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    disabled={isResetting}
                    onClick={() => setResetModal(null)}
                    className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={isResetting}
                    onClick={handleConfirmResetPassword}
                    className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold cursor-pointer transition-all shadow-md disabled:opacity-50 flex items-center gap-2"
                  >
                    {isResetting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                    <span>{isResetting ? 'Resetting Password...' : 'Reset Password'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 space-y-2.5">
                  <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 font-semibold">
                    <span className="font-bold text-emerald-800 dark:text-emerald-300">Temporary password:</span>
                    <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold uppercase">
                      Expires in 24 hours
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 font-mono text-sm font-bold text-slate-900 dark:text-white select-all">
                    <span className="tracking-wider">{resetModal.tempPassword}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(resetModal.tempPassword);
                        setResetModal({ ...resetModal, isCopied: true });
                        setTimeout(() => {
                          if (resetModal) {
                            setResetModal((prev) => (prev ? { ...prev, isCopied: false } : null));
                          }
                        }, 2500);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                        resetModal.isCopied
                          ? 'bg-emerald-600 text-white'
                          : 'bg-blue-600 hover:bg-blue-500 text-white'
                      }`}
                    >
                      {resetModal.isCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> Copy
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-950/50 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1 text-slate-600 dark:text-slate-300 leading-relaxed">
                  <p className="font-bold text-slate-900 dark:text-white">Next Steps:</p>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-500 dark:text-slate-400">
                    <li>Give this temporary password to the user securely.</li>
                    <li>User must change this password after signing in.</li>
                    <li>They will be redirected to the mandatory password-change screen automatically upon login.</li>
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={() => setResetModal(null)}
                  className="w-full py-2.5 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Enable / Disable 2FA (Full TOTP Enrollment + Verification Flow) */}
      {twoFaModal?.isOpen && twoFaModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div
                  className={`p-2.5 rounded-xl ${
                    twoFaModal.action === 'enable'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                      : 'bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {twoFaModal.action === 'enable' ? (
                    <ShieldCheck className="w-5 h-5" />
                  ) : (
                    <ShieldAlert className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                    {twoFaModal.action === 'enable'
                      ? twoFaModal.step === 'verify'
                        ? 'Verify TOTP Authenticator Code'
                        : 'Enroll Two-Factor Authentication'
                      : 'Disable Two-Factor Authentication'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {twoFaModal.action === 'enable'
                      ? 'RFC 6238 TOTP Authenticator Enrollment'
                      : 'Remove multi-factor authentication requirement'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={twoFaModal.isProcessing}
                onClick={() => setTwoFaModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            {/* Target User Details */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
              <div>
                <p className="font-bold text-xs text-slate-900 dark:text-white">{twoFaModal.user.name}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{twoFaModal.user.email}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Campus: {twoFaModal.user.branchName || 'Headquarters Campus'}
                </p>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                {twoFaModal.user.role}
              </span>
            </div>

            {twoFaModal.error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{twoFaModal.error}</div>
              </div>
            )}

            {twoFaModal.action === 'enable' && twoFaModal.step === 'confirm' && (
              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
                <p className="font-bold text-slate-900 dark:text-white">
                  Start TOTP 2FA enrollment for {twoFaModal.user.name}?
                </p>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                  Clicking <strong>Generate TOTP Factor</strong> will provision a cryptographic RFC 6238 TOTP secret and QR code on the server. You can then scan the QR code or enter the verification code to activate 2FA.
                </p>
              </div>
            )}

            {twoFaModal.action === 'enable' && twoFaModal.step === 'verify' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
                  <p className="font-bold">Step 1: Scan QR Code with Authenticator App</p>
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">
                    Have the user scan this QR code in Google Authenticator, Authy, or Microsoft Authenticator.
                  </p>
                </div>

                {twoFaModal.qrUrl && (
                  <div className="flex flex-col items-center justify-center p-4 bg-white rounded-2xl border border-slate-200 shadow-inner">
                    <img
                      src={twoFaModal.qrUrl}
                      alt="TOTP QR Code"
                      className="w-44 h-44 object-contain"
                    />
                  </div>
                )}

                {twoFaModal.secret && (
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Manual Setup Key (Base32 Secret)
                    </span>
                    <div className="flex items-center justify-between gap-2 font-mono text-xs font-bold text-slate-900 dark:text-white select-all">
                      <span className="break-all">{twoFaModal.secret}</span>
                      <button
                        type="button"
                        onClick={() => navigator.clipboard.writeText(twoFaModal.secret || '')}
                        className="px-2 py-1 rounded bg-blue-600 text-white text-[10px] font-sans font-bold shrink-0 cursor-pointer"
                      >
                        Copy Key
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-1.5 pt-1">
                  <label className="block font-bold text-slate-800 dark:text-slate-200">
                    Step 2: Enter 6-Digit Authenticator Code to Verify & Activate
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    value={twoFaModal.totpCode}
                    onChange={(e) =>
                      setTwoFaModal((prev) =>
                        prev ? { ...prev, totpCode: e.target.value.replace(/\D/g, '').slice(0, 6), error: null } : null
                      )
                    }
                    placeholder="000000"
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-center font-mono text-base font-black tracking-[0.35em] text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {twoFaModal.action === 'disable' && (
              <div className="space-y-3 text-xs">
                <p className="font-bold text-slate-900 dark:text-white">
                  Disable two-factor authentication for {twoFaModal.user.name}?
                </p>
                <div className="p-3 bg-rose-50/70 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-800 dark:text-rose-300 space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0" /> Security Warning
                  </p>
                  <p className="leading-relaxed text-[11px]">
                    This will unenroll the user's active TOTP factor and remove the 2FA requirement on login. This action is recorded in the security audit log.
                  </p>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Audit Reason (Optional)
                  </label>
                  <input
                    type="text"
                    value={twoFaModal.disableReason}
                    onChange={(e) =>
                      setTwoFaModal((prev) => (prev ? { ...prev, disableReason: e.target.value } : null))
                    }
                    placeholder="e.g. Lost authenticator device - identity verified"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            )}

            <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setTwoFaModal(null)}
                disabled={twoFaModal.isProcessing}
                className="px-3.5 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirm2FaAction}
                disabled={twoFaModal.isProcessing}
                className={`px-4 py-2 text-xs font-bold text-white rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-1.5 ${
                  twoFaModal.action === 'enable'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-rose-600 hover:bg-rose-700'
                } ${twoFaModal.isProcessing ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {twoFaModal.isProcessing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Processing...
                  </>
                ) : twoFaModal.action === 'enable' ? (
                  twoFaModal.step === 'verify' ? (
                    <>
                      <Check className="w-3.5 h-3.5" /> Verify Code & Enable 2FA
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5" /> Generate TOTP Factor
                    </>
                  )
                ) : (
                  <>
                    <ShieldOff className="w-3.5 h-3.5" /> Disable 2FA
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Activate / Disable / Suspend Account Status Confirmation */}
      {statusModal?.isOpen && statusModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-500" />
                {statusModal.targetStatus === 'Active'
                  ? `Activate ${statusModal.user.name}?`
                  : statusModal.targetStatus === 'Disabled'
                  ? `Disable ${statusModal.user.name}?`
                  : `Suspend ${statusModal.user.name}?`}
              </h3>
              <button
                type="button"
                disabled={statusModal.isProcessing}
                onClick={() => setStatusModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-900 dark:text-white">{statusModal.user.name}</p>
                <p className="text-[11px] text-slate-500">{statusModal.user.email}</p>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                Current: {statusModal.user.status || 'Active'} → {statusModal.targetStatus}
              </span>
            </div>

            {statusModal.error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{statusModal.error}</div>
              </div>
            )}

            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              {statusModal.targetStatus === 'Active'
                ? 'This will restore sign-in access and allow the user to access their authorized campuses.'
                : 'This will immediately block sign-in access and revoke all active sessions for this user.'}
            </p>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Audit Reason (Optional)
              </label>
              <input
                type="text"
                value={statusModal.reason}
                onChange={(e) => setStatusModal((prev) => (prev ? { ...prev, reason: e.target.value } : null))}
                placeholder="Reason for status change..."
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                disabled={statusModal.isProcessing}
                onClick={() => setStatusModal(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={statusModal.isProcessing}
                onClick={handleConfirmStatusChange}
                className={`px-4 py-2 text-white rounded-xl font-bold shadow-md cursor-pointer inline-flex items-center gap-1.5 ${
                  statusModal.targetStatus === 'Active'
                    ? 'bg-emerald-600 hover:bg-emerald-500'
                    : statusModal.targetStatus === 'Disabled'
                    ? 'bg-slate-700 hover:bg-slate-600'
                    : 'bg-rose-600 hover:bg-rose-500'
                } disabled:opacity-50`}
              >
                {statusModal.isProcessing && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                Confirm {statusModal.targetStatus}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Role Assignment Confirmation */}
      {roleModal?.isOpen && roleModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600" /> Confirm Authoritative Role Assignment
              </h3>
              <button
                type="button"
                disabled={roleModal.isProcessing}
                onClick={() => setRoleModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1">
              <p className="font-bold text-slate-900 dark:text-white">{roleModal.user.name} ({roleModal.user.email})</p>
              <p className="text-[11px] text-blue-600 dark:text-blue-400 font-bold">
                New Primary Role: {ROLE_DISPLAY_LABELS[normalizeUserRole(roleModal.primaryRole)] || roleModal.primaryRole}
              </p>
            </div>

            {roleModal.error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{roleModal.error}</div>
              </div>
            )}

            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              This will update the user's authoritative role in PostgreSQL (`public.profiles`) and recompute their system permissions immediately.
            </p>

            <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                disabled={roleModal.isProcessing}
                onClick={() => setRoleModal(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={roleModal.isProcessing}
                onClick={handleConfirmRoleChange}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-md cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
              >
                {roleModal.isProcessing && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                Confirm Role Assignment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Force Password Change Confirmation */}
      {forcePwdModal?.isOpen && forcePwdModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-orange-600" /> Force Password Change on Next Login
              </h3>
              <button
                type="button"
                disabled={forcePwdModal.isProcessing}
                onClick={() => setForcePwdModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
              <p className="font-bold text-slate-900 dark:text-white">{forcePwdModal.user.name}</p>
              <p className="text-[11px] text-slate-500">{forcePwdModal.user.email}</p>
            </div>

            {forcePwdModal.error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{forcePwdModal.error}</div>
              </div>
            )}

            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              This sets <code className="font-mono font-bold">must_change_password = true</code> and invalidates active sessions. The user will be required to set a new password upon their next login.
            </p>

            <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                disabled={forcePwdModal.isProcessing}
                onClick={() => setForcePwdModal(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={forcePwdModal.isProcessing}
                onClick={handleConfirmForcePasswordChange}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-xl font-bold shadow-md cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
              >
                {forcePwdModal.isProcessing && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                Require Password Change
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Revoke Active Sessions Confirmation */}
      {revokeSessionsModal?.isOpen && revokeSessionsModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <LogOut className="w-4 h-4 text-purple-600" /> Revoke All Active Sessions
              </h3>
              <button
                type="button"
                disabled={revokeSessionsModal.isProcessing}
                onClick={() => setRevokeSessionsModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
              <p className="font-bold text-slate-900 dark:text-white">{revokeSessionsModal.user.name}</p>
              <p className="text-[11px] text-slate-500">{revokeSessionsModal.user.email}</p>
            </div>

            {revokeSessionsModal.error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{revokeSessionsModal.error}</div>
              </div>
            )}

            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              This will immediately invalidate all active web and mobile tokens for <strong>{revokeSessionsModal.user.name}</strong> across all devices. They will be required to sign in again.
            </p>

            <div className="pt-2 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                disabled={revokeSessionsModal.isProcessing}
                onClick={() => setRevokeSessionsModal(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={revokeSessionsModal.isProcessing}
                onClick={handleConfirmRevokeSessions}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold shadow-md cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50"
              >
                {revokeSessionsModal.isProcessing && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                Revoke All Sessions
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: View Security Events & Audit Trail */}
      {securityEventsModal?.isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-4 text-xs max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <History className="w-4 h-4 text-indigo-600" />
                  {securityEventsModal.user
                    ? `Security Events & Audit Trail — ${securityEventsModal.user.name}`
                    : 'System Security Events & Authentication Audit Log'}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {securityEventsModal.user
                    ? `Account: ${securityEventsModal.user.email} • Last Login: ${formatLastLogin(securityEventsModal.user.lastLogin)}`
                    : 'Authoritative record of logins, password resets, 2FA enrollments, role changes, and session revocations.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSecurityEventsModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            {securityEventsModal.error && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{securityEventsModal.error}</div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {securityEventsModal.isLoading ? (
                <div className="py-12 text-center text-slate-400 flex flex-col items-center gap-2">
                  <RefreshCw className="w-5 h-5 animate-spin text-indigo-500" />
                  <span>Loading authoritative security events...</span>
                </div>
              ) : securityEventsModal.events.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  No security events recorded for this filter yet.
                </div>
              ) : (
                securityEventsModal.events.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-slate-900 dark:text-white">{evt.action}</span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60">
                          {evt.module}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">{evt.details}</p>
                      <p className="text-[10px] text-slate-400">Actor: {evt.user}</p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 shrink-0">
                      {evt.timestamp ? new Date(evt.timestamp).toLocaleString() : 'Just now'}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 flex justify-end border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setSecurityEventsModal(null)}
                className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-xl font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: View Effective Permissions & RBAC Hierarchy (users -> user_roles -> roles -> role_permissions -> effective permissions) */}
      {effectivePermissionsModal?.isOpen && effectivePermissionsModal.user && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-4 text-xs max-h-[88vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Effective RBAC Permissions — {effectivePermissionsModal.user.name}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Architecture: <code className="font-mono font-bold">users → user_roles → roles → role_permissions → effective permissions</code>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEffectivePermissionsModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            {effectivePermissionsModal.error && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <div className="font-medium">{effectivePermissionsModal.error}</div>
              </div>
            )}

            {effectivePermissionsModal.data && (
              <div className="flex-1 overflow-y-auto space-y-4 pr-1">
                {/* Primary & Additional Roles Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-2xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 space-y-1">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-600 dark:text-blue-400 block">
                      Primary Authoritative Role
                    </span>
                    <div className="font-black text-sm text-blue-950 dark:text-blue-100">
                      {ROLE_DISPLAY_LABELS[effectivePermissionsModal.data.primaryRole] ||
                        effectivePermissionsModal.data.primaryRole}
                    </div>
                    <span className="inline-block font-mono text-[10px] px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 font-bold">
                      {effectivePermissionsModal.data.primaryRole}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-purple-50/70 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 space-y-1.5">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-purple-600 dark:text-purple-400 block">
                      Additional Roles ({effectivePermissionsModal.data.additionalRoles.length})
                    </span>
                    {effectivePermissionsModal.data.additionalRoles.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {effectivePermissionsModal.data.additionalRoles.map((r) => (
                          <span
                            key={r}
                            className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-purple-600 text-white"
                          >
                            + {ROLE_DISPLAY_LABELS[r] || r} ({r})
                          </span>
                        ))}
                      </div>
                    ) : (
                      <div className="text-slate-400 italic text-xs">No additional roles assigned</div>
                    )}
                  </div>
                </div>

                {/* Authorized Campuses */}
                <div className="p-3 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200/70 dark:border-indigo-800/60 space-y-1.5">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block">
                    Authorized Campuses / Branches
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(effectivePermissionsModal.data.assignedCampuses &&
                    effectivePermissionsModal.data.assignedCampuses.length > 0
                      ? effectivePermissionsModal.data.assignedCampuses
                      : [effectivePermissionsModal.data.branchName || 'Grace Cathedral Headquarters']
                    ).map((c, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200"
                      >
                        {idx === 0 ? `Primary: ${c}` : c}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Union of Effective Permissions */}
                <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/25 border border-emerald-200 dark:border-emerald-800/70 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Effective Permissions ({effectivePermissionsModal.data.effectivePermissions.length})
                    </span>
                    <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400">
                      Union of [{effectivePermissionsModal.data.roles.join(' + ')}]
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {effectivePermissionsModal.data.effectivePermissions.map((perm) => (
                      <span
                        key={perm}
                        className="px-2 py-1 rounded-lg font-mono text-[10px] font-bold bg-white dark:bg-slate-900 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 shadow-2xs"
                      >
                        {perm}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Explicit Deny Rules / Guardrails */}
                {effectivePermissionsModal.data.deniedPermissions.length > 0 && (
                  <div className="p-3.5 rounded-2xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/70 space-y-2">
                    <div className="font-extrabold text-rose-900 dark:text-rose-200 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-rose-600" />
                      Explicit Deny Rules Enforced ({effectivePermissionsModal.data.deniedPermissions.length})
                    </div>
                    <p className="text-[11px] text-rose-700 dark:text-rose-300">
                      Non-admin role combinations cannot escalate to system-level administration or security settings:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {effectivePermissionsModal.data.deniedPermissions.map((denied) => (
                        <span
                          key={denied}
                          className="px-2 py-0.5 rounded-md font-mono text-[10px] font-bold bg-rose-100 dark:bg-rose-900/70 text-rose-800 dark:text-rose-200 border border-rose-300 dark:border-rose-700"
                        >
                          DENY: {denied}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="pt-2 flex justify-end border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setEffectivePermissionsModal(null)}
                className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-xl font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
