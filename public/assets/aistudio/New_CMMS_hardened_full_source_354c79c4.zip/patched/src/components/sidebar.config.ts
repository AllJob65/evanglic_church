import { ModuleTab } from '../context/CMMSContext';
import { UserRole } from '../types';
import {
  LayoutDashboard,
  Users,
  Building2,
  UsersRound,
  UserCheck,
  BookOpen,
  Calendar,
  Send,
  HeartHandshake,
  FileText,
  TrendingUp,
  BarChart3,
  ShieldCheck,
  Settings,
  Database,
  FileCheck2,
  User,
  HeartPulse,
  Layers,
  Sparkles,
  Smartphone,
  Webhook,
} from 'lucide-react';

export type SystemAppRole = 'admin' | 'manager' | 'ministry Leader' | 'user' | UserRole;

export interface SidebarSubItemConfig {
  id: ModuleTab;
  path: string;
  translationKey: string;
  defaultLabel: string;
  roles: UserRole[];
  badgeKey?: 'prayers' | 'approvals' | 'none';
}

export interface SidebarItemConfig {
  id: ModuleTab;
  path: string;
  translationKey: string;
  defaultLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: UserRole[];
  badgeKey?: 'prayers' | 'approvals' | 'none';
  highlight?: boolean;
  isComingSoon?: boolean;
  subItems?: SidebarSubItemConfig[];
}

export interface SidebarGroupConfig {
  title: string;
  translationKey: string;
  roles: UserRole[];
  items: SidebarItemConfig[];
}

/**
 * Universal Sidebar Navigation Configuration
 * Every item specifies explicit `roles: UserRole[]`.
 * Items will be filtered using Array.prototype.filter() so unauthorized routes
 * are NEVER rendered in the DOM.
 */
export const SIDEBAR_NAV_GROUPS: SidebarGroupConfig[] = [
  {
    title: 'Main',
    translationKey: 'nav.group.core',
    roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
    items: [
      {
        id: 'dashboard',
        path: '/dashboard',
        translationKey: 'nav.dashboard',
        defaultLabel: 'Dashboard',
        icon: LayoutDashboard,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
      {
        id: 'approvals',
        path: '/approvals',
        translationKey: 'nav.approvals',
        defaultLabel: 'Form Approvals',
        icon: FileCheck2,
        roles: ['SYSTEM_ADMIN', 'MANAGER'],
        badgeKey: 'approvals',
      },
    ],
  },
  {
    title: 'Congregation & Care',
    translationKey: 'nav.group.congregation',
    roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
    items: [
      {
        id: 'members',
        path: '/members',
        translationKey: 'nav.members',
        defaultLabel: 'Members',
        icon: Users,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'],
      },
      {
        id: 'families',
        path: '/families',
        translationKey: 'nav.families',
        defaultLabel: 'Family Mapping',
        icon: UsersRound,
        roles: ['SYSTEM_ADMIN', 'MANAGER'],
      },
      {
        id: 'prayer_counseling',
        path: '/prayer-counseling',
        translationKey: 'nav.prayer_counseling',
        defaultLabel: 'Prayer & Counseling',
        icon: HeartHandshake,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'REGULAR_MEMBER'],
        badgeKey: 'prayers',
      },
      {
        id: 'visitations',
        path: '/visitations',
        translationKey: 'nav.visitations',
        defaultLabel: 'Visitations & Care',
        icon: HeartPulse,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'],
      },
    ],
  },
  {
    title: 'Ministry & Engagement',
    translationKey: 'nav.group.ministry',
    roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
    items: [
      {
        id: 'bible',
        path: '/bible',
        translationKey: 'nav.bible',
        defaultLabel: 'Holy Bible',
        icon: BookOpen,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
      {
        id: 'devotions',
        path: '/devotions',
        translationKey: 'nav.devotions',
        defaultLabel: 'Daily Devotion & Word',
        icon: Sparkles,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
      {
        id: 'ministries',
        path: '/ministries',
        translationKey: 'nav.ministries',
        defaultLabel: 'Ministries',
        icon: UsersRound,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
      {
        id: 'attendance',
        path: '/attendance',
        translationKey: 'nav.attendance',
        defaultLabel: 'Attendance',
        icon: UserCheck,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
      {
        id: 'events',
        path: '/events',
        translationKey: 'nav.events',
        defaultLabel: 'Events & Promo',
        icon: Calendar,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
      {
        id: 'communications',
        path: '/communications',
        translationKey: 'nav.communications',
        defaultLabel: 'Communication Broadcasts',
        icon: Send,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'],
      },
      {
        id: 'documents',
        path: '/documents',
        translationKey: 'nav.documents',
        defaultLabel: 'Document Repository',
        icon: FileText,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      },
    ],
  },
  {
    title: 'Operations & Intelligence',
    translationKey: 'nav.group.operations',
    roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'REGULAR_MEMBER'],
    items: [
      {
        id: 'branches',
        path: '/branches',
        translationKey: 'nav.branches',
        defaultLabel: 'Branches & Chaples',
        icon: Building2,
        roles: ['SYSTEM_ADMIN', 'MANAGER'],
      },
      {
        id: 'assets',
        path: '/assets',
        translationKey: 'nav.assets',
        defaultLabel: 'Assets & Facilities',
        icon: Layers,
        roles: ['SYSTEM_ADMIN', 'MANAGER'],
      },
      {
        id: 'predictive',
        path: '/predictive',
        translationKey: 'nav.predictive',
        defaultLabel: 'Predictive Analytics',
        icon: TrendingUp,
        roles: ['SYSTEM_ADMIN', 'MANAGER'],
      },
      {
        id: 'reports',
        path: '/reports',
        translationKey: 'nav.reports',
        defaultLabel: 'Executive Reports',
        icon: BarChart3,
        roles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'],
      },
      
    ],
  },
  {
    title: 'Administration & Security',
    translationKey: 'nav.group.admin',
    roles: ['SYSTEM_ADMIN', 'MANAGER'],
    items: [
      {
        id: 'security_audit',
        path: '/security-audit',
        translationKey: 'nav.security',
        defaultLabel: 'Security & Audit Logs',
        icon: ShieldCheck,
        roles: ['SYSTEM_ADMIN', 'MANAGER'],
      },
      {
        id: 'backup',
        path: '/backup',
        translationKey: 'nav.backup',
        defaultLabel: 'Backup & Restore',
        icon: Database,
        roles: ['SYSTEM_ADMIN'],
      },
      {
        id: 'api_integrations',
        path: '/admin/api',
        translationKey: 'nav.api_integrations',
        defaultLabel: 'API & Integration Hub',
        icon: Webhook,
        roles: ['SYSTEM_ADMIN'],
      },
      {
        id: 'settings',
        path: '/settings',
        translationKey: 'nav.settings',
        defaultLabel: 'System Settings',
        icon: Settings,
        roles: ['SYSTEM_ADMIN'],
      },
    ],
  },
];

/**
 * Filters sidebar navigation items strictly based on the active role.
 * Unauthorized items are COMPLETELY REMOVED from the DOM using Array.prototype.filter.
 */
export function getAuthorizedSidebarGroups(currentRole: UserRole): SidebarGroupConfig[] {
  return SIDEBAR_NAV_GROUPS
    .filter((group) => group.roles.includes(currentRole))
    .map((group) => ({
      ...group,
      items: group.items
        .filter((item) => item.roles.includes(currentRole))
        .map((item) => ({
          ...item,
          subItems: item.subItems
            ? item.subItems.filter((sub) => sub.roles.includes(currentRole))
            : undefined,
        })),
    }))
    .filter((group) => group.items.length > 0);
}

