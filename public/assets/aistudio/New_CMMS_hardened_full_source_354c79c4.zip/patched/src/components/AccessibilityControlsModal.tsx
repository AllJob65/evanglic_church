import React, { useEffect, useState } from 'react';
import { reachDeck, ReachDeckSettings } from '../services/reachdeck';
import {
  Eye,
  X,
  ShieldCheck,
  RotateCcw,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Square,
  Sliders,
  Sparkles,
  Glasses,
  Maximize2,
  Check,
  HelpCircle,
  Layers,
} from 'lucide-react';

interface AccessibilityControlsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReachDeckToolbar?: () => void;
}

/**
 * Apply saved accessibility settings globally.
 */
export function applyAccessibilitySettings() {
  if (typeof window === 'undefined') return;

  const root = document.documentElement;

  const highContrast =
    localStorage.getItem('cmms_high_contrast') === 'true';

  const fontSize =
    localStorage.getItem('cmms_font_scale') || 'normal';

  const reduceMotion =
    localStorage.getItem('cmms_reduce_motion') === 'true';

  const dyslexicFont =
    localStorage.getItem('cmms_dyslexic_font') === 'true';

  // High Contrast
  root.classList.toggle('high-contrast-mode', highContrast);

  // Font Size
  root.classList.remove('text-scale-lg', 'text-scale-xl');

  if (fontSize === 'large') {
    root.classList.add('text-scale-lg');
  }

  if (fontSize === 'xlarge') {
    root.classList.add('text-scale-xl');
  }

  // Reduce Motion
  root.classList.toggle('reduce-motion', reduceMotion);

  // Dyslexic Font
  root.classList.toggle('font-dyslexic', dyslexicFont);
}

// Apply saved settings when application loads
if (typeof window !== 'undefined') {
  applyAccessibilitySettings();
}

export const AccessibilityControlsModal: React.FC<AccessibilityControlsModalProps> = ({
  isOpen,
  onClose,
  onOpenReachDeckToolbar,
}) => {
  /*
   * Main accessibility settings
   */
  const [highContrast, setHighContrast] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('cmms_high_contrast') === 'true';
  });

  const [fontSize, setFontSize] = useState(() => {
    if (typeof window === 'undefined') return 'normal';
    return localStorage.getItem('cmms_font_scale') || 'normal';
  });

  const [reduceMotion, setReduceMotion] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('cmms_reduce_motion') === 'true';
  });

  const [dyslexicFont, setDyslexicFont] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('cmms_dyslexic_font') === 'true';
  });

  /*
   * Controls which section is displayed:
   * 'accessibility' = WCAG/Visual Accessibility settings
   * 'reachdeck' = ReachDeck Read Aloud & Speech Engine settings
   */
  const [activeSection, setActiveSection] = useState<'accessibility' | 'reachdeck'>('accessibility');

  // ReachDeck settings state
  const [reachSettings, setReachSettings] = useState<ReachDeckSettings>(reachDeck.getSettings());
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    const unsub = reachDeck.subscribe((state) => {
      setIsSpeaking(state.isSpeaking);
      setIsPaused(state.isPaused);
    });

    const voices = reachDeck.getVoices();
    setAvailableVoices(voices);

    return () => {
      unsub();
    };
  }, []);

  /*
   * Save accessibility settings
   */
  useEffect(() => {
    if (typeof window === 'undefined') return;

    localStorage.setItem('cmms_high_contrast', highContrast ? 'true' : 'false');
    localStorage.setItem('cmms_font_scale', fontSize);
    localStorage.setItem('cmms_reduce_motion', reduceMotion ? 'true' : 'false');
    localStorage.setItem('cmms_dyslexic_font', dyslexicFont ? 'true' : 'false');

    applyAccessibilitySettings();
  }, [highContrast, fontSize, reduceMotion, dyslexicFont]);

  const updateReachSetting = <K extends keyof ReachDeckSettings>(key: K, value: ReachDeckSettings[K]) => {
    const updated = { ...reachSettings, [key]: value };
    setReachSettings(updated);
    reachDeck.saveSettings({ [key]: value });
  };

  /*
   * Reset accessibility settings
   */
  const handleReset = () => {
    setHighContrast(false);
    setFontSize('normal');
    setReduceMotion(false);
    setDyslexicFont(false);

    if (typeof window !== 'undefined') {
      localStorage.setItem('cmms_high_contrast', 'false');
      localStorage.setItem('cmms_font_scale', 'normal');
      localStorage.setItem('cmms_reduce_motion', 'false');
      localStorage.setItem('cmms_dyslexic_font', 'false');
      applyAccessibilitySettings();
    }
  };

  /*
   * Do not render when closed
   */
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="accessibility-modal-title"
      className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* HEADER */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-900 to-indigo-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-400/30 shrink-0">
              <Eye className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3
                id="accessibility-modal-title"
                className="text-base sm:text-lg font-black tracking-tight truncate"
              >
                Accessibility & WCAG 2.1 AA
              </h3>
              <p className="text-xs text-blue-200 mt-0.5">
                ReachDeck Read Aloud & Universal Display Controls
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close accessibility settings"
            className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-all cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TABS */}
        <div
          role="tablist"
          aria-label="Accessibility options"
          className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 shrink-0"
        >
          {/* Accessibility Tab */}
          <button
            type="button"
            role="tab"
            aria-selected={activeSection === 'accessibility'}
            onClick={() => setActiveSection('accessibility')}
            className={`flex-1 px-3 sm:px-4 py-3 text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
              activeSection === 'accessibility'
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 bg-white dark:bg-slate-900'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            Visual & Layout Settings
          </button>

          {/* ReachDeck Tab */}
          <button
            type="button"
            role="tab"
            aria-selected={activeSection === 'reachdeck'}
            onClick={() => setActiveSection('reachdeck')}
            className={`flex-1 px-3 sm:px-4 py-3 text-xs sm:text-sm font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
              activeSection === 'reachdeck'
                ? 'text-emerald-600 dark:text-emerald-400 border-b-2 border-emerald-600 bg-white dark:bg-slate-900'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            ReachDeck Read Aloud
          </button>
        </div>

        {/* CONTENT */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto">
          {/* VISUAL ACCESSIBILITY SETTINGS */}
          {activeSection === 'accessibility' && (
            <div className="space-y-4">
              {/* High Contrast */}
              <div className="flex items-center justify-between gap-4 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <div className="min-w-0">
                  <label
                    htmlFor="toggle-high-contrast"
                    className="font-bold text-sm text-slate-900 dark:text-white block cursor-pointer"
                  >
                    High Contrast Theme (WCAG AAA)
                  </label>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Boosts contrast ratios above 7:1 for maximum optical clarity.
                  </p>
                </div>
                <input
                  type="checkbox"
                  id="toggle-high-contrast"
                  checked={highContrast}
                  onChange={(e) => setHighContrast(e.target.checked)}
                  aria-label="Enable high contrast theme"
                  className="w-5 h-5 text-blue-600 rounded cursor-pointer shrink-0"
                />
              </div>

              {/* Text Size */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-sm text-slate-900 dark:text-white">
                    Text Size Scaling
                  </label>
                  <span className="text-xs font-mono text-blue-600 dark:text-blue-400 font-bold uppercase">
                    {fontSize}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Scales font geometry cleanly without clipping cards or modal forms.
                </p>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {[
                    { id: 'normal', label: '100% Normal' },
                    { id: 'large', label: '115% Large' },
                    { id: 'xlarge', label: '130% Extra' },
                  ].map((scale) => (
                    <button
                      key={scale.id}
                      type="button"
                      aria-pressed={fontSize === scale.id}
                      onClick={() => setFontSize(scale.id)}
                      className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        fontSize === scale.id
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      {scale.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reduce Motion */}
              <div className="flex items-center justify-between gap-4 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <div className="min-w-0">
                  <label
                    htmlFor="toggle-reduce-motion"
                    className="font-bold text-sm text-slate-900 dark:text-white block cursor-pointer"
                  >
                    Reduce Animations & Motion
                  </label>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Stops animated transitions for users sensitive to screen motion.
                  </p>
                </div>
                <input
                  type="checkbox"
                  id="toggle-reduce-motion"
                  checked={reduceMotion}
                  onChange={(e) => setReduceMotion(e.target.checked)}
                  aria-label="Reduce animations and motion"
                  className="w-5 h-5 text-blue-600 rounded cursor-pointer shrink-0"
                />
              </div>

              {/* Dyslexic Font */}
              <div className="flex items-center justify-between gap-4 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <div className="min-w-0">
                  <label
                    htmlFor="toggle-dyslexic-font"
                    className="font-bold text-sm text-slate-900 dark:text-white block cursor-pointer"
                  >
                    Dyslexia-Friendly Typography
                  </label>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Applies heavy bottom-weighted glyphs for increased readability.
                  </p>
                </div>
                <input
                  type="checkbox"
                  id="toggle-dyslexic-font"
                  checked={dyslexicFont}
                  onChange={(e) => setDyslexicFont(e.target.checked)}
                  aria-label="Enable dyslexia-friendly font"
                  className="w-5 h-5 text-blue-600 rounded cursor-pointer shrink-0"
                />
              </div>

              {/* Compliance Badge */}
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 flex items-start gap-2 text-xs text-emerald-800 dark:text-emerald-300">
                <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                <span>
                  Complies with W3C WCAG 2.1 Level AA and Section 508 standards with full keyboard navigation and ARIA landmarks.
                </span>
              </div>
            </div>
          )}

          {/* REACHDECK READ ALOUD ENGINE SETTINGS */}
          {activeSection === 'reachdeck' && (
            <div className="space-y-4">
              {/* Quick Playback Bar */}
              <div className="p-4 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 border border-emerald-500/30 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    <div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-white">
                        ReachDeck Text-to-Speech
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {isSpeaking ? (isPaused ? 'Speech paused' : 'Reading aloud...') : 'Ready to read aloud'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {!isSpeaking || isPaused ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (isPaused) reachDeck.resume();
                          else reachDeck.speakSelection();
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-md cursor-pointer"
                        title="Listen / Resume"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" /> Listen
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => reachDeck.pause()}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-md cursor-pointer"
                        title="Pause Speech"
                      >
                        <Pause className="w-3.5 h-3.5 fill-current" /> Pause
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => reachDeck.stop()}
                      className="p-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-rose-100 hover:text-rose-600 dark:hover:bg-rose-950 text-slate-700 dark:text-slate-300 rounded-xl transition-all cursor-pointer"
                      title="Stop Speech (Alt+X / Esc)"
                    >
                      <Square className="w-3.5 h-3.5 fill-current" />
                    </button>
                  </div>
                </div>

                {/* Keyboard Shortcuts Hint */}
                <div className="p-2.5 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-400 flex items-center justify-between">
                  <span>Press <kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono font-bold text-slate-900 dark:text-white">Alt + R</kbd> to read selection</span>
                  <span><kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono font-bold text-slate-900 dark:text-white">Alt + X</kbd> to stop</span>
                </div>
              </div>

              {/* Voice Selector */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-1.5">
                <label className="text-xs font-bold text-slate-900 dark:text-white block">
                  Speech Synthesizer Voice
                </label>
                <select
                  value={reachSettings.voiceUri}
                  onChange={(e) => updateReachSetting('voiceUri', e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white cursor-pointer"
                >
                  <option value="">Default System Voice</option>
                  {availableVoices.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>

              {/* Speed & Pitch Controls */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-1">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-900 dark:text-white">Speed Rate</span>
                    <span className="text-emerald-600 font-mono">{reachSettings.rate}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.0"
                    step="0.1"
                    value={reachSettings.rate}
                    onChange={(e) => updateReachSetting('rate', parseFloat(e.target.value))}
                    className="w-full accent-emerald-600 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-1">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-900 dark:text-white">Pitch</span>
                    <span className="text-emerald-600 font-mono">{reachSettings.pitch}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="1.5"
                    step="0.1"
                    value={reachSettings.pitch}
                    onChange={(e) => updateReachSetting('pitch', parseFloat(e.target.value))}
                    className="w-full accent-emerald-600 cursor-pointer"
                  />
                </div>
              </div>

              {/* Visual Aids & Touch-to-Read (Mobile & Tablet) */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Touch & Visual Reading Aids
                </h4>

                {/* Touch to Read on Mobile & Tablet */}
                <div className="p-3.5 rounded-xl border border-emerald-300 dark:border-emerald-700/60 bg-emerald-50/50 dark:bg-emerald-950/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <label className="font-bold text-xs text-emerald-900 dark:text-emerald-300 block cursor-pointer">
                        Touch-to-Read (Mobile & Touch Devices)
                      </label>
                      <p className="text-[11px] text-emerald-700/90 dark:text-emerald-400/90 mt-0.5">
                        Touch or tap any text, card, button, or heading on the screen to read it aloud.
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={reachSettings.touchToSpeak}
                      onChange={(e) => updateReachSetting('touchToSpeak', e.target.checked)}
                      className="w-5 h-5 text-emerald-600 rounded cursor-pointer shrink-0"
                    />
                  </div>
                  
                  {/* Phone Stop Shortcuts Guide */}
                  <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-800/60 flex items-center justify-between text-[10px] text-emerald-800 dark:text-emerald-300">
                    <span className="font-semibold">🛑 Phone Stop Choices (Alt + X equivalent):</span>
                    <span className="bg-emerald-200/70 dark:bg-emerald-900/60 px-2 py-0.5 rounded-md font-mono font-bold">
                      2-Finger Tap / Floating Stop / Alt+X
                    </span>
                  </div>
                </div>

                {/* Word Highlighter */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                  <div>
                    <label className="font-bold text-xs text-slate-900 dark:text-white block cursor-pointer">
                      Synchronized Dual-Color Highlighting
                    </label>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Highlights words and sentences in yellow/blue as they are spoken.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={reachSettings.highlightWords}
                    onChange={(e) => updateReachSetting('highlightWords', e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {/* Reading Ruler */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                  <div>
                    <label className="font-bold text-xs text-slate-900 dark:text-white block cursor-pointer">
                      Reading Ruler Guide
                    </label>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Horizontal focus strip following cursor to reduce visual crowding.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={reachSettings.readingRuler}
                    onChange={(e) => updateReachSetting('readingRuler', e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {/* Screen Mask */}
                <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                  <div>
                    <label className="font-bold text-xs text-slate-900 dark:text-white block cursor-pointer">
                      Screen Mask Dimming
                    </label>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Dims background content to focus purely on the active paragraph.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={reachSettings.screenMask}
                    onChange={(e) => updateReachSetting('screenMask', e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* FOOTER */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={handleReset}
            className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset to Default
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
