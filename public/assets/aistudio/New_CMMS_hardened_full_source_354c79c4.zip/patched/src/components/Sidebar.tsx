import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { normalizeUserRole, ROLE_SPECIFICATIONS } from '../utils/rbac';
import {
  getAuthorizedSidebarGroups,
  SidebarItemConfig,
  SidebarSubItemConfig,
} from './sidebar.config';
import { triggerGoogleTranslate } from '../utils/googleTranslate';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
  User,
  LogOut,
  Sun,
  Moon,
  Monitor,
  Globe,
  Check,
  Settings,
  Church,
} from 'lucide-react';

interface SidebarProps {
  isMobileMenuOpen?: boolean;
  onCloseMobileMenu?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isMobileMenuOpen = false,
  onCloseMobileMenu,
}) => {
  const {
    activeModule,
    setActiveModule,
    prayerRequests,
    workflows,
    members,
    isSidebarCollapsed,
    setIsSidebarCollapsed,
    language,
    setLanguage,
    themeMode,
    setThemeMode,
    t,
    activeRole,
    addAuditLog,
    logout: cmmsLogout,
    setIsAuthenticated,
    churchLogoUrl,
    darkLogoUrl,
    systemName,
  } = useCMMS();

  const { currentUser, userProfile, logout: authLogout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const normRole = normalizeUserRole(userProfile?.role || activeRole);
  const roleTitle = ROLE_SPECIFICATIONS[normRole]?.title || normRole;
  const isEthiopicScript = language === 'Amharic' || language === 'Tigrigna';
  const fontFamilyClass = isEthiopicScript ? 'font-menbere' : 'font-montserrat';

  const [expandedParentIds, setExpandedParentIds] = useState<Record<string, boolean>>({
    dashboard: true,
  });
  const [hoveredCollapsedItem, setHoveredCollapsedItem] = useState<{
    item: SidebarItemConfig;
    top: number;
  } | null>(null);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [logoImgError, setLogoImgError] = useState(false);

  useEffect(() => {
    setLogoImgError(false);
  }, [churchLogoUrl, darkLogoUrl]);

  const isDarkTheme =
    themeMode === 'dark' ||
    themeMode === 'advanced-dark' ||
    (themeMode === 'system' &&
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-color-scheme: dark)').matches);

  const effectiveLogoUrl = (isDarkTheme && darkLogoUrl ? darkLogoUrl : churchLogoUrl) || churchLogoUrl;
  const effectiveChurchName =
    systemName && systemName !== 'CMMS' ? systemName : 'Grace Cathedral International';

  const userMenuRef = useRef<HTMLDivElement>(null);
  const hoverTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Close user menu on outside click or Escape
  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (
        isUserMenuOpen &&
        userMenuRef.current &&
        !userMenuRef.current.contains(e.target as Node)
      ) {
        setIsUserMenuOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsUserMenuOpen(false);
        setHoveredCollapsedItem(null);
        onCloseMobileMenu?.();
      }
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isUserMenuOpen, onCloseMobileMenu]);

  const pendingPrayers = useMemo(
    () => prayerRequests?.filter((p) => p.status === 'Pending').length || 0,
    [prayerRequests]
  );
  const pendingApprovals = useMemo(
    () => workflows?.filter((w) => w.status === 'Pending').length || 0,
    [workflows]
  );

  // Filter navigation items strictly using Array.prototype.filter() based on active user role
  const authorizedGroups = useMemo(() => {
    return getAuthorizedSidebarGroups(normRole);
  }, [normRole]);

  // Pastoral & Ministry Contacts for the Dribbble "MESSAGES" section (backed by real member data)
  const ministryContacts = useMemo(() => {
    const source = Array.isArray(members) ? members : [];
    const leaders = source
      .filter(
        (m) =>
          m.status === 'Active' &&
          (m.role === 'Pastor' ||
            m.role === 'Leader' ||
            m.role === 'Elder' ||
            Boolean(m.ministry))
      )
      .slice(0, 3);
    if (leaders.length > 0) {
      return leaders.map((m, idx) => ({
        id: m.id,
        name: `${m.firstName || ''} ${m.lastName || ''}`.trim() || m.name || 'Ministry Leader',
        role: m.ministry || m.role || 'Pastoral Care',
        photoUrl: m.photoUrl || '',
        online: idx !== 2,
      }));
    }
    return [];
  }, [members]);

  // Determine active item from current route or context activeModule
  const isPathMatch = (targetPath: string, itemId: string) => {
    if (location.pathname === targetPath) return true;
    if (targetPath !== '/dashboard' && location.pathname.startsWith(targetPath)) return true;
    return activeModule === itemId && location.pathname === targetPath;
  };

  const isCurrentActive = (item: SidebarItemConfig) => {
    if (isPathMatch(item.path, item.id)) return true;
    if (activeModule === item.id) return true;
    if (item.subItems?.some((sub) => isPathMatch(sub.path, sub.id) || activeModule === sub.id)) {
      return true;
    }
    return false;
  };

  const isSubItemActive = (sub: SidebarSubItemConfig) => {
    if (location.pathname === sub.path) return true;
    if (sub.path !== '/dashboard' && location.pathname.startsWith(sub.path)) return true;
    return activeModule === sub.id;
  };

  // Automatically expand parent item when one of its sub-items is active
  useEffect(() => {
    authorizedGroups.forEach((group) => {
      group.items.forEach((item) => {
        if (
          item.subItems &&
          item.subItems.length > 1 &&
          item.subItems.some((sub) => isSubItemActive(sub))
        ) {
          setExpandedParentIds((prev) =>
            prev[item.id] ? prev : { ...prev, [item.id]: true }
          );
        }
      });
    });
  }, [location.pathname, activeModule, authorizedGroups]);

  const handleNavigate = (item: SidebarItemConfig | SidebarSubItemConfig) => {
    setActiveModule(item.id);
    navigate(item.path);
    setHoveredCollapsedItem(null);
    onCloseMobileMenu?.();
  };

  const handleParentClick = (item: SidebarItemConfig) => {
    const hasMultipleSubs = Boolean(item.subItems && item.subItems.length > 1);
    if (!isSidebarCollapsed && hasMultipleSubs) {
      setExpandedParentIds((prev) => ({
        ...prev,
        [item.id]: !prev[item.id],
      }));
      if (!isCurrentActive(item)) {
        handleNavigate(item);
      }
      return;
    }
    handleNavigate(item);
  };

  const handleToggleSubmenuOnly = (e: React.MouseEvent, itemId: string) => {
    e.stopPropagation();
    setExpandedParentIds((prev) => ({
      ...prev,
      [itemId]: !prev[itemId],
    }));
  };

  const handleSignOut = async () => {
    try {
      setIsUserMenuOpen(false);
      onCloseMobileMenu?.();
      addAuditLog('User Logout', 'Authentication', `User signed out from Sidebar`);

      localStorage.removeItem('cmms_token');
      localStorage.removeItem('cmms_auth_token');
      localStorage.removeItem('cmms_active_user');
      localStorage.removeItem('cmms_applicant_data');
      localStorage.removeItem('cmms_onboarding_state');
      localStorage.removeItem('cmms_onboarding_workflow');
      localStorage.removeItem('cmms_rejection_reason');

      setIsAuthenticated(false);
      if (authLogout) await authLogout();
      if (cmmsLogout) cmmsLogout();

      navigate('/login', { replace: true });
    } catch (err) {
      console.error('Logout error from sidebar:', err);
      setIsAuthenticated(false);
      navigate('/login', { replace: true });
    }
  };

  const handleLanguageSelect = (langName: string) => {
    setLanguage(langName);
    const l = langName.toLowerCase().trim();
    const isInternal =
      l === 'en' ||
      l === 'english' ||
      l === 'am' ||
      l === 'amharic' ||
      l === 'ti' ||
      l === 'tigrigna' ||
      l === 'om' ||
      l === 'afaan oromoo';
    if (!isInternal) {
      triggerGoogleTranslate(langName);
    }
  };

  const getInitials = (nameStr: string) => {
    if (!nameStr) return 'CM';
    const parts = nameStr.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const displayName = userProfile?.name || currentUser?.displayName || 'Authenticated User';
  const displayEmail = userProfile?.email || currentUser?.email || '';
  const displayAvatar = userProfile?.photoUrl || currentUser?.photoURL || '';
  const selectedThemeOption: 'light' | 'dark' | 'system' =
    themeMode === 'advanced-dark' ? 'dark' : themeMode;

  const getBadgeCount = (badgeKey?: 'prayers' | 'approvals' | 'none') => {
    if (badgeKey === 'prayers') return pendingPrayers;
    if (badgeKey === 'approvals') return pendingApprovals;
    return 0;
  };

  const handleCollapsedMouseEnter = (
    e: React.MouseEvent<HTMLDivElement>,
    item: SidebarItemConfig
  ) => {
    if (!isSidebarCollapsed) return;
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    const rect = e.currentTarget.getBoundingClientRect();
    setHoveredCollapsedItem({
      item,
      top: Math.max(16, Math.min(rect.top, window.innerHeight - 200)),
    });
  };

  const handleCollapsedMouseLeave = () => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    hoverTimeoutRef.current = setTimeout(() => {
      setHoveredCollapsedItem(null);
    }, 160);
  };

  return (
    <>
      {/* =================================================================== */}
      {/* DESKTOP SIDEBAR — Full Height (top: 0 to bottom: 0, 100dvh)         */}
      {/* Logo & church name at top, scrollable nav in middle, user at bottom */}
      {/* =================================================================== */}
      <aside
        id="cmms-desktop-sidebar"
        aria-label="Primary Sidebar Navigation"
        className={`app-sidebar-floating hidden md:flex flex-col fixed top-0 left-0 bottom-0 h-dvh z-30 p-2.5 transition-[width] duration-300 ease-out select-none ${
          isSidebarCollapsed ? 'w-20 sidebar-collapsed' : 'w-64'
        } ${fontFamilyClass}`}
      >
        {/* Inner Floating Surface Card (High Corner Radius & Soft Diffuse Shadow per Reference) */}
        <div className="relative flex flex-col w-full h-full bg-white dark:bg-slate-900 rounded-[26px] border border-slate-200/80 dark:border-slate-800/90 shadow-[0_8px_30px_rgb(15,23,42,0.04)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.3)] transition-all duration-300">
          {/* Circular Edge Collapse / Expand Toggle Button on Outer Right Edge */}
          <button
            type="button"
            onClick={() => {
              setIsSidebarCollapsed(!isSidebarCollapsed);
              setHoveredCollapsedItem(null);
            }}
            aria-label={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            title={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="absolute -right-3 top-6 z-40 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200/90 dark:border-slate-700 text-slate-500 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-700 shadow-xs flex items-center justify-center transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            {isSidebarCollapsed ? (
              <ChevronRight className="w-3.5 h-3.5 stroke-[2.2]" />
            ) : (
              <ChevronLeft className="w-3.5 h-3.5 stroke-[2.2]" />
            )}
          </button>

          {/* 0. TOP SIDEBAR HEADER: Church Logo & System Name */}
          <div
            className={`shrink-0 px-3 pt-3.5 pb-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center ${
              isSidebarCollapsed ? 'justify-center px-0' : 'gap-2.5'
            }`}
          >
            <button
              type="button"
              onClick={() => {
                setActiveModule('dashboard');
                navigate('/dashboard');
              }}
              title={effectiveChurchName}
              className={`flex items-center min-w-0 text-left rounded-xl transition-colors cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                isSidebarCollapsed ? 'justify-center mx-auto' : 'gap-2.5 w-full'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-slate-900 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
                {effectiveLogoUrl && !logoImgError ? (
                  <img
                    src={effectiveLogoUrl}
                    alt={effectiveChurchName}
                    onError={() => setLogoImgError(true)}
                    className="w-full h-full object-contain p-1 bg-white dark:bg-slate-900"
                  />
                ) : (
                  <Church className="w-4.5 h-4.5 text-white dark:text-slate-100 stroke-[2]" />
                )}
              </div>

              {!isSidebarCollapsed && (
                <div className="min-w-0 flex-1 pr-2">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate leading-tight">
                    {effectiveChurchName}
                  </p>
                  <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 truncate mt-0.5">
                    {roleTitle}
                  </p>
                </div>
              )}
            </button>
          </div>

          {/* 1. SCROLLABLE NAVIGATION GROUPS WITH TREE SUB-MENUS */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden px-3 pt-3 pb-2 space-y-4 sidebar-themed-scrollbar">
            {authorizedGroups.map((group) => (
              <div key={group.title} className="space-y-1">
                {/* Subtle Section Label */}
                {!isSidebarCollapsed ? (
                  <div className="px-2.5 pt-0.5 pb-1 text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-400 dark:text-slate-500">
                    {t(group.translationKey, group.title)}
                  </div>
                ) : (
                  <div className="h-px w-6 mx-auto my-1.5 bg-slate-100 dark:bg-slate-800/80" />
                )}

                {/* Navigation Items */}
                <div className="space-y-0.5">
                  {group.items.map((item) => {
                    const active = isCurrentActive(item);
                    const Icon = item.icon;
                    const badgeCount = getBadgeCount(item.badgeKey);
                    const hasSubItems = Boolean(item.subItems && item.subItems.length > 1);
                    const isSubOpen = Boolean(expandedParentIds[item.id]);

                    return (
                      <div
                        key={item.id}
                        onMouseEnter={(e) => handleCollapsedMouseEnter(e, item)}
                        onMouseLeave={handleCollapsedMouseLeave}
                        className="relative"
                      >
                        <button
                          type="button"
                          onClick={() => handleParentClick(item)}
                          aria-current={active ? 'page' : undefined}
                          aria-expanded={hasSubItems && !isSidebarCollapsed ? isSubOpen : undefined}
                          title={
                            isSidebarCollapsed
                              ? t(item.translationKey, item.defaultLabel)
                              : undefined
                          }
                          className={`w-full min-h-[38px] flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[13px] transition-all duration-150 cursor-pointer relative group focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                            active
                              ? 'bg-slate-100/95 dark:bg-slate-800/90 text-slate-900 dark:text-white font-semibold'
                              : 'text-slate-600 dark:text-slate-400 font-medium hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-100'
                          } ${isSidebarCollapsed ? 'justify-center px-0 w-10 h-10 mx-auto' : ''}`}
                        >
                          <Icon
                            className={`w-[18px] h-[18px] shrink-0 transition-colors ${
                              active
                                ? 'text-slate-900 dark:text-white stroke-[2]'
                                : 'text-slate-400 dark:text-slate-500 group-hover:text-slate-700 dark:group-hover:text-slate-300 stroke-[1.75]'
                            }`}
                          />

                          {!isSidebarCollapsed && (
                            <span className="truncate flex-1 text-left leading-snug">
                              {t(item.translationKey, item.defaultLabel)}
                            </span>
                          )}

                          {/* Real Notification Badge Counter */}
                          {badgeCount > 0 && (
                            <span
                              className={`min-w-[18px] h-[18px] px-1.5 text-[10px] font-bold rounded-full inline-flex items-center justify-center tabular-nums ${
                                active
                                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                                  : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                              } ${
                                isSidebarCollapsed
                                  ? 'absolute -top-1 -right-1 ring-2 ring-white dark:ring-slate-900'
                                  : ''
                              }`}
                            >
                              {badgeCount}
                            </span>
                          )}

                          {/* Accordion Chevron for Items with Sub-menus */}
                          {!isSidebarCollapsed && hasSubItems && (
                            <span
                              role="button"
                              tabIndex={-1}
                              onClick={(e) => handleToggleSubmenuOnly(e, item.id)}
                              className="p-0.5 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                            >
                              {isSubOpen ? (
                                <ChevronUp className="w-3.5 h-3.5" />
                              ) : (
                                <ChevronDown className="w-3.5 h-3.5" />
                              )}
                            </span>
                          )}
                        </button>

                        {/* Nested Sub-menu with L-Shaped Tree Connectors (Dribbble Reference) */}
                        <AnimatePresence initial={false}>
                          {!isSidebarCollapsed && hasSubItems && isSubOpen && item.subItems && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.18, ease: 'easeOut' }}
                              className="overflow-hidden"
                            >
                              <div className="relative pl-6 pr-1 pt-1 pb-1 space-y-0.5">
                                {item.subItems.map((sub, idx) => {
                                  const subActive = isSubItemActive(sub);
                                  const subBadge = getBadgeCount(sub.badgeKey);
                                  const isLast = idx === item.subItems!.length - 1;

                                  return (
                                    <div key={`${item.id}-${sub.id}`} className="relative flex items-center">
                                      {/* Vertical spine line */}
                                      <span
                                        aria-hidden="true"
                                        className={`absolute -left-2.5 top-0 w-px bg-slate-200 dark:bg-slate-700/80 ${
                                          isLast ? 'h-1/2' : 'h-full'
                                        }`}
                                      />
                                      {/* Curved L-branch connector */}
                                      <span
                                        aria-hidden="true"
                                        className="absolute -left-2.5 top-1/2 -translate-y-full w-2.5 h-2.5 border-l border-b border-slate-200 dark:border-slate-700/80 rounded-bl-lg"
                                      />

                                      <button
                                        type="button"
                                        onClick={() => handleNavigate(sub)}
                                        className={`w-full min-h-[32px] flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs transition-all cursor-pointer text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                                          subActive
                                            ? 'bg-slate-100/95 dark:bg-slate-800/90 text-slate-900 dark:text-white font-semibold'
                                            : 'text-slate-500 dark:text-slate-400 font-medium hover:bg-slate-50 dark:hover:bg-slate-800/40 hover:text-slate-900 dark:hover:text-slate-200'
                                        }`}
                                      >
                                        <span className="truncate">
                                          {t(sub.translationKey, sub.defaultLabel)}
                                        </span>
                                        {subBadge > 0 && (
                                          <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-slate-200/80 dark:bg-slate-700 text-slate-700 dark:text-slate-200 tabular-nums">
                                            {subBadge}
                                          </span>
                                        )}
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* 2. PASTORAL & MINISTRY CONTACTS ("MESSAGES" Style from Dribbble Reference) */}
            {ministryContacts.length > 0 && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800/70 space-y-1.5">
                {!isSidebarCollapsed && (
                  <div className="px-2.5 py-1 flex items-center justify-between">
                    <span className="text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-400 dark:text-slate-500">
                      Pastoral Team
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (normRole === 'REGULAR_MEMBER') {
                          setActiveModule('prayer_counseling');
                          navigate('/prayer-counseling');
                        } else {
                          setActiveModule('communications');
                          navigate('/communications');
                        }
                      }}
                      title="Open Messages & Broadcasts"
                      className="w-5 h-5 rounded-md text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                <div className="space-y-0.5">
                  {ministryContacts.map((person) => (
                    <button
                      key={person.id}
                      type="button"
                      onClick={() => {
                        if (normRole === 'REGULAR_MEMBER') {
                          setActiveModule('prayer_counseling');
                          navigate('/prayer-counseling');
                        } else {
                          setActiveModule('communications');
                          navigate('/communications');
                        }
                      }}
                      title={
                        isSidebarCollapsed ? `${person.name} (${person.role})` : undefined
                      }
                      className={`w-full flex items-center gap-2.5 px-2 py-1.5 rounded-xl text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer ${
                        isSidebarCollapsed ? 'justify-center px-0' : ''
                      }`}
                    >
                      <div className="relative shrink-0">
                        {person.photoUrl ? (
                          <img
                            src={person.photoUrl}
                            alt={person.name}
                            className="w-7 h-7 rounded-full object-cover bg-slate-100 dark:bg-slate-800"
                          />
                        ) : (
                          <div className="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-bold flex items-center justify-center">
                            {getInitials(person.name)}
                          </div>
                        )}
                        <span
                          className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                            person.online ? 'bg-emerald-500' : 'bg-rose-500'
                          }`}
                        />
                      </div>

                      {!isSidebarCollapsed && (
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-slate-700 dark:text-slate-200 truncate leading-tight">
                            {person.name}
                          </p>
                          <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate">
                            {person.role}
                          </p>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 3. BOTTOM USER ACCOUNT & SETTINGS FOOTER */}
          <div
            ref={userMenuRef}
            className="relative p-2.5 border-t border-slate-100 dark:border-slate-800/80"
          >
            <button
              type="button"
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              aria-expanded={isUserMenuOpen}
              aria-haspopup="true"
              title={isSidebarCollapsed ? `${displayName} (${roleTitle})` : undefined}
              className={`w-full flex items-center gap-2.5 p-1.5 rounded-2xl hover:bg-slate-100/80 dark:hover:bg-slate-800/70 transition-colors cursor-pointer text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                isSidebarCollapsed ? 'justify-center' : ''
              }`}
            >
              <div className="relative shrink-0">
                {displayAvatar ? (
                  <img
                    src={displayAvatar}
                    alt={displayName}
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs flex items-center justify-center">
                    {getInitials(displayName)}
                  </div>
                )}
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
              </div>

              {!isSidebarCollapsed && (
                <>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white truncate leading-tight">
                      {displayName}
                    </p>
                    <p className="text-[11px] font-medium text-slate-400 dark:text-slate-500 truncate mt-0.5">
                      {roleTitle}
                    </p>
                  </div>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform duration-150 shrink-0 ${
                      isUserMenuOpen ? 'rotate-180 text-slate-700 dark:text-slate-200' : ''
                    }`}
                  />
                </>
              )}
            </button>

            {/* Popover Account Menu (Profile, Theme, Language, Logout) */}
            <AnimatePresence>
              {isUserMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.97 }}
                  transition={{ duration: 0.15, ease: 'easeOut' }}
                  className={`fixed md:absolute bottom-16 ${
                    isSidebarCollapsed ? 'left-20' : 'left-2.5 right-2.5'
                  } min-w-[232px] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-xl z-50 p-2 space-y-2`}
                >
                  {/* User Summary */}
                  <div className="px-2.5 py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {displayName}
                    </p>
                    {displayEmail && (
                      <p className="text-[11px] text-slate-400 truncate">{displayEmail}</p>
                    )}
                  </div>

                  {/* Quick Profile & Settings Links */}
                  <div className="space-y-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        setActiveModule('my_profile');
                        navigate('/my-profile');
                      }}
                      className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                    >
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>My Member Profile</span>
                    </button>

                    {normRole === 'SYSTEM_ADMIN' && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          setActiveModule('settings');
                          navigate('/settings');
                        }}
                        className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                      >
                        <Settings className="w-3.5 h-3.5 text-slate-400" />
                        <span>System Settings</span>
                      </button>
                    )}
                  </div>

                  {/* Compact Theme Switcher */}
                  <div className="px-1.5 pt-1 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block mb-1 px-1">
                      Appearance
                    </span>
                    <div className="grid grid-cols-3 gap-1 p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl">
                      {[
                        { id: 'light' as const, label: 'Light', icon: Sun },
                        { id: 'dark' as const, label: 'Dark', icon: Moon },
                        { id: 'system' as const, label: 'Auto', icon: Monitor },
                      ].map((opt) => {
                        const isSelected = selectedThemeOption === opt.id;
                        const IconComp = opt.icon;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setThemeMode(opt.id)}
                            className={`flex items-center justify-center gap-1 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
                            }`}
                          >
                            <IconComp className="w-3 h-3" />
                            <span>{opt.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Compact Language Switcher */}
                  <div className="px-1.5 pt-1 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1 mb-1 px-1">
                      <Globe className="w-3 h-3" />
                      <span>Language</span>
                    </span>
                    <div className="grid grid-cols-2 gap-1">
                      {[
                        { name: 'English', label: 'English' },
                        { name: 'Amharic', label: 'አማርኛ' },
                        { name: 'Tigrigna', label: 'ትግርኛ' },
                        { name: 'Afaan Oromoo', label: 'Oromoo' },
                      ].map((langOpt) => {
                        const isCurrent = language === langOpt.name;
                        return (
                          <button
                            key={langOpt.name}
                            type="button"
                            onClick={() => handleLanguageSelect(langOpt.name)}
                            className={`px-2 py-1 rounded-lg text-[11px] flex items-center justify-between transition-colors cursor-pointer ${
                              isCurrent
                                ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold'
                                : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                            }`}
                          >
                            <span className="truncate">{langOpt.label}</span>
                            {isCurrent && <Check className="w-3 h-3 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Sign Out */}
                  <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={handleSignOut}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* ================================================================= */}
        {/* FLOATING FLY-OUT CARD WHEN COLLAPSED (Dribbble Reference Frames)  */}
        {/* ================================================================= */}
        <AnimatePresence>
          {isSidebarCollapsed && hoveredCollapsedItem && (
            <motion.div
              initial={{ opacity: 0, x: -6, scale: 0.98 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -6, scale: 0.98 }}
              transition={{ duration: 0.14, ease: 'easeOut' }}
              style={{ top: hoveredCollapsedItem.top }}
              onMouseEnter={() => {
                if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
              }}
              onMouseLeave={handleCollapsedMouseLeave}
              className="fixed left-[78px] z-50 min-w-[184px] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-[0_12px_32px_rgb(15,23,42,0.12)] dark:shadow-[0_12px_32px_rgb(0,0,0,0.45)] p-2"
            >
              {hoveredCollapsedItem.item.subItems &&
              hoveredCollapsedItem.item.subItems.length > 1 ? (
                <div className="space-y-0.5">
                  <div className="px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {t(
                      hoveredCollapsedItem.item.translationKey,
                      hoveredCollapsedItem.item.defaultLabel
                    )}
                  </div>
                  {hoveredCollapsedItem.item.subItems.map((sub) => {
                    const subActive = isSubItemActive(sub);
                    const subBadge = getBadgeCount(sub.badgeKey);
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => handleNavigate(sub)}
                        className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                          subActive
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold'
                            : 'text-slate-600 dark:text-slate-400 font-medium hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        <span>{t(sub.translationKey, sub.defaultLabel)}</span>
                        {subBadge > 0 && (
                          <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                            {subBadge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => handleNavigate(hoveredCollapsedItem.item)}
                  className="w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                >
                  <span>
                    {t(
                      hoveredCollapsedItem.item.translationKey,
                      hoveredCollapsedItem.item.defaultLabel
                    )}
                  </span>
                  {getBadgeCount(hoveredCollapsedItem.item.badgeKey) > 0 && (
                    <span className="ml-2 px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-slate-900 text-white dark:bg-white dark:text-slate-900">
                      {getBadgeCount(hoveredCollapsedItem.item.badgeKey)}
                    </span>
                  )}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </aside>

      {/* =================================================================== */}
      {/* MOBILE DRAWER OVERLAY — Matches Clean Dribbble Aesthetic            */}
      {/* No logo, church name, or search input                               */}
      {/* =================================================================== */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onCloseMobileMenu}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Slide-out Floating-Style Drawer */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className={`relative z-10 w-[84%] max-w-[300px] bg-white dark:bg-slate-900 h-full flex flex-col border-r border-slate-200/80 dark:border-slate-800 shadow-2xl ${fontFamilyClass}`}
            >
              {/* Mobile Drawer Top Header (Logo + Church Name + Close Toggle) */}
              <div className="px-4 pt-[max(0.875rem,env(safe-area-inset-top,0px))] pb-3 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-slate-900 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center overflow-hidden shrink-0">
                    {effectiveLogoUrl && !logoImgError ? (
                      <img
                        src={effectiveLogoUrl}
                        alt={effectiveChurchName}
                        onError={() => setLogoImgError(true)}
                        className="w-full h-full object-contain p-1 bg-white dark:bg-slate-900"
                      />
                    ) : (
                      <Church className="w-4.5 h-4.5 text-white dark:text-slate-100 stroke-[2]" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate leading-tight">
                      {effectiveChurchName}
                    </p>
                    <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 truncate mt-0.5">
                      {roleTitle}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onCloseMobileMenu}
                  aria-label="Close navigation menu"
                  className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
                >
                  <X className="w-4.5 h-4.5" />
                </button>
              </div>

              {/* Mobile Scrollable Navigation */}
              <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4 sidebar-themed-scrollbar">
                {authorizedGroups.map((group) => (
                  <div key={group.title} className="space-y-1">
                    <div className="px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-400 dark:text-slate-500">
                      {t(group.translationKey, group.title)}
                    </div>

                    <div className="space-y-0.5">
                      {group.items.map((item) => {
                        const active = isCurrentActive(item);
                        const Icon = item.icon;
                        const badgeCount = getBadgeCount(item.badgeKey);
                        const hasSubItems = Boolean(item.subItems && item.subItems.length > 1);
                        const isSubOpen = Boolean(expandedParentIds[item.id]);

                        return (
                          <div key={item.id}>
                            <button
                              type="button"
                              onClick={() => handleParentClick(item)}
                              className={`w-full min-h-[42px] flex items-center justify-between px-3 py-2 rounded-xl text-[13px] transition-all cursor-pointer ${
                                active
                                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold'
                                  : 'text-slate-600 dark:text-slate-400 font-medium hover:bg-slate-50 dark:hover:bg-slate-800/50'
                              }`}
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <Icon
                                  className={`w-[18px] h-[18px] shrink-0 ${
                                    active
                                      ? 'text-slate-900 dark:text-white'
                                      : 'text-slate-400 dark:text-slate-500'
                                  }`}
                                />
                                <span className="truncate">
                                  {t(item.translationKey, item.defaultLabel)}
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                {badgeCount > 0 && (
                                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-900 text-white dark:bg-white dark:text-slate-900">
                                    {badgeCount}
                                  </span>
                                )}
                                {hasSubItems && (
                                  <span
                                    role="button"
                                    tabIndex={-1}
                                    onClick={(e) => handleToggleSubmenuOnly(e, item.id)}
                                    className="p-1 text-slate-400"
                                  >
                                    {isSubOpen ? (
                                      <ChevronUp className="w-3.5 h-3.5" />
                                    ) : (
                                      <ChevronDown className="w-3.5 h-3.5" />
                                    )}
                                  </span>
                                )}
                              </div>
                            </button>

                            {/* Mobile Nested Sub-items with L-connector */}
                            {hasSubItems && isSubOpen && item.subItems && (
                              <div className="relative pl-6 pr-1 pt-1 pb-1 space-y-0.5">
                                {item.subItems.map((sub, idx) => {
                                  const subActive = isSubItemActive(sub);
                                  const isLast = idx === item.subItems!.length - 1;
                                  return (
                                    <div
                                      key={`mob-${item.id}-${sub.id}`}
                                      className="relative flex items-center"
                                    >
                                      <span
                                        aria-hidden="true"
                                        className={`absolute -left-2.5 top-0 w-px bg-slate-200 dark:bg-slate-700 ${
                                          isLast ? 'h-1/2' : 'h-full'
                                        }`}
                                      />
                                      <span
                                        aria-hidden="true"
                                        className="absolute -left-2.5 top-1/2 -translate-y-full w-2.5 h-2.5 border-l border-b border-slate-200 dark:border-slate-700 rounded-bl-lg"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => handleNavigate(sub)}
                                        className={`w-full min-h-[36px] flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs text-left ${
                                          subActive
                                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold'
                                            : 'text-slate-500 dark:text-slate-400 font-medium'
                                        }`}
                                      >
                                        <span className="truncate">
                                          {t(sub.translationKey, sub.defaultLabel)}
                                        </span>
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              {/* Mobile User Footer */}
              <div className="p-3.5 pb-[max(1rem,env(safe-area-inset-bottom,0px))] border-t border-slate-100 dark:border-slate-800/80 space-y-2.5">
                <div className="flex items-center justify-between gap-2.5 px-1">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs flex items-center justify-center shrink-0">
                      {getInitials(displayName)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                        {displayName}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">{roleTitle}</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Sidebar;


