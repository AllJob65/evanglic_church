import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { ROLE_PERMISSIONS_MATRIX, normalizeUserRole } from '../utils/rbac';
import { UserRole } from '../types';
import {
  Shield,
  Check,
  X,
  Lock,
  AlertCircle,
  Search,
  LayoutGrid,
  Table as TableIcon,
  CheckCircle2,
  DollarSign,
  UserCheck
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const RolePermissionsModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { activeRole, setActiveRole } = useCMMS();
  const [filterQuery, setFilterQuery] = useState('');
  const [viewMode, setViewMode] = useState<'matrix' | 'cards'>('matrix');

  // Lock body scroll on modal open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Handle escape key
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    },
    [onClose]
  );

  useEffect(() => {
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleKeyDown]);

  const roles = useMemo(
    () => Object.keys(ROLE_PERMISSIONS_MATRIX) as UserRole[],
    []
  );

  const filteredRoles = useMemo(() => {
    return roles.filter((role) =>
      role.toLowerCase().includes(filterQuery.toLowerCase().trim())
    );
  }, [roles, filterQuery]);

  if (!isOpen) return null;

  const formatCurrency = (amount: number) => {
    if (amount >= 9999999) return 'Unlimited';
    if (amount === 0) return '$0';
    return `$${amount.toLocaleString()}`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-7xl max-h-[92vh] flex flex-col border border-slate-200 dark:border-slate-800 overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Access Control Matrix
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300">
                  {roles.length} Roles
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Financial limits, administrative scopes, and security boundaries
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar Bar */}
        <div className="px-6 py-3.5 bg-slate-50/80 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Active Session:
            </span>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800">
              <UserCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="text-xs font-bold text-blue-900 dark:text-blue-200">
                {normalizeUserRole(activeRole)}
              </span>
              <span className="text-slate-300 dark:text-slate-700">|</span>
              <span className="text-xs font-medium text-blue-700 dark:text-blue-300 flex items-center gap-1">
                <DollarSign className="w-3 h-3" />
                Limit: {formatCurrency(ROLE_PERMISSIONS_MATRIX[normalizeUserRole(activeRole)]?.financialApprovalLimit || 0)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* View Switcher */}
            <div className="flex items-center bg-slate-200/60 dark:bg-slate-800 p-1 rounded-lg">
              <button
                onClick={() => setViewMode('matrix')}
                className={`p-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1 ${
                  viewMode === 'matrix'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Matrix Table View"
              >
                <TableIcon className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`p-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1 ${
                  viewMode === 'cards'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Card View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search roles..."
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                className="pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 w-48 sm:w-64"
              />
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="overflow-auto flex-1 p-4 sm:p-6">
          {filteredRoles.length === 0 ? (
            <div className="py-12 text-center text-slate-500 dark:text-slate-400">
              No roles matching "{filterQuery}"
            </div>
          ) : viewMode === 'matrix' ? (
            <div className="cmms-table-scroll overflow-x-auto border rounded-xl border-slate-200 dark:border-slate-800">
              <table className="cmms-data-table w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-100/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-semibold">
                    <th className="p-3 sticky left-0 bg-slate-100 dark:bg-slate-800 z-20 min-w-[180px] shadow-sm">
                      Role Name
                    </th>
                    <th className="p-3 min-w-[120px] whitespace-nowrap">Fin. Limit</th>
                    <th className="p-3 whitespace-nowrap">Members (V/E/D)</th>
                    <th className="p-3 whitespace-nowrap">Finances (V/M)</th>
                    <th className="p-3 whitespace-nowrap">Branches</th>
                    <th className="p-3 whitespace-nowrap">Ministries</th>
                    <th className="p-3 whitespace-nowrap">Workflows</th>
                    <th className="p-3 whitespace-nowrap">Audit Logs</th>
                    <th className="p-3 whitespace-nowrap">Counseling</th>
                    <th className="p-3 whitespace-nowrap">Export Scope</th>
                    <th className="p-3 text-center sticky right-0 bg-slate-100 dark:bg-slate-800 z-20 shadow-sm whitespace-nowrap">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredRoles.map((roleName) => {
                    const perm = ROLE_PERMISSIONS_MATRIX[roleName];
                    const isActive = activeRole === roleName;
                    return (
                      <tr
                        key={roleName}
                        className={`group hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                          isActive ? 'bg-blue-50/50 dark:bg-blue-950/30' : ''
                        }`}
                      >
                        <td className="p-3 sticky left-0 bg-white dark:bg-slate-900 z-10 font-medium text-slate-900 dark:text-white shadow-sm">
                          <div className="flex items-center gap-2">
                            {isActive && (
                              <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                            )}
                            <span className={isActive ? 'font-bold text-blue-600 dark:text-blue-400' : ''}>
                              {roleName}
                            </span>
                          </div>
                        </td>
                        <td className="p-3 whitespace-nowrap tabular-nums">
                          <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(perm.financialApprovalLimit)}
                          </span>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1">
                            <PermIcon active={perm.canViewAllMembers} />
                            <PermIcon active={perm.canEditMembers} />
                            <PermIcon active={perm.canDeleteMembers} isDanger />
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1">
                            <PermIcon active={perm.canViewFinances} />
                            <PermIcon active={perm.canManageFinances} />
                          </div>
                        </td>
                        <td className="p-3"><PermIcon active={perm.canManageBranches} /></td>
                        <td className="p-3"><PermIcon active={perm.canManageMinistries} /></td>
                        <td className="p-3"><PermIcon active={perm.canManageWorkflows} /></td>
                        <td className="p-3"><PermIcon active={perm.canViewAuditLogs} /></td>
                        <td className="p-3">
                          {perm.canViewCounseling ? (
                            <Lock className="w-4 h-4 text-purple-500" />
                          ) : (
                            <X className="w-4 h-4 text-slate-300 dark:text-slate-600" />
                          )}
                        </td>
                        <td className="p-3 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 whitespace-nowrap">
                            {perm.dataExportScope}
                          </span>
                        </td>
                        <td className="p-3 text-center sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/90 z-10 shadow-sm whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setActiveRole(roleName)}
                            disabled={isActive}
                            className={`min-h-[32px] px-3 py-1 rounded-lg text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                              isActive
                                ? 'bg-blue-600 text-white shadow-xs cursor-default'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 cursor-pointer'
                            }`}
                          >
                            {isActive ? 'Active' : 'Switch'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            /* Card View */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredRoles.map((roleName) => {
                const perm = ROLE_PERMISSIONS_MATRIX[roleName];
                const isActive = activeRole === roleName;
                return (
                  <div
                    key={roleName}
                    className={`p-5 rounded-xl border transition-all flex flex-col justify-between ${
                      isActive
                        ? 'border-blue-500 bg-blue-50/20 dark:bg-blue-950/20 shadow-md ring-1 ring-blue-500'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                          {roleName}
                        </h3>
                        {isActive && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white">
                            Active Role
                          </span>
                        )}
                      </div>

                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800">
                          <span className="text-slate-500 dark:text-slate-400">Financial Limit</span>
                          <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(perm.financialApprovalLimit)}
                          </span>
                        </div>
                        <div className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800">
                          <span className="text-slate-500 dark:text-slate-400">Export Scope</span>
                          <span className="font-medium text-slate-700 dark:text-slate-300">
                            {perm.dataExportScope}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px] mb-4">
                        <BadgePerm label="View Members" active={perm.canViewAllMembers} />
                        <BadgePerm label="Edit Members" active={perm.canEditMembers} />
                        <BadgePerm label="Manage Finances" active={perm.canManageFinances} />
                        <BadgePerm label="Audit Logs" active={perm.canViewAuditLogs} />
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveRole(roleName)}
                      disabled={isActive}
                      className={`w-full py-2 rounded-lg text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-blue-600 text-white cursor-default'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {isActive ? 'Current Active Role' : 'Switch to this Role'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer Note */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-blue-500 shrink-0" />
          <span>
            Role switches take effect immediately across all system navigation, approval thresholds, and data export scopes.
          </span>
        </div>
      </div>
    </div>
  );
};

// Helper components for granular permission icons
const PermIcon: React.FC<{ active: boolean; isDanger?: boolean }> = ({ active, isDanger }) => {
  if (!active) return <X className="w-4 h-4 text-slate-300 dark:text-slate-700" />;
  return isDanger ? (
    <X className="w-4 h-4 text-rose-500" />
  ) : (
    <Check className="w-4 h-4 text-emerald-500" />
  );
};

const BadgePerm: React.FC<{ label: string; active: boolean }> = ({ label, active }) => (
  <div className={`flex items-center gap-1.5 ${active ? 'text-slate-800 dark:text-slate-200' : 'text-slate-400 dark:text-slate-600'}`}>
    <PermIcon active={active} />
    <span>{label}</span>
  </div>
);