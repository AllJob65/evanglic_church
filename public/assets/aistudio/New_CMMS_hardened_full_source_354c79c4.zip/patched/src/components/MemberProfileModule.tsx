import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from '../i18n/LanguageContext';
import { Member, MembershipStatus, Gender, MaritalStatus } from '../types';
import { apiService } from '../services/api';
import { normalizeUserRole } from '../utils/rbac';
import { sanitizeEthiopianPhoneInput, validateEthiopianPhone } from '../utils/phoneValidation';
import { formatToE164 } from '../schemas/phone.schema';
import { gregorianToEthiopian } from '../utils/ethiopianCalendar';
import { EthiopianDateHelper, DEFAULT_MALE_AVATAR, DEFAULT_FEMALE_AVATAR } from './EthiopianDateHelper';
import { EthiopianPhoneInput } from './EthiopianPhoneInput';
import { MinistryLiveChatModal } from './MinistryLiveChatModal';
import { MinistryVideoConferenceModal } from './MinistryVideoConferenceModal';
import { DirectVideoCallModal } from './DirectVideoCallModal';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Heart,
  Briefcase,
  Shield,
  Edit3,
  Clock,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  QrCode,
  Users,
  Award,
  BookOpen,
  Send,
  Building,
  Home,
  FileText,
  X,
  Plus,
  MessageSquare,
  Video,
  Sparkles,
  RefreshCw,
  Camera,
  Upload,
  Paperclip,
  Eye,
} from 'lucide-react';

type FormTab = 'personal' | 'marital' | 'contact' | 'spiritual' | 'professional' | 'health';

export interface MemberProfileModuleProps {
  memberId?: string;
  member?: Member;
  onBack?: () => void;
}

export const MemberProfileModule: React.FC<MemberProfileModuleProps> = ({
  memberId,
  member: propMember,
  onBack,
}) => {
  const { t } = useTranslation();
  const {
    userProfile: authUserProfile,
    currentUser: authCurrentUser,
    loading: authLoading,
    userRole: authUserRole,
    branchId: authBranchId,
    branchName: authBranchName,
    refreshSession,
  } = useAuth();

  const {
    currentUser,
    members,
    families,
    profileChangeRequests,
    submitProfileChangeRequest,
    activeRole,
    branches,
    ministries,
    addAuditLog,
    reloadFromBackend,
  } = useCMMS();

  const [isLoadingProfile, setIsLoadingProfile] = useState<boolean>(false);
  const [profileLoadError, setProfileLoadError] = useState<string | null>(null);
  const [fetchedAuthUser, setFetchedAuthUser] = useState<any | null>(null);
  const [avatarLoadError, setAvatarLoadError] = useState<boolean>(false);

  // Authoritative authenticated user identity (from AuthContext or /api/auth/me)
  const effectiveAuthUser = authUserProfile || fetchedAuthUser || authCurrentUser || currentUser;
  const authEmail = String(effectiveAuthUser?.email || '').trim().toLowerCase();
  const authId = String(effectiveAuthUser?.id || (effectiveAuthUser as any)?.uid || '').trim();
  const authMemberId = String((effectiveAuthUser as any)?.memberId || '').trim();

  // Fetch / synchronize profile data once AuthContext finishes loading
  const loadAuthenticatedProfile = useCallback(async (forceRefresh = false) => {
    if (authLoading) return;
    if (!effectiveAuthUser && !forceRefresh) return;

    setIsLoadingProfile(true);
    setProfileLoadError(null);

    try {
      // 1. Verify / refresh authoritative user from /api/auth/me when needed
      try {
        const meRes = await apiService.getCurrentUser();
        if (meRes?.user) {
          setFetchedAuthUser(meRes.user);
        }
      } catch (meErr: any) {
        // Non-fatal if session is already in AuthContext; log only if forced
        if (forceRefresh && !effectiveAuthUser) {
          throw meErr;
        }
      }

      // 2. Ensure CMMS state (members, families, branches, ministries) is loaded
      if (forceRefresh || members.length === 0) {
        await reloadFromBackend();
      }
    } catch (err: any) {
      setProfileLoadError(
        err?.message || 'Unable to load your profile. Please check your connection and try again.'
      );
    } finally {
      setIsLoadingProfile(false);
    }
  }, [authLoading, effectiveAuthUser, members.length, reloadFromBackend]);

  useEffect(() => {
    if (!authLoading && effectiveAuthUser && members.length === 0) {
      loadAuthenticatedProfile(false);
    }
  }, [authLoading, effectiveAuthUser, members.length, loadAuthenticatedProfile]);

  // 1. Find explicitly linked Member record (NEVER fallback to members[0] which leaks another member's data)
  const matchedMemberRecord = useMemo<Member | null>(() => {
    if (propMember) return propMember;
    if (memberId) {
      return members.find((m) => m.id === memberId) || null;
    }
    if (!effectiveAuthUser) return null;

    return (
      (authMemberId ? members.find((m) => m.id === authMemberId) : undefined) ||
      (authId ? members.find((m) => m.id === authId) : undefined) ||
      (authEmail
        ? members.find((m) => m.email && m.email.trim().toLowerCase() === authEmail)
        : undefined) ||
      null
    );
  }, [propMember, memberId, members, effectiveAuthUser, authMemberId, authId, authEmail]);

  // 2. If no Member directory record exists yet, synthesize a real display profile from the authenticated user's session/SystemUser profile
  // (Supports SYSTEM_ADMIN, MANAGER, PASTOR, MINISTRY_LEADER, and Google OAuth / Supabase users)
  const synthesizedUserMember = useMemo<Member | null>(() => {
    if (matchedMemberRecord) return matchedMemberRecord;
    if (memberId) return null; // When viewing a specific memberId that doesn't exist, show not found
    if (!effectiveAuthUser || (!authEmail && !authId)) return null;

    const rawFullName = String(
      effectiveAuthUser.name ||
        (effectiveAuthUser as any).full_name ||
        (effectiveAuthUser as any).displayName ||
        (authEmail ? authEmail.split('@')[0] : 'Authenticated User')
    ).trim();

    const nameParts = rawFullName.split(/\s+/).filter(Boolean);
    const firstName = nameParts[0] || 'Authenticated';
    const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : 'User';
    const middleName = nameParts.length > 2 ? nameParts.slice(1, -1).join(' ') : '';

    // Check if user saved local profile overrides via Navbar Account modal
    let savedLocalProfile: any = null;
    try {
      const rawLocal = localStorage.getItem('cmms_user_profile');
      if (rawLocal) {
        const parsed = JSON.parse(rawLocal);
        if (!parsed.email || parsed.email.toLowerCase() === authEmail) {
          savedLocalProfile = parsed;
        }
      }
    } catch {}

    const resolvedRole = normalizeUserRole(
      effectiveAuthUser.role || authUserRole || activeRole || 'REGULAR_MEMBER'
    );
    const roleTitleMap: Record<string, string> = {
      SYSTEM_ADMIN: 'System Administrator',
      MANAGER: 'Operations Manager',
      PASTOR: 'Pastor',
      MINISTRY_LEADER: 'Ministry Leader',
      REGULAR_MEMBER: 'Member',
    };

    const resolvedAvatar =
      savedLocalProfile?.photoUrl ||
      (effectiveAuthUser as any).photoUrl ||
      (effectiveAuthUser as any).avatar ||
      (effectiveAuthUser as any).picture ||
      currentUser?.photoUrl ||
      DEFAULT_MALE_AVATAR;

    const resolvedBranchId =
      (effectiveAuthUser as any).branchId ||
      (effectiveAuthUser as any).branch_id ||
      authBranchId ||
      branches[0]?.id ||
      'br-1';

    return {
      id: authId || `usr-${authEmail || 'me'}`,
      memberIdNumber:
        (effectiveAuthUser as any).memberIdNumber ||
        (authId ? `USR-${authId.slice(0, 8).toUpperCase()}` : 'CMMS-USER'),
      title: (effectiveAuthUser as any).title || (resolvedRole === 'PASTOR' ? 'Pastor' : ''),
      name: savedLocalProfile?.name || rawFullName,
      firstName,
      middleName,
      lastName: nameParts.length > 2 ? nameParts[nameParts.length - 1] : (nameParts[1] || ''),
      dateOfBirth: (effectiveAuthUser as any).dateOfBirth || (effectiveAuthUser as any).dob || '',
      age: (effectiveAuthUser as any).age || undefined,
      gender: ((effectiveAuthUser as any).gender as any) || 'Male',
      photoUrl: resolvedAvatar,
      primaryPhone:
        savedLocalProfile?.phone ||
        effectiveAuthUser.phone ||
        (effectiveAuthUser as any).primaryPhone ||
        'Not provided',
      altPhone: (effectiveAuthUser as any).altPhone || '',
      email: authEmail || 'Not provided',
      preferredCommChannel: (effectiveAuthUser as any).preferredCommChannel || 'Email',
      streetAddress:
        (effectiveAuthUser as any).streetAddress ||
        (effectiveAuthUser as any).address ||
        'Not provided',
      city: (effectiveAuthUser as any).city || 'Addis Ababa',
      subCity: (effectiveAuthUser as any).subCity || 'Not provided',
      woreda: (effectiveAuthUser as any).woreda || 'Not provided',
      kebele: (effectiveAuthUser as any).kebele || 'Not provided',
      houseNumber: (effectiveAuthUser as any).houseNumber || 'Not provided',
      country: (effectiveAuthUser as any).country || 'Ethiopia',
      maritalStatus: (effectiveAuthUser as any).maritalStatus || undefined,
      occupation: (effectiveAuthUser as any).occupation || roleTitleMap[resolvedRole] || 'Member',
      membershipStatus: ((effectiveAuthUser as any).status || 'Active') as any,
      membershipType: resolvedRole === 'REGULAR_MEMBER' ? 'Full Member' : (roleTitleMap[resolvedRole] as any),
      membershipDate:
        (effectiveAuthUser as any).createdAt ||
        (effectiveAuthUser as any).created_at ||
        (effectiveAuthUser as any).lastLogin?.slice(0, 10) ||
        new Date().toISOString().slice(0, 10),
      branchId: resolvedBranchId,
      isWaterBaptized: Boolean((effectiveAuthUser as any).isWaterBaptized ?? true),
      foundationCourseCompleted: Boolean((effectiveAuthUser as any).foundationCourseCompleted ?? true),
      emergencyContact: (effectiveAuthUser as any).emergencyContact || {
        name: 'Not provided',
        relationship: 'Not provided',
        phone: 'Not provided',
      },
      ministryIds: Array.isArray((effectiveAuthUser as any).ministryIds)
        ? (effectiveAuthUser as any).ministryIds
        : [],
      createdAt:
        (effectiveAuthUser as any).createdAt ||
        (effectiveAuthUser as any).created_at ||
        new Date().toISOString().slice(0, 10),
      lastActive: (effectiveAuthUser as any).lastLogin || new Date().toISOString(),
      attendanceScore: 100,
    };
  }, [
    matchedMemberRecord,
    memberId,
    effectiveAuthUser,
    authEmail,
    authId,
    authUserRole,
    activeRole,
    currentUser?.photoUrl,
    authBranchId,
    branches,
  ]);

  const currentMember = matchedMemberRecord || synthesizedUserMember;
  const isSynthesizedAccountProfile = !matchedMemberRecord && Boolean(synthesizedUserMember);

  const currentRole = normalizeUserRole(activeRole || authUserRole || currentUser?.role || 'REGULAR_MEMBER');
  const isExecutiveStaff = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'].includes(currentRole);
  const isMinistryLeader = currentRole === 'MINISTRY_LEADER';

  // Determine if viewing member is in any ministry led by this leader
  const myMemberId =
    currentUser?.memberId ||
    members.find((m) => m.email?.toLowerCase() === authEmail)?.id ||
    authId;

  const myLedMinistries = ministries.filter(
    (m) =>
      (myMemberId && m.leaderMemberId === myMemberId) ||
      m.leaderMemberId === authId ||
      (Array.isArray((m as any).leaderMemberIds) && (
        (myMemberId && (m as any).leaderMemberIds.includes(myMemberId)) ||
        (m as any).leaderMemberIds.includes(authId)
      ))
  );

  const isMemberInMyLedMinistries = Boolean(
    currentMember &&
      myLedMinistries.some((m) => Array.isArray(m.memberIds) && m.memberIds.includes(currentMember.id))
  );

  const canStartPrivateCall = Boolean(
    currentMember &&
      currentMember.id !== myMemberId &&
      currentMember.id !== authId &&
      (isExecutiveStaff || (isMinistryLeader && isMemberInMyLedMinistries))
  );

  const linkedFamily = currentMember?.familyId ? families.find((f) => f.id === currentMember.familyId) : null;
  const branchObj = currentMember?.branchId ? branches.find((b) => b.id === currentMember.branchId) : null;
  const displayBranchName =
    branchObj?.name ||
    (effectiveAuthUser as any)?.branchName ||
    authBranchName ||
    'Headquarters Campus';

  // Track pending change requests for this member
  const memberPendingRequests = profileChangeRequests.filter(
    (req) => req.memberId === currentMember?.id && req.status === 'Pending'
  );

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [successNotice, setSuccessNotice] = useState('');
  const [errorNotice, setErrorNotice] = useState('');

  // 1:1 Direct Video Call Modal
  const [isDirectVideoModalOpen, setIsDirectVideoModalOpen] = useState(false);
  const [directVideoData, setDirectVideoData] = useState<{ conversationId: string; roomUrl: string } | null>(null);
  const [isStartingVideo, setIsStartingVideo] = useState(false);

  // Ministry Collaboration Modals
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [collabMinistryId, setCollabMinistryId] = useState<string>('');

  const handleLaunchChat = (minId: string) => {
    setCollabMinistryId(minId);
    setIsChatModalOpen(true);
  };

  const handleJoinVideo = (minId: string) => {
    setCollabMinistryId(minId);
    setIsVideoModalOpen(true);
  };

  // Start Private 1:1 Video Call
  const handleStartPrivateVideoCall = async () => {
    if (!currentMember) return;
    setIsStartingVideo(true);
    setErrorNotice('');
    try {
      // 1. Create or get direct conversation with this member
      const convRes = await apiService.createConversation({
        type: 'direct',
        participantIds: [currentMember.id],
      });
      if (!convRes.success || !convRes.conversation) {
        throw new Error('Failed to create or access direct conversation');
      }

      // 2. Start direct video call
      const callRes = await apiService.startDirectVideoCall(convRes.conversation.id);
      if (!callRes.success || !callRes.roomUrl) {
        throw new Error('Failed to initiate 1:1 video call');
      }

      setDirectVideoData({
        conversationId: convRes.conversation.id,
        roomUrl: callRes.roomUrl,
      });
      setIsDirectVideoModalOpen(true);
    } catch (err: any) {
      if (err?.code === 'MEMBER_TO_MEMBER_BLOCKED') {
        setErrorNotice(
          t(
            'member_to_member_blocked_video',
            'Direct video calls between regular members are restricted. One participant must be a staff member or ministry leader.'
          )
        );
      } else if (err?.code === 'OUTSIDE_LED_MINISTRY') {
        setErrorNotice(
          t(
            'outside_led_ministry_video',
            'Ministry leaders may only direct-message or call members of ministries they lead.'
          )
        );
      } else {
        setErrorNotice(
          err?.error || err?.message || t('failed_to_start_video', 'Failed to start private video call.')
        );
      }
    } finally {
      setIsStartingVideo(false);
    }
  };

  // Editable Form States (Matches MemberModule.tsx structure, fields, labels, and validation)
  const [editForm, setEditForm] = useState<Partial<Member>>({});
  const [formTab, setFormTab] = useState<FormTab>('personal');
  const [formValidationError, setFormValidationError] = useState<string>('');
  const [paperPreviewModal, setPaperPreviewModal] = useState<{
    isOpen: boolean;
    title: string;
    url: string;
    fileName?: string;
  }>({
    isOpen: false,
    title: '',
    url: '',
    fileName: '',
  });

  const cleanField = (val?: string) =>
    !val || val === 'Not provided' || val === 'Not available' ? '' : val;

  const handleGenderChange = (newGender: Gender) => {
    let updatedPhoto = editForm.photoUrl;
    if (
      !updatedPhoto ||
      updatedPhoto === DEFAULT_MALE_AVATAR ||
      updatedPhoto === DEFAULT_FEMALE_AVATAR
    ) {
      updatedPhoto = newGender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR;
    }
    setEditForm((prev) => ({ ...prev, gender: newGender, photoUrl: updatedPhoto }));
  };

  const handleOpenEdit = () => {
    if (!currentMember) return;
    setEditForm({
      ...currentMember,
      title: currentMember.title || 'Mr',
      firstName: cleanField(currentMember.firstName),
      middleName: cleanField(currentMember.middleName),
      lastName: cleanField(currentMember.lastName),
      gender: currentMember.gender || 'Male',
      dateOfBirth: cleanField(currentMember.dateOfBirth) || '1995-05-15',
      nationality: currentMember.nationality || 'Ethiopian',
      nationalIdNumber: cleanField(currentMember.nationalIdNumber),
      passportNumber: cleanField(currentMember.passportNumber),
      photoUrl:
        currentMember.photoUrl ||
        (currentMember.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR),
      maritalStatus: currentMember.maritalStatus || 'Single',
      marriageDate: cleanField(currentMember.marriageDate),
      divorceDate: cleanField(currentMember.divorceDate),
      spouseName: cleanField(currentMember.spouseName),
      spousePhone: cleanField(currentMember.spousePhone),
      spouseMemberId: cleanField(currentMember.spouseMemberId),
      maleChildrenCount: currentMember.maleChildrenCount ?? 0,
      femaleChildrenCount: currentMember.femaleChildrenCount ?? 0,
      adoptedChildrenCount: currentMember.adoptedChildrenCount ?? 0,
      primaryPhone: cleanField(currentMember.primaryPhone),
      altPhone: cleanField(currentMember.altPhone),
      email: cleanField(currentMember.email),
      preferredCommChannel: currentMember.preferredCommChannel || 'SMS',
      woreda: cleanField(currentMember.woreda),
      kebele: cleanField(currentMember.kebele),
      houseNumber: cleanField(currentMember.houseNumber),
      streetAddress: cleanField(currentMember.streetAddress),
      city: cleanField(currentMember.city) || 'Addis Ababa',
      subCity: cleanField(currentMember.subCity),
      region: cleanField(currentMember.region) || 'Addis Ababa',
      postalCode: cleanField(currentMember.postalCode),
      branchId: currentMember.branchId || branches[0]?.id || '',
      membershipDate:
        cleanField(currentMember.membershipDate) || new Date().toISOString().split('T')[0],
      membershipLocation: cleanField(currentMember.membershipLocation),
      salvationDate: cleanField(currentMember.salvationDate),
      salvationLocation: cleanField(currentMember.salvationLocation),
      isWaterBaptized: currentMember.isWaterBaptized ?? false,
      waterBaptismDate: cleanField(currentMember.waterBaptismDate),
      waterBaptismLocation: cleanField(currentMember.waterBaptismLocation),
      isHolySpiritBaptized: currentMember.isHolySpiritBaptized ?? false,
      foundationCourseCompleted: currentMember.foundationCourseCompleted ?? false,
      membershipStatus: currentMember.membershipStatus || 'Active',
      departureReason: currentMember.departureReason,
      departureDate: cleanField(currentMember.departureDate),
      departureEndDate: cleanField(currentMember.departureEndDate),
      statusStartDate: cleanField(currentMember.statusStartDate),
      statusEndDate: cleanField(currentMember.statusEndDate),
      excommunicationDescription: cleanField(currentMember.excommunicationDescription),
      excommunicationPaperUrl: currentMember.excommunicationPaperUrl || '',
      excommunicationPaperName: currentMember.excommunicationPaperName || '',
      educationLevel: currentMember.educationLevel || 'Bachelor',
      fieldOfStudy: cleanField(currentMember.fieldOfStudy),
      occupation: cleanField(currentMember.occupation),
      employerName: cleanField(currentMember.employerName),
      employerType: currentMember.employerType || 'Private',
      employerTypeOther: cleanField(currentMember.employerTypeOther),
      bloodType: currentMember.bloodType || 'A+',
      emergencyContact: {
        name: cleanField(currentMember.emergencyContact?.name),
        relationship: cleanField(currentMember.emergencyContact?.relationship),
        phone: cleanField(currentMember.emergencyContact?.phone),
      },
      ministryIds: Array.isArray(currentMember.ministryIds) ? [...currentMember.ministryIds] : [],
      ministriesJoinedNow: Array.isArray(currentMember.ministriesJoinedNow)
        ? [...currentMember.ministriesJoinedNow]
        : Array.isArray(currentMember.ministryIds)
        ? [...currentMember.ministryIds]
        : [],
      ministriesServedBefore: Array.isArray(currentMember.ministriesServedBefore)
        ? [...currentMember.ministriesServedBefore]
        : [],
    });
    setFormTab('personal');
    setFormValidationError('');
    setIsEditModalOpen(true);
  };

  const validateStrictMemberForm = (
    form: Partial<Member>
  ): { isValid: boolean; error?: string; tab?: FormTab } => {
    if (!form.firstName?.trim()) {
      return { isValid: false, error: 'First Name is strictly required.', tab: 'personal' };
    }
    if (!form.lastName?.trim()) {
      return {
        isValid: false,
        error: 'Last Name / Grandfather Name is strictly required.',
        tab: 'personal',
      };
    }
    if (!form.gender) {
      return { isValid: false, error: 'Gender must be selected.', tab: 'personal' };
    }
    if (!form.dateOfBirth) {
      return { isValid: false, error: 'Date of Birth is strictly required.', tab: 'personal' };
    }
    if (!form.primaryPhone?.trim()) {
      return {
        isValid: false,
        error: 'Primary Ethiopian Phone Number is strictly required.',
        tab: 'contact',
      };
    }
    const phoneCheck = validateEthiopianPhone(form.primaryPhone);
    if (!phoneCheck.isValid) {
      return {
        isValid: false,
        error:
          phoneCheck.error ||
          'Invalid Ethiopian phone (+251... 9 digits or 09/07... 10 digits)',
        tab: 'contact',
      };
    }
    if (form.altPhone?.trim()) {
      const altCheck = validateEthiopianPhone(form.altPhone);
      if (!altCheck.isValid) {
        return {
          isValid: false,
          error: `Invalid Alternative Phone: ${altCheck.error || 'Must be Ethiopian mobile'}`,
          tab: 'contact',
        };
      }
    }
    if (!form.woreda?.trim()) {
      return {
        isValid: false,
        error: 'Woreda is strictly required for Ethiopian address mapping.',
        tab: 'contact',
      };
    }
    if (!form.kebele?.trim()) {
      return {
        isValid: false,
        error: 'Kebele is strictly required for Ethiopian address mapping.',
        tab: 'contact',
      };
    }
    if (!form.houseNumber?.trim()) {
      return { isValid: false, error: 'House Number is strictly required.', tab: 'contact' };
    }
    if (form.maritalStatus === 'Married' && form.spousePhone?.trim()) {
      const spouseCheck = validateEthiopianPhone(form.spousePhone);
      if (!spouseCheck.isValid) {
        return {
          isValid: false,
          error: `Invalid Spouse Phone: ${
            spouseCheck.error || 'Must be Ethiopian mobile (09/07 or +2519/+2517)'
          }`,
          tab: 'marital',
        };
      }
    }
    if (form.emergencyContact?.phone?.trim()) {
      const emgCheck = validateEthiopianPhone(form.emergencyContact.phone);
      if (!emgCheck.isValid) {
        return {
          isValid: false,
          error: `Invalid Emergency Contact Phone: ${
            emgCheck.error || 'Must be Ethiopian mobile (09/07 or +2519/+2517)'
          }`,
          tab: 'health',
        };
      }
    }
    return { isValid: true };
  };

  const handleSubmitProfileChanges = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMember) return;

    const validation = validateStrictMemberForm(editForm);
    if (!validation.isValid) {
      setFormValidationError(validation.error || 'Please fill all required strict fields.');
      if (validation.tab) setFormTab(validation.tab);
      return;
    }
    setFormValidationError('');

    const statusNotActive = editForm.membershipStatus && editForm.membershipStatus !== 'Active';
    const startDate =
      editForm.departureDate ||
      editForm.statusStartDate ||
      (statusNotActive ? new Date().toISOString().split('T')[0] : undefined);
    const endDate =
      editForm.membershipStatus === 'Excommunicated'
        ? editForm.departureEndDate || editForm.statusEndDate || undefined
        : undefined;

    const formattedSubmission: Partial<Member> = {
      ...editForm,
      title: editForm.title || 'Mr',
      firstName: editForm.firstName!.trim(),
      middleName: (editForm.middleName || '').trim(),
      lastName: editForm.lastName!.trim(),
      gender: (editForm.gender as Gender) || 'Male',
      dateOfBirth: editForm.dateOfBirth || '1995-05-15',
      age: editForm.dateOfBirth
        ? new Date().getFullYear() - new Date(editForm.dateOfBirth).getFullYear()
        : currentMember.age,
      nationality: editForm.nationality || 'Ethiopian',
      photoUrl:
        editForm.photoUrl ||
        (editForm.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR),
      maritalStatus: editForm.maritalStatus || 'Single',
      marriageDate: editForm.maritalStatus === 'Married' ? editForm.marriageDate || '' : '',
      divorceDate: editForm.maritalStatus === 'Divorced' ? editForm.divorceDate || '' : '',
      spouseName: editForm.maritalStatus === 'Married' ? editForm.spouseName || '' : '',
      spousePhone:
        editForm.maritalStatus === 'Married' && editForm.spousePhone
          ? formatToE164(editForm.spousePhone)
          : '',
      spouseMemberId: editForm.maritalStatus === 'Married' ? editForm.spouseMemberId || '' : '',
      maleChildrenCount:
        editForm.maritalStatus === 'Single' ? 0 : Number(editForm.maleChildrenCount) || 0,
      femaleChildrenCount:
        editForm.maritalStatus === 'Single' ? 0 : Number(editForm.femaleChildrenCount) || 0,
      adoptedChildrenCount:
        editForm.maritalStatus === 'Single' ? 0 : Number(editForm.adoptedChildrenCount) || 0,
      primaryPhone: editForm.primaryPhone
        ? formatToE164(editForm.primaryPhone)
        : editForm.primaryPhone || '',
      altPhone: editForm.altPhone ? formatToE164(editForm.altPhone) : '',
      email: (editForm.email || '').trim(),
      preferredCommChannel: editForm.preferredCommChannel || 'SMS',
      woreda: (editForm.woreda || '').trim(),
      kebele: (editForm.kebele || '').trim(),
      houseNumber: (editForm.houseNumber || '').trim(),
      streetAddress: (editForm.streetAddress || '').trim(),
      city: (editForm.city || '').trim(),
      subCity: (editForm.subCity || '').trim(),
      region: (editForm.region || '').trim(),
      branchId: editForm.branchId || currentMember.branchId || branches[0]?.id || '',
      membershipDate: editForm.membershipDate || currentMember.membershipDate || '',
      membershipLocation: (editForm.membershipLocation || '').trim(),
      salvationDate: editForm.salvationDate || '',
      salvationLocation: (editForm.salvationLocation || '').trim(),
      isWaterBaptized: Boolean(editForm.isWaterBaptized),
      waterBaptismDate: editForm.isWaterBaptized ? editForm.waterBaptismDate || '' : '',
      waterBaptismLocation: editForm.isWaterBaptized
        ? (editForm.waterBaptismLocation || '').trim()
        : '',
      membershipStatus: (editForm.membershipStatus as MembershipStatus) || 'Active',
      departureReason: statusNotActive
        ? (editForm.departureReason as any) || (editForm.membershipStatus as any)
        : undefined,
      departureDate: statusNotActive ? startDate : undefined,
      statusStartDate: statusNotActive ? startDate : undefined,
      departureEndDate: statusNotActive ? endDate : undefined,
      statusEndDate: statusNotActive ? endDate : undefined,
      excommunicationPaperUrl:
        editForm.membershipStatus === 'Excommunicated'
          ? editForm.excommunicationPaperUrl
          : undefined,
      excommunicationPaperName:
        editForm.membershipStatus === 'Excommunicated'
          ? editForm.excommunicationPaperName
          : undefined,
      excommunicationDescription:
        editForm.membershipStatus === 'Excommunicated'
          ? editForm.excommunicationDescription
          : undefined,
      educationLevel: editForm.educationLevel || 'Bachelor',
      fieldOfStudy: (editForm.fieldOfStudy || '').trim(),
      occupation: (editForm.occupation || '').trim(),
      employerName: (editForm.employerName || '').trim(),
      employerType: editForm.employerType || 'Private',
      employerTypeOther:
        editForm.employerType === 'Other' ? (editForm.employerTypeOther || '').trim() : '',
      bloodType: editForm.bloodType || 'A+',
      emergencyContact: {
        name: (editForm.emergencyContact?.name || '').trim(),
        relationship: (editForm.emergencyContact?.relationship || '').trim(),
        phone: editForm.emergencyContact?.phone
          ? formatToE164(editForm.emergencyContact.phone)
          : '',
      },
    };

    const normalizeCompare = (val: any): string => {
      if (val === null || val === undefined || val === 'Not provided' || val === 'Not available') {
        return '';
      }
      if (typeof val === 'object') {
        if ('name' in val || 'relationship' in val || 'phone' in val) {
          return JSON.stringify({
            name: cleanField(val.name),
            relationship: cleanField(val.relationship),
            phone: cleanField(val.phone),
          });
        }
        return JSON.stringify(val);
      }
      return String(val).trim();
    };

    const editableKeys: (keyof Member)[] = [
      'photoUrl',
      'title',
      'firstName',
      'middleName',
      'lastName',
      'gender',
      'dateOfBirth',
      'nationality',
      'maritalStatus',
      'marriageDate',
      'divorceDate',
      'spouseName',
      'spousePhone',
      'spouseMemberId',
      'maleChildrenCount',
      'femaleChildrenCount',
      'adoptedChildrenCount',
      'primaryPhone',
      'altPhone',
      'email',
      'preferredCommChannel',
      'woreda',
      'kebele',
      'houseNumber',
      'streetAddress',
      'city',
      'subCity',
      'region',
      'branchId',
      'membershipDate',
      'membershipLocation',
      'salvationDate',
      'salvationLocation',
      'isWaterBaptized',
      'waterBaptismDate',
      'waterBaptismLocation',
      'membershipStatus',
      'departureReason',
      'departureDate',
      'departureEndDate',
      'excommunicationDescription',
      'excommunicationPaperUrl',
      'excommunicationPaperName',
      'educationLevel',
      'fieldOfStudy',
      'occupation',
      'employerName',
      'employerType',
      'employerTypeOther',
      'emergencyContact',
      'bloodType',
    ];

    const changedKeys: Partial<Member> = {};
    editableKeys.forEach((key) => {
      const nextVal = formattedSubmission[key];
      const prevVal = (currentMember as any)[key];
      if (nextVal !== undefined && normalizeCompare(nextVal) !== normalizeCompare(prevVal)) {
        (changedKeys as any)[key] = nextVal;
      }
    });

    if (Object.keys(changedKeys).length === 0) {
      setFormValidationError('No changes were detected from your existing profile.');
      return;
    }

    submitProfileChangeRequest(currentMember.id, changedKeys, currentMember);
    addAuditLog(
      'Submitted Profile Change Request',
      'Member Portal',
      `Member ${formattedSubmission.firstName} ${formattedSubmission.lastName} submitted profile update request (${Object.keys(changedKeys).length} fields)`
    );
    setIsEditModalOpen(false);
    setSuccessNotice(
      'Your profile modification request has been submitted to the Admin Approval Queue! Changes will take effect once approved.'
    );
    setTimeout(() => setSuccessNotice(''), 5000);
  };

  // 1. LOADING STATE: Wait for AuthContext restoration or initial profile fetch
  if (authLoading || (isLoadingProfile && !currentMember)) {
    return (
      <div
        role="status"
        aria-live="polite"
        className="space-y-6 animate-pulse"
      >
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex flex-col sm:flex-row items-center gap-5">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-slate-200 dark:bg-slate-800 shrink-0" />
            <div className="flex-1 space-y-3 w-full text-center sm:text-left">
              <div className="h-7 bg-slate-200 dark:bg-slate-800 rounded-xl w-48 sm:w-64 mx-auto sm:mx-0" />
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-lg w-36 sm:w-48 mx-auto sm:mx-0" />
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-lg w-56 mx-auto sm:mx-0" />
            </div>
          </div>
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-4 text-center sm:text-left">
            Loading profile...
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 h-56"
            >
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
              <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
              <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-2/3" />
              <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 2. ERROR STATE: If profile request failed and no profile is available
  if (profileLoadError && !currentMember) {
    return (
      <div
        role="alert"
        className="p-8 bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900/60 text-center space-y-4 max-w-xl mx-auto my-6 shadow-sm"
      >
        <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
          <AlertCircle className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Unable to load your profile.
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {profileLoadError}
          </p>
        </div>
        <button
          type="button"
          onClick={() => loadAuthenticatedProfile(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Retry Loading Profile</span>
        </button>
      </div>
    );
  }

  // 3. EMPTY PROFILE STATE: If authenticated user has no profile record at all
  if (!currentMember) {
    return (
      <div className="p-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-center space-y-4 max-w-xl mx-auto my-6 shadow-xs">
        <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
          <User className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Your profile information has not been completed yet.
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Please contact church administration or refresh to synchronize your member profile record.
          </p>
        </div>
        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => loadAuthenticatedProfile(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-xs cursor-pointer transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Profile</span>
          </button>
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              Go Back
            </button>
          )}
        </div>
      </div>
    );
  }

  const ethDob = currentMember.dateOfBirth ? gregorianToEthiopian(currentMember.dateOfBirth) : null;
  const fullDisplayName = [
    currentMember.title,
    currentMember.firstName,
    currentMember.middleName,
    currentMember.lastName,
  ]
    .filter(Boolean)
    .join(' ')
    .trim() || currentMember.name || 'Authenticated User';

  const fallbackAvatar =
    currentMember.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR;
  const avatarSrc =
    !avatarLoadError && currentMember.photoUrl ? currentMember.photoUrl : fallbackAvatar;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
            <img
              src={avatarSrc}
              alt={fullDisplayName}
              onError={() => setAvatarLoadError(true)}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover ring-4 ring-white/20 shadow-2xl shrink-0 bg-slate-800"
            />
            <div className="space-y-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  {fullDisplayName}
                </h1>
                <span className="px-3 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-blue-500/30 text-blue-200 border border-blue-400/40">
                  {currentMember.membershipStatus || 'Active'}
                </span>
              </div>
              <p className="text-xs text-blue-200 font-mono">
                ID: {currentMember.memberIdNumber || 'Not available'} • {currentMember.gender || 'Not provided'}
                {currentMember.age ? ` • Age ${currentMember.age}` : ''}
              </p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-2 text-xs text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-blue-400" />
                  {displayBranchName}
                </span>
                {linkedFamily && (
                  <span className="flex items-center gap-1.5">
                    <Home className="w-3.5 h-3.5 text-amber-400" />
                    {linkedFamily.householdName} ({currentMember.familyRole || 'Head'})
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row md:flex-col items-center gap-2.5 w-full md:w-auto">
            {canStartPrivateCall && (
              <button
                onClick={handleStartPrivateVideoCall}
                disabled={isStartingVideo}
                className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                title={t('start_private_video_call', 'Start Private Video Call')}
              >
                <Video className="w-4 h-4" />
                <span>
                  {isStartingVideo
                    ? t('connecting', 'Connecting...')
                    : t('start_private_video_call', 'Start Private Video Call')}
                </span>
              </button>
            )}

            <button
              onClick={handleOpenEdit}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Edit3 className="w-4 h-4" />
              Request Profile Update
            </button>
            <div className="px-3 py-1.5 rounded-xl bg-white/10 backdrop-blur-md text-[11px] text-blue-200 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-blue-300" />
              <span>Role: {currentRole}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Info Banner when viewing synthesized profile without a full Member Directory record */}
      {isSynthesizedAccountProfile && (
        <div className="p-4 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/80 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5 text-blue-900 dark:text-blue-200">
            <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Authenticated Account Profile ({currentRole})</p>
              <p className="text-[11px] text-blue-700 dark:text-blue-300">
                Showing your verified account credentials. You can click "Request Profile Update" to submit additional personal or address details.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleOpenEdit}
            className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] shrink-0 cursor-pointer"
          >
            Complete Details
          </button>
        </div>
      )}

      {/* Notifications */}
      {successNotice && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2 shadow-xs animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successNotice}</span>
        </div>
      )}

      {errorNotice && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 rounded-2xl text-rose-900 dark:text-rose-200 text-xs font-semibold flex items-center gap-2 shadow-xs animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorNotice}</span>
        </div>
      )}

      {/* Pending Approval Ticket Alert if active */}
      {memberPendingRequests.length > 0 && (
        <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-2xl space-y-2">
          <div className="flex items-center gap-2 text-amber-900 dark:text-amber-200 font-bold text-xs">
            <Clock className="w-4 h-4 text-amber-600 animate-spin" />
            <span>Profile Update Awaiting Administrator Authorization ({memberPendingRequests.length} pending)</span>
          </div>
          <div className="space-y-1.5 pl-6">
            {memberPendingRequests.map((req) => {
              const changeCount = req.changedFields?.length ?? Object.keys(req.newSnapshot || req.requestedChanges || {}).length;
              return (
                <div key={req.id} className="text-xs text-amber-800 dark:text-amber-300 flex items-center justify-between">
                  <span>
                    Ticket <strong>#{req.id}</strong> submitted on {req.submittedAt} (
                    {changeCount} fields requested)
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-200 text-amber-900">
                    Pending Admin Approval
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Profile Sections Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Column 1: Personal, Contact & Location Details */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <Phone className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-900 dark:text-white">
              Personal, Contact & Address
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">First Name</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {currentMember.firstName || 'Not provided'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Last Name</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {currentMember.lastName || 'Not provided'}
                </span>
              </div>
              {currentMember.middleName && (
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Middle Name</span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {currentMember.middleName}
                  </span>
                </div>
              )}
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Date of Birth</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {currentMember.dateOfBirth || 'Not provided'}
                </span>
              </div>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Primary Phone</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">
                {currentMember.primaryPhone || 'Not provided'}
              </span>
            </div>
            {currentMember.altPhone && (
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Alternative Phone</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">{currentMember.altPhone}</span>
              </div>
            )}
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Email Address</span>
              <span className="text-slate-700 dark:text-slate-300 break-all">
                {currentMember.email || 'Not provided'}
              </span>
            </div>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Residence & Location</span>
              <p className="font-semibold text-slate-900 dark:text-white">
                {currentMember.streetAddress || 'Not provided'}
              </p>
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 dark:text-slate-400 pt-1">
                <div>City: <strong className="text-slate-800 dark:text-slate-200">{currentMember.city || 'Not provided'}</strong></div>
                <div>Sub-City: <strong className="text-slate-800 dark:text-slate-200">{currentMember.subCity || 'Not provided'}</strong></div>
                <div>Country: <strong className="text-slate-800 dark:text-slate-200">{currentMember.country || 'Ethiopia'}</strong></div>
                <div>House No: <strong className="text-slate-800 dark:text-slate-200">{currentMember.houseNumber || 'Not provided'}</strong></div>
              </div>
            </div>
          </div>
        </div>

        {/* Column 2: Family & Household Container */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <Heart className="w-4 h-4 text-rose-500" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-900 dark:text-white">
              Family & Household Container
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Marital Status</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {currentMember.maritalStatus || 'Not provided'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Occupation</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {currentMember.occupation || 'Not provided'}
                </span>
              </div>
            </div>

            {currentMember.maritalStatus === 'Married' && (
              <div className="p-3 bg-rose-50/50 dark:bg-rose-950/30 rounded-xl border border-rose-200/60 dark:border-rose-900/60 space-y-1.5">
                <span className="text-[10px] font-bold text-rose-800 dark:text-rose-300 block">Spouse Details</span>
                <p className="font-bold text-slate-900 dark:text-white">{currentMember.spouseName || 'Not linked'}</p>
                {currentMember.spousePhone && (
                  <p className="font-mono text-slate-600 dark:text-slate-400">{currentMember.spousePhone}</p>
                )}
              </div>
            )}

            {linkedFamily ? (
              <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/30 rounded-xl border border-indigo-200/60 dark:border-indigo-900/60 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-indigo-950 dark:text-indigo-200 text-xs">
                    {linkedFamily.householdName}
                  </span>
                  <span className="font-mono text-[10px] text-indigo-600 dark:text-indigo-400 font-bold">
                    {linkedFamily.familyCode}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  Role: <strong>{currentMember.familyRole || 'Member'}</strong> • {linkedFamily.memberIds.length} Linked Family Members
                </p>
              </div>
            ) : (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-slate-500 dark:text-slate-400">
                Not currently linked to a multi-member household container.
              </div>
            )}
          </div>
        </div>

        {/* Column 3: Church Information & Spiritual Milestones */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <Award className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-900 dark:text-white">
              Church Membership & Milestones
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Branch / Campus</span>
                <span className="font-semibold text-slate-900 dark:text-white">{displayBranchName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Registration Date</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {currentMember.membershipDate || currentMember.createdAt || 'Not available'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Water Baptized</span>
              <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${currentMember.isWaterBaptized ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'}`}>
                {currentMember.isWaterBaptized ? '✓ Baptized' : 'Pending'}
              </span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Foundation Class</span>
              <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${currentMember.foundationCourseCompleted ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'}`}>
                {currentMember.foundationCourseCompleted ? '✓ Completed' : 'In Progress'}
              </span>
            </div>

            {ethDob && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Ethiopian Calendar DOB</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {ethDob.day}/{ethDob.month}/{ethDob.year} E.C. ({currentMember.dateOfBirth} G.C.)
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Ministries Joined by Member Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-xs">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Church Ministries & Service Departments Enrolled
              </h3>
              <p className="text-[11px] text-slate-500">
                Active ministry memberships, leadership roles, and rehearsal/meeting schedules
              </p>
            </div>
          </div>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
            {ministries.filter(
              (m) =>
                currentMember.ministryIds?.includes(m.id) ||
                m.memberIds?.includes(currentMember.id) ||
                m.leaderMemberId === currentMember.id
            ).length}{' '}
            Active Ministries
          </span>
        </div>

        {(() => {
          const joined = ministries.filter(
            (m) =>
              currentMember.ministryIds?.includes(m.id) ||
              m.memberIds?.includes(currentMember.id) ||
              m.leaderMemberId === currentMember.id
          );

          if (joined.length === 0) {
            return (
              <div className="p-6 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 space-y-2">
                <Users className="w-8 h-8 mx-auto text-slate-400" />
                <p className="text-xs font-semibold">You are not currently enrolled in any church ministry rosters.</p>
                <p className="text-[11px] text-slate-400">Visit the Ministry page or contact your pastoral team to join a team!</p>
              </div>
            );
          }

          return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {joined.map((min) => {
                const isLeader = min.leaderMemberId === currentMember.id;
                const isVolunteer = !isLeader && (min.category?.toLowerCase().includes('volunteer') || min.name?.toLowerCase().includes('media') || min.name?.toLowerCase().includes('usher'));
                const roleBadge = isLeader ? '👑 Ministry Leader' : isVolunteer ? '🌟 Ministry Volunteer' : '✓ Active Member';
                const roleBadgeClass = isLeader
                  ? 'bg-amber-100 text-amber-900 dark:bg-amber-900/60 dark:text-amber-200 border border-amber-300'
                  : isVolunteer
                  ? 'bg-purple-100 text-purple-900 dark:bg-purple-900/60 dark:text-purple-200 border border-purple-300'
                  : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200';

                return (
                  <div
                    key={min.id}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3 hover:border-indigo-500/50 transition-all flex flex-col justify-between shadow-xs"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-bold text-xs text-slate-900 dark:text-white">{min.name}</h4>
                          <span className="text-[10px] text-slate-500 font-mono">{min.category || 'Worship & Service'}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${roleBadgeClass}`}>
                          {roleBadge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-2">{min.description}</p>
                    </div>

                    <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-slate-700">
                      <div className="flex items-center justify-between text-[10px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-indigo-500" />
                          {min.meetingSchedule || 'Saturdays 3:00 PM'}
                        </span>
                        <span>{min.memberIds?.length || 12} Members</span>
                      </div>

                      {/* Direct Live Collaboration Action Buttons */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <button
                          onClick={() => handleLaunchChat(min.id)}
                          className="px-2.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold border border-indigo-200 dark:border-indigo-800 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                          <span>Launch Chat</span>
                        </button>

                        <button
                          onClick={() => handleJoinVideo(min.id)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold border border-emerald-200 dark:border-emerald-800 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <Video className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span>Join Video</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })()}
      </div>

      {/* Ministry Live Chat Real-Time Modal */}
      <MinistryLiveChatModal
        isOpen={isChatModalOpen}
        onClose={() => setIsChatModalOpen(false)}
        initialMinistryId={collabMinistryId}
        onSwitchToVideo={(mId) => {
          setIsChatModalOpen(false);
          setCollabMinistryId(mId);
          setIsVideoModalOpen(true);
        }}
      />

      {/* Ministry Video Conference Modal */}
      <MinistryVideoConferenceModal
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
        ministryId={collabMinistryId || ministries[0]?.id || 'min-1'}
      />

      {/* Profile Edit Request Modal (Reuses MemberModule 6-Tab Structure, Fields, Labels & Validation) */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-3xl border-0 sm:border border-slate-200 dark:border-slate-800 p-4 sm:p-6 my-0 sm:my-8 space-y-4 max-h-[92vh] sm:max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base sm:text-lg text-slate-900 dark:text-white flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-blue-600 shrink-0" />
                  <span className="truncate">
                    Request Profile Details Update: {editForm.firstName || currentMember.firstName} {editForm.lastName || currentMember.lastName}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Modifications are queued for Admin Authorization before updating your official member record
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Section Navigation Tabs */}
            <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 sm:gap-4 text-xs font-semibold overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => setFormTab('personal')}
                className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  formTab === 'personal' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                }`}
              >
                1. Personal & Identity
              </button>
              <button
                type="button"
                onClick={() => setFormTab('marital')}
                className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  formTab === 'marital' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                }`}
              >
                2. Marital & Family Status
              </button>
              <button
                type="button"
                onClick={() => setFormTab('contact')}
                className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  formTab === 'contact' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                }`}
              >
                3. Address (Woreda & Kebele)
              </button>
              <button
                type="button"
                onClick={() => setFormTab('spiritual')}
                className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  formTab === 'spiritual' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                }`}
              >
                4. Spiritual, Baptism & Ministry
              </button>
              <button
                type="button"
                onClick={() => setFormTab('professional')}
                className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  formTab === 'professional' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                }`}
              >
                5. Education & Work
              </button>
              <button
                type="button"
                onClick={() => setFormTab('health')}
                className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1 whitespace-nowrap cursor-pointer ${
                  formTab === 'health' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                }`}
              >
                6. Emergency & Health
              </button>
            </div>

            <form onSubmit={handleSubmitProfileChanges} className="space-y-4 text-xs">
              {/* Strict Validation Error Alert Banner */}
              {formValidationError && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center justify-between gap-2 text-xs text-rose-700 dark:text-rose-200 animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span className="font-semibold">{formValidationError}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormValidationError('')}
                    className="text-rose-600 dark:text-rose-300 font-bold hover:underline cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              )}

              {/* TAB 1: PERSONAL & IDENTITY DETAILS */}
              {formTab === 'personal' && (
                <div className="space-y-4">
                  {/* Photo Upload & Image Editor Panel */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <label className="block font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Camera className="w-4 h-4 text-blue-600" /> Member Photo & Profile Avatar
                    </label>

                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      <div className="relative shrink-0">
                        <img
                          src={editForm.photoUrl || (editForm.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR)}
                          alt="Member Preview"
                          className="w-20 h-20 rounded-2xl object-cover ring-4 ring-blue-500/20 shadow-md"
                        />
                      </div>

                      <div className="flex-1 w-full space-y-2 text-xs">
                        <div className="flex items-center gap-2">
                          <label className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold cursor-pointer transition-all flex items-center gap-1.5 shadow-sm">
                            <Upload className="w-4 h-4" /> Upload Custom Photo
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    setEditForm({ ...editForm, photoUrl: reader.result as string });
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                          <span className="text-[11px] text-slate-500">Auto-defaults to gender avatar if not uploaded</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Title</label>
                      <select
                        value={editForm.title || 'Mr'}
                        onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                      >
                        <option value="Mr">Mr</option>
                        <option value="Mrs">Mrs</option>
                        <option value="Ms">Ms</option>
                        <option value="Dr">Dr</option>
                        <option value="Pastor">Pastor</option>
                        <option value="Evangelist">Evangelist</option>
                        <option value="Teacher">Teacher</option>
                        <option value="Professor">Professor</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">First Name *</label>
                      <input
                        type="text"
                        required
                        value={editForm.firstName || ''}
                        onChange={(e) => setEditForm({ ...editForm, firstName: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Middle Name</label>
                      <input
                        type="text"
                        value={editForm.middleName || ''}
                        onChange={(e) => setEditForm({ ...editForm, middleName: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Last Name *</label>
                      <input
                        type="text"
                        required
                        value={editForm.lastName || ''}
                        onChange={(e) => setEditForm({ ...editForm, lastName: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Gender</label>
                      <select
                        value={editForm.gender || 'Male'}
                        onChange={(e) => handleGenderChange(e.target.value as Gender)}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                      </select>
                    </div>

                    {/* Date of Birth with Ethiopian Calendar Converter */}
                    <EthiopianDateHelper
                      label="Date of Birth"
                      value={editForm.dateOfBirth || '1995-05-15'}
                      onChange={(val) => setEditForm({ ...editForm, dateOfBirth: val })}
                    />

                    <div>
                      <label className="block font-semibold mb-1">Nationality</label>
                      <select
                        value={editForm.nationality || 'Ethiopian'}
                        onChange={(e) => setEditForm({ ...editForm, nationality: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                      >
                        <option value="Ethiopian">🇪🇹 Ethiopian</option>
                        <option value="Eritrean">🇪🇷 Eritrean</option>
                        <option value="Kenyan">🇰🇪 Kenyan</option>
                        <option value="Ugandan">🇺🇬 Ugandan</option>
                        <option value="Sudanese">🇸🇩 Sudanese</option>
                        <option value="South Sudanese">🇸🇸 South Sudanese</option>
                        <option value="Somali">🇸🇴 Somali</option>
                        <option value="Djiboutian">🇩🇯 Djiboutian</option>
                        <option value="American">🇺🇸 American</option>
                        <option value="Canadian">🇨🇦 Canadian</option>
                        <option value="British">🇬🇧 British</option>
                        <option value="German">🇩🇪 German</option>
                        <option value="Australian">🇦🇺 Australian</option>
                        <option value="Other">🌍 Other</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: MARITAL STATUS & FAMILY MEMBERS STATUS (CHILDREN BREAKDOWN) */}
              {formTab === 'marital' && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                      <div className="flex items-center gap-2">
                        <Heart className="w-4 h-4 text-rose-500" />
                        <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                          1. Marital Status & Partner Details
                        </h4>
                      </div>
                      <span
                        className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          editForm.maritalStatus === 'Married'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                        }`}
                      >
                        {editForm.maritalStatus || 'Single'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                          Marital Status *
                        </label>
                        <select
                          value={editForm.maritalStatus || 'Single'}
                          onChange={(e) =>
                            setEditForm({
                              ...editForm,
                              maritalStatus: e.target.value as MaritalStatus,
                            })
                          }
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-slate-900 dark:text-white"
                        >
                          <option value="Single">Single</option>
                          <option value="Married">Married</option>
                          <option value="Widowed">Widowed</option>
                          <option value="Divorced">Divorced</option>
                          <option value="Separated">Separated</option>
                        </select>
                      </div>

                      {editForm.maritalStatus === 'Married' && (
                        <EthiopianDateHelper
                          label="Marriage Date (Wedding Date)"
                          value={editForm.marriageDate || ''}
                          onChange={(val) => setEditForm({ ...editForm, marriageDate: val })}
                        />
                      )}

                      {editForm.maritalStatus === 'Divorced' && (
                        <EthiopianDateHelper
                          label="Divorce Date"
                          value={editForm.divorceDate || ''}
                          onChange={(val) => setEditForm({ ...editForm, divorceDate: val })}
                        />
                      )}
                    </div>

                    {editForm.maritalStatus === 'Married' && (
                      <div className="p-3.5 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900/60 space-y-3 mt-2">
                        <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-300 font-bold text-xs">
                          <Users className="w-4 h-4 text-emerald-600" />
                          <span>Spouse Information & Phone Mapping</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                              Spouse Full Name
                            </label>
                            <input
                              type="text"
                              placeholder="e.g., Almaz Bekele"
                              value={editForm.spouseName || ''}
                              onChange={(e) => setEditForm({ ...editForm, spouseName: e.target.value })}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                              Spouse Phone Number
                            </label>
                            <EthiopianPhoneInput
                              value={editForm.spousePhone || ''}
                              onChange={(e) => setEditForm({ ...editForm, spousePhone: e.target.value })}
                              placeholder="0911223344 or +251911223344"
                            />
                          </div>
                        </div>

                        {/* Auto Spouse Mapping by Phone */}
                        {(() => {
                          if (!editForm.spousePhone || editForm.spousePhone.length < 8) return null;
                          const cleanSearch = (editForm.spousePhone || '').replace(/[\s\-\(\)\+]/g, '');
                          if (cleanSearch.length < 8) return null;
                          const matchedSpouse = (members || []).find((m) => {
                            if (m.id === currentMember.id) return false;
                            const cleanMemberPhone = (m.primaryPhone || '').replace(/[\s\-\(\)\+]/g, '');
                            if (cleanMemberPhone.length < 8) return false;
                            return (
                              cleanMemberPhone.endsWith(cleanSearch.slice(-8)) ||
                              cleanSearch.endsWith(cleanMemberPhone.slice(-8))
                            );
                          });

                          if (matchedSpouse) {
                            return (
                              <div className="p-2.5 bg-emerald-100 dark:bg-emerald-900/60 rounded-xl border border-emerald-300 dark:border-emerald-700 flex items-center justify-between gap-2 text-xs">
                                <div className="flex items-center gap-2">
                                  <img
                                    src={matchedSpouse.photoUrl || DEFAULT_MALE_AVATAR}
                                    alt=""
                                    className="w-7 h-7 rounded-full object-cover"
                                  />
                                  <div>
                                    <span className="font-bold text-emerald-950 dark:text-emerald-200">
                                      Mapped Church Member Found: {matchedSpouse.title} {matchedSpouse.firstName} {matchedSpouse.lastName}
                                    </span>
                                    <div className="text-[10px] text-emerald-800 dark:text-emerald-300">
                                      ID: {matchedSpouse.memberIdNumber} • Phone: {matchedSpouse.primaryPhone}
                                    </div>
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditForm({
                                      ...editForm,
                                      spouseName: `${matchedSpouse.firstName} ${matchedSpouse.lastName}`,
                                      spouseMemberId: matchedSpouse.id,
                                      spousePhone: matchedSpouse.primaryPhone,
                                    });
                                  }}
                                  className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-[11px] shadow-sm transition-all"
                                >
                                  ✓ Link Spouse
                                </button>
                              </div>
                            );
                          }
                          return null;
                        })()}
                      </div>
                    )}
                  </div>

                  {/* Section 2: Family Members Status (Children Breakdown) - ONLY ACTIVE IF NOT SINGLE */}
                  {editForm.maritalStatus !== 'Single' ? (
                    <div className="p-4 bg-indigo-50/60 dark:bg-indigo-950/30 rounded-2xl border border-indigo-200 dark:border-indigo-800/60 space-y-3">
                      <div className="flex items-center justify-between border-b border-indigo-200 dark:border-indigo-800/60 pb-2">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                          <h4 className="font-bold text-indigo-950 dark:text-indigo-200 text-xs uppercase tracking-wider">
                            2. Family Members Status (Children Breakdown)
                          </h4>
                        </div>
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-200 text-indigo-900 dark:bg-indigo-900 dark:text-indigo-200">
                          Total: {(editForm.maleChildrenCount || 0) + (editForm.femaleChildrenCount || 0) + (editForm.adoptedChildrenCount || 0)} Children
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 dark:text-slate-400">
                        Specify count of biological and adopted children for family records, sunday school placement, and ministry tracking.
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 space-y-1">
                          <label className="block text-[11px] font-bold text-blue-700 dark:text-blue-300">
                            Male Children
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={editForm.maleChildrenCount ?? 0}
                            onChange={(e) =>
                              setEditForm({
                                ...editForm,
                                maleChildrenCount: parseInt(e.target.value) || 0,
                              })
                            }
                            className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-center text-blue-700 dark:text-blue-300 text-sm"
                          />
                        </div>

                        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 space-y-1">
                          <label className="block text-[11px] font-bold text-pink-700 dark:text-pink-300">
                            Female Children
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={editForm.femaleChildrenCount ?? 0}
                            onChange={(e) =>
                              setEditForm({
                                ...editForm,
                                femaleChildrenCount: parseInt(e.target.value) || 0,
                              })
                            }
                            className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-center text-pink-600 dark:text-pink-400 text-sm"
                          />
                        </div>

                        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 space-y-1">
                          <label className="block text-[11px] font-bold text-amber-700 dark:text-amber-300">
                            Adopted Children
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={editForm.adoptedChildrenCount ?? 0}
                            onChange={(e) =>
                              setEditForm({
                                ...editForm,
                                adoptedChildrenCount: parseInt(e.target.value) || 0,
                              })
                            }
                            className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-center text-amber-600 dark:text-amber-400 text-sm"
                          />
                        </div>
                      </div>

                      <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-200/80 dark:border-indigo-900/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">Children Summary:</span>
                        <div className="flex flex-wrap items-center gap-1.5 font-bold text-[11px]">
                          <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 dark:bg-blue-950 dark:text-blue-200">
                            👦 {editForm.maleChildrenCount || 0} Male
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-pink-50 text-pink-800 dark:bg-pink-950 dark:text-pink-200">
                            👧 {editForm.femaleChildrenCount || 0} Female
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 dark:bg-amber-950 dark:text-amber-200">
                            👶 {editForm.adoptedChildrenCount || 0} Adopted
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-slate-500 text-xs">
                      <Users className="w-6 h-6 mx-auto mb-1 text-slate-400" />
                      <p className="font-semibold">Family & Children breakdown is active for Married, Widowed, Divorced, or Separated members.</p>
                      <p className="text-[10px] mt-0.5">Currently registered as <strong>Single</strong>.</p>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: CONTACT & ADDRESS (Woreda, Kebele, House Number) */}
              {formTab === 'contact' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <EthiopianPhoneInput
                      label="Primary Phone Number"
                      required
                      value={editForm.primaryPhone || ''}
                      onChange={(e) => setEditForm({ ...editForm, primaryPhone: e.target.value })}
                      placeholder="0911234567 or +251911234567"
                      helperText="Ethiopian mobile number for member identification and official SMS notifications."
                      showQuickPrefixes={true}
                    />
                    <EthiopianPhoneInput
                      label="Alternative Phone (Optional)"
                      value={editForm.altPhone || ''}
                      onChange={(e) => setEditForm({ ...editForm, altPhone: e.target.value })}
                      placeholder="0912345678 or 0712345678"
                      helperText="Secondary contact number."
                      showQuickPrefixes={false}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">
                        Email Address <span className="text-slate-400 font-normal">(Optional)</span>
                      </label>
                      <input
                        type="email"
                        placeholder="member@example.com (optional)"
                        value={editForm.email || ''}
                        onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Preferred Communication</label>
                      <select
                        value={editForm.preferredCommChannel || 'SMS'}
                        onChange={(e) => setEditForm({ ...editForm, preferredCommChannel: e.target.value as any })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                      >
                        <option value="SMS">SMS (Text Message)</option>
                        <option value="Email">Email</option>
                        <option value="WhatsApp">WhatsApp</option>
                        <option value="Phone">Phone Call</option>
                      </select>
                    </div>
                  </div>

                  {/* Contact Address Fields: Kebele, House Number, Woreda */}
                  <div className="p-3.5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-200 dark:border-blue-900/60 space-y-3">
                    <label className="block font-bold text-blue-950 dark:text-blue-200 text-xs">
                      Residential Address Details (Ethiopia Standard)
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                          Woreda (Worda) *
                        </label>
                        <input
                          type="text"
                          placeholder="e.g., Woreda 03"
                          value={editForm.woreda || ''}
                          onChange={(e) => setEditForm({ ...editForm, woreda: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                          Kebele *
                        </label>
                        <input
                          type="text"
                          placeholder="e.g., Kebele 05"
                          value={editForm.kebele || ''}
                          onChange={(e) => setEditForm({ ...editForm, kebele: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                          House Number *
                        </label>
                        <input
                          type="text"
                          placeholder="e.g., House No. 124"
                          value={editForm.houseNumber || ''}
                          onChange={(e) => setEditForm({ ...editForm, houseNumber: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-semibold mb-1">Street Address</label>
                        <input
                          type="text"
                          placeholder="e.g. Bole Road, Near Mall"
                          value={editForm.streetAddress || ''}
                          onChange={(e) => setEditForm({ ...editForm, streetAddress: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold mb-1">Sub-City / City</label>
                        <input
                          type="text"
                          placeholder="e.g. Bole, Addis Ababa"
                          value={editForm.city || ''}
                          onChange={(e) => setEditForm({ ...editForm, city: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold mb-1">Region / State</label>
                        <input
                          type="text"
                          value={editForm.region || ''}
                          onChange={(e) => setEditForm({ ...editForm, region: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: SPIRITUAL, BAPTISM, MEMBERSHIP & MINISTRY */}
              {formTab === 'spiritual' && (
                <div className="space-y-4">
                  {/* Membership Details (Date & Location) */}
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <label className="block font-bold text-slate-900 dark:text-white text-xs">
                      Membership Details
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-semibold mb-1">Assigned Campus Branch</label>
                        <select
                          value={editForm.branchId || ''}
                          onChange={(e) => setEditForm({ ...editForm, branchId: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        >
                          {branches.map((b) => (
                            <option key={b.id} value={b.id}>
                              {b.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <EthiopianDateHelper
                        label="Membership Date"
                        value={editForm.membershipDate || ''}
                        onChange={(val) => setEditForm({ ...editForm, membershipDate: val })}
                      />

                      <div>
                        <label className="block font-semibold mb-1">Membership Received Location / Church</label>
                        <input
                          type="text"
                          placeholder="e.g. Grace Cathedral Main Church"
                          value={editForm.membershipLocation || ''}
                          onChange={(e) => setEditForm({ ...editForm, membershipLocation: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Salvation Details (Where saved & Date) */}
                  <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/60 space-y-3">
                    <label className="block font-bold text-amber-950 dark:text-amber-200 text-xs">
                      Salvation Details
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <EthiopianDateHelper
                        label="Salvation Date"
                        value={editForm.salvationDate || ''}
                        onChange={(val) => setEditForm({ ...editForm, salvationDate: val })}
                      />

                      <div>
                        <label className="block font-semibold mb-1">Where Saved (Church / City / Location)</label>
                        <input
                          type="text"
                          placeholder="e.g. Full Gospel Church, Addis Ababa"
                          value={editForm.salvationLocation || ''}
                          onChange={(e) => setEditForm({ ...editForm, salvationLocation: e.target.value })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Water Baptism Details (Church & Date) */}
                  <div className="p-3.5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-200 dark:border-blue-900/60 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block font-bold text-blue-950 dark:text-blue-200 text-xs">
                        Water Baptism Status & Details
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer font-bold">
                        <input
                          type="checkbox"
                          checked={Boolean(editForm.isWaterBaptized)}
                          onChange={(e) => setEditForm({ ...editForm, isWaterBaptized: e.target.checked })}
                          className="w-4 h-4 text-blue-600 rounded"
                        />
                        <span>Is Water Baptized?</span>
                      </label>
                    </div>

                    {editForm.isWaterBaptized && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <EthiopianDateHelper
                          label="Baptism Date"
                          value={editForm.waterBaptismDate || ''}
                          onChange={(val) => setEditForm({ ...editForm, waterBaptismDate: val })}
                        />

                        <div>
                          <label className="block font-semibold mb-1">Where Baptized (Church / Lake / Location)</label>
                          <input
                            type="text"
                            placeholder="e.g. Grace Cathedral Church / Lake Bishoftu"
                            value={editForm.waterBaptismLocation || ''}
                            onChange={(e) => setEditForm({ ...editForm, waterBaptismLocation: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <label className="block font-bold text-slate-900 dark:text-white text-xs">
                      Membership Status & Active Record Status
                    </label>
                    <div>
                      <label className="block font-semibold mb-1">Membership Status</label>
                      <select
                        value={editForm.membershipStatus || 'Active'}
                        onChange={(e) => {
                          const newStatus = e.target.value as MembershipStatus;
                          setEditForm({
                            ...editForm,
                            membershipStatus: newStatus,
                            departureReason: newStatus !== 'Active' ? (newStatus as any) : undefined,
                          });
                        }}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold"
                      >
                        <option value="Active">🟢 Active Member</option>
                        <option value="Inactive">⏸️ Inactive Status</option>
                        <option value="Transferred">🔄 Transferred to Another Church</option>
                        <option value="On Leave">🏖️ On Leave</option>
                        <option value="Left Church">🚪 Left Church</option>
                        <option value="Excommunicated">⛔ Excommunicated</option>
                        <option value="Deceased">✝️ Deceased (Passed Away)</option>
                      </select>
                    </div>

                    {editForm.membershipStatus && editForm.membershipStatus !== 'Active' && (
                      <div className="p-3 bg-amber-50/80 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 space-y-3 pt-2">
                        <div className="flex items-center gap-1.5 text-amber-900 dark:text-amber-200 font-bold text-xs">
                          <Calendar className="w-4 h-4 text-amber-600" />
                          <span>Non-Active Status Details ({editForm.membershipStatus})</span>
                        </div>
                        <div
                          className={
                            editForm.membershipStatus === 'Excommunicated'
                              ? 'grid grid-cols-1 sm:grid-cols-2 gap-3'
                              : 'grid grid-cols-1 gap-3'
                          }
                        >
                          <EthiopianDateHelper
                            label={
                              editForm.membershipStatus === 'Excommunicated'
                                ? 'Excommunication Start Date *'
                                : 'Status / Departure Date *'
                            }
                            value={
                              editForm.departureDate ||
                              editForm.statusStartDate ||
                              new Date().toISOString().split('T')[0]
                            }
                            onChange={(val) =>
                              setEditForm({
                                ...editForm,
                                departureDate: val,
                                statusStartDate: val,
                                departureReason: (editForm.membershipStatus as any) || 'Inactive',
                              })
                            }
                          />

                          {editForm.membershipStatus === 'Excommunicated' && (
                            <EthiopianDateHelper
                              label="Excommunication End Date (Optional)"
                              value={editForm.departureEndDate || editForm.statusEndDate || ''}
                              onChange={(val) =>
                                setEditForm({
                                  ...editForm,
                                  departureEndDate: val,
                                  statusEndDate: val,
                                })
                              }
                            />
                          )}
                        </div>

                        {editForm.membershipStatus === 'Excommunicated' && (
                          <div className="space-y-3 pt-2 border-t border-purple-200 dark:border-purple-800/60">
                            <div>
                              <label className="block text-xs font-bold text-purple-950 dark:text-purple-200 mb-1 flex items-center gap-1">
                                <FileText className="w-3.5 h-3.5 text-purple-600" />
                                Excommunication Description & Official Decree
                              </label>
                              <textarea
                                rows={3}
                                value={editForm.excommunicationDescription || ''}
                                onChange={(e) =>
                                  setEditForm({ ...editForm, excommunicationDescription: e.target.value })
                                }
                                placeholder="Enter official reason, description, or decree for excommunication..."
                                className="w-full px-3 py-2 text-xs rounded-xl border border-purple-200 dark:border-purple-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-purple-950 dark:text-purple-200 mb-1 flex items-center gap-1">
                                <Paperclip className="w-3.5 h-3.5 text-purple-600" />
                                Paper of Excommunication (Import Document / Letter)
                              </label>
                              {editForm.excommunicationPaperUrl ? (
                                <div className="flex items-center justify-between p-2.5 bg-purple-100/70 dark:bg-purple-950/80 rounded-xl border border-purple-300 dark:border-purple-700 text-xs">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <FileText className="w-4 h-4 text-purple-700 shrink-0" />
                                    <span className="font-bold text-purple-900 dark:text-purple-200 truncate">
                                      {editForm.excommunicationPaperName || 'Excommunication_Paper.pdf'}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2 shrink-0">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setPaperPreviewModal({
                                          isOpen: true,
                                          title: 'Paper of Excommunication',
                                          url: editForm.excommunicationPaperUrl || '',
                                          fileName:
                                            editForm.excommunicationPaperName || 'Excommunication Paper',
                                        })
                                      }
                                      className="px-2.5 py-1 bg-purple-700 text-white rounded-lg font-bold text-[11px] hover:bg-purple-800 flex items-center gap-1"
                                    >
                                      <Eye className="w-3 h-3" /> View
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        setEditForm({
                                          ...editForm,
                                          excommunicationPaperUrl: '',
                                          excommunicationPaperName: '',
                                        })
                                      }
                                      className="p-1 text-rose-600 hover:text-rose-800 dark:text-rose-400"
                                      title="Remove document"
                                    >
                                      <X className="w-4 h-4" />
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <label className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-purple-300 dark:border-purple-700 rounded-xl cursor-pointer hover:bg-purple-50/50 dark:hover:bg-purple-950/30 transition-colors text-xs font-bold text-purple-800 dark:text-purple-300">
                                  <Upload className="w-4 h-4 text-purple-600" />
                                  <span>Import / Upload Paper of Excommunication (PDF, Image, Scan)</span>
                                  <input
                                    type="file"
                                    accept="image/*,.pdf,.doc,.docx"
                                    className="hidden"
                                    onChange={(e) => {
                                      const file = e.target.files?.[0];
                                      if (file) {
                                        const reader = new FileReader();
                                        reader.onload = (evt) => {
                                          setEditForm({
                                            ...editForm,
                                            excommunicationPaperUrl: evt.target?.result as string,
                                            excommunicationPaperName: file.name,
                                          });
                                        };
                                        reader.readAsDataURL(file);
                                      }
                                    }}
                                  />
                                </label>
                              )}
                            </div>
                          </div>
                        )}
                        <p className="text-[11px] text-amber-800 dark:text-amber-300 italic">
                          Note: Members with non-active statuses will automatically be archived under the{' '}
                          <strong>Past and Death Record</strong> tab upon approval.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 5: EDUCATION & WORK */}
              {formTab === 'professional' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Education Level</label>
                      <select
                        value={editForm.educationLevel || 'Bachelor'}
                        onChange={(e) => setEditForm({ ...editForm, educationLevel: e.target.value as any })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="No Formal Education">No Formal Education</option>
                        <option value="Primary">Primary</option>
                        <option value="Secondary">Secondary</option>
                        <option value="Diploma">Diploma</option>
                        <option value="Bachelor">Bachelor Degree</option>
                        <option value="Master">Master Degree</option>
                        <option value="Doctorate">Doctorate</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Field of Study</label>
                      <input
                        type="text"
                        value={editForm.fieldOfStudy || ''}
                        onChange={(e) => setEditForm({ ...editForm, fieldOfStudy: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Occupation / Profession</label>
                      <input
                        type="text"
                        value={editForm.occupation || ''}
                        onChange={(e) => setEditForm({ ...editForm, occupation: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Employer / Organization</label>
                      <input
                        type="text"
                        value={editForm.employerName || ''}
                        onChange={(e) => setEditForm({ ...editForm, employerName: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Employer Type</label>
                      <select
                        value={editForm.employerType || 'Individual'}
                        onChange={(e) => setEditForm({ ...editForm, employerType: e.target.value as any })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="Individual">Individual</option>
                        <option value="Private">Private</option>
                        <option value="Government">Government</option>
                        <option value="NGO (Non-Profit)">NGO (Non-Profit)</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>

                  {editForm.employerType === 'Other' && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 animate-in fade-in">
                      <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                        Specify Other Employer Type *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., Freelance / Cooperative / Self-Employed / Missionary Organization"
                        value={editForm.employerTypeOther || ''}
                        onChange={(e) => setEditForm({ ...editForm, employerTypeOther: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* TAB 6: HEALTH & EMERGENCY */}
              {formTab === 'health' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Emergency Contact Name</label>
                      <input
                        type="text"
                        value={editForm.emergencyContact?.name || ''}
                        onChange={(e) =>
                          setEditForm({
                            ...editForm,
                            emergencyContact: {
                              name: e.target.value,
                              relationship: editForm.emergencyContact?.relationship || '',
                              phone: editForm.emergencyContact?.phone || '',
                            },
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Relationship</label>
                      <input
                        type="text"
                        value={editForm.emergencyContact?.relationship || ''}
                        onChange={(e) =>
                          setEditForm({
                            ...editForm,
                            emergencyContact: {
                              name: editForm.emergencyContact?.name || '',
                              relationship: e.target.value,
                              phone: editForm.emergencyContact?.phone || '',
                            },
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <EthiopianPhoneInput
                        label="Emergency Phone"
                        value={editForm.emergencyContact?.phone || ''}
                        onChange={(e) =>
                          setEditForm({
                            ...editForm,
                            emergencyContact: {
                              name: editForm.emergencyContact?.name || '',
                              relationship: editForm.emergencyContact?.relationship || '',
                              phone: e.target.value,
                            },
                          })
                        }
                        placeholder="0911223344 or +251911223344"
                        showQuickPrefixes={false}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold mb-1">Blood Type</label>
                    <select
                      value={editForm.bloodType || 'A+'}
                      onChange={(e) => setEditForm({ ...editForm, bloodType: e.target.value as any })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    >
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
                <div className="flex gap-2">
                  {formTab !== 'personal' && (
                    <button
                      type="button"
                      onClick={() => {
                        if (formTab === 'marital') setFormTab('personal');
                        if (formTab === 'contact') setFormTab('marital');
                        if (formTab === 'spiritual') setFormTab('contact');
                        if (formTab === 'professional') setFormTab('spiritual');
                        if (formTab === 'health') setFormTab('professional');
                      }}
                      className="px-3 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-xl font-semibold cursor-pointer"
                    >
                      &larr; Back
                    </button>
                  )}
                  {formTab !== 'health' && (
                    <button
                      type="button"
                      onClick={() => {
                        if (formTab === 'personal') setFormTab('marital');
                        if (formTab === 'marital') setFormTab('contact');
                        if (formTab === 'contact') setFormTab('spiritual');
                        if (formTab === 'spiritual') setFormTab('professional');
                        if (formTab === 'professional') setFormTab('health');
                      }}
                      className="px-3 py-1.5 bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 rounded-xl font-semibold cursor-pointer"
                    >
                      Next Section &rarr;
                    </button>
                  )}
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    Submit Request for Approval
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Paper Preview Modal */}
      {paperPreviewModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">{paperPreviewModal.title}</h3>
              <button
                type="button"
                onClick={() => setPaperPreviewModal({ ...paperPreviewModal, isOpen: false })}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="max-h-[70vh] overflow-auto flex items-center justify-center bg-slate-50 dark:bg-slate-800 rounded-xl p-4">
              {paperPreviewModal.url.startsWith('data:image') ? (
                <img src={paperPreviewModal.url} alt={paperPreviewModal.fileName} className="max-h-[60vh] object-contain rounded-lg" />
              ) : (
                <iframe src={paperPreviewModal.url} title={paperPreviewModal.title} className="w-full h-[60vh] rounded-lg" />
              )}
            </div>
          </div>
        </div>
      )}

      {/* 1:1 Private Video Call Modal */}
      {isDirectVideoModalOpen && directVideoData && (
        <DirectVideoCallModal
          isOpen={isDirectVideoModalOpen}
          onClose={() => {
            setIsDirectVideoModalOpen(false);
            setDirectVideoData(null);
          }}
          conversationId={directVideoData.conversationId}
          roomUrl={directVideoData.roomUrl}
          remoteParticipantName={fullDisplayName}
          remoteParticipantRole={currentMember.membershipStatus || 'Member'}
          remoteParticipantAvatar={avatarSrc}
        />
      )}
    </div>
  );
};

