import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, KeyRound, ShieldCheck, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { validatePasswordStrength } from '../utils/passwordValidation';

export const SupabasePasswordResetPage: React.FC = () => {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [recoveryReady, setRecoveryReady] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const validation = useMemo(() => validatePasswordStrength(password), [password]);
  const passwordsMatch = Boolean(password && confirmPassword && password === confirmPassword);

  useEffect(() => {
    let active = true;
    const params = new URLSearchParams(window.location.search);
    const tokenHash = params.get('token_hash');
    const tokenType = params.get('type');

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!active) return;
      if (event === 'PASSWORD_RECOVERY' && session) {
        setRecoveryReady(true);
        setChecking(false);
        setErrorMessage('');
      }
    });

    const initializeRecovery = async () => {
      if (!isSupabaseConfigured) {
        if (active) {
          setErrorMessage('Password recovery is unavailable because Supabase is not configured.');
          setChecking(false);
        }
        return;
      }

      // Supports custom Supabase email templates that send TokenHash directly
      // to /reset-password?token_hash=...&type=recovery.
      if (tokenHash && tokenType === 'recovery') {
        const { data, error } = await supabase.auth.verifyOtp({
          token_hash: tokenHash,
          type: 'recovery',
        });
        if (!active) return;
        if (error || !data.session) {
          setErrorMessage(error?.message || 'This password reset link is invalid or has expired. Request a new link.');
          setChecking(false);
          return;
        }
        setRecoveryReady(true);
        setChecking(false);
        window.history.replaceState({}, document.title, '/reset-password');
        return;
      }

      // Supports the standard Supabase ConfirmationURL flow (access token in
      // the URL fragment) and authenticated recovery sessions after redirect.
      const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ''));
      const hasRecoveryMarker = hashParams.get('type') === 'recovery';
      const { data, error } = await supabase.auth.getSession();
      if (!active) return;

      if (!error && data.session && hasRecoveryMarker) {
        setRecoveryReady(true);
        setErrorMessage('');
      } else if (hashParams.get('error_description') || hashParams.get('error')) {
        setErrorMessage(
          hashParams.get('error_description') ||
          hashParams.get('error') ||
          'The password reset link could not be verified.'
        );
      } else {
        setErrorMessage('This password reset link is invalid, expired, or already used. Request a new password reset email.');
      }
      setChecking(false);
    };

    void initializeRecovery();
    return () => {
      active = false;
      authListener.subscription.unsubscribe();
    };
  }, []);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!recoveryReady) {
      setErrorMessage('Verify your password reset link before choosing a new password.');
      return;
    }
    if (!validation.isValid) {
      setErrorMessage(validation.errors[0] || 'Choose a stronger password.');
      return;
    }
    if (!passwordsMatch) {
      setErrorMessage('The password confirmation does not match.');
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;

      setSuccessMessage('Your password has been updated successfully. You can now sign in with your new password.');
      setPassword('');
      setConfirmPassword('');
      // End the recovery session so the link cannot be reused as an active session.
      await supabase.auth.signOut({ scope: 'local' });
      window.setTimeout(() => navigate('/login/member', { replace: true }), 1800);
    } catch (error: any) {
      setErrorMessage(error?.message || 'Unable to update your password. Request a new reset link and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
      <section className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-6 sm:p-8 shadow-2xl">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-600/15 text-blue-400">
          <KeyRound className="h-7 w-7" />
        </div>
        <div className="text-center">
          <h1 className="text-2xl font-bold">Set a New Password</h1>
          <p className="mt-2 text-sm text-slate-400">Choose a new secure password for your Church Management System account.</p>
        </div>

        {checking ? (
          <div role="status" className="mt-8 flex items-center justify-center gap-2 text-sm text-slate-300">
            <Loader2 className="h-5 w-5 animate-spin" /> Verifying your reset link…
          </div>
        ) : successMessage ? (
          <div role="status" className="mt-7 rounded-xl border border-emerald-800 bg-emerald-950/40 p-4 text-sm text-emerald-300">
            <CheckCircle2 className="mb-2 h-6 w-6" />
            {successMessage}
            <p className="mt-2 text-xs text-emerald-400">Redirecting to member login…</p>
          </div>
        ) : !recoveryReady ? (
          <div className="mt-7 space-y-4">
            <div role="alert" className="rounded-xl border border-rose-800 bg-rose-950/40 p-4 text-sm text-rose-300">
              <AlertCircle className="mb-2 h-5 w-5" />
              {errorMessage || 'The reset link could not be verified.'}
            </div>
            <button type="button" onClick={() => navigate('/forgot-password')} className="w-full rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-500">
              Request a New Reset Link
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-7 space-y-5">
            <div>
              <label htmlFor="recovery-password" className="mb-2 block text-sm font-medium text-slate-200">New password</label>
              <div className="relative">
                <input id="recovery-password" type={showPassword ? 'text' : 'password'} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 pr-12 text-sm text-white outline-none focus:border-blue-500" placeholder="Enter your new password" />
                <button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? 'Hide password' : 'Show password'} className="absolute right-3 top-3 text-slate-400">
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
              {password && (
                <ul className="mt-2 space-y-1 text-xs text-slate-400">
                  <li className={validation.requirements.minLength ? 'text-emerald-400' : ''}>{validation.requirements.minLength ? '✓' : '○'} At least 8 characters</li>
                  <li className={validation.requirements.hasUppercase && validation.requirements.hasLowercase ? 'text-emerald-400' : ''}>{validation.requirements.hasUppercase && validation.requirements.hasLowercase ? '✓' : '○'} Uppercase and lowercase letters</li>
                  <li className={validation.requirements.hasNumber ? 'text-emerald-400' : ''}>{validation.requirements.hasNumber ? '✓' : '○'} At least one number</li>
                  <li className={validation.requirements.hasSymbol ? 'text-emerald-400' : ''}>{validation.requirements.hasSymbol ? '✓' : '○'} At least one special character</li>
                  <li className={validation.requirements.notCommonOrLeaked ? 'text-emerald-400' : ''}>{validation.requirements.notCommonOrLeaked ? '✓' : '○'} Not a commonly compromised password</li>
                </ul>
              )}
            </div>
            <div>
              <label htmlFor="recovery-confirm-password" className="mb-2 block text-sm font-medium text-slate-200">Confirm new password</label>
              <div className="relative">
                <input id="recovery-confirm-password" type={showConfirm ? 'text' : 'password'} autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 pr-12 text-sm text-white outline-none focus:border-blue-500" placeholder="Confirm your new password" />
                <button type="button" onClick={() => setShowConfirm((value) => !value)} aria-label={showConfirm ? 'Hide confirmation' : 'Show confirmation'} className="absolute right-3 top-3 text-slate-400">
                  {showConfirm ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>
            {errorMessage && <p role="alert" className="rounded-lg border border-rose-800 bg-rose-950/40 p-3 text-sm text-rose-300">{errorMessage}</p>}
            <button type="submit" disabled={submitting || !validation.isValid || !passwordsMatch} className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              {submitting ? 'Updating password…' : 'Update Password'}
            </button>
          </form>
        )}
        <div className="mt-7 border-t border-slate-800 pt-4 text-center">
          <button type="button" onClick={() => navigate('/login/member')} className="text-sm text-slate-400 hover:text-white">Back to Member Login</button>
        </div>
      </section>
    </main>
  );
};
