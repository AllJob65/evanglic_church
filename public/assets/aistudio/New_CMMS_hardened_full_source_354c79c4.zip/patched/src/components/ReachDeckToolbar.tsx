import React, { useState, useEffect } from 'react';
import { reachDeck, ReachDeckSettings } from '../services/reachdeck';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  Square,
  FastForward,
  Sparkles,
  Sliders,
  Maximize2,
  Eye,
  Glasses,
  FileAudio,
  Check,
  ChevronDown,
  X,
  HelpCircle,
  Headphones,
  MousePointerClick,
  Smartphone
} from 'lucide-react';

interface ReachDeckToolbarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReachDeckToolbar: React.FC<ReachDeckToolbarProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<ReachDeckSettings>(reachDeck.getSettings());
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentWord, setCurrentWord] = useState('');
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  useEffect(() => {
    const unsubscribe = reachDeck.subscribe((state) => {
      setIsSpeaking(state.isSpeaking);
      setIsPaused(state.isPaused);
      setCurrentWord(state.currentWord);
    });

    setVoices(reachDeck.getVoices());
    const interval = setInterval(() => {
      const v = reachDeck.getVoices();
      if (v.length > 0) {
        setVoices(v);
        clearInterval(interval);
      }
    }, 500);

    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, []);
useEffect(() => {
  const handleKeyboardShortcuts = (event: KeyboardEvent) => {
    // Alt + R = Start Reading
    if (event.altKey && event.key.toLowerCase() === 'r') {
      event.preventDefault();

      const selectedText = window.getSelection()?.toString().trim();

      if (selectedText) {
        reachDeck.speak(selectedText);
      } else {
        reachDeck.speakSelection();
      }
    }

    // Alt + X = Stop Reading
    if (event.altKey && event.key.toLowerCase() === 'x') {
      event.preventDefault();
      reachDeck.stop();
    }
  };

  window.addEventListener('keydown', handleKeyboardShortcuts);

  return () => {
    window.removeEventListener('keydown', handleKeyboardShortcuts);
  };
}, []);
  // Hover to speak event listener
// Hover-to-Speak is intentionally disabled by default.
// Reading only starts when the user clicks Listen or uses a keyboard shortcut.
useEffect(() => {
  if (!settings.hoverToSpeak) return;

  let hoverTimeout: ReturnType<typeof setTimeout> | null = null;

  const handleMouseOver = (e: MouseEvent) => {
    const target = e.target as HTMLElement;
    if (!target) return;

    if (target.closest('#reachdeck-toolbar-container')) return;

    const text = target.innerText?.trim();

    if (text && text.length > 2 && text.length < 200) {
      if (hoverTimeout) {
        clearTimeout(hoverTimeout);
      }

      hoverTimeout = setTimeout(() => {
        reachDeck.speak(text);
      }, 400);
    }
  };

  const handleMouseOut = () => {
    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
      hoverTimeout = null;
    }
  };

  document.addEventListener('mouseover', handleMouseOver);
  document.addEventListener('mouseout', handleMouseOut);

  return () => {
    document.removeEventListener('mouseover', handleMouseOver);
    document.removeEventListener('mouseout', handleMouseOut);

    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
    }
  };
}, [settings.hoverToSpeak]);

  const updateSetting = <K extends keyof ReachDeckSettings>(key: K, value: ReachDeckSettings[K]) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    reachDeck.saveSettings({ [key]: value });
  };

  const handlePlay = () => {
    if (isPaused) {
      reachDeck.resume();
    } else {
      reachDeck.speakSelection();
    }
  };

  const handlePause = () => {
    reachDeck.pause();
  };

  const handleStop = () => {
    reachDeck.stop();
  };

  const handleAudioDownload = async () => {
    const content = reachDeck.extractPageContent();
    const dataUrl = await reachDeck.generateAudioDownload(content);
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `ReachDeck_Page_Audio_${new Date().toISOString().slice(0, 10)}.mp3`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  if (!isOpen) return null;

  return (
    <div
      id="reachdeck-toolbar-container"
      role="region"
      aria-label="ReachDeck Digital Inclusion and Text-to-Speech Toolbar"
      className="fixed top-16 left-1/2 -translate-x-1/2 z-50 max-w-4xl w-[95%] bg-slate-900/95 backdrop-blur-md text-white px-4 py-2.5 rounded-2xl shadow-2xl border border-indigo-500/40 animate-in fade-in slide-in-from-top-4 duration-200"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* ReachDeck Brand & Status */}
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs">
            <Headphones className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-xs tracking-wider text-indigo-300 uppercase">ReachDeck</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-950 text-indigo-200 font-mono border border-indigo-800">
                TTS Voice Engine
              </span>
            </div>
            {currentWord ? (
              <p className="text-[11px] text-amber-300 font-semibold truncate max-w-[140px] sm:max-w-[200px]">
                "{currentWord}"
              </p>
            ) : (
              <p className="text-[10px] text-slate-400">Page Reader Ready</p>
            )}
          </div>
        </div>

        {/* Primary Playback Controls */}
        <div className="flex items-center gap-1.5 bg-slate-800/80 p-1 rounded-xl border border-slate-700">
          {!isSpeaking || isPaused ? (
            <button
              onClick={handlePlay}
              aria-label="Play text-to-speech audio"
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isPaused ? 'Resume' : 'Listen'}</span>
            </button>
          ) : (
            <button
              onClick={handlePause}
              aria-label="Pause text-to-speech audio"
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5 fill-current" />
              <span>Pause</span>
            </button>
          )}

          <button
            onClick={handleStop}
            aria-label="Stop audio reading"
            disabled={!isSpeaking && !isPaused}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-700/60 rounded-lg disabled:opacity-30 transition-all cursor-pointer"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
          </button>
        </div>

        {/* Secondary Inclusion Features */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Touch-to-Read (Mobile/Tablet) Toggle */}
          <button
            onClick={() => updateSetting('touchToSpeak', !settings.touchToSpeak)}
            title="Touch-to-Read: Tap any part of the page to read aloud"
            aria-pressed={settings.touchToSpeak}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
              settings.touchToSpeak
                ? 'bg-emerald-600/30 text-emerald-300 border-emerald-400'
                : 'border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Touch Read</span>
          </button>

          {/* Hover to Speak Toggle */}
          <button
            onClick={() => updateSetting('hoverToSpeak', !settings.hoverToSpeak)}
            title="Hover-to-Speak: Point cursor at any text to read aloud"
            aria-pressed={settings.hoverToSpeak}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
              settings.hoverToSpeak
                ? 'bg-blue-600/30 text-blue-300 border-blue-400'
                : 'border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <MousePointerClick className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Hover Speak</span>
          </button>

          {/* Reading Ruler Toggle */}
          <button
            onClick={() => updateSetting('readingRuler', !settings.readingRuler)}
            title="Dyslexia Reading Ruler"
            aria-pressed={settings.readingRuler}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
              settings.readingRuler
                ? 'bg-yellow-500/30 text-yellow-300 border-yellow-400'
                : 'border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Glasses className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Reading Ruler</span>
          </button>

          {/* Screen Mask */}
          <button
            onClick={() => updateSetting('screenMask', !settings.screenMask)}
            title="Screen Focus Mask"
            aria-pressed={settings.screenMask}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
              settings.screenMask
                ? 'bg-purple-600/30 text-purple-300 border-purple-400'
                : 'border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Screen Mask</span>
          </button>

          {/* Audio MP3 Export */}
          <button
            onClick={handleAudioDownload}
            title="Download Audio File of Current Page"
            className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition-all cursor-pointer"
          >
            {downloadSuccess ? <Check className="w-4 h-4 text-emerald-400" /> : <FileAudio className="w-4 h-4" />}
          </button>

          {/* Voice & Speed Settings Toggle */}
          <button
            onClick={() => setIsSettingsOpen(!isSettingsOpen)}
            aria-label="ReachDeck voice rate and pitch settings"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all cursor-pointer"
          >
            <Sliders className="w-4 h-4" />
          </button>

          {/* Close Toolbar */}
          <button
            onClick={onClose}
            aria-label="Close ReachDeck toolbar"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all ml-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expanded Voice & Rate Settings Drawer */}
      {isSettingsOpen && (
        <div className="mt-3 pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          {/* Voice Selector */}
          <div>
            <label className="text-[11px] font-bold text-slate-400 block mb-1">
              Select Voice & Language
            </label>
            <select
              value={settings.voiceUri}
              onChange={(e) => updateSetting('voiceUri', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">Default System Natural Voice</option>
              {voices.map((v) => (
                <option key={v.voiceURI} value={v.voiceURI}>
                  {v.name} ({v.lang})
                </option>
              ))}
            </select>
          </div>

          {/* Reading Speed Slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[11px] font-bold text-slate-400">
                Speech Speed ({settings.rate}x)
              </label>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.8"
              step="0.1"
              value={settings.rate}
              onChange={(e) => updateSetting('rate', parseFloat(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          {/* Speech Pitch Slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[11px] font-bold text-slate-400">
                Pitch ({settings.pitch}x)
              </label>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.5"
              step="0.1"
              value={settings.pitch}
              onChange={(e) => updateSetting('pitch', parseFloat(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
