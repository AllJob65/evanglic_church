import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Cake,
  Heart,
  Send,
  Sparkles,
  CheckCircle,
  Calendar,
  Phone,
  MessageSquare,
  Clock,
  Mail,
  User,
  Users,
  Search,
} from 'lucide-react';

export const EventMessagingTab: React.FC = () => {
  const { members, sendCommunication, addAuditLog } = useCMMS();
  const [selectedEventType, setSelectedEventType] = useState<'birthdays' | 'anniversaries'>('birthdays');
  const [searchQuery, setSearchQuery] = useState('');
  const [customBlessingText, setCustomBlessingText] = useState('');
  const [activeChannel, setActiveChannel] = useState<'SMS' | 'Email' | 'WhatsApp'>('SMS');
  const [dispatchStatus, setDispatchStatus] = useState<string | null>(null);

  const today = new Date();
  const currentMonth = today.getMonth() + 1;
  const currentDay = today.getDate();

  // 1. Birthday Members
  const birthdayMembers = members
    .filter((m) => m.dateOfBirth)
    .map((m) => {
      const dob = new Date(m.dateOfBirth!);
      const dobMonth = dob.getMonth() + 1;
      const dobDay = dob.getDate();
      const isToday = dobMonth === currentMonth && dobDay === currentDay;
      const isThisMonth = dobMonth === currentMonth;
      const ageTurning = today.getFullYear() - dob.getFullYear();

      return {
        ...m,
        dobMonth,
        dobDay,
        isToday,
        isThisMonth,
        ageTurning: ageTurning > 0 ? ageTurning : 1,
      };
    })
    .sort((a, b) => {
      if (a.isToday && !b.isToday) return -1;
      if (!a.isToday && b.isToday) return 1;
      return a.dobDay - b.dobDay;
    });

  // 2. Wedding Anniversary Members (Married with marriageDate)
  const anniversaryMembers = members
    .filter((m) => m.maritalStatus === 'Married' && m.marriageDate)
    .map((m) => {
      const md = new Date(m.marriageDate!);
      const mdMonth = md.getMonth() + 1;
      const mdDay = md.getDate();
      const isToday = mdMonth === currentMonth && mdDay === currentDay;
      const isThisMonth = mdMonth === currentMonth;
      const yearsMarried = today.getFullYear() - md.getFullYear();

      return {
        ...m,
        anniversaryMonth: mdMonth,
        anniversaryDay: mdDay,
        isToday,
        isThisMonth,
        yearsMarried: yearsMarried > 0 ? yearsMarried : 1,
      };
    })
    .sort((a, b) => {
      if (a.isToday && !b.isToday) return -1;
      if (!a.isToday && b.isToday) return 1;
      return a.anniversaryDay - b.anniversaryDay;
    });

  const filteredBirthdays = birthdayMembers.filter(
    (m) =>
      `${m.firstName} ${m.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.primaryPhone.includes(searchQuery)
  );

  const filteredAnniversaries = anniversaryMembers.filter(
    (m) =>
      `${m.firstName} ${m.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.spouseName && m.spouseName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      m.primaryPhone.includes(searchQuery)
  );

  const handleSendBirthdayGreeting = (m: typeof birthdayMembers[0]) => {
    const greeting =
      customBlessingText ||
      `መልካም ልደት ${m.title} ${m.firstName}! Happy Birthday from Grace Cathedral. "The Lord bless you and keep you" (Numbers 6:24). We rejoice with you on your ${m.ageTurning}th birthday!`;

    sendCommunication({
      id: `comm-bday-${Date.now()}`,
      senderRole: 'Pastoral Office',
      channel: activeChannel,
      targetAudience: `${m.firstName} ${m.lastName} (${m.primaryPhone})`,
      subject: `Birthday Blessings for ${m.firstName}! 🎂`,
      body: greeting,
      status: 'Sent',
      recipientCount: 1,
      deliveryStats: { sent: 1, delivered: 1, opened: 1, failed: 0 },
      sentAt: new Date().toISOString(),
    });

    addAuditLog(
      'Sent Birthday Greeting',
      'Automated Event Messaging',
      `Sent ${activeChannel} birthday blessing to ${m.firstName} ${m.lastName} (${m.primaryPhone})`
    );

    setDispatchStatus(`Successfully dispatched birthday blessing to ${m.firstName} ${m.lastName}!`);
    setTimeout(() => setDispatchStatus(null), 3500);
  };

  const handleSendAnniversaryGreeting = (m: typeof anniversaryMembers[0]) => {
    const spouse = m.spouseName || 'Spouse';
    const greeting =
      customBlessingText ||
      `Happy ${m.yearsMarried}th Wedding Anniversary to ${m.firstName} and ${spouse}! "What God has joined together, let no one separate" (Mark 10:9). Grace Cathedral prays for God's everlasting love over your marriage!`;

    sendCommunication({
      id: `comm-anniv-${Date.now()}`,
      senderRole: 'Pastoral Office',
      channel: activeChannel,
      targetAudience: `${m.firstName} & ${spouse} (${m.primaryPhone})`,
      subject: `Happy Wedding Anniversary to ${m.firstName} & ${spouse}! 💍`,
      body: greeting,
      status: 'Sent',
      recipientCount: m.spousePhone ? 2 : 1,
      deliveryStats: { sent: m.spousePhone ? 2 : 1, delivered: m.spousePhone ? 2 : 1, opened: 1, failed: 0 },
      sentAt: new Date().toISOString(),
    });

    addAuditLog(
      'Sent Anniversary Wish',
      'Automated Event Messaging',
      `Sent wedding anniversary wishes to ${m.firstName} & ${spouse} (Phone: ${m.primaryPhone}${m.spousePhone ? `, Spouse Phone: ${m.spousePhone}` : ''})`
    );

    setDispatchStatus(`Successfully dispatched anniversary wishes to ${m.firstName} & ${spouse}!`);
    setTimeout(() => setDispatchStatus(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-blue-500/10 dark:from-pink-950/40 dark:to-blue-950/40 border border-pink-200 dark:border-pink-900 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-pink-600 dark:text-pink-400" />
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Automated Event & Milestone Messaging Engine
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Send personalized birthday wishes and wedding anniversary greetings with automatic spouse mapping.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSelectedEventType('birthdays')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              selectedEventType === 'birthdays'
                ? 'bg-pink-600 text-white shadow-md shadow-pink-500/20'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Cake className="w-4 h-4" /> Member Birthdays ({birthdayMembers.filter((b) => b.isToday).length} Today)
          </button>
          <button
            onClick={() => setSelectedEventType('anniversaries')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              selectedEventType === 'anniversaries'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            <Heart className="w-4 h-4" /> Wedding Anniversaries ({anniversaryMembers.filter((a) => a.isToday).length} Today)
          </button>
        </div>
      </div>

      {dispatchStatus && (
        <div className="p-3.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          {dispatchStatus}
        </div>
      )}

      {/* Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search member name, spouse, or phone..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="font-semibold text-slate-500">Dispatch Channel:</span>
          {(['SMS', 'Email', 'WhatsApp'] as const).map((ch) => (
            <button
              key={ch}
              onClick={() => setActiveChannel(ch)}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                activeChannel === ch
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {ch}
            </button>
          ))}
        </div>
      </div>

      {/* TAB CONTENT: BIRTHDAYS */}
      {selectedEventType === 'birthdays' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredBirthdays.map((m) => (
              <div
                key={m.id}
                className={`p-4 rounded-2xl border transition-all ${
                  m.isToday
                    ? 'bg-pink-50/70 dark:bg-pink-950/30 border-pink-300 dark:border-pink-800 shadow-md ring-2 ring-pink-400/30'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img src={m.photoUrl} alt="" className="w-11 h-11 rounded-xl object-cover" />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white">
                          {m.title} {m.firstName} {m.lastName}
                        </h4>
                        {m.isToday && (
                          <span className="px-1.5 py-0.5 rounded-full text-[9px] font-extrabold bg-pink-500 text-white animate-pulse">
                            TODAY! 🎂
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">{m.primaryPhone}</p>
                      <p className="text-[10px] text-pink-600 dark:text-pink-400 font-semibold">
                        Turning {m.ageTurning} years old ({m.dateOfBirth})
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Status: <span className="font-semibold text-slate-700 dark:text-slate-300">{m.maritalStatus}</span>
                  </span>
                  <button
                    onClick={() => handleSendBirthdayGreeting(m)}
                    className="px-3 py-1.5 bg-pink-600 hover:bg-pink-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                  >
                    <Send className="w-3 h-3" /> Send Birthday Wish
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: WEDDING ANNIVERSARIES */}
      {selectedEventType === 'anniversaries' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAnniversaries.map((m) => (
              <div
                key={m.id}
                className={`p-4 rounded-2xl border transition-all ${
                  m.isToday
                    ? 'bg-purple-50/70 dark:bg-purple-950/30 border-purple-300 dark:border-purple-800 shadow-md ring-2 ring-purple-400/30'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img src={m.photoUrl} alt="" className="w-11 h-11 rounded-xl object-cover" />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white">
                          {m.firstName} & {m.spouseName || 'Spouse'}
                        </h4>
                        {m.isToday && (
                          <span className="px-1.5 py-0.5 rounded-full text-[9px] font-extrabold bg-purple-600 text-white animate-pulse">
                            ANNIVERSARY! 💍
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                        {m.primaryPhone} {m.spousePhone ? `• Spouse: ${m.spousePhone}` : ''}
                      </p>
                      <p className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold">
                        Celebrating {m.yearsMarried} Years of Marriage (Married {m.marriageDate})
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Spouse Mapped: <span className="font-semibold text-slate-700 dark:text-slate-300">{m.spouseName || 'Yes'}</span>
                  </span>
                  <button
                    onClick={() => handleSendAnniversaryGreeting(m)}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                  >
                    <Send className="w-3 h-3" /> Send Couple Blessing
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
