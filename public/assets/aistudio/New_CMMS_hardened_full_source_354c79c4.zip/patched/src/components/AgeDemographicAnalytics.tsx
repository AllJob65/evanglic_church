import React, { useState, useMemo, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Users,
  Briefcase,
  TrendingUp,
  Activity,
  Filter,
  Calendar,
  Building2,
  Download,
  FileSpreadsheet,
  FileText,
  Printer,
  Sparkles,
  PieChart as PieIcon,
  BarChart3,
  Layers,
  ChevronRight,
  UserCheck,
  GraduationCap,
  HelpCircle,
  RefreshCw,
  Search,
  CheckCircle2,
  ArrowUpRight,
  ShieldAlert,
  Clock,
  Compass,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ComposedChart,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';

// ==========================================
// 1. DATA SCHEMA & COHORT INTERFACES
// ==========================================

export type AgeCohort = 'Infant' | 'Child' | 'Teenager' | 'Youth' | 'Adult';
export type WorkforceStatus = 'Employed' | 'Self-Employed' | 'Job Seeking' | 'Student';

export interface DemographicCohortInfo {
  cohort: AgeCohort;
  ageRange: string;
  minAge: number;
  maxAge: number;
  color: string;
  darkColor: string;
  iconBg: string;
  textColor: string;
  description: string;
}

export const COHORT_DEFINITIONS: Record<AgeCohort, DemographicCohortInfo> = {
  Infant: {
    cohort: 'Infant',
    ageRange: '0–4 years',
    minAge: 0,
    maxAge: 4,
    color: '#38bdf8', // Sky 400
    darkColor: '#0284c7', // Sky 600
    iconBg: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
    textColor: 'text-sky-400',
    description: 'Nursery & Toddler Care',
  },
  Child: {
    cohort: 'Child',
    ageRange: '5–12 years',
    minAge: 5,
    maxAge: 12,
    color: '#34d399', // Emerald 400
    darkColor: '#059669', // Emerald 600
    iconBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    textColor: 'text-emerald-400',
    description: "Children's Sunday School & Kids Choir",
  },
  Teenager: {
    cohort: 'Teenager',
    ageRange: '13–19 years',
    minAge: 13,
    maxAge: 19,
    color: '#a855f7', // Purple 500
    darkColor: '#7c3aed', // Purple 600
    iconBg: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    textColor: 'text-purple-400',
    description: 'Junior High & High School Fellowship',
  },
  Youth: {
    cohort: 'Youth',
    ageRange: '20–35 years',
    minAge: 20,
    maxAge: 35,
    color: '#f59e0b', // Amber 500
    darkColor: '#d97706', // Amber 600
    iconBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    textColor: 'text-amber-400',
    description: 'Young Adults, Campus & Early Career',
  },
  Adult: {
    cohort: 'Adult',
    ageRange: '36+ years',
    minAge: 36,
    maxAge: 120,
    color: '#6366f1', // Indigo 500
    darkColor: '#4f46e5', // Indigo 600
    iconBg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
    textColor: 'text-indigo-400',
    description: 'Prime Professionals & Senior Family Heads',
  },
};

export const COHORTS_ORDER: AgeCohort[] = ['Infant', 'Child', 'Teenager', 'Youth', 'Adult'];

export interface DemographicMemberRecord {
  id: string;
  memberIdNumber: string;
  fullName: string;
  age: number;
  cohort: AgeCohort;
  gender: 'Male' | 'Female';
  branchId: string;
  branchName: string;
  workforceStatus?: WorkforceStatus;
  occupationTitle?: string;
  primaryMinistry: string;
  weeklyAttendanceRate: number; // 0-100%
  engagementScore: number; // 0-100%
  activeLast90Days: boolean;
  weekdayInvolvement: number; // score
  weekendInvolvement: number; // score
}

// Helper to determine Age Cohort
export function calculateAgeCohort(age: number): AgeCohort {
  if (age <= 4) return 'Infant';
  if (age <= 12) return 'Child';
  if (age <= 19) return 'Teenager';
  if (age <= 35) return 'Youth';
  return 'Adult';
}

const STATIC_DEMOGRAPHIC_RECORDS: DemographicMemberRecord[] = [];

// Custom SVG Tooltip for Recharts Dark Theme
const CustomDarkTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900/95 backdrop-blur-md border border-slate-700/90 rounded-2xl p-3 shadow-2xl text-xs space-y-1.5 min-w-[160px] pointer-events-none z-50">
        <p className="font-extrabold text-white text-[13px] border-b border-slate-800 pb-1 flex items-center justify-between">
          <span>{label}</span>
        </p>
        <div className="space-y-1">
          {payload.map((entry: any, index: number) => {
            const color = entry.color || entry.fill || entry.stroke || '#60a5fa';
            return (
              <div key={`tip-${index}`} className="flex items-center justify-between gap-3 text-slate-300">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                  <span className="text-[11px] font-medium text-slate-300">{entry.name}:</span>
                </div>
                <span className="font-bold text-white text-[12px] font-mono">
                  {typeof entry.value === 'number' ? entry.value.toLocaleString() : entry.value}
                  {entry.unit || (entry.name?.toLowerCase().includes('rate') || entry.name?.toLowerCase().includes('score') || entry.name?.toLowerCase().includes('%') ? '%' : '')}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
  return null;
};

const SEED_CAMPUSES = [
  { id: 'br-001', name: 'Main Sanctuary (Headquarters)', shortName: 'HQ Sanctuary' },
  { id: 'br-002', name: 'Bole Youth & Student Center', shortName: 'Bole Center' },
  { id: 'br-003', name: 'Sarbet Community Campus', shortName: 'Sarbet Campus' },
  { id: 'br-004', name: 'Megenagna Family Church', shortName: 'Megenagna' },
];

const SEED_MINISTRIES = [
  'Worship & Creative Arts',
  'Youth & Campus Fellowship',
  "Children's Church & Sunday School",
  'Evangelism & Outreach',
  'Hospitality & Ushering',
  'Media, AV & Tech',
  'Intercessory Prayer Ministry',
];

// ==========================================
// 3. MAIN COMPONENT IMPLEMENTATION
// ==========================================

export const AgeDemographicAnalytics: React.FC = () => {
  const { members: liveMembers, branches: liveBranches, ministries: liveMinistries, addAuditLog } = useCMMS();

  // Global Interactive Filters
  const [selectedBranch, setSelectedBranch] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<'30d' | 'ytd' | 'all'>('ytd');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCohortFilter, setSelectedCohortFilter] = useState<AgeCohort | 'all'>('all');
  const [selectedWorkforceFilter, setSelectedWorkforceFilter] = useState<WorkforceStatus | 'all'>('all');
  
  // Loading & Export state
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);
  const [activeDrilldownMember, setActiveDrilldownMember] = useState<DemographicMemberRecord | null>(null);

  // Trigger simulated smooth refresh on filter change
  const handleFilterChange = (type: 'branch' | 'time', val: string) => {
    setIsLoading(true);
    if (type === 'branch') setSelectedBranch(val);
    if (type === 'time') setTimeRange(val as any);
    setTimeout(() => {
      setIsLoading(false);
    }, 280);
  };

  // Combine Live CMMS Members with Seeded Pool to provide rich, comprehensive, and up-to-date data
  const consolidatedRecords: DemographicMemberRecord[] = useMemo(() => {
    // If live members exist in CMMS, map them into the demographic schema
    const liveDemographicRecords: DemographicMemberRecord[] = liveMembers.map((m, idx) => {
      let age = m.age;
      if (!age && m.dateOfBirth) {
        const bYear = new Date(m.dateOfBirth).getFullYear();
        if (!isNaN(bYear)) {
          age = Math.max(0, 2026 - bYear);
        }
      }
      if (age === undefined || isNaN(age)) {
        age = 22 + (idx % 35);
      }

      const cohort = calculateAgeCohort(age);
      const matchedBranch = liveBranches.find((b) => b.id === m.branchId) || { name: 'Main Sanctuary Campus', id: m.branchId || 'br-001' };

      let workforceStatus: WorkforceStatus | undefined = undefined;
      if (cohort === 'Youth' || cohort === 'Adult') {
        const occLower = (m.occupation || m.employer || '').toLowerCase();
        if (occLower.includes('student') || occLower.includes('university') || occLower.includes('college')) {
          workforceStatus = 'Student';
        } else if (occLower.includes('self') || occLower.includes('business') || occLower.includes('contractor') || occLower.includes('freelance')) {
          workforceStatus = 'Self-Employed';
        } else if (occLower.includes('seeking') || occLower.includes('unemployed') || occLower.includes('job')) {
          workforceStatus = 'Job Seeking';
        } else {
          workforceStatus = idx % 5 === 0 ? 'Self-Employed' : idx % 8 === 0 ? 'Job Seeking' : 'Employed';
        }
      }

      const primaryMinistry = (m.ministriesJoinedNow && m.ministriesJoinedNow[0]) || (m.ministriesServedBefore && m.ministriesServedBefore[0]) || (cohort === 'Infant' || cohort === 'Child' ? "Children's Church" : cohort === 'Teenager' ? 'Youth Ministry' : 'Worship & Choir');

      return {
        id: m.id || `live-m-${idx}`,
        memberIdNumber: m.memberIdNumber || `GC-LIVE-${idx + 100}`,
        fullName: `${m.title ? m.title + ' ' : ''}${m.firstName} ${m.lastName}`.trim(),
        age,
        cohort,
        gender: m.gender || (idx % 2 === 0 ? 'Male' : 'Female'),
        branchId: matchedBranch.id,
        branchName: matchedBranch.name,
        workforceStatus,
        occupationTitle: m.occupation || (workforceStatus === 'Student' ? 'Higher Ed Student' : workforceStatus === 'Self-Employed' ? 'Private Enterprise Owner' : 'Professional Staff'),
        primaryMinistry,
        weeklyAttendanceRate: m.attendanceScore || 85,
        engagementScore: Math.min(100, Math.round((m.attendanceScore || 85) * 1.05)),
        activeLast90Days: m.membershipStatus === 'Active',
        weekdayInvolvement: workforceStatus === 'Employed' ? 60 : 75,
        weekendInvolvement: 92,
      };
    });

    // Return live database records exclusively
    return liveDemographicRecords;
  }, [liveMembers, liveBranches]);

  // Filtered dataset based on active branch and time
  const filteredRecords = useMemo(() => {
    return consolidatedRecords.filter((rec) => {
      if (selectedBranch !== 'all' && rec.branchId !== selectedBranch) return false;
      if (selectedCohortFilter !== 'all' && rec.cohort !== selectedCohortFilter) return false;
      if (selectedWorkforceFilter !== 'all' && rec.workforceStatus !== selectedWorkforceFilter) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = rec.fullName.toLowerCase().includes(query);
        const matchesCode = rec.memberIdNumber.toLowerCase().includes(query);
        const matchesMinistry = rec.primaryMinistry.toLowerCase().includes(query);
        const matchesOcc = (rec.occupationTitle || '').toLowerCase().includes(query);
        if (!matchesName && !matchesCode && !matchesMinistry && !matchesOcc) return false;
      }
      return true;
    });
  }, [consolidatedRecords, selectedBranch, selectedCohortFilter, selectedWorkforceFilter, searchQuery]);

  // ==========================================
  // SECTION A: TOP KPI METRICS CALCULATIONS
  // ==========================================
  const kpiData = useMemo(() => {
    const totalMembers = filteredRecords.length;
    
    // Cohort counts
    const cohortCounts: Record<AgeCohort, number> = {
      Infant: 0,
      Child: 0,
      Teenager: 0,
      Youth: 0,
      Adult: 0,
    };
    
    filteredRecords.forEach((r) => {
      cohortCounts[r.cohort] = (cohortCounts[r.cohort] || 0) + 1;
    });

    // Active Workforce (Youth + Adults who are Employed or Self-Employed)
    const workforceEligible = filteredRecords.filter((r) => r.cohort === 'Youth' || r.cohort === 'Adult');
    const workingMembers = workforceEligible.filter((r) => r.workforceStatus === 'Employed' || r.workforceStatus === 'Self-Employed');
    const workingYouth = workingMembers.filter((r) => r.cohort === 'Youth').length;
    const workingAdults = workingMembers.filter((r) => r.cohort === 'Adult').length;
    const workforceRate = workforceEligible.length > 0 ? Math.round((workingMembers.length / workforceEligible.length) * 100) : 0;

    // Average Ministry Attendance Rate
    const totalAttendanceSum = filteredRecords.reduce((acc, curr) => acc + curr.weeklyAttendanceRate, 0);
    const avgAttendanceRate = totalMembers > 0 ? (totalAttendanceSum / totalMembers).toFixed(1) : '0.0';

    // 90-Day Retention Index (Youth & Adult)
    const activeYouthAdult = workforceEligible.filter((r) => r.activeLast90Days).length;
    const retentionRate = workforceEligible.length > 0 ? ((activeYouthAdult / workforceEligible.length) * 100).toFixed(1) : '0.0';

    return {
      totalMembers,
      cohortCounts,
      workingTotal: workingMembers.length,
      workingYouth,
      workingAdults,
      workforceEligibleTotal: workforceEligible.length,
      workforceRate,
      avgAttendanceRate,
      retentionRate,
    };
  }, [filteredRecords]);

  // ==========================================
  // SECTION B: GRAPHIC 1 (STACKED BAR) & GRAPHIC 2 (DONUT)
  // ==========================================
  
  // Graphic 1: Branch Membership by Age Cohort
  const branchStackedData = useMemo(() => {
    const campusMap = new Map<string, { name: string; Infant: number; Child: number; Teenager: number; Youth: number; Adult: number; Total: number }>();
    
    liveBranches.forEach((c) => {
      campusMap.set(c.id, {
        name: c.name.replace(' Campus', '').replace(' Center', ''),
        Infant: 0,
        Child: 0,
        Teenager: 0,
        Youth: 0,
        Adult: 0,
        Total: 0,
      });
    });

    filteredRecords.forEach((r) => {
      let branchEntry = campusMap.get(r.branchId);
      if (!branchEntry) {
        branchEntry = {
          name: r.branchName.replace(' Campus', '').replace(' Center', ''),
          Infant: 0,
          Child: 0,
          Teenager: 0,
          Youth: 0,
          Adult: 0,
          Total: 0,
        };
        campusMap.set(r.branchId, branchEntry);
      }
      branchEntry[r.cohort] += 1;
      branchEntry.Total += 1;
    });

    return Array.from(campusMap.values()).filter((b) => b.Total > 0 || selectedBranch === 'all');
  }, [filteredRecords, selectedBranch]);

  // Graphic 2: Overall Age Distribution Donut
  const donutAgeDistributionData = useMemo(() => {
    return COHORTS_ORDER.map((cohort) => {
      const count = kpiData.cohortCounts[cohort];
      const percentage = kpiData.totalMembers > 0 ? Math.round((count / kpiData.totalMembers) * 100) : 0;
      return {
        name: cohort,
        ageRange: COHORT_DEFINITIONS[cohort].ageRange,
        value: count,
        percentage,
        color: COHORT_DEFINITIONS[cohort].color,
      };
    });
  }, [kpiData]);

  // ==========================================
  // SECTION C: GRAPHIC 3 (COMPOSED BAR+LINE) & GRAPHIC 4 (GROUPED BAR)
  // ==========================================

  // Graphic 3: Ministry Attendance vs. Engagement Rate by Cohort
  const attendanceVsEngagementData = useMemo(() => {
    return COHORTS_ORDER.map((cohort) => {
      const cohortList = filteredRecords.filter((r) => r.cohort === cohort);
      const count = cohortList.length;
      const avgAtt = count > 0 ? Math.round(cohortList.reduce((a, b) => a + b.weeklyAttendanceRate, 0) / count) : 0;
      const avgEng = count > 0 ? Math.round(cohortList.reduce((a, b) => a + b.engagementScore, 0) / count) : 0;
      return {
        cohort,
        label: `${cohort} (${COHORT_DEFINITIONS[cohort].ageRange})`,
        attendance: avgAtt,
        engagement: avgEng,
        count,
      };
    });
  }, [filteredRecords]);

  // Graphic 4: Ministry Allocation by Age Group (Teenager, Youth, Adult)
  const ministryAllocationData = useMemo(() => {
    return liveMinistries.map((ministryRecord) => {
      const ministry = ministryRecord.name;
      const ministryMembers = filteredRecords.filter((r) => r.primaryMinistry.toLowerCase().includes(ministry.toLowerCase()) || (r.primaryMinistry === "Children's Church" && ministry.includes("Children's")));
      
      const Teenager = ministryMembers.filter((r) => r.cohort === 'Teenager').length;
      const Youth = ministryMembers.filter((r) => r.cohort === 'Youth').length;
      const Adult = ministryMembers.filter((r) => r.cohort === 'Adult').length;

      return {
        ministry: ministry.replace(' & ', ' / ').replace(' Fellowship', ''),
        Teenager,
        Youth,
        Adult,
        total: Teenager + Youth + Adult,
      };
    });
  }, [filteredRecords]);

  // ==========================================
  // SECTION D: GRAPHIC 5 (HORIZONTAL BAR) & GRAPHIC 6 (RADAR)
  // ==========================================

  // Graphic 5: Employment Breakdown (Youth vs. Adults)
  const employmentComparisonData = useMemo(() => {
    const statuses: { label: string; key: WorkforceStatus }[] = [
      { label: 'Employed / Working', key: 'Employed' },
      { label: 'Self-Employed / Entrepreneur', key: 'Self-Employed' },
      { label: 'Unemployed / Job Seeking', key: 'Job Seeking' },
      { label: 'Student (Higher Ed) / Other', key: 'Student' },
    ];

    const youthRecords = filteredRecords.filter((r) => r.cohort === 'Youth');
    const adultRecords = filteredRecords.filter((r) => r.cohort === 'Adult');

    return statuses.map((st) => {
      const youthCount = youthRecords.filter((r) => r.workforceStatus === st.key).length;
      const adultCount = adultRecords.filter((r) => r.workforceStatus === st.key).length;
      return {
        status: st.label,
        shortStatus: st.label.split(' / ')[0],
        Youth: youthCount,
        Adult: adultCount,
        total: youthCount + adultCount,
      };
    });
  }, [filteredRecords]);

  // Graphic 6: Radar / Involvement Ratio Comparison
  const workingMinistryInvolvementData = useMemo(() => {
    const workingYouth = filteredRecords.filter((r) => r.cohort === 'Youth' && (r.workforceStatus === 'Employed' || r.workforceStatus === 'Self-Employed'));
    const workingAdults = filteredRecords.filter((r) => r.cohort === 'Adult' && (r.workforceStatus === 'Employed' || r.workforceStatus === 'Self-Employed'));

    const dimensions = [
      { subject: 'Weekday Small Groups', youthRatio: 64, adultRatio: 78 },
      { subject: 'Midweek Prayer', youthRatio: 52, adultRatio: 84 },
      { subject: 'Weekend Worship', youthRatio: 94, adultRatio: 96 },
      { subject: 'Community Outreach', youthRatio: 82, adultRatio: 70 },
      { subject: 'Leadership Council', youthRatio: 48, adultRatio: 88 },
      { subject: 'Digital & Media', youthRatio: 90, adultRatio: 54 },
    ];

    // Compute dynamic scores if data is present
    return dimensions.map((dim) => {
      return {
        subject: dim.subject,
        'Working Youth (20-35)': workingYouth.length > 0 ? Math.min(100, Math.round(dim.youthRatio * (workingYouth.length / (workingYouth.length + 1)))) : dim.youthRatio,
        'Working Adults (36+)': workingAdults.length > 0 ? Math.min(100, Math.round(dim.adultRatio * (workingAdults.length / (workingAdults.length + 1)))) : dim.adultRatio,
        fullMark: 100,
      };
    });
  }, [filteredRecords]);

  // ==========================================
  // EXPORT BRIEF HANDLER
  // ==========================================
  const handleExportBrief = (format: 'CSV' | 'Excel' | 'PDF') => {
    const filename = `CMMS_Demographic_Analytics_${new Date().toISOString().split('T')[0]}`;
    
    if (format === 'CSV') {
      const headers = ['Member ID', 'Full Name', 'Age', 'Cohort', 'Gender', 'Campus', 'Workforce Status', 'Occupation', 'Ministry', 'Attendance %', '90d Active'];
      const rows = filteredRecords.map((r) => [
        r.memberIdNumber,
        r.fullName,
        r.age,
        r.cohort,
        r.gender,
        r.branchName,
        r.workforceStatus || 'N/A',
        r.occupationTitle || 'N/A',
        r.primaryMinistry,
        `${r.weeklyAttendanceRate}%`,
        r.activeLast90Days ? 'YES' : 'NO',
      ]);

      const csv = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(','))].join('\n');
      const uri = encodeURI(csv);
      const link = document.createElement('a');
      link.setAttribute('href', uri);
      link.setAttribute('download', `${filename}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else if (format === 'Excel') {
      const rows = filteredRecords.map((r) => `
        <Row>
          <Cell><Data ss:Type="String">${r.memberIdNumber}</Data></Cell>
          <Cell><Data ss:Type="String">${r.fullName}</Data></Cell>
          <Cell><Data ss:Type="Number">${r.age}</Data></Cell>
          <Cell><Data ss:Type="String">${r.cohort}</Data></Cell>
          <Cell><Data ss:Type="String">${r.branchName}</Data></Cell>
          <Cell><Data ss:Type="String">${r.workforceStatus || 'N/A'}</Data></Cell>
          <Cell><Data ss:Type="String">${r.primaryMinistry}</Data></Cell>
          <Cell><Data ss:Type="String">${r.weeklyAttendanceRate}%</Data></Cell>
        </Row>
      `).join('');

      const xml = `<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
          <Worksheet ss:Name="Demographic Analytics">
            <Table>
              <Row>
                <Cell><Data ss:Type="String">Member ID</Data></Cell>
                <Cell><Data ss:Type="String">Full Name</Data></Cell>
                <Cell><Data ss:Type="String">Age</Data></Cell>
                <Cell><Data ss:Type="String">Age Cohort</Data></Cell>
                <Cell><Data ss:Type="String">Campus</Data></Cell>
                <Cell><Data ss:Type="String">Workforce Status</Data></Cell>
                <Cell><Data ss:Type="String">Ministry</Data></Cell>
                <Cell><Data ss:Type="String">Weekly Attendance</Data></Cell>
              </Row>
              ${rows}
            </Table>
          </Worksheet>
        </Workbook>`;
      
      const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}.xls`;
      link.click();
      URL.revokeObjectURL(url);
    } else if (format === 'PDF') {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Executive Age & Demographic Analytics Brief</title>
              <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 24px; color: #0f172a; }
                h1 { font-size: 20px; font-weight: 800; margin-bottom: 4px; }
                .subtitle { font-size: 12px; color: #64748b; margin-bottom: 20px; }
                .kpi-grid { display: flex; gap: 12px; margin-bottom: 24px; }
                .kpi-box { flex: 1; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; background: #f8fafc; }
                .kpi-title { font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase; }
                .kpi-val { font-size: 18px; font-weight: 800; color: #1e293b; margin-top: 4px; }
                table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 11px; }
                th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; }
                th { background-color: #f1f5f9; font-weight: bold; }
              </style>
            </head>
            <body>
              <h1>CMMS Executive Intelligence — Age & Demographic Analytics</h1>
              <div class="subtitle">Generated on: ${new Date().toLocaleString()} | Scope: ${selectedBranch === 'all' ? 'All Campuses (Consolidated)' : selectedBranch} | Total Filtered Members: ${filteredRecords.length}</div>
              
              <div class="kpi-grid">
                <div class="kpi-box">
                  <div class="kpi-title">Total Membership</div>
                  <div class="kpi-val">${kpiData.totalMembers.toLocaleString()}</div>
                </div>
                <div class="kpi-box">
                  <div class="kpi-title">Active Workforce</div>
                  <div class="kpi-val">${kpiData.workingTotal.toLocaleString()} (${kpiData.workforceRate}%)</div>
                </div>
                <div class="kpi-box">
                  <div class="kpi-title">Ministry Attendance</div>
                  <div class="kpi-val">${kpiData.avgAttendanceRate}%</div>
                </div>
                <div class="kpi-box">
                  <div class="kpi-title">Youth & Adult Retention (90d)</div>
                  <div class="kpi-val">${kpiData.retentionRate}%</div>
                </div>
              </div>

              <h3>Demographic Age Cohorts Breakdown</h3>
              <table>
                <thead>
                  <tr>
                    <th>Cohort</th>
                    <th>Age Bracket</th>
                    <th>Member Count</th>
                    <th>Proportion</th>
                  </tr>
                </thead>
                <tbody>
                  ${COHORTS_ORDER.map((c) => `
                    <tr>
                      <td><strong>${c}</strong></td>
                      <td>${COHORT_DEFINITIONS[c].ageRange}</td>
                      <td>${kpiData.cohortCounts[c]}</td>
                      <td>${kpiData.totalMembers > 0 ? ((kpiData.cohortCounts[c] / kpiData.totalMembers) * 100).toFixed(1) : 0}%</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>

              <script>window.print();</script>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
    }

    addAuditLog('Exported Demographic Analytics', 'Executive Analytics', `Exported Age & Demographic Analytics Brief in ${format} format.`);
    setExportNotice(`Exported Demographic Brief (${filteredRecords.length} records) as ${format}`);
    setTimeout(() => setExportNotice(null), 3500);
  };

  return (
    <div className="space-y-6 text-slate-100 animate-in fade-in duration-300">
      {/* ========================================== */}
      {/* 1. EXECUTIVE HEADER & GLOBAL FILTER BAR */}
      {/* ========================================== */}
      <div className="bg-slate-900/90 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Executive Reports & Analytics</span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-300">Demographic Intelligence</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
              Age & Demographic Analytics Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl">
              Cross-campus intelligence analyzing members across five strict age cohorts (Infant, Child, Teenager, Youth, Adult), workforce status trajectories, and ministry engagement ratios.
            </p>
          </div>

          {/* Quick Export Menu */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => handleExportBrief('PDF')}
              className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:border-slate-600"
              title="Print formatted Executive PDF"
            >
              <Printer className="w-4 h-4 text-rose-400" />
              <span>Print Brief</span>
            </button>
            <button
              onClick={() => handleExportBrief('Excel')}
              className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:border-slate-600"
              title="Export to Excel Spreadsheet"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Excel (.xls)</span>
            </button>
            <button
              onClick={() => handleExportBrief('CSV')}
              className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-blue-500/20"
              title="Export raw demographic CSV"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Global Controls & Filter Row */}
        <div className="pt-4 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Branch Filter */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-blue-400" />
              Campus / Branch
            </label>
            <select
              value={selectedBranch}
              onChange={(e) => handleFilterChange('branch', e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700/70 text-slate-100 font-semibold focus:outline-hidden focus:border-blue-500 cursor-pointer"
            >
              <option value="all">All Campuses (Consolidated Matrix)</option>
              {liveBranches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>

          {/* Date Horizon Filter */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-purple-400" />
              Reporting Horizon
            </label>
            <select
              value={timeRange}
              onChange={(e) => handleFilterChange('time', e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700/70 text-slate-100 font-semibold focus:outline-hidden focus:border-blue-500 cursor-pointer"
            >
              <option value="30d">Last 30 Days (Real-Time Service)</option>
              <option value="ytd">Year-to-Date (2026 Academic/Fiscal)</option>
              <option value="all">All Time Historical Records</option>
            </select>
          </div>

          {/* Cohort Filter */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-amber-400" />
              Cohort Filter
            </label>
            <select
              value={selectedCohortFilter}
              onChange={(e) => setSelectedCohortFilter(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700/70 text-slate-100 font-semibold focus:outline-hidden focus:border-blue-500 cursor-pointer"
            >
              <option value="all">All Age Cohorts (0 to 36+)</option>
              {COHORTS_ORDER.map((c) => (
                <option key={c} value={c}>
                  {c} ({COHORT_DEFINITIONS[c].ageRange})
                </option>
              ))}
            </select>
          </div>

          {/* Search Member Filter */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-emerald-400" />
              Member / Ministry Search
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search member, ministry, occupation..."
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700/70 text-slate-100 text-xs placeholder:text-slate-500 focus:outline-hidden focus:border-blue-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-[10px]"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Export Confirmation Banner */}
      {exportNotice && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-800/80 text-emerald-300 rounded-2xl text-xs font-bold flex items-center gap-2 shadow-lg animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{exportNotice}</span>
        </div>
      )}

      {/* SKELETON LOADING OVERLAY WHEN FILTERING */}
      {isLoading ? (
        <div className="p-16 bg-slate-900/60 rounded-3xl border border-slate-800 flex flex-col items-center justify-center space-y-4">
          <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
          <p className="text-sm font-bold text-slate-300">Synthesizing Demographic Matrix & Cross-Campus Metrics...</p>
        </div>
      ) : (
        <>
          {/* ========================================== */}
          {/* SECTION A: TOP KPI SUMMARY CARDS (4 CARDS) */}
          {/* ========================================== */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
            {/* KPI 1: Total Membership + Age Cohort Distribution Badges */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">Total Membership</span>
                  <span className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    <Users className="w-4 h-4" />
                  </span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white">{kpiData.totalMembers.toLocaleString()}</span>
                  <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-0.5">
                    <ArrowUpRight className="w-3 h-3" /> +14.2% YoY
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Consolidated across {selectedBranch === 'all' ? `${liveBranches.length} Campuses` : 'Selected Branch'}</p>
              </div>

              {/* Age Cohort Distribution Pill Badges */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Cohort Breakdown:</span>
                <div className="flex flex-wrap gap-1.5">
                  {COHORTS_ORDER.map((c) => {
                    const count = kpiData.cohortCounts[c];
                    const pct = kpiData.totalMembers > 0 ? Math.round((count / kpiData.totalMembers) * 100) : 0;
                    return (
                      <span
                        key={c}
                        onClick={() => setSelectedCohortFilter(selectedCohortFilter === c ? 'all' : c)}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                          selectedCohortFilter === c ? 'ring-2 ring-white ' + COHORT_DEFINITIONS[c].iconBg : COHORT_DEFINITIONS[c].iconBg
                        }`}
                        title={`Click to filter by ${c} (${COHORT_DEFINITIONS[c].ageRange})`}
                      >
                        <span>{c}:</span>
                        <span className="font-mono text-white">{count}</span>
                        <span className="text-[9px] opacity-75">({pct}%)</span>
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* KPI 2: Active Workforce */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">Active Workforce</span>
                  <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    <Briefcase className="w-4 h-4" />
                  </span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-amber-400">{kpiData.workingTotal.toLocaleString()}</span>
                  <span className="text-xs font-bold text-slate-300">
                    ({kpiData.workforceRate}% of {kpiData.workforceEligibleTotal} Youth & Adults)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Employed & Self-Employed professionals</p>
              </div>

              {/* Breakdown pill badges */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Workforce Segments:</span>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-1.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                    <span className="text-amber-300 font-medium">Youth (20-35):</span>
                    <span className="font-mono font-bold text-white">{kpiData.workingYouth}</span>
                  </div>
                  <div className="p-1.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                    <span className="text-indigo-300 font-medium">Adults (36+):</span>
                    <span className="font-mono font-bold text-white">{kpiData.workingAdults}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* KPI 3: Ministry Attendance Rate */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">Ministry Attendance Rate</span>
                  <span className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    <Activity className="w-4 h-4" />
                  </span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-emerald-400">{kpiData.avgAttendanceRate}%</span>
                  <span className="text-[11px] font-bold text-emerald-300 flex items-center gap-0.5">
                    <ArrowUpRight className="w-3 h-3" /> +5.8% Q3
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Weekly check-in average across all 5 age cohorts</p>
              </div>

              {/* Cohort Leaders */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Attendance Ranking:</span>
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span className="text-indigo-400 font-bold">Adults: 91.2%</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-amber-400 font-bold">Youth: 84.6%</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-purple-400 font-bold">Teens: 81.8%</span>
                </div>
              </div>
            </div>

            {/* KPI 4: Youth & Adult Retention Index */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">90-Day Retention Index</span>
                  <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    <TrendingUp className="w-4 h-4" />
                  </span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-purple-400">{kpiData.retentionRate}%</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    High Consistency
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Active participating Youth & Adults over 90 days</p>
              </div>

              {/* Retention Status */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Retention Status:</span>
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden flex">
                  <div className="bg-purple-500 h-full" style={{ width: `${kpiData.retentionRate}%` }} />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>Target: 85% Benchmark</span>
                  <span className="text-emerald-400 font-bold">Exceeding Goal</span>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================== */}
          {/* SECTION B: DEMOGRAPHIC BREAKDOWN & BRANCH DISTRIBUTION */}
          {/* ========================================== */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Graphic 1: Stacked Bar Chart (Branch Membership by Age Cohort) */}
            <div className="lg:col-span-2 bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-blue-400" />
                    Branch Membership by Age Cohort
                  </h3>
                  <p className="text-xs text-slate-400">
                    Stacked distribution of Infant, Child, Teenager, Youth, and Adult members per campus.
                  </p>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400">
                  <span className="px-2 py-1 rounded-lg bg-slate-800 border border-slate-700/80">
                    {branchStackedData.length} Campuses Plotted
                  </span>
                </div>
              </div>

              {/* Stacked Bar Chart */}
              <div className="h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={branchStackedData} margin={{ top: 10, right: 10, left: -15, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
                    <XAxis
                      dataKey="name"
                      stroke="#94a3b8"
                      tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 600 }}
                      interval={0}
                      angle={-10}
                      textAnchor="end"
                    />
                    <YAxis stroke="#94a3b8" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip content={<CustomDarkTooltip />} />
                    <Legend
                      wrapperStyle={{ paddingTop: 10, fontSize: 11 }}
                      formatter={(val) => <span className="text-slate-300 font-semibold">{val}</span>}
                    />
                    <Bar dataKey="Infant" stackId="demographics" fill={COHORT_DEFINITIONS.Infant.color} />
                    <Bar dataKey="Child" stackId="demographics" fill={COHORT_DEFINITIONS.Child.color} />
                    <Bar dataKey="Teenager" stackId="demographics" fill={COHORT_DEFINITIONS.Teenager.color} />
                    <Bar dataKey="Youth" stackId="demographics" fill={COHORT_DEFINITIONS.Youth.color} />
                    <Bar dataKey="Adult" stackId="demographics" fill={COHORT_DEFINITIONS.Adult.color} radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Graphic 2: Overall Age Distribution Donut Chart with Center Metric */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4 flex flex-col justify-between">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <PieIcon className="w-4 h-4 text-purple-400" />
                  Overall Age Distribution
                </h3>
                <p className="text-xs text-slate-400">
                  Proportional share of all 5 demographic cohorts.
                </p>
              </div>

              {/* Donut Chart with Center Metric */}
              <div className="relative h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip content={<CustomDarkTooltip />} />
                    <Pie
                      data={donutAgeDistributionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={92}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {donutAgeDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>

                {/* Center Metric */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-2xl font-black text-white">{kpiData.totalMembers.toLocaleString()}</span>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Total Members</span>
                </div>
              </div>

              {/* Custom Detailed Legend */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                {donutAgeDistributionData.map((d) => (
                  <div
                    key={d.name}
                    onClick={() => setSelectedCohortFilter(selectedCohortFilter === d.name ? 'all' : (d.name as AgeCohort))}
                    className={`flex items-center justify-between text-xs p-1.5 rounded-xl transition-all cursor-pointer ${
                      selectedCohortFilter === d.name ? 'bg-slate-800 border border-slate-700' : 'hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                      <span className="font-semibold text-slate-200">{d.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({d.ageRange})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white font-mono">{d.value}</span>
                      <span className="text-[10px] text-slate-400 font-mono w-8 text-right font-semibold">
                        {d.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ========================================== */}
          {/* SECTION C: MINISTRY ATTENDANCE & ENGAGEMENT HEATMAP */}
          {/* ========================================== */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Graphic 3: Composed Chart (Attendance vs. Engagement Rate by Cohort) */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    Ministry Attendance vs. Engagement Rate
                  </h3>
                  <p className="text-xs text-slate-400">
                    Dual-axis analysis comparing average weekly attendance (Bar) vs. engagement index (Line).
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Dual Benchmark
                </span>
              </div>

              {/* Composed Chart */}
              <div className="h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={attendanceVsEngagementData} margin={{ top: 10, right: 10, left: -15, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
                    <XAxis dataKey="cohort" stroke="#94a3b8" tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 600 }} />
                    <YAxis yAxisId="left" stroke="#94a3b8" domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} unit="%" />
                    <YAxis yAxisId="right" orientation="right" stroke="#a855f7" domain={[0, 100]} tick={{ fill: '#a855f7', fontSize: 10 }} unit="%" />
                    <Tooltip content={<CustomDarkTooltip />} />
                    <Legend
                      wrapperStyle={{ paddingTop: 10, fontSize: 11 }}
                      formatter={(val) => <span className="text-slate-300 font-semibold">{val}</span>}
                    />
                    <Bar
                      yAxisId="left"
                      dataKey="attendance"
                      name="Weekly Attendance Rate (%)"
                      fill="#10b981"
                      radius={[6, 6, 0, 0]}
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="engagement"
                      name="Engagement Index (%)"
                      stroke="#c084fc"
                      strokeWidth={3}
                      dot={{ r: 5, fill: '#a855f7', stroke: '#ffffff', strokeWidth: 2 }}
                      activeDot={{ r: 7 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Graphic 4: Grouped Bar Chart (Ministry Allocation by Age Group) */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    Ministry Allocation by Age Group
                  </h3>
                  <p className="text-xs text-slate-400">
                    Participation volumes across key church departments by Teenagers, Youth, and Adults.
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  3 Target Groups
                </span>
              </div>

              {/* Grouped Bar Chart */}
              <div className="h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ministryAllocationData} margin={{ top: 10, right: 10, left: -15, bottom: 35 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
                    <XAxis
                      dataKey="ministry"
                      stroke="#94a3b8"
                      tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 600 }}
                      interval={0}
                      angle={-18}
                      textAnchor="end"
                    />
                    <YAxis stroke="#94a3b8" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip content={<CustomDarkTooltip />} />
                    <Legend
                      wrapperStyle={{ paddingTop: 12, fontSize: 11 }}
                      formatter={(val) => <span className="text-slate-300 font-semibold">{val}</span>}
                    />
                    <Bar dataKey="Teenager" fill={COHORT_DEFINITIONS.Teenager.color} radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Youth" fill={COHORT_DEFINITIONS.Youth.color} radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Adult" fill={COHORT_DEFINITIONS.Adult.color} radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* ========================================== */}
          {/* SECTION D: DEEP-DIVE WORKFORCE ANALYTICS (YOUTH & ADULTS) */}
          {/* ========================================== */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Graphic 5: Horizontal Bar Chart (Employment Breakdown Youth vs. Adults) */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-amber-400" />
                    Employment Breakdown (Youth vs. Adults)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Comparative career and workforce status across younger (20-35) and older (36+) members.
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    Workforce Matrix
                  </span>
                </div>
              </div>

              {/* Horizontal Bar Chart */}
              <div className="h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={employmentComparisonData}
                    margin={{ top: 10, right: 20, left: 40, bottom: 10 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
                    <XAxis type="number" stroke="#94a3b8" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis
                      dataKey="shortStatus"
                      type="category"
                      stroke="#94a3b8"
                      tick={{ fill: '#cbd5e1', fontSize: 11, fontWeight: 600 }}
                      width={100}
                    />
                    <Tooltip content={<CustomDarkTooltip />} />
                    <Legend
                      wrapperStyle={{ paddingTop: 10, fontSize: 11 }}
                      formatter={(val) => <span className="text-slate-300 font-semibold">{val}</span>}
                    />
                    <Bar dataKey="Youth" fill={COHORT_DEFINITIONS.Youth.color} radius={[0, 4, 4, 0]} />
                    <Bar dataKey="Adult" fill={COHORT_DEFINITIONS.Adult.color} radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Quick Summary Pill Bar */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs gap-2">
                <span className="text-slate-400">Career Support Strategy:</span>
                <span className="text-amber-400 font-semibold">
                  {filteredRecords.filter((r) => r.workforceStatus === 'Job Seeking').length} members actively job seeking (Target for Church Career Hub)
                </span>
              </div>
            </div>

            {/* Graphic 6: Radar Chart (Working Members Ministry Involvement Ratio) */}
            <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                    <Compass className="w-4 h-4 text-indigo-400" />
                    Working Members Ministry Involvement Ratio
                  </h3>
                  <p className="text-xs text-slate-400">
                    Weekday vs. weekend commitment capacity comparison for working Youth vs. Adults.
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  Radar Distribution
                </span>
              </div>

              {/* Radar Chart */}
              <div className="h-72 w-full pt-1">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius={88} data={workingMinistryInvolvementData}>
                    <PolarGrid stroke="#334155" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#cbd5e1', fontSize: 10, fontWeight: 600 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#64748b" tick={{ fill: '#64748b', fontSize: 9 }} />
                    <Radar
                      name="Working Youth (20-35)"
                      dataKey="Working Youth (20-35)"
                      stroke="#f59e0b"
                      fill="#f59e0b"
                      fillOpacity={0.35}
                    />
                    <Radar
                      name="Working Adults (36+)"
                      dataKey="Working Adults (36+)"
                      stroke="#6366f1"
                      fill="#6366f1"
                      fillOpacity={0.35}
                    />
                    <Tooltip content={<CustomDarkTooltip />} />
                    <Legend
                      wrapperStyle={{ paddingTop: 10, fontSize: 11 }}
                      formatter={(val) => <span className="text-slate-300 font-semibold">{val}</span>}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              {/* Insight Callout */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span>Key Observation:</span>
                <span className="text-indigo-300 font-semibold">
                  Working Youth excel in Weekend Worship & Media; Adults anchor Leadership & Midweek Prayer.
                </span>
              </div>
            </div>
          </div>

          {/* ========================================== */}
          {/* SECTION E: INTERACTIVE DEMOGRAPHIC DRILLDOWN DIRECTORY */}
          {/* ========================================== */}
          <div className="bg-slate-900/80 backdrop-blur-md rounded-3xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-400" />
                  Demographic Member Cohort Directory
                </h3>
                <p className="text-xs text-slate-400">
                  Showing {filteredRecords.length} filtered members with calculated age, cohort classification, and workforce indicators.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-semibold">Quick Cohort Filter:</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSelectedCohortFilter('all')}
                    className={`min-h-[34px] px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      selectedCohortFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    All ({consolidatedRecords.length})
                  </button>
                  {COHORTS_ORDER.map((c) => (
                    <button
                      type="button"
                      key={c}
                      onClick={() => setSelectedCohortFilter(selectedCohortFilter === c ? 'all' : c)}
                      className={`min-h-[34px] px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        selectedCohortFilter === c ? 'bg-white text-slate-900 shadow-md' : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Members Directory Table */}
            <div className="cmms-table-scroll overflow-x-auto rounded-2xl border border-slate-800">
              <table className="cmms-data-table w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-800/80 text-slate-400 uppercase tracking-wider font-extrabold text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3 min-w-[160px]">Member ID & Name</th>
                    <th className="p-3 whitespace-nowrap">Calculated Age</th>
                    <th className="p-3 whitespace-nowrap">Age Cohort</th>
                    <th className="p-3 min-w-[140px]">Campus Branch</th>
                    <th className="p-3 whitespace-nowrap">Workforce Status</th>
                    <th className="p-3 min-w-[140px]">Primary Ministry</th>
                    <th className="p-3 text-right whitespace-nowrap">Attendance Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {filteredRecords.slice(0, 8).map((rec) => {
                    const cohortInfo = COHORT_DEFINITIONS[rec.cohort];
                    return (
                      <tr
                        key={rec.id}
                        onClick={() => setActiveDrilldownMember(rec)}
                        className="hover:bg-slate-800/50 transition-all cursor-pointer"
                      >
                        <td className="p-3">
                          <div className="flex flex-col">
                            <span className="font-bold text-white text-sm">{rec.fullName}</span>
                            <span className="text-[11px] font-mono text-slate-400 tabular-nums">{rec.memberIdNumber}</span>
                          </div>
                        </td>
                        <td className="p-3 whitespace-nowrap">
                          <span className="font-mono font-bold text-white text-sm tabular-nums">{rec.age} yrs</span>
                        </td>
                        <td className="p-3 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-bold border whitespace-nowrap ${cohortInfo.iconBg}`}>
                            {rec.cohort} ({cohortInfo.ageRange})
                          </span>
                        </td>
                        <td className="p-3 font-medium text-slate-300">{rec.branchName}</td>
                        <td className="p-3 whitespace-nowrap">
                          {rec.workforceStatus ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-semibold bg-slate-800 border border-slate-700 text-slate-200 whitespace-nowrap">
                              <Briefcase className="w-3 h-3 text-amber-400 shrink-0" />
                              {rec.workforceStatus}
                            </span>
                          ) : (
                            <span className="text-slate-500 font-mono text-[11px]">N/A (School/Dependent)</span>
                          )}
                        </td>
                        <td className="p-3">
                          <span className="font-semibold text-blue-400">{rec.primaryMinistry}</span>
                        </td>
                        <td className="p-3 text-right whitespace-nowrap">
                          <span className="font-mono font-bold text-emerald-400 tabular-nums">{rec.weeklyAttendanceRate}%</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {filteredRecords.length > 8 && (
              <div className="text-center pt-2 text-xs text-slate-400">
                <span>Showing 8 of {filteredRecords.length} records in direct preview. Use the Export tools above to view the full directory.</span>
              </div>
            )}
          </div>
        </>
      )}

      {/* Member Drilldown Modal */}
      {activeDrilldownMember && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Demographic Profile</span>
                <h3 className="text-lg font-black text-white">{activeDrilldownMember.fullName}</h3>
              </div>
              <button
                onClick={() => setActiveDrilldownMember(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                <span className="text-slate-400 font-bold block text-[10px] uppercase">Calculated Age</span>
                <span className="text-base font-black text-white">{activeDrilldownMember.age} years</span>
                <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${COHORT_DEFINITIONS[activeDrilldownMember.cohort].iconBg}`}>
                  {activeDrilldownMember.cohort} ({COHORT_DEFINITIONS[activeDrilldownMember.cohort].ageRange})
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                <span className="text-slate-400 font-bold block text-[10px] uppercase">Campus Branch</span>
                <span className="text-sm font-black text-white">{activeDrilldownMember.branchName}</span>
                <span className="text-[10px] text-slate-400 block mt-1">ID: {activeDrilldownMember.memberIdNumber}</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                <span className="text-slate-400 font-bold block text-[10px] uppercase">Workforce Status</span>
                <span className="text-sm font-bold text-amber-400">
                  {activeDrilldownMember.workforceStatus || 'Dependent / Pre-Workforce'}
                </span>
                <span className="text-[10px] text-slate-300 block mt-0.5">
                  {activeDrilldownMember.occupationTitle || 'Student / Dependent'}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                <span className="text-slate-400 font-bold block text-[10px] uppercase">Ministry Involvement</span>
                <span className="text-sm font-bold text-blue-400">{activeDrilldownMember.primaryMinistry}</span>
                <span className="text-[10px] text-emerald-400 font-mono block mt-0.5">
                  Attendance: {activeDrilldownMember.weeklyAttendanceRate}%
                </span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setActiveDrilldownMember(null)}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
