import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { GoogleTranslatorWidget } from './GoogleTranslatorWidget';
import {
  Church,
  Shield,
  Users,
  CreditCard,
  MessageSquare,
  Globe,
  ArrowRight,
  CheckCircle2,
  Calendar,
  MapPin,
  Clock,
  BookOpen,
  Lock,
  ChevronRight,
  Smartphone,
  Phone,
  Mail,
  Heart,
  ChevronUp,
  TrendingUp,
  Activity,
  Layers,
  HeartHandshake,
  UserCheck,
  Building2,
  FileText,
  LogIn,
  SunMedium,
  Sun,
  Moon,
  Check,
  ExternalLink,
} from 'lucide-react';

interface LandingPageProps {
  onEnterPortal?: (role?: UserRole) => void;
  onLaunchApp?: () => void;
  onFindGroup?: () => void;
  onOpenRegister?: () => void;
  onOpenLogin?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onEnterPortal,
  onLaunchApp,
  onFindGroup,
  onOpenRegister,
  onOpenLogin,
}) => {
  const {
    systemName,
    churchLogoUrl,
    members,
    ministries,
    branches,
    language,
    themeMode,
    setThemeMode,
  } = useCMMS();
  const { switchDemoRole } = useAuth();
  const [isTranslatorOpen, setIsTranslatorOpen] = useState(false);

  const isDark = themeMode === 'dark';
  const toggleTheme = () => {
    setThemeMode(isDark ? 'light' : 'dark');
  };

  const handleLaunchRole = (role: UserRole) => {
    switchDemoRole(role);
    onEnterPortal?.(role);
  };

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleScrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const primaryBranch = branches && branches.length > 0 ? branches[0] : null;

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white font-montserrat transition-colors duration-200">
      {/* 1. TOP FLOATING NAVBAR */}
      <header className="sticky top-0 z-40 bg-white/85 dark:bg-slate-950/85 backdrop-blur-md border-b border-slate-200 dark:border-slate-800/80 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between">
          {/* Brand Identity */}
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl p-0.5 shadow-md flex items-center justify-center shrink-0"
              style={{
                background: 'linear-gradient(135deg, var(--cmms-primary-color, #2563eb), var(--cmms-accent-color, #7c3aed))',
              }}
            >
              {churchLogoUrl ? (
                <img src={churchLogoUrl} alt="Logo" className="w-6 h-6 rounded-lg object-contain" />
              ) : (
                <Church className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              )}
            </div>
            <div>
              <h1 className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                <span>{systemName || 'Grace Cathedral International'}</span>
              </h1>
              <p
                className="text-[11px] font-medium tracking-wide"
                style={{ color: 'var(--cmms-primary-color, #2563eb)' }}
              >
                Church Management System (CMMS)
              </p>
            </div>
          </div>

          {/* Center Navigation Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-600 dark:text-slate-300">
            <button
              type="button"
              onClick={() => handleScrollToSection('features')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Features
            </button>
            <button
              type="button"
              onClick={() => handleScrollToSection('ecosystem')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Ecosystem
            </button>
            <button
              type="button"
              onClick={() => handleScrollToSection('roles')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Workflows
            </button>
            <button
              type="button"
              onClick={() => handleScrollToSection('security')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Security
            </button>
            <button
              type="button"
              onClick={() => handleScrollToSection('campuses')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Campuses
            </button>
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Theme Toggle (Light / Dark) */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              {isDark ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Light</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600" />
                  <span className="hidden sm:inline">Dark</span>
                </>
              )}
            </button>

            {/* Google Translator Trigger Button */}
            <button
              type="button"
              onClick={() => setIsTranslatorOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer"
              title="Change Interface Language"
              aria-label="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span className="hidden sm:inline">Language</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-blue-500/15 text-blue-700 dark:text-blue-300 font-mono uppercase">
                {language}
              </span>
            </button>

            {/* Secondary CTA: Sign In */}
            <button
              type="button"
              onClick={onOpenLogin}
              className="px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 hover:text-slate-900 dark:text-slate-200 dark:hover:text-white border border-slate-300 dark:border-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <LogIn className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
              <span>Sign In</span>
            </button>

            {/* Primary CTA: Get Started */}
            <button
              type="button"
              onClick={onOpenRegister}
              style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
              className="px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl hover:opacity-95 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. HERO SECTION */}
      <section className="relative pt-12 sm:pt-20 pb-16 sm:pb-24 overflow-hidden border-b border-slate-200 dark:border-slate-800/80">
        {/* Subtle Ambient Radial Lighting (Restrained & Professional) */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[360px] bg-gradient-to-tr from-blue-600/10 via-indigo-600/10 to-transparent blur-3xl pointer-events-none rounded-full" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-6">
          {/* Unboxed Metadata Kicker (Anti-Slop Zero-Pill) */}
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-blue-600 dark:text-blue-400">
            <span>{systemName || 'Grace Cathedral International'}</span>
            <span aria-hidden="true" className="text-slate-400 dark:text-slate-600">·</span>
            <span>Church Management System</span>
            <span aria-hidden="true" className="text-slate-400 dark:text-slate-600">·</span>
            <span>Enterprise Sovereign Platform</span>
          </div>

          {/* Main Headline */}
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 dark:text-white max-w-4xl mx-auto leading-tight">
            Manage Your Church. Connect Your People.
          </h2>

          {/* Supporting Text */}
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-3xl mx-auto leading-relaxed font-normal">
            A modern, unified platform designed specifically for church administration. Seamlessly coordinate
            member management, ministries, attendance tracking, events, communications, prayer requests,
            YouVersion Bible study, daily devotions, executive reports, and leadership governance.
          </p>

          {/* Primary & Secondary Call To Actions */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              type="button"
              onClick={onOpenRegister}
              style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
              className="px-6 py-3.5 rounded-2xl hover:opacity-95 text-white font-bold text-sm shadow-xl transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onOpenLogin}
              className="px-6 py-3.5 rounded-2xl bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-800 hover:text-slate-900 dark:text-slate-200 dark:hover:text-white font-bold text-sm border border-slate-300 dark:border-slate-700 transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <LogIn className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              <span>Sign In to Portal</span>
            </button>
          </div>

          {/* Clean Unboxed Capability Separator */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-slate-600 dark:text-slate-400 font-medium">
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Member &amp; Family Profiles
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Multi-Service Attendance
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              YouVersion Scripture Reader
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Pastoral Daily Devotions
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Executive Growth Reports
            </span>
          </div>

          {/* 3. HERO GRAPHIC / MODERN DASHBOARD PREVIEW */}
          <div className="pt-10 max-w-5xl mx-auto text-left">
            <div className="relative rounded-3xl bg-slate-50/90 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-7 backdrop-blur-xl overflow-hidden">
              {/* Top Window Bar */}
              <div className="flex items-center justify-between pb-5 border-b border-slate-200 dark:border-slate-800/80">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <div className="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <div className="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="ml-2 text-xs font-mono text-slate-500 dark:text-slate-400">
                    cmms.gracecathedral.org/overview
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                    {primaryBranch?.name || 'Headquarters'}
                  </span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                </div>
              </div>

              {/* Graphical Metric Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 pt-5 pb-6">
                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 shadow-xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                    <span>Active Congregation</span>
                    <Users className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">{members.length}</p>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">Registered members</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 shadow-xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                    <span>Campuses</span>
                    <Activity className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">{branches.length}</p>
                  <span className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">Active locations</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 shadow-xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                    <span>Active Ministries</span>
                    <HeartHandshake className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  </div>
                  <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">{ministries.length} Groups</p>
                  <span className="text-[11px] text-amber-600 dark:text-amber-400 font-medium">Equipping leaders</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 shadow-xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                    <span>Bible &amp; Devotion</span>
                    <BookOpen className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">YouVersion</p>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">NASV 1260 &amp; NIV 111</span>
                </div>
              </div>

              {/* Platform Ecosystem Mini Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800/80 space-y-1.5 shadow-xs">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <UserCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span>Member Care &amp; Household</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                    Complete family unit indexing, pastoral visitations, and spiritual milestone records.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800/80 space-y-1.5 shadow-xs">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <Calendar className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>Gatherings &amp; Service Events</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                    Sunday worship, midweek communion, youth fellowship, and special revival schedules.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800/80 space-y-1.5 shadow-xs">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                    <TrendingUp className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Executive Growth Reports</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                    Actionable demographic distributions, attendance health KPIs, and CSV exports.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. FEATURE SECTION */}
      <section id="features" className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Comprehensive Capabilities</span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Designed for Modern Church Operations
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Every feature is purpose-built to reduce administrative friction and cultivate genuine spiritual fellowship.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {/* 1. Members */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Members</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Manage member profiles, families, roles, and relationships across all branch campuses.
            </p>
          </div>

          {/* 2. Ministries */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Ministries</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Organize ministries, departmental leaders, teams, and member service assignments.
            </p>
          </div>

          {/* 3. Attendance */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <UserCheck className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Attendance</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Track attendance across worship services, special events, and discipleship classes.
            </p>
          </div>

          {/* 4. Events */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Events</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Manage church events, schedules, volunteer rosters, and congregation participants.
            </p>
          </div>

          {/* 5. Prayer */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Heart className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Prayer</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Receive confidential prayer requests with pastoral follow-up and counseling tracking.
            </p>
          </div>

          {/* 6. Bible */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Bible</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Access the YouVersion Bible experience with Amharic and English translations and private study marks.
            </p>
          </div>

          {/* 7. Daily Devotion */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 flex items-center justify-center">
              <SunMedium className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Daily Devotion</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Publish and share pastoral devotional reflections and Scripture applications with all members.
            </p>
          </div>

          {/* 8. Reports */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Reports</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Generate useful church management reports, demographic analyses, and executive exports.
            </p>
          </div>
        </div>
      </section>

      {/* 5. MODULE VISUALIZATION: CMMS ECOSYSTEM ARCHITECTURE */}
      <section id="ecosystem" className="py-16 sm:py-24 bg-slate-50/80 dark:bg-slate-900/40 border-y border-slate-200 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-2 max-w-2xl mx-auto">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Integrated Architecture</span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              The CMMS Connected Ecosystem
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              All modules connect harmoniously through a centralized data layer, providing a single source of truth.
            </p>
          </div>

          {/* Connected Cards Visual Tree */}
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Tier 1: Sovereign Core Node */}
            <div className="flex justify-center">
              <div className="px-6 py-4 rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 border border-blue-400/40 text-white shadow-xl shadow-blue-500/20 text-center space-y-1 max-w-sm">
                <div className="flex items-center justify-center gap-2">
                  <Church className="w-5 h-5" />
                  <span className="font-black text-sm uppercase tracking-wider">CMMS Sovereign Core</span>
                </div>
                <p className="text-[11px] text-blue-100 font-normal">
                  Centralized Authentication, RBAC &amp; Tenant Database
                </p>
              </div>
            </div>

            {/* Connecting Vertical Stem */}
            <div className="flex justify-center -my-3">
              <div className="w-px h-6 bg-slate-300 dark:bg-slate-700" />
            </div>

            {/* Tier 2: Primary Operational Pillars */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Pillar 1: Members & People */}
              <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 relative shadow-xs">
                <div className="flex items-center justify-between text-blue-600 dark:text-blue-400">
                  <span className="text-xs font-bold uppercase tracking-wider">People</span>
                  <Users className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Members</h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Family directories, pastoral counseling records, and member spiritual journeys.
                </p>
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                  <span>Downstream:</span>
                  <span className="text-blue-600 dark:text-blue-300 font-semibold">Attendance</span>
                </div>
              </div>

              {/* Pillar 2: Ministry & Discipleship */}
              <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 relative shadow-xs">
                <div className="flex items-center justify-between text-indigo-600 dark:text-indigo-400">
                  <span className="text-xs font-bold uppercase tracking-wider">Discipleship</span>
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Ministries</h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Worship, youth, ushers, protocol, and community fellowship departments.
                </p>
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                  <span>Downstream:</span>
                  <span className="text-indigo-600 dark:text-indigo-300 font-semibold">Prayer &amp; Pastoral Care</span>
                </div>
              </div>

              {/* Pillar 3: Events & Operations */}
              <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 relative shadow-xs">
                <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
                  <span className="text-xs font-bold uppercase tracking-wider">Gatherings</span>
                  <Calendar className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Events</h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Worship schedules, special conferences, facility reservations, and service logs.
                </p>
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                  <span>Downstream:</span>
                  <span className="text-emerald-600 dark:text-emerald-300 font-semibold">Communications</span>
                </div>
              </div>
            </div>

            {/* Connecting Vertical Stem */}
            <div className="flex justify-center -my-3">
              <div className="w-px h-6 bg-slate-300 dark:bg-slate-700" />
            </div>

            {/* Tier 3: Downstream Spiritual & Growth Modules */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Attendance -> Bible */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/80 space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-200">
                  <BookOpen className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                  <span>Holy Bible (YouVersion)</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  Amharic NASV and English NIV Scripture reading with private user bookmarks and notes.
                </p>
              </div>

              {/* Prayer -> Devotion */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/80 space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-200">
                  <SunMedium className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                  <span>Church Daily Devotion</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  Pastoral devotionals published directly to all congregation members daily.
                </p>
              </div>

              {/* Communication -> Reports */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/80 space-y-1.5 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-200">
                  <TrendingUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  <span>Reports &amp; Analytics</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  Attendance retention, demographic distributions, and financial summary charts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. ROLE WORKFLOWS SECTION (TEST-DRIVE EXPERIENCES) */}
      <section id="roles" className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Role-Based Access Control</span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Tailored Experiences by Role
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Switch into any role persona to test-drive specific workflows, dashboards, and permission boundaries.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* System Admin */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 transition-colors flex flex-col justify-between space-y-4 shadow-xs">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                <Shield className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">System Admin</h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Complete system governance: Member onboarding approvals, audit trails, user permission matrices, and multi-campus configurations.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleLaunchRole('SYSTEM_ADMIN')}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Test as System Admin
            </button>
          </div>

          {/* Pastor */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-500/50 transition-colors flex flex-col justify-between space-y-4 shadow-xs">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                <Heart className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Pastor</h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Shepherding the flock: Pastoral visitations, confidential prayer counseling, daily devotional authoring, and member spiritual care.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleLaunchRole('PASTOR')}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
            >
              Test as Pastor
            </button>
          </div>

          {/* Ministry Leader */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-500/50 transition-colors flex flex-col justify-between space-y-4 shadow-xs">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Ministry Leader</h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Departmental coordination: Volunteer teams, rehearsal schedules, service assignments, and ministry attendance tracking.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleLaunchRole('MINISTRY_LEADER')}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Test as Ministry Leader
            </button>
          </div>

          {/* Regular Member */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 transition-colors flex flex-col justify-between space-y-4 shadow-xs">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                <UserCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Regular Member</h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Congregation portal: Personal discipleship, family profile, YouVersion Bible study marks, daily devotions, and prayer requests.
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleLaunchRole('REGULAR_MEMBER')}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Test as Member
            </button>
          </div>
        </div>
      </section>

      {/* 7. TRUST & SECURITY SECTION (ACCURATE & AUTHENTIC) */}
      <section id="security" className="py-16 sm:py-24 bg-slate-50/80 dark:bg-slate-900/40 border-y border-slate-200 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-2 max-w-2xl mx-auto">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Enterprise Reliability</span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Built on Trust and Security
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Real architectural guarantees safeguarding your church records, pastoral counseling, and financial data.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* 1. RBAC */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400">
                <Shield className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-slate-200">
                  Role-Based Access Control
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Strict separation of privileges between Pastors, Administrators, Managers, Ministry Leaders, and Members.
              </p>
            </div>

            {/* 2. Secure Auth */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-indigo-600 dark:text-indigo-400">
                <Lock className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-slate-200">
                  Secure Authentication
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Encrypted password protection, session validation, and multi-factor authentication support for leadership accounts.
              </p>
            </div>

            {/* 3. Audit Logging */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400">
                <FileText className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-slate-200">
                  System Audit Trails
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Comprehensive logging of member record updates, role changes, and administrative actions for accountability.
              </p>
            </div>

            {/* 4. Session Management */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-amber-600 dark:text-amber-400">
                <Clock className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-slate-200">
                  Session Management
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Timed session tokens, automatic inactivity timeouts, and 30-day security re-authentication for elevated roles.
              </p>
            </div>

            {/* 5. Data Protection */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-cyan-600 dark:text-cyan-400">
                <CheckCircle2 className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-slate-200">
                  Data Privacy Isolation
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Personal Bible notes, bookmarks, and private pastoral prayer requests remain strictly private to authorized users.
              </p>
            </div>

            {/* 6. Multi-Campus Sync */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
              <div className="flex items-center gap-2.5 text-purple-600 dark:text-purple-400">
                <Building2 className="w-4 h-4" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-slate-200">
                  Multi-Campus Tenancy
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Synchronized data across all branch locations with campus-specific leadership oversight and centralized reporting.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. CAMPUSES & SERVICE TIMES */}
      <section id="campuses" className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-1">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Branch Locations</span>
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            Campuses &amp; Weekly Gathering Times
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Join fellowship in person across our regional church campuses.
          </p>
        </div>

        {branches.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400">
            No data available
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {branches.map((branch) => (
              <div
                key={branch.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-3 shadow-xs"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-blue-600 dark:text-blue-400 uppercase">{branch.name}</span>
                    <MapPin className="w-4 h-4 text-slate-400 dark:text-slate-500" />
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">{branch.address || 'No address specified'}</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{branch.city || ''}</p>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-1 text-[11px] text-slate-500 dark:text-slate-400">
                  {branch.serviceTimes && branch.serviceTimes.length > 0 ? (
                    branch.serviceTimes.map((st, idx) => (
                      <div key={idx} className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                        <span>{st.day}: {st.time}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-400 dark:text-slate-500">No service times configured</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 9. PROFESSIONAL LANDING PAGE FOOTER */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12 pb-12 border-b border-slate-200 dark:border-slate-800">
            {/* Col 1: Identity & Description */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-xl p-0.5 flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, var(--cmms-primary-color, #2563eb), var(--cmms-accent-color, #7c3aed))',
                  }}
                >
                  <Church className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white tracking-tight">
                    {systemName || 'CMMS'}
                  </h4>
                  <p className="text-[11px] text-blue-600 dark:text-blue-400 font-medium">
                    Church Management System (CMMS)
                  </p>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed max-w-sm">
                A sovereign enterprise management platform enabling church leadership, pastors, and members
                to collaborate, pray, study, and grow together in ministry.
              </p>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={onOpenRegister}
                  style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                  className="px-4 py-2 rounded-xl hover:opacity-95 text-white font-bold text-xs transition-colors cursor-pointer"
                >
                  Get Started
                </button>
                <button
                  type="button"
                  onClick={onOpenLogin}
                  className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 font-bold text-xs transition-colors cursor-pointer"
                >
                  Sign In
                </button>
              </div>
            </div>

            {/* Col 2: Core Modules Navigation */}
            <div className="space-y-3">
              <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Core Modules</h5>
              <ul className="space-y-2 text-xs">
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('REGULAR_MEMBER')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Members Directory
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('MINISTRY_LEADER')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Ministries &amp; Teams
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('SYSTEM_ADMIN')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Service Attendance
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('SYSTEM_ADMIN')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Calendar &amp; Events
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Spiritual & Reports */}
            <div className="space-y-3">
              <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Spiritual &amp; Insights</h5>
              <ul className="space-y-2 text-xs">
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('REGULAR_MEMBER')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Holy Bible (YouVersion)
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('PASTOR')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Daily Devotions
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('PASTOR')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Prayer Requests
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleLaunchRole('SYSTEM_ADMIN')}
                    className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  >
                    Executive Reports
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 4: Contact Information */}
            <div className="space-y-3">
              <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Headquarters</h5>
              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
                <div className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                  <span>{primaryBranch?.address || 'No data available'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>{primaryBranch?.phone || 'No data available'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>{primaryBranch?.email || 'No data available'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Copyright and Controls */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span>© {new Date().getFullYear()} {systemName || 'Grace Cathedral International'}. All rights reserved.</span>
            </div>

            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => setIsTranslatorOpen(true)}
                className="hover:text-slate-800 dark:hover:text-slate-300 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Multilingual: {language.toUpperCase()}</span>
              </button>

              <button
                type="button"
                onClick={handleScrollToTop}
                className="hover:text-slate-800 dark:hover:text-slate-300 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <ChevronUp className="w-3.5 h-3.5" />
                <span>Back to Top</span>
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Multilingual Google Translation Modal */}
      {isTranslatorOpen && (
        <GoogleTranslatorWidget isOpen={isTranslatorOpen} onClose={() => setIsTranslatorOpen(false)} />
      )}
    </div>
  );
};

export default LandingPage;
