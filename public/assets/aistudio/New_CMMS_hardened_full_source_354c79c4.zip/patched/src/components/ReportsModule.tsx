import React, { useState, useMemo } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  TrendingUp,
  BarChart3,
  Users,
  Calendar,
  DollarSign,
  Heart,
  Sparkles,
  Download,
  Printer,
  Filter,
  ArrowUpRight,
  CheckCircle2,
  Building2,
  BookOpen,
  FileSpreadsheet,
  FileText,
  Clock,
  ChevronRight,
  UserCheck,
  Activity,
  Layers,
  Award,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart as RechartsPie,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';

type ReportTab = 'overview' | 'demographics' | 'attendance' | 'giving' | 'pastoral';

export const ReportsModule: React.FC = () => {
  const {
    members,
    families,
    branches,
    ministries,
    attendanceRecords,
    attendanceSessions,
    events,
    prayerRequests,
    counselingSessions,
    visitations,
    systemName,
  } = useCMMS();

  const [activeTab, setActiveTab] = useState<ReportTab>('overview');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<'30d' | '90d' | '1y' | 'all'>('30d');
  const [isExporting, setIsExporting] = useState(false);

  // Filtered members based on branch selection
  const filteredMembers = useMemo(() => {
    if (selectedBranchId === 'all') return members;
    return members.filter((m) => m.branchId === selectedBranchId);
  }, [members, selectedBranchId]);

  // Aggregate metrics
  const totalMembers = filteredMembers.length;
  const activeMembers = filteredMembers.filter((m) => m.membershipStatus === 'Active' || !m.membershipStatus).length;
  const baptizedMembers = filteredMembers.filter((m) => m.isWaterBaptized || m.isHolySpiritBaptized).length;

  // Cohort calculations
  const demographicCohorts = useMemo(() => {
    let infants = 0;
    let children = 0;
    let teens = 0;
    let youth = 0;
    let adults = 0;

    const currentYear = new Date().getFullYear();

    filteredMembers.forEach((m) => {
      if (!m.dateOfBirth) return;
      const birthYear = new Date(m.dateOfBirth).getFullYear();
      if (isNaN(birthYear)) return;
      const age = Math.max(0, currentYear - birthYear);

      if (age <= 3) infants++;
      else if (age <= 12) children++;
      else if (age <= 17) teens++;
      else if (age <= 29) youth++;
      else adults++;
    });

    return [
      { name: 'Infants (0-3)', count: infants, color: '#ec4899' },
      { name: 'Children (4-12)', count: children, color: '#f59e0b' },
      { name: 'Teens (13-17)', count: teens, color: '#10b981' },
      { name: 'Youth (18-29)', count: youth, color: '#3b82f6' },
      { name: 'Adults (30+)', count: adults, color: '#6366f1' },
    ];
  }, [filteredMembers]);

  // Attendance statistics from real attendanceSessions
  const attendanceMonthlyTrend = useMemo(() => {
    return attendanceSessions.map((s) => ({
      month: s.date,
      attendance: s.presentCount || 0,
      target: s.totalCount || s.presentCount || 0,
      checkInRate: s.totalCount ? Math.round(((s.presentCount || 0) / s.totalCount) * 100) : 0,
    }));
  }, [attendanceSessions]);

  const weeklyWorshipPeak = useMemo(() => {
    if (attendanceSessions.length === 0) return 0;
    return Math.max(...attendanceSessions.map((s) => s.presentCount || 0));
  }, [attendanceSessions]);

  // Giving & Financial breakdown from real ministry budgets
  const totalMinistryBudget = useMemo(() => {
    return ministries.reduce((acc, m) => acc + (m.budgetAllocated || 0), 0);
  }, [ministries]);

  const financialSummary = useMemo(() => {
    if (ministries.length === 0 || totalMinistryBudget === 0) return [];
    const colors = ['#2563eb', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444'];
    return ministries.map((m, idx) => ({
      category: m.name,
      amount: m.budgetAllocated || 0,
      percentage: Math.round(((m.budgetAllocated || 0) / totalMinistryBudget) * 100),
      color: colors[idx % colors.length],
    }));
  }, [ministries, totalMinistryBudget]);

  // Pastoral Care statistics
  const prayerResolvedCount = prayerRequests.filter((p) => p.status === 'Answered' || p.status === 'Closed').length;
  const visitationsCompletedCount = visitations.filter((v) => v.status === 'Completed').length;
  const counselingCompletedCount = counselingSessions.filter((c) => c.status === 'Completed').length;

  // Handle Export to CSV
  const handleExportCSV = () => {
    setIsExporting(true);
    try {
      let csvContent = 'data:text/csv;charset=utf-8,';

      if (activeTab === 'demographics') {
        csvContent += 'Cohort Category,Count,Percentage of Congregation\n';
        demographicCohorts.forEach((c) => {
          const pct = totalMembers > 0 ? ((c.count / totalMembers) * 100).toFixed(1) : '0';
          csvContent += `"${c.name}",${c.count},"${pct}%"\n`;
        });
      } else if (activeTab === 'giving') {
        csvContent += 'Financial Category,Amount (USD),Share Percentage\n';
        financialSummary.forEach((f) => {
          csvContent += `"${f.category}",$${f.amount},"${f.percentage}%"\n`;
        });
      } else if (activeTab === 'attendance') {
        csvContent += 'Month,Actual Attendance,Target Goal,Check-In Reliability Rate\n';
        attendanceMonthlyTrend.forEach((t) => {
          csvContent += `"${t.month}",${t.attendance},${t.target},"${t.checkInRate}%"\n`;
        });
      } else {
        // Default Overview CSV
        csvContent += `CMMS EXECUTIVE REPORT - ${systemName || 'CMMS'}\n`;
        csvContent += `Generated Date,"${new Date().toLocaleDateString()}"\n`;
        csvContent += `Total Members,${totalMembers}\n`;
        csvContent += `Active Members,${activeMembers}\n`;
        csvContent += `Baptized Members,${baptizedMembers}\n`;
        csvContent += `Total Campuses,${branches.length}\n`;
        csvContent += `Active Ministries,${ministries.length}\n`;
        csvContent += `Completed Visitations,${visitationsCompletedCount}\n`;
        csvContent += `Answered Prayers,${prayerResolvedCount}\n`;
      }

      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `CMMS_${activeTab.toUpperCase()}_Report_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setTimeout(() => setIsExporting(false), 600);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Executive Report Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 sm:p-8 rounded-3xl text-white shadow-xl border border-slate-800">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Sovereign Executive Intelligence & Growth Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Executive Reports & Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
            Comprehensive church administration data covering member demographics, multi-campus attendance, financial stewardship, and pastoral impact.
          </p>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            disabled={isExporting}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-50"
            title="Download formatted CSV report"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Exporting...' : 'Export Excel / CSV'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all border border-slate-700 flex items-center gap-2 cursor-pointer"
            title="Print formatted executive briefing"
          >
            <Printer className="w-4 h-4 text-slate-300" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Filter & Horizon Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Branch / Campus Filter */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
            <Building2 className="w-4 h-4 text-blue-500" />
            <span>Campus:</span>
          </div>
          <select
            value={selectedBranchId}
            onChange={(e) => setSelectedBranchId(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 font-semibold focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Campuses ({branches.length} Locations)</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 hidden sm:block" />

          {/* Time Range Selector */}
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
            <Calendar className="w-4 h-4 text-indigo-500" />
            <span>Timeframe:</span>
          </div>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(['30d', '90d', '1y', 'all'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                  timeRange === r
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {r === '30d' ? '30 Days' : r === '90d' ? 'Quarter' : r === '1y' ? '1 Year' : 'All-Time'}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Category Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'demographics', label: 'Demographics', icon: Users },
            { id: 'attendance', label: 'Attendance', icon: Activity },
            { id: 'giving', label: 'Stewardship', icon: DollarSign },
            { id: 'pastoral', label: 'Pastoral Care', icon: Heart },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as ReportTab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: EXECUTIVE OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Metric Indicators */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Total Active Roster
                </span>
                <div className="p-2.5 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded-xl">
                  <Users className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-2xl font-bold text-slate-900 dark:text-white">
                  {totalMembers}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {activeMembers} active members across {branches.length} campuses
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Weekly Worship Peak
                </span>
                <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl">
                  <Activity className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-2xl font-bold text-slate-900 dark:text-white">{weeklyWorshipPeak}</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">{attendanceSessions.length} recorded sessions</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Ministry Budget
                </span>
                <div className="p-2.5 bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 rounded-xl">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-2xl font-bold text-slate-900 dark:text-white">{totalMinistryBudget.toLocaleString()}</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Allocated across {ministries.length} ministries</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Pastoral Care Volume
                </span>
                <div className="p-2.5 bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 rounded-xl">
                  <Heart className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-2xl font-bold text-slate-900 dark:text-white">
                  {visitationsCompletedCount + prayerResolvedCount}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {prayerResolvedCount} answered prayers & {visitationsCompletedCount} home visits
              </p>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 6-Month Attendance Growth */}
            <div className="lg:col-span-2 p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    Attendance vs Target Trajectory
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Monthly verified service attendance compared with pastoral goals
                  </p>
                </div>
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded-lg">
                  Trending Up
                </span>
              </div>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={attendanceMonthlyTrend}>
                    <defs>
                      <linearGradient id="attendanceGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2563eb" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                    <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderRadius: '12px',
                        border: '1px solid #1e293b',
                        color: '#f8fafc',
                        fontSize: '12px',
                      }}
                    />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="attendance"
                      name="Actual Attendance"
                      stroke="#2563eb"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#attendanceGradient)"
                    />
                    <Line
                      type="monotone"
                      dataKey="target"
                      name="Target Milestone"
                      stroke="#10b981"
                      strokeWidth={2}
                      strokeDasharray="4 4"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Demographic Distribution Pie */}
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Congregation Age Cohorts
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                  Generational balance across selected campus
                </p>

                <div className="h-48 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPie>
                      <Pie
                        data={demographicCohorts}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={75}
                        paddingAngle={4}
                        dataKey="count"
                      >
                        {demographicCohorts.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                {demographicCohorts.map((c) => (
                  <div key={c.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }} />
                      <span className="text-slate-600 dark:text-slate-400">{c.name}</span>
                    </div>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">{c.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DEMOGRAPHICS */}
      {activeTab === 'demographics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                Generational Demographic Cohort Breakdown
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
                Active member count categorised by age brackets and ministry life stages
              </p>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={demographicCohorts}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.5} />
                    <XAxis dataKey="name" fontSize={11} stroke="#94a3b8" />
                    <YAxis fontSize={12} stroke="#94a3b8" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderRadius: '12px',
                        border: '1px solid #1e293b',
                        color: '#f8fafc',
                      }}
                    />
                    <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Quick Cohort Summary Card */}
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Spiritual Milestones
              </h3>
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-500" />
                    <span className="text-slate-700 dark:text-slate-300">Water Baptized</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {baptizedMembers} ({totalMembers > 0 ? Math.round((baptizedMembers / totalMembers) * 100) : 0}%)
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-blue-500" />
                    <span className="text-slate-700 dark:text-slate-300">Enrolled in Ministries</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {ministries.reduce((acc, m) => acc + (m.memberCount || 0), 0)}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-500" />
                    <span className="text-slate-700 dark:text-slate-300">Total Households</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {families.length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ATTENDANCE */}
      {activeTab === 'attendance' && (
        <div className="space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
              Multi-Service Attendance Trajectory & Reliability Rate
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
              Track attendance across Sunday First Service, Second Worship, and Wednesday Midweek teachings
            </p>

            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={attendanceMonthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.5} />
                  <XAxis dataKey="month" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderRadius: '12px',
                      border: '1px solid #1e293b',
                      color: '#f8fafc',
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="attendance" name="Verified Attendance" stroke="#2563eb" strokeWidth={3} />
                  <Line type="monotone" dataKey="target" name="Campus Target" stroke="#10b981" strokeWidth={2} strokeDasharray="4 4" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: GIVING & STEWARDSHIP */}
      {activeTab === 'giving' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                Stewardship Contribution Distribution
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                Allocation between general tithes, missionary commitments, and physical capital
              </p>

              <div className="space-y-4 pt-2">
                {financialSummary.map((f) => (
                  <div key={f.category} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-slate-700 dark:text-slate-300">{f.category}</span>
                      <span className="font-mono text-slate-900 dark:text-white">
                        ${f.amount.toLocaleString()} ({f.percentage}%)
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${f.percentage}%`, backgroundColor: f.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                  Budget Compliance
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                  Current monthly operational run-rate against projected target
                </p>
                <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200 space-y-2">
                  <div className="flex items-center justify-between font-bold">
                    <span>Allocated Budget:</span>
                    <span className="font-mono">{totalMinistryBudget.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between font-bold">
                    <span>Spent Budget:</span>
                    <span className="font-mono text-emerald-600 dark:text-emerald-400">
                      {ministries.reduce((acc, m) => acc + (m.budgetSpent || 0), 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 flex items-center justify-between">
                <span>Certified by Finance Committee</span>
                <span className="text-emerald-600 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> In Good Standing
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: PASTORAL CARE */}
      {activeTab === 'pastoral' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Home Visitations
              </span>
              <p className="text-2xl font-bold text-slate-900 dark:text-white mt-2">
                {visitationsCompletedCount}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Visits completed by elder care team</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Counseling Sessions
              </span>
              <p className="text-2xl font-bold text-slate-900 dark:text-white mt-2">
                {counselingCompletedCount}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Pre-marital & pastoral appointments</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Answered Prayers
              </span>
              <p className="text-2xl font-bold text-emerald-600 mt-2">
                {prayerResolvedCount}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Documented testimonies of answered prayer</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportsModule;
