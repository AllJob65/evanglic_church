import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCMMS } from '../context/CMMSContext';
import { useBible } from '../context/BibleContext';
import { BibleScriptureViewer } from './bible/BibleScriptureViewer';
import { BibleBookChapterPickerModal } from './bible/BibleBookChapterPickerModal';
import { BiblePassage } from './bible/BiblePassage';
import { BibleMultiVerseActionBar } from './bible/BibleMultiVerseActionBar';
import {
  BookOpen,
  Search,
  Sliders,
  ChevronLeft,
  ChevronRight,
  Bookmark,
  FileText,
  Lock,
  RefreshCw,
  AlertCircle,
  Copy,
  Check,
  Share2,
  Trash2,
  ExternalLink,
  BookMarked,
  Sparkles,
  Send,
  X,
} from 'lucide-react';
import { BIBLE_CANON, BibleBookInfo } from '../data/bibleCanon';
import { BibleVerseItem, BibleChapterData } from '../data/bibleData';
import { bibleService } from '../services/bibleService';
import { devotionService } from '../services/devotionService';
import { BibleBookmark, DevotionStatus } from '../types';

export const BibleView: React.FC = () => {
  const navigate = useNavigate();
  const { language, currentUser } = useCMMS();
  const {
    selectedVersionId,
    setSelectedVersionId,
    selectedSlotKey,
    setSelectedSlotKey,
    userVisibleBibles,
    otherAvailableBibles,
    configuredSlots,
    refreshUserBibles,
    currentBook,
    setCurrentBook,
    currentChapter,
    setCurrentChapter,
    jumpToReference,
  } = useBible();

  const userId = (currentUser as any)?.id || currentUser?.memberId || currentUser?.email || 'authenticated-member';
  const isPastorOrAdmin = currentUser?.role === 'PASTOR' || currentUser?.role === 'SYSTEM_ADMIN';
  const isSystemAdmin = currentUser?.role === 'SYSTEM_ADMIN';

  // Primary Navigation Tabs
  const [activeTab, setActiveTab] = useState<'reader' | 'search' | 'marks' | 'admin'>('reader');
  const [marksSubTab, setMarksSubTab] = useState<'bookmarks' | 'highlights' | 'notes'>('bookmarks');

  // System Admin Translation Management State
  const [adminCatalog, setAdminCatalog] = useState<any[]>([]);
  const [adminSlots, setAdminSlots] = useState<any[]>([]);
  const [adminConfigState, setAdminConfigState] = useState<any>(null);
  const [isLoadingAdminCatalog, setIsLoadingAdminCatalog] = useState(false);
  const [adminSearchFilter, setAdminSearchFilter] = useState('');
  const [adminLangFilter, setAdminLangFilter] = useState('ALL');
  const [adminStatusMsg, setAdminStatusMsg] = useState<string | null>(null);

  const loadAdminTranslationCatalog = useCallback(async (fresh = false) => {
    if (!isSystemAdmin) return;
    setIsLoadingAdminCatalog(true);
    try {
      const res = await bibleService.getAdminBibleTranslations(fresh);
      setAdminCatalog(res.allYouVersionBibles || []);
      setAdminSlots(res.configuredSlots || []);
      setAdminConfigState(res.adminConfig || null);
    } catch (err) {
      console.warn('[BibleView] Failed to load admin translation catalog:', err);
    } finally {
      setIsLoadingAdminCatalog(false);
    }
  }, [isSystemAdmin]);

  useEffect(() => {
    if (activeTab === 'admin' && isSystemAdmin && adminCatalog.length === 0) {
      loadAdminTranslationCatalog(false);
    }
  }, [activeTab, isSystemAdmin, adminCatalog.length, loadAdminTranslationCatalog]);

  const handleAdminUpdateConfig = async (payload: any) => {
    try {
      const userHeaders = {
        userId,
        userName: currentUser?.name || 'System Admin',
        userRole: currentUser?.role || 'SYSTEM_ADMIN',
      };
      const updated = await bibleService.updateAdminBibleTranslations(userHeaders, payload);
      if (updated?.allYouVersionBibles) setAdminCatalog(updated.allYouVersionBibles);
      if (updated?.configuredSlots) setAdminSlots(updated.configuredSlots);
      if (updated?.adminConfig) setAdminConfigState(updated.adminConfig);
      await refreshUserBibles();
      setAdminStatusMsg('Translation settings saved. Existing Bible study data preserved.');
      setTimeout(() => setAdminStatusMsg(null), 3000);
    } catch (err: any) {
      setAdminStatusMsg(`Error updating translation config: ${err.message || 'Failed'}`);
    }
  };

  // Active selected Bible metadata from userVisibleBibles or otherAvailableBibles
  const activeBibleMeta = useMemo(() => {
    const allChoices = [...userVisibleBibles, ...otherAvailableBibles];
    const bySlot = allChoices.find(
      (b) => b.slotKey === selectedSlotKey && Number(b.id) === Number(selectedVersionId)
    );
    if (bySlot) return bySlot;
    const byId = allChoices.find((b) => Number(b.id) === Number(selectedVersionId));
    if (byId) return byId;
    return userVisibleBibles[0] || {
      id: 111,
      slotKey: 'NIV',
      abbreviation: 'NIV11',
      localized_abbreviation: 'NIV',
      title: 'New International Version 2011',
      localized_title: 'New International Version',
      userDisplayLabel: 'NIV — New International Version',
      language_tag: 'en',
    };
  }, [userVisibleBibles, otherAvailableBibles, selectedSlotKey, selectedVersionId]);

  const selectorCompositeValue = `${activeBibleMeta.slotKey || 'CUSTOM'}:${activeBibleMeta.id}`;

  // Book & Chapter Picker Modal
  const [isBookPickerOpen, setIsBookPickerOpen] = useState(false);

  // Reader Settings & Appearance (Strictly Bible-only — independent of global CMMS themeMode)
  const [fontFamily, setFontFamily] = useState<'serif' | 'sans' | 'mono'>('serif');
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [lineSpacing, setLineSpacing] = useState<'compact' | 'normal' | 'relaxed'>('normal');
  const [readerTheme, setReaderThemeState] = useState<'light' | 'parchment' | 'dark' | 'midnight'>(() => {
    try {
      const saved = localStorage.getItem(`cmms_bible_reader_theme_${userId}`) || localStorage.getItem('cmms_bible_reader_theme');
      if (saved === 'light' || saved === 'parchment' || saved === 'dark' || saved === 'midnight') {
        return saved;
      }
    } catch {}
    return 'light';
  });

  const setReaderTheme = (th: 'light' | 'parchment' | 'dark' | 'midnight') => {
    setReaderThemeState(th);
    try {
      localStorage.setItem(`cmms_bible_reader_theme_${userId}`, th);
      localStorage.setItem('cmms_bible_reader_theme', th);
    } catch {}
  };
  const [translationMode, setTranslationMode] = useState<'Amharic' | 'English' | 'Parallel'>('Parallel');
  const [viewLayout, setViewLayout] = useState<'verse' | 'paragraph'>('verse');
  const [showSettingsBar, setShowSettingsBar] = useState(false);

  // Authoritative YouVersion Scripture State
  const [chapterData, setChapterData] = useState<BibleChapterData | null>(null);
  const [isLoadingPassage, setIsLoadingPassage] = useState<boolean>(true);
  const [passageError, setPassageError] = useState<string | null>(null);

  // Verse Interaction & Selection
  const [selectedVerses, setSelectedVerses] = useState<BibleVerseItem[]>([]);
  const [activeVerseMenuId, setActiveVerseMenuId] = useState<string | null>(null);

  // Private Note Modal (Strictly User-Private Study Data)
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [activeNoteVerseKey, setActiveNoteVerseKey] = useState<string | null>(null);
  const [activeNoteText, setActiveNoteText] = useState('');
  const [activeNotePassageTitle, setActiveNotePassageTitle] = useState('');

  // Pastor & System Admin Devotional Publishing Modal ("Post to Members")
  const [isDevotionalModalOpen, setIsDevotionalModalOpen] = useState(false);
  const [devotionalTitle, setDevotionalTitle] = useState('');
  const [devotionalTopic, setDevotionalTopic] = useState('Faith & Daily Living');
  const [devotionalMessage, setDevotionalMessage] = useState('');
  const [devotionalPrayer, setDevotionalPrayer] = useState('');
  const [devotionalStatus, setDevotionalStatus] = useState<DevotionStatus>('published');
  const [isPublishingDevotional, setIsPublishingDevotional] = useState(false);
  const [devotionalSuccessMsg, setDevotionalSuccessMsg] = useState<string | null>(null);

  // Personal Bible Study Marks (Strictly scoped to authenticated user ID)
  const [bookmarks, setBookmarks] = useState<BibleBookmark[]>(() => {
    try {
      const saved = localStorage.getItem(`cmms_bible_bookmarks_${userId}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [highlights, setHighlights] = useState<Record<string, 'yellow' | 'green' | 'blue' | 'rose' | 'purple'>>(() => {
    try {
      const saved = localStorage.getItem(`cmms_bible_highlights_${userId}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [notes, setNotes] = useState<Record<string, { note: string; date: string; id?: string }>>(() => {
    try {
      const saved = localStorage.getItem(`cmms_bible_notes_${userId}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Array<{
    reference: string;
    bookName: string;
    chapter: number;
    verseNum: number;
    textEnglish: string;
    textAmharic: string;
  }>>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Book metadata from Canon
  const currentBookInfo: BibleBookInfo = useMemo(() => {
    return (
      BIBLE_CANON.find((b) => b.id.toUpperCase() === currentBook.toUpperCase()) || {
        id: currentBook,
        nameEnglish: currentBook,
        nameAmharic: currentBook,
        shortCode: currentBook,
        testament: 'New',
        category: 'Gospels',
        categoryAmharic: 'ወንጌል',
        chaptersCount: 28,
      }
    );
  }, [currentBook]);

  // Load User Private Marks from Server / Local
  useEffect(() => {
    const userHeaders = {
      userId,
      userName: currentUser?.name || 'Member',
      userRole: currentUser?.role || 'REGULAR_MEMBER',
    };

    // Bookmarks
    bibleService.getUserBookmarks(userHeaders).then((res) => {
      if (res && res.length > 0) {
        setBookmarks(res);
        try { localStorage.setItem(`cmms_bible_bookmarks_${userId}`, JSON.stringify(res)); } catch {}
      }
    }).catch(() => {});

    // Highlights
    bibleService.getUserHighlights(userHeaders).then((res) => {
      if (res && res.length > 0) {
        const mapped: Record<string, 'yellow' | 'green' | 'blue' | 'rose' | 'purple'> = {};
        res.forEach((h) => {
          const key = `${h.bookId}-${h.chapter}-${h.verse}`;
          mapped[key] = (h.color as any) || 'yellow';
        });
        setHighlights(mapped);
        try { localStorage.setItem(`cmms_bible_highlights_${userId}`, JSON.stringify(mapped)); } catch {}
      }
    }).catch(() => {});

    // Notes
    bibleService.getUserNotes(userHeaders).then((res) => {
      if (res && res.length > 0) {
        const mapped: Record<string, { note: string; date: string; id?: string }> = {};
        res.forEach((n) => {
          const key = `${n.bookId}-${n.chapter}-${n.verse || 1}`;
          mapped[key] = { note: n.noteText, date: n.createdAt ? new Date(n.createdAt).toLocaleDateString() : 'Recent', id: n.id };
        });
        setNotes(mapped);
        try { localStorage.setItem(`cmms_bible_notes_${userId}`, JSON.stringify(mapped)); } catch {}
      }
    }).catch(() => {});
  }, [userId, currentUser?.name, currentUser?.role]);

  // FETCH SCRIPTURE STRICTLY FROM YOUVERSION (No local mock database or fake verses)
  const loadYouVersionPassage = useCallback(async () => {
    setIsLoadingPassage(true);
    setPassageError(null);
    try {
      const data = await bibleService.getPassage(currentBook, Number(currentChapter) || 1, String(selectedVersionId));
      if (data && data.verses && data.verses.length > 0) {
        setChapterData(data);
        setPassageError(null);
      } else {
        setChapterData(null);
        setPassageError('Bible content temporarily unavailable — YouVersion service could not be reached. Please check your network connection or try again.');
      }
    } catch {
      setChapterData(null);
      setPassageError('Bible content temporarily unavailable — YouVersion service could not be reached. Please check your network connection or try again.');
    } finally {
      setIsLoadingPassage(false);
    }
  }, [currentBook, currentChapter, selectedVersionId]);

  useEffect(() => {
    loadYouVersionPassage();
    // Record Reading History privately
    bibleService.recordHistory(
      { userId, userName: currentUser?.name || 'Member', userRole: currentUser?.role || 'REGULAR_MEMBER' },
      currentBook,
      currentBookInfo.nameEnglish,
      Number(currentChapter) || 1
    );
  }, [loadYouVersionPassage, currentBook, currentChapter, userId, currentBookInfo.nameEnglish, currentUser?.name, currentUser?.role]);

  // Book & Chapter Navigation
  const handleSelectBookAndChapter = (bookId: string, chapterNum: number) => {
    setCurrentBook(bookId);
    setCurrentChapter(String(chapterNum));
    setIsBookPickerOpen(false);
    setSelectedVerses([]);
    setActiveVerseMenuId(null);
    setActiveTab('reader');
  };

  const handlePrevChapter = () => {
    const prev = Math.max(1, (Number(currentChapter) || 1) - 1);
    setCurrentChapter(String(prev));
    setSelectedVerses([]);
  };

  const handleNextChapter = () => {
    const maxChapters = currentBookInfo.chaptersCount || 50;
    const next = Math.min(maxChapters, (Number(currentChapter) || 1) + 1);
    setCurrentChapter(String(next));
    setSelectedVerses([]);
  };

  // Verse Selection
  const handleToggleSelectVerse = (verse: BibleVerseItem) => {
    const vNum = verse.verse || verse.verseNumber || 1;
    setSelectedVerses((prev) => {
      const exists = prev.some((v) => (v.verse || v.verseNumber) === vNum);
      if (exists) {
        return prev.filter((v) => (v.verse || v.verseNumber) !== vNum);
      } else {
        return [...prev, verse].sort((a, b) => (a.verse || a.verseNumber || 0) - (b.verse || b.verseNumber || 0));
      }
    });
  };

  // Private Bookmark Toggle
  const handleToggleBookmark = (verse: BibleVerseItem) => {
    const vNum = verse.verse || verse.verseNumber || 1;
    const exists = bookmarks.some((b) => b.bookId === currentBook && b.chapter === Number(currentChapter) && b.verse === vNum);
    const userHeaders = { userId, userName: currentUser?.name || 'Member', userRole: currentUser?.role || 'REGULAR_MEMBER' };

    if (exists) {
      const updated = bookmarks.filter((b) => !(b.bookId === currentBook && b.chapter === Number(currentChapter) && b.verse === vNum));
      setBookmarks(updated);
      try { localStorage.setItem(`cmms_bible_bookmarks_${userId}`, JSON.stringify(updated)); } catch {}
      const target = bookmarks.find((b) => b.bookId === currentBook && b.chapter === Number(currentChapter) && b.verse === vNum);
      if (target?.id) bibleService.deleteBookmark(userHeaders, target.id);
    } else {
      const newBm: BibleBookmark = {
        id: `bm-${Date.now()}`,
        userId,
        bookId: currentBook,
        bookNameAmharic: currentBookInfo.nameAmharic,
        bookNameEnglish: currentBookInfo.nameEnglish,
        chapter: Number(currentChapter) || 1,
        verse: vNum,
        verseText: verse.textEnglish || verse.textAmharic || '',
        createdAt: new Date().toISOString(),
      };
      const updated = [newBm, ...bookmarks];
      setBookmarks(updated);
      try { localStorage.setItem(`cmms_bible_bookmarks_${userId}`, JSON.stringify(updated)); } catch {}
      bibleService.toggleBookmark(userHeaders, {
        bookId: currentBook,
        bookNameAmharic: currentBookInfo.nameAmharic,
        bookNameEnglish: currentBookInfo.nameEnglish,
        chapter: Number(currentChapter) || 1,
        verse: vNum,
        verseText: verse.textEnglish || verse.textAmharic || '',
      });
    }
  };

  // Private Highlight Color
  const handleSetHighlightColor = (verseNum: number, color: 'yellow' | 'green' | 'blue' | 'rose' | 'purple' | null) => {
    const key = `${currentBook}-${currentChapter}-${verseNum}`;
    const userHeaders = { userId, userName: currentUser?.name || 'Member', userRole: currentUser?.role || 'REGULAR_MEMBER' };

    setHighlights((prev) => {
      const next = { ...prev };
      if (!color) {
        delete next[key];
      } else {
        next[key] = color;
      }
      try { localStorage.setItem(`cmms_bible_highlights_${userId}`, JSON.stringify(next)); } catch {}
      return next;
    });

    if (color) {
      bibleService.saveHighlight(userHeaders, {
        bookId: currentBook,
        chapter: Number(currentChapter) || 1,
        verse: verseNum,
        color,
      });
    }
  };

  // Open Private Note Modal
  const handleOpenNoteModal = (verseKey: string, initialText: string = '') => {
    const parts = verseKey.split('-');
    const vNum = parts[2] || '1';
    setActiveNoteVerseKey(verseKey);
    setActiveNotePassageTitle(`${currentBookInfo.nameEnglish} ${currentChapter}:${vNum}`);
    setActiveNoteText(notes[verseKey]?.note || initialText);
    setIsNoteModalOpen(true);
  };

  // Save Private Study Note
  const handleSaveNote = () => {
    if (!activeNoteVerseKey || !activeNoteText.trim()) return;
    const parts = activeNoteVerseKey.split('-');
    const bookId = parts[0] || currentBook;
    const chapter = Number(parts[1]) || 1;
    const verse = Number(parts[2]) || 1;
    const userHeaders = { userId, userName: currentUser?.name || 'Member', userRole: currentUser?.role || 'REGULAR_MEMBER' };

    setNotes((prev) => {
      const updated = {
        ...prev,
        [activeNoteVerseKey]: {
          note: activeNoteText.trim(),
          date: new Date().toLocaleDateString(),
          id: prev[activeNoteVerseKey]?.id || `note-${Date.now()}`,
        },
      };
      try { localStorage.setItem(`cmms_bible_notes_${userId}`, JSON.stringify(updated)); } catch {}
      return updated;
    });

    bibleService.saveNote(userHeaders, {
      bookId,
      chapter,
      verse,
      note: activeNoteText.trim(),
      passageTitle: activeNotePassageTitle,
    });

    setIsNoteModalOpen(false);
    setActiveNoteVerseKey(null);
    setActiveNoteText('');
  };

  // Delete Private Study Note
  const handleDeleteNote = (verseKey: string) => {
    const userHeaders = { userId, userName: currentUser?.name || 'Member', userRole: currentUser?.role || 'REGULAR_MEMBER' };
    const noteId = notes[verseKey]?.id;
    setNotes((prev) => {
      const next = { ...prev };
      delete next[verseKey];
      try { localStorage.setItem(`cmms_bible_notes_${userId}`, JSON.stringify(next)); } catch {}
      return next;
    });
    if (noteId) {
      bibleService.deleteNote(userHeaders, noteId);
    }
  };

  // Copy Verse Text
  const handleCopyVerse = (verse: BibleVerseItem) => {
    const vNum = verse.verse || verse.verseNumber || 1;
    const ref = `${currentBookInfo.nameEnglish} ${currentChapter}:${vNum}`;
    const text = `«${verse.textAmharic || ''}»\n"${verse.textEnglish || ''}"\n— ${ref} (${selectedVersionId === 1260 ? 'YouVersion NASV' : 'YouVersion NIV'})`;
    navigator.clipboard?.writeText(text);
  };

  // Share Verse
  const handleShareVerse = async (verse: BibleVerseItem) => {
    const vNum = verse.verse || verse.verseNumber || 1;
    const ref = `${currentBookInfo.nameEnglish} ${currentChapter}:${vNum}`;
    const text = `«${verse.textAmharic || ''}»\n"${verse.textEnglish || ''}"\n— ${ref} (YouVersion)`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({ title: `Holy Bible: ${ref}`, text });
        return;
      } catch {}
    }
    navigator.clipboard?.writeText(text);
  };

  // OPEN "POST TO MEMBERS" DEVOTIONAL PUBLISHING MODAL (Pastor / System Admin Only)
  const handleOpenDevotionalModal = () => {
    if (!isPastorOrAdmin) return;
    const verseNums = selectedVerses.map((v) => v.verse || v.verseNumber || 1).sort((a, b) => a - b);
    const rangeStr = verseNums.length > 1
      ? `${currentBookInfo.nameEnglish} ${currentChapter}:${verseNums[0]}-${verseNums[verseNums.length - 1]}`
      : `${currentBookInfo.nameEnglish} ${currentChapter}:${verseNums[0] || 1}`;

    const combinedText = selectedVerses
      .map((v) => v.textEnglish || v.textAmharic || '')
      .filter(Boolean)
      .join(' ');

    setDevotionalTitle(`Reflection on ${rangeStr}`);
    setDevotionalMessage('');
    setDevotionalPrayer('');
    setDevotionalStatus('published');
    setDevotionalSuccessMsg(null);
    setIsDevotionalModalOpen(true);
  };

  // SUBMIT DEVOTIONAL POST TO MEMBERS (Pastor / System Admin Only)
  const handlePublishDevotional = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isPastorOrAdmin || !devotionalTitle.trim() || !devotionalMessage.trim()) return;

    const verseNums = selectedVerses.map((v) => v.verse || v.verseNumber || 1).sort((a, b) => a - b);
    const rangeStr = verseNums.length > 1
      ? `${currentBookInfo.nameEnglish} ${currentChapter}:${verseNums[0]}-${verseNums[verseNums.length - 1]}`
      : `${currentBookInfo.nameEnglish} ${currentChapter}:${verseNums[0] || 1}`;

    const keyVerseText = selectedVerses
      .map((v) => v.textEnglish || v.textAmharic || '')
      .filter(Boolean)
      .join(' ');

    setIsPublishingDevotional(true);
    try {
      const userHeaders = {
        userId,
        userName: currentUser?.name || 'Pastor',
        userRole: currentUser?.role || 'PASTOR',
      };

      await devotionService.createDevotion(userHeaders, {
        title: devotionalTitle.trim(),
        topic: devotionalTopic,
        scriptureReference: rangeStr,
        keyVerse: keyVerseText,
        body: devotionalMessage.trim(),
        prayer: devotionalPrayer.trim() || undefined,
        status: devotionalStatus,
        publishedAt: devotionalStatus === 'published' ? new Date().toISOString() : undefined,
      });

      setDevotionalSuccessMsg(`Devotional "${devotionalTitle}" posted successfully! It is now live on Members → Daily Devotion.`);
      setSelectedVerses([]);
      setTimeout(() => {
        setIsDevotionalModalOpen(false);
        setDevotionalSuccessMsg(null);
      }, 1800);
    } catch (err: any) {
      alert(`Failed to publish devotional: ${err.message || 'Please check authorization'}`);
    } finally {
      setIsPublishingDevotional(false);
    }
  };

  // Execute Search
  const executeSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const q = searchQuery.trim();
    if (!q) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    try {
      const res = await bibleService.searchScripture(q);
      const mapped = (res || []).map((r) => ({
        reference: `${r.bookEnglish} ${r.chapter}:${r.verseNumber}`,
        bookName: r.bookEnglish,
        chapter: r.chapter,
        verseNum: r.verseNumber,
        textEnglish: r.textEnglish,
        textAmharic: r.textAmharic,
      }));
      setSearchResults(mapped);
    } catch {
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="bible-page w-full min-w-0 space-y-6 max-w-7xl mx-auto">
      {/* 1. QUIET SCRIPTURE HERO BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 sm:p-8 rounded-3xl text-white shadow-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-semibold">
            <BookOpen className="w-3.5 h-3.5 text-blue-400" />
            <span>Scripture Source: YouVersion Platform API (NASV 1260 / NIV 111)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Holy Bible — መጽሐፍ ቅዱስ
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
            Live scripture powered by YouVersion with private personal marks, bookmarks, and pastoral devotional publishing.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowSettingsBar(!showSettingsBar)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all border flex items-center gap-2 cursor-pointer ${
              showSettingsBar
                ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                : 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-slate-200'
            }`}
            title="Toggle Reader Appearance (Font, Size, Theme)"
          >
            <Sliders className="w-4 h-4" />
            <span>Appearance</span>
          </button>

          <button
            type="button"
            onClick={() => setIsBookPickerOpen(true)}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
          >
            <BookMarked className="w-4 h-4" />
            <span>{currentBookInfo.nameEnglish} {currentChapter}</span>
          </button>
        </div>
      </div>

      {/* 2. PRIMARY NAVIGATION TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs font-bold">
        {[
          { id: 'reader', label: 'Scripture Reader', icon: BookOpen },
          { id: 'search', label: 'Passage Search', icon: Search },
          { id: 'marks', label: 'My Private Marks', icon: Bookmark },
          ...(isSystemAdmin ? [{ id: 'admin', label: 'Translation Admin (YouVersion)', icon: Sliders }] : []),
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-2xl flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3. TAB: PURE SCRIPTURE READER */}
      {activeTab === 'reader' && (
        <div className="space-y-4">
          {/* Reader Top Controls Toolbar */}
          <div className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            {/* Left: Prev/Next & Quick Jump */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevChapter}
                disabled={Number(currentChapter) <= 1}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 text-slate-700 dark:text-slate-300 cursor-pointer"
                title="Previous Chapter"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setIsBookPickerOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <span>{currentBookInfo.nameEnglish} {currentChapter}</span>
              </button>

              <button
                type="button"
                onClick={handleNextChapter}
                disabled={Number(currentChapter) >= (currentBookInfo.chaptersCount || 50)}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 text-slate-700 dark:text-slate-300 cursor-pointer"
                title="Next Chapter"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Right: Translation Selector & Layout */}
            <div className="flex items-center gap-2">
              {/* YouVersion Version Selector (Primary translations + More Options for all other available Bible versions) */}
              <select
                value={selectorCompositeValue}
                onChange={(e) => {
                  const val = e.target.value;
                  const [slotPart, idPart] = val.split(':');
                  const nextId = Number(idPart);
                  if (!isNaN(nextId) && nextId > 0) {
                    setSelectedSlotKey(slotPart || 'NIV');
                    setSelectedVersionId(nextId);
                    const allChoices = [...userVisibleBibles, ...otherAvailableBibles];
                    const chosen =
                      allChoices.find((b) => b.slotKey === slotPart && Number(b.id) === nextId) ||
                      allChoices.find((b) => Number(b.id) === nextId);
                    const isAmharicVersion =
                      nextId === 1260 ||
                      slotPart === 'AM05' ||
                      slotPart === 'NASV' ||
                      chosen?.language_tag === 'am';
                    if (isAmharicVersion && translationMode === 'English') {
                      setTranslationMode('Amharic');
                    } else if (!isAmharicVersion && translationMode === 'Amharic') {
                      setTranslationMode('English');
                    }
                  }
                }}
                aria-label="Select Bible Translation"
                className="max-w-[260px] sm:max-w-[320px] px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 cursor-pointer truncate"
              >
                <optgroup label="Primary Translations (Amharic & English)">
                  {userVisibleBibles.map((bible) => {
                    const sKey = bible.slotKey || `CUSTOM_${bible.id}`;
                    const label =
                      bible.userDisplayLabel ||
                      `${bible.localized_abbreviation || bible.abbreviation} — ${bible.localized_title || bible.title}`;
                    return (
                      <option key={`${sKey}:${bible.id}`} value={`${sKey}:${bible.id}`}>
                        {label}
                      </option>
                    );
                  })}
                </optgroup>
                {otherAvailableBibles.length > 0 && (
                  <optgroup label={`More Options — Oromiffa (${otherAvailableBibles.length})`}>
                    {otherAvailableBibles.map((bible) => {
                      const sKey = bible.slotKey || `MORE_${bible.id}`;
                      const label =
                        bible.userDisplayLabel ||
                        `${bible.localized_abbreviation || bible.abbreviation} — ${bible.localized_title || bible.title}`;
                      return (
                        <option key={`${sKey}:${bible.id}`} value={`${sKey}:${bible.id}`}>
                          {label}
                        </option>
                      );
                    })}
                  </optgroup>
                )}
              </select>

              {/* Translation Mode */}
              <div className="flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl">
                {(['Parallel', 'Amharic', 'English'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setTranslationMode(m)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                      translationMode === m
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-bold shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>

              {/* Layout Mode */}
              <div className="hidden md:flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setViewLayout('verse')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer ${
                    viewLayout === 'verse'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Verses
                </button>
                <button
                  type="button"
                  onClick={() => setViewLayout('paragraph')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer ${
                    viewLayout === 'paragraph'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Paragraph
                </button>
              </div>
            </div>
          </div>

          {/* Reader Appearance Customization Bar */}
          {showSettingsBar && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Font Family</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                  {(['serif', 'sans', 'mono'] as const).map((ff) => (
                    <button
                      key={ff}
                      type="button"
                      onClick={() => setFontFamily(ff)}
                      className={`flex-1 py-1 rounded-lg text-xs font-bold capitalize cursor-pointer ${
                        fontFamily === ff ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {ff}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Font Size</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                  {[
                    { id: 'sm', label: 'A-' },
                    { id: 'base', label: 'A' },
                    { id: 'lg', label: 'A+' },
                    { id: 'xl', label: 'A++' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setFontSize(s.id as any)}
                      className={`flex-1 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        fontSize === s.id ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Line Spacing</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                  {[
                    { id: 'compact', label: 'Tight' },
                    { id: 'normal', label: 'Normal' },
                    { id: 'relaxed', label: 'Wide' },
                  ].map((sp) => (
                    <button
                      key={sp.id}
                      type="button"
                      onClick={() => setLineSpacing(sp.id as any)}
                      className={`flex-1 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        lineSpacing === sp.id ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {sp.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Theme Canvas</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                  {[
                    { id: 'light', label: 'Light' },
                    { id: 'parchment', label: 'Sepia' },
                    { id: 'dark', label: 'Dark' },
                    { id: 'midnight', label: 'Night' },
                  ].map((th) => (
                    <button
                      key={th.id}
                      type="button"
                      onClick={() => setReaderTheme(th.id as any)}
                      className={`flex-1 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        readerTheme === th.id ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {th.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* LOADING STATE */}
          {isLoadingPassage && (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Loading Scripture from YouVersion...
              </p>
            </div>
          )}

          {/* TEMPORARILY UNAVAILABLE OUTAGE STATE WITH RETRY BUTTON (Strictly No Fake Verses) */}
          {!isLoadingPassage && passageError && (
            <div className="p-8 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-base text-amber-900 dark:text-amber-100">
                  Bible content temporarily unavailable
                </h3>
                <p className="text-xs text-amber-800 dark:text-amber-300 max-w-md mx-auto">
                  The YouVersion Scripture provider could not load this chapter right now. Please verify your connection or click Retry.
                </p>
              </div>
              <button
                type="button"
                onClick={loadYouVersionPassage}
                className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold inline-flex items-center gap-2 shadow-md cursor-pointer transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry Loading Chapter</span>
              </button>
            </div>
          )}

          {/* SCRIPTURE VIEWER CANVAS (Displayed ONLY when genuine YouVersion data is present) */}
          {!isLoadingPassage && !passageError && chapterData && (
            <div className="min-h-[500px]">
              <BibleScriptureViewer
                currentChapter={chapterData}
                currentBook={currentBookInfo}
                selectedBookId={currentBook}
                selectedChapterNum={Number(currentChapter) || 1}
                translationMode={translationMode}
                viewLayout={viewLayout}
                readerSettings={{
                  fontSize,
                  fontFamily,
                  lineSpacing,
                  theme: readerTheme,
                  preferredVersionId: selectedVersionId,
                  preferredVersionName:
                    activeBibleMeta.userDisplayLabel ||
                    activeBibleMeta.localized_title ||
                    activeBibleMeta.title ||
                    'New International Version',
                  preferredVersionAbbreviation:
                    activeBibleMeta.slotKey === 'AM05'
                      ? 'አማ05'
                      : activeBibleMeta.localized_abbreviation || activeBibleMeta.abbreviation || 'NIV',
                  preferredLanguage: translationMode,
                  showVerseNumbers: true,
                  showFootnotes: false,
                  showCrossReferences: false,
                  showRedLetters: true,
                  readingWidth: 'standard',
                  rememberReadingPosition: true,
                  trackReadingHistory: true,
                  enableNotes: true,
                  enableHighlights: true,
                  enableBookmarks: true,
                }}
                fontSizePx={fontSize === 'sm' ? 14 : fontSize === 'base' ? 16 : fontSize === 'lg' ? 18 : 20}
                lineSpacing={lineSpacing}
                readerTheme={readerTheme}
                showRedLetters={true}
                highlights={highlights}
                bookmarks={bookmarks}
                notes={notes}
                selectedVerses={selectedVerses}
                onToggleSelectVerse={handleToggleSelectVerse}
                activeVerseMenuId={activeVerseMenuId}
                setActiveVerseMenuId={setActiveVerseMenuId}
                currentSpokenVerseNum={null}
                onSetHighlightColor={handleSetHighlightColor}
                onToggleBookmarkVerse={handleToggleBookmark}
                onOpenNoteModalForVerse={(vKey) => handleOpenNoteModal(vKey)}
                onDeleteNote={handleDeleteNote}
                onShareVerse={handleShareVerse}
                onCopyVerse={handleCopyVerse}
                onBroadcastVerse={() => {}}
                onPrevChapter={handlePrevChapter}
                onNextChapter={handleNextChapter}
              />
            </div>
          )}
        </div>
      )}

      {/* 4. TAB: PASSAGE SEARCH (Respects isolated Bible readerTheme) */}
      {activeTab === 'search' && (
        <div
          data-bible-theme={readerTheme}
          className={`bible-scripture-canvas ${
            readerTheme === 'dark' || readerTheme === 'midnight'
              ? 'bible-canvas-dark dark bg-slate-900 text-slate-100 border-slate-800'
              : readerTheme === 'parchment'
              ? 'bible-canvas-parchment bg-amber-50 text-stone-900 border-amber-200/80'
              : 'bible-canvas-light bg-white text-slate-900 border-slate-200'
          } rounded-3xl border shadow-sm p-4 sm:p-6 space-y-4`}
        >
          <form onSubmit={executeSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search scripture reference e.g. John 3:16, Romans 8:28, Psalm 23..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer shadow-md disabled:opacity-50"
            >
              {isSearching ? 'Searching...' : 'Search'}
            </button>
          </form>

          {/* Search Results */}
          <div className="space-y-3 pt-2">
            {searchResults.length === 0 && searchQuery.trim() && !isSearching && (
              <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                No verses found matching "{searchQuery}". Try a scripture reference like "John 3:16" or "Psalm 23".
              </div>
            )}

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {searchResults.map((result, idx) => (
                <div key={idx} className="py-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-black">
                      {result.reference}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        jumpToReference(`${result.bookName}.${result.chapter}.${result.verseNum}`);
                        setActiveTab('reader');
                      }}
                      className="px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Read in Reader</span>
                    </button>
                  </div>
                  {result.textEnglish && (
                    <p className="text-xs font-serif text-slate-800 dark:text-slate-100 leading-relaxed italic">
                      "{result.textEnglish}"
                    </p>
                  )}
                  {result.textAmharic && (
                    <p className="text-xs font-serif text-slate-600 dark:text-slate-300 leading-relaxed">
                      "{result.textAmharic}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5B. TAB: SYSTEM ADMIN TRANSLATION MANAGEMENT (Complete YouVersion /v1/bibles Catalog) */}
      {activeTab === 'admin' && isSystemAdmin && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-blue-600" />
                <span>YouVersion Bible Translation Management (System Admin)</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Complete paginated YouVersion <code className="font-mono">/v1/bibles</code> catalog ({adminCatalog.length} versions). Disabling a translation never deletes or modifies Bible study data.
              </p>
            </div>
            <button
              type="button"
              onClick={() => loadAdminTranslationCatalog(true)}
              disabled={isLoadingAdminCatalog}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAdminCatalog ? 'animate-spin' : ''}`} />
              <span>Sync Paginated /v1/bibles</span>
            </button>
          </div>

          {adminStatusMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold">
              {adminStatusMsg}
            </div>
          )}

          {/* Section 1: Selected CMMS User Translations (Amharic excluding አማ2000/አማ54/መቅካእኤ + English ESV, NIV, CSB, NLT) */}
          <div className="space-y-3">
            <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
              1. Selected CMMS User Translations (Amharic [Excl. አማ2000, አማ54, መቅካእኤ] & English [ESV, NIV, CSB, NLT])
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {(adminSlots.length > 0 ? adminSlots : configuredSlots)
                .filter((slot: any) => Boolean(slot.youversionBibleId))
                .map((slot: any) => {
                const isMatched = Boolean(slot.youversionBibleId);
                return (
                  <div
                    key={slot.slotKey}
                    className={`p-4 rounded-2xl border space-y-2.5 ${
                      isMatched
                        ? 'bg-slate-50 dark:bg-slate-800/70 border-slate-200 dark:border-slate-700'
                        : 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200/70 dark:border-amber-800/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[11px] font-black">
                          Slot #{slot.displayOrder}: {slot.requestedAbbreviation}
                        </span>
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white mt-1">
                          {slot.matchedLocalizedTitle || slot.matchedTitle || slot.requestedTitle}
                        </h4>
                      </div>
                      <label className="inline-flex items-center gap-1.5 text-xs font-bold cursor-pointer">
                        <input
                          type="checkbox"
                          checked={Boolean(slot.enabled)}
                          onChange={(e) =>
                            handleAdminUpdateConfig({
                              toggleSlotKey: slot.slotKey,
                              toggleEnabled: e.target.checked,
                            })
                          }
                          className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span>{slot.enabled ? 'Enabled' : 'Disabled'}</span>
                      </label>
                    </div>

                    <div className="text-[11px] space-y-1 text-slate-600 dark:text-slate-300">
                      <p>
                        <strong>YouVersion ID:</strong>{' '}
                        {slot.youversionBibleId ? (
                          <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                            {slot.youversionBibleId}
                          </span>
                        ) : (
                          <span className="text-amber-600 dark:text-amber-400 font-semibold">
                            Unmatched in current API key
                          </span>
                        )}
                      </p>
                      {slot.youversionBibleId && (
                        <>
                          <p>
                            <strong>API Title:</strong> {slot.matchedTitle}
                          </p>
                          <p>
                            <strong>Localized Title:</strong> {slot.matchedLocalizedTitle}
                          </p>
                          <p>
                            <strong>API Abbr / Localized:</strong> {slot.matchedAbbreviation} /{' '}
                            {slot.matchedLocalizedAbbreviation}
                          </p>
                        </>
                      )}
                    </div>

                    {slot.youversionBibleId && (
                      <div className="flex items-center gap-2 pt-1 border-t border-slate-200/70 dark:border-slate-700/70 text-[11px]">
                        <button
                          type="button"
                          onClick={() =>
                            handleAdminUpdateConfig({ defaultBibleId: Number(slot.youversionBibleId) })
                          }
                          className={`px-2 py-1 rounded-lg font-bold cursor-pointer ${
                            Number(adminConfigState?.defaultBibleId) === Number(slot.youversionBibleId)
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          Default Bible
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleAdminUpdateConfig({ featuredBibleId: Number(slot.youversionBibleId) })
                          }
                          className={`px-2 py-1 rounded-lg font-bold cursor-pointer ${
                            Number(adminConfigState?.featuredBibleId) === Number(slot.youversionBibleId)
                              ? 'bg-amber-500 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          Featured
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 2: Complete Paginated YouVersion Catalog for Future Admin Selection */}
          <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
                2. Complete YouVersion API Catalog ({adminCatalog.length} Bibles)
              </h3>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={adminSearchFilter}
                  onChange={(e) => setAdminSearchFilter(e.target.value)}
                  placeholder="Filter by ID, abbreviation, title, language..."
                  className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                />
                <select
                  value={adminLangFilter}
                  onChange={(e) => setAdminLangFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                >
                  <option value="ALL">All Languages</option>
                  <option value="en">English (en)</option>
                  <option value="am">Amharic (am)</option>
                </select>
              </div>
            </div>

            <div className="max-h-96 overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {adminCatalog
                .filter((b) => {
                  if (adminLangFilter !== 'ALL' && !String(b.language_tag || '').startsWith(adminLangFilter)) {
                    return false;
                  }
                  if (!adminSearchFilter.trim()) return true;
                  const q = adminSearchFilter.toLowerCase();
                  return (
                    String(b.id).includes(q) ||
                    String(b.abbreviation || '').toLowerCase().includes(q) ||
                    String(b.localized_abbreviation || '').toLowerCase().includes(q) ||
                    String(b.title || '').toLowerCase().includes(q) ||
                    String(b.localized_title || '').toLowerCase().includes(q) ||
                    String(b.language_tag || '').toLowerCase().includes(q)
                  );
                })
                .slice(0, 100)
                .map((b) => (
                  <div
                    key={b.id}
                    className="p-3 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/40"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-blue-600 dark:text-blue-400">
                          ID: {b.id}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-bold">
                          {b.localized_abbreviation || b.abbreviation}
                        </span>
                        <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                          {b.language_tag}
                        </span>
                      </div>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">
                        {b.localized_title || b.title}{' '}
                        {b.localized_title && b.title && b.localized_title !== b.title
                          ? `(${b.title})`
                          : ''}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        handleAdminUpdateConfig({
                          toggleBibleId: Number(b.id),
                          toggleEnabled: !b.enabled,
                        })
                      }
                      className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer ${
                        b.enabled
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {b.enabled ? 'Enabled for Users' : 'Enable'}
                    </button>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. TAB: MY PRIVATE MARKS (STRICTLY PRIVATE TO USER) */}
      {activeTab === 'marks' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Bookmark className="w-5 h-5 text-blue-600" />
                <span>የእኔ የግል ማስታወሻና ዕልባቶች (My Personal Marks)</span>
              </h2>
              <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-0.5">
                <Lock className="w-3.5 h-3.5" />
                <span>Strictly private to your account ({currentUser?.email || 'You'})</span>
              </div>
            </div>

            {/* Sub-tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setMarksSubTab('bookmarks')}
                className={`px-3 py-1.5 rounded-xl cursor-pointer transition-colors ${
                  marksSubTab === 'bookmarks' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-xs' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Bookmarks ({bookmarks.length})
              </button>
              <button
                type="button"
                onClick={() => setMarksSubTab('highlights')}
                className={`px-3 py-1.5 rounded-xl cursor-pointer transition-colors ${
                  marksSubTab === 'highlights' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-xs' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Highlights ({Object.keys(highlights).length})
              </button>
              <button
                type="button"
                onClick={() => setMarksSubTab('notes')}
                className={`px-3 py-1.5 rounded-xl cursor-pointer transition-colors ${
                  marksSubTab === 'notes' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-xs' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Private Notes ({Object.keys(notes).length})
              </button>
            </div>
          </div>

          {/* Bookmarks */}
          {marksSubTab === 'bookmarks' && (
            <div className="space-y-3">
              {bookmarks.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  You have not bookmarked any verses yet. Select verses in the reader and click Bookmark.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {bookmarks.map((bm) => (
                    <div
                      key={bm.id}
                      className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3"
                    >
                      <div
                        className="cursor-pointer"
                        onClick={() => {
                          jumpToReference(`${bm.bookId}.${bm.chapter}.${bm.verse}`);
                          setActiveTab('reader');
                        }}
                      >
                        <p className="text-sm font-black text-blue-600 dark:text-blue-400 hover:underline">
                          {bm.bookNameEnglish || bm.bookId} {bm.chapter}:{bm.verse}
                        </p>
                        <span className="text-[10px] text-slate-400">{bm.bookNameAmharic}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const userHeaders = { userId, userName: currentUser?.name || 'Member', userRole: currentUser?.role || 'REGULAR_MEMBER' };
                          const updated = bookmarks.filter((b) => b.id !== bm.id);
                          setBookmarks(updated);
                          try { localStorage.setItem(`cmms_bible_bookmarks_${userId}`, JSON.stringify(updated)); } catch {}
                          if (bm.id) bibleService.deleteBookmark(userHeaders, bm.id);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                        title="Remove bookmark"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Highlights */}
          {marksSubTab === 'highlights' && (
            <div className="space-y-3">
              {Object.keys(highlights).length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No highlighted verses yet. Select verses in the reader to apply highlighters.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {Object.entries(highlights).map(([key, color]) => {
                    const parts = key.split('-');
                    return (
                      <div
                        key={key}
                        className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3 cursor-pointer"
                        onClick={() => {
                          jumpToReference(`${parts[0]}.${parts[1]}.${parts[2]}`);
                          setActiveTab('reader');
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <span className={`w-3.5 h-3.5 rounded-full ${color === 'yellow' ? 'bg-amber-400' : color === 'green' ? 'bg-emerald-400' : color === 'blue' ? 'bg-cyan-400' : color === 'rose' ? 'bg-rose-400' : 'bg-purple-400'}`} />
                          <span className="font-bold text-xs text-slate-900 dark:text-white">
                            {parts[0]} {parts[1]}:{parts[2]}
                          </span>
                        </div>
                        <span className="text-[11px] text-blue-600 dark:text-blue-400 font-bold">Read</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Private Notes */}
          {marksSubTab === 'notes' && (
            <div className="space-y-3">
              {Object.keys(notes).length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No private study notes yet. Click on any verse in the reader and select "Private Note".
                </div>
              ) : (
                <div className="space-y-3">
                  {Object.entries(notes).map(([key, val]) => {
                    const parts = key.split('-');
                    return (
                      <div
                        key={key}
                        className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-black text-xs">
                              {parts[0]} {parts[1]}:{parts[2]}
                            </span>
                            <span className="text-[10px] text-slate-400">{val.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleOpenNoteModal(key, val.note)}
                              className="px-2.5 py-1 text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline cursor-pointer"
                            >
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteNote(key)}
                              className="p-1 text-slate-400 hover:text-rose-500 cursor-pointer"
                              title="Delete note"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                          {val.note}
                        </p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 6. MULTI-VERSE ACTION BAR (With Pastor/Admin "Post to Members" Action) */}
      <BibleMultiVerseActionBar
        selectedVerses={selectedVerses}
        currentBook={currentBookInfo}
        chapterNumber={Number(currentChapter) || 1}
        onClearSelection={() => setSelectedVerses([])}
        onOpenNoteModal={() => {
          if (selectedVerses.length > 0) {
            const vNum = selectedVerses[0].verse || selectedVerses[0].verseNumber || 1;
            handleOpenNoteModal(`${currentBook}-${currentChapter}-${vNum}`);
          }
        }}
        onPostDevotionalToMembers={handleOpenDevotionalModal}
        isPastorOrAdmin={isPastorOrAdmin}
        onBookmarkVerses={() => {
          selectedVerses.forEach((v) => handleToggleBookmark(v));
          setSelectedVerses([]);
        }}
        onApplyHighlight={(color) => {
          selectedVerses.forEach((v) => {
            const vNum = v.verse || v.verseNumber || 1;
            handleSetHighlightColor(vNum, color);
          });
          setSelectedVerses([]);
        }}
        onCopySelected={() => {
          const combined = selectedVerses
            .map((v) => `[${v.verse || v.verseNumber}] ${v.textEnglish || v.textAmharic}`)
            .join('\n');
          navigator.clipboard?.writeText(`${currentBookInfo.nameEnglish} ${currentChapter}\n${combined}`);
        }}
        onShareSelected={() => {
          if (selectedVerses.length > 0) handleShareVerse(selectedVerses[0]);
        }}
      />

      {/* 7. PRIVATE STUDY NOTE MODAL (Strictly Private to Current User) */}
      {isNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span>Private Study Note</span>
                </h3>
                <div className="flex items-center gap-1 text-[11px] text-emerald-600 font-semibold">
                  <Lock className="w-3 h-3" />
                  <span>Confidential to your account only — Never shared publicly</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsNoteModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900/40 text-xs font-bold text-blue-900 dark:text-blue-300">
              {activeNotePassageTitle}
            </div>

            <textarea
              value={activeNoteText}
              onChange={(e) => setActiveNoteText(e.target.value)}
              placeholder="Write your personal reflections, sermon takeaways, or study notes..."
              rows={5}
              className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsNoteModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveNote}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer"
              >
                Save Private Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. POST TO MEMBERS: CHURCH DAILY DEVOTIONAL MODAL (PASTOR & SYSTEM_ADMIN ONLY) */}
      {isDevotionalModalOpen && isPastorOrAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-500" />
                  <span>Post Church Daily Devotional</span>
                </h3>
                <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                  Pastor & System Admin Publishing · Appears in Members → Daily Devotion
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsDevotionalModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {devotionalSuccessMsg ? (
              <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-center space-y-2">
                <Check className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="text-xs font-bold">{devotionalSuccessMsg}</p>
              </div>
            ) : (
              <form onSubmit={handlePublishDevotional} className="space-y-3.5 text-xs">
                {/* Scripture Anchor Information */}
                <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                  <span className="text-[10px] font-black uppercase text-slate-400">Selected Scripture Passage</span>
                  <div className="text-xs font-bold text-blue-600 dark:text-blue-400">
                    {selectedVerses.length > 0
                      ? `${currentBookInfo.nameEnglish} ${currentChapter}:${selectedVerses.map((v) => v.verse || v.verseNumber || 1).join(', ')}`
                      : `${currentBookInfo.nameEnglish} ${currentChapter}`}
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 italic line-clamp-3">
                    "{selectedVerses.map((v) => v.textEnglish || v.textAmharic).join(' ')}"
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Devotional Title *
                  </label>
                  <input
                    type="text"
                    value={devotionalTitle}
                    onChange={(e) => setDevotionalTitle(e.target.value)}
                    required
                    placeholder="e.g. Walking by Faith in Times of Transition"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Spiritual Topic
                  </label>
                  <select
                    value={devotionalTopic}
                    onChange={(e) => setDevotionalTopic(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-semibold"
                  >
                    <option value="Faith & Daily Living">Faith & Daily Living</option>
                    <option value="Prayer & Fasting">Prayer & Fasting</option>
                    <option value="Love & Fellowship">Love & Fellowship</option>
                    <option value="Discipleship & Service">Discipleship & Service</option>
                    <option value="Wisdom & Guidance">Wisdom & Guidance</option>
                    <option value="Grace & Redemption">Grace & Redemption</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Pastoral Message / Reflection *
                  </label>
                  <textarea
                    value={devotionalMessage}
                    onChange={(e) => setDevotionalMessage(e.target.value)}
                    required
                    rows={4}
                    placeholder="Write the church devotional message, pastoral guidance, or application for members..."
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Pastoral Prayer (Optional)
                  </label>
                  <textarea
                    value={devotionalPrayer}
                    onChange={(e) => setDevotionalPrayer(e.target.value)}
                    rows={2}
                    placeholder="Lord, grant our congregation the strength to walk in your truth today..."
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-slate-500">Status:</span>
                    <button
                      type="button"
                      onClick={() => setDevotionalStatus('published')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        devotionalStatus === 'published' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      Publish Immediately
                    </button>
                    <button
                      type="button"
                      onClick={() => setDevotionalStatus('draft')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        devotionalStatus === 'draft' ? 'bg-amber-600 text-white' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      Save as Draft
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsDevotionalModalOpen(false)}
                      className="px-4 py-2 rounded-xl text-slate-500 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isPublishingDevotional}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold shadow-md cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isPublishingDevotional ? 'Publishing...' : 'Publish to Members'}</span>
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 9. BOOK & CHAPTER PICKER MODAL */}
      <BibleBookChapterPickerModal
        isOpen={isBookPickerOpen}
        onClose={() => setIsBookPickerOpen(false)}
        selectedBookId={currentBook}
        selectedChapterNum={Number(currentChapter) || 1}
        onSelectBookAndChapter={handleSelectBookAndChapter}
      />
    </div>
  );
};

export default BibleView;
