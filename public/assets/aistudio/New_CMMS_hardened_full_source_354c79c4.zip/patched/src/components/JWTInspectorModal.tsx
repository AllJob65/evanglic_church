import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Key,
  ShieldCheck,
  Lock,
  Copy,
  Check,
  X,
  Code,
  Terminal,
  Database,
  Building2,
  Cpu,
  Sparkles
} from 'lucide-react';

interface JWTInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JWTInspectorModal: React.FC<JWTInspectorModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, activeRole, permissions, selectedBranchId, branches } = useCMMS();
  const [copied, setCopied] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);

  if (!isOpen) return null;

  const currentBranch = branches.find((b) => b.id === selectedBranchId) || {
    id: selectedBranchId || '',
    name: 'No Branch Selected'
  };

  const userName = currentUser?.name || 'Authenticated User';
  const userEmail = currentUser?.email || '';
  const userId = currentUser?.memberId || '';

  // Construct realistic JWT token representation
  const headerObj = {
    alg: 'HS256',
    typ: 'JWT',
    kid: 'cmms-auth-key-v1'
  };

  const payloadObj = {
    sub: userId,
    name: userName,
    email: userEmail,
    role: activeRole,
    tenant_context: {
      church_id: 'church-grace-cathedral-global',
      branch_id: selectedBranchId === 'all' ? '*' : selectedBranchId,
      branch_name: selectedBranchId === 'all' ? 'All Campuses (Super Admin)' : currentBranch.name,
      tenant_isolation_mode: 'ROW_LEVEL_SECURITY'
    },
    permissions: permissions,
    iss: 'cmms.auth.engine',
    aud: 'cmms.frontend.applet',
    iat: Math.floor(Date.now() / 1000) - 120,
    exp: Math.floor(Date.now() / 1000) + 86400,
    jti: 'jwt-claim-' + Math.random().toString(36).substring(2, 9)
  };

  const b64Header = btoa(JSON.stringify(headerObj));
  const b64Payload = btoa(JSON.stringify(payloadObj));
  const fakeSig = 'SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
  const simulatedJwt = `${b64Header}.${b64Payload}.${fakeSig}`;

  const curlSample = `curl -X GET "https://api.cmms.internal/api/members" \\
  -H "Authorization: Bearer ${simulatedJwt.slice(0, 40)}..." \\
  -H "X-Tenant-ID: ${selectedBranchId === 'all' ? 'global' : selectedBranchId}" \\
  -H "Content-Type: application/json"`;

  const copyToClipboard = (text: string, isCurl = false) => {
    navigator.clipboard.writeText(text);
    if (isCurl) {
      setCopiedCurl(true);
      setTimeout(() => setCopiedCurl(false), 2000);
    } else {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="jwt-inspector-title"
      className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-3xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-6">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border-b border-blue-500/30 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-400/30">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="jwt-inspector-title" className="text-base sm:text-lg font-black tracking-tight">
                  JWT Authorization & Multi-Tenant Claims Inspector
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Signature Valid
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Stateless token containing signed user scope, tenant context (church_id) and RBAC permissions.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close JWT Inspector"
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Tenant Isolation Guard Badge */}
          <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 flex items-start gap-3 text-xs">
            <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-blue-900 dark:text-blue-200">
                Multi-Tenant Request Interceptor Guard (enforceTenant):
              </span>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                Backend middleware decrypts and verifies this token on every API call, constraining SQL queries to{' '}
                <code className="font-mono bg-blue-100 dark:bg-blue-900 px-1 py-0.5 rounded text-blue-800 dark:text-blue-200">
                  WHERE branch_id = '{selectedBranchId === 'all' ? '*' : selectedBranchId}'
                </code>.
              </p>
            </div>
          </div>

          {/* Decoded Claims Tabs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Header Claims */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-rose-600 dark:text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5" />
                  Header: Algorithm & Type
                </span>
                <span className="text-[10px] font-mono text-slate-400">JOSE Header</span>
              </div>
              <pre className="text-xs font-mono bg-slate-900 text-rose-300 p-3 rounded-lg overflow-x-auto">
                {JSON.stringify(headerObj, null, 2)}
              </pre>
            </div>

            {/* Signature Block */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-cyan-600 dark:text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  HMACSHA256 Signature
                </span>
                <span className="text-[10px] font-mono text-emerald-500 font-bold">256-bit Secret</span>
              </div>
              <pre className="text-xs font-mono bg-slate-900 text-cyan-300 p-3 rounded-lg overflow-x-auto whitespace-pre-wrap break-all">
                HMACSHA256(
                  base64UrlEncode(header) + "." +
                  base64UrlEncode(payload),
                  [Server-Side Secret Key]
                )
              </pre>
            </div>
          </div>

          {/* Payload Data Claims */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-purple-600 dark:text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5" />
                Decoded Payload Claims (RBAC Scope & Tenant Key)
              </span>
              <button
                onClick={() => copyToClipboard(JSON.stringify(payloadObj, null, 2))}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Claims JSON'}
              </button>
            </div>
            <pre className="text-xs font-mono bg-slate-900 text-purple-300 p-3 rounded-lg overflow-x-auto max-h-56">
              {JSON.stringify(payloadObj, null, 2)}
            </pre>
          </div>

          {/* cURL Authorization Sample */}
          <div className="bg-slate-900 p-4 rounded-xl text-white">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-amber-400 font-bold flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5" />
                API Request with Bearer Token & Tenant Header
              </span>
              <button
                onClick={() => copyToClipboard(curlSample, true)}
                className="text-xs text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                {copiedCurl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCurl ? 'Copied cURL' : 'Copy cURL'}
              </button>
            </div>
            <pre className="text-xs font-mono text-slate-300 bg-slate-950 p-3 rounded-lg overflow-x-auto">
              {curlSample}
            </pre>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Token Expires in 24 hours • Refreshed on activity
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
