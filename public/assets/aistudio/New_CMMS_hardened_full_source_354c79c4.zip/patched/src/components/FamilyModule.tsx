import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Family, Member, Gender } from '../types';
import {
  sanitizeEthiopianPhoneInput,
  validateEthiopianPhone,
} from '../utils/phoneValidation';
import { EthiopianPhoneInput } from './EthiopianPhoneInput';
import { ActionMenu } from './ui/ActionMenu';
import {
  EthiopianDateHelper,
  DEFAULT_MALE_AVATAR,
  DEFAULT_FEMALE_AVATAR,
} from './EthiopianDateHelper';
import {
  Home,
  Plus,
  Heart,
  MapPin,
  X,
  User,
  Search,
  CheckCircle2,
  Edit3,
  Trash2,
  Baby,
  RefreshCw,
  FolderTree,
} from 'lucide-react';

interface ChildFormInput {
  firstName: string;
  middleName?: string;
  lastName: string;
  gender: Gender;
  dateOfBirth: string;
  primaryPhone?: string;
  photoUrl?: string;
}

/**
 * Addis Ababa Sub-Cities
 */
const ADDIS_ABABA_SUB_CITIES = [
  'Bole',
  'Kirkos',
  'Lemi Kura',
  'Addis Ketema',
  'Arada',
  'Gullele',
  'Yeka',
  'Lideta',
  'Nifas Silk-Lafto',
  'Kolfe Keranio',
  'Akaki Kaliti',
] as const;

export const FamilyModule: React.FC = () => {
  const {
    families,
    members,
    branches,
    registerUnifiedHousehold,
    propagateHouseholdAddress,
    updateFamily,
    deleteFamily,
    permissions,
  } = useCMMS();

  const [selectedFamily, setSelectedFamily] = useState<Family | null>(
    families[0] || null
  );

  const [isUnifiedModalOpen, setIsUnifiedModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [successNotice, setSuccessNotice] = useState('');

  // ============================================================
  // EDIT FAMILY STATE
  // ============================================================

  const [editFamilyName, setEditFamilyName] = useState('');
  const [editFamilyType, setEditFamilyType] =
    useState<Family['familyType']>('Nuclear Family');
  const [editPrimaryLang, setEditPrimaryLang] = useState('English');
  const [editAddress, setEditAddress] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editRegion, setEditRegion] = useState('');

  // ============================================================
  // UNIFIED REGISTRATION FORM STATE
  // IMPORTANT:
  // No fake/personal/example data is pre-populated.
  // ============================================================

  const [regBranchId, setRegBranchId] = useState(
    branches[0]?.id || ''
  );

  const [regHouseholdName, setRegHouseholdName] = useState('');
  const [regFamilyType, setRegFamilyType] =
    useState<Family['familyType']>('Nuclear Family');

  const [regPrimaryLanguage, setRegPrimaryLanguage] = useState('');
  const [regSharedPhone, setRegSharedPhone] = useState('');
  const [sharedPhoneError, setSharedPhoneError] = useState('');

  // ============================================================
  // ETHIOPIAN ADDRESS
  // ============================================================

  const [regStreetAddress, setRegStreetAddress] = useState('');
  const [regCity, setRegCity] = useState('');
  const [regSubCity, setRegSubCity] = useState('');
  const [regWoreda, setRegWoreda] = useState('');
  const [regKebele, setRegKebele] = useState('');
  const [regHouseNumber, setRegHouseNumber] = useState('');
  const [regRegion, setRegRegion] = useState('');

  // ============================================================
  // HEAD OF HOUSEHOLD
  // ============================================================

  const [headTitle, setHeadTitle] = useState('');
  const [headFirstName, setHeadFirstName] = useState('');
  const [headMiddleName, setHeadMiddleName] = useState('');
  const [headLastName, setHeadLastName] = useState('');
  const [headGender, setHeadGender] = useState<Gender>('Male');
  const [headDob, setHeadDob] = useState('');
  const [headPhone, setHeadPhone] = useState('');
  const [headOccupation, setHeadOccupation] = useState('');

  // ============================================================
  // SPOUSE
  // ============================================================

  const [includeSpouse, setIncludeSpouse] = useState(false);
  const [spouseTitle, setSpouseTitle] = useState('');
  const [spouseFirstName, setSpouseFirstName] = useState('');
  const [spouseMiddleName, setSpouseMiddleName] = useState('');
  const [spouseLastName, setSpouseLastName] = useState('');
  const [spouseGender, setSpouseGender] = useState<Gender>('Female');
  const [spouseDob, setSpouseDob] = useState('');
  const [spousePhone, setSpousePhone] = useState('');
  const [spouseOccupation, setSpouseOccupation] = useState('');

  // ============================================================
  // CHILDREN
  // ============================================================

  const [childrenList, setChildrenList] = useState<ChildFormInput[]>([]);

  const handleAddChild = () => {
    setChildrenList((previous) => [
      ...previous,
      {
        firstName: '',
        middleName: '',
        lastName: '',
        gender: 'Male',
        dateOfBirth: '',
        primaryPhone: '',
      },
    ]);
  };

  const handleRemoveChild = (index: number) => {
    setChildrenList((previous) =>
      previous.filter((_, idx) => idx !== index)
    );
  };

  const handleChildFieldChange = (
    index: number,
    field: keyof ChildFormInput,
    value: string | Gender
  ) => {
    setChildrenList((previous) => {
      const updated = [...previous];

      updated[index] = {
        ...updated[index],
        [field]: value,
      };

      return updated;
    });
  };

  // ============================================================
  // PHONE HANDLERS
  // ============================================================

  const handleSharedPhoneInput = (val: string) => {
    const sanitized = sanitizeEthiopianPhoneInput(val);

    setRegSharedPhone(sanitized);

    if (!sanitized) {
      setSharedPhoneError('');
      return;
    }

    const check = validateEthiopianPhone(sanitized);

    if (!check.isValid) {
      setSharedPhoneError(
        check.error || 'Invalid Ethiopian phone format'
      );
    } else {
      setSharedPhoneError('');

      if (!headPhone) {
        setHeadPhone(sanitized);
      }
    }
  };

  const handleHeadPhoneInput = (val: string) => {
    setHeadPhone(sanitizeEthiopianPhoneInput(val));
  };

  const handleSpousePhoneInput = (val: string) => {
    setSpousePhone(sanitizeEthiopianPhoneInput(val));
  };

  // ============================================================
  // RESET REGISTRATION FORM
  // ============================================================

  const resetRegistrationForm = () => {
    setRegBranchId(branches[0]?.id || '');

    setRegHouseholdName('');
    setRegFamilyType('Nuclear Family');
    setRegPrimaryLanguage('');

    setRegSharedPhone('');
    setSharedPhoneError('');

    setRegStreetAddress('');
    setRegCity('');
    setRegSubCity('');
    setRegWoreda('');
    setRegKebele('');
    setRegHouseNumber('');
    setRegRegion('');

    setHeadTitle('');
    setHeadFirstName('');
    setHeadMiddleName('');
    setHeadLastName('');
    setHeadGender('Male');
    setHeadDob('');
    setHeadPhone('');
    setHeadOccupation('');

    setIncludeSpouse(false);
    setSpouseTitle('');
    setSpouseFirstName('');
    setSpouseMiddleName('');
    setSpouseLastName('');
    setSpouseGender('Female');
    setSpouseDob('');
    setSpousePhone('');
    setSpouseOccupation('');

    setChildrenList([]);
  };

  // ============================================================
  // EDIT FAMILY
  // ============================================================

  const handleOpenEditModal = (fam: Family) => {
    setEditFamilyName(fam.householdName);
    setEditFamilyType(fam.familyType);
    setEditPrimaryLang(fam.primaryLanguage);
    setEditAddress(fam.address || '');
    setEditCity(fam.city || '');
    setEditRegion(fam.region || '');

    setIsEditModalOpen(true);
  };

  const handleSaveEditFamily = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedFamily || !editFamilyName.trim()) {
      return;
    }

    const updated: Family = {
      ...selectedFamily,
      householdName: editFamilyName.trim(),
      familyType: editFamilyType,
      primaryLanguage: editPrimaryLang,
      address: editAddress.trim(),
      city: editCity.trim(),
      region: editRegion.trim(),
    };

    updateFamily(updated);

    setSelectedFamily(updated);
    setIsEditModalOpen(false);

    setSuccessNotice('Household details updated successfully!');

    setTimeout(() => {
      setSuccessNotice('');
    }, 3000);
  };

  // ============================================================
  // PROPAGATE HOUSEHOLD ADDRESS
  // ============================================================

  const handlePropagateAddress = () => {
    if (!selectedFamily) {
      return;
    }

    const parts = (selectedFamily.address || '')
      .split(',')
      .map((part) => part.trim())
      .filter(Boolean);

    const woredaPart = parts.find((part) =>
      part.toLowerCase().includes('woreda')
    );

    const kebelePart = parts.find((part) =>
      part.toLowerCase().includes('kebele')
    );

    propagateHouseholdAddress(selectedFamily.id, {
      streetAddress: selectedFamily.address || '',
      city: selectedFamily.city || '',
      region: selectedFamily.region || '',
      woreda: woredaPart,
      kebele: kebelePart,
    });

    setSuccessNotice(
      `Address successfully propagated to all ${selectedFamily.memberIds.length} household members!`
    );

    setTimeout(() => {
      setSuccessNotice('');
    }, 3000);
  };

  // ============================================================
  // DELETE FAMILY
  // ============================================================

  const handleDeleteFamily = (id: string, name: string) => {
    if (
      confirm(
        `Are you sure you want to delete household record for ${name}?`
      )
    ) {
      deleteFamily(id);

      if (selectedFamily?.id === id) {
        const nextFamily =
          families.find((family) => family.id !== id) || null;

        setSelectedFamily(nextFamily);
      }
    }
  };

  // ============================================================
  // REGISTER UNIFIED HOUSEHOLD
  // ============================================================

  const handleRegisterUnifiedHousehold = (
    e: React.FormEvent
  ) => {
    e.preventDefault();

    // ----------------------------------------------------------
    // Required fields
    // ----------------------------------------------------------

    if (
      !regHouseholdName.trim() ||
      !headFirstName.trim() ||
      !headLastName.trim()
    ) {
      alert(
        'Please fill in the required Household Name, Head First Name, and Head Last Name.'
      );
      return;
    }

    // ----------------------------------------------------------
    // Shared phone validation
    // ----------------------------------------------------------

    const valResult =
      validateEthiopianPhone(regSharedPhone);

    if (!valResult.isValid) {
      setSharedPhoneError(
        valResult.error ||
          'Please enter a valid Ethiopian phone number.'
      );

      return;
    }

    // ----------------------------------------------------------
    // Head phone validation if independently entered
    // ----------------------------------------------------------

    if (headPhone.trim()) {
      const headPhoneCheck =
        validateEthiopianPhone(headPhone);

      if (!headPhoneCheck.isValid) {
        alert(
          headPhoneCheck.error ||
            'Please enter a valid Ethiopian phone number for the Head of Household.'
        );

        return;
      }
    }

    // ----------------------------------------------------------
    // Spouse validation
    // ----------------------------------------------------------

    if (includeSpouse) {
      if (!spouseFirstName.trim()) {
        alert(
          'Please enter the spouse first name or disable "Include Spouse".'
        );

        return;
      }

      if (spousePhone.trim()) {
        const spouseCheck =
          validateEthiopianPhone(spousePhone);

        if (!spouseCheck.isValid) {
          alert(
            spouseCheck.error ||
              'Please enter a valid Ethiopian phone number for the spouse.'
          );

          return;
        }
      }
    }

    // ----------------------------------------------------------
    // Children phone validation
    // ----------------------------------------------------------

    for (const child of childrenList) {
      if (child.primaryPhone?.trim()) {
        const childPhoneCheck =
          validateEthiopianPhone(child.primaryPhone);

        if (!childPhoneCheck.isValid) {
          alert(
            childPhoneCheck.error ||
              'Please enter a valid Ethiopian phone number for each child.'
          );

          return;
        }
      }
    }

    // ----------------------------------------------------------
    // Unified registration payload
    //
    // subCity is intentionally included here.
    // The CMMS context/backend must persist this property.
    // ----------------------------------------------------------

    const payload = {
      household: {
        householdName: regHouseholdName.trim(),
        familyType: regFamilyType,
        primaryLanguage: regPrimaryLanguage.trim(),
        primaryHouseholdPhone: regSharedPhone.trim(),

        address: regStreetAddress.trim(),
        city: regCity.trim(),
        subCity: regSubCity.trim(),
        region: regRegion.trim(),
        woreda: regWoreda.trim(),
        kebele: regKebele.trim(),
        houseNumber: regHouseNumber.trim(),
      },

      head: {
        title: headTitle.trim(),
        firstName: headFirstName.trim(),
        middleName: headMiddleName.trim(),
        lastName: headLastName.trim(),
        gender: headGender,
        dateOfBirth: headDob,
        primaryPhone:
          headPhone.trim() || regSharedPhone.trim(),
        occupation: headOccupation.trim(),

        photoUrl:
          headGender === 'Male'
            ? DEFAULT_MALE_AVATAR
            : DEFAULT_FEMALE_AVATAR,

        branchId: regBranchId,

        streetAddress: regStreetAddress.trim(),
        city: regCity.trim(),
        subCity: regSubCity.trim(),
        region: regRegion.trim(),
        woreda: regWoreda.trim(),
        kebele: regKebele.trim(),
        houseNumber: regHouseNumber.trim(),
      },

      spouse:
        includeSpouse && spouseFirstName.trim()
          ? {
              title: spouseTitle.trim(),
              firstName: spouseFirstName.trim(),
              middleName: spouseMiddleName.trim(),
              lastName:
                spouseLastName.trim() ||
                headLastName.trim(),
              gender: spouseGender,
              dateOfBirth: spouseDob,
              primaryPhone: spousePhone.trim(),
              occupation: spouseOccupation.trim(),

              photoUrl:
                spouseGender === 'Female'
                  ? DEFAULT_FEMALE_AVATAR
                  : DEFAULT_MALE_AVATAR,

              branchId: regBranchId,

              streetAddress: regStreetAddress.trim(),
              city: regCity.trim(),
              subCity: regSubCity.trim(),
              region: regRegion.trim(),
              woreda: regWoreda.trim(),
              kebele: regKebele.trim(),
              houseNumber: regHouseNumber.trim(),
            }
          : undefined,

      children: childrenList
        .filter(
          (child) => child.firstName.trim() !== ''
        )
        .map((child) => ({
          firstName: child.firstName.trim(),
          middleName: child.middleName?.trim() || '',
          lastName:
            child.lastName?.trim() ||
            headLastName.trim(),
          gender: child.gender,
          dateOfBirth: child.dateOfBirth,
          primaryPhone:
            child.primaryPhone?.trim() || '',
          branchId: regBranchId,

          streetAddress: regStreetAddress.trim(),
          city: regCity.trim(),
          subCity: regSubCity.trim(),
          region: regRegion.trim(),
          woreda: regWoreda.trim(),
          kebele: regKebele.trim(),
          houseNumber: regHouseNumber.trim(),
        })),
    };

    // ----------------------------------------------------------
    // Execute registration
    // ----------------------------------------------------------

    try {
      const newFam =
        registerUnifiedHousehold(payload);

      setSelectedFamily(newFam);

      setIsUnifiedModalOpen(false);

      setSuccessNotice(
        `Unified Household "${newFam.householdName}" (${newFam.familyCode}) successfully created with ${newFam.memberIds.length} members!`
      );

      setTimeout(() => {
        setSuccessNotice('');
      }, 4000);

      // Clear every form field after successful registration.
      resetRegistrationForm();
    } catch (error) {
      console.error(
        'Unified household registration failed:',
        error
      );

      alert(
        'The household could not be registered. Please check the form and try again.'
      );
    }
  };

  // ============================================================
  // SEARCH
  // ============================================================

  const normalizedSearchQuery =
    searchQuery.trim().toLowerCase();

  const filteredFamilies = families.filter((family) => {
    if (!normalizedSearchQuery) {
      return true;
    }

    return (
      family.householdName
        .toLowerCase()
        .includes(normalizedSearchQuery) ||
      family.familyCode
        .toLowerCase()
        .includes(normalizedSearchQuery) ||
      (family.address || '')
        .toLowerCase()
        .includes(normalizedSearchQuery) ||
      (family.city || '')
        .toLowerCase()
        .includes(normalizedSearchQuery) ||
      (family.region || '')
        .toLowerCase()
        .includes(normalizedSearchQuery)
    );
  });

  // ============================================================
  // MEMBER HELPERS
  // ============================================================

  const getMember = (id: string) =>
    members.find((member) => member.id === id);

  const familyMembers = selectedFamily
    ? selectedFamily.memberIds
        .map((id) => getMember(id))
        .filter(Boolean) as Member[]
    : [];

  const headMember =
    familyMembers.find(
      (member) =>
        member.id ===
        selectedFamily?.headOfHouseholdMemberId
    ) || familyMembers[0];

  const spouseMember = familyMembers.find(
    (member) =>
      member.familyRole === 'Spouse' ||
      (member.maritalStatus === 'Married' &&
        member.id !== headMember?.id)
  );

  const childrenMembers = familyMembers.filter(
    (member) =>
      member.familyRole === 'Child' ||
      (member.id !== headMember?.id &&
        member.id !== spouseMember?.id)
  );

  // ============================================================
  // RENDER
  // ============================================================

  return (
    <div className="space-y-6">
      {/* ======================================================
          HEADER
      ====================================================== */}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 rounded-xl">
              <Home className="w-6 h-6" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-900 dark:text-white">
                  Family & Household Management Mapping
                </h1>

                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200">
                  {families.length} Unified Containers
                </span>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Unified household containers, primary
                identifier linking, dynamic children nodes,
                and address synchronization.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {permissions.canEditMembers && (
            <button
              onClick={() => setIsUnifiedModalOpen(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Register Unified Household
            </button>
          )}
        </div>
      </div>

      {/* ======================================================
          SUCCESS NOTICE
      ====================================================== */}

      {successNotice && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between gap-2 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successNotice}</span>
          </div>

          <button
            onClick={() => setSuccessNotice('')}
            className="p-1 hover:bg-emerald-100 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ======================================================
          MAIN GRID
      ====================================================== */}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ====================================================
            HOUSEHOLD DIRECTORY
        ==================================================== */}

        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-bold text-xs text-slate-500 uppercase tracking-wider">
              Household Containers ({filteredFamilies.length})
            </h3>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />

            <input
              type="text"
              placeholder="Search households by name, code, or address..."
              value={searchQuery}
              onChange={(e) =>
                setSearchQuery(e.target.value)
              }
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div className="space-y-2.5 max-h-[720px] overflow-y-auto pr-1">
            {filteredFamilies.map((family) => {
              const isSelected =
                selectedFamily?.id === family.id;

              const head = getMember(
                family.headOfHouseholdMemberId
              );

              return (
                <div
                  key={family.id}
                  onClick={() =>
                    setSelectedFamily(family)
                  }
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-50/90 dark:bg-indigo-950/60 border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-extrabold text-indigo-700 dark:text-indigo-300">
                      {family.familyCode}
                    </span>

                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {family.familyType}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1.5">
                    {family.householdName}
                  </h4>

                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <User className="w-3.5 h-3.5 text-slate-400" />

                    <span>
                      Head:{' '}
                      <strong>
                        {head
                          ? `${head.firstName} ${head.lastName}`
                          : 'Unassigned'}
                      </strong>
                    </span>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-semibold">
                      {family.memberIds.length} Linked Profiles
                    </span>

                    <span className="font-bold text-indigo-600 dark:text-indigo-400">
                      {family.primaryLanguage ||
                        'Not specified'}
                    </span>
                  </div>
                </div>
              );
            })}

            {filteredFamilies.length === 0 && (
              <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center">
                <p className="text-xs text-slate-500">
                  No household records found.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* ====================================================
            HOUSEHOLD MAPPING
        ==================================================== */}

        <div className="lg:col-span-8 space-y-6">
          {selectedFamily ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs p-6 space-y-6">
              {/* Household Header */}

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
                <div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="font-mono text-xs font-black px-2.5 py-1 rounded-lg bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                      {selectedFamily.familyCode}
                    </span>

                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                      {selectedFamily.householdName}
                    </h2>

                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {selectedFamily.familyType}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-indigo-500 shrink-0" />

                    <span>
                      {selectedFamily.address ||
                        'Address not provided'}

                      {selectedFamily.city
                        ? `, ${selectedFamily.city}`
                        : ''}

                      {selectedFamily.region
                        ? `, ${selectedFamily.region}`
                        : ''}
                    </span>
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <ActionMenu
                    recordTitle={selectedFamily.householdName}
                    primaryAction={
                      permissions.canEditMembers
                        ? {
                            id: 'edit-household',
                            label: 'Edit Details',
                            icon: <Edit3 className="w-3.5 h-3.5" />,
                            onClick: () => handleOpenEditModal(selectedFamily),
                          }
                        : {
                            id: 'propagate-address',
                            label: 'Propagate Address',
                            icon: <RefreshCw className="w-3.5 h-3.5" />,
                            onClick: handlePropagateAddress,
                          }
                    }
                    secondaryActions={[
                      ...(permissions.canEditMembers
                        ? [
                            {
                              id: 'propagate-address-sub',
                              label: 'Propagate Address to Members',
                              icon: <RefreshCw className="w-3.5 h-3.5 text-indigo-600" />,
                              onClick: handlePropagateAddress,
                            },
                            {
                              id: 'delete-household',
                              label: 'Delete Household Record',
                              icon: <Trash2 className="w-3.5 h-3.5" />,
                              variant: 'danger' as const,
                              dividerBefore: true,
                              onClick: () =>
                                handleDeleteFamily(
                                  selectedFamily.id,
                                  selectedFamily.householdName
                                ),
                            },
                          ]
                        : []),
                    ]}
                  />
                </div>
              </div>

              {/* KPI */}

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Total Members
                  </span>

                  <span className="text-base font-extrabold text-slate-900 dark:text-white">
                    {selectedFamily.memberIds.length}{' '}
                    Linked
                  </span>
                </div>

                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Children
                  </span>

                  <span className="text-base font-extrabold text-indigo-600 dark:text-indigo-400">
                    {childrenMembers.length}{' '}
                    Registered
                  </span>
                </div>

                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Primary Language
                  </span>

                  <span className="text-base font-extrabold text-slate-900 dark:text-white">
                    {selectedFamily.primaryLanguage ||
                      'Not specified'}
                  </span>
                </div>

                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">
                    Household Status
                  </span>

                  <span className="text-base font-extrabold text-emerald-600 dark:text-emerald-400">
                    {selectedFamily.status !==
                    'Inactive'
                      ? 'Active'
                      : 'Inactive'}
                  </span>
                </div>
              </div>

              {/* Relationship Mapping */}

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FolderTree className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />

                    <h3 className="font-bold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
                      Interactive Relationship Mapping
                      Tree
                    </h3>
                  </div>

                  <span className="text-[11px] text-slate-500 font-mono">
                    Container ID: {selectedFamily.id}
                  </span>
                </div>

                <div className="p-6 bg-slate-50/80 dark:bg-slate-950/60 rounded-3xl border border-indigo-100 dark:border-indigo-950/80 space-y-6">
                  {/* Root */}

                  <div className="flex justify-center">
                    <div className="px-4 py-2 bg-indigo-600 text-white rounded-2xl shadow-md text-xs font-bold flex items-center gap-2">
                      <Home className="w-4 h-4" />

                      <span>
                        {selectedFamily.householdName}{' '}
                        ({selectedFamily.familyCode})
                      </span>
                    </div>
                  </div>

                  <div className="w-0.5 h-6 bg-indigo-300 dark:bg-indigo-800 mx-auto" />

                  {/* Head + Spouse */}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {headMember ? (
                      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border-2 border-indigo-500/80 shadow-md space-y-3 relative">
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border border-blue-200">
                            👑 Head of Household
                          </span>

                          <span className="font-mono text-[10px] text-slate-400">
                            {headMember.memberIdNumber}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <img
                            src={
                              headMember.photoUrl ||
                              DEFAULT_MALE_AVATAR
                            }
                            alt={
                              headMember.firstName
                            }
                            className="w-12 h-12 rounded-xl object-cover ring-2 ring-indigo-500 shrink-0"
                          />

                          <div className="min-w-0">
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                              {headMember.title}{' '}
                              {headMember.firstName}{' '}
                              {headMember.lastName}
                            </h4>

                            {headMember.primaryPhone && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                                {headMember.primaryPhone}
                              </p>
                            )}

                            <p className="text-[11px] text-slate-500 truncate">
                              {headMember.occupation ||
                                'Member'}
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-300 text-center text-slate-400 text-xs">
                        Head of Household
                        Unassigned
                      </div>
                    )}

                    {spouseMember ? (
                      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border-2 border-rose-400/80 shadow-md space-y-3 relative">
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-200">
                            💍 Spouse
                          </span>

                          <span className="font-mono text-[10px] text-slate-400">
                            {spouseMember.memberIdNumber}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <img
                            src={
                              spouseMember.photoUrl ||
                              DEFAULT_FEMALE_AVATAR
                            }
                            alt={
                              spouseMember.firstName
                            }
                            className="w-12 h-12 rounded-xl object-cover ring-2 ring-rose-400 shrink-0"
                          />

                          <div className="min-w-0">
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                              {spouseMember.title}{' '}
                              {spouseMember.firstName}{' '}
                              {spouseMember.lastName}
                            </h4>

                            {spouseMember.primaryPhone && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                                {
                                  spouseMember.primaryPhone
                                }
                              </p>
                            )}

                            <p className="text-[11px] text-slate-500 truncate">
                              {spouseMember.occupation ||
                                'Member'}
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 bg-white/60 dark:bg-slate-900/60 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 flex flex-col items-center justify-center text-center text-slate-400 text-xs">
                        <Heart className="w-5 h-5 text-slate-300 mb-1" />

                        <span>
                          No Spouse Linked to
                          Household
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Children */}

                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-center gap-2">
                      <div className="h-0.5 bg-indigo-200 dark:bg-indigo-800 flex-1" />

                      <span className="text-[11px] font-bold text-indigo-900 dark:text-indigo-300 uppercase px-3 py-1 bg-indigo-100 dark:bg-indigo-950 rounded-full flex items-center gap-1.5">
                        <Baby className="w-3.5 h-3.5" />
                        Children & Dependents (
                        {childrenMembers.length})
                      </span>

                      <div className="h-0.5 bg-indigo-200 dark:bg-indigo-800 flex-1" />
                    </div>

                    {childrenMembers.length === 0 ? (
                      <div className="p-4 bg-white/70 dark:bg-slate-900/70 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-center text-xs text-slate-500">
                        No children currently
                        registered in this household
                        container.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                        {childrenMembers.map(
                          (child) => (
                            <div
                              key={child.id}
                              className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2 hover:border-indigo-400 transition-colors"
                            >
                              <div className="flex items-center justify-between">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase ${
                                    child.gender ===
                                    'Male'
                                      ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                                      : 'bg-pink-50 text-pink-700 dark:bg-pink-950 dark:text-pink-300'
                                  }`}
                                >
                                  {child.gender ===
                                  'Male'
                                    ? '👦 Male Child'
                                    : '👧 Female Child'}
                                </span>

                                <span className="font-mono text-[9px] text-slate-400">
                                  {
                                    child.memberIdNumber
                                  }
                                </span>
                              </div>

                              <div className="flex items-center gap-2.5">
                                <img
                                  src={
                                    child.photoUrl ||
                                    (child.gender ===
                                    'Male'
                                      ? DEFAULT_MALE_AVATAR
                                      : DEFAULT_FEMALE_AVATAR)
                                  }
                                  alt={
                                    child.firstName
                                  }
                                  className="w-10 h-10 rounded-xl object-cover ring-1 ring-slate-200 dark:ring-slate-700 shrink-0"
                                />

                                <div className="min-w-0">
                                  <h5 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                                    {
                                      child.firstName
                                    }{' '}
                                    {child.lastName}
                                  </h5>

                                  {child.dateOfBirth && (
                                    <p className="text-[10px] text-slate-500">
                                      DOB:{' '}
                                      {
                                        child.dateOfBirth
                                      }
                                      {child.age !==
                                        undefined &&
                                        ` (Age ${child.age})`}
                                    </p>
                                  )}

                                  {child.primaryPhone && (
                                    <p className="text-[10px] font-mono text-slate-500 truncate">
                                      {
                                        child.primaryPhone
                                      }
                                    </p>
                                  )}
                                </div>
                              </div>
                            </div>
                          )
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-center space-y-2">
              <Home className="w-12 h-12 text-slate-300 mx-auto" />

              <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm">
                Select a Household
              </h3>

              <p className="text-xs text-slate-500">
                Select any household container from
                the directory to view its
                relationship tree.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ======================================================
          UNIFIED HOUSEHOLD REGISTRATION MODAL
      ====================================================== */}

      {isUnifiedModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 max-w-3xl w-full p-6 space-y-6 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}

            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-100 dark:bg-indigo-950 text-indigo-600 rounded-xl">
                  <Home className="w-5 h-5" />
                </div>

                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Unified Household & Family Batch
                    Registration
                  </h3>

                  <p className="text-[11px] text-slate-500">
                    Registers the household container,
                    head of household, spouse, and
                    children in a single transaction.
                  </p>
                </div>
              </div>

              <button
                onClick={() =>
                  setIsUnifiedModalOpen(false)
                }
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={handleRegisterUnifiedHousehold}
              className="space-y-5 text-xs"
            >
              {/* =================================================
                  SECTION 1
              ================================================= */}

              <div className="p-4 bg-indigo-50/60 dark:bg-indigo-950/30 rounded-2xl border border-indigo-200 dark:border-indigo-900/60 space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-indigo-950 dark:text-indigo-200">
                  1. Unified Household Container
                  Information
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Household Name */}

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Household Family Name *
                    </label>

                    <input
                      type="text"
                      required
                      placeholder="Household name"
                      value={regHouseholdName}
                      onChange={(e) =>
                        setRegHouseholdName(
                          e.target.value
                        )
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-semibold"
                    />
                  </div>

                  {/* Family Type */}

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Family Structure Type
                    </label>

                    <select
                      value={regFamilyType}
                      onChange={(e) =>
                        setRegFamilyType(
                          e.target.value as Family['familyType']
                        )
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                    >
                      <option value="Nuclear Family">
                        Nuclear Family
                      </option>

                      <option value="Extended Family">
                        Extended Family
                      </option>

                      <option value="Single Parent Household">
                        Single Parent Household
                      </option>

                      <option value="Elderly Couple">
                        Elderly Couple
                      </option>

                      <option value="Individual Member">
                        Individual Member
                      </option>
                    </select>
                  </div>

                  {/* Shared Phone */}

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Shared Family Phone Number *
                    </label>

                    <input
                      type="text"
                      required
                      value={regSharedPhone}
                      onChange={(e) =>
                        handleSharedPhoneInput(
                          e.target.value
                        )
                      }
                      placeholder="0911234567"
                      className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-900 font-mono text-slate-900 dark:text-white ${
                        sharedPhoneError
                          ? 'border-rose-500'
                          : 'border-slate-300 dark:border-slate-700'
                      }`}
                    />

                    {sharedPhoneError && (
                      <span className="text-[10px] text-rose-500 font-semibold">
                        {sharedPhoneError}
                      </span>
                    )}
                  </div>
                </div>

                {/* Branch */}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold mb-1">
                      Church Branch
                    </label>

                    <select
                      value={regBranchId}
                      onChange={(e) =>
                        setRegBranchId(
                          e.target.value
                        )
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    >
                      <option value="">
                        Select Branch
                      </option>

                      {branches.map((branch) => (
                        <option
                          key={branch.id}
                          value={branch.id}
                        >
                          {branch.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold mb-1">
                      Primary Language
                    </label>

                    <input
                      type="text"
                      value={regPrimaryLanguage}
                      onChange={(e) =>
                        setRegPrimaryLanguage(
                          e.target.value
                        )
                      }
                      placeholder="Primary language"
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                  </div>
                </div>

                {/* =================================================
                    ETHIOPIAN LOCATION
                ================================================= */}

                <div className="pt-2">
                  <h5 className="font-bold text-[11px] uppercase tracking-wide text-indigo-900 dark:text-indigo-300 mb-2">
                    Ethiopian Address
                  </h5>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {/* Street */}

                    <div>
                      <label className="block font-semibold mb-1">
                        Street Address
                      </label>

                      <input
                        type="text"
                        value={regStreetAddress}
                        onChange={(e) =>
                          setRegStreetAddress(
                            e.target.value
                          )
                        }
                        placeholder="Street address"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>

                    {/* City */}

                    <div>
                      <label className="block font-semibold mb-1">
                        City
                      </label>

                      <input
                        type="text"
                        value={regCity}
                        onChange={(e) =>
                          setRegCity(e.target.value)
                        }
                        placeholder="City"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>

                    {/* SubCity Dropdown */}

                    <div>
                      <label className="block font-semibold mb-1">
                        SubCity
                      </label>

                      <select
                        value={regSubCity}
                        onChange={(e) =>
                          setRegSubCity(
                            e.target.value
                          )
                        }
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      >
                        <option value="">
                          Select SubCity
                        </option>

                        {ADDIS_ABABA_SUB_CITIES.map(
                          (subCity) => (
                            <option
                              key={subCity}
                              value={subCity}
                            >
                              {subCity}
                            </option>
                          )
                        )}
                      </select>
                    </div>

                    {/* Woreda */}

                    <div>
                      <label className="block font-semibold mb-1">
                        Woreda
                      </label>

                      <input
                        type="text"
                        value={regWoreda}
                        onChange={(e) =>
                          setRegWoreda(
                            e.target.value
                          )
                        }
                        placeholder="Woreda"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>

                    {/* Kebele */}

                    <div>
                      <label className="block font-semibold mb-1">
                        Kebele
                      </label>

                      <input
                        type="text"
                        value={regKebele}
                        onChange={(e) =>
                          setRegKebele(
                            e.target.value
                          )
                        }
                        placeholder="Kebele"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>

                    {/* House Number */}

                    <div>
                      <label className="block font-semibold mb-1">
                        House Number
                      </label>

                      <input
                        type="text"
                        value={regHouseNumber}
                        onChange={(e) =>
                          setRegHouseNumber(
                            e.target.value
                          )
                        }
                        placeholder="House number"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>

                    {/* Region */}

                    <div>
                      <label className="block font-semibold mb-1">
                        Region
                      </label>

                      <input
                        type="text"
                        value={regRegion}
                        onChange={(e) =>
                          setRegRegion(
                            e.target.value
                          )
                        }
                        placeholder="Region"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* =================================================
                  SECTION 2 - HEAD
              ================================================= */}

              <div className="p-4 bg-blue-50/60 dark:bg-blue-950/30 rounded-2xl border border-blue-200 dark:border-blue-900/60 space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-blue-950 dark:text-blue-200">
                  2. Head of Household Personal
                  Details
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  {/* Title */}

                  <div>
                    <label className="block font-semibold mb-1">
                      Title
                    </label>

                    <select
                      value={headTitle}
                      onChange={(e) =>
                        setHeadTitle(e.target.value)
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    >
                      <option value="">
                        Select Title
                      </option>

                      <option value="Mr">
                        Mr
                      </option>

                      <option value="Mrs">
                        Mrs
                      </option>

                      <option value="Dr">
                        Dr
                      </option>

                      <option value="Pastor">
                        Pastor
                      </option>

                      <option value="Elder">
                        Elder
                      </option>
                    </select>
                  </div>

                  {/* First */}

                  <div>
                    <label className="block font-semibold mb-1">
                      First Name *
                    </label>

                    <input
                      type="text"
                      required
                      value={headFirstName}
                      onChange={(e) =>
                        setHeadFirstName(
                          e.target.value
                        )
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                  </div>

                  {/* Middle */}

                  <div>
                    <label className="block font-semibold mb-1">
                      Middle Name
                    </label>

                    <input
                      type="text"
                      value={headMiddleName}
                      onChange={(e) =>
                        setHeadMiddleName(
                          e.target.value
                        )
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                  </div>

                  {/* Last */}

                  <div>
                    <label className="block font-semibold mb-1">
                      Last Name *
                    </label>

                    <input
                      type="text"
                      required
                      value={headLastName}
                      onChange={(e) =>
                        setHeadLastName(
                          e.target.value
                        )
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Gender */}

                  <div>
                    <label className="block font-semibold mb-1">
                      Gender
                    </label>

                    <select
                      value={headGender}
                      onChange={(e) =>
                        setHeadGender(
                          e.target.value as Gender
                        )
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    >
                      <option value="Male">
                        Male
                      </option>

                      <option value="Female">
                        Female
                      </option>
                    </select>
                  </div>

                  {/* DOB */}

                  <EthiopianDateHelper
                    label="Date of Birth"
                    value={headDob}
                    onChange={(val) =>
                      setHeadDob(val)
                    }
                  />

                  {/* Phone */}

                  <div>
                    <label className="block font-semibold mb-1">
                      Head Phone
                    </label>

                    <input
                      type="text"
                      value={headPhone}
                      onChange={(e) =>
                        handleHeadPhoneInput(
                          e.target.value
                        )
                      }
                      placeholder="Optional individual phone"
                      className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono"
                    />
                  </div>
                </div>

                {/* Occupation */}

                <div>
                  <label className="block font-semibold mb-1">
                    Occupation
                  </label>

                  <input
                    type="text"
                    value={headOccupation}
                    onChange={(e) =>
                      setHeadOccupation(
                        e.target.value
                      )
                    }
                    placeholder="Occupation"
                    className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                </div>
              </div>

              {/* =================================================
                  SECTION 3 - SPOUSE
              ================================================= */}

              <div className="p-4 bg-rose-50/60 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900/60 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-rose-950 dark:text-rose-200">
                    3. Spouse Information
                  </h4>

                  <label className="flex items-center gap-2 cursor-pointer font-bold text-rose-900 dark:text-rose-300">
                    <input
                      type="checkbox"
                      checked={includeSpouse}
                      onChange={(e) =>
                        setIncludeSpouse(
                          e.target.checked
                        )
                      }
                      className="w-4 h-4 text-rose-600 rounded"
                    />

                    <span>
                      Include Spouse in
                      Registration
                    </span>
                  </label>
                </div>

                {includeSpouse && (
                  <div className="space-y-3 pt-1 animate-in fade-in duration-150">
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                      {/* Title */}

                      <div>
                        <label className="block font-semibold mb-1">
                          Title
                        </label>

                        <select
                          value={spouseTitle}
                          onChange={(e) =>
                            setSpouseTitle(
                              e.target.value
                            )
                          }
                          className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        >
                          <option value="">
                            Select Title
                          </option>

                          <option value="Mrs">
                            Mrs
                          </option>

                          <option value="Ms">
                            Ms
                          </option>

                          <option value="Dr">
                            Dr
                          </option>

                          <option value="Pastor">
                            Pastor
                          </option>
                        </select>
                      </div>

                      {/* First */}

                      <div>
                        <label className="block font-semibold mb-1">
                          Spouse First Name *
                        </label>

                        <input
                          type="text"
                          required={includeSpouse}
                          value={spouseFirstName}
                          onChange={(e) =>
                            setSpouseFirstName(
                              e.target.value
                            )
                          }
                          className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                      </div>

                      {/* Middle */}

                      <div>
                        <label className="block font-semibold mb-1">
                          Middle Name
                        </label>

                        <input
                          type="text"
                          value={spouseMiddleName}
                          onChange={(e) =>
                            setSpouseMiddleName(
                              e.target.value
                            )
                          }
                          className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                      </div>

                      {/* Last */}

                      <div>
                        <label className="block font-semibold mb-1">
                          Last Name
                        </label>

                        <input
                          type="text"
                          value={spouseLastName}
                          onChange={(e) =>
                            setSpouseLastName(
                              e.target.value
                            )
                          }
                          placeholder={
                            headLastName ||
                            'Family surname'
                          }
                          className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {/* Gender */}

                      <div>
                        <label className="block font-semibold mb-1">
                          Gender
                        </label>

                        <select
                          value={spouseGender}
                          onChange={(e) =>
                            setSpouseGender(
                              e.target.value as Gender
                            )
                          }
                          className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        >
                          <option value="Female">
                            Female
                          </option>

                          <option value="Male">
                            Male
                          </option>
                        </select>
                      </div>

                      {/* DOB */}

                      <EthiopianDateHelper
                        label="Date of Birth"
                        value={spouseDob}
                        onChange={(val) =>
                          setSpouseDob(val)
                        }
                      />

                      {/* Phone */}

                      <div>
                        <label className="block font-semibold mb-1">
                          Spouse Phone
                        </label>

                        <EthiopianPhoneInput
                          value={spousePhone}
                          onChange={(e) =>
                            handleSpousePhoneInput(
                              e.target.value
                            )
                          }
                          placeholder="Optional phone"
                        />
                      </div>
                    </div>

                    {/* Occupation */}

                    <div>
                      <label className="block font-semibold mb-1">
                        Occupation
                      </label>

                      <input
                        type="text"
                        value={spouseOccupation}
                        onChange={(e) =>
                          setSpouseOccupation(
                            e.target.value
                          )
                        }
                        placeholder="Occupation"
                        className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* =================================================
                  SECTION 4 - CHILDREN
              ================================================= */}

              <div className="p-4 bg-teal-50/60 dark:bg-teal-950/30 rounded-2xl border border-teal-200 dark:border-teal-900/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-xs uppercase tracking-wider text-teal-950 dark:text-teal-200">
                      4. Children & Dependent Nodes (
                      {childrenList.length})
                    </h4>

                    <p className="text-[11px] text-slate-500">
                      Dynamically add biological or
                      adopted children linked directly
                      to this household.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddChild}
                    className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Child
                  </button>
                </div>

                {childrenList.length === 0 ? (
                  <div className="p-3 bg-white/60 dark:bg-slate-900/60 rounded-xl border border-dashed border-teal-200 dark:border-teal-900/80 text-center text-slate-500">
                    No children added yet. Click
                    &quot;Add Child&quot; to include
                    children.
                  </div>
                ) : (
                  <div className="space-y-3 pt-1">
                    {childrenList.map(
                      (child, index) => (
                        <div
                          key={index}
                          className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-teal-200 dark:border-teal-900/80 space-y-2 shadow-xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-teal-900 dark:text-teal-200 text-xs">
                              Child #{index + 1}
                            </span>

                            <button
                              type="button"
                              onClick={() =>
                                handleRemoveChild(
                                  index
                                )
                              }
                              className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg text-xs font-bold"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                            {/* First Name */}

                            <div>
                              <label className="block text-[11px] font-semibold mb-0.5">
                                First Name *
                              </label>

                              <input
                                type="text"
                                required
                                value={
                                  child.firstName
                                }
                                onChange={(e) =>
                                  handleChildFieldChange(
                                    index,
                                    'firstName',
                                    e.target.value
                                  )
                                }
                                placeholder="Child's first name"
                                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                              />
                            </div>

                            {/* Gender */}

                            <div>
                              <label className="block text-[11px] font-semibold mb-0.5">
                                Gender
                              </label>

                              <select
                                value={
                                  child.gender
                                }
                                onChange={(e) =>
                                  handleChildFieldChange(
                                    index,
                                    'gender',
                                    e.target
                                      .value as Gender
                                  )
                                }
                                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                              >
                                <option value="Male">
                                  Male
                                </option>

                                <option value="Female">
                                  Female
                                </option>
                              </select>
                            </div>

                            {/* DOB */}

                            <div>
                              <EthiopianDateHelper
                                label="Date of Birth"
                                value={
                                  child.dateOfBirth
                                }
                                onChange={(val) =>
                                  handleChildFieldChange(
                                    index,
                                    'dateOfBirth',
                                    val
                                  )
                                }
                              />
                            </div>

                            {/* Phone */}

                            <div>
                              <label className="block text-[11px] font-semibold mb-0.5">
                                Phone
                              </label>

                              <input
                                type="text"
                                value={
                                  child.primaryPhone ||
                                  ''
                                }
                                onChange={(e) =>
                                  handleChildFieldChange(
                                    index,
                                    'primaryPhone',
                                    sanitizeEthiopianPhoneInput(
                                      e.target.value
                                    )
                                  )
                                }
                                placeholder="Optional phone"
                                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-xs"
                              />
                            </div>
                          </div>

                          {/* Child Middle / Last Name */}

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[11px] font-semibold mb-0.5">
                                Middle Name
                              </label>

                              <input
                                type="text"
                                value={
                                  child.middleName ||
                                  ''
                                }
                                onChange={(e) =>
                                  handleChildFieldChange(
                                    index,
                                    'middleName',
                                    e.target.value
                                  )
                                }
                                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-semibold mb-0.5">
                                Last Name
                              </label>

                              <input
                                type="text"
                                value={
                                  child.lastName ||
                                  ''
                                }
                                onChange={(e) =>
                                  handleChildFieldChange(
                                    index,
                                    'lastName',
                                    e.target.value
                                  )
                                }
                                placeholder="Last name"
                                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                              />
                            </div>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                )}
              </div>

              {/* =================================================
                  SUBMIT
              ================================================= */}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() =>
                    setIsUnifiedModalOpen(false)
                  }
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Execute Single-Transaction
                  Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================
          EDIT HOUSEHOLD DETAILS MODAL
      ====================================================== */}

      {isEditModalOpen && selectedFamily && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Edit Household:{' '}
                {selectedFamily.householdName}
              </h3>

              <button
                onClick={() =>
                  setIsEditModalOpen(false)
                }
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={handleSaveEditFamily}
              className="space-y-3 text-xs"
            >
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Household Name *
                </label>

                <input
                  type="text"
                  required
                  value={editFamilyName}
                  onChange={(e) =>
                    setEditFamilyName(
                      e.target.value
                    )
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Household Structure Type
                </label>

                <select
                  value={editFamilyType}
                  onChange={(e) =>
                    setEditFamilyType(
                      e.target.value as Family['familyType']
                    )
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="Nuclear Family">
                    Nuclear Family
                  </option>

                  <option value="Extended Family">
                    Extended Family
                  </option>

                  <option value="Single Parent Household">
                    Single Parent Household
                  </option>

                  <option value="Elderly Couple">
                    Elderly Couple
                  </option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Primary Language
                </label>

                <input
                  type="text"
                  value={editPrimaryLang}
                  onChange={(e) =>
                    setEditPrimaryLang(
                      e.target.value
                    )
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Street Address
                </label>

                <input
                  type="text"
                  value={editAddress}
                  onChange={(e) =>
                    setEditAddress(e.target.value)
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    City
                  </label>

                  <input
                    type="text"
                    value={editCity}
                    onChange={(e) =>
                      setEditCity(e.target.value)
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Region
                  </label>

                  <input
                    type="text"
                    value={editRegion}
                    onChange={(e) =>
                      setEditRegion(e.target.value)
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() =>
                    setIsEditModalOpen(false)
                  }
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
