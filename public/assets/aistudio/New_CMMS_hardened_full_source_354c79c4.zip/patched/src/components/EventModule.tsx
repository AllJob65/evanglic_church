import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { EventItem } from '../types';
import {
  Calendar,
  Plus,
  Ticket,
  MapPin,
  Mic,
  X,
  Image as ImageIcon,
  Eye,
  Check,
} from 'lucide-react';

export const EventModule: React.FC = () => {
  const { events, addEvent, permissions, branches } = useCMMS();
  const [isAddEventModalOpen, setIsAddEventModalOpen] = useState(false);
  const [previewPosterUrl, setPreviewPosterUrl] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [type, setType] = useState<EventItem['type']>('Conference');
  const [startDate, setStartDate] = useState('2026-09-15');
  const [location, setLocation] = useState('Grace Cathedral Main Auditorium');
  const [capacity, setCapacity] = useState(1000);
  const [posterUrl, setPosterUrl] = useState(
    'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=1200&q=80'
  );

  const posterPresets = [
    { label: 'Conference Banner', url: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Worship / Concert', url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Youth Retreat', url: 'https://images.unsplash.com/photo-1526772662000-3f88f10405ff?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Leadership Seminar', url: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&w=1200&q=80' },
  ];

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    const newEvt: EventItem = {
      id: `evt-${Date.now().toString().slice(-4)}`,
      title,
      type,
      branchId: branches[0]?.id || 'br-001',
      startDate,
      endDate: startDate,
      location,
      description: 'Church event for spiritual revival, word exposition, and fellowship.',
      posterUrl: posterUrl.trim() || posterPresets[0].url,
      speakerNames: [],
      capacity,
      registeredCount: 0,
      isPaid: false,
      status: 'Upcoming',
    };

    addEvent(newEvt);
    setIsAddEventModalOpen(false);
    setTitle('');
  };

  return (
    <div className="space-y-6 text-base">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-6 h-6 text-purple-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Event & Poster Tracking Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200">
              {events.length} Scheduled Events
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Track official event promotional posters, attendance ticketing tiers, and venue allocations.
          </p>
        </div>

        {permissions.canEditMembers && (
          <button
            onClick={() => setIsAddEventModalOpen(true)}
            className="min-h-[44px] px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule New Event & Upload Poster</span>
          </button>
        )}
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {events.map((evt) => {
          const currentPoster = evt.posterUrl || posterPresets[0].url;

          return (
            <div
              key={evt.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden flex flex-col justify-between space-y-0"
            >
              {/* Event Poster Banner */}
              <div className="relative h-48 w-full bg-slate-900 overflow-hidden group">
                <img
                  src={currentPoster}
                  alt={evt.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-purple-600 text-white shadow-md">
                    {evt.type}
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500 text-white shadow-md">
                    {evt.status}
                  </span>
                </div>

                {/* View Full Poster Button */}
                <button
                  onClick={() => setPreviewPosterUrl(currentPoster)}
                  className="absolute bottom-3 right-3 min-h-[44px] px-3.5 py-2 rounded-xl bg-black/60 hover:bg-black/90 text-white text-xs font-bold backdrop-blur-md border border-white/20 transition-all flex items-center gap-1.5 shadow-lg cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" /> <span>View Poster</span>
                </button>
              </div>

              {/* Event Information */}
              <div className="p-4 sm:p-6 space-y-4">
                <div>
                  <h3 className="font-bold text-lg text-slate-900 dark:text-white leading-tight">{evt.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{evt.description}</p>
                </div>

                <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>
                      {evt.startDate} to {evt.endDate}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>{evt.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mic className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>Speakers: {evt.speakerNames.join(', ')}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      {evt.registeredCount} / {evt.capacity} Registered
                    </span>
                    <span className="text-xs text-slate-400">
                      {evt.isPaid ? `Paid Event ($${evt.ticketPrice})` : 'Free Admission'}
                    </span>
                  </div>

                  <button
                    onClick={() => alert(`Registered attendee for ${evt.title}!`)}
                    className="min-h-[44px] px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Ticket className="w-3.5 h-3.5" /> <span>Register</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Poster Preview Lightbox Modal */}
      {previewPosterUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-2 sm:p-4">
          <div className="relative max-w-3xl w-full bg-slate-900 rounded-2xl sm:rounded-3xl border border-slate-800 overflow-hidden shadow-2xl p-2">
            <button
              onClick={() => setPreviewPosterUrl(null)}
              className="absolute top-4 right-4 z-10 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-black/60 hover:bg-black text-white border border-white/20 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewPosterUrl}
              alt="Event Poster Preview"
              className="w-full h-auto max-h-[80vh] object-contain rounded-xl sm:rounded-2xl mx-auto"
            />
          </div>
        </div>
      )}

      {/* Schedule Event & Poster Modal */}
      {isAddEventModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-md border-0 sm:border border-slate-200 dark:border-slate-800 p-4 sm:p-6 space-y-4 max-h-[92vh] sm:max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Schedule Event & Upload Poster</h3>
              <button
                type="button"
                onClick={() => setIsAddEventModalOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-slate-600 rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Event Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Leadership & Anointing Conference 2026"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Event Category</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="Conference">Conference</option>
                  <option value="Crusade">Crusade</option>
                  <option value="Retreat">Retreat</option>
                  <option value="Seminar">Seminar</option>
                  <option value="Outreach">Community Outreach</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Promotional Poster Image</label>
                <div className="space-y-2">
                  <input
                    type="text"
                    value={posterUrl}
                    onChange={(e) => setPosterUrl(e.target.value)}
                    placeholder="Paste Image URL or select preset..."
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    {posterPresets.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPosterUrl(preset.url)}
                        className={`p-2 rounded-xl text-[10px] font-bold border text-left truncate transition-all ${
                          posterUrl === preset.url
                            ? 'bg-purple-100 text-purple-900 border-purple-500 dark:bg-purple-950 dark:text-purple-200'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Event Date</label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Venue Location</label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Seat Capacity</label>
                <input
                  type="number"
                  value={capacity}
                  onChange={(e) => setCapacity(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddEventModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-purple-600 text-white rounded-xl font-semibold">
                  Schedule Event & Save Poster
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
