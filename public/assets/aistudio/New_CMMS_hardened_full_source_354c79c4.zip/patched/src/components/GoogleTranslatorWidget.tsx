import React, { useState, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Globe,
  Check,
  ChevronDown,
  Search,
  Sparkles,
  ArrowRight,
  ExternalLink,
  Languages,
  X,
} from 'lucide-react';

export interface GlobalLanguage {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  region: string;
}

export const POPULAR_LANGUAGES: GlobalLanguage[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧', region: 'Global' },
  { code: 'am', name: 'Amharic', nativeName: 'አማርኛ', flag: '🇪🇹', region: 'Ethiopia' },
  { code: 'om', name: 'Afaan Oromoo', nativeName: 'Afaan Oromoo', flag: '🇪🇹', region: 'Ethiopia' },
  { code: 'ti', name: 'Tigrigna', nativeName: 'ትግርኛ', flag: '🇪🇹', region: 'Ethiopia / Eritrea' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸', region: 'Europe / Latin America' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷', region: 'Europe / Africa' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', region: 'Middle East / North Africa' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪', region: 'Europe' },
  { code: 'zh-CN', name: 'Chinese (Simplified)', nativeName: '简体中文', flag: '🇨🇳', region: 'Asia' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹', region: 'Europe / Brazil' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', flag: '🇰🇪', region: 'East Africa' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹', region: 'Europe' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', flag: '🇰🇷', region: 'Asia' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵', region: 'Asia' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳', region: 'Asia' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺', region: 'Eurasia' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', flag: '🇳🇱', region: 'Europe' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷', region: 'Middle East / Europe' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', flag: '🇮🇱', region: 'Middle East' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', flag: '🇬🇷', region: 'Europe' },
];

interface GoogleTranslatorWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleTranslatorWidget: React.FC<GoogleTranslatorWidgetProps> = ({ isOpen, onClose }) => {
  const { language, setLanguage } = useCMMS();
  const [selectedLangCode, setSelectedLangCode] = useState<string>('en');
  const [searchQuery, setSearchQuery] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);

  // Initialize GTranslate / Google Translate Element
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Declare global init function
    (window as any).googleTranslateElementInit = () => {
      try {
        if ((window as any).google && (window as any).google.translate) {
          new (window as any).google.translate.TranslateElement(
            {
              pageLanguage: 'en',
              includedLanguages: 'en,am,om,ti,es,fr,ar,de,zh-CN,pt,sw,it,ko,ja,hi,ru,nl,tr,he,el',
              layout: (window as any).google.translate.TranslateElement.InlineLayout.SIMPLE,
              autoDisplay: false,
            },
            'google_translate_element'
          );
        }
      } catch (e) {
        console.warn('Google Translate initialization notice:', e);
      }
    };

    // Inject Google Translate script if not present
    if (!document.getElementById('google-translate-script')) {
      const script = document.createElement('script');
      script.id = 'google-translate-script';
      script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      script.async = true;
      script.onerror = () => {
        console.warn('[Google Translate] Script load failed or was blocked.');
      };
      document.body.appendChild(script);
    }
  }, []);

  const handleSelectLanguage = (lang: GlobalLanguage) => {
    setSelectedLangCode(lang.code);
    setIsTranslating(true);

    // Sync with CMMS Context language if one of the 4 native church languages
    const isInternal = ['en', 'am', 'ti', 'om'].includes(lang.code);
    if (lang.code === 'en') setLanguage('English');
    else if (lang.code === 'am') setLanguage('Amharic');
    else if (lang.code === 'ti') setLanguage('Tigrigna');
    else if (lang.code === 'om') setLanguage('Afaan Oromoo');

    if (isInternal) {
      // Clear external translator state so it cannot interfere with native church languages
      import('../utils/googleTranslate').then((m) => m.clearGoogleTranslateCookie());
    } else {
      // Trigger Google Translate cookie / dropdown change ONLY for non-native languages
      try {
        const select = document.querySelector('.goog-te-combo') as HTMLSelectElement;
        if (select) {
          select.value = lang.code;
          select.dispatchEvent(new Event('change'));
        }
      } catch (err) {
        console.warn('Could not dispatch google translate change event', err);
      }
    }

    setTimeout(() => {
      setIsTranslating(false);
      onClose();
    }, 500);
  };

  if (!isOpen) return null;

  const filteredLanguages = POPULAR_LANGUAGES.filter(
    (l) =>
      l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.nativeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.region.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="gtranslate-title"
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-blue-500/20 text-blue-300 border border-blue-400/30">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="gtranslate-title" className="text-base sm:text-lg font-black tracking-tight">
                  Google Translate & GTranslate
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/30 text-blue-200 border border-blue-400/40 font-mono">
                  100+ Languages
                </span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">
                Real-time page translation powered by Google Neural Machine Translation.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close translation modal"
            className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Google Translate Hidden Container */}
        <div id="google_translate_element" className="hidden"></div>

        {/* Search & Quick Filter */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search language by name, native script, or region..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Language Grid */}
        <div className="p-4 max-h-[380px] overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {filteredLanguages.map((lang) => {
            const isSelected =
              selectedLangCode === lang.code ||
              (language === 'English' && lang.code === 'en') ||
              (language === 'Amharic' && lang.code === 'am') ||
              (language === 'Tigrigna' && lang.code === 'ti') ||
              (language === 'Afaan Oromoo' && lang.code === 'om');

            return (
              <button
                key={lang.code}
                onClick={() => handleSelectLanguage(lang)}
                className={`p-3 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-500 text-blue-900 dark:text-blue-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-800 dark:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl" role="img" aria-label={lang.name}>
                    {lang.flag}
                  </span>
                  <div className="text-left">
                    <p className="font-bold text-xs">{lang.name}</p>
                    <p className="text-[11px] text-slate-400">{lang.nativeName} • {lang.region}</p>
                  </div>
                </div>

                {isSelected && <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />}
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            Automatic RTL text direction & Geolocation detection
          </span>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-sm cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
