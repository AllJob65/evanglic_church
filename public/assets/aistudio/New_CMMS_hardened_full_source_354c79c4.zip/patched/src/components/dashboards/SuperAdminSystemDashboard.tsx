import React, { useState } from 'react';
import { useCMMS } from '../../context/CMMSContext';
import {
  Building2,
  ShieldCheck,
  Users,
  Activity,
  HardDrive,
  Cpu,
  CheckCircle2,
  RefreshCw,
  Terminal,
  ArrowUpRight,
  Globe,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip
} from 'recharts';
import { RealtimeConnectionIndicator } from '../RealtimeConnectionIndicator';

export const SuperAdminSystemDashboard: React.FC = () => {
  const {
    branches,
    members,
    systemUsers,
    auditLogs,
    setActiveModule,
    setSelectedBranchId,
    selectedBranchId
  } = useCMMS();

  const [dbStatus] = useState({
    engine: 'PostgreSQL',
    connections: 'Managed by Server',
    uptime: 'Active',
    lastBackup: 'Managed in Backup Module',
    size: `${members.length + branches.length + systemUsers.length + auditLogs.length} Loaded Records`,
    tenants: branches.length,
    health: 'Operational'
  });

  const latencyData: { time: string; latency: number }[] = [];

  return (
    <div className="space-y-6" id="super-admin-system-dashboard">
      {/* Super Admin Top Banner */}
      
      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Tenant Campuses
            </span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <Building2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{branches.length}</span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              {branches.length > 0
                ? `${Math.round((branches.filter((b) => (b.status || 'Active') === 'Active').length / branches.length) * 100)}% Active`
                : '0% Active'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Row-level isolation by branchId / church_id
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              System Operators (RBAC)
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{systemUsers.length}</span>
            <span className="text-xs font-semibold text-purple-600 dark:text-purple-400">7 Distinct Roles</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            JWT Stateless Bearer Authorization
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Database Status
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <HardDrive className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{dbStatus.health}</span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">Operational</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Configured database: PostgreSQL
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Immutable Audit Logs
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{auditLogs.length}</span>
            <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">Tracked</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Audit events currently loaded
          </p>
        </div>
      </div>

      {/* Multi-Tenancy Campus Fleet Overview & Server Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Tenant Campus Partition Matrix */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                Multi-Tenant Campus Matrix (Row-Level Isolated)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Click any tenant to simulate scoped administrative view or leave on global aggregation.
              </p>
            </div>
            <button
              onClick={() => setSelectedBranchId('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedBranchId === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              View All (Global Aggregate)
            </button>
          </div>

          <div className="space-y-3">
            {branches.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                No data available
              </div>
            ) : (
              branches.map((b) => {
                const bMembers = members.filter((m) => m.branchId === b.id).length;
                const isSelected = selectedBranchId === b.id;
                return (
                  <div
                    key={b.id}
                    onClick={() => setSelectedBranchId(isSelected ? 'all' : b.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/30 shadow-xs'
                        : 'border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}>
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900 dark:text-white">{b.name}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                            {b.id}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {b.city || 'No city specified'} • Pastor: {b.pastorName || 'Unassigned'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-right">
                      <div>
                        <div className="text-xs font-bold text-slate-900 dark:text-white">{bMembers} Members</div>
                        <div className="text-[10px] text-emerald-600 font-semibold">Tenant Active</div>
                      </div>
                      <div className="p-1 rounded-lg text-slate-400 hover:text-blue-600">
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right 1 Col: Server Telemetry & Database Diagnostics */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Cpu className="w-4 h-4 text-amber-500" />
                Cluster Telemetry & Performance
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                Configured Telemetry
              </span>
            </div>

            {latencyData.length === 0 ? (
              <div className="h-40 w-full mb-4 flex items-center justify-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                No telemetry latency stream data available
              </div>
            ) : (
              <div className="h-40 w-full mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={latencyData}>
                    <defs>
                      <linearGradient id="latencyGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="time" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <Tooltip />
                    <Area type="monotone" dataKey="latency" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#latencyGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Database Engine:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{dbStatus.engine}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Configured Connection Pool:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{dbStatus.connections}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Last Encrypted Snapshot:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{dbStatus.lastBackup}</span>
              </div>
            </div>

            {/* Supabase Realtime Health Monitoring Card */}
            <div className="mt-3 pt-2">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Realtime Database Stream</span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-normal">Realtime connection status</span>
              </div>
              <RealtimeConnectionIndicator
                variant="detailed"
                channelName="superadmin-cluster-diagnostics"
                tableName="notifications"
                className="bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700"
              />
            </div>

          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              Database Integration Configured
            </span>
            <button
              onClick={() => setActiveModule('backup')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1 cursor-pointer"
            >
              Manage DDL Migrations &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Global Audit Log Stream */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-500" />
              Global System Audit Stream
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Audit events currently available to this dashboard.
            </p>
          </div>
          <button
            onClick={() => setActiveModule('security_audit')}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1 cursor-pointer"
          >
            Full Security Audit Center &rarr;
          </button>
        </div>

        <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
          {auditLogs.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              No data available
            </div>
          ) : (
            auditLogs.slice(0, 6).map((log, idx) => (
              <div
                key={log.id ? `${log.id}-${idx}` : `log-${idx}`}
                className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5">
                    <Terminal className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">{log.action}</div>
                    <div className="text-slate-600 dark:text-slate-400 text-[11px] mt-0.5">{log.details}</div>
                    <div className="text-[10px] text-slate-400 mt-1 font-mono">Operator: {log.user || 'System Engine'}</div>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 font-mono shrink-0">{log.timestamp}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
