import React from 'react';
import { useCMMS } from '../../context/CMMSContext';
import {
  Users,
  Building2,
  Calendar,
  Layers,
  HeartHandshake,
  CheckCircle2,
  Clock,
  Send,
  UserPlus,
  FileBarChart,
  ShieldCheck,
  TrendingUp,
  MapPin,
  ArrowUpRight,
  Sparkles
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export const ChurchAdminDashboard: React.FC = () => {
  const {
    members,
    ministries,
    events,
    branches,
    selectedBranchId,
    setActiveModule,
    workflows,
    language
  } = useCMMS();

  // Filter members by local church / campus
  const localMembers = selectedBranchId === 'all'
    ? members
    : members.filter((m) => m.branchId === selectedBranchId);

  const activeMembers = localMembers.filter((m) => m.membershipStatus === 'Active');
  const upcomingEvents = events.filter((e) => new Date(e.date) >= new Date()).slice(0, 4);
  const pendingWorkflows = workflows.filter((w) => w.status === 'Pending').length;

  const currentBranch = branches.find((b) => b.id === selectedBranchId) || branches[0] || {
    name: 'All Campuses',
    city: '',
    address: ''
  };

  const statusData = [
    { name: 'Active', value: activeMembers.length, color: '#10b981' },
    { name: 'New Converts', value: localMembers.filter((m) => m.discipleshipStatus === 'New Convert').length, color: '#8b5cf6' },
    { name: 'In Class', value: localMembers.filter((m) => m.discipleshipStatus === 'In Foundation Class').length, color: '#3b82f6' },
    { name: 'Leaders', value: localMembers.filter((m) => m.discipleshipStatus === 'Discipler / Leader').length, color: '#f59e0b' },
  ];

  const facilityBookings = events.map((e) => ({
    room: e.location || 'Campus Facility',
    time: `${e.date} • ${e.time || ''}`,
    event: e.title,
    leader: e.organizer || 'Event Coordinator',
  }));

  return (
    <div className="space-y-6" id="church-admin-dashboard">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-slate-900 to-blue-950 border border-blue-500/30 rounded-2xl p-5 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 tracking-wider uppercase flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-400" />
                Church Administration & Operations Dashboard
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/10 text-slate-200">
                {currentBranch.name}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {currentBranch.name} Operations Hub
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Member Lifecycle, Ministry Department Rosters, Facility Bookings & Campus Administrative Services.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveModule('members')}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              Onboard New Member
            </button>
            <button
              onClick={() => setActiveModule('events')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-blue-400" />
              Schedule Event / Facility
            </button>
            <button
              onClick={() => setActiveModule('communications')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-4 h-4 text-emerald-400" />
              Campus Broadcast
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Campus Active Members
            </span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{activeMembers.length}</span>
            <span className="text-xs font-semibold text-emerald-600">Active Covenant</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {localMembers.length} Total records in local database
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Active Ministries & Teams
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{ministries.length}</span>
            <span className="text-xs font-semibold text-purple-600">Staffed</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Registered ministry departments
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Upcoming Events
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{upcomingEvents.length}</span>
            <span className="text-xs font-semibold text-amber-600">Scheduled</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Conferences, vigils & seminars
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Pending Approvals
            </span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{pendingWorkflows}</span>
            <span className="text-xs font-semibold text-rose-600">Queue</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Membership transfers & profile changes
          </p>
        </div>
      </div>

      {/* Facility Bookings & Discipleship Demographics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Campus Facility & Room Reservation Schedule */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                Campus Facility & Hall Booking Schedule
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Live reservation roster for church auditoriums, halls, and meeting rooms.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('events')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1 cursor-pointer"
            >
              Book Room &rarr;
            </button>
          </div>

          <div className="space-y-3">
            {facilityBookings.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No data available
              </div>
            ) : (
              facilityBookings.map((b, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-sm text-slate-900 dark:text-white">{b.room}</div>
                    <div className="text-xs text-slate-600 dark:text-slate-400 font-medium mt-0.5">
                      {b.event}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-2">
                      <span className="font-mono bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded text-[10px] font-bold">
                        {b.time}
                      </span>
                      <span>Coordinator: {b.leader}</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    Confirmed
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right 1 Col: Discipleship Lifecycle Distribution */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-purple-600" />
              Member Discipleship Funnel
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Distribution across salvation to spiritual leadership.
            </p>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={4}>
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-2">
              {statusData.map((d, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                  <span className="text-slate-600 dark:text-slate-300 truncate">{d.name}: {d.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setActiveModule('reports')}
              className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-all flex items-center justify-center gap-1 cursor-pointer"
            >
              <FileBarChart className="w-3.5 h-3.5" />
              Generate Campus Growth Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
