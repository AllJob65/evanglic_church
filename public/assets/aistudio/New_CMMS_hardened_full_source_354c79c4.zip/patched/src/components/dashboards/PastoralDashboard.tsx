import React, { useState } from 'react';
import { useCMMS } from '../../context/CMMSContext';
import {
  HeartHandshake,
  Heart,
  Users,
  Calendar,
  Clock,
  CheckCircle2,
  Lock,
  Plus,
  BookOpen,
  MessageSquare,
  Sparkles,
  PhoneCall,
  UserCheck,
  Flame,
  Shield,
  FileText
} from 'lucide-react';

export const PastoralDashboard: React.FC = () => {
  const {
    prayerRequests,
    counselingSessions,
    visitations,
    members,
    setActiveModule,
    addPrayerRequest
  } = useCMMS();

  const [newPrayerModal, setNewPrayerModal] = useState(false);
  const [prayerRequester, setPrayerRequester] = useState('');
  const [prayerTopic, setPrayerTopic] = useState('');
  const [prayerDesc, setPrayerDesc] = useState('');
  const [isConfidential, setIsConfidential] = useState(true);

  const pendingPrayers = prayerRequests.filter((p) => p.status === 'Pending');
  const answeredPrayers = prayerRequests.filter((p) => p.status === 'Answered');
  const scheduledAppointments = (counselingSessions || []).filter((c) => c.status === 'Scheduled');

  const handleCreatePrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerTopic.trim()) return;
    addPrayerRequest({
      id: `pr-${Date.now()}`,
      requestNumber: `PR-${Date.now().toString().slice(-4)}`,
      memberId: 'pastoral-care',
      memberName: prayerRequester.trim() || 'Anonymous Member',
      requesterName: prayerRequester.trim() || 'Anonymous Member',
      topic: prayerTopic.trim(),
      title: prayerTopic.trim(),
      description: prayerDesc.trim(),
      details: prayerDesc.trim(),
      category: 'Pastoral Care',
      priority: 'High',
      urgency: 'High',
      isConfidential: isConfidential,
      status: 'Pending',
      submittedDate: new Date().toISOString().split('T')[0],
      submittedAt: new Date().toISOString().split('T')[0]
    });
    setPrayerRequester('');
    setPrayerTopic('');
    setPrayerDesc('');
    setNewPrayerModal(false);
  };

  return (
    <div className="space-y-6" id="pastoral-care-dashboard">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/30 rounded-2xl p-5 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 tracking-wider uppercase flex items-center gap-1.5">
                <HeartHandshake className="w-3.5 h-3.5 text-emerald-400" />
                Pastoral Care & Spiritual Oversight Dashboard
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Strict Pastoral Privilege
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Shepherding & Soul Care Sanctuary
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Confidential Intercessory Prayers, Counseling Appointments, Member Discipleship Mentorship & Hospital Visitations.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setNewPrayerModal(true)}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Log Intercession / Prayer
            </button>
            <button
              onClick={() => setActiveModule('prayer_counseling')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-emerald-400" />
              Counseling Schedule
            </button>
            <button
              onClick={() => setActiveModule('visitations')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Heart className="w-4 h-4 text-rose-400" />
              Hospital & Home Visits
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Active Intercessions
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Flame className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{pendingPrayers.length}</span>
            <span className="text-xs font-semibold text-emerald-600">In Prayer Queue</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {answeredPrayers.length} Documented Testimonies of Praise
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Counseling Sessions
            </span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <MessageSquare className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{scheduledAppointments.length}</span>
            <span className="text-xs font-semibold text-blue-600">Scheduled</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Pre-marital, grief care & deliverance
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Care Visits Logged
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Heart className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{visitations.length}</span>
            <span className="text-xs font-semibold text-purple-600">Conducted</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Hospital bedsides, bereavement & homes
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Discipleship Mentors
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {members.filter((m) => m.discipleshipStatus === 'Discipler / Leader').length}
            </span>
            <span className="text-xs font-semibold text-amber-600">Active Disciplers</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Leading cell groups & discipleship classes
          </p>
        </div>
      </div>

      {/* Main Two Columns: Intercession Queue + Counseling Appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Intercessory Prayer Requests Sanctuary */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Flame className="w-4 h-4 text-emerald-600" />
                Intercessory Prayer Sanctuary
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Confidential petitions from members needing spiritual breakthroughs.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('prayer_counseling')}
              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 flex items-center gap-1 cursor-pointer"
            >
              All Requests &rarr;
            </button>
          </div>

          <div className="space-y-3">
            {prayerRequests.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No data available
              </div>
            ) : (
              prayerRequests.slice(0, 4).map((p) => (
                <div
                  key={p.id}
                  className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">{p.topic}</span>
                        {p.isConfidential && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-[10px] font-bold flex items-center gap-0.5">
                            <Lock className="w-2.5 h-2.5" /> Confidential
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                        {p.description}
                      </p>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 flex items-center gap-3">
                        <span>Requester: <strong>{p.requesterName}</strong></span>
                        <span>Category: {p.category}</span>
                        <span className="text-[10px] text-slate-400">{p.submittedAt}</span>
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                        p.status === 'Answered'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {p.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Counseling Appointments & Follow-ups */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                Pastoral Counseling Appointments
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Scheduled spiritual consultations, marriage care, and mentorship sessions.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('prayer_counseling')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1 cursor-pointer"
            >
              Appointment Desk &rarr;
            </button>
          </div>

          <div className="space-y-3">
            {scheduledAppointments.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No data available
              </div>
            ) : (
              scheduledAppointments.slice(0, 4).map((c) => (
                <div
                  key={c.id}
                  className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-sm text-slate-900 dark:text-white">{c.memberName}</div>
                    <div className="text-xs text-blue-600 dark:text-blue-400 font-semibold mt-0.5">{c.category}</div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-2">
                      <span className="font-medium">{c.scheduledDate} • {c.scheduledTime}</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                    {c.status}
                  </span>
                </div>
              ))
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setActiveModule('devotions')}
              className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-emerald-600" />
              Publish Daily Devotional & Pastoral Epistle
            </button>
          </div>
        </div>
      </div>

      {/* Quick Add Prayer Modal */}
      {newPrayerModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="text-lg font-black text-slate-900 dark:text-white mb-1">
              Log Confidential Prayer Petition
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Enter prayer requests for pastoral care and dedicated intercession coverage.
            </p>

            <form onSubmit={handleCreatePrayer} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Member / Requester Name
                </label>
                <input
                  type="text"
                  value={prayerRequester}
                  onChange={(e) => setPrayerRequester(e.target.value)}
                  placeholder="e.g. Sister Bethlehem or Anonymous"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Prayer Focus / Title *
                </label>
                <input
                  type="text"
                  required
                  value={prayerTopic}
                  onChange={(e) => setPrayerTopic(e.target.value)}
                  placeholder="e.g. Physical Healing & Family Restoration"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Petition Details
                </label>
                <textarea
                  rows={3}
                  value={prayerDesc}
                  onChange={(e) => setPrayerDesc(e.target.value)}
                  placeholder="Provide spiritual context for the pastoral prayer team..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="confidential"
                  checked={isConfidential}
                  onChange={(e) => setIsConfidential(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="confidential" className="text-xs text-slate-700 dark:text-slate-300 font-semibold cursor-pointer">
                  Mark as Strictly Confidential (Restricted to Pastoral Staff Only)
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setNewPrayerModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Save to Prayer Sanctuary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
