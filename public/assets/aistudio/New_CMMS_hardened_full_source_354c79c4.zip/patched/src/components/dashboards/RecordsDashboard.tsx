import React, { useState } from 'react';
import { useCMMS } from '../../context/CMMSContext';
import {
  FileText,
  Award,
  Users,
  UserPlus,
  BookOpen,
  Printer,
  Download,
  CheckCircle2,
  Clock,
  Search,
  Building2,
  Calendar,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

export const RecordsDashboard: React.FC = () => {
  const {
    members,
    documents,
    setActiveModule,
    systemName
  } = useCMMS();

  const [certModal, setCertModal] = useState(false);
  const [certType, setCertType] = useState('Baptism');
  const [recipientName, setRecipientName] = useState('');
  const [officiatingMinister, setOfficiatingMinister] = useState('');
  const [certDate, setCertDate] = useState(new Date().toISOString().split('T')[0]);

  const baptizedCount = members.filter((m) => m.isWaterBaptized).length;

  const certificateTemplates = [
    { id: 'cert-1', name: 'Water Baptism Certificate', count: baptizedCount, icon: Award, color: 'text-blue-600 bg-blue-50 dark:bg-blue-950' },
    { id: 'cert-2', name: 'Child Dedication Certificate', count: 0, icon: Award, color: 'text-purple-600 bg-purple-50 dark:bg-purple-950' },
    { id: 'cert-3', name: 'Holy Matrimony Certificate', count: 0, icon: Award, color: 'text-rose-600 bg-rose-50 dark:bg-rose-950' },
    { id: 'cert-4', name: 'Official Membership Transfer Letter', count: 0, icon: FileText, color: 'text-amber-600 bg-amber-50 dark:bg-amber-950' },
  ];

  const councilMinutes = documents.map((d) => ({
    title: d.title,
    date: d.uploadDate,
    author: d.uploadedBy,
    status: d.category,
  }));

  const handleGenerateCertificate = (type: string) => {
    setCertType(type);
    setCertModal(true);
  };

  return (
    <div className="space-y-6" id="records-secretary-dashboard">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-500/30 rounded-2xl p-5 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 tracking-wider uppercase flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                Church Records & Secretarial Office
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/10 text-slate-200">
                Official Seal Station
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Church Registry, Certificates & Council Archives
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Official Baptism & Dedication Certificates, Council Meeting Minutes, Demographic Audits & Fast Intake.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveModule('members')}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              Member Intake Desk
            </button>
            <button
              onClick={() => setActiveModule('documents')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-blue-400" />
              Document Vault
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Church Registry
            </span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{members.length}</span>
            <span className="text-xs font-semibold text-emerald-600">Registered</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Complete demographic index
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Certificates Issued
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{baptizedCount}</span>
            <span className="text-xs font-semibold text-purple-600">Recorded</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Baptism, Dedication & Marriage
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Council Minutes Stored
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{documents.length}</span>
            <span className="text-xs font-semibold text-amber-600">Documents</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Elder board & general council
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Demographic Audits
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">100% Valid</span>
            <span className="text-xs font-semibold text-emerald-600">Clean</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Zero duplicate member codes
          </p>
        </div>
      </div>

      {/* Certificate Generator & Meeting Minutes */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Certificate Generator Station */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-blue-600" />
                Official Church Certificate Issuance Station
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Generate and print customized baptism, child dedication, marriage, and transfer certificates.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {certificateTemplates.map((cert) => {
              const Icon = cert.icon;
              return (
                <div
                  key={cert.id}
                  className="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:border-blue-500 hover:shadow-xs transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2.5 mb-2">
                      <div className={`p-2 rounded-xl ${cert.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-sm text-slate-900 dark:text-white">{cert.name}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {cert.count} issued to date with official serial watermark.
                    </p>
                  </div>

                  <button
                    onClick={() => handleGenerateCertificate(cert.name)}
                    className="mt-4 w-full py-2 rounded-xl bg-slate-100 hover:bg-blue-600 hover:text-white dark:bg-slate-800 dark:hover:bg-blue-600 text-xs font-bold text-slate-700 dark:text-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Issue & Print Certificate
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Church Council Archives */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              Church Council Minutes
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Sealed proceedings of Elder Board sessions.
            </p>

            <div className="space-y-3">
              {councilMinutes.map((m, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-xs font-bold text-slate-900 dark:text-white">{m.title}</div>
                  <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                    <span>{m.date}</span>
                    <span className="font-semibold text-emerald-600">{m.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setActiveModule('documents')}
              className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-all flex items-center justify-center gap-1 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              Access Complete Secretarial Archive
            </button>
          </div>
        </div>
      </div>

      {/* Certificate Modal */}
      {certModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="text-center pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-600 mx-auto flex items-center justify-center mb-2">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                {certType}
              </h3>
              <p className="text-xs text-slate-500">{systemName || 'CMMS'}</p>
            </div>

            <div className="py-4 space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Recipient Full Name *
                </label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Officiating Minister / Presiding Elder *
                </label>
                <input
                  type="text"
                  value={officiatingMinister}
                  onChange={(e) => setOfficiatingMinister(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Date of Ordinance *
                </label>
                <input
                  type="date"
                  value={certDate}
                  onChange={(e) => setCertDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
              <button
                onClick={() => setCertModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                Print Certificate PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
