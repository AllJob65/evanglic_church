import React, { useState } from 'react';
import { useCMMS } from '../../context/CMMSContext';
import {
  UsersRound,
  Calendar,
  Send,
  CheckCircle2,
  Clock,
  UserCheck,
  Package,
  Layers,
  Sparkles,
  MessageSquare,
  Plus,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { StartConference } from '../GroupLeader/StartConference';
import { GroupLeaderQr } from '../GroupLeader/GroupLeaderQr';

export const MinistryDashboard: React.FC = () => {
  const {
    ministries,
    volunteerShifts,
    assets,
    members,
    events,
    setActiveModule
  } = useCMMS();

  const [selectedMinistryId, setSelectedMinistryId] = useState(ministries[0]?.id || '');
  const currentMinistry = ministries.find((m) => m.id === selectedMinistryId) || ministries[0] || {
    id: '',
    name: 'No Ministry Selected',
    category: '',
    leaderName: 'Unassigned',
    memberCount: 0,
    meetingTime: 'Not scheduled',
    meetingSchedule: 'Not scheduled',
    description: 'No ministries available.'
  };

  const volunteerRoster = (volunteerShifts || [])
    .filter((v) => !currentMinistry.id || v.ministryId === currentMinistry.id)
    .map((v) => ({
      name: v.memberName,
      role: v.role,
      status: v.status,
      event: `${v.serviceDate} • ${v.shiftTime}`,
    }));

  const resourceRequests = (assets || []).map((a) => ({
    item: a.name,
    qty: 1,
    status: a.condition,
    urgency: 'Normal',
  }));

  return (
    <div className="space-y-6" id="ministry-leader-dashboard">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-500/30 rounded-2xl p-5 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-purple-500/20 text-purple-300 border border-purple-500/40 tracking-wider uppercase flex items-center gap-1.5">
                <UsersRound className="w-3.5 h-3.5 text-purple-400" />
                Ministry Leader & Volunteer Operations
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/10 text-slate-200">
                {currentMinistry.name}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {currentMinistry.name} Command Center
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              Volunteer Rosters, Duty Scheduling, Department Attendance Check-ins & Equipment Requests.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Ministry Switcher */}
            <select
              value={selectedMinistryId}
              onChange={(e) => setSelectedMinistryId(e.target.value)}
              className="px-3 py-2 text-xs font-bold rounded-xl bg-purple-900/60 border border-purple-400/40 text-white focus:outline-hidden cursor-pointer"
            >
              {ministries.map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-white">
                  {m.name}
                </option>
              ))}
            </select>

            <button
              onClick={() => setActiveModule('communications')}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              Broadcast Team SMS
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Enlisted Volunteers
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <UsersRound className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {currentMinistry.memberCount || 0}
            </span>
            <span className="text-xs font-semibold text-emerald-600">Active Roster</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Leader: {currentMinistry.leaderName || 'Unassigned'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Service Roster Assigned
            </span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{volunteerRoster.length}</span>
            <span className="text-xs font-semibold text-blue-600">Assigned</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Scheduled volunteer shifts
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Weekly Practice & Rehearsals
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-lg font-black text-slate-900 dark:text-white">{currentMinistry.meetingSchedule || currentMinistry.meetingTime || 'None'}</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Scheduled gathering time
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Equipment & Assets
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{resourceRequests.length}</span>
            <span className="text-xs font-semibold text-emerald-600">Items</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Registered inventory assets
          </p>
        </div>
      </div>

      {/* Group Leader Live WebRTC Video Conference & Live Chat Dispatcher */}
      <StartConference
        groupId={currentMinistry.id}
        leaderId="leader-user-current"
        groupName={currentMinistry.name}
        onOpenLiveChat={() => setActiveModule('communications')}
      />

      {/* Official Group Leader Attendance QR Generator Station */}
      <GroupLeaderQr
        ministryId={currentMinistry.id}
        ministryName={currentMinistry.name}
        serviceType="Group Session"
      />

      {/* Volunteer Duty Roster & Requisition Desk */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Service Volunteer Duty Roster */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-purple-600" />
                Sunday Service Volunteer Duty Schedule
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Assigned team duties for upcoming corporate worship services.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('attendance')}
              className="text-xs font-bold text-purple-600 hover:text-purple-700 dark:text-purple-400 flex items-center gap-1 cursor-pointer"
            >
              Take Ministry Attendance &rarr;
            </button>
          </div>

          <div className="space-y-3">
            {volunteerRoster.map((v, i) => (
              <div
                key={i}
                className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-sm text-slate-900 dark:text-white">{v.name}</div>
                  <div className="text-xs text-purple-600 dark:text-purple-400 font-semibold mt-0.5">{v.role}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">{v.event}</div>
                </div>
                <span
                  className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                    v.status === 'Confirmed'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                  }`}
                >
                  {v.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right 1 Col: Department Equipment & Resource Requests */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-2">
              <Package className="w-4 h-4 text-indigo-600" />
              Department Gear & Resource Queue
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Requisitions submitted to Church Administration.
            </p>

            <div className="space-y-3">
              {resourceRequests.map((r, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">{r.item}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">Quantity: {r.qty} Units</div>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        (r.status === 'Excellent' || r.status === 'Good')
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                      }`}
                    >
                      {r.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setActiveModule('ministries')}
              className="w-full py-2 rounded-xl bg-purple-50 dark:bg-purple-950 text-xs font-bold text-purple-700 dark:text-purple-300 hover:bg-purple-100 transition-all flex items-center justify-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Submit New Equipment Requisition
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
