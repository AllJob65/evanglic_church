import React, { useState } from 'react';
import { useCMMS } from '../../context/CMMSContext';
import {
  User,
  Heart,
  Calendar,
  Flame,
  QrCode,
  CheckCircle2,
  Clock,
  Sparkles,
  Download,
  Plus,
  ArrowUpRight,
  ShieldCheck,
  Send,
  BookOpen,
  Award
} from 'lucide-react';
import { MemberGroupPortal } from '../Member/MemberGroupPortal';
import { MemberAttendancePortal } from '../Member/MemberAttendancePortal';

export const MemberPortalDashboard: React.FC = () => {
  const {
    userProfile,
    families,
    ministries,
    events,
    prayerRequests,
    addPrayerRequest,
    setActiveModule,
    systemName
  } = useCMMS();

  const displayName = userProfile?.name || (userProfile ? `${userProfile.firstName || ''} ${userProfile.lastName || ''}`.trim() : 'Member');
  const memberCode = userProfile?.memberCode || userProfile?.memberIdNumber || 'Unassigned';

  const myFamily = families.find((f) => f.id === (userProfile as any)?.familyId);
  const myMinistry = ministries.find((m) => (userProfile as any)?.ministryIds?.includes(m.id)) || ministries[0];

  const [prayerModal, setPrayerModal] = useState(false);
  const [prayerTopic, setPrayerTopic] = useState('');
  const [prayerDesc, setPrayerDesc] = useState('');

  const myRegisteredEvents = events.slice(0, 2);
  const myRecentPrayers = prayerRequests.slice(0, 3);

  const handlePrayerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerTopic.trim()) return;
    addPrayerRequest({
      id: `pr-${Date.now()}`,
      requestNumber: `PR-${Date.now().toString().slice(-4)}`,
      memberId: userProfile?.id || 'mem-default',
      memberName: displayName,
      requesterName: displayName,
      topic: prayerTopic.trim(),
      title: prayerTopic.trim(),
      description: prayerDesc.trim(),
      details: prayerDesc.trim(),
      category: 'Personal Member Care',
      priority: 'Normal',
      urgency: 'Medium',
      isConfidential: true,
      status: 'Pending',
      submittedDate: new Date().toISOString().split('T')[0],
      submittedAt: new Date().toISOString().split('T')[0]
    });
    setPrayerTopic('');
    setPrayerDesc('');
    setPrayerModal(false);
  };

  return (
    <div className="space-y-6" id="member-portal-dashboard">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 border border-blue-500/30 rounded-2xl p-5 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-white font-black text-xl shrink-0 overflow-hidden shadow-inner">
              {userProfile?.photoUrl ? (
                <img src={userProfile.photoUrl} alt={displayName} className="w-full h-full object-cover" />
              ) : (
                <User className="w-7 h-7 text-blue-300" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 tracking-wider uppercase">
                  Member Portal
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                  Active in Covenant
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Welcome back, {displayName}!
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Member Code: <strong className="font-mono text-amber-300">{memberCode}</strong> • Main Sanctuary Campus
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setPrayerModal(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Flame className="w-4 h-4 text-amber-400" />
              Request Prayer
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Discipleship & Attendance
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {(userProfile as any)?.attendanceScore !== undefined ? `${(userProfile as any).attendanceScore}%` : 'N/A'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Sunday & Midweek Gatherings
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Household / Family
            </span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400">
              <Heart className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {myFamily ? `${myFamily.memberCount || 0} Members` : 'None'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {myFamily ? myFamily.familyName : 'No household linked'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Enlisted Ministry
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-lg font-black text-slate-900 dark:text-white">
              {myMinistry ? myMinistry.name : 'No Ministry'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            {myMinistry ? myMinistry.category : 'Not enrolled'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Active Petitions
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Flame className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{myRecentPrayers.length}</span>
            <span className="text-xs font-semibold text-amber-600">Under Prayer</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Pastoral prayer cover active
          </p>
        </div>
      </div>

      {/* Member Live Group Communications & WebRTC Video Call Portal */}
      <MemberGroupPortal
        groupId={userProfile?.ministryIds?.[0] || 'min-1'}
        groupName="Worship & Praise Fellowship"
        memberId={userProfile?.id || 'mem-default'}
        onOpenChat={() => setActiveModule('communications')}
      />

      {/* Member Ministry Attendance Portal (1-Click Web Check-In & Group Leader QR Scanner) */}
      <MemberAttendancePortal />

      {/* Two Columns: Upcoming Church Services & Personal Devotional Hub */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Events & Attendance Pass */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                My Upcoming Services & Gatherings
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Check in above via 1-Click Web Check-In or by scanning your group leader's QR code.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {myRegisteredEvents.map((e) => (
              <div
                key={e.id}
                className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-50 transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-sm text-slate-900 dark:text-white">{e.title}</div>
                  <div className="text-xs text-blue-600 dark:text-blue-400 font-semibold mt-0.5">
                    {e.date} • {e.time || '09:00 AM - 12:00 PM'}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">{e.location || 'Main Sanctuary Auditorium'}</div>
                </div>

                <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-600 dark:text-blue-400 font-semibold text-xs border border-blue-500/20">
                  Enrolled
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Daily Devotional & Pastoral Word */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-emerald-600" />
                Today's Daily Manna Devotional
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                Fresh Word
              </span>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/50 dark:border-emerald-800/40">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                "Walking in the Supernatural Grace of God"
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed italic">
                "And God is able to make all grace abound toward you, that you, always having all sufficiency in all things, may have an abundance for every good work." — 2 Corinthians 9:8
              </p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <button
              onClick={() => setActiveModule('devotions')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1 cursor-pointer"
            >
              Read Full Devotional Library &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Prayer Request Modal */}
      {prayerModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="text-lg font-black text-slate-900 dark:text-white mb-1">
              Submit Prayer Petition
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Our Pastoral and Intercession Team will lift your request up before the Lord.
            </p>

            <form onSubmit={handlePrayerSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Prayer Focus *
                </label>
                <input
                  type="text"
                  required
                  value={prayerTopic}
                  onChange={(e) => setPrayerTopic(e.target.value)}
                  placeholder="e.g. Healing, Family Breakthrough, Exams"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Details / Specific Needs
                </label>
                <textarea
                  rows={3}
                  value={prayerDesc}
                  onChange={(e) => setPrayerDesc(e.target.value)}
                  placeholder="Share details so our prayer warriors can stand in agreement..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPrayerModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Send to Pastoral Prayer Cover
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
