import React, { useState, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Ministry, MonthlyBudgetItem, MinistryActivityLog } from '../types';
import { supabaseMinistryService } from '../services/supabaseMinistryService';
import { MinistryLiveChatModal } from './MinistryLiveChatModal';
import { RealtimeConnectionIndicator } from './RealtimeConnectionIndicator';
import { StartConference } from './GroupLeader/StartConference';
import { MinistryAnnualPlanningManager } from './MinistryAnnualPlanningManager';
import {
  UsersRound,
  Plus,
  DollarSign,
  Calendar,
  CheckSquare,
  Square,
  UserCheck,
  Trash2,
  X,
  Layers,
  MessageSquare,
  Activity,
  Radio,
  Sparkles,
  Send,
  Video,
  Clock,
  Shield,
  CheckCircle2,
  FileText,
  Loader2,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const MinistryModule: React.FC = () => {
  const {
    ministries,
    addMinistry,
    updateMinistry,
    deleteMinistry,
    deleteSubMinistry,
    refreshMinistries,
    branches,
    members,
    attendanceRecords,
    permissions,
    currency,
    currentUser,
    activeRole,
    t,
  } = useCMMS();

  const [selectedMinistry, setSelectedMinistry] = useState<Ministry | null>(ministries[0] || null);
  const [activeTab, setActiveTab] = useState<'annual_planning' | 'overview' | 'budget' | 'attendance' | 'subministries' | 'activity'>('annual_planning');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);

  // Persistence, Form, and Error/Success Feedback State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmittingSub, setIsSubmittingSub] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [subFormError, setSubFormError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoadingMinistries, setIsLoadingMinistries] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // New Ministry Form
  const [newMinistryName, setNewMinistryName] = useState('');
  const [newMinistryDesc, setNewMinistryDesc] = useState('');
  const [newBudget, setNewBudget] = useState(15000);
  const [selectedBranchId, setSelectedBranchId] = useState<string>(branches[0]?.id || 'br-001');
  const [selectedDirectorId, setSelectedDirectorId] = useState<string>('');

  // Sub-ministry form
  const [isAddSubModalOpen, setIsAddSubModalOpen] = useState(false);
  const [subName, setSubName] = useState('');
  const [subLeaderName, setSubLeaderName] = useState('');

  // Selected Month for Budget & To-Do List
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(0);
  const [newTodoInput, setNewTodoInput] = useState<string>('');

  // Real-time Activity Logs State
  const [activityLogs, setActivityLogs] = useState<MinistryActivityLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState<boolean>(false);
  const [newLogTitle, setNewLogTitle] = useState<string>('');
  const [newLogDesc, setNewLogDesc] = useState<string>('');

  const getMember = (id?: string) => members.find((m) => m.id === id);

  // Keep selected ministry synchronized with database records
  useEffect(() => {
    if (ministries && ministries.length > 0) {
      if (!selectedMinistry || !ministries.some((m) => m.id === selectedMinistry.id)) {
        setSelectedMinistry(ministries[0]);
      } else {
        const matching = ministries.find((m) => m.id === selectedMinistry.id);
        if (matching) setSelectedMinistry(matching);
      }
    } else {
      setSelectedMinistry(null);
    }
  }, [ministries]);

  // Initial load / revalidation on mount
  useEffect(() => {
    let active = true;
    setIsLoadingMinistries(true);
    setFetchError(null);
    refreshMinistries()
      .then((data) => {
        if (active) {
          setIsLoadingMinistries(false);
          if (data && data.length > 0 && !selectedMinistry) {
            setSelectedMinistry(data[0]);
          }
        }
      })
      .catch((err) => {
        if (active) {
          setIsLoadingMinistries(false);
          setFetchError(err?.message || 'Unable to load ministries. Please check your connection.');
        }
      });
    return () => {
      active = false;
    };
  }, []);

  // Set default branch and director when branches or members load
  useEffect(() => {
    if (branches.length > 0 && !selectedBranchId) {
      setSelectedBranchId(branches[0].id);
    }
    if (members.length > 0 && !selectedDirectorId) {
      setSelectedDirectorId(members[0].id);
    }
  }, [branches, members]);

  // Fetch activity logs for the selected ministry
  useEffect(() => {
    if (!selectedMinistry) return;
    setIsLoadingLogs(true);

    supabaseMinistryService
      .getActivityLogs(selectedMinistry.id)
      .then((logs) => {
        setActivityLogs(logs);
        setIsLoadingLogs(false);
      })
      .catch(() => setIsLoadingLogs(false));

    // Subscribe to realtime activity updates
    const subscription = supabaseMinistryService.subscribeToMinistryActivity(
      selectedMinistry.id,
      (newActivity) => {
        setActivityLogs((prev) => [newActivity, ...prev]);
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedMinistry?.id]);

  const handlePostActivityLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMinistry || !newLogTitle.trim()) return;

    await supabaseMinistryService.createActivityLog(
      selectedMinistry.id,
      {
        actionType: 'message_posted',
        title: newLogTitle.trim(),
        description: newLogDesc.trim() || undefined,
        userName: currentUser?.name || 'Ministry Leader',
        userId: currentUser?.memberId || 'usr-leader',
      }
    );

    // Refresh logs
    const updated = await supabaseMinistryService.getActivityLogs(selectedMinistry.id);
    setActivityLogs(updated);
    setNewLogTitle('');
    setNewLogDesc('');
  };

  const handleCreateMinistry = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanName = newMinistryName.trim();
    if (!cleanName) {
      setFormError('Ministry name is required.');
      return;
    }

    // Duplicate check in existing ministries (case-insensitive)
    const isDuplicate = ministries.some(
      (m) => m.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (isDuplicate) {
      setFormError('A ministry with this name already exists in this church.');
      return;
    }

    setIsSubmitting(true);

    const defaultMonthlyAllocations: MonthlyBudgetItem[] = MONTH_NAMES.map((month, idx) => ({
      month,
      amount: Math.round(newBudget / 12),
      purpose: `${cleanName} ${month} Operational Programs & Ministry Outreach`,
      status: 'Allocated',
      todos: [
        { id: `todo-${idx}-1`, task: `Prepare ${month} ministry budget report`, isCompleted: false, actionType: 'Do' },
        { id: `todo-${idx}-2`, task: `Schedule ${month} volunteer roster`, isCompleted: false, actionType: 'Do' },
        { id: `todo-${idx}-3`, task: `Execute ${month} community engagement event`, isCompleted: false, actionType: 'Do' },
      ],
    }));

    const newM: Partial<Ministry> = {
      name: cleanName,
      description: newMinistryDesc.trim() || 'Departmental ministry driving church vision and community impact.',
      branchId: selectedBranchId || branches[0]?.id || 'br-001',
      directorMemberId: selectedDirectorId || members[0]?.id || 'mem-101',
      establishedDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      memberCount: 1,
      annualBudget: Number(newBudget) || 15000,
      spentBudget: 0,
      monthlyAllocations: defaultMonthlyAllocations,
      subMinistries: [],
    };

    try {
      // Send to backend and await confirmed database persistence
      const saved = await addMinistry(newM);
      setSelectedMinistry(saved);
      setIsCreateModalOpen(false);
      setNewMinistryName('');
      setNewMinistryDesc('');
      setNewBudget(15000);
      setFormError(null);
      setSuccessMessage('Ministry registered successfully.');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error('Failed to register ministry:', err);
      let errMsg = 'Unable to save ministry. Please try again.';
      if (err?.message) {
        if (err.message.includes('already exists')) {
          errMsg = 'A ministry with this name already exists in this church.';
        } else if (err.message.includes('permission') || err.message.includes('403') || err.message.includes('FORBIDDEN')) {
          errMsg = 'You do not have permission to perform this action.';
        } else if (err.message.includes('session') || err.message.includes('401')) {
          errMsg = 'Your session has expired. Please sign in again.';
        } else if (err.message.includes('Failed to fetch') || err.message.includes('connect')) {
          errMsg = 'Unable to connect to the server. Please check your connection.';
        } else {
          errMsg = err.message;
        }
      }
      setFormError(errMsg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddSubMinistry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMinistry) return;

    const cleanSub = subName.trim();
    if (!cleanSub) {
      setSubFormError('Sub-unit name is required.');
      return;
    }

    setIsSubmittingSub(true);
    setSubFormError(null);

    const newSub = {
      id: `sub-${Date.now().toString().slice(-4)}`,
      name: cleanSub,
      leaderName: subLeaderName.trim() || 'Voluntary Leader',
      memberCount: 5,
    };

    const updated: Ministry = {
      ...selectedMinistry,
      subMinistries: [...(selectedMinistry.subMinistries || []), newSub],
    };

    try {
      const saved = await updateMinistry(updated);
      setSelectedMinistry(saved);
      setIsAddSubModalOpen(false);
      setSubName('');
      setSubLeaderName('');
      setSuccessMessage('Sub-unit added successfully.');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setSubFormError(err?.message || 'Unable to save sub-unit. Please try again.');
    } finally {
      setIsSubmittingSub(false);
    }
  };

  const handleDeleteMinistry = async () => {
    if (!selectedMinistry) return;
    setIsDeleting(true);
    try {
      await deleteMinistry(selectedMinistry.id);
      setDeleteConfirmOpen(false);
      const remaining = ministries.filter((m) => m.id !== selectedMinistry.id);
      setSelectedMinistry(remaining[0] || null);
      setSuccessMessage('Ministry deleted successfully.');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(err?.message || 'Unable to delete ministry. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const activeMinistry = selectedMinistry
    ? {
        ...selectedMinistry,
        monthlyAllocations:
          selectedMinistry.monthlyAllocations && selectedMinistry.monthlyAllocations.length === 12
            ? selectedMinistry.monthlyAllocations
            : MONTH_NAMES.map((month, idx) => ({
                month,
                amount: Math.round((selectedMinistry.annualBudget || 12000) / 12),
                purpose: `${selectedMinistry.name} ${month} Operational Programs & Outreach Objectives`,
                status: 'Allocated' as const,
                todos: [
                  { id: `todo-${idx}-1`, task: `Prepare ${month} ministry budget breakdown`, isCompleted: true, actionType: 'Do' as const },
                  { id: `todo-${idx}-2`, task: `Schedule ${month} volunteer roster`, isCompleted: false, actionType: 'Do' as const },
                  { id: `todo-${idx}-3`, task: `Execute ${month} community engagement event`, isCompleted: false, actionType: 'Do' as const },
                ],
              })),
      }
    : null;

  const handleToggleTodo = (monthIdx: number, todoId: string) => {
    if (!activeMinistry) return;

    const updatedAllocations = activeMinistry.monthlyAllocations.map((alloc, idx) => {
      if (idx !== monthIdx) return alloc;
      return {
        ...alloc,
        todos: alloc.todos.map((t) => (t.id === todoId ? { ...t, isCompleted: !t.isCompleted } : t)),
      };
    });

    const updatedMin = { ...activeMinistry, monthlyAllocations: updatedAllocations };
    updateMinistry(updatedMin);
    setSelectedMinistry(updatedMin);
  };

  const handleAddTodoItem = (monthIdx: number) => {
    if (!activeMinistry || !newTodoInput.trim()) return;

    const updatedAllocations = activeMinistry.monthlyAllocations.map((alloc, idx) => {
      if (idx !== monthIdx) return alloc;
      return {
        ...alloc,
        todos: [
          ...alloc.todos,
          { id: `todo-${Date.now()}`, task: newTodoInput.trim(), isCompleted: false, actionType: 'Do' as const },
        ],
      };
    });

    const updatedMin = { ...activeMinistry, monthlyAllocations: updatedAllocations };
    updateMinistry(updatedMin);
    setSelectedMinistry(updatedMin);
    setNewTodoInput('');
  };

  const ministryMembers = members.filter((m) => selectedMinistry && m.ministryIds.includes(selectedMinistry.id));
  const ministryMemberIds = ministryMembers.map((m) => m.id);
  const relevantAttendance = attendanceRecords.filter((a) => ministryMemberIds.includes(a.memberId));

  const totalAllocated = selectedMinistry?.monthlyAllocations
    ? selectedMinistry.monthlyAllocations.reduce((sum, item) => sum + item.amount, 0)
    : selectedMinistry?.annualBudget || 0;

  return (
    <div className="space-y-6">
      {/* Status Feedback Banners */}
      {successMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-200 font-semibold animate-in fade-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-700 hover:text-emerald-900 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {fetchError && (
        <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center justify-between text-xs text-rose-800 dark:text-rose-200 font-medium">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600" />
            <span>{fetchError}</span>
          </div>
          <button
            onClick={() => refreshMinistries()}
            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" /> Retry
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <UsersRound className="w-6 h-6 text-purple-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Ministry & Department Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200">
              {ministries.length} Active Ministries
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Departmental structures, annual budget allocations, realtime collaboration, and attendance tracking.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => refreshMinistries()}
            title="Reload ministries from database"
            className="min-h-[44px] px-3 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingMinistries ? 'animate-spin text-purple-600' : ''}`} />
            <span>Sync</span>
          </button>

          <button
            onClick={() => setIsLiveChatOpen(true)}
            className="min-h-[44px] px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Live Fellowship Chat</span>
          </button>

          {permissions.canManageMinistries && (
            <button
              onClick={() => { setFormError(null); setIsCreateModalOpen(true); }}
              className="min-h-[44px] px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Establish Ministry</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ministries List Column */}
        <div className="space-y-3">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white uppercase tracking-wider text-xs">
            Ministry Registry
          </h3>

          <div className="space-y-2">
            {isLoadingMinistries && ministries.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
                <Loader2 className="w-6 h-6 text-purple-600 animate-spin mb-2" />
                <p className="text-xs text-slate-500 font-medium">Loading ministries...</p>
              </div>
            ) : ministries.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                <UsersRound className="w-8 h-8 text-slate-300 dark:text-slate-600 mb-2" />
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">No ministries have been registered yet.</p>
                {permissions.canManageMinistries && (
                  <button
                    onClick={() => { setFormError(null); setIsCreateModalOpen(true); }}
                    className="mt-3 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Establish Ministry
                  </button>
                )}
              </div>
            ) : (
              ministries.map((min) => {
                const isSelected = selectedMinistry?.id === min.id;
                const director = getMember(min.directorMemberId);
                return (
                  <div
                    key={min.id}
                    onClick={() => setSelectedMinistry(min)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-purple-50/80 dark:bg-purple-950/60 border-purple-500 shadow-md ring-2 ring-purple-500/20'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{min.name}</h4>
                      <span className="w-2 h-2 rounded-full bg-emerald-500" title="Online Sync" />
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Director: {director ? `${director.firstName} ${director.lastName}` : 'TBD'}
                    </p>

                    <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-slate-500">{min.memberCount} Members</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        Budget: {currency} ${min.annualBudget.toLocaleString()}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Selected Ministry Detail View */}
        <div className="lg:col-span-2 space-y-6">
          {selectedMinistry ? (
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">{selectedMinistry.name}</h2>
                    <RealtimeConnectionIndicator
                      channelName={`ministry-activity-health-${selectedMinistry.id}`}
                      tableName="ministry_activity_logs"
                      variant="pill"
                    />
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{selectedMinistry.description}</p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setIsLiveChatOpen(true)}
                    className="min-h-[44px] px-3.5 py-2.5 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-bold border border-indigo-200 dark:border-indigo-800/60 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Open Chat</span>
                  </button>

                  {permissions.canManageMinistries && (
                    <button
                      onClick={() => setDeleteConfirmOpen(true)}
                      title="Delete Ministry"
                      className="min-h-[44px] px-3 py-2.5 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-bold border border-rose-200 dark:border-rose-800/60 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Delete</span>
                    </button>
                  )}

                  <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/50 border border-purple-200 dark:border-purple-800 text-right">
                    <span className="text-xs text-slate-500 block">Annual Budget</span>
                    <span className="text-lg font-bold text-purple-600 dark:text-purple-400">
                      {currency} ${selectedMinistry.annualBudget.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Sub-tabs Navigation */}
              <div className="flex border-b border-slate-200 dark:border-slate-800 gap-3 sm:gap-6 text-xs font-semibold overflow-x-auto pb-1">
                <button
                  onClick={() => setActiveTab('annual_planning')}
                  className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    activeTab === 'annual_planning'
                      ? 'border-indigo-500 text-indigo-500 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-4 h-4" /> Annual Planning & Reporting (Q1–Q4)
                </button>
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    activeTab === 'overview'
                      ? 'border-purple-600 text-purple-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <UsersRound className="w-4 h-4" /> Overview & Roster
                </button>
                <button
                  onClick={() => setActiveTab('activity')}
                  className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    activeTab === 'activity'
                      ? 'border-purple-600 text-purple-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Activity className="w-4 h-4" /> Realtime Activity Stream ({activityLogs.length})
                </button>
                <button
                  onClick={() => setActiveTab('budget')}
                  className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    activeTab === 'budget'
                      ? 'border-purple-600 text-purple-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <DollarSign className="w-4 h-4" /> Annual Budget Allocation
                </button>
                <button
                  onClick={() => setActiveTab('attendance')}
                  className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    activeTab === 'attendance'
                      ? 'border-purple-600 text-purple-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <UserCheck className="w-4 h-4" /> Attendance Tracking
                </button>
                <button
                  onClick={() => setActiveTab('subministries')}
                  className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    activeTab === 'subministries'
                      ? 'border-purple-600 text-purple-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Layers className="w-4 h-4" /> Sub-Ministries ({selectedMinistry.subMinistries?.length || 0})
                </button>
              </div>

              {/* TAB 0: MINISTRY ANNUAL PLANNING & REPORTING WORKFLOW */}
              {activeTab === 'annual_planning' && (
                <MinistryAnnualPlanningManager
                  ministries={ministries}
                  selectedMinistry={selectedMinistry}
                  currency={currency}
                  currentUser={currentUser}
                  activeRole={activeRole}
                />
              )}

              {/* TAB 1: OVERVIEW & ROSTER */}
              {activeTab === 'overview' && (
                <div className="space-y-4 text-xs">
                  {/* Group Leader Video & Chat Control Center */}
                  <StartConference
                    groupId={selectedMinistry.id}
                    leaderId={currentUser?.memberId || 'usr-leader'}
                    groupName={selectedMinistry.name}
                    onOpenLiveChat={() => setIsLiveChatOpen(true)}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                      <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                        Leadership Structure
                      </h4>
                      <p>
                        <strong>Director:</strong> {getMember(selectedMinistry.directorMemberId)?.firstName}{' '}
                        {getMember(selectedMinistry.directorMemberId)?.lastName}
                      </p>
                      <p><strong>Established Date:</strong> {selectedMinistry.establishedDate}</p>
                      <p><strong>Enrolled Volunteers:</strong> {selectedMinistry.memberCount} Members</p>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                      <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                        Budget Summary
                      </h4>
                      <p><strong>Total Annual Allocation:</strong> {currency} ${selectedMinistry.annualBudget.toLocaleString()}</p>
                      <p><strong>Spent YTD:</strong> {currency} ${selectedMinistry.spentBudget.toLocaleString()}</p>
                      <p><strong>Remaining Balance:</strong> {currency} ${(selectedMinistry.annualBudget - selectedMinistry.spentBudget).toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-bold text-slate-900 dark:text-white">Assigned Ministry Members ({ministryMembers.length})</h4>
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                      {ministryMembers.map((m) => (
                        <div key={m.id} className="p-3 bg-white dark:bg-slate-900 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <img src={m.photoUrl} alt="" className="w-8 h-8 rounded-lg object-cover" />
                            <div>
                              <p className="font-bold text-slate-900 dark:text-white">{m.firstName} {m.lastName}</p>
                              <p className="text-[10px] text-slate-500">{m.occupation}</p>
                            </div>
                          </div>
                          <span className="text-purple-600 font-semibold">{m.primaryPhone}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: REALTIME ACTIVITY STREAM (Step 11) */}
              {activeTab === 'activity' && (
                <div className="space-y-5 text-xs">
                  {/* Post Announcement / Activity Form */}
                  <form onSubmit={handlePostActivityLog} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-3">
                    <h4 className="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                      Post Realtime Ministry Milestone / Announcement
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        placeholder="Milestone title (e.g. Choir Rehearsal Updated)"
                        value={newLogTitle}
                        onChange={(e) => setNewLogTitle(e.target.value)}
                        className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                      />
                      <input
                        type="text"
                        placeholder="Description or details..."
                        value={newLogDesc}
                        onChange={(e) => setNewLogDesc(e.target.value)}
                        className="px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        disabled={!newLogTitle.trim()}
                        className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Log Activity
                      </button>
                    </div>
                  </form>

                  {/* Activity List */}
                  <div className="space-y-2">
                    <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                      Live Ministry Events Feed
                    </h4>

                    {isLoadingLogs ? (
                      <div className="p-8 text-center text-slate-400">Loading activity feed...</div>
                    ) : activityLogs.length === 0 ? (
                      <div className="p-6 text-center text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                        No activity recorded yet. Post an announcement or interact in live chat!
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {activityLogs.map((log, idx) => (
                          <div
                            key={log.id ? `${log.id}-${idx}` : `act-${idx}`}
                            className="p-3.5 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/70 flex items-start gap-3 shadow-xs"
                          >
                            <div className="p-2 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shrink-0">
                              <Activity className="w-4 h-4" />
                            </div>
                            <div className="flex-1 space-y-0.5">
                              <div className="flex items-center justify-between">
                                <p className="font-bold text-slate-900 dark:text-white text-xs">{log.title}</p>
                                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {new Date(log.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              {log.description && (
                                <p className="text-slate-600 dark:text-slate-300 text-[11px]">{log.description}</p>
                              )}
                              <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold">
                                By {log.userName || 'Ministry Coordinator'}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: ANNUAL BUDGET ALLOCATION */}
              {activeTab === 'budget' && (
                <div className="space-y-6 text-xs">
                  <div className="p-5 bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
                    <div>
                      <span className="text-xs text-purple-200 font-semibold uppercase tracking-wider">
                        Dedicated Annual Budget Allocation
                      </span>
                      <h3 className="text-2xl font-black mt-1">
                        {currency} ${selectedMinistry.annualBudget.toLocaleString()}
                      </h3>
                      <p className="text-xs text-purple-200 mt-0.5">
                        Allocated across 12 monthly operation cycles with custom task planning.
                      </p>
                    </div>

                    <div className="text-right bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/20">
                      <span className="text-[11px] text-purple-200 block">Total Monthly Sum</span>
                      <span className="text-lg font-bold">{currency} ${totalAllocated.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-bold text-slate-900 dark:text-white">12-Month Allocation Schedule</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                      {MONTH_NAMES.map((month, idx) => {
                        const isSelectedMonth = selectedMonthIndex === idx;
                        const alloc = activeMinistry?.monthlyAllocations?.[idx];
                        const completedCount = alloc?.todos?.filter((t) => t.isCompleted).length || 0;
                        const totalTodos = alloc?.todos?.length || 0;

                        return (
                          <div
                            key={month}
                            onClick={() => setSelectedMonthIndex(idx)}
                            className={`p-3 rounded-xl border transition-all cursor-pointer ${
                              isSelectedMonth
                                ? 'bg-purple-50 dark:bg-purple-950/70 border-purple-500 ring-2 ring-purple-500/20'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                            }`}
                          >
                            <p className="font-bold text-slate-900 dark:text-white text-xs">{month}</p>
                            <p className="text-purple-600 dark:text-purple-400 font-bold mt-1">
                              {currency} ${alloc?.amount.toLocaleString() || '0'}
                            </p>
                            <p className="text-[10px] text-slate-400 mt-1">
                              Tasks: {completedCount}/{totalTodos} Done
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Selected Month Task Checklist */}
                  {activeMinistry && (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 space-y-3">
                      <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                        {MONTH_NAMES[selectedMonthIndex]} Ministry Action Items
                      </h4>

                      <div className="space-y-2">
                        {activeMinistry.monthlyAllocations[selectedMonthIndex]?.todos?.map((td) => (
                          <div
                            key={td.id}
                            onClick={() => handleToggleTodo(selectedMonthIndex, td.id)}
                            className="flex items-center gap-2.5 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 cursor-pointer"
                          >
                            {td.isCompleted ? (
                              <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                            <span className={td.isCompleted ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}>
                              {td.task}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="flex gap-2 pt-2">
                        <input
                          type="text"
                          value={newTodoInput}
                          onChange={(e) => setNewTodoInput(e.target.value)}
                          placeholder="Add new action item for this month..."
                          className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => handleAddTodoItem(selectedMonthIndex)}
                          className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
                        >
                          Add Task
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: ATTENDANCE */}
              {activeTab === 'attendance' && (
                <div className="space-y-4 text-xs">
                  <h4 className="font-bold text-slate-900 dark:text-white">Ministry Attendance Records</h4>
                  {relevantAttendance.length === 0 ? (
                    <p className="text-slate-400 italic">No attendance records logged for members of this ministry.</p>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                      {relevantAttendance.slice(0, 10).map((att) => (
                        <div key={att.id} className="p-3 bg-white dark:bg-slate-900 flex items-center justify-between">
                          <div>
                            <p className="font-bold text-slate-900 dark:text-white">{att.memberName}</p>
                            <p className="text-[10px] text-slate-400">{att.serviceType} • {att.date}</p>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            att.status === 'Present' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {att.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: SUB-MINISTRIES */}
              {activeTab === 'subministries' && (
                <div className="space-y-4 text-xs">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 dark:text-white">Sub-Units & Teams</h4>
                    <button
                      onClick={() => setIsAddSubModalOpen(true)}
                      className="px-3 py-1.5 bg-purple-600 text-white rounded-xl font-bold flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Sub-Unit
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(selectedMinistry.subMinistries || []).map((sub) => (
                      <div key={sub.id} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-1">
                        <p className="font-bold text-slate-900 dark:text-white">{sub.name}</p>
                        <p className="text-slate-500">Lead: {sub.leaderName}</p>
                        <p className="text-slate-400 text-[10px]">{sub.memberCount} Team Members</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-12 text-center text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              Select a ministry to view details
            </div>
          )}
        </div>
      </div>

      {/* Live Fellowship Chat Modal */}
      {isLiveChatOpen && (
        <MinistryLiveChatModal
          isOpen={isLiveChatOpen}
          onClose={() => setIsLiveChatOpen(false)}
          initialMinistryId={selectedMinistry?.id}
        />
      )}

      {/* Create Ministry Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Establish New Ministry</h3>
              <button
                onClick={() => {
                  if (!isSubmitting) {
                    setIsCreateModalOpen(false);
                    setFormError(null);
                  }
                }}
                disabled={isSubmitting}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreateMinistry} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Ministry Name *</label>
                <input
                  type="text"
                  required
                  disabled={isSubmitting}
                  value={newMinistryName}
                  onChange={(e) => {
                    setNewMinistryName(e.target.value);
                    if (formError) setFormError(null);
                  }}
                  placeholder="e.g. Media & Tech Ministry, Youth Fellowship"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Campus / Branch</label>
                <select
                  value={selectedBranchId}
                  onChange={(e) => setSelectedBranchId(e.target.value)}
                  disabled={isSubmitting}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                >
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.city || 'Campus'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Ministry Director</label>
                <select
                  value={selectedDirectorId}
                  onChange={(e) => setSelectedDirectorId(e.target.value)}
                  disabled={isSubmitting}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName} ({m.membershipStatus})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Purpose / Description</label>
                <textarea
                  rows={3}
                  disabled={isSubmitting}
                  value={newMinistryDesc}
                  onChange={(e) => setNewMinistryDesc(e.target.value)}
                  placeholder="State the core objective, liturgical scope, or community impact..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Annual Budget Allocation ({currency})</label>
                <input
                  type="number"
                  min="0"
                  disabled={isSubmitting}
                  value={newBudget}
                  onChange={(e) => setNewBudget(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => {
                    setIsCreateModalOpen(false);
                    setFormError(null);
                  }}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-semibold shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving to Database...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      <span>Establish Ministry</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Sub-Ministry Modal */}
      {isAddSubModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Add Sub-Ministry / Unit</h3>
              <button
                onClick={() => {
                  if (!isSubmittingSub) {
                    setIsAddSubModalOpen(false);
                    setSubFormError(null);
                  }
                }}
                disabled={isSubmittingSub}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {subFormError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{subFormError}</span>
              </div>
            )}

            <form onSubmit={handleAddSubMinistry} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Sub-Unit Name *</label>
                <input
                  type="text"
                  required
                  disabled={isSubmittingSub}
                  value={subName}
                  onChange={(e) => {
                    setSubName(e.target.value);
                    if (subFormError) setSubFormError(null);
                  }}
                  placeholder="e.g. Gospel Choir, Sound Crew, Media Stream"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Sub-Unit Leader Name</label>
                <input
                  type="text"
                  disabled={isSubmittingSub}
                  value={subLeaderName}
                  onChange={(e) => setSubLeaderName(e.target.value)}
                  placeholder="e.g. Brother Thomas"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-60"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  disabled={isSubmittingSub}
                  onClick={() => {
                    setIsAddSubModalOpen(false);
                    setSubFormError(null);
                  }}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingSub}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-semibold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmittingSub ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <span>Save Sub-Unit</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Ministry Confirmation Modal */}
      {deleteConfirmOpen && selectedMinistry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-sm border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950 flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">Delete Ministry</h3>
                <p className="text-xs text-slate-500">Permanent database action</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Are you sure you want to delete <span className="font-bold text-slate-900 dark:text-white">{selectedMinistry.name}</span>?
              All associated sub-units and department assignments will be safely unlinked from the database.
            </p>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeleteConfirmOpen(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteMinistry}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirm Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
