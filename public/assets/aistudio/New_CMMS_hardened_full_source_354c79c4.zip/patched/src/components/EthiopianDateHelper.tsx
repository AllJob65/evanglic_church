import React, { useState } from 'react';
import { Calendar } from 'lucide-react';
import {
  gregorianToEthiopian,
  ethiopianToGregorian,
  ETHIOPIAN_MONTHS,
} from '../utils/ethiopianCalendar';

export const DEFAULT_MALE_AVATAR =
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300';
export const DEFAULT_FEMALE_AVATAR =
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=300';

export interface EthiopianDateHelperProps {
  label: string;
  value?: string;
  onChange: (val: string) => void;
  required?: boolean;
  className?: string;
}

export const EthiopianDateHelper: React.FC<EthiopianDateHelperProps> = ({
  label,
  value,
  onChange,
  required,
  className = '',
}) => {
  const [isOpenConverter, setIsOpenConverter] = useState(false);
  const ethDate = value ? gregorianToEthiopian(value) : null;

  // Converter local state
  const [eYear, setEYear] = useState<number>(ethDate?.year || 2018);
  const [eMonth, setEMonth] = useState<number>(ethDate?.month || 8);
  const [eDay, setEDay] = useState<number>(ethDate?.day || 12);

  const handleApplyEthiopianDate = () => {
    const gregStr = ethiopianToGregorian(eYear, eMonth, eDay);
    onChange(gregStr);
    setIsOpenConverter(false);
  };

  return (
    <div className={`space-y-1.5 ${className}`}>
      <div className="flex items-center justify-between gap-1">
        <label className="block font-semibold text-slate-700 dark:text-slate-300">
          {label} {required && <span className="text-rose-500">*</span>}
        </label>
        <button
          type="button"
          onClick={() => {
            if (ethDate) {
              setEYear(ethDate.year);
              setEMonth(ethDate.month);
              setEDay(ethDate.day);
            }
            setIsOpenConverter(!isOpenConverter);
          }}
          className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-bold cursor-pointer"
        >
          <Calendar className="w-3 h-3" />
          🇪🇹 Ethiopian Calendar
        </button>
      </div>

      <input
        type="date"
        required={required}
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
      />

      {ethDate && (
        <div className="flex items-center gap-2 px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg text-[11px] text-emerald-800 dark:text-emerald-300 font-medium">
          <span className="shrink-0 font-bold">🇪🇹 ET:</span>
          <span className="truncate">{ethDate.formattedAmharic}</span>
        </div>
      )}

      {/* Ethiopian Date Converter Popover / Inline Box */}
      {isOpenConverter && (
        <div className="p-3 bg-slate-100 dark:bg-slate-800/90 rounded-xl border border-blue-200 dark:border-blue-800 space-y-2 text-xs shadow-md">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-1.5">
            <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1">
              🇪🇹 Set Date via Ethiopian Calendar
            </span>
            <button
              type="button"
              onClick={() => setIsOpenConverter(false)}
              className="text-slate-400 hover:text-slate-600 font-bold"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Year (ዓ.ም)</label>
              <input
                type="number"
                min="1900"
                max="2050"
                value={eYear}
                onChange={(e) => setEYear(parseInt(e.target.value) || 2018)}
                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Month (ወር)</label>
              <select
                value={eMonth}
                onChange={(e) => setEMonth(parseInt(e.target.value))}
                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs"
              >
                {ETHIOPIAN_MONTHS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.id}. {m.en} ({m.am})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Day (ቀን)</label>
              <select
                value={eDay}
                onChange={(e) => setEDay(parseInt(e.target.value))}
                className="w-full p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-mono"
              >
                {Array.from({ length: eMonth === 13 ? 6 : 30 }, (_, i) => i + 1).map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[10px] text-slate-500 font-mono">
              = Gregorian: {ethiopianToGregorian(eYear, eMonth, eDay)}
            </span>
            <button
              type="button"
              onClick={handleApplyEthiopianDate}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs cursor-pointer shadow-xs"
            >
              Apply Date
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
