import React, { useEffect, useState, useRef } from 'react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { supabaseAttendanceService } from '../../services/supabaseAttendanceService';
import { useCMMS } from '../../context/CMMSContext';
import {
  UserCheck,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Camera,
  Sparkles,
  RefreshCw,
  ScanLine,
  X,
  Users,
  ShieldCheck,
  Lock,
  Radio,
  Clock,
  MapPin,
  Calendar,
} from 'lucide-react';

interface JoinedMinistryItem {
  id: string;
  name: string;
  category?: string;
  leaderName?: string;
}

export const MemberAttendancePortal: React.FC = () => {
  const {
    userProfile,
    ministries,
    activeAttendanceSessions,
    checkInToSession,
    attendanceRecords,
    currentUser,
  } = useCMMS();

  const [joinedMinistries, setJoinedMinistries] = useState<JoinedMinistryItem[]>([]);
  const [selectedMinistryId, setSelectedMinistryId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Scanner Modal State
  const [showQrModal, setShowQrModal] = useState(false);
  const [scannedQrCode, setScannedQrCode] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // 1. Fetch only the ministries the logged-in member belongs to
  useEffect(() => {
    let isMounted = true;

    const fetchMemberMinistries = async () => {
      const contextMatched: JoinedMinistryItem[] = ministries
        .filter((m) => userProfile?.ministryIds?.includes(m.id))
        .map((m) => ({
          id: m.id,
          name: m.name,
          category: m.category,
          leaderName: m.leaderName,
        }));

      if (isSupabaseConfigured) {
        try {
          const {
            data: { user },
          } = await supabase.auth.getUser();

          const userEmail = user?.email || userProfile?.email;

          if (userEmail) {
            const { data: memberProfile } = await supabase
              .from('members')
              .select('id')
              .eq('email', userEmail)
              .maybeSingle();

            if (memberProfile?.id) {
              const { data: memberships } = await supabase
                .from('ministry_members')
                .select('ministry_id, ministries(id, name, category, leader_name)')
                .eq('member_id', memberProfile.id);

              if (memberships && memberships.length > 0 && isMounted) {
                const formatted: JoinedMinistryItem[] = memberships
                  .filter((m: any) => m.ministries)
                  .map((m: any) => ({
                    id: m.ministries.id,
                    name: m.ministries.name,
                    category: m.ministries.category,
                    leaderName: m.ministries.leader_name,
                  }));

                if (formatted.length > 0) {
                  setJoinedMinistries(formatted);
                  setSelectedMinistryId(formatted[0].id);
                  return;
                }
              }
            }
          }
        } catch (err) {
          console.warn('Error fetching member ministries from Supabase:', err);
        }
      }

      if (isMounted) {
        const defaultList =
          contextMatched.length > 0
            ? contextMatched
            : ministries.map((m) => ({
                id: m.id,
                name: m.name,
                category: m.category,
                leaderName: m.leaderName,
              }));
        setJoinedMinistries(defaultList);
        setSelectedMinistryId(defaultList[0]?.id || '');
      }
    };

    fetchMemberMinistries();

    return () => {
      isMounted = false;
    };
  }, [userProfile, ministries]);

  const activeMinistry =
    joinedMinistries.find((m) => m.id === selectedMinistryId) || joinedMinistries[0];

  // Look for any active session corresponding to the selected ministry
  const activeSessionForMinistry = activeAttendanceSessions.find(
    (s) => s.groupId === selectedMinistryId && s.status === 'active'
  );

  // Check if current user is already checked in today
  const effectiveMemberId = userProfile?.id || currentUser?.memberId || 'mem-101';
  const todayStr = new Date().toISOString().substring(0, 10);
  const alreadyCheckedInToday = attendanceRecords.find(
    (r) =>
      r.memberId === effectiveMemberId &&
      r.date === todayStr &&
      (r.serviceName?.includes(activeMinistry?.name || '') ||
        r.sessionId === activeSessionForMinistry?.sessionId)
  );

  // Camera stream handler for scanning modal
  useEffect(() => {
    if (showQrModal) {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices
          .getUserMedia({ video: { facingMode: 'environment' } })
          .then((stream) => {
            streamRef.current = stream;
            if (videoRef.current) {
              videoRef.current.srcObject = stream;
            }
          })
          .catch((err) => {
            console.warn('Camera access not granted or unavailable in iframe:', err);
            setCameraError('Optical camera preview is active in simulation mode.');
          });
      }
    } else {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
    }

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [showQrModal]);

  // 2. Manual 1-Click Web Check-In (Option B)
  const handleManualCheckIn = async () => {
    if (!selectedMinistryId) return;
    setLoading(true);
    setStatus(null);

    try {
      if (activeSessionForMinistry) {
        // Direct check-in to the leader's active session
        const result = await checkInToSession({
          sessionId: activeSessionForMinistry.sessionId,
          checkInType: 'manual',
          memberId: effectiveMemberId,
          memberName: userProfile
            ? `${userProfile.firstName} ${userProfile.lastName}`
            : currentUser?.name,
        });

        if (result.success) {
          setStatus({
            type: 'success',
            message: result.message || `Checked into "${activeSessionForMinistry.title}" via 1-Click Verification!`,
          });
        } else {
          setStatus({ type: 'error', message: result.message });
        }
      } else {
        // Fallback check-in if leader session not started yet
        const eventName = activeMinistry?.name ? `${activeMinistry.name} Gathering` : 'Ministry Gathering';
        const serviceType = 'Regular Meeting';

        const { data, error } = await supabaseAttendanceService.checkinMemberRpc({
          eventName,
          serviceType,
          checkInMethod: 'Manual Web Click',
        });

        if (error) {
          setStatus({ type: 'error', message: `Check-in error: ${error.message}` });
        } else {
          setStatus({
            type: 'success',
            message: `Attendance logged for ${eventName} via 1-Click Web Check-In!`,
          });
        }
      }
    } catch (err: any) {
      setStatus({ type: 'error', message: err.message || 'Unexpected error during check-in' });
    } finally {
      setLoading(false);
    }
  };

  // 3. Scan & Process Group Leader's QR Code (Option A)
  const handleVerifyLeaderQr = async (qrPayloadText: string) => {
    if (!qrPayloadText.trim()) return;
    setLoading(true);
    setStatus(null);

    try {
      let payload: any;
      try {
        payload = JSON.parse(qrPayloadText);
      } catch {
        throw new Error('Invalid QR payload format. Please scan an official Group Leader QR code.');
      }

      if (!payload.leaderGenerated) {
        throw new Error('Unauthorized QR code. Only leader-generated session QR codes are valid.');
      }

      const targetSessionId = payload.sessionId || activeSessionForMinistry?.sessionId;

      if (targetSessionId) {
        const result = await checkInToSession({
          sessionId: targetSessionId,
          checkInType: 'qr',
          memberId: effectiveMemberId,
          memberName: userProfile
            ? `${userProfile.firstName} ${userProfile.lastName}`
            : currentUser?.name,
          token: payload.token,
        });

        if (result.success) {
          setStatus({
            type: 'success',
            message: `Leader QR Verified! ${result.message}`,
          });
          setShowQrModal(false);
          setScannedQrCode('');
        } else {
          throw new Error(result.message);
        }
      } else {
        const eventName = payload.eventName || `${activeMinistry?.name || 'Ministry'} Gathering`;
        const serviceType = payload.serviceType || 'Group Session';

        await supabaseAttendanceService.checkinMemberRpc({
          eventName,
          serviceType,
          checkInMethod: 'QR Code Scanning',
        });

        setStatus({
          type: 'success',
          message: `Official QR Verified! Attendance logged for ${eventName}.`,
        });
        setShowQrModal(false);
        setScannedQrCode('');
      }
    } catch (err: any) {
      setStatus({ type: 'error', message: err.message || 'Failed to process QR code' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="w-full p-6 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-white"
      id="member-attendance-portal"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-indigo-400" />
              Verified Member Access
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700 flex items-center gap-1">
              <Lock className="w-2.5 h-2.5" />
              Leader-Verified Attendance Only
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            My Ministry Attendance Portal
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Restricted exclusively to your enrolled ministries. Check in via 1-Click web verification or scan your group leader's live session QR code.
          </p>
        </div>

        {/* Member Profile Badge */}
        <div className="flex items-center gap-3 p-2 bg-slate-950/70 border border-slate-800 rounded-xl">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/30 border border-indigo-500/30 flex items-center justify-center font-black text-sm text-indigo-300">
            {userProfile?.firstName?.charAt(0) || currentUser?.name?.charAt(0) || 'M'}
          </div>
          <div>
            <p className="text-xs font-bold text-white leading-tight">
              {userProfile ? `${userProfile.firstName} ${userProfile.lastName}` : currentUser?.name || 'Verified Member'}
            </p>
            <p className="text-[10px] text-slate-400">
              ID: {userProfile?.memberIdNumber || userProfile?.id || 'CMMS-MEM-001'}
            </p>
          </div>
        </div>
      </div>

      {/* Status Feedback Message */}
      {status && (
        <div
          className={`mt-4 p-4 rounded-xl text-xs font-semibold flex items-center justify-between gap-3 border animate-in fade-in ${
            status.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
              : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {status.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{status.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatus(null)}
            className="text-[11px] text-slate-400 hover:text-white px-2 py-0.5 rounded hover:bg-white/10 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Ministry Selection & Active Session Banner */}
      {joinedMinistries.length > 0 ? (
        <div className="mt-5 space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                Select Joined Ministry Group
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                {joinedMinistries.length} enrolled group{joinedMinistries.length > 1 ? 's' : ''}
              </span>
            </label>
            <select
              value={selectedMinistryId}
              onChange={(e) => setSelectedMinistryId(e.target.value)}
              className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-4 py-3 text-sm font-bold text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 cursor-pointer"
            >
              {joinedMinistries.map((ministry) => (
                <option key={ministry.id} value={ministry.id} className="bg-slate-900 text-white font-medium">
                  {ministry.name} {ministry.category ? `(${ministry.category})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Active Session Detector Banner */}
          {activeSessionForMinistry ? (
            <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/60 to-indigo-950/60 border border-purple-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 shrink-0">
                  <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Live Active Session
                    </span>
                    <span className="text-xs font-bold text-white">
                      {activeSessionForMinistry.title}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-purple-400" />
                      Started {new Date(activeSessionForMinistry.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {activeSessionForMinistry.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-purple-400" />
                        {activeSessionForMinistry.location}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {alreadyCheckedInToday ? (
                <div className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Checked In Today
                </div>
              ) : (
                <span className="text-[11px] font-bold text-purple-300 self-start sm:self-auto">
                  Ready for Check-In
                </span>
              )}
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500 shrink-0" />
              <span>No live session is currently broadcasting for this group. You can still use 1-Click Check-In or scan a QR code when your leader launches the session.</span>
            </div>
          )}

          {/* Action Check-In Cards (Option A & Option B) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Option B: 1-Click Web Check-In */}
            <button
              type="button"
              onClick={handleManualCheckIn}
              disabled={loading || !selectedMinistryId || !!alreadyCheckedInToday}
              className={`p-5 text-left rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                alreadyCheckedInToday
                  ? 'bg-slate-950/60 border-slate-800 opacity-80 cursor-not-allowed'
                  : 'bg-gradient-to-br from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 border-indigo-500/30 shadow-xl shadow-indigo-600/20 active:scale-[0.98]'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
                  {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <UserCheck className="w-5 h-5" />}
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-white/15 text-white">
                  Option B
                </span>
              </div>

              <div>
                <h4 className="text-base font-black text-white">
                  {alreadyCheckedInToday ? 'Checked In' : '1-Click Web Check-In'}
                </h4>
                <p className="text-xs text-indigo-100/80 mt-1 font-medium">
                  {alreadyCheckedInToday
                    ? `You are checked into ${activeMinistry?.name} for today.`
                    : `Instantly verify presence in ${activeMinistry?.name || 'selected group'}.`}
                </p>
              </div>
            </button>

            {/* Option A: Scan Group Leader QR Code */}
            <button
              type="button"
              onClick={() => setShowQrModal(true)}
              disabled={loading || !!alreadyCheckedInToday}
              className={`p-5 text-left rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                alreadyCheckedInToday
                  ? 'bg-slate-950/60 border-slate-800 opacity-80 cursor-not-allowed'
                  : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700 hover:border-purple-500/40 shadow-xl active:scale-[0.98]'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <QrCode className="w-5 h-5" />
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-700 text-slate-300">
                  Option A
                </span>
              </div>

              <div>
                <h4 className="text-base font-black text-white flex items-center gap-1.5">
                  Scan Group Leader QR
                </h4>
                <p className="text-xs text-slate-400 mt-1 font-medium">
                  Point camera at the leader's display or projector screen to verify live token.
                </p>
              </div>
            </button>
          </div>
          {/* Personal Attendance History */}
          <div className="pt-4 border-t border-slate-800">
            <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                My Verified Attendance History
              </span>
              <span className="text-[10px] text-slate-400 font-normal">
                {attendanceRecords.filter(r => r.memberId === effectiveMemberId).length} record(s)
              </span>
            </h4>

            {attendanceRecords.filter(r => r.memberId === effectiveMemberId).length > 0 ? (
              <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
                <table className="cmms-data-table w-full text-left text-xs">
                  <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                    <tr>
                      <th className="p-3 whitespace-nowrap">Date</th>
                      <th className="p-3 min-w-[160px]">Ministry / Gathering</th>
                      <th className="p-3 whitespace-nowrap">Verification Method</th>
                      <th className="p-3 text-right whitespace-nowrap">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {attendanceRecords
                      .filter(r => r.memberId === effectiveMemberId)
                      .slice(0, 5)
                      .map((rec) => (
                        <tr key={rec.id} className="hover:bg-slate-900/40 transition-all">
                          <td className="p-3 font-mono text-[11px] text-slate-300 whitespace-nowrap tabular-nums">
                            {rec.date} {rec.time ? `• ${rec.time}` : ''}
                          </td>
                          <td className="p-3 font-semibold text-white">
                            {rec.serviceName || rec.eventName || 'Ministry Gathering'}
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 whitespace-nowrap">
                              {rec.checkInMethod || '1-Click Web Check-In'}
                            </span>
                          </td>
                          <td className="p-3 text-right whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 whitespace-nowrap">
                              ✓ {rec.status || 'Present'}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 text-[11px] text-slate-400 text-center">
                No past check-in records found. Use the buttons above to check in when your session begins.
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="text-center py-8 px-4 bg-slate-800/40 rounded-xl border border-slate-800 mt-4">
          <p className="text-sm text-slate-400">
            You are not currently enrolled in any ministry groups. Contact a church administrator to join a group.
          </p>
        </div>
      )}

      {/* QR SCANNER MODAL */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl relative animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ScanLine className="w-4 h-4 text-emerald-400 animate-pulse shrink-0" />
                <h4 className="font-black text-sm text-white">Scan Leader's Official QR Code</h4>
              </div>
              <button
                type="button"
                aria-label="Close QR scanner"
                onClick={() => {
                  setShowQrModal(false);
                  setScannedQrCode('');
                }}
                className="min-h-[32px] min-w-[32px] text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 cursor-pointer inline-flex items-center justify-center shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Optical Scanner Viewfinder with Video Stream Support */}
            <div className="relative aspect-square w-full rounded-2xl bg-slate-950 border-2 border-dashed border-emerald-500/50 flex flex-col items-center justify-center p-4 overflow-hidden">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="absolute inset-0 w-full h-full object-cover opacity-70"
              />
              <div className="w-full h-0.5 bg-emerald-400 animate-pulse shadow-[0_0_15px_#34d399] absolute top-1/2 -translate-y-1/2 z-10"></div>
              <div className="absolute inset-10 border-2 border-emerald-400/50 rounded-xl pointer-events-none z-10" />
              
              <div className="relative z-10 text-center flex flex-col items-center">
                <Camera className="w-8 h-8 text-emerald-400 mb-2 opacity-90 drop-shadow-md" />
                <p className="text-xs text-white font-bold drop-shadow-md">
                  Point camera at Group Leader's screen
                </p>
                <span className="text-[10px] text-emerald-300 font-mono mt-1 bg-black/60 px-2 py-0.5 rounded-full">
                  Optical scanner active
                </span>
              </div>
            </div>

            {/* Quick One-Click Match Simulation & Paste Payload Fallback */}
            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  const targetSession = activeSessionForMinistry || activeAttendanceSessions[0];
                  const payload = targetSession
                    ? JSON.stringify({
                        leaderGenerated: true,
                        sessionId: targetSession.sessionId,
                        ministryId: targetSession.groupId,
                        token: targetSession.qrPayloadToken,
                        timestamp: new Date().toISOString(),
                      })
                    : JSON.stringify({
                        leaderGenerated: true,
                        sessionId: 'att_987654',
                        ministryId: selectedMinistryId || 'min-001',
                        eventName: activeMinistry?.name ? `${activeMinistry.name} Gathering` : 'Ministry Gathering',
                        timestamp: new Date().toISOString(),
                      });

                  handleVerifyLeaderQr(payload);
                }}
                disabled={loading}
                className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer transition-all"
              >
                <Sparkles className="w-4 h-4" />
                Simulate Match Leader's Live Session QR Code
              </button>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Or paste scanned QR code text/payload..."
                  value={scannedQrCode}
                  onChange={(e) => setScannedQrCode(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => handleVerifyLeaderQr(scannedQrCode)}
                  disabled={loading || !scannedQrCode.trim()}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold rounded-xl cursor-pointer transition-all"
                >
                  Verify
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
