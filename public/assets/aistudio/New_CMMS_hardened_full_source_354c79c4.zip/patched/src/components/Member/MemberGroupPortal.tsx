import React, { useEffect, useState } from 'react';
import { Video, Radio, ExternalLink, MessageSquare, Sparkles, CheckCircle2, ShieldCheck, ShieldAlert } from 'lucide-react';
import { VideoConference, GroupChatSession } from '../../types';
import { supabaseMinistryService } from '../../services/supabaseMinistryService';
import { io } from 'socket.io-client';

interface MemberGroupPortalProps {
  groupId: string;
  groupName?: string;
  memberId?: string;
  onOpenChat?: () => void;
  className?: string;
}

export const MemberGroupPortal: React.FC<MemberGroupPortalProps> = ({
  groupId,
  groupName = 'Assigned Ministry Group',
  memberId = 'member-default',
  onOpenChat,
  className = '',
}) => {
  const [activeCall, setActiveCall] = useState<{ id?: string; roomUrl: string; title: string; leaderId?: string; createdAt?: string | Date } | null>(null);
  const [activeChatSession, setActiveChatSession] = useState<GroupChatSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [membershipError, setMembershipError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    // Fetch active video calls & chat sessions for this group
    const fetchActiveSessions = async () => {
      try {
        // 1. Direct Supabase Query check
        const supaCall = await supabaseMinistryService.getActiveVideoConference(groupId);
        if (isMounted && supaCall) {
          setActiveCall({
            id: supaCall.id,
            roomUrl: supaCall.room_url,
            title: supaCall.title,
            leaderId: supaCall.leader_profile_id,
            createdAt: supaCall.created_at,
          });
        }

        // 2. Server API fallback check
        const [resCall, resChat] = await Promise.all([
          fetch(`/api/video-conferences/active?groupId=${encodeURIComponent(groupId)}`),
          fetch(`/api/group-chats/active?groupId=${encodeURIComponent(groupId)}`),
        ]);

        if (resCall.ok) {
          const data = await resCall.json();
          if (isMounted && data.activeCall && !supaCall) {
            setActiveCall(data.activeCall);
          }
        }

        if (resChat.ok) {
          const chatData = await resChat.json();
          if (isMounted && chatData.activeSession) {
            setActiveChatSession(chatData.activeSession);
          }
        }
      } catch (err) {
        console.warn('Error querying active group conferences:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchActiveSessions();

    // 1. Supabase Realtime postgres_changes subscription
    const unsubConf = supabaseMinistryService.subscribeToVideoConferences(groupId, {
      onStarted: (conf) => {
        if (isMounted) {
          setActiveCall({
            id: conf.id,
            roomUrl: conf.room_url,
            title: conf.title,
            leaderId: conf.leader_profile_id,
            createdAt: conf.created_at,
          });
        }
      },
      onEnded: () => {
        if (isMounted) setActiveCall(null);
      },
    });

    const unsubChat = supabaseMinistryService.subscribeToGroupChats(groupId, {
      onStarted: (session) => {
        if (isMounted) {
          setActiveChatSession({
            id: session.id,
            groupId: session.ministry_id,
            leaderId: session.leader_profile_id,
            isActive: session.is_active,
            startedAt: session.created_at,
          });
        }
      },
      onEnded: () => {
        if (isMounted) setActiveChatSession(null);
      },
    });

    // 2. WebSocket fallback subscriber
    const socket = io({ path: '/socket.io' });
    socket.emit('join_group_channel', { groupId, userId: memberId });

    socket.on('error', (err: any) => {
      if (
        err?.code === 'FORBIDDEN_GROUP' ||
        err?.code === 'FORBIDDEN_MINISTRY' ||
        err?.code === 'FORBIDDEN'
      ) {
        if (isMounted) {
          setMembershipError(
            err.message ||
              'You are not an enrolled member of this fellowship group. Please contact your ministry leader.'
          );
        }
      }
    });

    socket.on('video_conference_started', (conf: VideoConference) => {
      if (isMounted && conf.groupId === groupId && conf.status === 'active') {
        setActiveCall(conf);
      }
    });

    socket.on('video_conference_ended', (data: { id: string; groupId: string }) => {
      if (isMounted && data.groupId === groupId) {
        setActiveCall(null);
      }
    });

    socket.on('chat_session_started', (session: GroupChatSession) => {
      if (isMounted && session.groupId === groupId) {
        setActiveChatSession(session);
      }
    });

    socket.on('chat_session_ended', (data: { sessionId: string; groupId: string }) => {
      if (isMounted && data.groupId === groupId) {
        setActiveChatSession(null);
      }
    });

    return () => {
      isMounted = false;
      socket.disconnect();
      unsubConf.unsubscribe();
      unsubChat.unsubscribe();
    };
  }, [groupId, memberId]);

  return (
    <div className={`p-5 rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-xl ${className}`}>
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Radio className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-base text-white">Group Communications & Live Fellowship</h3>
            <p className="text-xs text-slate-400">{groupName}</p>
          </div>
        </div>

        {activeCall ? (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Live Broadcast Active
          </span>
        ) : (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
            Realtime Sync Online
          </span>
        )}
      </div>

      {/* Access Denied Warning Banner */}
      {membershipError && (
        <div className="mt-4 p-4 bg-rose-950/70 border border-rose-500/80 rounded-xl flex items-start gap-3 shadow-lg">
          <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="text-xs font-bold text-rose-200">Membership Verification Required</p>
            <p className="text-xs text-rose-300 leading-relaxed">{membershipError}</p>
          </div>
        </div>
      )}

      {/* Active Video Call Alert Banner */}
      {activeCall ? (
        <div className="mt-4 p-4 bg-emerald-950/60 border border-emerald-500/80 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg transition-all">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Video className="w-4 h-4 text-emerald-400" />
              <span className="font-extrabold text-sm text-emerald-300">Live Video Call in Progress</span>
            </div>
            <p className="text-sm font-semibold text-white">{activeCall.title}</p>
            <p className="text-xs text-slate-300">
              Your group leader has opened the live video room. Click to join with video & audio.
            </p>
          </div>
          <a
            href={activeCall.roomUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all shrink-0 cursor-pointer"
          >
            <ExternalLink className="w-4 h-4" />
            Join Video Call
          </a>
        </div>
      ) : (
        <div className="mt-4 p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Video className="w-4 h-4 text-slate-500" />
            <p className="text-slate-400 text-xs">No active video conference right now.</p>
          </div>
          <span className="text-[10px] font-mono text-slate-500">Auto-refresh enabled</span>
        </div>
      )}

      {/* Live Chat Session Notification & Quick Action */}
      {activeChatSession && (
        <div className="mt-3 p-3 bg-purple-950/40 border border-purple-500/50 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-purple-400 animate-bounce" />
            <div>
              <span className="text-xs font-bold text-purple-300">Live Chat Session Active</span>
              <p className="text-[11px] text-slate-400">Fellowship members are conversing in the group channel.</p>
            </div>
          </div>
          {onOpenChat && (
            <button
              onClick={onOpenChat}
              className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg cursor-pointer transition-all"
            >
              Open Chat
            </button>
          )}
        </div>
      )}
    </div>
  );
};
