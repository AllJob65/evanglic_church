import React from 'react';
import { MemberAttendancePortal } from './MemberAttendancePortal';

export { MemberAttendancePortal };

interface AttendanceCheckInProps {
  eventName?: string;
  serviceType?: string;
  onCheckInSuccess?: (record: any) => void;
  className?: string;
}

export const AttendanceCheckIn: React.FC<AttendanceCheckInProps> = () => {
  return <MemberAttendancePortal />;
};
