import React, { useEffect, useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { validatePasswordStrength } from '../utils/passwordValidation';
import { SearchModal } from './SearchModal';
import { AccessibilityControlsModal } from './AccessibilityControlsModal';
import { GoogleTranslatorWidget } from './GoogleTranslatorWidget';
import { triggerGoogleTranslate } from '../utils/googleTranslate';
import { RealtimeConnectionIndicator } from './RealtimeConnectionIndicator';
import {
  Search,
  Bell,
  Sun,
  Moon,
  Monitor,
  User,
  LogOut,
  KeyRound,
  Eye,
  Languages,
  Globe,
  Check,
  CheckCircle2,
  AlertCircle,
  X,
  Menu,
  ChevronDown,
  HeartHandshake,
  FileCheck2,
  Clock,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  onOpenRoleModal?: () => void;
  onToggleMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleMobileMenu }) => {
  const {
    themeMode,
    setThemeMode,
    language,
    langCode,
    setLanguage,
    t,
    activeModule,
    updateUserProfilePhoto,
    workflows,
    prayerRequests,
    addAuditLog,
    setActiveModule,
    logout: cmmsLogout,
    setIsAuthenticated,
    isSidebarCollapsed,
  } = useCMMS();

  const { currentUser, userProfile: authProfile, logout: authLogout, changePassword } = useAuth();
  const navigate = useNavigate();

  // Command palette search modal state
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isMac, setIsMac] = useState(false);

  // Dropdown states & Refs for outside-click collapse
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const notificationsRef = useRef<HTMLDivElement>(null);
  const profileDropdownRef = useRef<HTMLDivElement>(null);

  // Live East Africa Time (+03:00 EAT) Clock
  const [eatNow, setEatNow] = useState<Date>(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setEatNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const eatTimeFormatted = useMemo(() => {
    try {
      return new Intl.DateTimeFormat('en-US', {
        timeZone: 'Africa/Addis_Ababa',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }).format(eatNow);
    } catch {
      return eatNow.toLocaleTimeString();
    }
  }, [eatNow]);

  const eatDateFormatted = useMemo(() => {
    try {
      return new Intl.DateTimeFormat('en-US', {
        timeZone: 'Africa/Addis_Ababa',
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }).format(eatNow);
    } catch {
      return eatNow.toLocaleDateString();
    }
  }, [eatNow]);

  // Auto-collapse dropdowns when clicking anywhere outside or on Escape
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node;
      if (
        isNotificationsOpen &&
        notificationsRef.current &&
        !notificationsRef.current.contains(target)
      ) {
        setIsNotificationsOpen(false);
      }
      if (
        isProfileDropdownOpen &&
        profileDropdownRef.current &&
        !profileDropdownRef.current.contains(target)
      ) {
        setIsProfileDropdownOpen(false);
      }
    };

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsNotificationsOpen(false);
        setIsProfileDropdownOpen(false);
      }
    };

    if (isNotificationsOpen || isProfileDropdownOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('touchstart', handleOutsideClick);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isNotificationsOpen, isProfileDropdownOpen]);

  // Notifications read tracking
  const [clearedNotificationIds, setClearedNotificationIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('cmms_cleared_notifs') || '[]');
    } catch {
      return [];
    }
  });

  // Modal dialog states
  const [isMyProfileModalOpen, setIsMyProfileModalOpen] = useState(false);
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [isAccessibilityModalOpen, setIsAccessibilityModalOpen] = useState(false);
  const [isTranslatorOpen, setIsTranslatorOpen] = useState(false);

  // User Profile details
  const [userProfile, setUserProfile] = useState(() => {
    try {
      const stored = localStorage.getItem('cmms_user_profile');
      if (stored) return JSON.parse(stored);
    } catch {
      // Fallback
    }
    return {
      name: authProfile?.name || currentUser?.displayName || 'Authenticated User',
      email: authProfile?.email || currentUser?.email || '',
      phone: authProfile?.phone || '',
      campus: authProfile?.branchName || '',
      photoUrl: authProfile?.photoUrl || '',
    };
  });

  // Profile Edit Temp States
  const [editName, setEditName] = useState(userProfile.name);
  const [editEmail, setEditEmail] = useState(userProfile.email);
  const [editPhone, setEditPhone] = useState(userProfile.phone);
  const [editPhotoUrl, setEditPhotoUrl] = useState(userProfile.photoUrl);
  const [profileSuccessMsg, setProfileSuccessMsg] = useState('');
  const [imgError, setImgError] = useState(false);

  // Change Password Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [isSavingPassword, setIsSavingPassword] = useState(false);

  // Theme selection derived from CMMSContext
  const selectedThemeOption: 'light' | 'dark' | 'system' =
    themeMode === 'advanced-dark' ? 'dark' : themeMode;

  // Detect OS for keyboard shortcuts
  useEffect(() => {
    if (typeof navigator !== 'undefined') {
      setIsMac(/(Mac|iPhone|iPod|iPad)/i.test(navigator.userAgent));
    }
  }, []);

  // Sync auth profile updates
  useEffect(() => {
    if (authProfile) {
      setUserProfile((prev: any) => ({
        ...prev,
        name: authProfile.name || prev.name,
        email: authProfile.email || prev.email,
        campus: authProfile.branchName || prev.campus,
      }));
    }
  }, [authProfile]);

  // Global Keyboard Shortcut: Cmd+K / Ctrl+K opens Command Palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Theme mode switch handler
  const handleThemeChange = (mode: 'light' | 'dark' | 'system') => {
    setThemeMode(mode);
  };

  // Language Change with Google Translate Integration
  const handleLanguageSelect = (langName: string) => {
    setLanguage(langName);
    const l = langName.toLowerCase().trim();
    const isInternal =
      l === 'en' ||
      l === 'english' ||
      l === 'am' ||
      l === 'amharic' ||
      l === 'አማርኛ' ||
      l === 'ti' ||
      l === 'tigrigna' ||
      l === 'ትግርኛ' ||
      l === 'om' ||
      l === 'afaan oromoo' ||
      l === 'oromo';
    if (!isInternal) {
      triggerGoogleTranslate(langName);
    }
  };

  // Profile Save
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...userProfile,
      name: editName,
      email: editEmail,
      phone: editPhone,
      photoUrl: editPhotoUrl,
    };
    setUserProfile(updated);
    localStorage.setItem('cmms_user_profile', JSON.stringify(updated));

    if (updateUserProfilePhoto && editPhotoUrl) {
      updateUserProfilePhoto(editPhotoUrl);
    }

    addAuditLog('Profile Update', 'User Management', `User updated profile information`);
    setProfileSuccessMsg('Profile details successfully updated!');
    setTimeout(() => {
      setProfileSuccessMsg('');
      setIsMyProfileModalOpen(false);
    }, 1200);
  };

  // Authoritative Password Change with Supabase Auth
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!currentPassword) {
      setPasswordError('Please enter your current password');
      return;
    }
    const validation = validatePasswordStrength(newPassword);
    if (!validation.isValid) {
      setPasswordError(validation.errors[0] || 'Password does not meet security requirements.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('Passwords do not match');
      return;
    }

    setIsSavingPassword(true);
    try {
      const res = await changePassword(currentPassword, newPassword);
      setIsSavingPassword(false);
      if (res.success) {
        setPasswordSuccess('Password successfully updated!');
        addAuditLog('Password Changed', 'Security', `User changed account password`);
        setTimeout(() => {
          setIsChangePasswordModalOpen(false);
          setCurrentPassword('');
          setNewPassword('');
          setConfirmPassword('');
          setPasswordSuccess('');
        }, 1200);
      } else {
        setPasswordError(res.message || 'Failed to update password');
      }
    } catch (err: any) {
      setIsSavingPassword(false);
      setPasswordError(err.message || 'An error occurred while changing password');
    }
  };

  // Real-time Pending Notifications
  const pendingWorkflows = workflows || [];
  const pendingPrayers = prayerRequests || [];

  const workflowNotifs = pendingWorkflows
    .filter((w) => w.status === 'Pending' && !clearedNotificationIds.includes(`wf-${w.id}`))
    .map((w) => ({
      id: `wf-${w.id}`,
      title: `Workflow: ${w.requestType || w.requestCode}`,
      description: `${w.requesterName} - ${w.branchName || 'Branch'}`,
      time: w.submittedDate || 'Recent',
      type: 'workflow' as const,
      module: 'workflows' as const,
    }));

  const prayerNotifs = pendingPrayers
    .filter((p) => p.status === 'Pending' && !clearedNotificationIds.includes(`pr-${p.id}`))
    .map((p) => ({
      id: `pr-${p.id}`,
      title: `Prayer Request: ${p.title || 'New Petition'}`,
      description: `${p.memberName || 'Anonymous'} - ${p.category || 'Spiritual'}`,
      time: p.submittedDate || 'Recent',
      type: 'prayer' as const,
      module: 'pastoral' as const,
    }));

  const notifications = [...workflowNotifs, ...prayerNotifs];
  const unreadCount = notifications.length;

  const handleMarkAllRead = () => {
    const allIds = [...clearedNotificationIds, ...notifications.map((n) => n.id)];
    setClearedNotificationIds(allIds);
    localStorage.setItem('cmms_cleared_notifs', JSON.stringify(allIds));
  };

  const handleLogout = async () => {
    try {
      setIsLogoutModalOpen(false);
      setIsProfileDropdownOpen(false);
      addAuditLog('User Logout', 'Authentication', `User signed out from top navbar`);

      localStorage.removeItem('cmms_token');
      localStorage.removeItem('cmms_auth_token');
      localStorage.removeItem('cmms_active_user');
      localStorage.removeItem('cmms_applicant_data');
      localStorage.removeItem('cmms_onboarding_state');
      localStorage.removeItem('cmms_onboarding_workflow');
      localStorage.removeItem('cmms_rejection_reason');

      setIsAuthenticated(false);
      if (authLogout) await authLogout();
      if (cmmsLogout) cmmsLogout();

      navigate('/login', { replace: true });
    } catch (err) {
      console.error('Logout error:', err);
      setIsAuthenticated(false);
      navigate('/login', { replace: true });
    }
  };

  const getInitials = (nameStr: string) => {
    if (!nameStr) return 'CM';
    const parts = nameStr.trim().split(' ');
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  return (
    <>
      {/* 
        UNIFIED TOP NAVBAR (Desktop, Tablet & Mobile):
        - Matches Sidebar's floating rounded surface aesthetic (bg-white dark:bg-slate-900, subtle 1px border, soft shadow)
        - Left: Mobile sidebar drawer toggle + Live Clock (+3:00 East Africa Time)
        - Center/Right: Single Command Search trigger (⌘K) + Realtime status + Theme toggle + Notifications + User Profile
      */}
      <header
        className={`app-navbar-floating hidden md:flex fixed top-0 left-0 right-0 ${
          isSidebarCollapsed
            ? 'md:left-20 md:w-[calc(100%-80px)] sidebar-collapsed'
            : 'md:left-64 md:w-[calc(100%-256px)]'
        } z-40 w-full h-14 md:h-16 px-2.5 pt-2 md:py-2 transition-all duration-300 ease-out select-none`}
      >
        <div className="flex w-full h-full px-2.5 sm:px-3 lg:px-4 items-center justify-between gap-1.5 sm:gap-2.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-[22px] border border-slate-200/80 dark:border-slate-800/90 shadow-[0_8px_30px_rgb(15,23,42,0.04)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.3)] min-w-0">
          {/* ========================================================================= */}
          {/* 1. LEFT: Mobile Sidebar Drawer Toggle + Live Clock (+3:00 East Africa)    */}
          {/* ========================================================================= */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 shrink">
            {/* Mobile Sidebar Drawer Toggle */}
            <button
              type="button"
              onClick={onToggleMobileMenu}
              aria-label="Toggle navigation drawer"
              className="md:hidden w-9 h-9 rounded-xl bg-slate-100/90 dark:bg-slate-800/80 hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors cursor-pointer shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            >
              <Menu className="w-4.5 h-4.5" />
            </button>

            {/* Live Clock (+3:00 East Africa Time) */}
            <div
              className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-2.5 py-1.5 rounded-xl bg-slate-100/80 dark:bg-slate-800/70 border border-slate-200/70 dark:border-slate-700/70 text-slate-800 dark:text-slate-100 min-w-0 overflow-hidden"
              title="Live East Africa Time (UTC+03:00)"
            >
              <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-emerald-500/15 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2]" />
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 leading-none">
                <span className="font-mono font-bold text-[11px] sm:text-xs md:text-[13px] tracking-tight tabular-nums text-slate-900 dark:text-white whitespace-nowrap">
                  {eatTimeFormatted}
                </span>
                <span className="hidden lg:inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100/80 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60 whitespace-nowrap">
                  UTC+3:00 East Africa
                </span>
                <span className="hidden xl:inline text-[11px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap border-l border-slate-200 dark:border-slate-700 pl-2">
                  {eatDateFormatted}
                </span>
              </div>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* 2. CENTER: Single Global Search Input with ⌘ K Keycaps                    */}
          {/* ========================================================================= */}
          <div className="flex-1 max-w-xs lg:max-w-md mx-auto hidden md:block min-w-0">
            <button
              type="button"
              onClick={() => setIsSearchModalOpen(true)}
              className="w-full h-9 px-3 rounded-xl bg-slate-100/80 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-slate-400 dark:text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-all text-xs font-medium cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              aria-label="Search members, ministries, events, and commands"
            >
              <div className="flex items-center gap-2 min-w-0">
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="truncate">{t('navbar.search_placeholder', 'Search members, ministries, events...')}</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <kbd className="min-w-[18px] h-[18px] px-1 inline-flex items-center justify-center text-[10px] font-sans font-semibold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 rounded-md shadow-2xs border border-slate-200/70 dark:border-slate-700">
                  {isMac ? '⌘' : 'Ctrl'}
                </kbd>
                <kbd className="min-w-[18px] h-[18px] px-1 inline-flex items-center justify-center text-[10px] font-sans font-semibold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 rounded-md shadow-2xs border border-slate-200/70 dark:border-slate-700">
                  K
                </kbd>
              </div>
            </button>
          </div>

          {/* ========================================================================= */}
          {/* 3. RIGHT: Mobile Search Icon, Connection Status, Theme, Bell & Profile    */}
          {/* ========================================================================= */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Compact Search Trigger on Mobile & Small Tablet Screens */}
            <button
              type="button"
              onClick={() => setIsSearchModalOpen(true)}
              aria-label="Search"
              className="md:hidden w-9 h-9 rounded-xl bg-slate-100/90 dark:bg-slate-800/80 hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors cursor-pointer shrink-0"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* REALTIME DATABASE CONNECTION HEALTH INDICATOR */}
            <div className="hidden xl:block">
              <RealtimeConnectionIndicator variant="pill" />
            </div>

            {/* QUICK THEME TOGGLE BUTTON */}
            <button
              type="button"
              onClick={() =>
                handleThemeChange(selectedThemeOption === 'dark' ? 'light' : 'dark')
              }
              aria-label="Toggle color theme"
              title={selectedThemeOption === 'dark' ? 'Switch to Light mode' : 'Switch to Dark mode'}
              className="w-9 h-9 rounded-xl bg-slate-100/80 dark:bg-slate-800/70 hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            >
              {selectedThemeOption === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>

            {/* NOTIFICATION CENTER */}
            <div className="relative" ref={notificationsRef}>
              <button
                type="button"
                id="notifications-button"
                aria-haspopup="true"
                aria-expanded={isNotificationsOpen}
                aria-label={`Notifications (${unreadCount} unread)`}
                onClick={() => {
                  setIsNotificationsOpen(!isNotificationsOpen);
                  setIsProfileDropdownOpen(false);
                }}
                className={`relative w-9 h-9 flex items-center justify-center rounded-xl transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isNotificationsOpen
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                    : 'bg-slate-100/80 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'
                }`}
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] px-1 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notification Popover Dropdown */}
              {isNotificationsOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setIsNotificationsOpen(false)}
                  />
                  <div
                    role="region"
                    aria-labelledby="notifications-heading"
                    className="fixed sm:absolute left-3 right-3 sm:left-auto sm:right-0 top-16 sm:top-auto sm:mt-2 w-auto sm:w-96 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150 max-h-[80vh] flex flex-col"
                  >
                    {/* Header */}
                    <div className="p-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-800/40">
                      <div className="flex items-center gap-2">
                        <span id="notifications-heading" className="font-bold text-xs text-slate-900 dark:text-white">
                          {t('navbar.notifications_title', 'Notifications & Alerts')}
                        </span>
                        {unreadCount > 0 && (
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300">
                            {unreadCount} {t('common.new', 'New')}
                          </span>
                        )}
                      </div>
                      {unreadCount > 0 && (
                        <button
                          onClick={handleMarkAllRead}
                          className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                        >
                          {t('navbar.mark_all_read', 'Mark all as read')}
                        </button>
                      )}
                    </div>

                    {/* Notification List */}
                    <div className="max-h-[340px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center space-y-2">
                          <CheckCircle2 className="w-7 h-7 text-emerald-500 mx-auto opacity-70" />
                          <p className="font-semibold text-slate-700 dark:text-slate-300">{t('navbar.all_caught_up', 'All caught up!')}</p>
                          <p className="text-xs text-slate-400">{t('navbar.no_pending', 'No pending approvals or unread alerts')}</p>
                        </div>
                      ) : (
                        notifications.map((item) => (
                          <div
                            key={item.id}
                            onClick={() => {
                              setIsNotificationsOpen(false);
                              if (item.type === 'workflow') {
                                setActiveModule('approvals');
                                navigate('/approvals');
                              } else {
                                setActiveModule('prayer_counseling');
                                navigate('/prayer-counseling');
                              }
                            }}
                            className="p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors flex items-start gap-3 cursor-pointer group"
                          >
                            <div className={`p-2 rounded-xl mt-0.5 shrink-0 ${
                              item.type === 'workflow'
                                ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400'
                                : 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                            }`}>
                              {item.type === 'workflow' ? <FileCheck2 className="w-4 h-4" /> : <HeartHandshake className="w-4 h-4" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-slate-900 dark:text-white truncate group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                                {item.title}
                              </p>
                              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                                {item.description}
                              </p>
                              <div className="flex items-center gap-1.5 mt-1 text-[11px] text-slate-400">
                                <Clock className="w-3 h-3" />
                                <span>{item.time}</span>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* USER PROFILE AVATAR & DROPDOWN */}
            <div className="relative" ref={profileDropdownRef}>
              <button
                type="button"
                id="user-profile-button"
                aria-haspopup="true"
                aria-expanded={isProfileDropdownOpen}
                aria-label="Open User Account Menu"
                onClick={() => {
                  setIsProfileDropdownOpen(!isProfileDropdownOpen);
                  setIsNotificationsOpen(false);
                }}
                className={`flex items-center gap-2 p-1 pr-2 rounded-xl transition-all cursor-pointer h-9 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isProfileDropdownOpen
                    ? 'bg-slate-100 dark:bg-slate-800'
                    : 'bg-slate-100/70 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {editPhotoUrl && !imgError ? (
                  <img
                    src={editPhotoUrl}
                    alt={userProfile.name}
                    onError={() => setImgError(true)}
                    className="w-7 h-7 rounded-lg object-cover shrink-0"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-[11px] flex items-center justify-center shrink-0">
                    {getInitials(userProfile.name)}
                  </div>
                )}
                <span className="hidden lg:block font-semibold text-xs text-slate-800 dark:text-slate-200 truncate max-w-[110px]">
                  {userProfile.name}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              </button>

              {/* USER PROFILE DROPDOWN MENU */}
              {isProfileDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setIsProfileDropdownOpen(false)}
                  />
                  <div
                    role="menu"
                    aria-orientation="vertical"
                    className="fixed sm:absolute left-3 right-3 sm:left-auto sm:right-0 top-16 sm:top-auto sm:mt-2 w-auto sm:w-80 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-xl z-50 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 animate-in fade-in slide-in-from-top-2 duration-150 max-h-[85vh] overflow-y-auto"
                  >
                    {/* User Header */}
                    <div className="p-4 bg-slate-50/70 dark:bg-slate-800/40">
                      <div className="flex items-center gap-3">
                        {editPhotoUrl && !imgError ? (
                          <img
                            src={editPhotoUrl}
                            alt={userProfile.name}
                            className="w-10 h-10 rounded-xl object-cover shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs flex items-center justify-center shrink-0">
                            {getInitials(userProfile.name)}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                            {userProfile.name}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {userProfile.email}
                          </p>
                          {userProfile.campus && (
                            <span className="inline-flex items-center gap-1 mt-1 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                              {userProfile.campus}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Account Links */}
                    <div className="p-2 space-y-0.5 text-xs font-medium">
                      <button
                        role="menuitem"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          setActiveModule('my_profile');
                          navigate('/my-profile');
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 min-h-[40px] rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                      >
                        <User className="w-4 h-4 text-slate-400" />
                        <span>{t('navbar.my_profile', 'My Member Profile')}</span>
                      </button>

                      <button
                        role="menuitem"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          setIsMyProfileModalOpen(true);
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 min-h-[40px] rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                      >
                        <Sparkles className="w-4 h-4 text-slate-400" />
                        <span>{t('navbar.quick_settings', 'Quick Account Settings')}</span>
                      </button>

                      <button
                        role="menuitem"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          setIsChangePasswordModalOpen(true);
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 min-h-[40px] rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                      >
                        <KeyRound className="w-4 h-4 text-slate-400" />
                        <span>{t('navbar.change_password', 'Change Password')}</span>
                      </button>

                      <button
                        role="menuitem"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          setIsAccessibilityModalOpen(true);
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 min-h-[40px] rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-left"
                      >
                        <Eye className="w-4 h-4 text-slate-400" />
                        <span>{t('navbar.accessibility', 'Accessibility & Screen Reader')}</span>
                      </button>
                    </div>

                    {/* Multi-Language Selector Section */}
                    <div className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                          <Languages className="w-3.5 h-3.5 text-slate-400" />
                          <span>{t('navbar.language', 'Language')}</span>
                        </span>
                        <button
                          onClick={() => {
                            setIsProfileDropdownOpen(false);
                            setIsTranslatorOpen(true);
                          }}
                          className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                        >
                          <Globe className="w-3 h-3" />
                          <span>100+ More</span>
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-1.5 text-xs">
                        {[
                          { code: 'en', name: 'English', native: 'English', flag: '🇬🇧' },
                          { code: 'am', name: 'Amharic', native: 'አማርኛ', flag: '🇪🇹' },
                          { code: 'ti', name: 'Tigrigna', native: 'ትግርኛ', flag: '🇪🇹' },
                          { code: 'om', name: 'Afaan Oromoo', native: 'Oromoo', flag: '🇪🇹' },
                        ].map((langItem) => {
                          const isCurrent = language === langItem.name || langCode === langItem.code;
                          return (
                            <button
                              key={langItem.name}
                              onClick={() => handleLanguageSelect(langItem.code)}
                              className={`px-2.5 py-2 min-h-[38px] rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                                isCurrent
                                  ? 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white font-semibold'
                                  : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/80 text-slate-600 dark:text-slate-300'
                              }`}
                            >
                              <span className="text-xs">{langItem.flag} {langItem.native}</span>
                              {isCurrent && <Check className="w-3 h-3 text-slate-900 dark:text-white" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* 3-Way Theme Switcher (Light / Dark / System) */}
                    <div className="p-3 bg-slate-50/50 dark:bg-slate-800/30">
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-2">
                        {t('navbar.appearance', 'Appearance Theme')}
                      </span>
                      <div
                        role="radiogroup"
                        aria-label="Theme mode selection"
                        className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl"
                      >
                        {[
                          { id: 'light' as const, label: 'Light', icon: Sun },
                          { id: 'dark' as const, label: 'Dark', icon: Moon },
                          { id: 'system' as const, label: 'System', icon: Monitor },
                        ].map((opt) => {
                          const isSelected = selectedThemeOption === opt.id;
                          const IconComp = opt.icon;
                          return (
                            <button
                              key={opt.id}
                              type="button"
                              role="radio"
                              aria-checked={isSelected}
                              onClick={() => handleThemeChange(opt.id)}
                              className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                                isSelected
                                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                              }`}
                            >
                              <IconComp className="w-3.5 h-3.5" />
                              <span>{opt.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Logout Action */}
                    <div className="p-2">
                      <button
                        role="menuitem"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          setIsLogoutModalOpen(true);
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer text-left text-xs font-semibold"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>{t('navbar.sign_out', 'Sign Out of Account')}</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* COMMAND PALETTE SEARCH MODAL */}
      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
      />

      {/* ACCOUNT PROFILE MODAL */}
      {isMyProfileModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="profile-modal-title"
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-white/10 text-white border border-white/15">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h3 id="profile-modal-title" className="text-base font-bold tracking-tight">
                    Account & Profile Details
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">Manage your personal details and avatar</p>
                </div>
              </div>
              <button
                onClick={() => setIsMyProfileModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="p-6 space-y-4 text-xs">
              {profileSuccessMsg && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 rounded-2xl flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{profileSuccessMsg}</span>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Avatar Photo URL</label>
                <input
                  type="url"
                  value={editPhotoUrl}
                  onChange={(e) => setEditPhotoUrl(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="https://..."
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsMyProfileModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold shadow-sm"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CHANGE PASSWORD MODAL */}
      {isChangePasswordModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="password-modal-title"
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-white/10 text-white border border-white/20">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 id="password-modal-title" className="text-base font-bold tracking-tight">
                    Change Password
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">Update credentials to secure your account</p>
                </div>
              </div>
              <button
                onClick={() => setIsChangePasswordModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="p-6 space-y-4 text-xs">
              {passwordError && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 rounded-2xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{passwordError}</span>
                </div>
              )}

              {passwordSuccess && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 rounded-2xl flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{passwordSuccess}</span>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Current Password</label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="Min. 6 characters"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsChangePasswordModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingPassword}
                  className="px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold shadow-sm"
                >
                  {isSavingPassword ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LOGOUT CONFIRMATION MODAL */}
      {isLogoutModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="logout-dialog-title"
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-center space-y-4">
            <div className="w-12 h-12 bg-rose-100 dark:bg-rose-950/60 rounded-2xl flex items-center justify-center mx-auto text-rose-600 dark:text-rose-400">
              <LogOut className="w-6 h-6" />
            </div>

            <div>
              <h3 id="logout-dialog-title" className="text-base font-black text-slate-900 dark:text-white">
                Sign Out Confirmation
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Are you sure you want to end your current session?
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsLogoutModalOpen(false)}
                className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleLogout}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-xs shadow-md shadow-rose-600/30"
              >
                Yes, Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ACCESSIBILITY MODAL */}
      <AccessibilityControlsModal
        isOpen={isAccessibilityModalOpen}
        onClose={() => setIsAccessibilityModalOpen(false)}
      />

      {/* GOOGLE TRANSLATOR 100+ LANGUAGES MODAL */}
      <GoogleTranslatorWidget
        isOpen={isTranslatorOpen}
        onClose={() => setIsTranslatorOpen(false)}
      />
    </>
  );
};

export default Navbar;

