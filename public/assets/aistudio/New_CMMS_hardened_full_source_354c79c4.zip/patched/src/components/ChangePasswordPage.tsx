import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCMMS } from '../context/CMMSContext';
import { validatePasswordStrength } from '../utils/passwordValidation';
import {
  Church,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  ShieldCheck,
  ArrowRight,
  LogOut,
  UserCheck,
  Check,
  X,
} from 'lucide-react';

export const ChangePasswordPage: React.FC = () => {
  const { userProfile, changePassword, logout, getDefaultRouteForRole, loading } = useAuth();
  const { systemName, churchName } = useCMMS();
  const navigate = useNavigate();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Auto-redirect if already verified or unauthenticated
  useEffect(() => {
    if (loading) return;

    if (!userProfile) {
      navigate('/login', { replace: true });
      return;
    }

    const mustChange = Boolean(userProfile.must_change_password || (userProfile as any).mustChangePassword);
    if (!mustChange && !successMessage) {
      const targetRoute = getDefaultRouteForRole(userProfile.role) || '/dashboard';
      const targetPath = targetRoute.startsWith('/') ? targetRoute : `/${targetRoute}`;
      navigate(targetPath, { replace: true });
    }
  }, [userProfile, loading, navigate, getDefaultRouteForRole, successMessage]);

  // Password validation analysis
  const validation = useMemo(() => {
    return validatePasswordStrength(newPassword);
  }, [newPassword]);

  const passwordsMatch = useMemo(() => {
    if (!newPassword || !confirmPassword) return false;
    return newPassword === confirmPassword;
  }, [newPassword, confirmPassword]);

  const isDifferentFromCurrent = useMemo(() => {
    if (!newPassword) return true;
    if (newPassword.trim() === 'Pass@12345') return false;
    if (currentPassword && newPassword === currentPassword) return false;
    return true;
  }, [newPassword, currentPassword]);

  const canSubmit = useMemo(() => {
    return (
      currentPassword.trim().length > 0 &&
      validation.isValid &&
      passwordsMatch &&
      isDifferentFromCurrent &&
      !isLoading
    );
  }, [currentPassword, validation.isValid, passwordsMatch, isDifferentFromCurrent, isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!currentPassword.trim()) {
      setErrorMessage('Please enter your temporary/current password.');
      return;
    }

    if (!isDifferentFromCurrent) {
      setErrorMessage('New password cannot be the same as your temporary password.');
      return;
    }

    if (!passwordsMatch) {
      setErrorMessage('New password and confirmation do not match.');
      return;
    }

    if (!validation.isValid) {
      setErrorMessage(validation.errors[0] || 'Password does not meet the security criteria.');
      return;
    }

    setIsLoading(true);

    try {
      const result = await changePassword(currentPassword, newPassword, confirmPassword);
      setIsLoading(false);

      if (!result.success) {
        setErrorMessage(result.message || 'Failed to update password. Please check your credentials.');
        return;
      }

      setSuccessMessage('Password successfully updated! Redirecting to your dashboard...');
      
      const targetRoute = getDefaultRouteForRole(userProfile?.role) || '/dashboard';
      const targetPath = targetRoute.startsWith('/') ? targetRoute : `/${targetRoute}`;

      setTimeout(() => {
        navigate(targetPath, { replace: true });
      }, 1200);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err.message || 'An unexpected error occurred while saving your password.');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  // Password Strength Bar Configuration
  const strengthColor = useMemo(() => {
    switch (validation.score) {
      case 4:
        return 'bg-emerald-500';
      case 3:
        return 'bg-blue-500';
      case 2:
        return 'bg-amber-500';
      default:
        return 'bg-rose-500';
    }
  }, [validation.score]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-10 font-sans selection:bg-blue-600 selection:text-white">
      {/* 1. Header Bar with Church Brand */}
      <header className="max-w-4xl w-full mx-auto flex items-center justify-between pb-6 border-b border-slate-850">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 p-0.5 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Church className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-extrabold text-sm sm:text-base text-white tracking-tight">
              {churchName || systemName || 'CMMS'}
            </h1>
            <p className="text-[11px] text-blue-400 font-medium">
              CMMS Account Security Onboarding
            </p>
          </div>
        </div>

        {/* Safe Logout Escape Hatch */}
        <button
          type="button"
          onClick={handleLogout}
          className="text-xs text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-850 cursor-pointer"
          title="Sign out of temporary session"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Sign Out</span>
        </button>
      </header>

      {/* 2. Main Password Change Container */}
      <main className="max-w-xl w-full mx-auto my-auto py-8">
        <div className="bg-slate-900/90 rounded-3xl border border-slate-800 shadow-2xl p-6 sm:p-8 backdrop-blur-xl space-y-6">
          {/* Card Header & Requirement Explanation */}
          <div className="space-y-2 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Mandatory First-Login Setup</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Create Your Permanent Password
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
              Your account is using a temporary password. You must create a new password before continuing to access the Church Management System.
            </p>
          </div>

          {/* User Identity Pill */}
          {userProfile && (
            <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 truncate">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold shrink-0">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <p className="font-bold text-white truncate">{userProfile.name || userProfile.email}</p>
                  <p className="text-[11px] text-slate-400 truncate">{userProfile.email}</p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-lg bg-blue-500/10 text-blue-400 text-[10px] font-mono font-bold uppercase shrink-0">
                {userProfile.role}
              </span>
            </div>
          )}

          {/* Error Banner */}
          {errorMessage && (
            <div
              role="alert"
              className="p-3.5 rounded-2xl bg-rose-950/50 border border-rose-800/80 text-rose-200 text-xs flex items-start gap-2.5 animate-in fade-in-50"
            >
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMessage}</div>
            </div>
          )}

          {/* Success Banner */}
          {successMessage && (
            <div
              role="status"
              className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-800/80 text-emerald-200 text-xs flex items-start gap-2.5 animate-in fade-in-50"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1 font-bold">{successMessage}</div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Field 1: Current / Temporary Password */}
            <div className="space-y-1.5">
              <label
                htmlFor="currentPassword"
                className="block text-xs font-bold text-slate-300"
              >
                Temporary / Current Password *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="currentPassword"
                  name="currentPassword"
                  type={showCurrentPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  placeholder="Enter the temporary password provided by your admin"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  disabled={isLoading || Boolean(successMessage)}
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword((prev) => !prev)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                  aria-label={showCurrentPassword ? 'Hide current password' : 'Show current password'}
                >
                  {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Field 2: New Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="newPassword"
                  className="block text-xs font-bold text-slate-300"
                >
                  New Permanent Password *
                </label>
                {newPassword && (
                  <span className="text-[11px] font-semibold text-slate-400">
                    Strength: <span className="font-bold text-white">{validation.feedback}</span>
                  </span>
                )}
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <KeyRound className="w-4 h-4" />
                </div>
                <input
                  id="newPassword"
                  name="newPassword"
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  autoComplete="new-password"
                  placeholder="Create a strong, unique password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  disabled={isLoading || Boolean(successMessage)}
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword((prev) => !prev)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                  aria-label={showNewPassword ? 'Hide new password' : 'Show new password'}
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Password Strength Meter */}
              {newPassword && (
                <div className="pt-1 space-y-1">
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${strengthColor}`}
                      style={{ width: `${Math.max(15, (validation.score / 4) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Field 3: Confirm New Password */}
            <div className="space-y-1.5">
              <label
                htmlFor="confirmPassword"
                className="block text-xs font-bold text-slate-300"
              >
                Confirm New Password *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  autoComplete="new-password"
                  placeholder="Re-enter your new permanent password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={isLoading || Boolean(successMessage)}
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                  aria-label={showConfirmPassword ? 'Hide confirmation password' : 'Show confirmation password'}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Password Security Criteria Checklist */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                Security Requirements
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
                <div className="flex items-center gap-1.5">
                  {validation.requirements.minLength ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                  <span className={validation.requirements.minLength ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                    At least 8 characters
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {validation.requirements.hasUppercase ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                  <span className={validation.requirements.hasUppercase ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                    One uppercase letter (A-Z)
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {validation.requirements.hasLowercase ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                  <span className={validation.requirements.hasLowercase ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                    One lowercase letter (a-z)
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {validation.requirements.hasNumber ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                  <span className={validation.requirements.hasNumber ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                    One number (0-9)
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {validation.requirements.hasSymbol ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                  <span className={validation.requirements.hasSymbol ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                    One special symbol (!@#$%^&*)
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {isDifferentFromCurrent ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                  )}
                  <span className={isDifferentFromCurrent ? 'text-slate-200 font-medium' : 'text-rose-400 font-medium'}>
                    Different from temporary password
                  </span>
                </div>

                <div className="flex items-center gap-1.5 sm:col-span-2">
                  {passwordsMatch ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <X className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                  <span className={passwordsMatch ? 'text-slate-200 font-medium' : 'text-slate-500'}>
                    Password confirmation matches
                  </span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={!canSubmit || Boolean(successMessage)}
                className={`w-full py-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg ${
                  canSubmit && !successMessage
                    ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                }`}
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                    <span>Saving Secure Credentials...</span>
                  </>
                ) : successMessage ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Password Updated</span>
                  </>
                ) : (
                  <>
                    <span>Confirm &amp; Activate Account</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>

      {/* 3. Footer */}
      <footer className="max-w-4xl w-full mx-auto text-center pt-6 text-xs text-slate-500 border-t border-slate-850">
        <p>© {new Date().getFullYear()} {churchName || systemName || 'CMMS'}. Enterprise CMMS.</p>
      </footer>
    </div>
  );
};

export default ChangePasswordPage;
