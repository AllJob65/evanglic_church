import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { WorkflowRequest } from '../types';
import {
  GitPullRequest,
  CheckCircle2,
  XCircle,
  Clock,
  Shield,
  FileCheck,
  AlertCircle,
} from 'lucide-react';

export const WorkflowModule: React.FC = () => {
  const { workflows, updateWorkflowStatus, permissions, activeRole } = useCMMS();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <GitPullRequest className="w-6 h-6 text-purple-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Workflow Engine & Approval Queue</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200">
              {workflows.filter((w) => w.status === 'Pending').length} Pending Sign-offs
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Multi-step governance sign-offs for budget approvals, baptism candidates, member transfers, and asset requisitions.
          </p>
        </div>

        <div className="p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl text-xs font-semibold text-purple-800 dark:text-purple-300">
          Current Role Approval Power: <strong>{activeRole}</strong>
        </div>
      </div>

      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
        <h3 className="font-bold text-base text-slate-900 dark:text-white">Active Workflow Queue</h3>

        <div className="space-y-3">
          {workflows.map((wf) => (
            <div
              key={wf.id}
              className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-purple-600 dark:text-purple-400">
                  {wf.requestCode}
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                    wf.status === 'Approved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : wf.status === 'Rejected'
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {wf.status}
                </span>
              </div>

              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">{wf.requestType}</h4>
                <p className="text-slate-500 mt-0.5">{wf.details}</p>
                <p className="text-slate-400 text-[11px] mt-1">
                  Requested by: <strong>{wf.requesterName}</strong> • Branch: {wf.branchName}
                </p>
              </div>

              {/* If Membership Application, render candidate info card */}
              {wf.requestType === 'Membership Application' && wf.pendingMemberData && (
                <div className="p-3.5 bg-purple-50/70 dark:bg-purple-950/30 rounded-xl border border-purple-200 dark:border-purple-900 flex items-start gap-3">
                  <img
                    src={
                      wf.pendingMemberData.photoUrl ||
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'
                    }
                    alt={wf.requesterName}
                    className="w-12 h-12 rounded-xl object-cover border border-purple-300 dark:border-purple-700 shrink-0"
                  />
                  <div className="flex-1 min-w-0 space-y-1 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-purple-900 dark:text-purple-200">
                        {wf.pendingMemberData.title} {wf.pendingMemberData.firstName} {wf.pendingMemberData.lastName}
                      </span>
                      <span className="font-mono text-[10px] text-purple-600 dark:text-purple-400 font-bold">
                        {wf.pendingMemberData.memberIdNumber}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400">
                      Phone: {wf.pendingMemberData.primaryPhone} • Email: {wf.pendingMemberData.email} • Residence: {wf.pendingMemberData.city}, {wf.pendingMemberData.subCity || 'City'}
                    </p>
                    <p className="text-[10px] text-purple-700 dark:text-purple-300 font-semibold">
                      Spiritual: {wf.pendingMemberData.waterBaptized ? 'Water Baptized' : 'Pending Baptism'} • Profession: {wf.pendingMemberData.occupation || 'N/A'}
                    </p>
                  </div>
                </div>
              )}

              {wf.amountRequested && (
                <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-900 dark:text-white">
                  Requested Expenditure Amount: ${wf.amountRequested.toLocaleString()}
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <span className="text-slate-400">Current Approval Step: {wf.currentStep} (Assigned to {wf.assignedApproverRole})</span>

                {wf.status === 'Pending' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateWorkflowStatus(wf.id, 'Approved')}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Approve Request
                    </button>
                    <button
                      onClick={() => updateWorkflowStatus(wf.id, 'Rejected')}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold flex items-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Reject
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
