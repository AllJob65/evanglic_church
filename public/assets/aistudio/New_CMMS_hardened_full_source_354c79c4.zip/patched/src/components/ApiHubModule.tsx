import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCMMS } from '../context/CMMSContext';
import { apiHubService } from '../services/apiHubService';
import {
  ApiKeyRecord,
  WebhookSubscription,
  SupabaseConnectionStatus,
  SmsGatewayConfig,
} from '../types';
import {
  Key,
  Database,
  Smartphone,
  Webhook,
  Code2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  Send,
  Plus,
  Trash2,
  ShieldCheck,
  Zap,
  Terminal,
  ExternalLink,
  Lock,
  Globe,
  Radio,
  Server,
  Sparkles,
  Layers,
  FileCode,
  Search,
} from 'lucide-react';

export const ApiHubModule: React.FC = () => {
  const { addAuditLog, branches } = useCMMS();

  // Active Tab: 'supabase' | 'sms_gateway' | 'external_api' | 'webhooks' | 'sdk_code'
  const [activeTab, setActiveTab] = useState<'supabase' | 'sms_gateway' | 'external_api' | 'webhooks' | 'sdk_code'>('supabase');

  // 1. Supabase State
  const [supabaseStatus, setSupabaseStatus] = useState<SupabaseConnectionStatus | null>(null);
  const [checkingSupabase, setCheckingSupabase] = useState(false);
  const [copiedSchema, setCopiedSchema] = useState(false);

  // 2. SMS Gateway State
  const [smsConfig, setSmsConfig] = useState<SmsGatewayConfig>({
    provider: 'EthioTelecom',
    senderId: 'GRACECATH',
    enabled: true,
    balanceCredits: 4250,
    monthlyQuota: 10000,
    usedCredits: 5750,
  });
  const [testSmsRecipient, setTestSmsRecipient] = useState('+251911223344');
  const [testSmsMessage, setTestSmsMessage] = useState('Grace Cathedral: Blessed Sunday! "The Lord bless you and keep you" (Num 6:24).');
  const [smsSending, setSmsSending] = useState(false);
  const [smsResult, setSmsResult] = useState<any>(null);

  // 3. API Keys State
  const [apiKeys, setApiKeys] = useState<ApiKeyRecord[]>([]);
  const [isCreateKeyModalOpen, setIsCreateKeyModalOpen] = useState(false);
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyDescription, setNewKeyDescription] = useState('');
  const [newKeyRateLimit, setNewKeyRateLimit] = useState(120);
  const [newKeyScopes, setNewKeyScopes] = useState<string[]>(['read:members', 'read:events']);
  const [createdKeySecret, setCreatedKeySecret] = useState<string | null>(null);
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);

  // 4. Webhooks State
  const [webhooks, setWebhooks] = useState<WebhookSubscription[]>([]);
  const [isCreateWebhookModalOpen, setIsCreateWebhookModalOpen] = useState(false);
  const [newWebhookName, setNewWebhookName] = useState('');
  const [newWebhookUrl, setNewWebhookUrl] = useState('');
  const [newWebhookEvents, setNewWebhookEvents] = useState<string[]>(['member.created', 'attendance.recorded']);
  const [testingWebhookId, setTestingWebhookId] = useState<string | null>(null);
  const [webhookTestResult, setWebhookTestResult] = useState<any>(null);

  // 5. Interactive API Console Tester
  const [selectedEndpoint, setSelectedEndpoint] = useState('/api/v1/external/members');
  const [selectedMethod, setSelectedMethod] = useState<'GET' | 'POST'>('GET');
  const [testApiKey, setTestApiKey] = useState('');
  const [testRequestBody, setTestRequestBody] = useState(
    JSON.stringify(
      {
        firstName: '',
        lastName: '',
        primaryPhone: '',
        email: '',
        branchId: '',
        discipleshipStatus: 'New Believer',
      },
      null,
      2
    )
  );
  const [apiConsoleResponse, setApiConsoleResponse] = useState<any>(null);
  const [executingApiTest, setExecutingApiTest] = useState(false);

  // Load initial data
  useEffect(() => {
    handleCheckSupabase();
    loadApiKeys();
    loadWebhooks();
    loadSmsConfig();
  }, []);

  const handleCheckSupabase = async () => {
    setCheckingSupabase(true);
    try {
      const status = await apiHubService.checkSupabaseConnection();
      setSupabaseStatus(status);
    } catch (e: any) {
      console.warn('Supabase test failed:', e);
    } finally {
      setCheckingSupabase(false);
    }
  };

  const loadApiKeys = async () => {
    try {
      const data = await apiHubService.getApiKeys();
      setApiKeys(data);
      if (data.length > 0 && data[0].apiKey) {
        setTestApiKey(data[0].apiKey);
      }
    } catch (e) {
      console.warn('Load API keys failed:', e);
    }
  };

  const loadWebhooks = async () => {
    try {
      const data = await apiHubService.getWebhooks();
      setWebhooks(data);
    } catch (e) {
      console.warn('Load webhooks failed:', e);
    }
  };

  const loadSmsConfig = async () => {
    try {
      const data = await apiHubService.getSmsConfig();
      if (data) setSmsConfig(data);
    } catch (e) {
      console.warn('Load SMS config failed:', e);
    }
  };

  const handleCreateApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName) return;

    try {
      const res = await apiHubService.createApiKey({
        name: newKeyName,
        scopes: newKeyScopes,
        rateLimitPerMin: newKeyRateLimit,
        description: newKeyDescription,
      });

      if (res.success && res.data) {
        setCreatedKeySecret(res.data.apiKey || null);
        loadApiKeys();
        setNewKeyName('');
        setNewKeyDescription('');
        addAuditLog('Created External API Key', 'API Integrations', `Generated key ${res.data.name}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteApiKey = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to permanently revoke key "${name}"? External systems using it will lose access immediately.`)) return;
    try {
      await apiHubService.deleteApiKey(id);
      loadApiKeys();
      addAuditLog('Revoked External API Key', 'API Integrations', `Revoked key "${name}"`);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWebhookName || !newWebhookUrl) return;

    try {
      const res = await apiHubService.createWebhook({
        name: newWebhookName,
        targetUrl: newWebhookUrl,
        events: newWebhookEvents,
      });

      if (res.success) {
        loadWebhooks();
        setIsCreateWebhookModalOpen(false);
        setNewWebhookName('');
        setNewWebhookUrl('');
        addAuditLog('Created Webhook Subscription', 'API Integrations', `Subscribed ${newWebhookName}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteWebhook = async (id: string, name: string) => {
    if (!window.confirm(`Delete webhook "${name}"?`)) return;
    try {
      await apiHubService.deleteWebhook(id);
      loadWebhooks();
    } catch (err) {
      console.error(err);
    }
  };

  const handleTestWebhook = async (webhookId: string) => {
    setTestingWebhookId(webhookId);
    setWebhookTestResult(null);
    try {
      const res = await apiHubService.testWebhook(webhookId, 'member.created');
      setWebhookTestResult(res);
    } catch (err: any) {
      setWebhookTestResult({ error: err.message || 'Webhook test failed' });
    } finally {
      setTestingWebhookId(null);
    }
  };

  const handleSendTestSms = async (e: React.FormEvent) => {
    e.preventDefault();
    setSmsSending(true);
    setSmsResult(null);

    try {
      const res = await apiHubService.sendTestSms({
        gateway: smsConfig.provider,
        recipients: [testSmsRecipient],
        message: testSmsMessage,
        senderId: smsConfig.senderId,
      });
      setSmsResult(res);
      addAuditLog('SMS Gateway Test Dispatch', 'API Integrations', `Dispatched SMS to ${testSmsRecipient} via ${smsConfig.provider}`);
    } catch (err: any) {
      setSmsResult({ error: err.message || 'Failed to dispatch SMS' });
    } finally {
      setSmsSending(false);
    }
  };

  const handleExecuteConsoleTest = async () => {
    setExecutingApiTest(true);
    setApiConsoleResponse(null);

    try {
      let parsedBody = undefined;
      if (selectedMethod === 'POST') {
        try {
          parsedBody = JSON.parse(testRequestBody);
        } catch {
          setApiConsoleResponse({ error: 'Invalid JSON in request body' });
          setExecutingApiTest(false);
          return;
        }
      }

      const res = await apiHubService.executeApiTest(
        selectedEndpoint,
        selectedMethod,
        testApiKey,
        parsedBody
      );
      setApiConsoleResponse(res);
    } catch (err: any) {
      setApiConsoleResponse({ error: err.message || 'Network request failed' });
    } finally {
      setExecutingApiTest(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  const samplePostgresSql = `-- Sovereign CMMS Supabase Cloud Schema
-- Run this script in Supabase SQL Editor: https://app.supabase.com/project/_/sql

CREATE TABLE IF NOT EXISTS public.members (
    id TEXT PRIMARY KEY,
    title TEXT DEFAULT 'Mr.',
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    amharic_name TEXT,
    email TEXT UNIQUE,
    primary_phone TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    membership_status TEXT DEFAULT 'Active',
    discipleship_status TEXT DEFAULT 'New Believer',
    join_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.attendance_records (
    id TEXT PRIMARY KEY,
    member_id TEXT REFERENCES public.members(id) ON DELETE CASCADE,
    member_name TEXT,
    service_type TEXT NOT NULL,
    check_in_time TEXT NOT NULL,
    date DATE DEFAULT CURRENT_DATE,
    branch_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.branches (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    senior_pastor TEXT,
    city TEXT DEFAULT 'Addis Ababa',
    status TEXT DEFAULT 'Active'
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;

-- Allow Authenticated Staff & Read-Only Public API Access
DROP POLICY IF EXISTS "Public Read Access" ON public.members;
CREATE POLICY "Public Read Access" ON public.members FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public Read Branches" ON public.branches;
CREATE POLICY "Public Read Branches" ON public.branches FOR SELECT USING (true);
`;

  return (
    <div className="space-y-6 pb-12">
      {/* ================= TOP HEADER BANNER ================= */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-blue-600/30 border border-blue-500/40 text-blue-400 flex items-center justify-center font-bold">
                <Terminal className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                    System API & Integrations Hub
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-amber-400" /> Super Admin Exclusive
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  Connect external systems, manage Supabase database status, configure SMS gateways, generate secure API keys, and manage webhooks.
                </p>
              </div>
            </div>
          </div>

          {/* Quick System Indicators */}
          <div className="flex flex-wrap items-center gap-2.5 text-xs font-semibold">
            {/* Supabase Status Pill */}
            <div
              onClick={handleCheckSupabase}
              className={`px-3.5 py-2 rounded-2xl border cursor-pointer transition-all flex items-center gap-2 ${
                supabaseStatus?.isConnected
                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                  : 'bg-amber-950/60 border-amber-800 text-amber-300'
              }`}
            >
              <Database className="w-4 h-4 text-emerald-400" />
              <span>
                Supabase:{' '}
                {checkingSupabase
                  ? 'Testing...'
                  : supabaseStatus?.isConnected
                  ? `Connected (${supabaseStatus.latencyMs || 24}ms)`
                  : 'Local PostgreSQL Engine'}
              </span>
              <RefreshCw className={`w-3.5 h-3.5 ${checkingSupabase ? 'animate-spin' : ''}`} />
            </div>

            {/* REST API Status */}
            <div className="px-3.5 py-2 rounded-2xl bg-blue-950/60 border border-blue-800 text-blue-300 flex items-center gap-2">
              <Zap className="w-4 h-4 text-blue-400" />
              <span>REST API: v1.4.0 Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* ================= NAVIGATION TABS ================= */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'supabase', label: 'Supabase Cloud Database', icon: Database, badge: supabaseStatus?.isConnected ? 'Live' : 'Standby' },
          { id: 'sms_gateway', label: 'SMS Gateway Engine', icon: Smartphone, badge: `${smsConfig.balanceCredits} Credits` },
          { id: 'external_api', label: 'External REST API & Keys', icon: Key, badge: `${apiKeys.length} Keys` },
          { id: 'webhooks', label: 'Webhooks & Subscriptions', icon: Webhook, badge: `${webhooks.length} Active` },
          { id: 'sdk_code', label: 'SDK & Code Snippets', icon: Code2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-extrabold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    isActive
                      ? 'bg-blue-800 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ================= TAB 1: SUPABASE CLOUD CONNECTION ================= */}
      {activeTab === 'supabase' && (
        <div className="space-y-6">
          {/* Connection Status Card */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                    supabaseStatus?.isConnected
                      ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                      : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                  }`}
                >
                  <Database className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Supabase PostgreSQL Cloud Connection
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Live telemetry between this application and your Supabase PostgreSQL cluster.
                  </p>
                </div>
              </div>

              <button
                onClick={handleCheckSupabase}
                disabled={checkingSupabase}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-blue-600/20"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${checkingSupabase ? 'animate-spin' : ''}`} />
                <span>{checkingSupabase ? 'Verifying Link...' : 'Test Connection Now'}</span>
              </button>
            </div>

            {/* Diagnostic Metrics Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                <span className="text-[10px] uppercase font-bold text-slate-400">Connection State</span>
                <div className="flex items-center gap-2 mt-1">
                  {supabaseStatus?.isConnected ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                        Connected (Live)
                      </span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                      <span className="text-sm font-black text-amber-600 dark:text-amber-400">
                        Standby / Local Engine
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                <span className="text-[10px] uppercase font-bold text-slate-400">Roundtrip Latency</span>
                <p className="text-sm font-black text-slate-900 dark:text-white mt-1">
                  {supabaseStatus?.latencyMs ? `${supabaseStatus.latencyMs} ms` : 'Local (<1 ms)'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                <span className="text-[10px] uppercase font-bold text-slate-400">Project Endpoint</span>
                <p className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 mt-1 truncate">
                  {supabaseStatus?.url || 'VITE_SUPABASE_URL not configured'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60">
                <span className="text-[10px] uppercase font-bold text-slate-400">Anon Key Status</span>
                <div className="flex items-center gap-1.5 mt-1">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      supabaseStatus?.anonKeyConfigured ? 'bg-emerald-500' : 'bg-rose-500'
                    }`}
                  />
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    {supabaseStatus?.anonKeyConfigured ? 'Key Injected' : 'Missing Anon Key'}
                  </span>
                </div>
              </div>
            </div>

            {/* How to Check & Connect Step-by-Step Guide */}
            <div className="p-5 bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 rounded-2xl space-y-4">
              <div className="flex items-center gap-2 text-blue-900 dark:text-blue-200 font-bold text-sm">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <h4>How to Check Connection & Link Supabase to this CMMS</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700 dark:text-slate-300">
                <div className="space-y-2">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      1
                    </span>
                    <div>
                      <strong className="block text-slate-900 dark:text-white font-semibold">
                        Get Credentials from Supabase
                      </strong>
                      Go to your Supabase Project Dashboard → <em>Project Settings</em> → <em>API</em>. Copy the <strong>Project URL</strong> and <strong>Project API anon key</strong>.
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      2
                    </span>
                    <div>
                      <strong className="block text-slate-900 dark:text-white font-semibold">
                        Add Environment Variables
                      </strong>
                      Set <code className="font-mono bg-blue-100 dark:bg-blue-900 px-1 py-0.5 rounded">VITE_SUPABASE_URL</code> and <code className="font-mono bg-blue-100 dark:bg-blue-900 px-1 py-0.5 rounded">VITE_SUPABASE_ANON_KEY</code> in your environment or <code className="font-mono">.env</code>.
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      3
                    </span>
                    <div>
                      <strong className="block text-slate-900 dark:text-white font-semibold">
                        Execute Schema Migration
                      </strong>
                      Copy the SQL Schema below and paste it into the <em>SQL Editor</em> in your Supabase console to create all 8 core tables with RLS security policies.
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      4
                    </span>
                    <div>
                      <strong className="block text-slate-900 dark:text-white font-semibold">
                        Verify Connection
                      </strong>
                      Click <em>"Test Connection Now"</em> above. A green badge indicates live PostgreSQL table synchronization.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* SQL Schema Copy Block */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                  <FileCode className="w-4 h-4 text-indigo-500" />
                  <span>Supabase PostgreSQL DDL Schema (schema.postgres.sql)</span>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(samplePostgresSql);
                    setCopiedSchema(true);
                    setTimeout(() => setCopiedSchema(false), 2000);
                  }}
                  className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  {copiedSchema ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSchema ? 'Copied SQL!' : 'Copy SQL Schema'}</span>
                </button>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 max-h-56 overflow-y-auto">
                <pre className="text-[11px] font-mono text-indigo-300 whitespace-pre leading-relaxed">
                  {samplePostgresSql}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: SMS GATEWAY ENGINE ================= */}
      {activeTab === 'sms_gateway' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* SMS Config Card */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-blue-600" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  SMS Gateway Configuration
                </h4>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                Status: Active
              </span>
            </div>

            {/* Provider details */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Active SMS Gateway Engine:
              </label>
              <div className="p-3.5 rounded-2xl border border-blue-600 bg-blue-50/60 dark:bg-blue-950/40 ring-2 ring-blue-500/20">
                <div className="flex items-center justify-between mb-1">
                  <p className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>Ethio Telecom REST SMS Gateway</span>
                  </p>
                  <span className="text-[10px] text-blue-700 dark:text-blue-300 font-bold bg-blue-100 dark:bg-blue-900/60 px-2 py-0.5 rounded-md">
                    Exclusive SMS Gateway
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300">
                  Direct HTTP REST API endpoint (<code className="font-mono text-[10px] text-blue-600 dark:text-blue-400">/sms/v1/send</code>) for Ethiopian mobile networks (09, 07, +251).
                </p>
              </div>
            </div>

            {/* Sender ID & Quotas */}
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Registered Sender ID:
                </label>
                <input
                  type="text"
                  value={smsConfig.senderId}
                  onChange={(e) => setSmsConfig({ ...smsConfig, senderId: e.target.value })}
                  placeholder="e.g. GRACECATH"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Credit Balance:
                </label>
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono font-bold text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700">
                  {smsConfig.balanceCredits.toLocaleString()} Credits Available
                </div>
              </div>
            </div>

            {/* Quota Progress Bar */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-600 dark:text-slate-400">Monthly Usage</span>
                <span className="text-slate-900 dark:text-white font-bold">
                  {smsConfig.usedCredits} / {smsConfig.monthlyQuota} SMS (
                  {Math.round((smsConfig.usedCredits / smsConfig.monthlyQuota) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-blue-600 h-full rounded-full transition-all"
                  style={{ width: `${(smsConfig.usedCredits / smsConfig.monthlyQuota) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Test SMS Dispatcher */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-indigo-600" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Live Test SMS Dispatcher
                </h4>
              </div>
              <span className="text-xs text-slate-400 font-mono font-semibold">
                Sender: {smsConfig.senderId}
              </span>
            </div>

            <form onSubmit={handleSendTestSms} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Recipient Phone (+2519..., +2517..., 09..., 07...):
                </label>
                <input
                  type="text"
                  required
                  value={testSmsRecipient}
                  onChange={(e) => setTestSmsRecipient(e.target.value)}
                  placeholder="+251911223344 or 0911223344"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-slate-900 dark:text-white font-bold"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Message Body:</label>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {testSmsMessage.length} chars ({Math.ceil(testSmsMessage.length / 160)} segment)
                  </span>
                </div>
                <textarea
                  rows={3}
                  required
                  value={testSmsMessage}
                  onChange={(e) => setTestSmsMessage(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <button
                type="submit"
                disabled={smsSending}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{smsSending ? 'Dispatching Message...' : 'Send Test SMS Message'}</span>
              </button>
            </form>

            {smsResult && (
              <div
                className={`p-3.5 rounded-xl text-xs font-mono border ${
                  smsResult.success
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                    : 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
                }`}
              >
                {smsResult.success ? (
                  <div>
                    <p className="font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Dispatch Success (ID: {smsResult.dispatchId})
                    </p>
                    <p className="text-[11px] mt-1 text-slate-600 dark:text-slate-400">
                      Dispatched to: {smsResult.successfulNumbers?.join(', ')} via {smsResult.gatewayUsed}
                    </p>
                  </div>
                ) : (
                  <p className="font-bold">Error: {smsResult.error || 'Failed to dispatch'}</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 3: EXTERNAL REST API & API KEYS ================= */}
      {activeTab === 'external_api' && (
        <div className="space-y-6">
          {/* API Keys Header & Creation */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Key className="w-5 h-5 text-blue-600" />
                  <span>External System API Keys</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Generate tokens for third-party systems (Website, Kiosks, Mobile Apps, Biometrics, Accounting) to connect via REST API.
                </p>
              </div>

              <button
                onClick={() => setIsCreateKeyModalOpen(true)}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl text-xs font-bold shadow-md shadow-blue-600/20 flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Generate New API Key</span>
              </button>
            </div>

            {/* Newly Created Key Alert Modal */}
            {createdKeySecret && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-200 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>New API Key Generated — Copy it now!</span>
                </div>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-300">
                  This key will not be shown in full again. Store it securely in your external system's environment variables.
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={createdKeySecret}
                    className="flex-1 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 font-mono text-xs font-bold text-slate-900 dark:text-white"
                  />
                  <button
                    onClick={() => copyToClipboard(createdKeySecret, 'new_key')}
                    className="px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedKeyId === 'new_key' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedKeyId === 'new_key' ? 'Copied!' : 'Copy Key'}</span>
                  </button>
                  <button
                    onClick={() => setCreatedKeySecret(null)}
                    className="px-3 py-2.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}

            {/* Active API Keys Table */}
            <div className="space-y-3">
              {apiKeys.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  No active API keys found. Click "Generate New API Key" above.
                </div>
              ) : (
                apiKeys.map((key) => (
                  <div
                    key={key.id}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white text-sm">
                          {key.name}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                          {key.keyPrefix}...
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                          {key.status}
                        </span>
                      </div>
                      {key.description && (
                        <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                          {key.description}
                        </p>
                      )}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[10px] text-slate-400 font-semibold">Scopes:</span>
                        {key.scopes.map((scope) => (
                          <span
                            key={scope}
                            className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-[10px] font-mono text-slate-700 dark:text-slate-300"
                          >
                            {scope}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right text-[11px] text-slate-400 hidden sm:block">
                        <div>Rate: {key.rateLimitPerMin} req/min</div>
                        <div>Last used: {key.lastUsedAt ? new Date(key.lastUsedAt).toLocaleDateString() : 'Never'}</div>
                      </div>

                      {key.apiKey && (
                        <button
                          onClick={() => copyToClipboard(key.apiKey!, key.id)}
                          className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition-all"
                        >
                          {copiedKeyId === key.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedKeyId === key.id ? 'Copied' : 'Copy'}</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteApiKey(key.id, key.name)}
                        className="p-2 text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-950/60 rounded-xl cursor-pointer transition-all"
                        title="Revoke Key"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Interactive REST API Explorer Console */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-600" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Interactive REST API Console & Simulator
                </h4>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Header: X-API-Key: {testApiKey ? `${testApiKey.slice(0, 12)}...` : ''}</span>
            </div>

            {/* Endpoint & Method Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <select
                value={selectedMethod}
                onChange={(e) => setSelectedMethod(e.target.value as any)}
                className="p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white"
              >
                <option value="GET">GET</option>
                <option value="POST">POST</option>
              </select>

              <select
                value={selectedEndpoint}
                onChange={(e) => {
                  setSelectedEndpoint(e.target.value);
                  if (e.target.value.includes('members') && selectedMethod === 'POST') {
                    setSelectedMethod('POST');
                  }
                }}
                className="flex-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white"
              >
                <option value="/api/v1/external/members">GET /api/v1/external/members (List & Search Members)</option>
                <option value="/api/v1/external/members">POST /api/v1/external/members (Create / Ingest Member)</option>
                <option value="/api/v1/external/attendance">GET /api/v1/external/attendance (Attendance Logs)</option>
                <option value="/api/v1/external/attendance/check-in">POST /api/v1/external/attendance/check-in (Kiosk/Biometric Check-In)</option>
                <option value="/api/v1/external/events">GET /api/v1/external/events (Church Events & Services)</option>
                <option value="/api/v1/external/branches">GET /api/v1/external/branches (Campus Directory)</option>
                <option value="/api/v1/external/system/health">GET /api/v1/external/system/health (System Health Ping)</option>
              </select>

              <button
                onClick={handleExecuteConsoleTest}
                disabled={executingApiTest}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{executingApiTest ? 'Executing...' : 'Execute'}</span>
              </button>
            </div>

            {/* Request Body Editor (for POST) */}
            {selectedMethod === 'POST' && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Request JSON Body:
                </label>
                <textarea
                  rows={5}
                  value={testRequestBody}
                  onChange={(e) => setTestRequestBody(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-slate-950 font-mono text-xs text-indigo-200 border border-slate-800"
                />
              </div>
            )}

            {/* Live Response Viewer */}
            {apiConsoleResponse && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-700 dark:text-slate-300">Response Payload:</span>
                    <span
                      className={`px-2 py-0.5 rounded font-bold ${
                        apiConsoleResponse.status >= 200 && apiConsoleResponse.status < 300
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      }`}
                    >
                      Status: {apiConsoleResponse.status || 'Error'}
                    </span>
                  </div>
                  <span className="text-slate-400 font-semibold">{apiConsoleResponse.durationMs}ms</span>
                </div>

                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 max-h-72 overflow-y-auto">
                  <pre className="text-[11px] font-mono text-emerald-300 whitespace-pre leading-relaxed">
                    {JSON.stringify(apiConsoleResponse.data, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 4: WEBHOOKS ================= */}
      {activeTab === 'webhooks' && (
        <div className="space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Webhook className="w-5 h-5 text-indigo-600" />
                  <span>Outbound Webhook Event Subscriptions</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Push real-time notifications to external systems whenever members register, attend, or submit prayers.
                </p>
              </div>

              <button
                onClick={() => setIsCreateWebhookModalOpen(true)}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Subscribe Webhook</span>
              </button>
            </div>

            {/* Webhooks list */}
            <div className="space-y-3">
              {webhooks.map((wh) => (
                <div
                  key={wh.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white text-sm">
                          {wh.name}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                          {wh.active ? 'Active' : 'Disabled'}
                        </span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 font-mono text-[11px] mt-0.5">
                        {wh.targetUrl}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleTestWebhook(wh.id)}
                        disabled={testingWebhookId === wh.id}
                        className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer transition-all"
                      >
                        <Zap className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{testingWebhookId === wh.id ? 'Testing...' : 'Send Test Ping'}</span>
                      </button>

                      <button
                        onClick={() => handleDeleteWebhook(wh.id, wh.name)}
                        className="p-2 text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-950/60 rounded-xl cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-[10px]">
                    <span className="text-slate-400 font-semibold">Subscribed Events:</span>
                    {wh.events.map((evt) => (
                      <span
                        key={evt}
                        className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-mono font-bold"
                      >
                        {evt}
                      </span>
                    ))}
                    <span className="text-slate-400 ml-auto font-mono">
                      Secret: {wh.secretToken.slice(0, 14)}...
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Webhook Test Output */}
            {webhookTestResult && (
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono text-emerald-400 font-bold">
                  <span>Webhook Simulator Result:</span>
                  <span>Signature: HMAC SHA256 Verified</span>
                </div>
                <pre className="text-[11px] font-mono text-slate-300 whitespace-pre leading-relaxed">
                  {JSON.stringify(webhookTestResult, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 5: SDK & CODE SNIPPETS ================= */}
      {activeTab === 'sdk_code' && (
        <div className="space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Code2 className="w-5 h-5 text-blue-600" />
                <span>Integration Code Snippets & SDK</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Copy and paste production code snippets in your preferred language to connect external systems to this CMMS.
              </p>
            </div>

            {/* cURL Snippet */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>cURL (Bash / CLI)</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `curl -X GET "https://your-domain.com/api/v1/external/members?limit=10" \\\n  -H "X-API-Key: cmms_live_YOUR_KEY_HERE" \\\n  -H "Content-Type: application/json"`,
                      'curl'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedKeyId === 'curl' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <pre className="text-[11px] font-mono text-emerald-300 whitespace-pre">
{`# 1. Fetch Church Members Directory
curl -X GET "https://your-domain.com/api/v1/external/members?limit=10" \\
  -H "X-API-Key: cmms_live_YOUR_KEY_HERE" \\
  -H "Content-Type: application/json"

# 2. Ingest New Member from External Website
curl -X POST "https://your-domain.com/api/v1/external/members" \\
  -H "X-API-Key: cmms_live_YOUR_KEY_HERE" \\
  -H "Content-Type: application/json" \\
  -d '{
    "firstName": "Tigist",
    "lastName": "Assefa",
    "primaryPhone": "+251911223344",
    "email": "tigist@example.com",
    "branchId": "b1"
  }'`}
                </pre>
              </div>
            </div>

            {/* JavaScript / Node.js Snippet */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>JavaScript / TypeScript (Fetch / Node.js)</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `const res = await fetch('https://your-domain.com/api/v1/external/members', {\n  headers: { 'X-API-Key': 'cmms_live_YOUR_KEY_HERE' }\n});\nconst data = await res.json();`,
                      'js'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedKeyId === 'js' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <pre className="text-[11px] font-mono text-indigo-300 whitespace-pre">
{`// Query Church Members
async function getMembers() {
  const response = await fetch('https://your-domain.com/api/v1/external/members?branchId=b1', {
    method: 'GET',
    headers: {
      'X-API-Key': 'cmms_live_YOUR_KEY_HERE',
      'Content-Type': 'application/json',
    },
  });
  const data = await response.json();
  console.log('Members:', data);
}`}
                </pre>
              </div>
            </div>

            {/* Python Snippet */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>Python (requests library)</span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      `import requests\n\nheaders = {'X-API-Key': 'cmms_live_YOUR_KEY_HERE'}\nres = requests.get('https://your-domain.com/api/v1/external/members', headers=headers)\nprint(res.json())`,
                      'py'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedKeyId === 'py' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <pre className="text-[11px] font-mono text-amber-300 whitespace-pre">
{`import requests

headers = {
    "X-API-Key": "cmms_live_YOUR_KEY_HERE",
    "Content-Type": "application/json"
}

# Record Sanctuary Biometric Kiosk Check-In
payload = {
    "phone": "+251911223344",
    "serviceType": "Sunday Main Service",
    "checkInMethod": "Facial Recognition / Biometric"
}

response = requests.post("https://your-domain.com/api/v1/external/attendance/check-in", json=payload, headers=headers)
print(response.json())`}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE API KEY ================= */}
      {isCreateKeyModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Key className="w-5 h-5 text-blue-600" />
                <span>Generate External System API Key</span>
              </h3>
              <button
                onClick={() => setIsCreateKeyModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form
              onSubmit={(e) => {
                handleCreateApiKey(e);
                setIsCreateKeyModalOpen(false);
              }}
              className="space-y-4 text-xs"
            >
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Key Name / Integration System:
                </label>
                <input
                  type="text"
                  required
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  placeholder="e.g. Next.js Public Church Website, Foyer Kiosk Tablet"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Description (Optional):
                </label>
                <input
                  type="text"
                  value={newKeyDescription}
                  onChange={(e) => setNewKeyDescription(e.target.value)}
                  placeholder="e.g. Syncs online member registration form"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Rate Limit (Requests per minute):
                </label>
                <input
                  type="number"
                  min={10}
                  max={1000}
                  value={newKeyRateLimit}
                  onChange={(e) => setNewKeyRateLimit(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Permissions / Scopes:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'read:members', label: 'Read Members' },
                    { id: 'write:members', label: 'Create/Sync Members' },
                    { id: 'read:attendance', label: 'Read Attendance' },
                    { id: 'write:attendance', label: 'Record Check-In' },
                    { id: 'read:events', label: 'Read Events' },
                    { id: 'send:sms', label: 'Dispatch SMS' },
                    { id: 'admin:full', label: 'Full Admin Scope' },
                  ].map((scope) => {
                    const isChecked = newKeyScopes.includes(scope.id);
                    return (
                      <label
                        key={scope.id}
                        className={`p-2 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-500 text-blue-700 dark:text-blue-300'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewKeyScopes([...newKeyScopes, scope.id]);
                            } else {
                              setNewKeyScopes(newKeyScopes.filter((s) => s !== scope.id));
                            }
                          }}
                          className="rounded text-blue-600"
                        />
                        <span className="font-semibold text-xs">{scope.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateKeyModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md shadow-blue-600/20 cursor-pointer"
                >
                  Generate Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE WEBHOOK ================= */}
      {isCreateWebhookModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Webhook className="w-5 h-5 text-indigo-600" />
                <span>Subscribe New Webhook</span>
              </h3>
              <button
                onClick={() => setIsCreateWebhookModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateWebhook} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Webhook Name:
                </label>
                <input
                  type="text"
                  required
                  value={newWebhookName}
                  onChange={(e) => setNewWebhookName(e.target.value)}
                  placeholder="e.g. Pastoral Care CRM Sync"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Endpoint URL (HTTPS):
                </label>
                <input
                  type="url"
                  required
                  value={newWebhookUrl}
                  onChange={(e) => setNewWebhookUrl(e.target.value)}
                  placeholder="https://your-crm.com/api/webhooks"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Event Triggers:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'member.created', label: 'Member Registered' },
                    { id: 'member.updated', label: 'Member Updated' },
                    { id: 'attendance.recorded', label: 'Attendance Checked In' },
                    { id: 'event.created', label: 'Event Created' },
                    { id: 'prayer.submitted', label: 'Prayer Submitted' },
                    { id: 'sms.dispatched', label: 'SMS Dispatched' },
                  ].map((evt) => {
                    const isChecked = newWebhookEvents.includes(evt.id);
                    return (
                      <label
                        key={evt.id}
                        className={`p-2 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-indigo-700 dark:text-indigo-300'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewWebhookEvents([...newWebhookEvents, evt.id]);
                            } else {
                              setNewWebhookEvents(newWebhookEvents.filter((s) => s !== evt.id));
                            }
                          }}
                          className="rounded text-indigo-600"
                        />
                        <span className="font-semibold text-xs">{evt.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateWebhookModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-md shadow-indigo-600/20 cursor-pointer"
                >
                  Subscribe Webhook
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
