import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { PrayerRequest, CounselingSession } from '../types';
import {
  HeartHandshake,
  Plus,
  Lock,
  Video,
  CheckCircle,
  X,
  MessageCircle,
  Shield,
  Sparkles,
  Calendar,
  Clock,
} from 'lucide-react';

export const PrayerCounselingModule: React.FC = () => {
  const {
    prayerRequests,
    addPrayerRequest,
    updatePrayerStatus,
    counselingSessions,
    addCounselingSession,
    members,
    currentUser,
    permissions,
  } = useCMMS();

  const [activeTab, setActiveTab] = useState<'prayer' | 'counseling'>('prayer');
  const [isNewPrayerModalOpen, setIsNewPrayerModalOpen] = useState(false);
  const [isBookCounselingModalOpen, setIsBookCounselingModalOpen] = useState(false);

  // Prayer form
  const [prayerTitle, setPrayerTitle] = useState('');
  const [prayerDesc, setPrayerDesc] = useState('');
  const [prayerCategory, setPrayerCategory] =
    useState<PrayerRequest['category']>('Physical Health');
  const [isConfidential, setIsConfidential] = useState(false);

  // Counseling form
  const [counselingClientMemberId, setCounselingClientMemberId] = useState(members[0]?.id || '');
  const [counselingType, setCounselingType] =
    useState<CounselingSession['counselingType']>('Marriage');
  const [sessionDate, setSessionDate] = useState(new Date().toISOString().split('T')[0]);

  const handleCreatePrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerTitle) return;

    const newPr: PrayerRequest = {
      id: `pr-${Date.now().toString().slice(-4)}`,
      requestNumber: `PR-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      memberId: members[0]?.id || currentUser?.memberId || '',
      memberName: members[0] ? `${members[0].firstName} ${members[0].lastName}` : (currentUser?.name || 'Member'),
      category: prayerCategory,
      title: prayerTitle,
      description: prayerDesc,
      isConfidential,
      urgency: 'High',
      status: 'Pending',
      submittedDate: new Date().toISOString().split('T')[0],
    };

    addPrayerRequest(newPr);
    setIsNewPrayerModalOpen(false);
  };

  const handleBookCounseling = (e: React.FormEvent) => {
    e.preventDefault();
    const client = members.find((m) => m.id === counselingClientMemberId);

    const newCs: CounselingSession = {
      id: `cs-${Date.now().toString().slice(-4)}`,
      sessionCode: `CNS-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      clientMemberId: counselingClientMemberId,
      clientName: client ? `${client.firstName} ${client.lastName}` : '',
      counselorName: currentUser?.name || 'Assigned Counselor',
      counselingType,
      sessionDate,
      sessionTime: '02:00 PM',
      mode: 'In-Person',
      status: 'Scheduled',
      encryptedCaseNotes: '[Pastoral counseling session notes encrypted with AES-256]',
      treatmentGoals: ['Spiritual breakthrough', 'Weekly accountability'],
    };

    addCounselingSession(newCs);
    setIsBookCounselingModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-6 h-6 text-rose-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Prayer & Pastoral Counseling Center</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200">
              Encrypted Pastoral Care
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Prayer chain assignments, testimonies, confidential pastoral counseling, and case treatment plans.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsNewPrayerModalOpen(true)}
            className="min-h-[44px] px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Submit Prayer Request</span>
          </button>

          {permissions.canViewCounseling && (
            <button
              onClick={() => setIsBookCounselingModalOpen(true)}
              className="min-h-[44px] px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Book Pastoral Counseling</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs bar */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-3 sm:gap-6 text-sm font-semibold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('prayer')}
          className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'prayer'
              ? 'border-rose-600 text-rose-600 dark:text-rose-400 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" /> <span>Prayer Requests & Testimonies ({prayerRequests.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('counseling')}
          className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'counseling'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Lock className="w-4 h-4" /> <span>Confidential Counseling Sessions ({counselingSessions.length})</span>
        </button>
      </div>

      {/* Tab Body */}
      {activeTab === 'prayer' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {prayerRequests.map((pr) => (
            <div
              key={pr.id}
              className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-rose-600 dark:text-rose-400">
                  {pr.requestNumber}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    pr.status === 'Answered'
                      ? 'bg-emerald-100 text-emerald-800'
                      : pr.status === 'Praying'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {pr.status}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">{pr.title}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{pr.description}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500">Member: {pr.memberName}</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => updatePrayerStatus(pr.id, 'Praying')}
                    className="px-2 py-1 bg-blue-50 text-blue-700 rounded font-semibold text-[10px]"
                  >
                    Mark Praying
                  </button>
                  <button
                    onClick={() => updatePrayerStatus(pr.id, 'Answered', 'Glory to God! Prayer answered.')}
                    className="px-2 py-1 bg-emerald-50 text-emerald-700 rounded font-semibold text-[10px]"
                  >
                    Mark Answered
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'counseling' && (
        <div className="space-y-4">
          {!permissions.canViewCounseling ? (
            <div className="p-8 text-center bg-rose-50 dark:bg-rose-950/40 rounded-2xl border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 space-y-2">
              <Lock className="w-8 h-8 mx-auto text-rose-600" />
              <h3 className="font-bold text-base">Restricted Confidential Access</h3>
              <p className="text-xs">
                Counseling records are encrypted and accessible only to authorized Pastoral Counselors & Branch Administrators.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {counselingSessions.map((cs) => (
                <div
                  key={cs.id}
                  className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-purple-600 dark:text-purple-400">
                      {cs.sessionCode}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800">
                      {cs.counselingType}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">Client: {cs.clientName}</h4>
                    <p className="text-slate-500">Counselor: {cs.counselorName}</p>
                    <p className="text-slate-500">
                      {cs.sessionDate} @ {cs.sessionTime} ({cs.mode})
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl font-mono text-[11px] text-slate-600 dark:text-slate-300">
                    <Lock className="w-3.5 h-3.5 inline mr-1 text-purple-600" />
                    {cs.encryptedCaseNotes}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Submit Prayer Modal */}
      {isNewPrayerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Submit Prayer Request</h3>
              <button onClick={() => setIsNewPrayerModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePrayer} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1">Prayer Title</label>
                <input
                  type="text"
                  required
                  value={prayerTitle}
                  onChange={(e) => setPrayerTitle(e.target.value)}
                  placeholder="e.g. Healing for Family Member"
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Category</label>
                <select
                  value={prayerCategory}
                  onChange={(e) => setPrayerCategory(e.target.value as any)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Physical Health">Physical Health</option>
                  <option value="Emotional Well-being">Emotional Well-being</option>
                  <option value="Family Situation">Family Situation</option>
                  <option value="Financial Need">Financial Need</option>
                  <option value="Spiritual Concern">Spiritual Concern</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Details</label>
                <textarea
                  rows={3}
                  required
                  value={prayerDesc}
                  onChange={(e) => setPrayerDesc(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="confidential"
                  checked={isConfidential}
                  onChange={(e) => setIsConfidential(e.target.checked)}
                />
                <label htmlFor="confidential" className="font-semibold">
                  Keep Confidential (Pastoral Team Only)
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewPrayerModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-rose-600 text-white rounded-xl font-semibold">
                  Submit Prayer Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Book Counseling Modal */}
      {isBookCounselingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Book Pastoral Counseling</h3>
              <button onClick={() => setIsBookCounselingModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBookCounseling} className="space-y-3">
              <div>
                <label className="block font-semibold mb-1">Select Member Client</label>
                <select
                  value={counselingClientMemberId}
                  onChange={(e) => setCounselingClientMemberId(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Counseling Type</label>
                <select
                  value={counselingType}
                  onChange={(e) => setCounselingType(e.target.value as any)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Marriage">Marriage Counseling</option>
                  <option value="Premarital">Premarital Counseling</option>
                  <option value="Youth">Youth Counseling</option>
                  <option value="Grief">Grief & Bereavement</option>
                  <option value="Spiritual">Spiritual Guidance</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={sessionDate}
                  onChange={(e) => setSessionDate(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBookCounselingModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-purple-600 text-white rounded-xl font-semibold">
                  Confirm Session
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
