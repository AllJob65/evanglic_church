import React, { useState, useEffect, useMemo } from 'react';
import {
  Ministry,
  MinistryAnnualPlan,
  MinistryPlanWorkflowStatus,
  MinistryPlanObjective,
  MinistryPlanActivityItem,
  MinistryPlanKpiItem,
  MinistryPlanRiskItem,
  MinistryQuarterlyReport,
  MinistryQuarter,
  MinistryQuarterlyActivityReportItem,
  MinistryQuarterlyKpiReportItem,
} from '../types';
import { apiService } from '../services/api';
import {
  generateQuarterlyAndMonthlySchedule,
  aggregateQuarterlyReportsIntoAnnualReport,
  downloadMinistryPlanPdf,
  downloadMinistryPlanXlsx,
} from '../utils/ministryPlanningEngine';
import {
  FileText,
  FileSpreadsheet,
  Plus,
  Send,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Eye,
  Calendar,
  Target,
  Activity,
  DollarSign,
  Users,
  AlertTriangle,
  TrendingUp,
  Clock,
  ShieldCheck,
  MessageSquare,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Check,
  Trash2,
  Edit3,
  Layers,
  Award,
  ClipboardCheck,
  RefreshCw,
} from 'lucide-react';

interface MinistryAnnualPlanningManagerProps {
  ministries: Ministry[];
  selectedMinistry: Ministry | null;
  currency: string;
  currentUser: any;
  activeRole: string;
}

const WORKFLOW_STEPS: MinistryPlanWorkflowStatus[] = [
  'Draft',
  'Submitted',
  'Under Review',
  'Returned for Revision',
  'Approved',
  'Active',
  'Completed',
];

const STATUS_BADGE_STYLES: Record<string, string> = {
  Draft: 'bg-slate-800 text-slate-300 border-slate-700',
  Submitted: 'bg-sky-500/15 text-sky-400 border-sky-500/30',
  'Under Review': 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  'Returned for Revision': 'bg-orange-500/15 text-orange-400 border-orange-500/30',
  Approved: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  Active: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30',
  Completed: 'bg-teal-500/15 text-teal-300 border-teal-500/30',
  Rejected: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
};

const MONTH_OPTIONS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export const MinistryAnnualPlanningManager: React.FC<MinistryAnnualPlanningManagerProps> = ({
  ministries,
  selectedMinistry,
  currency,
  currentUser,
  activeRole,
}) => {
  const [plans, setPlans] = useState<MinistryAnnualPlan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [filterAllMinistries, setFilterAllMinistries] = useState<boolean>(false);

  // Sub-navigation inside the selected plan
  const [activeSubView, setActiveSubView] = useState<
    'overview' | 'timeline' | 'pastor_review' | 'quarterly_reports' | 'annual_report' | 'builder'
  >('overview');

  // Role detection for Pastor vs Ministry Leader capabilities
  const normalizedRole = String(activeRole || currentUser?.role || '').toLowerCase();
  const isPastorOrAdmin =
    normalizedRole.includes('pastor') ||
    normalizedRole.includes('super_admin') ||
    normalizedRole.includes('admin') ||
    normalizedRole.includes('executive');

  const isMinistryLeader =
    normalizedRole.includes('leader') ||
    normalizedRole.includes('coordinator') ||
    normalizedRole.includes('staff') ||
    isPastorOrAdmin;

  const selectedPlan = useMemo(
    () => plans.find((p) => p.id === selectedPlanId) || plans[0] || null,
    [plans, selectedPlanId]
  );

  // Fetch plans from PostgreSQL API
  const fetchPlans = async (keepSelectedId?: string) => {
    setIsLoading(true);
    try {
      const res = await apiService.getMinistryAnnualPlans(
        !filterAllMinistries && selectedMinistry ? { ministryId: selectedMinistry.id } : undefined
      );
      let loaded = res.plans || [];
      if (loaded.length === 0 && !filterAllMinistries && selectedMinistry) {
        const allRes = await apiService.getMinistryAnnualPlans();
        loaded = allRes.plans || [];
      }
      setPlans(loaded);
      if (keepSelectedId && loaded.some((p) => p.id === keepSelectedId)) {
        setSelectedPlanId(keepSelectedId);
      } else if (loaded.length > 0 && (!selectedPlanId || !loaded.some((p) => p.id === selectedPlanId))) {
        setSelectedPlanId(loaded[0].id);
      }
    } catch (err: any) {
      console.error('Failed to load ministry annual plans:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPlans();
  }, [selectedMinistry?.id, filterAllMinistries]);

  const showToast = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => setStatusMessage(null), 5000);
  };

  // ============================================================================
  // PLAN BUILDER / REVISION STATE
  // ============================================================================
  const [isEditingExisting, setIsEditingExisting] = useState<boolean>(false);
  const [formMinistryId, setFormMinistryId] = useState<string>(selectedMinistry?.id || ministries[0]?.id || 'min-01');
  const [formYear, setFormYear] = useState<number>(new Date().getFullYear());
  const [formTitle, setFormTitle] = useState<string>('');
  const [formVision, setFormVision] = useState<string>('');
  const [formResponsiblePerson, setFormResponsiblePerson] = useState<string>(currentUser?.name || 'Ministry Leader');
  const [formTargetAudience, setFormTargetAudience] = useState<string>('Congregation & Local Community');
  const [formExpectedParticipants, setFormExpectedParticipants] = useState<number>(350);
  const [formRequiredResources, setFormRequiredResources] = useState<string>(
    'Main Sanctuary, Sound & Media Equipment, Volunteer Team, Printed Discipleship Guides'
  );
  const [formOptionalBudget, setFormOptionalBudget] = useState<number>(120000);
  const [formMitigationSummary, setFormMitigationSummary] = useState<string>(
    'Cross-train backup facilitators, confirm venue reservations 30 days ahead, and track monthly expense run-rate.'
  );
  const [formExpectedOutcomesText, setFormExpectedOutcomesText] = useState<string>(
    '25% growth in active ministry engagement\n90% completion of quarterly discipleship milestones\nStronger leadership pipeline across cell groups'
  );
  const [formRevisionComment, setFormRevisionComment] = useState<string>('');

  const [formObjectives, setFormObjectives] = useState<MinistryPlanObjective[]>([
    {
      id: 'obj-1',
      title: 'Deepen Biblical Discipleship & Leadership Capacity',
      description: 'Equip ministry members and emerging leaders through structured training cohorts.',
      targetMetric: 'Train and certify 80 members across 4 quarters',
      priority: 'High',
      targetQuarter: 'All Quarters',
    },
    {
      id: 'obj-2',
      title: 'Expand Community Evangelism & Outreach Impact',
      description: 'Conduct quarterly outreach campaigns and neighborhood service initiatives.',
      targetMetric: 'Reach 400+ participants and integrate 60 new believers',
      priority: 'High',
      targetQuarter: 'All Quarters',
    },
  ]);

  const [formActivities, setFormActivities] = useState<MinistryPlanActivityItem[]>([
    {
      id: 'act-1',
      title: 'Q1 Leadership & Vision Launch Retreat',
      description: 'Full-day alignment workshop for all department coordinators and volunteers.',
      quarter: 'Q1',
      month: 'January',
      monthIndex: 1,
      responsiblePerson: currentUser?.name || 'Ministry Leader',
      targetAudience: 'Ministry Leaders & Volunteers',
      expectedParticipants: 75,
      requiredResources: 'Conference Hall, Training Manuals, Catering',
      estimatedBudget: 25000,
      status: 'Planned',
    },
    {
      id: 'act-2',
      title: 'Q2 Mid-Year Community Outreach & Evangelism Drive',
      description: 'Coordinated city-wide outreach and youth mentorship mobilization.',
      quarter: 'Q2',
      month: 'May',
      monthIndex: 5,
      responsiblePerson: currentUser?.name || 'Ministry Leader',
      targetAudience: 'Local Community & Youth',
      expectedParticipants: 180,
      requiredResources: 'PA System, Tents, Outreach Literature, Transport',
      estimatedBudget: 40000,
      status: 'Planned',
    },
    {
      id: 'act-3',
      title: 'Q3 Discipleship Intensive & Skill Workshop',
      description: 'Practical ministry workshops and small group leader equipping.',
      quarter: 'Q3',
      month: 'August',
      monthIndex: 8,
      responsiblePerson: currentUser?.name || 'Ministry Leader',
      targetAudience: 'Congregation & Cell Leaders',
      expectedParticipants: 120,
      requiredResources: 'Classrooms, Projector, Study Guides',
      estimatedBudget: 30000,
      status: 'Planned',
    },
    {
      id: 'act-4',
      title: 'Q4 Annual Harvest Thanksgiving & Impact Summit',
      description: 'Year-end celebration, testimony review, and next-year strategic transition.',
      quarter: 'Q4',
      month: 'November',
      monthIndex: 11,
      responsiblePerson: currentUser?.name || 'Ministry Leader',
      targetAudience: 'All Church Members & Guests',
      expectedParticipants: 250,
      requiredResources: 'Main Sanctuary, Media Production Team, Hospitality',
      estimatedBudget: 25000,
      status: 'Planned',
    },
  ]);

  const [formKpis, setFormKpis] = useState<MinistryPlanKpiItem[]>([
    {
      id: 'kpi-1',
      name: 'Active Ministry Participants Engaged',
      baselineValue: 180,
      targetValue: 350,
      actualValue: 0,
      weightPercentage: 50,
      unit: 'People',
      baseline: 180,
      target: 350,
      currentActual: 0,
      frequency: 'Quarterly',
    },
    {
      id: 'kpi-2',
      name: 'New Volunteers Recruited & Trained',
      baselineValue: 20,
      targetValue: 60,
      actualValue: 0,
      weightPercentage: 50,
      unit: 'Volunteers',
      baseline: 20,
      target: 60,
      currentActual: 0,
      frequency: 'Quarterly',
    },
  ]);

  const [formRisks, setFormRisks] = useState<MinistryPlanRiskItem[]>([
    {
      id: 'risk-1',
      riskDescription: 'Volunteer burnout during peak outreach seasons',
      severity: 'Medium',
      likelihood: 'Medium',
      impact: 'High',
      mitigationPlan: 'Rotate team schedules monthly and recruit assistant team leads in Q1.',
      owner: currentUser?.name || 'Ministry Leader',
    },
  ]);

  // Live preview of automatically generated Q1-Q4 milestones & 12-month timeline
  const liveGeneratedSchedule = useMemo(() => {
    return generateQuarterlyAndMonthlySchedule({
      activities: formActivities,
      objectives: formObjectives,
      optionalBudget: formOptionalBudget,
      expectedParticipants: formExpectedParticipants,
      responsiblePerson: formResponsiblePerson,
      year: formYear,
      requiredResources: formRequiredResources,
      ministryName:
        ministries.find((m) => m.id === formMinistryId)?.name ||
        selectedMinistry?.name ||
        'Ministry Department',
    });
  }, [
    formActivities,
    formObjectives,
    formOptionalBudget,
    formExpectedParticipants,
    formResponsiblePerson,
    formYear,
    formRequiredResources,
    formMinistryId,
    ministries,
    selectedMinistry,
  ]);

  const startNewPlanBuilder = () => {
    const targetMin = selectedMinistry || ministries[0];
    setIsEditingExisting(false);
    setFormMinistryId(targetMin?.id || 'min-01');
    setFormYear(new Date().getFullYear());
    setFormTitle(`${targetMin?.name || 'Ministry'} ${new Date().getFullYear()} Annual Strategic Plan`);
    setFormVision(
      `Equip, mobilize, and shepherd members through ${targetMin?.name || 'Ministry'} with measurable kingdom impact.`
    );
    setFormResponsiblePerson(currentUser?.name || 'Ministry Leader');
    setActiveSubView('builder');
  };

  const startEditOrRevisePlan = (plan: MinistryAnnualPlan) => {
    setIsEditingExisting(true);
    setFormMinistryId(plan.ministryId);
    setFormYear(plan.year);
    setFormTitle(plan.title);
    setFormVision(plan.visionStatement);
    setFormResponsiblePerson(plan.responsiblePerson);
    setFormTargetAudience(plan.targetAudience);
    setFormExpectedParticipants(plan.expectedParticipants);
    setFormRequiredResources(plan.requiredResources);
    setFormOptionalBudget(plan.optionalBudget);
    setFormMitigationSummary(plan.mitigationSummary);
    setFormExpectedOutcomesText((plan.expectedOutcomes || []).join('\n'));
    setFormObjectives(plan.objectives || []);
    setFormActivities(plan.activities || []);
    setFormKpis(plan.kpis || []);
    setFormRisks(plan.risks || []);
    setFormRevisionComment('');
    setActiveSubView('builder');
  };

  const handleSaveOrSubmitPlan = async (submitNow: boolean) => {
    setIsSubmitting(true);
    try {
      const targetMin = ministries.find((m) => m.id === formMinistryId) || selectedMinistry;
      const payload: Partial<MinistryAnnualPlan> & { submitNow?: boolean; comment?: string } = {
        ministryId: formMinistryId,
        ministryName: targetMin?.name || 'Ministry Department',
        year: Number(formYear),
        title: formTitle.trim() || `${targetMin?.name || 'Ministry'} ${formYear} Annual Plan`,
        visionStatement: formVision.trim(),
        responsiblePerson: formResponsiblePerson.trim() || currentUser?.name || 'Ministry Leader',
        targetAudience: formTargetAudience.trim(),
        expectedParticipants: Number(formExpectedParticipants) || 0,
        requiredResources: formRequiredResources.trim(),
        optionalBudget: Number(formOptionalBudget) || 0,
        currency,
        mitigationSummary: formMitigationSummary.trim(),
        expectedOutcomes: formExpectedOutcomesText
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        objectives: formObjectives,
        activities: formActivities,
        kpis: formKpis,
        risks: formRisks,
        submitNow,
        comment: formRevisionComment.trim() || undefined,
      };

      if (isEditingExisting && selectedPlan) {
        if (selectedPlan.status === 'Returned for Revision' || selectedPlan.status === 'Rejected' || submitNow) {
          const res = await apiService.reviseMinistryAnnualPlan(selectedPlan.id, payload);
          showToast('success', res.message || 'Ministry plan revised and saved to PostgreSQL.');
          await fetchPlans(res.plan.id);
        } else {
          const res = await apiService.updateMinistryAnnualPlan(selectedPlan.id, payload);
          showToast('success', res.message || 'Ministry plan updated.');
          await fetchPlans(res.plan.id);
        }
      } else {
        const res = await apiService.createMinistryAnnualPlan(payload);
        showToast('success', res.message || 'Annual ministry plan created and persisted.');
        await fetchPlans(res.plan.id);
      }
      setActiveSubView('overview');
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to save ministry annual plan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================================
  // PASTOR GOVERNANCE REVIEW STATE
  // ============================================================================
  const [pastorReviewComment, setPastorReviewComment] = useState<string>('');

  const handlePastorAction = async (
    action: 'start_review' | 'comment' | 'return' | 'approve' | 'reject' | 'activate' | 'complete'
  ) => {
    if (!selectedPlan) return;
    if ((action === 'return' || action === 'reject' || action === 'comment') && !pastorReviewComment.trim()) {
      showToast('error', 'Please enter pastoral review notes or reason before performing this action.');
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await apiService.reviewMinistryAnnualPlan(
        selectedPlan.id,
        action,
        pastorReviewComment.trim() || undefined
      );
      setPastorReviewComment('');
      showToast('success', res.message || `Workflow updated to ${res.plan.status}`);
      await fetchPlans(res.plan.id);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to execute pastoral review action.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLeaderSubmitDraft = async () => {
    if (!selectedPlan) return;
    setIsSubmitting(true);
    try {
      const res = await apiService.submitMinistryAnnualPlan(
        selectedPlan.id,
        'Annual Ministry Plan submitted by Ministry Leader for Pastoral Review.'
      );
      showToast('success', res.message || 'Plan submitted for Pastoral Review.');
      await fetchPlans(res.plan.id);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to submit plan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================================
  // QUARTERLY REPORT SUBMISSION STATE
  // ============================================================================
  const [selectedQuarter, setSelectedQuarter] = useState<MinistryQuarter>('Q1');
  const [qPlannedSummary, setQPlannedSummary] = useState<string>('');
  const [qActualSummary, setQActualSummary] = useState<string>('');
  const [qPlannedParticipants, setQPlannedParticipants] = useState<number>(100);
  const [qActualParticipants, setQActualParticipants] = useState<number>(115);
  const [qAllocatedBudget, setQAllocatedBudget] = useState<number>(30000);
  const [qActualExpense, setQActualExpense] = useState<number>(28500);
  const [qResultsSummary, setQResultsSummary] = useState<string>('');
  const [qChallenges, setQChallenges] = useState<string>('');
  const [qLessonsLearned, setQLessonsLearned] = useState<string>('');
  const [qNextQuarterAction, setQNextQuarterAction] = useState<string>('');
  const [qActivityItems, setQActivityItems] = useState<MinistryQuarterlyActivityReportItem[]>([]);
  const [qKpiItems, setQKpiItems] = useState<MinistryQuarterlyKpiReportItem[]>([]);

  // Populate quarterly report form when selectedPlan or selectedQuarter changes
  useEffect(() => {
    if (!selectedPlan) return;
    const existingQ = (selectedPlan.quarterlyReports || []).find((r) => r.quarter === selectedQuarter);
    const milestone = (selectedPlan.quarterlyMilestones || []).find((m) => m.quarter === selectedQuarter);
    const quarterActivities = (selectedPlan.activities || []).filter((a) => a.quarter === selectedQuarter);

    if (existingQ) {
      setQPlannedSummary(existingQ.plannedActivity);
      setQActualSummary(existingQ.actualActivity);
      setQPlannedParticipants(existingQ.plannedParticipants);
      setQActualParticipants(existingQ.actualParticipants);
      setQAllocatedBudget(existingQ.allocatedBudget);
      setQActualExpense(existingQ.actualExpense);
      setQResultsSummary(existingQ.results);
      setQChallenges(existingQ.challenges);
      setQLessonsLearned(existingQ.lessonsLearned);
      setQNextQuarterAction(existingQ.nextQuarterAction);
      setQActivityItems([]);
      setQKpiItems((existingQ.kpiPerformance || []) as any);
    } else {
      const plannedNames = quarterActivities.map((a) => a.title).join('; ');
      setQPlannedSummary(
        plannedNames || milestone?.keyDeliverables?.join('; ') || `${selectedQuarter} Planned Ministry Operations`
      );
      setQActualSummary(
        plannedNames
          ? `Successfully executed ${quarterActivities.length} planned ${selectedQuarter} ministry activities.`
          : `Completed ${selectedQuarter} scheduled outreach and discipleship programs.`
      );
      const pPart =
        milestone?.expectedParticipants ||
        Math.round((selectedPlan.expectedParticipants || 200) / 4);
      setQPlannedParticipants(pPart);
      setQActualParticipants(pPart);
      const alloc =
        milestone?.allocatedBudget || Math.round((selectedPlan.optionalBudget || 0) / 4);
      setQAllocatedBudget(alloc);
      setQActualExpense(alloc);
      setQResultsSummary(
        `Strong member participation and spiritual growth achieved across ${selectedQuarter} programs.`
      );
      setQChallenges('Scheduling coordination across multiple volunteer teams.');
      setQLessonsLearned('Early communication 3 weeks prior to major events increases attendance by 20%.');
      setQNextQuarterAction('Follow up with new visitors and prepare volunteer roster for next quarter.');

      setQActivityItems(
        quarterActivities.map((a) => ({
          activityId: a.id,
          plannedActivity: a.title,
          actualActivity: `Completed: ${a.title}`,
          completionRate: 100,
          plannedParticipants: a.expectedParticipants,
          actualParticipants: a.expectedParticipants,
          results: 'Target attendance and ministry objectives met.',
        }))
      );

      setQKpiItems(
        (selectedPlan.kpis || []).map((k) => ({
          kpiId: k.id,
          kpiName: k.name,
          unit: k.unit,
          target: Math.round((k.targetValue ?? k.target ?? 0) / 4) || (k.targetValue ?? k.target ?? 0),
          actual: Math.round((k.targetValue ?? k.target ?? 0) / 4) || (k.targetValue ?? k.target ?? 0),
          achievementRate: 100,
          varianceNote: 'On track with quarterly target',
        }))
      );
    }
  }, [selectedPlan?.id, selectedQuarter]);

  const handleSubmitQuarterlyReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan) return;
    setIsSubmitting(true);
    try {
      const res = await apiService.submitMinistryQuarterlyReport(selectedPlan.id, {
        quarter: selectedQuarter,
        plannedActivity: qPlannedSummary,
        actualActivity: qActualSummary,
        
        plannedParticipants: Number(qPlannedParticipants) || 0,
        actualParticipants: Number(qActualParticipants) || 0,
        kpiPerformance: qKpiItems.map((k) => ({
          kpiId: k.kpiId || k.id || '',
          kpiName: k.kpiName || k.name || '',
          unit: k.unit || '',
          quarterlyTarget: Number(k.quarterlyTarget ?? k.target ?? 0),
          actualAchieved: Number(k.actualAchieved ?? k.actual ?? k.currentActual ?? 0),
          achievementRate: Number(k.achievementRate || 0),
          remarks: k.remarks || k.varianceNote || '',
        })),
        challenges: qChallenges,
        allocatedBudget: Number(qAllocatedBudget) || 0,
        actualExpense: Number(qActualExpense) || 0,
        lessonsLearned: qLessonsLearned,
        nextQuarterAction: qNextQuarterAction,
        status: 'Submitted',
      });
      showToast('success', res.message || `${selectedQuarter} Report submitted and aggregated into Annual Report.`);
      await fetchPlans(res.plan.id);
    } catch (err: any) {
      showToast('error', err?.message || `Failed to submit ${selectedQuarter} report.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================================
  // ANNUAL REPORT SUBMISSION STATE
  // ============================================================================
  const liveAggregatedAnnual = useMemo(() => {
    if (!selectedPlan) return null;
    return aggregateQuarterlyReportsIntoAnnualReport(selectedPlan, selectedPlan.annualReport);
  }, [selectedPlan]);

  const [annualExecSummary, setAnnualExecSummary] = useState<string>('');
  const [annualAchievementsText, setAnnualAchievementsText] = useState<string>('');
  const [annualRecommendationsText, setAnnualRecommendationsText] = useState<string>('');
  const [markPlanCompletedOnSubmit, setMarkPlanCompletedOnSubmit] = useState<boolean>(false);

  useEffect(() => {
    if (!liveAggregatedAnnual) return;
    setAnnualExecSummary(liveAggregatedAnnual.executiveSummary || '');
    const achievements = Array.isArray(liveAggregatedAnnual.keyAchievements)
      ? (liveAggregatedAnnual.keyAchievements as any).join('\n')
      : String(liveAggregatedAnnual.keyAchievements || '');
    setAnnualAchievementsText(achievements);
    const recs = Array.isArray(liveAggregatedAnnual.strategicRecommendationsNextYear)
      ? (liveAggregatedAnnual.strategicRecommendationsNextYear as any).join('\n')
      : String(liveAggregatedAnnual.strategicRecommendationsNextYear || '');
    setAnnualRecommendationsText(recs);
  }, [liveAggregatedAnnual?.id, selectedPlan?.id]);

  const handleSubmitAnnualReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan) return;
    setIsSubmitting(true);
    try {
      const res = await apiService.submitMinistryAnnualReport(selectedPlan.id, {
        executiveSummary: annualExecSummary,
        keyAchievements: annualAchievementsText
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        strategicRecommendationsNextYear: annualRecommendationsText
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        status: 'Submitted',
        markPlanCompleted: markPlanCompletedOnSubmit,
      });
      showToast('success', res.message || 'Annual Ministry Report submitted and persisted to PostgreSQL.');
      await fetchPlans(res.plan.id);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to submit Annual Report.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================================
  // REAL PDF & EXCEL/XLSX EXPORT HANDLERS
  // ============================================================================
  const handleExportPdf = (scope: 'full' | 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'annual' = 'full') => {
    if (!selectedPlan) return;
    try {
      downloadMinistryPlanPdf(selectedPlan, scope);
      showToast('success', `Generated real PDF report (${scope.toUpperCase()}) for ${selectedPlan.planCode}.`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to generate PDF report.');
    }
  };

  const handleExportXlsx = () => {
    if (!selectedPlan) return;
    try {
      downloadMinistryPlanXlsx(selectedPlan);
      showToast('success', `Generated multi-sheet Excel (.xlsx) workbook for ${selectedPlan.planCode}.`);
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to generate Excel workbook.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Status Banner */}
      {statusMessage && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-3 text-sm font-semibold">
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-xs opacity-75 hover:opacity-100 underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Header Bar: Plan Selector, Role Filter & Export Actions */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 text-xs font-bold uppercase tracking-wider">
              PostgreSQL Workflow Engine
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {isPastorOrAdmin ? 'PASTOR / GOVERNANCE REVIEW MODE' : 'MINISTRY LEADER MODE'}
            </span>
          </div>
          <h3 className="text-xl font-bold text-white">
            Ministry Annual Planning, Milestones & Quarterly/Annual Reporting
          </h3>
          <p className="text-xs text-slate-400">
            End-to-end annual planning workflow: Draft → Submitted → Under Review → Returned for Revision → Approved → Active → Completed
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <label className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 px-3 py-2 rounded-xl border border-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={filterAllMinistries}
              onChange={(e) => setFilterAllMinistries(e.target.checked)}
              className="rounded border-slate-600 text-indigo-500 focus:ring-indigo-500"
            />
            <span>Show All Ministries ({plans.length})</span>
          </label>

          <button
            onClick={startNewPlanBuilder}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-indigo-600/20"
          >
            <Plus className="w-4 h-4" /> New Annual Plan
          </button>

          {selectedPlan && (
            <>
              <button
                onClick={() => handleExportPdf('full')}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold transition"
                title="Download Real PDF Report"
              >
                <FileText className="w-4 h-4" /> Export PDF
              </button>
              <button
                onClick={handleExportXlsx}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold transition"
                title="Download Multi-Sheet Excel (.xlsx) Workbook"
              >
                <FileSpreadsheet className="w-4 h-4" /> Export Excel (.XLSX)
              </button>
            </>
          )}
        </div>
      </div>

      {/* Plan Switcher Pills + Workflow Stepper */}
      {plans.length > 0 && activeSubView !== 'builder' && (
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {plans.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPlanId(p.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition flex items-center gap-2 ${
                    selectedPlan?.id === p.id
                      ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-sm'
                      : 'bg-slate-800/60 border-slate-700/70 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="font-mono text-[11px] text-indigo-400">{p.planCode}</span>
                  <span>{p.ministryName} ({p.year})</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] border ${
                      STATUS_BADGE_STYLES[p.status] || STATUS_BADGE_STYLES.Draft
                    }`}
                  >
                    {p.status}
                  </span>
                </button>
              ))}
            </div>

            {selectedPlan && (
              <div className="flex items-center gap-2">
                {selectedPlan.status === 'Draft' && isMinistryLeader && (
                  <button
                    onClick={handleLeaderSubmitDraft}
                    disabled={isSubmitting}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition"
                  >
                    <Send className="w-3.5 h-3.5" /> Submit Plan to Pastor
                  </button>
                )}
                {(selectedPlan.status === 'Draft' ||
                  selectedPlan.status === 'Returned for Revision' ||
                  selectedPlan.status === 'Rejected') &&
                  isMinistryLeader && (
                    <button
                      onClick={() => startEditOrRevisePlan(selectedPlan)}
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      {selectedPlan.status === 'Returned for Revision'
                        ? 'Revise Returned Plan'
                        : 'Edit Plan'}
                    </button>
                  )}
              </div>
            )}
          </div>

          {/* Workflow Pipeline Visualizer */}
          {selectedPlan && (
            <div className="pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                <span className="font-semibold uppercase tracking-wider text-slate-300">
                  Governance Workflow State Machine (Revision #{selectedPlan.revisionNumber})
                </span>
                <span>
                  Last Updated: {new Date(selectedPlan.updatedAt).toLocaleString()}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                {WORKFLOW_STEPS.map((step, idx) => {
                  const currentIdx = WORKFLOW_STEPS.indexOf(selectedPlan.status);
                  const isCurrent = selectedPlan.status === step;
                  const isPassed =
                    currentIdx > idx &&
                    selectedPlan.status !== 'Returned for Revision' &&
                    selectedPlan.status !== 'Rejected';

                  return (
                    <div
                      key={step}
                      className={`px-3 py-2 rounded-xl border text-xs flex items-center gap-2 ${
                        isCurrent
                          ? 'bg-indigo-600/25 border-indigo-500 text-white font-bold'
                          : isPassed
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300 font-medium'
                          : 'bg-slate-800/40 border-slate-800 text-slate-500'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                          isCurrent
                            ? 'bg-indigo-500 text-white'
                            : isPassed
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {isPassed ? <Check className="w-3 h-3" /> : idx + 1}
                      </div>
                      <span className="truncate">{step}</span>
                    </div>
                  );
                })}
              </div>

              {selectedPlan.returnedReason && selectedPlan.status === 'Returned for Revision' && (
                <div className="mt-3 p-3.5 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-200 text-xs flex items-start justify-between gap-4">
                  <div>
                    <span className="font-bold uppercase tracking-wider text-orange-400 block mb-0.5">
                      Pastor Returned Plan for Revision:
                    </span>
                    {selectedPlan.returnedReason}
                  </div>
                  <button
                    onClick={() => startEditOrRevisePlan(selectedPlan)}
                    className="px-3 py-1.5 bg-orange-500 hover:bg-orange-400 text-slate-950 font-bold rounded-lg shrink-0"
                  >
                    Revise & Resubmit Now
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Internal Sub-Navigation Tabs */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
            {[
              { id: 'overview', label: '1. Annual Plan Details & KPIs', icon: Target },
              { id: 'timeline', label: '2. Auto-Generated Q1–Q4 & Monthly Timeline', icon: Calendar },
              {
                id: 'pastor_review',
                label: `3. Pastor Review & Audit Trail (${(selectedPlan?.reviewHistory || []).length})`,
                icon: ShieldCheck,
              },
              {
                id: 'quarterly_reports',
                label: `4. Quarterly Reports (${(selectedPlan?.quarterlyReports || []).length}/4)`,
                icon: ClipboardCheck,
              },
              {
                id: 'annual_report',
                label: '5. Aggregated Annual Report & Exports',
                icon: Award,
              },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubView(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
                    activeSubView === tab.id
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'bg-slate-800/70 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* VIEW 1: PLAN OVERVIEW (Objectives, Activities, KPIs, Risks, Resources) */}
      {/* ==================================================================== */}
      {selectedPlan && activeSubView === 'overview' && (
        <div className="space-y-6">
          {/* Executive Metadata Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Ministry & Responsible Leader
              </span>
              <p className="text-base font-bold text-white mt-1">{selectedPlan.ministryName}</p>
              <p className="text-xs text-indigo-400 mt-0.5">
                Leader: {selectedPlan.responsiblePerson}
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Target Audience & Reach
              </span>
              <p className="text-base font-bold text-white mt-1">
                {selectedPlan.expectedParticipants.toLocaleString()} Expected Participants
              </p>
              <p className="text-xs text-slate-400 mt-0.5 truncate" title={selectedPlan.targetAudience}>
                Audience: {selectedPlan.targetAudience}
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Annual Optional Budget
              </span>
              <p className="text-base font-bold text-emerald-400 mt-1">
                {selectedPlan.currency || currency} {(selectedPlan.optionalBudget || 0).toLocaleString()}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                {(selectedPlan.activities || []).length} Planned Activities Across Q1–Q4
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Required Resources
              </span>
              <p className="text-xs text-slate-200 mt-1 line-clamp-2" title={selectedPlan.requiredResources}>
                {selectedPlan.requiredResources || 'Standard Ministry Facilities & Volunteer Teams'}
              </p>
            </div>
          </div>

          {/* Vision Statement & Expected Outcomes */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div>
                <h4 className="text-sm font-bold uppercase tracking-wider text-indigo-400">
                  Annual Plan Title & Strategic Vision ({selectedPlan.year})
                </h4>
                <h5 className="text-lg font-bold text-white mt-1">{selectedPlan.title}</h5>
                <p className="text-sm text-slate-300 mt-1 leading-relaxed">
                  {selectedPlan.visionStatement}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Strategic Objectives ({(selectedPlan.objectives || []).length})
                </h5>
                <div className="space-y-2.5">
                  {(selectedPlan.objectives || []).map((obj, idx) => (
                    <div
                      key={obj.id || idx}
                      className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-start justify-between gap-4"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-indigo-400">
                            OBJ-{idx + 1}
                          </span>
                          <span className="text-sm font-bold text-white">{obj.title}</span>
                        </div>
                        <p className="text-xs text-slate-300 mt-1">{obj.description}</p>
                        <p className="text-xs text-emerald-400 mt-1 font-medium">
                          Target Metric: {obj.targetMetric}
                        </p>
                      </div>
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {obj.priority}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-emerald-400">
                Expected Outcomes & Deliverables
              </h4>
              <ul className="space-y-2.5">
                {(selectedPlan.expectedOutcomes || []).map((outcome, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2.5 text-xs text-slate-200 bg-slate-800/40 p-3 rounded-xl border border-slate-800"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{outcome}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-3 border-t border-slate-800">
                <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
                  Risk Mitigation Strategy
                </h5>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-800/40 p-3 rounded-xl border border-slate-800">
                  {selectedPlan.mitigationSummary}
                </p>
              </div>
            </div>
          </div>

          {/* Planned Activities Table */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4">
              Planned Ministry Activities ({(selectedPlan.activities || []).length})
            </h4>
            <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-800">
              <table className="cmms-data-table w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase">
                    <th className="py-2.5 px-3 whitespace-nowrap">Qtr / Month</th>
                    <th className="py-2.5 px-3 min-w-[200px]">Activity & Description</th>
                    <th className="py-2.5 px-3 whitespace-nowrap">Responsible</th>
                    <th className="py-2.5 px-3 whitespace-nowrap">Target Audience</th>
                    <th className="py-2.5 px-3 whitespace-nowrap">Expected Reach</th>
                    <th className="py-2.5 px-3 min-w-[160px]">Required Resources</th>
                    <th className="py-2.5 px-3 text-right whitespace-nowrap">Budget</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {(selectedPlan.activities || []).map((act) => (
                    <tr key={act.id} className="hover:bg-slate-800/30">
                      <td className="py-3 px-3 font-mono font-bold text-indigo-400 whitespace-nowrap tabular-nums">
                        {act.quarter} • {act.month}
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-white">{act.title}</div>
                        <div className="text-slate-400 text-[11px]">{act.description}</div>
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">{act.responsiblePerson}</td>
                      <td className="py-3 px-3 whitespace-nowrap">{act.targetAudience}</td>
                      <td className="py-3 px-3 font-semibold whitespace-nowrap tabular-nums">{act.expectedParticipants}</td>
                      <td className="py-3 px-3 text-slate-300">{act.requiredResources}</td>
                      <td className="py-3 px-3 text-right font-mono text-emerald-400 whitespace-nowrap tabular-nums">
                        {selectedPlan.currency || currency} {(act.estimatedBudget || 0).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* KPIs & Risk Register */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
              <h4 className="text-sm font-bold uppercase tracking-wider text-indigo-400 mb-3">
                Key Performance Indicators (KPIs)
              </h4>
              <div className="space-y-2.5">
                {(selectedPlan.kpis || []).map((kpi) => {
                  const pct =
                    kpi.target > 0 ? Math.min(100, Math.round((kpi.currentActual / kpi.target) * 100)) : 0;
                  return (
                    <div
                      key={kpi.id}
                      className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{kpi.name}</span>
                        <span className="text-xs font-mono text-emerald-400">
                          Baseline: {kpi.baseline} → Target: {kpi.target} {kpi.unit} ({kpi.frequency})
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 rounded-full transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
              <h4 className="text-sm font-bold uppercase tracking-wider text-amber-400 mb-3">
                Risk Register & Mitigation Matrix
              </h4>
              <div className="space-y-2.5">
                {(selectedPlan.risks || []).map((r) => (
                  <div
                    key={r.id}
                    className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-white">{r.riskDescription}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                        Impact: {r.impact} | Likelihood: {r.likelihood}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300">
                      <strong className="text-emerald-400">Mitigation:</strong> {r.mitigationPlan}
                    </p>
                    <p className="text-[11px] text-slate-400">Owner: {r.owner}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* VIEW 2: AUTO-GENERATED Q1-Q4 MILESTONES & 12-MONTH TIMELINE          */}
      {/* ==================================================================== */}
      {selectedPlan && activeSubView === 'timeline' && (
        <div className="space-y-6">
          {/* Q1 - Q4 Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {(selectedPlan.quarterlyMilestones || []).map((qm) => (
              <div
                key={qm.quarter}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-extrabold">
                      {qm.quarter}
                    </span>
                    <span className="text-xs font-mono text-emerald-400 font-bold">
                      {selectedPlan.currency || currency} {(qm.allocatedBudget || 0).toLocaleString()}
                    </span>
                  </div>
                  <h5 className="text-sm font-bold text-white">{qm.title}</h5>
                  <p className="text-xs text-slate-400">
                    Target Reach: <strong className="text-slate-200">{qm.expectedParticipants}</strong> participants
                  </p>
                  <div className="pt-2 border-t border-slate-800/80">
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block mb-1.5">
                      Key Quarterly Deliverables
                    </span>
                    <ul className="space-y-1 text-xs text-slate-300">
                      {(qm.keyDeliverables || []).map((deliv, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <ChevronRight className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                          <span>{deliv}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Status: {qm.status}</span>
                  <button
                    onClick={() => {
                      setSelectedQuarter(qm.quarter);
                      setActiveSubView('quarterly_reports');
                    }}
                    className="text-xs font-bold text-indigo-400 hover:text-indigo-300"
                  >
                    Open {qm.quarter} Report →
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* 12-Month Timeline Grid */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4">
              Automatically Generated 12-Month Operational Timeline ({selectedPlan.year})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {(selectedPlan.monthlyActivities || []).map((m) => (
                <div
                  key={m.monthIndex}
                  className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">
                      {m.monthIndex}. {m.month}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-indigo-400 font-mono text-[10px] font-bold">
                      {m.quarter}
                    </span>
                  </div>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {(m.activities || []).map((act, i) => (
                      <li key={i} className="truncate" title={act}>
                        • {act}
                      </li>
                    ))}
                  </ul>
                  <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Reach: {m.expectedParticipants}</span>
                    <span className="font-mono text-emerald-400">
                      {selectedPlan.currency || currency} {(m.allocatedBudget || 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* VIEW 3: PASTOR GOVERNANCE REVIEW & AUDIT HISTORY                     */}
      {/* ==================================================================== */}
      {selectedPlan && activeSubView === 'pastor_review' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pastor Action Console */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
              <h4 className="text-sm font-bold uppercase tracking-wider">
                Pastor Governance Decision Console
              </h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Pastors can review, comment, return for revision, approve, or reject submitted annual ministry plans. Every action is recorded in PostgreSQL and the immutable Audit Trail.
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Pastoral Review Notes / Feedback / Return Reason
              </label>
              <textarea
                rows={4}
                value={pastorReviewComment}
                onChange={(e) => setPastorReviewComment(e.target.value)}
                placeholder="Enter pastoral feedback, directives, or revision instructions..."
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            {isPastorOrAdmin ? (
              <div className="grid grid-cols-2 gap-2.5 pt-2">
                <button
                  onClick={() => handlePastorAction('start_review')}
                  disabled={isSubmitting}
                  className="px-3 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-bold transition"
                >
                  Mark Under Review
                </button>
                <button
                  onClick={() => handlePastorAction('comment')}
                  disabled={isSubmitting}
                  className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold transition"
                >
                  Post Comment
                </button>
                <button
                  onClick={() => handlePastorAction('return')}
                  disabled={isSubmitting}
                  className="px-3 py-2.5 rounded-xl bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 text-orange-300 text-xs font-bold transition"
                >
                  Return for Revision
                </button>
                <button
                  onClick={() => handlePastorAction('reject')}
                  disabled={isSubmitting}
                  className="px-3 py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold transition"
                >
                  Reject Plan
                </button>
                <button
                  onClick={() => handlePastorAction('approve')}
                  disabled={isSubmitting}
                  className="col-span-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-lg shadow-emerald-600/20"
                >
                  Approve Annual Ministry Plan
                </button>
                {(selectedPlan.status === 'Approved' || selectedPlan.status === 'Active') && (
                  <>
                    <button
                      onClick={() => handlePastorAction('activate')}
                      disabled={isSubmitting}
                      className="px-3 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-bold transition"
                    >
                      Set Active
                    </button>
                    <button
                      onClick={() => handlePastorAction('complete')}
                      disabled={isSubmitting}
                      className="px-3 py-2 rounded-xl bg-teal-600/20 hover:bg-teal-600/30 border border-teal-500/40 text-teal-300 text-xs font-bold transition"
                    >
                      Mark Year Completed
                    </button>
                  </>
                )}
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 text-xs text-slate-300">
                You are currently signed in with a Ministry Leader role. Pastoral approval buttons are reserved for Pastors, Church Admins, or Super Admins.
              </div>
            )}
          </div>

          {/* Review & Audit History Log */}
          <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Immutable Workflow Review & Audit History ({(selectedPlan.reviewHistory || []).length})
            </h4>
            {(selectedPlan.reviewHistory || []).length === 0 ? (
              <p className="text-xs text-slate-400">No review actions recorded yet for this plan.</p>
            ) : (
              <div className="space-y-3">
                {(selectedPlan.reviewHistory || []).map((rev) => (
                  <div
                    key={rev.id}
                    className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/70 space-y-1.5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{rev.reviewerName}</span>
                        <span className="text-[11px] text-indigo-400 font-mono">({rev.reviewerRole})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-300 text-[10px] font-mono">
                          {rev.action}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {new Date(rev.createdAt).toLocaleString()}
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-200 leading-relaxed">{rev.comment}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* VIEW 4: QUARTERLY EXECUTION REPORTS (Q1, Q2, Q3, Q4)                 */}
      {/* ==================================================================== */}
      {selectedPlan && activeSubView === 'quarterly_reports' && (
        <div className="space-y-6">
          {/* Quarter Selector Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center gap-2">
              {(['Q1', 'Q2', 'Q3', 'Q4'] as MinistryQuarter[]).map((q) => {
                const submitted = (selectedPlan.quarterlyReports || []).find((r) => r.quarter === q);
                return (
                  <button
                    key={q}
                    onClick={() => setSelectedQuarter(q)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition flex items-center gap-2 ${
                      selectedQuarter === q
                        ? 'bg-indigo-600 text-white border-indigo-500'
                        : 'bg-slate-800/70 text-slate-300 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <span>{q} Report</span>
                    {submitted ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => handleExportPdf(selectedQuarter)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold transition"
            >
              <FileText className="w-4 h-4" /> Export {selectedQuarter} PDF
            </button>
          </div>

          <form onSubmit={handleSubmitQuarterlyReport} className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h4 className="text-base font-bold text-white">
                  {selectedQuarter} Ministry Execution Report — {selectedPlan.ministryName} ({selectedPlan.year})
                </h4>
                <p className="text-xs text-slate-400">
                  Record planned vs actual activities, participants, KPI performance, challenges, budget monitoring, lessons learned, and next-quarter action plan.
                </p>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-600/20"
              >
                {isSubmitting ? 'Saving...' : `Submit ${selectedQuarter} Report`}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Planned Activities ({selectedQuarter})
                </label>
                <textarea
                  rows={3}
                  value={qPlannedSummary}
                  onChange={(e) => setQPlannedSummary(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Actual Activities Executed ({selectedQuarter})
                </label>
                <textarea
                  rows={3}
                  value={qActualSummary}
                  onChange={(e) => setQActualSummary(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  required
                />
              </div>
            </div>

            {/* Participants & Budget Monitoring */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Planned Participants
                </label>
                <input
                  type="number"
                  value={qPlannedParticipants}
                  onChange={(e) => setQPlannedParticipants(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Actual Participants Reached
                </label>
                <input
                  type="number"
                  value={qActualParticipants}
                  onChange={(e) => setQActualParticipants(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Allocated Quarter Budget ({selectedPlan.currency || currency})
                </label>
                <input
                  type="number"
                  value={qAllocatedBudget}
                  onChange={(e) => setQAllocatedBudget(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Actual Quarter Expense ({selectedPlan.currency || currency})
                </label>
                <input
                  type="number"
                  value={qActualExpense}
                  onChange={(e) => setQActualExpense(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            {/* KPI Performance Tracking */}
            {qKpiItems.length > 0 && (
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-indigo-400">
                  {selectedQuarter} KPI Performance Evaluation
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {qKpiItems.map((k, idx) => (
                    <div
                      key={k.kpiId || idx}
                      className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/70 flex items-center justify-between gap-3"
                    >
                      <div>
                        <div className="text-xs font-bold text-white">{k.kpiName}</div>
                        <div className="text-[11px] text-slate-400">
                          Quarter Target: {k.target} {k.unit}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-400">Actual:</span>
                        <input
                          type="number"
                          value={k.actual}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setQKpiItems((prev) =>
                              prev.map((item, i) =>
                                i === idx
                                  ? {
                                      ...item,
                                      actual: val,
                                      achievementRate:
                                        item.target > 0 ? Math.round((val / item.target) * 100) : 100,
                                    }
                                  : item
                              )
                            );
                          }}
                          className="w-24 rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-xs text-white font-mono"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Results, Challenges, Lessons Learned & Next-Quarter Action */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Results & Impact Achieved
                </label>
                <textarea
                  rows={2}
                  value={qResultsSummary}
                  onChange={(e) => setQResultsSummary(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Challenges Encountered
                </label>
                <textarea
                  rows={2}
                  value={qChallenges}
                  onChange={(e) => setQChallenges(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Lessons Learned
                </label>
                <textarea
                  rows={2}
                  value={qLessonsLearned}
                  onChange={(e) => setQLessonsLearned(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Next-Quarter Action Plan
                </label>
                <textarea
                  rows={2}
                  value={qNextQuarterAction}
                  onChange={(e) => setQNextQuarterAction(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                  required
                />
              </div>
            </div>
          </form>
        </div>
      )}

      {/* ==================================================================== */}
      {/* VIEW 5: AGGREGATED ANNUAL REPORT & REAL PDF / XLSX EXPORTS           */}
      {/* ==================================================================== */}
      {selectedPlan && activeSubView === 'annual_report' && liveAggregatedAnnual && (
        <div className="space-y-6">
          {/* Aggregated KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Quarters Reported
              </span>
              <p className="text-xl font-extrabold text-white mt-1">
                {liveAggregatedAnnual.quartersIncluded.length} / 4 Quarters
              </p>
              <p className="text-xs text-indigo-400 mt-0.5">
                Activity Completion: {liveAggregatedAnnual.participantAchievementRate}%
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Aggregated Annual Participants
              </span>
              <p className="text-xl font-extrabold text-emerald-400 mt-1">
                {liveAggregatedAnnual.totalActualParticipants.toLocaleString()} Reached
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                Planned: {liveAggregatedAnnual.totalExpectedParticipants.toLocaleString()} ({liveAggregatedAnnual.participantAchievementRate}%)
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Aggregated Annual Budget vs Expense
              </span>
              <p className="text-xl font-extrabold text-white mt-1">
                {selectedPlan.currency || currency} {liveAggregatedAnnual.totalActualExpense.toLocaleString()}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                Budget: {selectedPlan.currency || currency} {liveAggregatedAnnual.totalAllocatedBudget.toLocaleString()} ({liveAggregatedAnnual.budgetUtilizationRate}%)
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Download Official Reports
              </span>
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={() => handleExportPdf('annual')}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold"
                >
                  <FileText className="w-3.5 h-3.5" /> PDF
                </button>
                <button
                  onClick={handleExportXlsx}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" /> XLSX
                </button>
              </div>
            </div>
          </div>

          {/* Quarterly Rollup Table */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4">
              Quarterly Results Rollup (Q1–Q4 Automatic Aggregation)
            </h4>
            <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-800">
              <table className="cmms-data-table w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase">
                    <th className="py-2.5 px-3 whitespace-nowrap">Quarter</th>
                    <th className="py-2.5 px-3 whitespace-nowrap">Planned vs Actual Reach</th>
                    <th className="py-2.5 px-3 whitespace-nowrap">Allocated vs Actual Expense</th>
                    <th className="py-2.5 px-3 min-w-[200px]">Key Results</th>
                    <th className="py-2.5 px-3 whitespace-nowrap">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {(['Q1', 'Q2', 'Q3', 'Q4'] as MinistryQuarter[]).map((q) => {
                    const rep = (selectedPlan.quarterlyReports || []).find((r) => r.quarter === q);
                    return (
                      <tr key={q} className="hover:bg-slate-800/30">
                        <td className="py-3 px-3 font-mono font-bold text-indigo-400 whitespace-nowrap tabular-nums">{q}</td>
                        <td className="py-3 px-3 whitespace-nowrap tabular-nums">
                          {rep
                            ? `${rep.actualParticipants} / ${rep.plannedParticipants} participants`
                            : 'Not yet reported'}
                        </td>
                        <td className="py-3 px-3 font-mono whitespace-nowrap tabular-nums">
                          {rep
                            ? `${selectedPlan.currency || currency} ${rep.actualExpense.toLocaleString()} / ${rep.allocatedBudget.toLocaleString()}`
                            : '—'}
                        </td>
                        <td className="py-3 px-3 text-slate-300">
                          {rep?.results || 'Pending quarterly submission'}
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold whitespace-nowrap ${
                              rep
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {rep ? rep.status : 'Pending'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Submit Final Annual Report Form */}
          <form
            onSubmit={handleSubmitAnnualReport}
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h4 className="text-base font-bold text-white">
                  Finalize & Submit Annual Ministry Impact Report ({selectedPlan.year})
                </h4>
                <p className="text-xs text-slate-400">
                  Aggregates Q1–Q4 results with executive commentary and strategic recommendations for next year.
                </p>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-indigo-600/20"
              >
                {isSubmitting ? 'Submitting...' : 'Submit Annual Report'}
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Executive Summary
              </label>
              <textarea
                rows={3}
                value={annualExecSummary}
                onChange={(e) => setAnnualExecSummary(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Key Annual Achievements (one per line)
                </label>
                <textarea
                  rows={4}
                  value={annualAchievementsText}
                  onChange={(e) => setAnnualAchievementsText(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Strategic Recommendations for Next Year (one per line)
                </label>
                <textarea
                  rows={4}
                  value={annualRecommendationsText}
                  onChange={(e) => setAnnualRecommendationsText(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-2">
              <input
                type="checkbox"
                checked={markPlanCompletedOnSubmit}
                onChange={(e) => setMarkPlanCompletedOnSubmit(e.target.checked)}
                className="rounded border-slate-700 text-indigo-500"
              />
              <span>Transition Annual Plan workflow status to "Completed" upon submission</span>
            </label>
          </form>
        </div>
      )}

      {/* ==================================================================== */}
      {/* VIEW 6: PLAN BUILDER / REVISION WIZARD                               */}
      {/* ==================================================================== */}
      {activeSubView === 'builder' && (
        <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h4 className="text-lg font-bold text-white">
                {isEditingExisting ? 'Revise / Edit Annual Ministry Plan' : 'Create Annual Ministry Plan'}
              </h4>
              <p className="text-xs text-slate-400">
                Automatically generates Q1, Q2, Q3, Q4 milestones and a 12-month timeline from your planned activities and budget.
              </p>
            </div>
            <button
              onClick={() => setActiveSubView('overview')}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700"
            >
              Cancel
            </button>
          </div>

          {/* Core Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Ministry</label>
              <select
                value={formMinistryId}
                onChange={(e) => setFormMinistryId(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              >
                {ministries.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Planning Year</label>
              <input
                type="number"
                value={formYear}
                onChange={(e) => setFormYear(Number(e.target.value))}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Responsible Person</label>
              <input
                type="text"
                value={formResponsiblePerson}
                onChange={(e) => setFormResponsiblePerson(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-300 mb-1">Annual Plan Title</label>
              <input
                type="text"
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Optional Annual Budget ({currency})
              </label>
              <input
                type="number"
                value={formOptionalBudget}
                onChange={(e) => setFormOptionalBudget(Number(e.target.value))}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Target Audience</label>
              <input
                type="text"
                value={formTargetAudience}
                onChange={(e) => setFormTargetAudience(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Expected Participants</label>
              <input
                type="number"
                value={formExpectedParticipants}
                onChange={(e) => setFormExpectedParticipants(Number(e.target.value))}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Required Resources</label>
              <input
                type="text"
                value={formRequiredResources}
                onChange={(e) => setFormRequiredResources(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Vision Statement</label>
              <textarea
                rows={2}
                value={formVision}
                onChange={(e) => setFormVision(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Expected Outcomes (one per line)
              </label>
              <textarea
                rows={2}
                value={formExpectedOutcomesText}
                onChange={(e) => setFormExpectedOutcomesText(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          {/* Dynamic Activities Builder */}
          <div className="space-y-3 pt-3 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <h5 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                Planned Activities (Drives Automatic Q1–Q4 & Monthly Generation)
              </h5>
              <button
                type="button"
                onClick={() =>
                  setFormActivities((prev) => [
                    ...prev,
                    {
                      id: `act-${Date.now()}`,
                      title: 'New Ministry Activity',
                      description: 'Scheduled program activity',
                      quarter: 'Q1',
                      month: 'March',
                      monthIndex: 3,
                      responsiblePerson: formResponsiblePerson,
                      targetAudience: formTargetAudience,
                      expectedParticipants: 80,
                      requiredResources: 'Standard Ministry Equipment',
                      estimatedBudget: 15000,
                      status: 'Planned',
                    },
                  ])
                }
                className="px-3 py-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 text-xs font-bold hover:bg-indigo-500/30"
              >
                + Add Activity
              </button>
            </div>

            <div className="space-y-2">
              {formActivities.map((act, idx) => (
                <div
                  key={act.id}
                  className="grid grid-cols-1 md:grid-cols-6 gap-2 p-3 rounded-xl bg-slate-800/40 border border-slate-700/60 items-center"
                >
                  <input
                    type="text"
                    value={act.title}
                    onChange={(e) =>
                      setFormActivities((prev) =>
                        prev.map((a, i) => (i === idx ? { ...a, title: e.target.value } : a))
                      )
                    }
                    placeholder="Activity Title"
                    className="md:col-span-2 rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-xs text-white"
                  />
                  <select
                    value={act.month}
                    onChange={(e) => {
                      const mName = e.target.value;
                      const mIdx = MONTH_OPTIONS.indexOf(mName) + 1;
                      const q: MinistryQuarter =
                        mIdx <= 3 ? 'Q1' : mIdx <= 6 ? 'Q2' : mIdx <= 9 ? 'Q3' : 'Q4';
                      setFormActivities((prev) =>
                        prev.map((a, i) =>
                          i === idx ? { ...a, month: mName, monthIndex: mIdx, quarter: q } : a
                        )
                      );
                    }}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-xs text-white"
                  >
                    {MONTH_OPTIONS.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={act.expectedParticipants}
                    onChange={(e) =>
                      setFormActivities((prev) =>
                        prev.map((a, i) =>
                          i === idx ? { ...a, expectedParticipants: Number(e.target.value) } : a
                        )
                      )
                    }
                    placeholder="Participants"
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-xs text-white"
                  />
                  <input
                    type="number"
                    value={act.estimatedBudget}
                    onChange={(e) =>
                      setFormActivities((prev) =>
                        prev.map((a, i) =>
                          i === idx ? { ...a, estimatedBudget: Number(e.target.value) } : a
                        )
                      )
                    }
                    placeholder="Budget"
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-xs text-white"
                  />
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono text-indigo-400 font-bold">{act.quarter}</span>
                    <button
                      type="button"
                      onClick={() =>
                        setFormActivities((prev) => prev.filter((_, i) => i !== idx))
                      }
                      className="text-rose-400 hover:text-rose-300 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Auto-Generated Q1-Q4 Preview */}
          <div className="p-4 rounded-xl bg-indigo-950/20 border border-indigo-500/30 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-300 block">
              Live Preview: Automatically Generated Q1–Q4 Milestones & Monthly Schedule
            </span>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {liveGeneratedSchedule.quarterlyMilestones.map((qm) => (
                <div key={qm.quarter} className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 text-xs">
                  <div className="font-bold text-indigo-400">{qm.quarter}</div>
                  <div className="text-slate-300 mt-1">
                    {qm.keyDeliverables.length} Deliverables • {qm.expectedParticipants} Reach
                  </div>
                  <div className="text-emerald-400 font-mono mt-0.5">
                    {currency} {qm.allocatedBudget.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {isEditingExisting && (
            <div>
              <label className="block text-xs font-bold text-amber-300 mb-1">
                Revision Note / Response to Pastor's Review
              </label>
              <input
                type="text"
                value={formRevisionComment}
                onChange={(e) => setFormRevisionComment(e.target.value)}
                placeholder="Describe the revisions made in response to pastoral feedback..."
                className="w-full rounded-xl bg-slate-950 border border-amber-500/40 px-3 py-2 text-xs text-white"
              />
            </div>
          )}

          <div className="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSaveOrSubmitPlan(false)}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
            >
              Save as Draft
            </button>
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSaveOrSubmitPlan(true)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-lg shadow-indigo-600/25"
            >
              <Send className="w-4 h-4" />
              {isEditingExisting ? 'Submit Revised Plan to Pastor' : 'Create & Submit Plan to Pastor'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
