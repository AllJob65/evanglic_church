import React, { useState, useEffect, useId } from 'react';
import {
  Phone,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Signal,
  Copy,
  Check,
} from 'lucide-react';
import {
  ETHIOPIAN_PHONE_REGEX,
  formatToE164,
  validateEthiopianPhone,
} from '../schemas/phone.schema';

export interface EthiopianPhoneInputProps {
  id?: string;
  name?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onValueChange?: (value: string, normalized: string, isValid: boolean) => void;
  onNormalizedChange?: (normalized: string) => void;
  label?: string;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
  helperText?: string;
  className?: string;
  showCarrierBadge?: boolean;
  showNormalizedPreview?: boolean;
  showQuickPrefixes?: boolean;
  autoFocus?: boolean;
}

export const EthiopianPhoneInput: React.FC<EthiopianPhoneInputProps> = ({
  id: propId,
  name = 'phone',
  value: controlledValue,
  defaultValue = '',
  onChange,
  onValueChange,
  onNormalizedChange,
  label = 'Ethiopian Mobile Number',
  placeholder = '0910109191 or +251910109191',
  required = false,
  disabled = false,
  error: externalError,
  helperText,
  className = '',
  showCarrierBadge = true,
  showNormalizedPreview = true,
  showQuickPrefixes = true,
  autoFocus = false,
}) => {
  const generatedId = useId();
  const inputId = propId || `eth-phone-${generatedId}`;

  // Internal state when uncontrolled
  const [internalValue, setInternalValue] = useState(defaultValue);
  const isControlled = controlledValue !== undefined;
  const currentValue = isControlled ? controlledValue : internalValue;

  const [isTouched, setIsTouched] = useState(false);
  const [copied, setCopied] = useState(false);

  // Run validation
  const validation = validateEthiopianPhone(currentValue);
  const normalizedValue = formatToE164(currentValue);

  // Sanitize and filter input: allow leading '+' and digits only, cap at 13 chars
  const sanitizePhoneInput = (input: string): string => {
    if (!input) return '';
    let cleaned = input.trim();

    // Check if starts with '+'
    const hasPlus = cleaned.startsWith('+');
    // Remove all non-digits
    const digitsOnly = cleaned.replace(/\D/g, '');

    if (hasPlus) {
      // "+2519..." capped at 13 total characters (+ plus 12 digits)
      return `+${digitsOnly.slice(0, 12)}`;
    } else {
      // Local "09..." or "07..." capped at 10 digits
      return digitsOnly.slice(0, 10);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const sanitized = sanitizePhoneInput(rawVal);

    if (!isControlled) {
      setInternalValue(sanitized);
    }

    // Create synthetic event with sanitized value
    const syntheticEvent = {
      ...e,
      target: {
        ...e.target,
        name: e.target.name || name,
        value: sanitized,
      },
    };

    if (onChange) {
      onChange(syntheticEvent as unknown as React.ChangeEvent<HTMLInputElement>);
    }

    const valResult = validateEthiopianPhone(sanitized);
    const normalized = formatToE164(sanitized);

    if (onValueChange) {
      onValueChange(sanitized, normalized, valResult.isValid);
    }

    if (onNormalizedChange) {
      onNormalizedChange(valResult.isValid ? normalized : sanitized);
    }
  };

  const handleQuickPrefix = (prefix: string) => {
    if (disabled) return;
    setIsTouched(true);
    let newVal = prefix;

    if (!isControlled) {
      setInternalValue(newVal);
    }

    const valResult = validateEthiopianPhone(newVal);
    const normalized = formatToE164(newVal);

    if (onValueChange) {
      onValueChange(newVal, normalized, valResult.isValid);
    }

    if (onNormalizedChange) {
      onNormalizedChange(normalized);
    }
  };

  const handleCopyNormalized = async () => {
    if (!validation.isValid || !validation.normalized) return;
    try {
      await navigator.clipboard.writeText(validation.normalized);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Fallback
    }
  };

  // Determine error state to display
  const displayError = externalError || (isTouched && currentValue && !validation.isValid ? validation.error : '');
  const isValidState = currentValue && validation.isValid;

  return (
    <div className={`space-y-1.5 text-left select-none ${className}`}>
      {/* Label and Helper Header */}
      {label && (
        <div className="flex items-center justify-between">
          <label
            htmlFor={inputId}
            className="block text-xs font-bold text-slate-700 dark:text-slate-300"
          >
            {label} {required && <span className="text-rose-500">*</span>}
          </label>

          {/* Carrier Badge */}
          {showCarrierBadge && isValidState && validation.carrier && (
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                validation.carrier === 'Safaricom Ethiopia'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                  : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800'
              }`}
            >
              <Signal className="w-2.5 h-2.5" />
              <span>{validation.carrier}</span>
            </span>
          )}
        </div>
      )}

      {/* Input Container */}
      <div className="relative rounded-2xl shadow-xs">
        {/* Left Flag & Phone Icon Indicator */}
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none gap-1.5">
          <span className="text-sm" role="img" aria-label="Ethiopia Flag">
            🇪🇹
          </span>
          <div className="h-4 w-[1px] bg-slate-300 dark:bg-slate-700" />
          <Phone
            className={`w-4 h-4 transition-colors ${
              displayError
                ? 'text-rose-500'
                : isValidState
                ? 'text-emerald-500'
                : 'text-slate-400'
            }`}
          />
        </div>

        {/* Text Input */}
        <input
          id={inputId}
          name={name}
          type="tel"
          inputMode="tel"
          autoComplete="tel"
          autoFocus={autoFocus}
          disabled={disabled}
          required={required}
          maxLength={13}
          value={currentValue}
          onChange={handleInputChange}
          onBlur={() => setIsTouched(true)}
          placeholder={placeholder}
          aria-invalid={Boolean(displayError)}
          aria-describedby={displayError ? `${inputId}-error` : helperText ? `${inputId}-helper` : undefined}
          className={`w-full pl-16 pr-10 py-2.5 bg-slate-50 dark:bg-slate-800/90 rounded-2xl text-xs font-mono font-bold tracking-wider transition-all placeholder:text-slate-400 placeholder:font-sans placeholder:font-normal focus:outline-none focus:ring-2 ${
            displayError
              ? 'border-2 border-rose-500 dark:border-rose-500/80 focus:ring-rose-500/20 text-rose-900 dark:text-rose-200 bg-rose-50/30 dark:bg-rose-950/20'
              : isValidState
              ? 'border-2 border-emerald-500 dark:border-emerald-500/80 focus:ring-emerald-500/20 text-slate-900 dark:text-white'
              : 'border border-slate-200 dark:border-slate-700 focus:border-blue-500 focus:ring-blue-500/20 text-slate-900 dark:text-white'
          } ${disabled ? 'opacity-50 cursor-not-allowed bg-slate-100 dark:bg-slate-900' : ''}`}
        />

        {/* Right Status Icon */}
        <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none">
          {displayError ? (
            <AlertCircle className="w-4 h-4 text-rose-500 animate-pulse" />
          ) : isValidState ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          ) : null}
        </div>
      </div>

      {/* Quick Prefix Shortcut Chips */}
      {showQuickPrefixes && !disabled && (
        <div className="flex items-center gap-1.5 pt-0.5 flex-wrap">
          <span className="text-[10px] font-semibold text-slate-400">Quick prefix:</span>
          {[
            { label: '09 (Ethio Telecom)', prefix: '09' },
            { label: '07 (Safaricom)', prefix: '07' },
            { label: '+2519 (Intl)', prefix: '+2519' },
            { label: '+2517 (Intl)', prefix: '+2517' },
          ].map((item) => (
            <button
              key={item.prefix}
              type="button"
              onClick={() => handleQuickPrefix(item.prefix)}
              className="px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-blue-950 dark:hover:text-blue-300 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
            >
              {item.prefix}
            </button>
          ))}
        </div>
      )}

      {/* Normalized E.164 Live Preview Badge */}
      {showNormalizedPreview && isValidState && validation.normalized && (
        <div className="flex items-center justify-between p-2 bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-[11px] text-emerald-800 dark:text-emerald-300 animate-in fade-in duration-200">
          <div className="flex items-center gap-1.5 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>Normalized E.164:</span>
            <code className="font-mono font-bold px-1.5 py-0.5 bg-white dark:bg-slate-900 rounded-md border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
              {validation.normalized}
            </code>
          </div>

          <button
            type="button"
            onClick={handleCopyNormalized}
            className="p-1 rounded-lg text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition-colors cursor-pointer"
            title="Copy normalized phone"
            aria-label="Copy normalized phone"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      )}

      {/* Error Message */}
      {displayError ? (
        <p
          id={`${inputId}-error`}
          role="alert"
          className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 flex items-center gap-1 mt-1"
        >
          <AlertCircle className="w-3 h-3 shrink-0" />
          <span>{displayError}</span>
        </p>
      ) : helperText ? (
        <p
          id={`${inputId}-helper`}
          className="text-[10px] text-slate-500 dark:text-slate-400 mt-1"
        >
          {helperText}
        </p>
      ) : null}
    </div>
  );
};

export {
  ETHIOPIAN_PHONE_REGEX,
  formatToE164,
  formatEthioPhone,
  validateEthiopianPhone,
} from '../schemas/phone.schema';

export default EthiopianPhoneInput;
