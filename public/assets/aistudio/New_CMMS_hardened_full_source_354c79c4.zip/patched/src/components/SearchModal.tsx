import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { normalizeUserRole } from '../utils/rbac';
import { UserRole } from '../types';
import {
  Search,
  X,
  Users,
  Calendar,
  BookOpen,
  HeartHandshake,
  ShieldCheck,
  Building2,
  FileText,
  Settings,
  Database,
  ArrowRight,
  Sparkles,
  Command,
  CornerDownLeft,
  UsersRound,
  CheckCircle2,
  Lock,
  Sun,
  Moon,
  Eye,
  Sliders,
  FileCheck2,
  Phone,
  Mail,
  HelpCircle,
} from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SearchItem {
  id: string;
  title: string;
  subtitle?: string;
  category: 'Modules' | 'Members' | 'Events' | 'Ministries' | 'Pastoral' | 'System' | 'Actions';
  url: string;
  icon: React.ComponentType<{ className?: string }>;
  allowedRoles: UserRole[];
  badge?: string;
  keywords?: string[];
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const {
    members,
    events,
    ministries,
    prayerRequests,
    workflows,
    themeMode,
    setThemeMode,
    setActiveModule,
  } = useCMMS();

  const { userRole } = useAuth();
  const navigate = useNavigate();

  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const normRole = normalizeUserRole(userRole);

  // Focus input automatically when opened
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Static Navigation Search Items with explicit role permissions
  const staticItems: SearchItem[] = useMemo(() => [
    // Module routes
    {
      id: 'mod-dashboard',
      title: 'Dashboard Overview',
      subtitle: 'Main church analytics, metrics & operations',
      category: 'Modules',
      url: '/dashboard',
      icon: ShieldCheck,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER'],
      keywords: ['home', 'kpi', 'stats', 'analytics', 'overview'],
    },
    {
      id: 'mod-profile',
      title: 'My Member Profile',
      subtitle: 'View and update personal demographic and household details',
      category: 'Modules',
      url: '/my-profile',
      icon: Users,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      keywords: ['profile', 'account', 'me', 'details', 'my info'],
    },
    {
      id: 'mod-members',
      title: 'Member Directory & Profiles',
      subtitle: 'Search, add, and manage baptized and associate members',
      category: 'Modules',
      url: '/members',
      icon: Users,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'],
      keywords: ['congregation', 'directory', 'people', 'members', 'users'],
    },
    {
      id: 'mod-devotions',
      title: 'Daily Devotion & Word',
      subtitle: 'Daily scripture readings, commentaries, and reflections',
      category: 'Modules',
      url: '/devotions',
      icon: BookOpen,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      keywords: ['bible', 'scripture', 'devotion', 'word', 'verse', 'prayer'],
    },
    {
      id: 'mod-ministries',
      title: 'Ministries & Fellowships',
      subtitle: 'Choir, Youth, Media, Evangelism, and department rosters',
      category: 'Modules',
      url: '/ministries',
      icon: UsersRound,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      keywords: ['fellowship', 'teams', 'departments', 'groups'],
    },
    {
      id: 'mod-events',
      title: 'Events & Calendar',
      subtitle: 'Church conferences, Sunday services, and broadcasts',
      category: 'Modules',
      url: '/events',
      icon: Calendar,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      keywords: ['schedule', 'calendar', 'service', 'conference', 'meeting'],
    },
    {
      id: 'mod-attendance',
      title: 'Attendance & Check-in',
      subtitle: 'Sunday service headcounts, QR check-ins & analytics',
      category: 'Modules',
      url: '/attendance',
      icon: CheckCircle2,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      keywords: ['checkin', 'roll call', 'headcount', 'attendance'],
    },
    {
      id: 'mod-prayer',
      title: 'Prayer & Pastoral Counseling',
      subtitle: 'Submit prayer petitions and schedule pastoral counseling',
      category: 'Modules',
      url: '/prayer-counseling',
      icon: HeartHandshake,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'REGULAR_MEMBER'],
      keywords: ['prayer', 'petition', 'counseling', 'pastor', 'help'],
    },
    {
      id: 'mod-approvals',
      title: 'Workflows & Approvals',
      subtitle: 'Review pending membership applications and requisitions',
      category: 'Modules',
      url: '/approvals',
      icon: FileCheck2,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER'],
      keywords: ['approvals', 'requests', 'membership application', 'workflows'],
    },
    {
      id: 'mod-branches',
      title: 'Branches & Campuses',
      subtitle: 'Manage sanctuary locations, halls, and geographic campuses',
      category: 'Modules',
      url: '/branches',
      icon: Building2,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER'],
      keywords: ['branch', 'campus', 'location', 'sanctuary'],
    },
    {
      id: 'mod-backup',
      title: 'Backup & Database Management',
      subtitle: 'Export cloud backups, snapshot Firestore, and database tools',
      category: 'System',
      url: '/backup',
      icon: Database,
      allowedRoles: ['SYSTEM_ADMIN'],
      keywords: ['backup', 'export', 'database', 'restore', 'snapshot'],
    },
    {
      id: 'mod-security',
      title: 'Security & Audit Logs',
      subtitle: '2FA access logs, IP audit trail, and security monitoring',
      category: 'System',
      url: '/security-audit',
      icon: ShieldCheck,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER'],
      keywords: ['security', 'audit', 'logs', 'compliance', '2fa'],
    },
    {
      id: 'mod-settings',
      title: 'System Settings & Config',
      subtitle: 'Branding, church logo, email templates, and SMTP setup',
      category: 'System',
      url: '/settings',
      icon: Settings,
      allowedRoles: ['SYSTEM_ADMIN'],
      keywords: ['settings', 'configuration', 'admin', 'setup', 'branding'],
    },
    // Quick Actions
    {
      id: 'act-theme-toggle',
      title: themeMode === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode',
      subtitle: 'Toggle interface visual theme appearance',
      category: 'Actions',
      url: '#action:toggle-theme',
      icon: themeMode === 'light' ? Moon : Sun,
      allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
      keywords: ['theme', 'dark', 'light', 'appearance', 'mode'],
    },
  ], [themeMode]);

  // Dynamic Content Search Items (Members, Events, Ministries, etc.)
  const dynamicItems: SearchItem[] = useMemo(() => {
    const list: SearchItem[] = [];

    // Members (only if authorized)
    if (['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'].includes(normRole)) {
      members.forEach((m) => {
        list.push({
          id: `mem-${m.id}`,
          title: `${m.firstName} ${m.lastName}`,
          subtitle: `${m.memberIdNumber || 'Member'} • ${m.membershipStatus} • ${m.primaryPhone || m.email || 'No contact'}`,
          category: 'Members',
          url: `/members?memberId=${m.id}`,
          icon: Users,
          allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR'],
          badge: m.membershipStatus,
          keywords: [m.firstName, m.lastName, m.email || '', m.primaryPhone || '', m.memberIdNumber || ''],
        });
      });
    }

    // Events
    events.forEach((ev) => {
      list.push({
        id: `ev-${ev.id}`,
        title: ev.title,
        subtitle: `${ev.startDate || ev.date || 'Upcoming'} • ${ev.location || 'Sanctuary'} • ${ev.category || 'Service'}`,
        category: 'Events',
        url: `/events?eventId=${ev.id}`,
        icon: Calendar,
        allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
        badge: ev.category,
        keywords: [ev.title, ev.location || '', ev.description || ''],
      });
    });

    // Ministries
    ministries.forEach((min) => {
      list.push({
        id: `min-${min.id}`,
        title: min.name,
        subtitle: `${min.leaderName ? `Leader: ${min.leaderName}` : 'Ministry Group'} • ${min.memberCount || 0} Members`,
        category: 'Ministries',
        url: `/ministries?ministryId=${min.id}`,
        icon: UsersRound,
        allowedRoles: ['SYSTEM_ADMIN', 'MANAGER', 'MINISTRY_LEADER', 'REGULAR_MEMBER'],
        badge: min.category,
        keywords: [min.name, min.leaderName || '', min.description || ''],
      });
    });

    // Workflows (for Admin / Manager)
    if (['SYSTEM_ADMIN', 'MANAGER'].includes(normRole)) {
      workflows.forEach((wf) => {
        list.push({
          id: `wf-${wf.id}`,
          title: `Workflow: ${wf.requestType || wf.requestCode}`,
          subtitle: `${wf.requesterName} • ${wf.branchName || 'HQ'} • Status: ${wf.status}`,
          category: 'System',
          url: `/approvals`,
          icon: FileCheck2,
          allowedRoles: ['SYSTEM_ADMIN', 'MANAGER'],
          badge: wf.status,
          keywords: [wf.requestType || '', wf.requestCode || '', wf.requesterName || ''],
        });
      });
    }

    return list;
  }, [members, events, ministries, workflows, normRole]);

  // Combine and STRICTLY filter by Role permissions
  const filteredResults = useMemo(() => {
    const all = [...staticItems, ...dynamicItems];

    // 1. STRICT ROLE FILTERING: unauthorized items are completely removed
    const roleAllowed = all.filter((item) => item.allowedRoles.includes(normRole));

    if (!query.trim()) {
      // Show modules and primary actions when query is empty
      return roleAllowed.filter((i) => i.category === 'Modules' || i.category === 'Actions').slice(0, 10);
    }

    const q = query.toLowerCase().trim();
    return roleAllowed
      .filter((item) => {
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchSubtitle = item.subtitle?.toLowerCase().includes(q);
        const matchKeywords = item.keywords?.some((k) => k.toLowerCase().includes(q));
        const matchCategory = item.category.toLowerCase().includes(q);
        return matchTitle || matchSubtitle || matchKeywords || matchCategory;
      })
      .slice(0, 20);
  }, [staticItems, dynamicItems, normRole, query]);

  // Reset selected index when results change
  useEffect(() => {
    setSelectedIndex(0);
  }, [filteredResults]);

  // Keyboard navigation handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < filteredResults.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : filteredResults.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredResults[selectedIndex]) {
        handleSelectItem(filteredResults[selectedIndex]);
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  const handleSelectItem = (item: SearchItem) => {
    onClose();

    if (item.url.startsWith('#action:')) {
      if (item.url === '#action:toggle-theme') {
        setThemeMode(themeMode === 'light' ? 'dark' : 'light');
      }
      return;
    }

    // Direct routing
    const baseModule = item.url.split('?')[0].replace('/', '');
    if (baseModule) {
      setActiveModule(baseModule as any);
    }
    navigate(item.url);
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="command-palette-title"
      className="fixed inset-0 z-50 flex items-start justify-center pt-3 sm:pt-20 px-3 sm:px-4 pb-[max(1rem,env(safe-area-inset-bottom,0px))] bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[88dvh] sm:max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Input Bar */}
        <div className="p-3.5 sm:p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3 bg-slate-50/50 dark:bg-slate-900/50">
          <Search className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
          <input
            ref={inputRef}
            id="command-palette-title"
            type="text"
            role="combobox"
            aria-expanded="true"
            aria-autocomplete="list"
            placeholder="Search commands, members, events, or pages..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-base sm:text-sm font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none py-1"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-flex items-center gap-1 px-2 py-1 text-xs font-mono font-bold text-slate-500 bg-slate-200/80 dark:bg-slate-800 dark:text-slate-400 rounded-lg border border-slate-300 dark:border-slate-700">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div ref={listRef} className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredResults.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400">
                <Search className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                No matching results found for &ldquo;{query}&rdquo;
              </p>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Only items authorized for your role ({normRole}) are searched and displayed.
              </p>
            </div>
          ) : (
            filteredResults.map((item, index) => {
              const isSelected = index === selectedIndex;
              const IconComp = item.icon;

              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectItem(item)}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`w-full min-h-[44px] flex items-center justify-between p-3 rounded-2xl transition-all text-left cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800/80 text-slate-900 dark:text-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-2 rounded-xl shrink-0 transition-colors ${
                        isSelected
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400'
                      }`}
                    >
                      <IconComp className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs sm:text-sm truncate">
                          {item.title}
                        </span>
                        {item.badge && (
                          <span
                            className={`px-2 py-0.5 rounded-md text-xs font-bold shrink-0 ${
                              isSelected
                                ? 'bg-white/20 text-white'
                                : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                      {item.subtitle && (
                        <p
                          className={`text-xs truncate mt-0.5 ${
                            isSelected ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {item.subtitle}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    <span
                      className={`hidden sm:inline-block px-2 py-0.5 text-xs font-semibold rounded-md ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {item.category}
                    </span>
                    {isSelected && (
                      <CornerDownLeft className="w-4 h-4 text-white animate-pulse" />
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer with Keyboard Hints */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold">↑</kbd>
              <kbd className="px-1.5 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold">↓</kbd>
              Navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold">↵</kbd>
              Select
            </span>
          </div>

          <div className="flex items-center gap-1 font-semibold text-blue-600 dark:text-blue-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Role: {normRole}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
