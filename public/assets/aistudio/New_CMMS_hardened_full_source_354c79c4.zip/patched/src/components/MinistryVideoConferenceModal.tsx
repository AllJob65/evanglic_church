import React, { useState, useEffect, useRef } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Ministry, MinistryVideoRoom, VideoParticipant } from '../types';
import { apiService } from '../services/api';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  Monitor,
  PhoneOff,
  Hand,
  Users,
  MessageSquare,
  Grid,
  Maximize,
  Minimize,
  Settings,
  Sparkles,
  Shield,
  ShieldAlert,
  Volume2,
  Smile,
  Send,
  X,
  Radio,
  Check,
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';

interface MinistryVideoConferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  ministryId: string;
}

export const MinistryVideoConferenceModal: React.FC<MinistryVideoConferenceModalProps> = ({
  isOpen,
  onClose,
  ministryId,
}) => {
  const { currentUser, ministries, activeRole } = useCMMS();
  const ministry = ministries.find((m) => m.id === ministryId) || ministries[0];

  // Local media stream & control states
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [layoutMode, setLayoutMode] = useState<'grid' | 'speaker'>('grid');
  const [isSidebarOpen, setIsSidebarOpen] = useState<'chat' | 'participants' | null>(null);
  const [videoChatMessages, setVideoChatMessages] = useState<{ id: string; sender: string; text: string; time: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [activeSpeakerId, setActiveSpeakerId] = useState<string>('host-lead');
  const [cameraError, setCameraError] = useState<string>('');
  const [accessDeniedError, setAccessDeniedError] = useState<string | null>(null);

  // Video Room participants
  const [room, setRoom] = useState<MinistryVideoRoom | null>(null);
  const [participants, setParticipants] = useState<VideoParticipant[]>([]);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const socketRef = useRef<Socket | null>(null);

  // Initialize room & WebRTC Local Media Stream
  useEffect(() => {
    if (!isOpen || !ministryId) return;

    // Fetch or create video room
    apiService
      .getMinistryVideoRoom(ministryId)
      .then((res) => {
        if (res.success && res.room) {
          setRoom(res.room);
          setParticipants(res.room.participants || []);
        }
      })
      .catch((err) => console.warn('Could not initialize video room:', err));

    // Join room endpoint
    apiService
      .joinMinistryVideoRoom(ministryId, {
        name: currentUser?.name || 'Church Member',
        role: activeRole || 'Member',
        avatar: currentUser?.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      })
      .then((res) => {
        if (res.success && res.room) {
          setParticipants(res.room.participants || []);
        }
      })
      .catch((e) => console.warn('Error joining room:', e));

    // Request user media stream (Camera & Mic) on user interaction
    const initLocalStream = async () => {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
          localStreamRef.current = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
          setCameraError('');
        } catch (err) {
          console.warn('Camera/Mic permission unavailable or in sandbox:', err);
          setCameraError('Camera preview using simulated visual feed in sandbox.');
        }
      }
    };

    // Connect socket for real-time video signaling & room actions
    const socket = io({
      path: '/socket.io',
      transports: ['websocket', 'polling'],
    });
    socketRef.current = socket;

    const currentUserId = currentUser?.memberId || currentUser?.email || 'usr-local';

    socket.on('connect', () => {
      socket.emit('video:join_room', {
        roomId: `room-${ministryId}-tenant-grace-main`,
        ministryId,
        user: {
          id: currentUserId,
          name: currentUser?.name || 'Church Member',
          role: activeRole || 'Member',
        },
      });
    });

    socket.on('video:participant_joined', (data: any) => {
      if (data.participant) {
        setParticipants((prev) => {
          if (prev.some((p) => p.userId === data.participant.userId)) return prev;
          return [...prev, data.participant];
        });
      }
    });

    socket.on('video:participant_left', (data: { userId: string }) => {
      setParticipants((prev) => prev.filter((p) => p.userId !== data.userId));
    });

    socket.on('video:audio_toggled', (data: { userId: string; isMuted: boolean }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.userId === data.userId ? { ...p, isMuted: data.isMuted } : p))
      );
    });

    socket.on('video:video_toggled', (data: { userId: string; isVideoOff: boolean }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.userId === data.userId ? { ...p, isVideoOff: data.isVideoOff } : p))
      );
    });

    socket.on('video:hand_raised', (data: { userId: string; isRaised: boolean }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.userId === data.userId ? { ...p, isHandRaised: data.isRaised } : p))
      );
    });

    socket.on('error', (err: any) => {
      if (
        err?.code === 'FORBIDDEN_ROOM' ||
        err?.code === 'FORBIDDEN' ||
        err?.code === 'FORBIDDEN_GROUP' ||
        err?.code === 'FORBIDDEN_LEADER'
      ) {
        setAccessDeniedError(
          err.message ||
            'Access denied: You are not an enrolled member of the fellowship group hosting this video room.'
        );
      }
    });

    return () => {
      // Clean up media streams
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      socket.disconnect();
      apiService.leaveMinistryVideoRoom(ministryId, currentUserId).catch(() => {});
    };
  }, [isOpen, ministryId, currentUser?.name, currentUser?.memberId, currentUser?.email, activeRole]);

  // Toggle Microphone
  const handleToggleMic = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((t) => (t.enabled = !nextMute));
    }
    socketRef.current?.emit('video:toggle_audio', {
      roomId: `room-${ministryId}-tenant-grace-main`,
      userId: currentUser?.memberId || currentUser?.email || 'usr-local',
      isMuted: nextMute,
    });
  };

  // Toggle Camera (User-gated hardware activation)
  const handleToggleVideo = async () => {
    const nextVideoOff = !isVideoOff;
    setIsVideoOff(nextVideoOff);
    if (!nextVideoOff && !localStreamRef.current) {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: !isMuted });
          localStreamRef.current = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
          setCameraError('');
        } catch (err) {
          console.warn('User camera permission error:', err);
          setCameraError('Camera access denied or unavailable.');
        }
      }
    } else if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((t) => (t.enabled = !nextVideoOff));
    }
    socketRef.current?.emit('video:toggle_video', {
      roomId: `room-${ministryId}-tenant-grace-main`,
      userId: currentUser?.memberId || currentUser?.email || 'usr-local',
      isVideoOff: nextVideoOff,
    });
  };

  // Toggle Screen Sharing
  const handleToggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
          const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          screenStreamRef.current = screenStream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = screenStream;
          }
          screenStream.getVideoTracks()[0].onended = () => {
            setIsScreenSharing(false);
            if (localStreamRef.current && localVideoRef.current) {
              localVideoRef.current.srcObject = localStreamRef.current;
            }
          };
          setIsScreenSharing(true);
        } else {
          setIsScreenSharing(true);
        }
      } catch (e) {
        console.warn('Screen share canceled or unpermitted:', e);
      }
    } else {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((t) => t.stop());
        screenStreamRef.current = null;
      }
      if (localStreamRef.current && localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
      setIsScreenSharing(false);
    }
  };

  // Toggle Hand Raise
  const handleToggleHandRaise = () => {
    const nextRaised = !isHandRaised;
    setIsHandRaised(nextRaised);
    socketRef.current?.emit('video:raise_hand', {
      roomId: `room-${ministryId}-tenant-grace-main`,
      userId: currentUser?.memberId || currentUser?.email || 'usr-local',
      userName: currentUser?.name || 'Member',
      isRaised: nextRaised,
    });
  };

  // Send In-Meeting Chat Message
  const handleSendInMeetingChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const newMsg = {
      id: `inchat-${Date.now()}`,
      sender: currentUser?.name || 'Me',
      text: chatInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setVideoChatMessages((prev) => [...prev, newMsg]);
    setChatInput('');
  };

  if (!isOpen) return null;

  const currentUserId = currentUser?.memberId || currentUser?.email || 'usr-local';

  // Render simulated participants alongside local user
  const displayParticipants: VideoParticipant[] = [
    {
      id: 'local-user',
      userId: currentUserId,
      name: `${currentUser?.name || 'You'} (You)`,
      role: activeRole || 'Member',
      isMuted,
      isVideoOff,
      isScreenSharing,
      isHandRaised,
      isSpeaking: !isMuted,
      joinedAt: new Date().toISOString(),
      avatar: currentUser?.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    },
    ...participants.filter((p) => p.userId !== currentUserId),
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150"
    >
      <div className="bg-slate-950 border border-slate-800 rounded-3xl w-full h-[92vh] max-w-6xl shadow-2xl flex flex-col overflow-hidden text-white relative">
        {/* Top Header Bar */}
        <div className="p-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between shrink-0 z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-2xl bg-rose-600/20 text-rose-400 border border-rose-500/30 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold tracking-tight">
                  {ministry?.name} — Fellowship Video Room
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  HD WebRTC
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Room ID: room-{ministryId} • {displayParticipants.length} Connected
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-800 rounded-xl p-1 border border-slate-700">
              <button
                onClick={() => setLayoutMode('grid')}
                className={`p-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  layoutMode === 'grid' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Grid View"
              >
                <Grid className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setLayoutMode('speaker')}
                className={`p-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  layoutMode === 'speaker' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Speaker View"
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Video Canvas & Right Drawer Layout */}
        <div className="flex-1 flex overflow-hidden relative">
          {/* Video Streams Grid */}
          <div className="flex-1 p-3 sm:p-5 overflow-y-auto bg-slate-950 flex flex-col justify-center">
            {accessDeniedError ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                <div className="w-16 h-16 rounded-3xl bg-rose-950/80 border border-rose-500/50 flex items-center justify-center text-rose-400 shadow-xl">
                  <ShieldAlert className="w-8 h-8" />
                </div>
                <div className="space-y-1.5 max-w-md">
                  <h3 className="text-base font-bold text-rose-200">Video Room Access Restricted</h3>
                  <p className="text-xs text-rose-300 font-medium leading-relaxed">
                    {accessDeniedError}
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-all cursor-pointer"
                >
                  Close Video Room
                </button>
              </div>
            ) : layoutMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 max-h-full">
                {displayParticipants.map((p, idx) => {
                  const isLocal = p.id === 'local-user';
                  return (
                    <div
                      key={p.id}
                      className={`relative aspect-video rounded-2xl bg-slate-900 border overflow-hidden flex items-center justify-center group shadow-lg ${
                        p.isSpeaking
                          ? 'border-indigo-500 ring-2 ring-indigo-500/40'
                          : 'border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Video Stream Element */}
                      {isLocal ? (
                        <video
                          ref={localVideoRef}
                          autoPlay
                          playsInline
                          muted
                          className={`w-full h-full object-cover transform -scale-x-100 ${
                            isVideoOff ? 'hidden' : 'block'
                          }`}
                        />
                      ) : (
                        <img
                          src={p.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80'}
                          alt={p.name}
                          className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-300"
                        />
                      )}

                      {/* Fallback Avatar when Camera is Off */}
                      {isLocal && isVideoOff && (
                        <div className="flex flex-col items-center justify-center space-y-2">
                          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-xl font-black shadow-xl">
                            {p.name[0]}
                          </div>
                          <span className="text-xs text-slate-400 font-semibold">Camera is Turned Off</span>
                        </div>
                      )}

                      {/* Participant Badge & Status */}
                      <div className="absolute bottom-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none z-10">
                        <div className="px-2.5 py-1 rounded-xl bg-slate-950/80 backdrop-blur-md border border-white/10 flex items-center gap-2 text-xs font-semibold">
                          <span>{p.name}</span>
                          <span className="text-[10px] text-indigo-400 font-bold">({p.role})</span>
                        </div>

                        <div className="flex items-center gap-1">
                          {p.isHandRaised && (
                            <span className="p-1 rounded-lg bg-amber-500/90 text-amber-950 text-xs font-bold animate-bounce shadow-md">
                              ✋
                            </span>
                          )}
                          <div
                            className={`p-1.5 rounded-xl backdrop-blur-md ${
                              p.isMuted ? 'bg-rose-600/80 text-white' : 'bg-slate-900/80 text-emerald-400'
                            }`}
                          >
                            {p.isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                          </div>
                        </div>
                      </div>

                      {/* Live Audio Visualizer Pulse */}
                      {p.isSpeaking && (
                        <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-bold flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                          Speaking
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              /* Speaker Layout Mode */
              <div className="flex-1 flex flex-col gap-3 h-full">
                <div className="flex-1 relative rounded-3xl bg-slate-900 border border-indigo-500/50 overflow-hidden flex items-center justify-center">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80"
                    alt="Active Speaker"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-4 left-4 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md text-xs font-bold flex items-center gap-2">
                    <span>{ministry?.leaderName || 'Host Leader'}</span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/30 text-amber-200 text-[10px]">
                      Active Speaker
                    </span>
                  </div>
                </div>

                {/* Filmstrip at bottom */}
                <div className="h-28 flex gap-2 overflow-x-auto pb-1">
                  {displayParticipants.map((p) => (
                    <div
                      key={p.id}
                      className="w-36 h-full rounded-2xl bg-slate-900 border border-slate-800 relative shrink-0 overflow-hidden flex items-center justify-center"
                    >
                      <div className="w-10 h-10 rounded-full bg-indigo-600/30 text-indigo-300 flex items-center justify-center font-bold text-sm">
                        {p.name[0]}
                      </div>
                      <span className="absolute bottom-1.5 left-1.5 text-[10px] font-bold text-slate-300 truncate max-w-[90%] bg-slate-950/80 px-1 rounded">
                        {p.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Sidebar Drawer: Participants or Live Chat */}
          {isSidebarOpen && (
            <div className="w-80 border-l border-slate-800 bg-slate-900/95 backdrop-blur-md flex flex-col z-20 animate-in slide-in-from-right-4 duration-150">
              {/* Sidebar Header */}
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                  {isSidebarOpen === 'chat' ? (
                    <>
                      <MessageSquare className="w-4 h-4 text-indigo-400" />
                      In-Meeting Live Chat
                    </>
                  ) : (
                    <>
                      <Users className="w-4 h-4 text-indigo-400" />
                      Participants ({displayParticipants.length})
                    </>
                  )}
                </h3>
                <button onClick={() => setIsSidebarOpen(null)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Sidebar Body */}
              {isSidebarOpen === 'chat' ? (
                <div className="flex-1 flex flex-col justify-between p-3 overflow-hidden">
                  <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                    {videoChatMessages.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center p-4 text-slate-500 text-xs space-y-1">
                        <MessageSquare className="w-8 h-8 text-slate-600" />
                        <p>No in-call chat messages yet.</p>
                      </div>
                    ) : (
                      videoChatMessages.map((m) => (
                        <div key={m.id} className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs space-y-1">
                          <div className="flex items-center justify-between text-[10px] text-slate-400">
                            <span className="font-bold text-indigo-300">{m.sender}</span>
                            <span>{m.time}</span>
                          </div>
                          <p className="text-slate-200">{m.text}</p>
                        </div>
                      ))
                    )}
                  </div>

                  <form onSubmit={handleSendInMeetingChat} className="pt-2 flex gap-1.5 border-t border-slate-800">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Type a message to all..."
                      className="flex-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                    />
                    <button
                      type="submit"
                      disabled={!chatInput.trim()}
                      className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              ) : (
                <div className="flex-1 p-3 overflow-y-auto space-y-2">
                  {displayParticipants.map((p) => (
                    <div
                      key={p.id}
                      className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-xs">
                          {p.name[0]}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-200">{p.name}</p>
                          <span className="text-[10px] text-slate-400">{p.role}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        {p.isHandRaised && <span className="text-xs">✋</span>}
                        {p.isMuted ? (
                          <MicOff className="w-3.5 h-3.5 text-rose-400" />
                        ) : (
                          <Mic className="w-3.5 h-3.5 text-emerald-400" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0 z-10">
          {/* Left info */}
          <div className="flex items-center gap-2 text-xs text-slate-400 hidden sm:flex">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Encrypted Room • Sovereign CMMS Cloud</span>
          </div>

          {/* Center Call Controls */}
          <div className="flex items-center gap-2.5 sm:gap-3 mx-auto sm:mx-0">
            {/* Mic Toggle */}
            <button
              onClick={handleToggleMic}
              className={`p-3 sm:px-4 sm:py-3 rounded-2xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
                isMuted
                  ? 'bg-rose-600 hover:bg-rose-500 text-white ring-2 ring-rose-500/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
              }`}
              title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              <span className="hidden sm:inline">{isMuted ? 'Unmute' : 'Mute'}</span>
            </button>

            {/* Video Toggle */}
            <button
              onClick={handleToggleVideo}
              className={`p-3 sm:px-4 sm:py-3 rounded-2xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
                isVideoOff
                  ? 'bg-rose-600 hover:bg-rose-500 text-white ring-2 ring-rose-500/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
              }`}
              title={isVideoOff ? 'Turn Video On' : 'Turn Video Off'}
            >
              {isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
              <span className="hidden sm:inline">{isVideoOff ? 'Start Video' : 'Stop Video'}</span>
            </button>

            {/* Screen Share */}
            <button
              onClick={handleToggleScreenShare}
              className={`p-3 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                isScreenSharing
                  ? 'bg-indigo-600 text-white ring-2 ring-indigo-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
              }`}
              title="Share Screen"
            >
              <Monitor className="w-4 h-4" />
            </button>

            {/* Raise Hand */}
            <button
              onClick={handleToggleHandRaise}
              className={`p-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                isHandRaised
                  ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
              }`}
              title="Raise Hand"
            >
              <Hand className="w-4 h-4" />
            </button>

            {/* In-Call Chat Drawer Toggle */}
            <button
              onClick={() => setIsSidebarOpen(isSidebarOpen === 'chat' ? null : 'chat')}
              className={`p-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                isSidebarOpen === 'chat'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
              }`}
              title="Open Chat"
            >
              <MessageSquare className="w-4 h-4" />
            </button>

            {/* Participants Drawer Toggle */}
            <button
              onClick={() => setIsSidebarOpen(isSidebarOpen === 'participants' ? null : 'participants')}
              className={`p-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                isSidebarOpen === 'participants'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
              }`}
              title="View Participants"
            >
              <Users className="w-4 h-4" />
            </button>

            {/* Leave Room Button */}
            <button
              onClick={onClose}
              className="px-4 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-xl transition-all cursor-pointer ml-2"
            >
              <PhoneOff className="w-4 h-4" />
              <span>Leave</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
