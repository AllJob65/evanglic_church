import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import {
  Users,
  Heart,
  Building2,
  UserCheck,
  Calendar,
  Send,
  HeartHandshake,
  BarChart3,
  BookOpen,
  ShieldCheck,
  Lock,
  ArrowRight,
  LogIn,
  UserPlus,
  Sun,
  Moon,
  Menu,
  X,
  CheckCircle2,
  LayoutDashboard,
  FolderTree,
  ChevronRight,
  MapPin,
  Phone,
  Mail,
  Clock,
  Layers,
  KeyRound,
  FileCheck2,
  Compass,
  Globe,
  Check,
  ChevronDown,
} from 'lucide-react';

export interface ChurchPeopleFrontpageProps {
  onLaunchApp?: () => void;
  onEnterPortal?: (role?: UserRole) => void;
  onFindGroup?: () => void;
  onOpenRegister?: () => void;
  onOpenLogin?: () => void;
  onOpenGoogleForm?: () => void;
}

type PreviewTabId = 'overview' | 'members' | 'ministries' | 'governance';

export const ChurchPeopleFrontpage: React.FC<ChurchPeopleFrontpageProps> = ({
  onLaunchApp,
  onEnterPortal,
  onFindGroup,
  onOpenRegister,
  onOpenLogin,
}) => {
  const { branches, themeMode, setThemeMode, language, langCode, setLanguage, t, isEthiopic, fontClass } = useCMMS();
  const { userProfile, switchDemoRole } = useAuth();
  const navigate = useNavigate();
  const shouldReduceMotion = useReducedMotion();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [activePreviewTab, setActivePreviewTab] = useState<PreviewTabId>('overview');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 20;
      setIsScrolled((prev) => (prev !== scrolled ? scrolled : prev));
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const isDark = themeMode === 'dark' || themeMode === 'advanced-dark';
  const toggleTheme = () => {
    setThemeMode(isDark ? 'light' : 'dark');
  };

  // Real configured branch contact details (without Grace Cathedral branding)
  const mainBranch = branches && branches.length > 0 ? branches[0] : null;
  const hasRealContactInfo = Boolean(
    mainBranch && (mainBranch.address || mainBranch.phone || mainBranch.email)
  );
  const contactAddress = mainBranch?.address
    ? `${mainBranch.address}${mainBranch.city ? `, ${mainBranch.city}` : ''}`
    : null;
  const contactPhone = mainBranch?.phone || null;
  const contactEmail = mainBranch?.email || null;
  const serviceTimes =
    mainBranch?.serviceTimes && mainBranch.serviceTimes.length > 0
      ? mainBranch.serviceTimes.map((s) => `${s.day} ${s.time}`).join(' · ')
      : null;

  // Navigation Handlers connected to real routes (never direct to /dashboard from landing page)
  const handleGetStarted = () => {
    setIsMobileMenuOpen(false);
    if (onOpenRegister) {
      onOpenRegister();
      return;
    }
    navigate('/register');
  };

  const handleLogin = () => {
    setIsMobileMenuOpen(false);
    if (onOpenLogin) {
      onOpenLogin();
      return;
    }
    navigate('/login');
  };

  const handleStaffLogin = () => {
    setIsMobileMenuOpen(false);
    navigate('/staff/login');
  };

  const handleFindGroup = () => {
    setIsMobileMenuOpen(false);
    if (onFindGroup) {
      onFindGroup();
      return;
    }
    navigate('/login?redirect=/ministries');
  };

  const handleRoleEntry = (role: UserRole) => {
    if (onEnterPortal) {
      onEnterPortal(role);
      return;
    }
    if (role !== 'REGULAR_MEMBER') {
      navigate('/staff/login');
    } else {
      navigate('/login');
    }
  };

  const scrollToSection = (sectionId: string) => {
    setIsMobileMenuOpen(false);
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: shouldReduceMotion ? 'auto' : 'smooth', block: 'start' });
    }
  };

  // Motion helper that respects prefers-reduced-motion
  const fadeUp = (delay = 0) =>
    shouldReduceMotion
      ? { initial: { opacity: 1, y: 0 }, animate: { opacity: 1, y: 0 } }
      : {
          initial: { opacity: 0, y: 18 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.45, delay, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
        };

  // Verified platform capabilities mapped to real modules in the codebase
  const featureCards = [
    {
      icon: Users,
      title: 'Member & Family Directory',
      description:
        'Maintain structured member profiles, household relationships, spiritual milestones, and public registration intake.',
      moduleLabel: 'Members & Households',
    },
    {
      icon: Building2,
      title: 'Ministry & Branch Management',
      description:
        'Organize multi-campus branches, ministry departments, small groups, leadership rosters, and service schedules.',
      moduleLabel: 'Branches & Ministries',
    },
    {
      icon: UserCheck,
      title: 'Attendance & Check-In',
      description:
        'Record service and group attendance, monitor participation trends, and follow up with absent members.',
      moduleLabel: 'Attendance Module',
    },
    {
      icon: Calendar,
      title: 'Events & Calendar Scheduling',
      description:
        'Coordinate church events, registrations, dual Gregorian and Ethiopian calendar views, and room assignments.',
      moduleLabel: 'Events & Calendar',
    },
    {
      icon: Send,
      title: 'Communication & Announcements',
      description:
        'Dispatch targeted announcements, ministry updates, and birthday or anniversary messages across channels.',
      moduleLabel: 'Communications',
    },
    {
      icon: HeartHandshake,
      title: 'Prayer Requests & Visitation Care',
      description:
        'Track confidential prayer requests, pastoral counseling sessions, and scheduled hospital or home visitations.',
      moduleLabel: 'Pastoral Care',
    },
    {
      icon: BarChart3,
      title: 'Reports & Administrative Insights',
      description:
        'Review demographic distributions, branch activity summaries, asset registries, and exportable CSV reports.',
      moduleLabel: 'Reports & Analytics',
    },
    {
      icon: BookOpen,
      title: 'Bible & Daily Devotionals',
      description:
        'Publish daily devotional readings, scripture passages, and discipleship learning materials for the congregation.',
      moduleLabel: 'Bible & Devotions',
    },
  ];

  // Platform Overview highlights backed by real features
  const overviewPoints = [
    {
      title: 'Centralized Member & Household Information',
      description:
        'Keep member profiles, family links, and registration approvals organized in one structured workspace instead of scattered spreadsheets.',
    },
    {
      title: 'Coordinated Ministry & Multi-Branch Operations',
      description:
        'Align pastors, ministry leaders, elders, and volunteers around shared calendars, group rosters, and branch directories.',
    },
    {
      title: 'Structured Pastoral Care & Follow-Up',
      description:
        'Assign visitation tasks, manage prayer and counseling queues, and ensure timely care for members and families.',
    },
    {
      title: 'Clear Reporting & Document Archiving',
      description:
        'Generate demographic and attendance reports, track church facilities and assets, and organize official documents.',
    },
  ];

  // 3-step How It Works
  const workflowSteps = [
    {
      step: '01',
      title: 'Set Up Your Organization',
      description:
        'Configure your primary campus and additional branches, define ministry departments, and establish administrative roles.',
      icon: Building2,
    },
    {
      step: '02',
      title: 'Organize Members & Ministries',
      description:
        'Add members directly or review submissions from the public registration form, link households, and assign small groups.',
      icon: Heart,
    },
    {
      step: '03',
      title: 'Coordinate Activities & Administration',
      description:
        'Track service attendance, schedule events, coordinate pastoral visitations, and review administrative reports.',
      icon: LayoutDashboard,
    },
  ];

  // Verified Security & Governance features implemented in the repository
  const securityFeatures = [
    {
      icon: KeyRound,
      title: 'Role-Based Access Control (RBAC)',
      description:
        'Granular permission boundaries across System Admin, Pastor, Ministry Leader, Elder/Deacon, Counselor, Volunteer, and Member roles.',
    },
    {
      icon: FileCheck2,
      title: 'Tamper-Evident Audit Logging',
      description:
        'Administrative actions, role changes, and security events are recorded in a hash-chained audit log with integrity verification.',
    },
    {
      icon: Lock,
      title: 'Session & Two-Factor Governance',
      description:
        'Authenticated session management with administrative session revocation, password policy enforcement, and 2FA support.',
    },
    {
      icon: ShieldCheck,
      title: 'Approval Workflows & Data Scope',
      description:
        'Public member registrations and sensitive administrative updates pass through structured review queues before activation.',
    },
  ];

  const roleCards: { title: string; role: UserRole; summary: string }[] = [
    {
      title: 'System Administrator',
      role: 'SYSTEM_ADMIN',
      summary: 'Full system configuration, user & role governance, security audit verification, and backups.',
    },
    {
      title: 'Pastor & Leadership',
      role: 'PASTOR',
      summary: 'Congregational oversight, member approvals, pastoral care, visitations, and executive reports.',
    },
    {
      title: 'Ministry Leader',
      role: 'MINISTRY_LEADER',
      summary: 'Ministry group rosters, event coordination, attendance tracking, and team communications.',
    },
    {
      title: 'Church Member',
      role: 'REGULAR_MEMBER',
      summary: 'Personal profile management, daily devotions, Bible reader, event schedules, and fellowship groups.',
    },
  ];

  return (
    <div
      id="home"
      className="min-h-screen bg-slate-50 dark:bg-[#0B0D10] text-slate-900 dark:text-slate-100 flex flex-col font-montserrat selection:bg-blue-600 selection:text-white transition-colors duration-200 overflow-x-hidden"
    >
      {/* Subtle Ambient Background Gradient (No heavy continuous JS loops) */}
      <div
        aria-hidden="true"
        className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      >
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[460px] rounded-full bg-gradient-to-tr from-blue-500/[0.07] via-indigo-500/[0.05] to-transparent dark:from-blue-500/[0.11] dark:via-indigo-500/[0.07] dark:to-transparent blur-3xl" />
        <div className="absolute top-[38%] -right-48 w-[520px] h-[520px] rounded-full bg-gradient-to-bl from-slate-200/50 via-blue-500/[0.04] to-transparent dark:from-blue-600/[0.06] dark:to-transparent blur-3xl" />
      </div>

      {/* =====================================================================
          1. ANIMATED TOP NAVIGATION BAR
      ===================================================================== */}
      <motion.header
        initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out ${
          isScrolled
            ? 'bg-white/95 dark:bg-[#0B0D10]/95 backdrop-blur-md border-b border-slate-200/80 dark:border-white/[0.08] shadow-sm'
            : 'bg-transparent border-b border-transparent shadow-none'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-[72px] flex items-center justify-between gap-4">
          {/* Application Identity: Strictly "Church Management System" */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => scrollToSection('home')}
              className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
            >
              <div className="w-9 h-9 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 flex items-center justify-center shadow-xs group-hover:bg-blue-600 dark:group-hover:bg-blue-500 dark:group-hover:text-white transition-colors shrink-0">
                <Layers className="w-4 h-4 stroke-[2]" />
              </div>
              <div className="min-w-0">
                <span className="block font-bold text-sm sm:text-base tracking-tight text-slate-900 dark:text-white truncate">
                  {t('landing.title', 'Church Management System')}
                </span>
                <span className="hidden sm:block text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate">
                  {t('landing.subtitle', 'Unified Operations & Ministry Platform')}
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-1 lg:gap-2"
          >
            {[
              { labelKey: 'landing.nav_home', defaultLabel: 'Home', id: 'home' },
              { labelKey: 'landing.nav_features', defaultLabel: 'Features', id: 'features' },
              { labelKey: 'landing.nav_about', defaultLabel: 'About', id: 'about' },
              { labelKey: 'landing.nav_how_it_works', defaultLabel: 'How It Works', id: 'how-it-works' },
              { labelKey: 'landing.nav_security', defaultLabel: 'Security', id: 'security' },
              ...(hasRealContactInfo ? [{ labelKey: 'landing.nav_contact', defaultLabel: 'Contact', id: 'contact' }] : []),
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => scrollToSection(item.id)}
                className="px-3 py-2 rounded-lg text-xs lg:text-sm font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-white/[0.06] transition-colors cursor-pointer"
              >
                {t(item.labelKey, item.defaultLabel)}
              </button>
            ))}
          </nav>

          {/* Right Actions: Language Switcher, Theme Toggle, Login, Get Started, Mobile Menu Button */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                aria-label="Change Language"
                title="Select Language"
                className="h-9 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-white/[0.06] dark:hover:bg-white/[0.1] border border-slate-200/80 dark:border-white/[0.08] text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Globe className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                <span className="hidden sm:inline">
                  {langCode === 'am' ? 'አማርኛ' : langCode === 'ti' ? 'ትግርኛ' : langCode === 'om' ? 'Oromoo' : 'English'}
                </span>
                <span className="sm:hidden text-[11px] font-bold uppercase">
                  {langCode}
                </span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>

              {isLangMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsLangMenuOpen(false)} />
                  <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                    {[
                      { code: 'en', name: 'English', native: 'English', flag: '🇬🇧' },
                      { code: 'am', name: 'Amharic', native: 'አማርኛ', flag: '🇪🇹' },
                      { code: 'ti', name: 'Tigrigna', native: 'ትግርኛ', flag: '🇪🇹' },
                      { code: 'om', name: 'Afaan Oromoo', native: 'Afaan Oromoo', flag: '🇪🇹' },
                    ].map((item) => (
                      <button
                        key={item.code}
                        type="button"
                        onClick={() => {
                          setLanguage(item.code);
                          setIsLangMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-xl font-medium transition-colors cursor-pointer ${
                          langCode === item.code
                            ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span>{item.flag}</span>
                          <span>{item.native}</span>
                        </span>
                        {langCode === item.code && <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            <button
              type="button"
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="h-9 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200/80 dark:bg-white/[0.06] dark:hover:bg-white/[0.1] border border-slate-200/80 dark:border-white/[0.08] text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isDark ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="hidden sm:inline">Light</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-slate-600" />
                  <span className="hidden sm:inline">Dark</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleLogin}
              className="hidden sm:inline-flex items-center gap-1.5 h-9 px-3.5 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 hover:text-slate-900 dark:text-slate-200 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/[0.06] border border-transparent hover:border-slate-200 dark:hover:border-white/[0.08] transition-all cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>{t('landing.login', 'Login')}</span>
            </button>

            <button
              type="button"
              onClick={handleGetStarted}
              className="hidden sm:inline-flex items-center gap-1.5 h-9 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs sm:text-sm font-semibold shadow-xs transition-all cursor-pointer"
            >
              <span>{t('landing.get_started', 'Get Started')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen((prev) => !prev)}
              aria-expanded={isMobileMenuOpen}
              aria-label={isMobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              className="md:hidden h-9 w-9 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/[0.06] dark:hover:bg-white/[0.1] border border-slate-200/80 dark:border-white/[0.08] flex items-center justify-center text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
            >
              {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Responsive Animated Mobile Menu */}
        <AnimatePresence initial={false}>
          {isMobileMenuOpen && (
            <motion.div
              initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, height: 0 }}
              transition={{ duration: 0.22, ease: 'easeInOut' }}
              className="md:hidden overflow-hidden border-t border-slate-200/80 dark:border-white/[0.08] bg-white dark:bg-[#111317] shadow-lg"
            >
              <div className="px-4 py-4 space-y-2">
                {/* Mobile Language Selector */}
                <div className="p-2 bg-slate-50 dark:bg-white/[0.04] rounded-2xl border border-slate-200/80 dark:border-white/[0.08]">
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block px-2 mb-1.5">
                    {t('navbar.language', 'Language')}
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 text-xs">
                    {[
                      { code: 'en', native: 'English', flag: '🇬🇧' },
                      { code: 'am', native: 'አማርኛ', flag: '🇪🇹' },
                      { code: 'ti', native: 'ትግርኛ', flag: '🇪🇹' },
                      { code: 'om', native: 'Oromoo', flag: '🇪🇹' },
                    ].map((langItem) => {
                      const isCurrent = langCode === langItem.code;
                      return (
                        <button
                          key={langItem.code}
                          type="button"
                          onClick={() => setLanguage(langItem.code)}
                          className={`px-2.5 py-1.5 rounded-xl border flex items-center justify-between text-left transition-all ${
                            isCurrent
                              ? 'bg-blue-600 text-white font-bold border-blue-600 shadow-xs'
                              : 'bg-white dark:bg-white/[0.06] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-white/[0.08]'
                          }`}
                        >
                          <span>{langItem.flag} {langItem.native}</span>
                          {isCurrent && <Check className="w-3 h-3 text-white" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {[
                  { labelKey: 'landing.nav_home', defaultLabel: 'Home', id: 'home' },
                  { labelKey: 'landing.nav_features', defaultLabel: 'Features', id: 'features' },
                  { labelKey: 'landing.nav_about', defaultLabel: 'About', id: 'about' },
                  { labelKey: 'landing.nav_how_it_works', defaultLabel: 'How It Works', id: 'how-it-works' },
                  { labelKey: 'landing.nav_security', defaultLabel: 'Security', id: 'security' },
                  ...(hasRealContactInfo ? [{ labelKey: 'landing.nav_contact', defaultLabel: 'Contact', id: 'contact' }] : []),
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => scrollToSection(item.id)}
                    className="w-full text-left px-3.5 py-2.5 rounded-xl text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors cursor-pointer"
                  >
                    {t(item.labelKey, item.defaultLabel)}
                  </button>
                ))}

                <div className="pt-3 mt-2 border-t border-slate-200/80 dark:border-white/[0.08] grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={handleLogin}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-white/[0.1] bg-slate-50 dark:bg-white/[0.04] text-slate-800 dark:text-slate-100 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>{t('landing.login', 'Login')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleGetStarted}
                    className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{t('landing.get_started', 'Get Started')}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>

      {/* =====================================================================
          2. HERO SECTION WITH STAGGERED REVEAL & INTERACTIVE INTERFACE PREVIEW
      ===================================================================== */}
      <main className="relative z-10 flex-1">
        <section className="pt-28 sm:pt-32 lg:pt-36 pb-16 sm:pb-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
              {/* Left Column: Headline, Supporting Copy & CTAs */}
              <div className="lg:col-span-6 space-y-6 text-left">
                <motion.div {...fadeUp(0.02)}>
                  <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-500/10 border border-blue-200/80 dark:border-blue-500/20 text-blue-700 dark:text-blue-300 text-xs font-semibold">
                    <span className="w-2 h-2 rounded-full bg-blue-600 dark:bg-blue-400" />
                    <span>{t('landing.admin_operations_badge', 'Church Administration & Ministry Operations')}</span>
                  </span>
                </motion.div>

                <motion.h1
                  {...fadeUp(0.08)}
                  className="text-3xl sm:text-5xl lg:text-[52px] font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.12]"
                >
                  {t('landing.manage_church', 'Manage Your Church.')}{' '}
                  <span className="bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent">
                    {t('landing.strengthen_community', 'Strengthen Your Community.')}
                  </span>
                </motion.h1>

                <motion.p
                  {...fadeUp(0.14)}
                  className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl"
                >
                  {t('landing.hero_summary', 'A unified platform for managing members, ministries, attendance, events, communication, and church administration.')}
                </motion.p>

                <motion.div
                  {...fadeUp(0.2)}
                  className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2"
                >
                  <button
                    type="button"
                    onClick={handleGetStarted}
                    className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>{t('landing.get_started', 'Get Started')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => scrollToSection('features')}
                    className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-100 dark:bg-[#14171C] dark:hover:bg-[#1B1F26] text-slate-800 dark:text-slate-100 border border-slate-200/90 dark:border-white/[0.1] font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>{t('landing.explore_features_btn', 'Explore Features')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleLogin}
                    className="px-4 py-3.5 rounded-xl text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white font-semibold text-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>{t('landing.sign_in_btn', 'Sign In')}</span>
                  </button>
                </motion.div>

                {/* Verified Capability Highlights */}
                <motion.div
                  {...fadeUp(0.26)}
                  className="pt-4 border-t border-slate-200/80 dark:border-white/[0.08] grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-slate-600 dark:text-slate-400"
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span>{t('landing.feature_multi_branch', 'Multi-Branch Support')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span>{t('landing.feature_rbac', 'Role-Based Permissions')}</span>
                  </div>
                  <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span>{t('landing.feature_multilingual', 'Multilingual Interface')}</span>
                  </div>
                </motion.div>
              </div>

              {/* Right Column: Interactive Architectural Workspace Illustration */}
              <motion.div
                initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
                className="lg:col-span-6"
              >
                <div className="relative rounded-2xl bg-white dark:bg-[#12151B] border border-slate-200/90 dark:border-white/[0.1] shadow-xl overflow-hidden">
                  {/* Top Window Bar */}
                  <div className="px-4 py-3 bg-slate-50 dark:bg-[#171B22] border-b border-slate-200/80 dark:border-white/[0.08] flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-600" />
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-600" />
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-600" />
                      <span className="ml-2 text-xs font-semibold text-slate-700 dark:text-slate-200">
                        Church Management System — Workspace Preview
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-500/10 border border-blue-200/70 dark:border-blue-500/20 text-[10px] font-semibold text-blue-700 dark:text-blue-300">
                      Interactive Preview
                    </span>
                  </div>

                  {/* Interactive Preview Tabs */}
                  <div className="p-4 sm:p-5 space-y-4">
                    <div
                      role="tablist"
                      aria-label="Workspace Preview Modules"
                      className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-[#0D1015] border border-slate-200/70 dark:border-white/[0.06]"
                    >
                      {[
                        { id: 'overview' as PreviewTabId, label: 'Overview', icon: LayoutDashboard },
                        { id: 'members' as PreviewTabId, label: 'Members', icon: Users },
                        { id: 'ministries' as PreviewTabId, label: 'Ministries', icon: Building2 },
                        { id: 'governance' as PreviewTabId, label: 'Governance', icon: ShieldCheck },
                      ].map((tab) => {
                        const Icon = tab.icon;
                        const isSelected = activePreviewTab === tab.id;
                        return (
                          <button
                            key={tab.id}
                            type="button"
                            role="tab"
                            aria-selected={isSelected}
                            onClick={() => setActivePreviewTab(tab.id)}
                            className={`py-2 px-2.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-white dark:bg-[#191E28] text-blue-600 dark:text-blue-400 shadow-2xs border border-slate-200/60 dark:border-white/[0.08]'
                                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                            }`}
                          >
                            <Icon className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{tab.label}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Preview Content Area (Honest module structure, no fabricated metrics) */}
                    <div className="min-h-[250px] rounded-xl bg-slate-50/80 dark:bg-[#0E1116] border border-slate-200/70 dark:border-white/[0.06] p-4 flex flex-col justify-between">
                      <AnimatePresence mode="wait">
                        {activePreviewTab === 'overview' && (
                          <motion.div
                            key="overview"
                            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
                            transition={{ duration: 0.2 }}
                            className="space-y-3"
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-xs font-bold text-slate-900 dark:text-white">
                                  Unified Navigation &amp; Module Hub
                                </p>
                                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                  Structured sidebar &amp; topbar workspace for daily operations
                                </p>
                              </div>
                              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                                Illustrative Layout
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                              {[
                                {
                                  title: 'Member & Family Profiles',
                                  desc: 'Directory records, household links & intake forms',
                                  icon: Users,
                                },
                                {
                                  title: 'Service Attendance & Events',
                                  desc: 'Check-in logs, calendars & event schedules',
                                  icon: Calendar,
                                },
                                {
                                  title: 'Pastoral Care & Visitations',
                                  desc: 'Prayer requests, counseling & shepherd follow-up',
                                  icon: HeartHandshake,
                                },
                                {
                                  title: 'Multi-Channel Dispatch',
                                  desc: 'Targeted announcements & group messaging',
                                  icon: Send,
                                },
                              ].map((item) => {
                                const ItemIcon = item.icon;
                                return (
                                  <div
                                    key={item.title}
                                    className="p-3 rounded-xl bg-white dark:bg-[#141820] border border-slate-200/80 dark:border-white/[0.07] flex items-start gap-2.5"
                                  >
                                    <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                                      <ItemIcon className="w-4 h-4" />
                                    </div>
                                    <div className="min-w-0">
                                      <p className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                                        {item.title}
                                      </p>
                                      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug mt-0.5">
                                        {item.desc}
                                      </p>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </motion.div>
                        )}

                        {activePreviewTab === 'members' && (
                          <motion.div
                            key="members"
                            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
                            transition={{ duration: 0.2 }}
                            className="space-y-3"
                          >
                            <div>
                              <p className="text-xs font-bold text-slate-900 dark:text-white">
                                Member Directory &amp; Household Records
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                Organized member profiles, family relationships, and onboarding review
                              </p>
                            </div>
                            <div className="space-y-2">
                              {[
                                {
                                  step: 'Public Registration Form',
                                  detail: 'Visitors and new members submit structured registration questionnaires online.',
                                },
                                {
                                  step: 'Approval & Campus Assignment',
                                  detail: 'Administrators review submissions and assign members to branches and ministries.',
                                },
                                {
                                  step: 'Household & Milestone Tracking',
                                  detail: 'Connect spouses, children, baptism records, and ministry participation.',
                                },
                              ].map((row) => (
                                <div
                                  key={row.step}
                                  className="p-2.5 rounded-xl bg-white dark:bg-[#141820] border border-slate-200/80 dark:border-white/[0.07] flex items-start gap-2.5"
                                >
                                  <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                                  <div>
                                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                                      {row.step}
                                    </p>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                      {row.detail}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}

                        {activePreviewTab === 'ministries' && (
                          <motion.div
                            key="ministries"
                            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
                            transition={{ duration: 0.2 }}
                            className="space-y-3"
                          >
                            <div>
                              <p className="text-xs font-bold text-slate-900 dark:text-white">
                                Ministries, Small Groups &amp; Campuses
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                Coordinate department leaders, fellowship groups, and branch activities
                              </p>
                            </div>
                            <div className="space-y-2">
                              {[
                                {
                                  step: 'Multi-Campus Branch Directory',
                                  detail: 'Manage branch locations, service schedules, and campus leadership.',
                                },
                                {
                                  step: 'Department & Group Rosters',
                                  detail: 'Organize worship, youth, outreach, and fellowship groups with dedicated leaders.',
                                },
                                {
                                  step: 'Bible & Daily Devotions',
                                  detail: 'Share scripture readings and daily devotionals across the congregation.',
                                },
                              ].map((row) => (
                                <div
                                  key={row.step}
                                  className="p-2.5 rounded-xl bg-white dark:bg-[#141820] border border-slate-200/80 dark:border-white/[0.07] flex items-start gap-2.5"
                                >
                                  <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                                  <div>
                                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                                      {row.step}
                                    </p>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                      {row.detail}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}

                        {activePreviewTab === 'governance' && (
                          <motion.div
                            key="governance"
                            initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
                            transition={{ duration: 0.2 }}
                            className="space-y-3"
                          >
                            <div>
                              <p className="text-xs font-bold text-slate-900 dark:text-white">
                                Role-Based Access &amp; Audit Integrity
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                Scoped permissions and verifiable administrative audit trails
                              </p>
                            </div>
                            <div className="space-y-2">
                              {[
                                {
                                  step: 'Role-Scoped Navigation',
                                  detail: 'Each role sees only the modules and actions authorized for their responsibilities.',
                                },
                                {
                                  step: 'Hash-Chained Security Audit Log',
                                  detail: 'Critical security and administrative events are recorded with integrity verification.',
                                },
                                {
                                  step: 'Active Session Management',
                                  detail: 'Administrators can review active sessions and revoke access when required.',
                                },
                              ].map((row) => (
                                <div
                                  key={row.step}
                                  className="p-2.5 rounded-xl bg-white dark:bg-[#141820] border border-slate-200/80 dark:border-white/[0.07] flex items-start gap-2.5"
                                >
                                  <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                                  <div>
                                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                                      {row.step}
                                    </p>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                      {row.detail}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Preview Footer Bar */}
                      <div className="pt-3 mt-3 border-t border-slate-200/80 dark:border-white/[0.07] flex items-center justify-between gap-2 text-[11px]">
                        <span className="text-slate-500 dark:text-slate-400">
                          Ready to access your workspace?
                        </span>
                        <button
                          type="button"
                          onClick={handleLogin}
                          className="font-semibold text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
                        >
                          <span>Open Portal</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            3. FEATURES SECTION (VERIFIED APPLICATION MODULES)
        ===================================================================== */}
        <section
          id="features"
          className="py-16 sm:py-24 bg-white dark:bg-[#0F1217] border-y border-slate-200/80 dark:border-white/[0.07] scroll-mt-16"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
            <div className="max-w-3xl mx-auto text-center space-y-3">
              <span className="inline-block text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Platform Capabilities
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
                Built for Every Aspect of Church Administration
              </h2>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                Every module in the Church Management System is designed to help leadership teams,
                administrators, and ministry coordinators work together in one organized platform.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {featureCards.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{
                      duration: 0.35,
                      delay: shouldReduceMotion ? 0 : (index % 4) * 0.06,
                      ease: 'easeOut',
                    }}
                    className="group p-6 rounded-2xl bg-slate-50/70 hover:bg-white dark:bg-[#141820] dark:hover:bg-[#181D27] border border-slate-200/80 hover:border-blue-500/40 dark:border-white/[0.07] dark:hover:border-blue-400/40 shadow-2xs hover:shadow-md transition-all duration-200 flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3.5">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200/60 dark:border-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <Icon className="w-5 h-5 stroke-[1.75]" />
                      </div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        {feature.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200/60 dark:border-white/[0.06] flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                      <span>{feature.moduleLabel}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* =====================================================================
            4. PLATFORM OVERVIEW SECTION (SPLIT LAYOUT)
        ===================================================================== */}
        <section id="about" className="py-16 sm:py-24 scroll-mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
              {/* Left Explanatory Column */}
              <motion.div
                initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
                className="lg:col-span-6 space-y-6"
              >
                <div className="space-y-3">
                  <span className="inline-block text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    Platform Overview
                  </span>
                  <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
                    One Organized System for Your Entire Ministry
                  </h2>
                  <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                    Instead of switching between disconnected tools for member lists, attendance sheets,
                    event calendars, and pastoral follow-ups, the Church Management System brings daily
                    operations into a single, structured interface.
                  </p>
                </div>

                <div className="space-y-4">
                  {overviewPoints.map((point) => (
                    <div
                      key={point.title}
                      className="p-4 rounded-xl bg-white dark:bg-[#12151B] border border-slate-200/80 dark:border-white/[0.08] flex items-start gap-3.5"
                    >
                      <div className="w-6 h-6 rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                          {point.title}
                        </h3>
                        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                          {point.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Right Architectural Illustration Card */}
              <motion.div
                initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.45, delay: 0.08, ease: 'easeOut' }}
                className="lg:col-span-6"
              >
                <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-[#12151B] border border-slate-200/90 dark:border-white/[0.1] shadow-lg space-y-6">
                  <div className="flex items-center justify-between border-b border-slate-200/80 dark:border-white/[0.08] pb-4">
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        Integrated Module Architecture
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Connected workflows across administration, care, and reporting
                      </p>
                    </div>
                    <FolderTree className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {[
                      {
                        category: 'Core Administration',
                        items: [
                          'Member Directory & Profiles',
                          'Households & Families',
                          'Multi-Campus Branches',
                          'Ministries & Small Groups',
                        ],
                      },
                      {
                        category: 'Operations & Engagement',
                        items: [
                          'Service & Group Attendance',
                          'Events & Dual Calendar',
                          'Multi-Channel Communications',
                          'Bible & Daily Devotions',
                        ],
                      },
                      {
                        category: 'Pastoral Care & Records',
                        items: [
                          'Prayer & Counseling Portal',
                          'Visitation & Shepherd Care',
                          'Asset & Facilities Registry',
                          'Document Vault & LMS',
                        ],
                      },
                      {
                        category: 'Governance & Insights',
                        items: [
                          'Approval Queue & Workflows',
                          'Executive & Demographic Reports',
                          'Role & Permission Matrix',
                          'Security Audit & Backups',
                        ],
                      },
                    ].map((group) => (
                      <div
                        key={group.category}
                        className="p-4 rounded-xl bg-slate-50 dark:bg-[#171B23] border border-slate-200/70 dark:border-white/[0.06] space-y-2.5"
                      >
                        <p className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                          {group.category}
                        </p>
                        <ul className="space-y-1.5">
                          {group.items.map((mod) => (
                            <li
                              key={mod}
                              className="text-xs text-slate-700 dark:text-slate-300 flex items-center gap-2"
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                              <span>{mod}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleFindGroup}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      <Compass className="w-4 h-4" />
                      <span>Explore Ministry Groups</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleGetStarted}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                    >
                      <span>Register as a Member</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            5. HOW IT WORKS SECTION (3 PROGRESSIVE STEPS)
        ===================================================================== */}
        <section
          id="how-it-works"
          className="py-16 sm:py-24 bg-white dark:bg-[#0F1217] border-y border-slate-200/80 dark:border-white/[0.07] scroll-mt-16"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
            <div className="max-w-2xl mx-auto text-center space-y-3">
              <span className="inline-block text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                How It Works
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
                Structured Workflow for Church Teams
              </h2>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
                A clear three-step approach to organizing your branches, congregation, and ongoing
                ministry activities.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
              {workflowSteps.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.step}
                    initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 18 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.25 }}
                    transition={{
                      duration: 0.4,
                      delay: shouldReduceMotion ? 0 : idx * 0.1,
                      ease: 'easeOut',
                    }}
                    className="p-6 sm:p-7 rounded-2xl bg-slate-50/80 dark:bg-[#141820] border border-slate-200/80 dark:border-white/[0.08] flex flex-col justify-between space-y-5"
                  >
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="w-11 h-11 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                          <Icon className="w-5 h-5" />
                        </div>
                        <span className="font-mono text-sm font-bold text-slate-400 dark:text-slate-500">
                          Step {item.step}
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                        {item.title}
                      </h3>

                      <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-200/70 dark:border-white/[0.06] flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-blue-400">
                      <span>
                        {idx === 0
                          ? 'Branches & Settings'
                          : idx === 1
                          ? 'Members & Registration'
                          : 'Attendance, Events & Reports'}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* =====================================================================
            6. TRUST, SECURITY & ROLE GOVERNANCE SECTION
        ===================================================================== */}
        <section id="security" className="py-16 sm:py-24 scroll-mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
            <div className="max-w-3xl mx-auto text-center space-y-3">
              <span className="inline-block text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Administration &amp; Access Control
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
                Accountable Governance &amp; Role-Based Security
              </h2>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                Protect sensitive member records and pastoral care notes with role-scoped access
                controls, session governance, and verifiable audit trails.
              </p>
            </div>

            {/* Security Capability Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {securityFeatures.map((sec, idx) => {
                const Icon = sec.icon;
                return (
                  <motion.div
                    key={sec.title}
                    initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 14 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{
                      duration: 0.35,
                      delay: shouldReduceMotion ? 0 : idx * 0.06,
                      ease: 'easeOut',
                    }}
                    className="p-5 rounded-2xl bg-white dark:bg-[#12151B] border border-slate-200/80 dark:border-white/[0.08] space-y-3"
                  >
                    <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-white/[0.06] text-slate-800 dark:text-slate-200 flex items-center justify-center">
                      <Icon className="w-4 h-4" />
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      {sec.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {sec.description}
                    </p>
                  </motion.div>
                );
              })}
            </div>

            {/* Role-Specific Portal Entry Points */}
            <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-[#12151B] border border-slate-200/90 dark:border-white/[0.08] space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                    Role-Based Portal Access
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                    Sign in to the portal tailored to your role within the church.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleStaffLogin}
                  className="self-start sm:self-auto px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/[0.06] dark:hover:bg-white/[0.1] text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
                >
                  Staff &amp; Leadership Sign In →
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {roleCards.map((item) => (
                  <div
                    key={item.role}
                    className="p-4 rounded-xl bg-slate-50 dark:bg-[#171B23] border border-slate-200/80 dark:border-white/[0.07] flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-1.5">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {item.title}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                        {item.summary}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRoleEntry(item.role)}
                      className="w-full py-2 px-3 rounded-lg bg-white hover:bg-slate-100 dark:bg-[#11141A] dark:hover:bg-white/[0.08] border border-slate-200 dark:border-white/[0.08] text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>Sign In as {item.title}</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            7. CONTACT & BRANCH INFORMATION (RENDERED WHEN CONFIGURED)
        ===================================================================== */}
        {hasRealContactInfo && (
          <section
            id="contact"
            className="py-12 sm:py-16 bg-white dark:bg-[#0F1217] border-t border-slate-200/80 dark:border-white/[0.07] scroll-mt-16"
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="p-6 sm:p-8 rounded-2xl bg-slate-50 dark:bg-[#141820] border border-slate-200/80 dark:border-white/[0.08] grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    Headquarters &amp; Contact
                  </span>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Main Campus Information
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Configured branch contact and service schedule details.
                  </p>
                </div>

                {contactAddress && (
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Location</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{contactAddress}</p>
                    </div>
                  </div>
                )}

                {(contactPhone || contactEmail) && (
                  <div className="flex items-start gap-3">
                    <Phone className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Contact</p>
                      {contactPhone && (
                        <p className="text-xs text-slate-600 dark:text-slate-400">{contactPhone}</p>
                      )}
                      {contactEmail && (
                        <p className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                          <Mail className="w-3 h-3 shrink-0" />
                          <span className="truncate">{contactEmail}</span>
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {serviceTimes && (
                  <div className="flex items-start gap-3">
                    <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        Service Schedule
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{serviceTimes}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}

        {/* =====================================================================
            8. FINAL CALL-TO-ACTION SECTION
        ===================================================================== */}
        <section className="py-16 sm:py-20">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
              className="p-8 sm:p-12 rounded-3xl bg-slate-900 dark:bg-[#141821] border border-slate-800 dark:border-white/[0.1] text-center space-y-6 shadow-xl"
            >
              <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
                Bring Your Church Administration Together.
              </h2>
              <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
                Access the member portal, submit a membership registration form, or sign in to your
                administrative workspace.
              </p>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleGetStarted}
                  className="px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleLogin}
                  className="px-7 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white border border-white/15 font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Sign In to Portal</span>
                </button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      {/* =====================================================================
          9. COMPACT FOOTER
      ===================================================================== */}
      <footer className="py-8 bg-white dark:bg-[#0B0D10] border-t border-slate-200/80 dark:border-white/[0.08] text-xs text-slate-600 dark:text-slate-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-950 flex items-center justify-center">
              <Layers className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-slate-900 dark:text-white">
              Church Management System
            </span>
            <span className="text-slate-400 dark:text-slate-600">•</span>
            <span>© {new Date().getFullYear()} Church Management System. All rights reserved.</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 font-medium">
            <button
              type="button"
              onClick={() => scrollToSection('features')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Features
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('about')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('security')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Security
            </button>
            <button
              type="button"
              onClick={handleGetStarted}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Register
            </button>
            <button
              type="button"
              onClick={handleLogin}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Login
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ChurchPeopleFrontpage;
