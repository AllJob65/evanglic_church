import React, { useState, useRef } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { AttendanceRecord } from '../types';
import { supabaseAttendanceService } from '../services/supabaseAttendanceService';
import { normalizeUserRole } from '../utils/rbac';
import { MemberAttendancePortal } from './Member/MemberAttendancePortal';
import { GroupLeaderQr } from './GroupLeader/GroupLeaderQr';
import {
  UserCheck,
  QrCode,
  Scan,
  Smartphone,
  Users,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle,
  Calendar,
  Clock,
  Building,
  Shield,
  Search,
  Download,
  Upload,
  Copy,
  Check,
  FileText,
  UserPlus,
  RefreshCw,
  Sparkles,
  Radio,
  History,
  ShieldAlert,
} from 'lucide-react';

export const AttendanceModule: React.FC = () => {
  const {
    members,
    attendanceRecords,
    recordAttendance,
    branches,
    ministries,
    addAuditLog,
    activeRole,
    userProfile,
  } = useCMMS();

  const userRole = normalizeUserRole((userProfile as any)?.role || activeRole);
  const isRegularMember = userRole === 'REGULAR_MEMBER';

  // If the logged-in user is a regular member, render the dedicated Member Attendance Portal
  // Members only see active attendance opportunities for their joined ministries (1-Click or Scan QR)
  // Ministry Attendance (manual roll call) and Excel Import are strictly hidden from members.
  if (isRegularMember) {
    return (
      <div className="space-y-6" id="member-attendance-view">
        {/* Member Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div>
            <div className="flex items-center gap-2">
              <UserCheck className="w-6 h-6 text-emerald-600" />
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">
                Member Attendance & Check-In Portal
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200">
                Active Verification
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Verify your attendance in active ministry sessions using 1-Click Web Check-In or by scanning your Group Leader's live dynamic QR code.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-2 rounded-xl text-xs font-semibold">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="text-slate-800 dark:text-slate-200">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          </div>
        </div>

        {/* Member Portal Component (Restricted to joined ministries, 1-click check-in, QR scan, personal history) */}
        <MemberAttendancePortal />
      </div>
    );
  }

  // -------------------------------------------------------------
  // MINISTRY LEADER & ADMIN ATTENDANCE MANAGEMENT SUITE
  // -------------------------------------------------------------
  const [activeTab, setActiveTab] = useState<
    'Leader Session & QR' | 'Ministry Attendance' | 'Excel Import' | 'Gate 1-Click & Scan' | 'Attendance Logs'
  >('Leader Session & QR');

  const [selectedMemberId, setSelectedMemberId] = useState(members[0]?.id || '');
  const [selectedService, setSelectedService] = useState('2nd Celebration Worship Service');
  const [checkInSuccess, setCheckInSuccess] = useState(false);

  // Manual Ministry Attendance state (Roster Roll Call)
  const [selectedMinistryId, setSelectedMinistryId] = useState<string>(ministries[0]?.id || 'min-1');
  const [ministryAttendanceDate, setMinistryAttendanceDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [ministryChecklist, setMinistryChecklist] = useState<Record<string, 'Present' | 'Absent' | 'Late'>>({});
  const [ministrySaveSuccess, setMinistrySaveSuccess] = useState(false);

  // Excel / CSV import state
  const [excelText, setExcelText] = useState('');
  const [importedCount, setImportedCount] = useState<number | null>(null);
  const [copiedSample, setCopiedSample] = useState(false);
  const [isProcessingImport, setIsProcessingImport] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Attendance log search & filter
  const [logSearchQuery, setLogSearchQuery] = useState('');
  const [logServiceFilter, setLogServiceFilter] = useState('All');

  // Sample CSV / Excel rows
  const SAMPLE_CSV_DATA = `Member Full Name, Date Attended, Ministry or Service, Status, Check-In Method, Notes`;

  const handleRecordGateCheckIn = async (method: 'Manual Web Click' | 'QR Code Scanning') => {
    const mem = members.find((m) => m.id === selectedMemberId);
    if (!mem) return;

    const newRec: AttendanceRecord = {
      id: `att-${Date.now().toString().slice(-4)}`,
      serviceName: selectedService,
      eventName: selectedService,
      serviceType: 'Sunday Main Service',
      branchId: mem.branchId,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      memberId: mem.id,
      memberName: `${mem.firstName} ${mem.lastName}`,
      checkInTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      checkInMethod: method,
      status: 'Present',
    };

    recordAttendance(newRec);

    try {
      await supabaseAttendanceService.recordAttendance(newRec);
    } catch (e) {
      console.warn('Attendance record synced locally, background Supabase sync notification:', e);
    }

    setCheckInSuccess(true);
    setTimeout(() => setCheckInSuccess(false), 2500);
  };

  const handleLoadSample = () => {
    setExcelText(SAMPLE_CSV_DATA.trim());
  };

  const handleCopySample = () => {
    navigator.clipboard.writeText(SAMPLE_CSV_DATA.trim());
    setCopiedSample(true);
    setTimeout(() => setCopiedSample(false), 2000);
  };

  const handleDownloadSampleCSV = () => {
    const blob = new Blob([SAMPLE_CSV_DATA.trim()], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CMMS_Attendance_Import_Sample_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadSampleXLS = () => {
    const rows = SAMPLE_CSV_DATA.trim().split('\n').map((line) => line.split(','));
    let xml = `<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="Attendance Import"><Table>`;
    rows.forEach((r) => {
      xml += '<Row>';
      r.forEach((cell) => {
        xml += `<Cell><Data ss:Type="String">${cell.trim()}</Data></Cell>`;
      });
      xml += '</Row>';
    });
    xml += '</Table></Worksheet></Workbook>';

    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CMMS_Attendance_Import_Sample_${new Date().toISOString().split('T')[0]}.xls`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setExcelText(content);
      }
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = () => {
    if (!excelText.trim()) return;
    setIsProcessingImport(true);

    const lines = excelText.split('\n').map((l) => l.trim()).filter(Boolean);
    let count = 0;

    lines.forEach((line, idx) => {
      if (idx === 0 && (line.toLowerCase().includes('member full name') || line.toLowerCase().includes('date attended'))) {
        return;
      }

      const parts = line.split(',').map((p) => p.trim());
      if (parts.length >= 1 && parts[0]) {
        const rawName = parts[0];
        const dateAttended = parts[1] || new Date().toISOString().split('T')[0];
        const ministryOrService = parts[2] || 'Sunday General Service';
        const status = (parts[3] as any) || 'Present';

        const matchedMember =
          members.find(
            (m) =>
              `${m.firstName} ${m.lastName}`.toLowerCase().includes(rawName.toLowerCase()) ||
              rawName.toLowerCase().includes(m.firstName.toLowerCase())
          ) || members[count % members.length];

        if (matchedMember) {
          const rec: AttendanceRecord = {
            id: `att-imp-${Date.now()}-${count}`,
            serviceName: ministryOrService,
            serviceType: 'Ministry Attendance',
            branchId: matchedMember.branchId,
            date: dateAttended,
            time: '09:30 AM',
            memberId: matchedMember.id,
            checkInTime: '09:30 AM',
            checkInMethod: 'Excel Import',
            status: status === 'Absent' ? 'Absent' : 'Present',
          };
          recordAttendance(rec);
          count++;
        }
      }
    });

    setIsProcessingImport(false);
    setImportedCount(count || lines.length);
    addAuditLog('Bulk Attendance Import', 'Attendance & Check-in', `Imported ${count} attendance records from CSV/XLS file.`);
    setTimeout(() => setImportedCount(null), 4000);
  };

  // Ministry roster members
  const currentMinistry = ministries.find((m) => m.id === selectedMinistryId) || ministries[0];
  const ministryMembers = members.filter(
    (m) =>
      (m.ministryIds || []).includes(selectedMinistryId) ||
      (m.ministriesJoinedNow || []).some(
        (name) => currentMinistry && name.toLowerCase().includes(currentMinistry.name.toLowerCase())
      )
  );

  const handleSaveMinistryAttendance = () => {
    let savedCount = 0;
    const targetMembers = ministryMembers.length > 0 ? ministryMembers : members.slice(0, 6);

    targetMembers.forEach((m) => {
      const status = ministryChecklist[m.id] || 'Present';
      const newRec: AttendanceRecord = {
        id: `att-min-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        serviceName: `${currentMinistry?.name || 'Ministry'} Roster Attendance`,
        serviceType: 'Ministry Attendance',
        branchId: m.branchId,
        date: ministryAttendanceDate,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        memberId: m.id,
        checkInTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        checkInMethod: 'Manual Headcount',
        status: status === 'Absent' ? 'Absent' : 'Present',
      };
      recordAttendance(newRec);
      savedCount++;
    });

    setMinistrySaveSuccess(true);
    addAuditLog(
      'Ministry Attendance Recorded',
      'Attendance Management',
      `Logged attendance for ${savedCount} members in ${currentMinistry?.name}.`
    );
    setTimeout(() => setMinistrySaveSuccess(false), 3000);
  };

  // Filtered attendance log
  const filteredAttendanceRecords = attendanceRecords.filter((rec) => {
    const matchesSearch =
      !logSearchQuery ||
      rec.memberName?.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
      rec.serviceName?.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
      rec.memberId?.toLowerCase().includes(logSearchQuery.toLowerCase());

    const matchesService =
      logServiceFilter === 'All' || rec.serviceName?.includes(logServiceFilter) || rec.serviceType?.includes(logServiceFilter);

    return matchesSearch && matchesService;
  });

  const atRiskMembers = members.filter((m) => m.attendanceScore < 75);

  return (
    <div className="space-y-6" id="ministry-leader-attendance-management">
      {/* Leader Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-purple-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Ministry Leader Attendance Management
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200">
              Leader & Staff Console
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Activate live QR attendance sessions, conduct ministry roll-call rosters, import Excel/CSV records, and manage check-in terminals.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-2 rounded-xl text-xs font-semibold">
          <Calendar className="w-4 h-4 text-slate-500" />
          <span className="text-slate-800 dark:text-slate-200">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
          </span>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
          {[
            { id: 'Leader Session & QR', label: '1. Create Session & Live QR', icon: QrCode },
            { id: 'Ministry Attendance', label: '2. Ministry Roster Roll Call', icon: Users },
            { id: 'Excel Import', label: '3. Excel / CSV Bulk Import', icon: FileSpreadsheet },
            { id: 'Gate 1-Click & Scan', label: '4. Sanctuary Gate Desk', icon: Scan },
            { id: 'Attendance Logs', label: '5. Master Attendance Records', icon: History },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`min-h-[44px] px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: Leader Live Dynamic QR & Session Creator */}
        {activeTab === 'Leader Session & QR' && (
          <div className="pt-4 space-y-4">
            <div className="p-4 bg-purple-50 dark:bg-purple-950/30 rounded-xl border border-purple-200 dark:border-purple-900/40 text-xs text-purple-900 dark:text-purple-200">
              <p className="font-bold flex items-center gap-1.5 mb-1">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Ministry Leader Live Session Activation
              </p>
              <p>
                Launch an instant or scheduled attendance session for your ministry group. A rotating 15-second dynamic QR code will be generated for projection or monitor display. Enrolled members will see this active session in their portal for 1-Click or QR verification.
              </p>
            </div>

            <GroupLeaderQr
              ministryId={selectedMinistryId}
              ministryName={currentMinistry?.name}
              serviceType="Ministry Gathering"
            />
          </div>
        )}

        {/* Tab 2: Ministry Roster Roll Call */}
        {activeTab === 'Ministry Attendance' && (
          <div className="pt-4 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-600" />
                  Manual Attendance Roster for Each Ministry
                </h4>
                <p className="text-xs text-slate-500">
                  Select a ministry department to take roll call and mark individual member attendance.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="date"
                  value={ministryAttendanceDate}
                  onChange={(e) => setMinistryAttendanceDate(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold"
                />
                <select
                  value={selectedMinistryId}
                  onChange={(e) => setSelectedMinistryId(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-slate-900 dark:text-white cursor-pointer"
                >
                  {ministries.map((min) => (
                    <option key={min.id} value={min.id}>
                      {min.name} ({min.category})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Ministry Members Roster Table */}
            <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900">
              <table className="cmms-data-table w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="p-3 whitespace-nowrap">Member Details</th>
                    <th className="p-3 whitespace-nowrap">Phone</th>
                    <th className="p-3 whitespace-nowrap">Branch</th>
                    <th className="p-3 text-center whitespace-nowrap">Attendance Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {(ministryMembers.length > 0 ? ministryMembers : members.slice(0, 8)).map((mem) => {
                    const currentStatus = ministryChecklist[mem.id] || 'Present';
                    return (
                      <tr key={mem.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="p-3 min-w-[180px]">
                          <div className="flex items-center gap-2.5">
                            <img src={mem.photoUrl} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
                            <div className="min-w-0">
                              <p className="font-bold text-slate-900 dark:text-white truncate">
                                {mem.title} {mem.firstName} {mem.lastName}
                              </p>
                              <p className="text-[10px] text-slate-500">{mem.memberIdNumber}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-3 font-mono text-slate-600 dark:text-slate-300 whitespace-nowrap">{mem.primaryPhone}</td>
                        <td className="p-3 text-slate-600 dark:text-slate-300 whitespace-nowrap">{mem.branchId}</td>
                        <td className="p-3 text-center whitespace-nowrap">
                          <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 gap-1">
                            <button
                              type="button"
                              onClick={() => setMinistryChecklist({ ...ministryChecklist, [mem.id]: 'Present' })}
                              className={`min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 whitespace-nowrap ${
                                currentStatus === 'Present'
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                              }`}
                            >
                              ✓ Present
                            </button>
                            <button
                              type="button"
                              onClick={() => setMinistryChecklist({ ...ministryChecklist, [mem.id]: 'Late' })}
                              className={`min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 whitespace-nowrap ${
                                currentStatus === 'Late'
                                  ? 'bg-amber-500 text-white shadow-xs'
                                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                              }`}
                            >
                              ⏱ Late
                            </button>
                            <button
                              type="button"
                              onClick={() => setMinistryChecklist({ ...ministryChecklist, [mem.id]: 'Absent' })}
                              className={`min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 whitespace-nowrap ${
                                currentStatus === 'Absent'
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                              }`}
                            >
                              ✗ Absent
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between pt-2">
              <p className="text-xs text-slate-500 font-semibold">
                Recording for: <span className="font-bold text-slate-900 dark:text-white">{currentMinistry?.name}</span> (
                {ministryMembers.length > 0 ? ministryMembers.length : 8} members)
              </p>
              <button
                onClick={handleSaveMinistryAttendance}
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-500/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Check className="w-4 h-4" /> Save Ministry Attendance
              </button>
            </div>

            {ministrySaveSuccess && (
              <div className="p-3 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Successfully saved attendance roster for {currentMinistry?.name}!
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Bulk Excel / CSV Import */}
        {activeTab === 'Excel Import' && (
          <div className="pt-4 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  Bulk Import Attendance (CSV or XLS)
                </h4>
                <p className="text-xs text-slate-500">
                  Import attendance logs with Member Full Name, Date Attended, and Service/Ministry Name.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleLoadSample}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300 text-xs font-bold border border-purple-200 dark:border-purple-800 flex items-center gap-1 hover:bg-purple-200 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" /> <span>Load Sample Data</span>
                </button>
                <button
                  onClick={handleDownloadSampleCSV}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 text-xs font-bold border border-blue-200 dark:border-blue-800 flex items-center gap-1 hover:bg-blue-200 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> <span>Sample CSV</span>
                </button>
                <button
                  onClick={handleDownloadSampleXLS}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800 flex items-center gap-1 hover:bg-emerald-200 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> <span>Sample XLS</span>
                </button>
                <button
                  onClick={handleCopySample}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-1 hover:bg-slate-300 cursor-pointer"
                >
                  {copiedSample ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSample ? 'Copied!' : 'Copy Sample'}</span>
                </button>
              </div>
            </div>

            {/* Sample Header Visual Guide */}
            <div className="p-4 bg-slate-100 dark:bg-slate-900/80 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-blue-500" /> Required CSV / Excel Header Structure
                </span>
                <span className="text-[10px] text-slate-500">Comma-separated or Excel Sheet</span>
              </div>
              <div className="overflow-x-auto font-mono text-[11px] bg-white dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200">
                Member Full Name, Date Attended, Ministry or Service, Status, Check-In Method, Notes
              </div>
            </div>

            {/* File Upload or Textarea Input */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Paste CSV Data or Upload File (.csv, .xls, .xlsx):
                </label>
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv, .xls, .xlsx, text/plain"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" /> Choose File from Computer
                  </button>
                </div>
              </div>

              <textarea
                rows={6}
                value={excelText}
                onChange={(e) => setExcelText(e.target.value)}
                placeholder="Member Full Name, Date Attended, Ministry or Service, Status, Check-In Method, Notes"
                className="w-full p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs text-slate-900 dark:text-white"
              />

              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  {excelText.trim() ? `${excelText.split('\n').filter(Boolean).length} rows ready to process` : 'No rows entered'}
                </span>
                <button
                  onClick={handleExecuteImport}
                  disabled={!excelText.trim() || isProcessingImport}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer"
                >
                  {isProcessingImport ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
                  Import & Register Attendance Records
                </button>
              </div>
            </div>

            {importedCount !== null && (
              <div className="p-3.5 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Successfully processed and registered {importedCount} attendance rows into the sovereign database!
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Sanctuary Gate / Greeter Desk Check-in */}
        {activeTab === 'Gate 1-Click & Scan' && (
          <div className="pt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Gate 1-Click */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4">
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200 flex items-center gap-1 w-fit">
                <UserCheck className="w-3.5 h-3.5" /> Greeter Desk 1-Click Verification
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Direct Member Gate Check-In</h4>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Service</label>
                  <select
                    value={selectedService}
                    onChange={(e) => setSelectedService(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                  >
                    <option value="1st Early Glory Service">1st Early Glory Service (06:30 AM - 08:30 AM)</option>
                    <option value="2nd Celebration Worship Service">2nd Celebration Worship Service (09:00 AM - 11:30 AM)</option>
                    <option value="3rd Youth Fire & Revival Service">3rd Youth Fire & Revival Service (02:00 PM - 04:30 PM)</option>
                    <option value="Midweek Wednesday Prayer Service">Midweek Wednesday Prayer Service</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Member</label>
                  <select
                    value={selectedMemberId}
                    onChange={(e) => setSelectedMemberId(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                  >
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName} ({m.memberIdNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => handleRecordGateCheckIn('Manual Web Click')}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <UserCheck className="w-4 h-4" /> Check In Selected Member
                </button>
              </div>
            </div>

            {/* Gate QR Scan Trigger */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-4 flex flex-col justify-between">
              <div>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200 flex items-center gap-1 w-fit">
                  <QrCode className="w-3.5 h-3.5" /> Gate Optical Terminal
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-2">Station Scanning Port</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Ready to receive scans from sanctuary access passes and member digital badges.
                </p>
              </div>

              <button
                onClick={() => handleRecordGateCheckIn('QR Code Scanning')}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all text-xs"
              >
                <QrCode className="w-4 h-4" /> Trigger Optical Gate Check-In
              </button>
            </div>
          </div>
        )}

        {/* Tab 5: Master Attendance Logs */}
        {activeTab === 'Attendance Logs' && (
          <div className="pt-4 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <History className="w-4 h-4 text-purple-600" />
                  Master Attendance Records & Audit Logs
                </h4>
                <p className="text-xs text-slate-500">
                  Showing {filteredAttendanceRecords.length} recorded check-ins across all services and ministries.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:flex-initial">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Search member, service..."
                    value={logSearchQuery}
                    onChange={(e) => setLogSearchQuery(e.target.value)}
                    className="w-full sm:w-56 min-h-[40px] pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-medium"
                  />
                </div>

                <select
                  value={logServiceFilter}
                  onChange={(e) => setLogServiceFilter(e.target.value)}
                  className="min-h-[40px] px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                >
                  <option value="All">All Services & Gatherings</option>
                  <option value="Service">Worship Services</option>
                  <option value="Ministry">Ministry Gatherings</option>
                </select>
              </div>
            </div>

            {/* Desktop & Tablet Table */}
            <div className="hidden md:block cmms-table-scroll overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="cmms-data-table w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-slate-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="p-3">Member Name</th>
                    <th className="p-3">Service / Ministry</th>
                    <th className="p-3 whitespace-nowrap">Date & Time</th>
                    <th className="p-3 whitespace-nowrap">Check-In Method</th>
                    <th className="p-3 text-right whitespace-nowrap">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredAttendanceRecords.slice(0, 15).map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-all">
                      <td className="p-3">
                        <span className="font-bold text-slate-900 dark:text-white">{rec.memberName || 'Congregant'}</span>
                        <span className="text-[10px] text-slate-400 block font-mono tabular-nums">{rec.memberId}</span>
                      </td>
                      <td className="p-3 font-semibold text-slate-700 dark:text-slate-300">
                        {rec.serviceName || rec.eventName || 'General Service'}
                      </td>
                      <td className="p-3 font-mono text-[11px] text-slate-500 whitespace-nowrap tabular-nums">
                        {rec.date} {rec.time ? `• ${rec.time}` : ''}
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 whitespace-nowrap">
                          {rec.checkInMethod || '1-Click Web Check-In'}
                        </span>
                      </td>
                      <td className="p-3 text-right whitespace-nowrap">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 whitespace-nowrap">
                          ✓ {rec.status || 'Present'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Stacked Cards (< 768px) */}
            <div className="md:hidden grid grid-cols-1 gap-2.5">
              {filteredAttendanceRecords.slice(0, 15).map((rec) => (
                <div
                  key={rec.id}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2 text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 dark:text-white truncate">
                        {rec.memberName || 'Congregant'}
                      </p>
                      <p className="text-[10px] font-mono text-slate-400 tabular-nums">{rec.memberId}</p>
                    </div>
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 whitespace-nowrap shrink-0">
                      ✓ {rec.status || 'Present'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px]">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Service</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {rec.serviceName || rec.eventName || 'General Service'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Date & Time</span>
                      <span className="font-mono text-slate-600 dark:text-slate-400 tabular-nums">
                        {rec.date} {rec.time ? `• ${rec.time}` : ''}
                      </span>
                    </div>
                    <div className="col-span-2">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                        {rec.checkInMethod || '1-Click Web Check-In'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {checkInSuccess && (
          <div className="mt-4 p-3 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-bounce">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            Check-In Recorded Successfully!
          </div>
        )}
      </div>

      {/* Critical Attendance Scoring & Pastoral Care Alerts (Leader Only) */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Attendance Scoring & Pastoral Care Alerts
          </h3>
          <span className="px-2 py-0.5 text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200 rounded-full">
            {atRiskMembers.length} Members Needing Follow-up
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {atRiskMembers.slice(0, 4).map((m) => (
            <div
              key={m.id}
              className="p-4 rounded-xl border border-amber-200 dark:border-amber-900 bg-amber-50/50 dark:bg-amber-950/30 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-3">
                <img src={m.photoUrl} alt="" className="w-10 h-10 rounded-xl object-cover" />
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    {m.title} {m.firstName} {m.lastName}
                  </h4>
                  <p className="text-[11px] text-slate-500">{m.primaryPhone}</p>
                  <p className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold mt-0.5">
                    Branch: {m.branchId}
                  </p>
                </div>
              </div>

              <div className="text-right space-y-1">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200">
                  {m.attendanceScore}% Score
                </span>
                <p className="text-[10px] text-slate-400">Absent 3+ weeks</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
