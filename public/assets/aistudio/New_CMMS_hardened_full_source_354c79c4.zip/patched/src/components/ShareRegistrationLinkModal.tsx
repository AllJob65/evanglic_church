import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  Link2,
  Copy,
  Check,
  QrCode,
  Download,
  Printer,
  Share2,
  Mail,
  MessageSquare,
  Send,
  RefreshCw,
  ShieldCheck,
  ShieldAlert,
  Clock,
  Building2,
  Users,
  Calendar,
  ExternalLink,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  FileSpreadsheet,
  Lock,
  Ban,
  Eye,
  ChevronRight,
  Smartphone,
  Info,
  History,
  Settings2,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { apiService } from '../services/api';
import {
  RegistrationInvitationRecord,
  RegistrationExpirationPreset,
  UserRole,
} from '../types';
import { normalizeUserRole } from '../utils/rbac';
import { EthiopianPhoneInput, validateEthiopianPhone } from './EthiopianPhoneInput';

export interface ShareRegistrationLinkModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialBranchId?: string;
}

type ModalTab = 'share' | 'configure' | 'history';
type DirectDispatchTab = 'none' | 'email' | 'sms';

export const ShareRegistrationLinkModal: React.FC<ShareRegistrationLinkModalProps> = ({
  isOpen,
  onClose,
  initialBranchId,
}) => {
  const { branches, ministries, systemName, churchName, addAuditLog } = useCMMS();
  const { userRole, branchId: userBranchId, branchIds: userBranchIds, userProfile } = useAuth();

  const normalizedRole: UserRole = normalizeUserRole(userRole || 'REGULAR_MEMBER');
  const isAuthorized = useMemo(() => {
    return (
      normalizedRole === 'SYSTEM_ADMIN' ||
      normalizedRole === 'MANAGER' ||
      normalizedRole === 'PASTOR' ||
      normalizedRole === 'MINISTRY_LEADER'
    );
  }, [normalizedRole]);

  const isGlobalCampusAccess = useMemo(() => {
    return (
      normalizedRole === 'SYSTEM_ADMIN' ||
      normalizedRole === 'MANAGER' ||
      (Array.isArray(userBranchIds) && userBranchIds.includes('*'))
    );
  }, [normalizedRole, userBranchIds]);

  // Modal Navigation & Responsive State
  const [activeTab, setActiveTab] = useState<ModalTab>('share');
  const [loading, setLoading] = useState<boolean>(false);
  const [generating, setGenerating] = useState<boolean>(false);
  const [revokingId, setRevokingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Invitations State from Real Backend Database
  const [invitations, setInvitations] = useState<(RegistrationInvitationRecord & { registrationUrl: string })[]>([]);
  const [selectedInvitation, setSelectedInvitation] = useState<(RegistrationInvitationRecord & { registrationUrl: string }) | null>(null);

  // Configuration Form State for Generating / Regenerating Links
  const [linkTitle, setLinkTitle] = useState<string>('Official Church Membership Registration Link');
  const [linkDescription, setLinkDescription] = useState<string>(
    'Public digital membership & fellowship onboarding invitation for new members and families.'
  );
  const [selectedBranchId, setSelectedBranchId] = useState<string>(
    initialBranchId || (isGlobalCampusAccess ? 'all' : userBranchId || 'br-1')
  );
  const [selectedMinistryId, setSelectedMinistryId] = useState<string>('');
  const [defaultRole, setDefaultRole] = useState<UserRole>('REGULAR_MEMBER');
  const [requiresApproval, setRequiresApproval] = useState<boolean>(true);
  const [singleUse, setSingleUse] = useState<boolean>(false);
  const [maxUsesInput, setMaxUsesInput] = useState<string>('');
  const [expirationPreset, setExpirationPreset] = useState<RegistrationExpirationPreset>('30d');
  const [customExpiresAt, setCustomExpiresAt] = useState<string>(() => {
    const d = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
    return d.toISOString().slice(0, 16);
  });

  // Copy & Share Feedback
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedMessage, setCopiedMessage] = useState<boolean>(false);

  // Direct Backend Dispatch (Email / SMS) State
  const [dispatchMode, setDispatchMode] = useState<DirectDispatchTab>('none');
  const [recipientEmail, setRecipientEmail] = useState<string>('');
  const [recipientPhone, setRecipientPhone] = useState<string>('');
  const [recipientName, setRecipientName] = useState<string>('');
  const [customShareNote, setCustomShareNote] = useState<string>('');
  const [dispatching, setDispatching] = useState<boolean>(false);

  // QR SVG Ref for PNG/SVG Download & Print
  const qrContainerRef = useRef<HTMLDivElement>(null);

  const showToast = (type: 'success' | 'error' | 'info', text: string) => {
    setToastMsg({ type, text });
    setTimeout(() => {
      setToastMsg((prev) => (prev?.text === text ? null : prev));
    }, 4000);
  };

  // Resolve real deployment origin (never hardcoded localhost in production)
  const clientOrigin = useMemo(() => {
    if (typeof window !== 'undefined' && window.location?.origin) {
      return window.location.origin.replace(/\/+$/, '');
    }
    return 'https://gracecathedral.org';
  }, []);

  // Load real invitations from backend when modal opens
  const loadInvitations = async () => {
    if (!isAuthorized) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await apiService.getRegistrationLinks({
        branchId: selectedBranchId !== 'all' ? selectedBranchId : undefined,
        origin: clientOrigin,
      });

      const list = Array.isArray(res.invitations) ? res.invitations : [];
      setInvitations(list);

      if (res.activeInvitation) {
        const withOrigin = {
          ...res.activeInvitation,
          registrationUrl: `${clientOrigin}/register/${res.activeInvitation.token}`,
        };
        setSelectedInvitation(withOrigin);
        setSelectedBranchId(withOrigin.branchId || 'all');
        setLinkTitle(withOrigin.title || 'Official Church Membership Registration Link');
        setRequiresApproval(withOrigin.requiresApproval ?? true);
        setSingleUse(withOrigin.singleUse ?? false);
        setExpirationPreset(withOrigin.expirationPreset || '30d');
      } else if (list.length > 0) {
        const firstActive = list.find((i) => i.status === 'active') || list[0];
        setSelectedInvitation({
          ...firstActive,
          registrationUrl: `${clientOrigin}/register/${firstActive.token}`,
        });
      }
    } catch (err: any) {
      console.error('[ShareRegistrationLinkModal] Failed to load invitations:', err);
      setErrorMsg(err?.message || 'Unable to load registration links from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && isAuthorized) {
      loadInvitations();
    }
  }, [isOpen, isAuthorized]);

  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Computed current registration URL (always points to /register/{token})
  const currentRegistrationUrl = selectedInvitation
    ? `${clientOrigin}/register/${selectedInvitation.token}`
    : '';

  const effectiveChurchTitle =
    selectedInvitation?.churchName ||
    systemName ||
    churchName ||
    'Grace Cathedral International';

  const effectiveBranchLabel =
    selectedInvitation?.branchName ||
    (selectedBranchId === 'all'
      ? 'All Campuses (Applicant Selects Branch)'
      : branches.find((b) => b.id === selectedBranchId)?.name || 'Headquarters Campus');

  const expirationDisplay = useMemo(() => {
    if (!selectedInvitation) return 'Not Set';
    if (!selectedInvitation.expiresAt) return 'Never Expires (Permanent Link)';
    const expDate = new Date(selectedInvitation.expiresAt);
    const diffMs = expDate.getTime() - Date.now();
    if (diffMs <= 0) return `Expired (${expDate.toLocaleDateString()})`;
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    const diffHours = Math.ceil(diffMs / (1000 * 60 * 60));
    const timeRemaining = diffDays > 1 ? `${diffDays} days left` : `${diffHours} hours left`;
    return `${expDate.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })} (${timeRemaining})`;
  }, [selectedInvitation]);

  const formattedShareInvitationText = useMemo(() => {
    if (!selectedInvitation || !currentRegistrationUrl) return '';
    const expNote = selectedInvitation.expiresAt
      ? `Valid until: ${new Date(selectedInvitation.expiresAt).toLocaleDateString()}`
      : 'Open for registration';
    return `Greetings from ${effectiveChurchTitle}!\n\nYou are warmly invited to complete your official Church Membership Registration (${effectiveBranchLabel}).\n\nRegister online here:\n${currentRegistrationUrl}\n\n${expNote}`;
  }, [selectedInvitation, currentRegistrationUrl, effectiveChurchTitle, effectiveBranchLabel]);

  // 1. Copy Link Handler with Fallback
  const handleCopyUrl = async () => {
    if (!currentRegistrationUrl) return;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(currentRegistrationUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = currentRegistrationUrl;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedLink(true);
      showToast('success', 'Registration link copied to clipboard!');
      addAuditLog(
        'Copied Registration Link',
        'Membership & Onboarding',
        `Copied registration link (${selectedInvitation?.token.slice(0, 10)}...) to clipboard`
      );
      setTimeout(() => setCopiedLink(false), 3000);
    } catch {
      showToast('error', 'Failed to copy link automatically. Please select and copy the URL.');
    }
  };

  // 2. Copy Full Invitation Message Handler
  const handleCopyFullMessage = async () => {
    if (!formattedShareInvitationText) return;
    try {
      await navigator.clipboard.writeText(formattedShareInvitationText);
      setCopiedMessage(true);
      showToast('success', 'Full invitation message copied to clipboard!');
      setTimeout(() => setCopiedMessage(false), 3000);
    } catch {
      showToast('error', 'Could not copy message.');
    }
  };

  // 3. Generate or Regenerate Registration Link
  const handleCreateOrRegenerateLink = async (revokePreviousActive: boolean) => {
    setGenerating(true);
    setErrorMsg(null);
    try {
      const parsedMax = singleUse
        ? 1
        : maxUsesInput.trim() !== ''
        ? Math.max(1, parseInt(maxUsesInput.trim(), 10) || 1)
        : null;

      const res = await apiService.createRegistrationLink({
        title: linkTitle.trim() || 'Official Church Membership Registration Link',
        description: linkDescription.trim(),
        branchId: selectedBranchId,
        ministryId: selectedMinistryId || undefined,
        defaultRole,
        requiresApproval,
        singleUse,
        maxUses: parsedMax,
        expirationPreset,
        customExpiresAt: expirationPreset === 'custom' ? new Date(customExpiresAt).toISOString() : undefined,
        revokePreviousActive,
        clientOrigin,
      });

      if (res.success && res.invitation) {
        const created = {
          ...res.invitation,
          registrationUrl: `${clientOrigin}/register/${res.invitation.token}`,
        };
        setSelectedInvitation(created);
        await loadInvitations();
        setActiveTab('share');
        showToast(
          'success',
          revokePreviousActive
            ? 'Previous link revoked and new registration link generated!'
            : 'New registration invitation link created and saved!'
        );
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to generate registration link.');
      showToast('error', err?.message || 'Failed to generate registration link.');
    } finally {
      setGenerating(false);
    }
  };

  // 4. Revoke Link Handler
  const handleRevokeInvitation = async (inv: RegistrationInvitationRecord) => {
    setRevokingId(inv.id);
    setErrorMsg(null);
    try {
      const res = await apiService.revokeRegistrationLink(
        inv.id,
        `Revoked by ${userProfile?.name || userProfile?.email || 'Administrator'}`
      );
      if (res.success) {
        showToast('info', `Registration link "${inv.title}" has been revoked.`);
        await loadInvitations();
        if (selectedInvitation?.id === inv.id) {
          setSelectedInvitation((prev) =>
            prev ? { ...prev, status: 'revoked', revokedAt: new Date().toISOString() } : null
          );
        }
      }
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to revoke registration link.');
    } finally {
      setRevokingId(null);
    }
  };

  // 5. Social & Native Share Handlers
  const handleWhatsAppShare = () => {
    if (!formattedShareInvitationText) return;
    addAuditLog(
      'Shared Registration Link via WhatsApp',
      'Membership & Onboarding',
      `Shared registration link (${selectedInvitation?.token.slice(0, 10)}...) on WhatsApp`
    );
    const waUrl = `https://wa.me/?text=${encodeURIComponent(formattedShareInvitationText)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  const handleTelegramShare = () => {
    if (!currentRegistrationUrl) return;
    addAuditLog(
      'Shared Registration Link via Telegram',
      'Membership & Onboarding',
      `Shared registration link (${selectedInvitation?.token.slice(0, 10)}...) on Telegram`
    );
    const tgText = `You are invited to register as a member at ${effectiveChurchTitle} (${effectiveBranchLabel}).`;
    const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(currentRegistrationUrl)}&text=${encodeURIComponent(tgText)}`;
    window.open(tgUrl, '_blank', 'noopener,noreferrer');
  };

  const handleNativeShare = async () => {
    if (!currentRegistrationUrl) return;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `${effectiveChurchTitle} – Member Registration`,
          text: `Complete your official church membership registration for ${effectiveBranchLabel}:`,
          url: currentRegistrationUrl,
        });
        addAuditLog(
          'Shared Registration Link via Native Share',
          'Membership & Onboarding',
          `Shared registration link (${selectedInvitation?.token.slice(0, 10)}...) via Web Share API`
        );
      } catch {
        // User cancelled share sheet
      }
    } else {
      handleCopyUrl();
    }
  };

  // 6. Direct Backend Email / SMS Dispatch Handler
  const handleDirectDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvitation) return;

    if (dispatchMode === 'email') {
      const cleanEmail = recipientEmail.trim();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        showToast('error', 'Please enter a valid recipient email address.');
        return;
      }
      setDispatching(true);
      try {
        const res = await apiService.dispatchRegistrationLink(selectedInvitation.id, {
          channel: 'EMAIL',
          recipient: cleanEmail,
          recipientName: recipientName.trim() || undefined,
          customMessage: customShareNote.trim() || undefined,
          clientOrigin,
        });
        if (res.success) {
          showToast('success', res.message || `Invitation email sent to ${cleanEmail}!`);
          setRecipientEmail('');
          setRecipientName('');
          setCustomShareNote('');
          setDispatchMode('none');
        } else {
          // Fallback to mailto client if SMTP is not configured in environment
          const subject = encodeURIComponent(`Official Membership Registration – ${effectiveChurchTitle}`);
          const body = encodeURIComponent(formattedShareInvitationText);
          window.location.href = `mailto:${cleanEmail}?subject=${subject}&body=${body}`;
          showToast('info', 'Opened default email client with pre-filled registration link.');
        }
      } catch (err: any) {
        const subject = encodeURIComponent(`Official Membership Registration – ${effectiveChurchTitle}`);
        const body = encodeURIComponent(formattedShareInvitationText);
        window.location.href = `mailto:${recipientEmail.trim()}?subject=${subject}&body=${body}`;
        showToast('info', 'Opened email client with registration invitation.');
      } finally {
        setDispatching(false);
      }
    } else if (dispatchMode === 'sms') {
      const phoneCheck = validateEthiopianPhone(recipientPhone);
      if (!phoneCheck.isValid) {
        showToast('error', phoneCheck.error || 'Please enter a valid Ethiopian mobile number.');
        return;
      }
      setDispatching(true);
      try {
        const res = await apiService.dispatchRegistrationLink(selectedInvitation.id, {
          channel: 'SMS',
          recipient: phoneCheck.normalized || recipientPhone.trim(),
          recipientName: recipientName.trim() || undefined,
          customMessage: customShareNote.trim() || undefined,
          clientOrigin,
        });
        if (res.success) {
          showToast('success', res.message || `Invitation SMS dispatched to ${recipientPhone}!`);
          setRecipientPhone('');
          setRecipientName('');
          setCustomShareNote('');
          setDispatchMode('none');
        } else {
          // Fallback to native SMS URI
          const smsUri = `sms:${phoneCheck.normalized || recipientPhone.trim()}?body=${encodeURIComponent(formattedShareInvitationText)}`;
          window.location.href = smsUri;
          showToast('info', 'Opened SMS app with registration link.');
        }
      } catch {
        const smsUri = `sms:${recipientPhone.trim()}?body=${encodeURIComponent(formattedShareInvitationText)}`;
        window.location.href = smsUri;
        showToast('info', 'Opened SMS app with registration link.');
      } finally {
        setDispatching(false);
      }
    }
  };

  // 7. Download QR Code as High-Resolution PNG
  const handleDownloadQrPng = () => {
    if (!qrContainerRef.current || !selectedInvitation) return;
    const svgElement = qrContainerRef.current.querySelector('svg');
    if (!svgElement) return;

    const svgData = new XMLSerializer().serializeToString(svgElement);
    const canvas = document.createElement('canvas');
    const size = 1024;
    canvas.width = size;
    canvas.height = size + 180;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      // White card background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Header bar
      ctx.fillStyle = '#4c1d95';
      ctx.fillRect(0, 0, canvas.width, 96);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 30px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(effectiveChurchTitle, canvas.width / 2, 50);
      ctx.font = '20px sans-serif';
      ctx.fillStyle = '#e9d5ff';
      ctx.fillText(effectiveBranchLabel, canvas.width / 2, 80);

      // Draw QR code centered
      const qrSize = 780;
      const qrOffset = (size - qrSize) / 2;
      ctx.drawImage(img, qrOffset, 130, qrSize, qrSize);

      // Footer text
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 24px sans-serif';
      ctx.fillText('Scan to Complete Official Membership Registration', canvas.width / 2, size + 70);

      ctx.fillStyle = '#64748b';
      ctx.font = '18px monospace';
      ctx.fillText(currentRegistrationUrl, canvas.width / 2, size + 115);

      URL.revokeObjectURL(url);

      const pngUrl = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = `Grace-Cathedral-Registration-QR-${selectedInvitation.token.slice(0, 10)}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);

      addAuditLog(
        'Downloaded Registration QR Code',
        'Membership & Onboarding',
        `Downloaded high-resolution PNG QR code for registration link (${selectedInvitation.token.slice(0, 10)}...)`
      );
      showToast('success', 'High-resolution QR Code PNG downloaded!');
    };
    img.src = url;
  };

  // 8. Print QR Code Poster
  const handlePrintQr = () => {
    if (!qrContainerRef.current || !selectedInvitation) return;
    const svgElement = qrContainerRef.current.querySelector('svg');
    if (!svgElement) return;
    const svgData = new XMLSerializer().serializeToString(svgElement);

    const printWin = window.open('', '_blank', 'width=800,height=900');
    if (!printWin) {
      showToast('error', 'Pop-up blocked. Please allow pop-ups to print the QR poster.');
      return;
    }

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${effectiveChurchTitle} – Member Registration QR Poster</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              margin: 0;
              padding: 40px;
              text-align: center;
              color: #0f172a;
            }
            .poster {
              max-width: 560px;
              margin: 0 auto;
              border: 3px solid #6d28d9;
              border-radius: 28px;
              padding: 40px 32px;
            }
            .badge {
              display: inline-block;
              background: #f3e8ff;
              color: #6d28d9;
              font-weight: 800;
              font-size: 12px;
              text-transform: uppercase;
              letter-spacing: 1.5px;
              padding: 6px 16px;
              border-radius: 999px;
              margin-bottom: 12px;
            }
            h1 {
              margin: 0 0 8px;
              font-size: 28px;
              font-weight: 900;
              color: #1e1b4b;
            }
            h2 {
              margin: 0 0 28px;
              font-size: 16px;
              font-weight: 600;
              color: #475569;
            }
            .qr-box {
              display: inline-block;
              padding: 24px;
              border: 2px dashed #cbd5e1;
              border-radius: 24px;
              background: #ffffff;
              margin-bottom: 24px;
            }
            .qr-box svg {
              width: 300px !important;
              height: 300px !important;
            }
            .url-box {
              background: #f8fafc;
              border: 1px solid #e2e8f0;
              border-radius: 12px;
              padding: 12px 16px;
              font-family: monospace;
              font-size: 13px;
              word-break: break-all;
              color: #334155;
              margin-top: 16px;
            }
            .meta {
              margin-top: 20px;
              font-size: 12px;
              color: #64748b;
            }
          </style>
        </head>
        <body>
          <div class="poster">
            <div class="badge">Official Member Onboarding</div>
            <h1>${effectiveChurchTitle}</h1>
            <h2>${effectiveBranchLabel}</h2>
            <div class="qr-box">${svgData}</div>
            <p style="font-size: 18px; font-weight: 800; margin: 0 0 6px;">Scan with Your Phone Camera to Register</p>
            <p style="font-size: 13px; color: #64748b; margin: 0;">Complete your membership & fellowship profile directly on your mobile device.</p>
            <div class="url-box">${currentRegistrationUrl}</div>
            <div class="meta">Invitation Status: Active • ${expirationDisplay}</div>
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 250);
            };
          </script>
        </body>
      </html>
    `);
    printWin.document.close();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/75 backdrop-blur-sm p-0 sm:p-4 md:p-6 overflow-y-auto animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="share-registration-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {/* Responsive Modal Container:
          - Mobile (320px-767px): Nearly full-screen bottom sheet (w-full max-h-[95dvh] rounded-t-3xl)
          - Tablet (768px-1023px): Centered modal (sm:max-w-2xl md:max-w-3xl sm:rounded-3xl)
          - Desktop (1024px+): Two-column capable wide modal (lg:max-w-5xl sm:max-h-[90vh]) */}
      <div className="w-full sm:max-w-2xl md:max-w-3xl lg:max-w-5xl max-h-[95dvh] sm:max-h-[90vh] bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border-t sm:border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 sm:zoom-in-95 duration-200">
        {/* Mobile Drag Handle Indicator */}
        <div className="sm:hidden flex justify-center pt-2.5 pb-1 bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900">
          <div className="w-12 h-1.5 rounded-full bg-white/30" />
        </div>

        {/* Top Header Banner */}
        <div className="px-4 py-4 sm:px-6 sm:py-5 bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white shrink-0">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-white/20 shrink-0 shadow-inner">
                <FileSpreadsheet className="w-5 h-5 sm:w-6 sm:h-6 text-purple-200" />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/30 text-purple-200 border border-purple-400/30">
                    Real-Time Onboarding Link
                  </span>
                  {selectedInvitation && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
                        selectedInvitation.status === 'active'
                          ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-400/40'
                          : selectedInvitation.status === 'revoked'
                          ? 'bg-rose-500/30 text-rose-200 border border-rose-400/40'
                          : 'bg-amber-500/30 text-amber-200 border border-amber-400/40'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          selectedInvitation.status === 'active'
                            ? 'bg-emerald-400 animate-pulse'
                            : selectedInvitation.status === 'revoked'
                            ? 'bg-rose-400'
                            : 'bg-amber-400'
                        }`}
                      />
                      {selectedInvitation.status}
                    </span>
                  )}
                </div>
                <h2
                  id="share-registration-modal-title"
                  className="text-base sm:text-xl font-black tracking-tight truncate mt-0.5"
                >
                  Share Member Registration Link
                </h2>
                <p className="text-[11px] sm:text-xs text-purple-200/90 truncate">
                  {effectiveChurchTitle} • {effectiveBranchLabel}
                </p>
              </div>
            </div>

            {/* Accessible Touch-Friendly Close Button (min 44x44px) */}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close registration link modal"
              className="min-w-[44px] min-h-[44px] rounded-2xl bg-white/10 hover:bg-white/20 active:scale-95 flex items-center justify-center text-white transition-all cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Sub-Tabs */}
          {isAuthorized && (
            <div className="flex items-center gap-1.5 mt-4 pt-3 border-t border-white/10 overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setActiveTab('share')}
                className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                  activeTab === 'share'
                    ? 'bg-white text-purple-950 shadow-sm'
                    : 'bg-white/10 text-purple-100 hover:bg-white/20'
                }`}
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share Link & QR Code</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('configure')}
                className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                  activeTab === 'configure'
                    ? 'bg-white text-purple-950 shadow-sm'
                    : 'bg-white/10 text-purple-100 hover:bg-white/20'
                }`}
              >
                <Settings2 className="w-3.5 h-3.5" />
                <span>Generate / Configure Link</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('history')}
                className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                  activeTab === 'history'
                    ? 'bg-white text-purple-950 shadow-sm'
                    : 'bg-white/10 text-purple-100 hover:bg-white/20'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>Active & Past Links ({invitations.length})</span>
              </button>
            </div>
          )}
        </div>

        {/* Toast Notification Banner */}
        {toastMsg && (
          <div
            className={`px-4 py-2.5 text-xs font-bold flex items-center justify-between gap-2 shrink-0 animate-in fade-in ${
              toastMsg.type === 'success'
                ? 'bg-emerald-600 text-white'
                : toastMsg.type === 'error'
                ? 'bg-rose-600 text-white'
                : 'bg-indigo-600 text-white'
            }`}
          >
            <div className="flex items-center gap-2">
              {toastMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{toastMsg.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setToastMsg(null)}
              className="p-1 hover:bg-white/20 rounded-lg cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Unauthorized Guard */}
        {!isAuthorized ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <Lock className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Authorized Access Required
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
              Only authorized church administrators, operations managers, pastors, and ministry leaders can generate or manage public member registration links.
            </p>
          </div>
        ) : (
          /* Scrollable Body */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
            {errorMsg && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* ========================================================= */}
            {/* TAB 1: SHARE LINK, QR CODE & DIRECT DISPATCH */}
            {/* ========================================================= */}
            {activeTab === 'share' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
                {/* Left Column (7 cols on Desktop): URL Box, Sharing Channels, Direct Dispatch & Metadata */}
                <div className="lg:col-span-7 space-y-5 min-w-0">
                  {/* Campus Selector Quick Switch */}
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <label
                        htmlFor="quick-campus-select"
                        className="text-xs font-extrabold text-slate-800 dark:text-slate-200 flex items-center gap-1.5"
                      >
                        <Building2 className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        <span>Target Campus / Branch Context</span>
                      </label>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        Pre-assigns applicant branch automatically
                      </span>
                    </div>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                      <select
                        id="quick-campus-select"
                        value={selectedBranchId}
                        disabled={!isGlobalCampusAccess || generating}
                        onChange={async (e) => {
                          const nextBranch = e.target.value;
                          setSelectedBranchId(nextBranch);
                          // Check if we already have an active link for this branch
                          const match = invitations.find(
                            (inv) => inv.status === 'active' && inv.branchId === nextBranch
                          );
                          if (match) {
                            setSelectedInvitation({
                              ...match,
                              registrationUrl: `${clientOrigin}/register/${match.token}`,
                            });
                          } else {
                            // Automatically generate a real database-backed link for the chosen branch
                            setGenerating(true);
                            try {
                              const bName =
                                nextBranch === 'all'
                                  ? 'Official Church Membership Registration Link'
                                  : `${branches.find((b) => b.id === nextBranch)?.name || 'Campus'} – Membership Registration Link`;
                              const res = await apiService.createRegistrationLink({
                                title: bName,
                                branchId: nextBranch,
                                requiresApproval,
                                singleUse,
                                expirationPreset,
                                clientOrigin,
                              });
                              if (res.success && res.invitation) {
                                const created = {
                                  ...res.invitation,
                                  registrationUrl: `${clientOrigin}/register/${res.invitation.token}`,
                                };
                                setSelectedInvitation(created);
                                await loadInvitations();
                                showToast('success', `Generated active registration link for ${created.branchName}`);
                              }
                            } catch (err: any) {
                              showToast('error', err?.message || 'Failed to switch branch link.');
                            } finally {
                              setGenerating(false);
                            }
                          }
                        }}
                        className="flex-1 min-h-[44px] px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                      >
                        {isGlobalCampusAccess && (
                          <option value="all">
                            All Campuses (Applicant Chooses Branch on Form)
                          </option>
                        )}
                        {branches
                          .filter(
                            (b) =>
                              isGlobalCampusAccess ||
                              userBranchIds.includes(b.id) ||
                              b.id === userBranchId
                          )
                          .map((b) => (
                            <option key={b.id} value={b.id}>
                              {b.name} — {b.city}
                            </option>
                          ))}
                      </select>

                      <button
                        type="button"
                        disabled={generating}
                        onClick={() => handleCreateOrRegenerateLink(true)}
                        title="Revoke current link and generate a new cryptographic token"
                        className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-purple-100 hover:bg-purple-200 dark:bg-purple-950/80 dark:hover:bg-purple-900 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shrink-0 disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${generating ? 'animate-spin' : ''}`} />
                        <span>Regenerate Link</span>
                      </button>
                    </div>
                  </div>

                  {/* Real Public Registration Link Display & Copy Box */}
                  <div className="p-4 rounded-2xl bg-purple-50/70 dark:bg-purple-950/25 border border-purple-200 dark:border-purple-800/80 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-[11px] font-black uppercase tracking-wider text-purple-800 dark:text-purple-300 flex items-center gap-1.5">
                        <Link2 className="w-3.5 h-3.5" />
                        Unique Public Registration Link
                      </span>
                      <a
                        href={currentRegistrationUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
                      >
                        <span>Open Live Form</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    {/* URL Box — readable, selectable, no horizontal page overflow */}
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <div className="flex-1 min-w-0 px-3.5 py-3 rounded-xl bg-white dark:bg-slate-900 border border-purple-200 dark:border-slate-700 font-mono text-xs text-slate-800 dark:text-slate-200 break-all select-all shadow-2xs">
                        {loading ? 'Generating secure registration token...' : currentRegistrationUrl}
                      </div>

                      <button
                        type="button"
                        onClick={handleCopyUrl}
                        disabled={!currentRegistrationUrl || loading}
                        className={`min-h-[44px] px-5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm shrink-0 ${
                          copiedLink
                            ? 'bg-emerald-600 text-white'
                            : 'bg-purple-600 hover:bg-purple-700 active:scale-95 text-white'
                        }`}
                      >
                        {copiedLink ? (
                          <>
                            <Check className="w-4 h-4" />
                            <span>Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            <span>Copy Link</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Secondary Copy Full Invitation Text Button */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <span className="text-[11px] text-slate-600 dark:text-slate-400">
                        Token ID:{' '}
                        <code className="font-mono font-bold text-purple-700 dark:text-purple-300">
                          {selectedInvitation?.token.slice(0, 16)}...
                        </code>
                      </span>
                      <button
                        type="button"
                        onClick={handleCopyFullMessage}
                        className="text-[11px] font-bold text-purple-700 dark:text-purple-300 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        {copiedMessage ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-600 dark:text-emerald-400">
                              Invitation Text Copied!
                            </span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy Full Invitation Message</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Multi-Channel Sharing Actions (Touch-Friendly >=44px Buttons) */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      Share Registration Invitation Via
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                      {/* WhatsApp */}
                      <button
                        type="button"
                        onClick={handleWhatsAppShare}
                        className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                      >
                        <MessageSquare className="w-4 h-4 shrink-0" />
                        <span>Share via WhatsApp</span>
                      </button>

                      {/* Telegram */}
                      <button
                        type="button"
                        onClick={handleTelegramShare}
                        className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                      >
                        <Send className="w-4 h-4 shrink-0" />
                        <span>Share via Telegram</span>
                      </button>

                      {/* Email Dispatch Toggle */}
                      <button
                        type="button"
                        onClick={() => setDispatchMode(dispatchMode === 'email' ? 'none' : 'email')}
                        className={`min-h-[44px] px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                          dispatchMode === 'email'
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <Mail className="w-4 h-4 text-indigo-500 shrink-0" />
                        <span>Send via Email</span>
                      </button>

                      {/* SMS Dispatch Toggle */}
                      <button
                        type="button"
                        onClick={() => setDispatchMode(dispatchMode === 'sms' ? 'none' : 'sms')}
                        className={`min-h-[44px] px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                          dispatchMode === 'sms'
                            ? 'bg-purple-600 text-white border-purple-600'
                            : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <Smartphone className="w-4 h-4 text-purple-500 shrink-0" />
                        <span>Send via SMS</span>
                      </button>

                      {/* Native Mobile / OS Share Sheet */}
                      <button
                        type="button"
                        onClick={handleNativeShare}
                        className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer sm:col-span-2 md:col-span-1"
                      >
                        <Share2 className="w-4 h-4 text-purple-600 shrink-0" />
                        <span>More Share Options</span>
                      </button>
                    </div>
                  </div>

                  {/* Direct Email or SMS Dispatch Drawer */}
                  {dispatchMode !== 'none' && (
                    <form
                      onSubmit={handleDirectDispatch}
                      className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-indigo-200 dark:border-indigo-900/60 space-y-3 animate-in fade-in"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                          {dispatchMode === 'email' ? (
                            <>
                              <Mail className="w-4 h-4 text-indigo-600" />
                              <span>Send Official Registration Invitation via Email</span>
                            </>
                          ) : (
                            <>
                              <Smartphone className="w-4 h-4 text-purple-600" />
                              <span>Send Official Registration Invitation via SMS</span>
                            </>
                          )}
                        </span>
                        <button
                          type="button"
                          onClick={() => setDispatchMode('none')}
                          className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                            Recipient Name (Optional)
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Brother Dawit"
                            value={recipientName}
                            onChange={(e) => setRecipientName(e.target.value)}
                            className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                          />
                        </div>

                        {dispatchMode === 'email' ? (
                          <div>
                            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                              Recipient Email Address *
                            </label>
                            <input
                              type="email"
                              required
                              placeholder="applicant@example.com"
                              value={recipientEmail}
                              onChange={(e) => setRecipientEmail(e.target.value)}
                              className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                            />
                          </div>
                        ) : (
                          <div>
                            <EthiopianPhoneInput
                              label="Recipient Mobile Phone"
                              required
                              value={recipientPhone}
                              onChange={(e) => setRecipientPhone(e.target.value)}
                              placeholder="0911234567"
                              showQuickPrefixes={false}
                            />
                          </div>
                        )}
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                          Personal Welcome Note (Optional — link is appended automatically)
                        </label>
                        <textarea
                          rows={2}
                          placeholder="We were blessed to have you worship with us! Please use this link to complete your membership profile."
                          value={customShareNote}
                          onChange={(e) => setCustomShareNote(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                        />
                      </div>

                      <div className="flex justify-end gap-2">
                        <button
                          type="submit"
                          disabled={dispatching}
                          className="min-h-[44px] px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>
                            {dispatching
                              ? 'Dispatching...'
                              : dispatchMode === 'email'
                              ? 'Send Email Invitation'
                              : 'Send SMS Invitation'}
                          </span>
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Link Metadata & Governance Summary Grid */}
                  {selectedInvitation && (
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          Invitation Security & Governance Metadata
                        </span>
                        {selectedInvitation.status === 'active' && (
                          <button
                            type="button"
                            onClick={() => handleRevokeInvitation(selectedInvitation)}
                            disabled={revokingId === selectedInvitation.id}
                            className="text-[11px] font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 flex items-center gap-1 cursor-pointer"
                          >
                            <Ban className="w-3 h-3" />
                            <span>Revoke Link</span>
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-bold uppercase text-slate-400 block">
                            Link Status
                          </span>
                          <span
                            className={`font-extrabold capitalize ${
                              selectedInvitation.status === 'active'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-rose-600 dark:text-rose-400'
                            }`}
                          >
                            {selectedInvitation.status}
                          </span>
                        </div>

                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-bold uppercase text-slate-400 block">
                            Approval Workflow
                          </span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">
                            {selectedInvitation.requiresApproval
                              ? 'Pending Pastoral Review'
                              : 'Auto-Approve Active'}
                          </span>
                        </div>

                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-bold uppercase text-slate-400 block">
                            Usage Limit
                          </span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">
                            {selectedInvitation.usesCount} used /{' '}
                            {selectedInvitation.singleUse
                              ? '1 (Single-Use)'
                              : selectedInvitation.maxUses
                              ? `${selectedInvitation.maxUses} max`
                              : 'Unlimited'}
                          </span>
                        </div>

                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 sm:col-span-2">
                          <span className="text-[10px] font-bold uppercase text-slate-400 block">
                            Expiration Schedule
                          </span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">
                            {expirationDisplay}
                          </span>
                        </div>

                        <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
                          <span className="text-[10px] font-bold uppercase text-slate-400 block">
                            Created By
                          </span>
                          <span className="font-bold text-slate-800 dark:text-slate-200 truncate block">
                            {selectedInvitation.createdByName}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Column (5 cols on Desktop): Real Scannable QR Code Card & Download/Print */}
                <div className="lg:col-span-5">
                  <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex flex-col items-center text-center space-y-4">
                    <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-purple-700 dark:text-purple-300">
                      <QrCode className="w-4 h-4" />
                      <span>Instant Mobile QR Registration</span>
                    </div>

                    {/* QR Canvas Wrapper */}
                    <div
                      ref={qrContainerRef}
                      className="p-5 bg-white rounded-3xl border-2 border-purple-200 shadow-md inline-flex flex-col items-center justify-center"
                    >
                      {currentRegistrationUrl ? (
                        <QRCodeSVG
                          value={currentRegistrationUrl}
                          size={200}
                          level="H"
                          includeMargin={true}
                          fgColor="#1e1b4b"
                          bgColor="#ffffff"
                        />
                      ) : (
                        <div className="w-[200px] h-[200px] flex items-center justify-center text-xs text-slate-400">
                          Generating QR...
                        </div>
                      )}
                      <span className="mt-2 text-[10px] font-mono font-bold text-slate-500">
                        Scan with Phone Camera
                      </span>
                    </div>

                    <div className="space-y-1 max-w-xs">
                      <p className="text-xs font-extrabold text-slate-900 dark:text-white">
                        {effectiveChurchTitle}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                        Project this QR code on sanctuary screens or print for welcome desks so visitors can register on their phones.
                      </p>
                    </div>

                    {/* Download & Print QR Buttons (Touch-Friendly >=44px) */}
                    <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      <button
                        type="button"
                        onClick={handleDownloadQrPng}
                        disabled={!currentRegistrationUrl}
                        className="min-h-[44px] px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                      >
                        <Download className="w-4 h-4 shrink-0" />
                        <span>Download QR (PNG)</span>
                      </button>

                      <button
                        type="button"
                        onClick={handlePrintQr}
                        disabled={!currentRegistrationUrl}
                        className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                      >
                        <Printer className="w-4 h-4 shrink-0 text-purple-600" />
                        <span>Print QR Poster</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* TAB 2: CONFIGURE & GENERATE NEW INVITATION LINK */}
            {/* ========================================================= */}
            {activeTab === 'configure' && (
              <div className="max-w-3xl mx-auto space-y-5">
                <div className="p-4 rounded-2xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/80 flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400 shrink-0 mt-0.5" />
                  <div className="text-xs space-y-1">
                    <p className="font-extrabold text-slate-900 dark:text-white">
                      Configure Custom Registration Link Parameters
                    </p>
                    <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                      Customize expiration windows, single-use vs. multi-use capacity, target campus/ministry assignment, and whether submissions require pastoral approval before activating.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Invitation Campaign / Link Title *
                    </label>
                    <input
                      type="text"
                      value={linkTitle}
                      onChange={(e) => setLinkTitle(e.target.value)}
                      placeholder="e.g. Sunday First-Timers & New Members Registration"
                      className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Assigned Campus / Branch *
                    </label>
                    <select
                      value={selectedBranchId}
                      disabled={!isGlobalCampusAccess}
                      onChange={(e) => setSelectedBranchId(e.target.value)}
                      className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    >
                      {isGlobalCampusAccess && (
                        <option value="all">All Campuses (Applicant Selects Branch)</option>
                      )}
                      {branches.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name} ({b.city})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Pre-Selected Ministry / Department (Optional)
                    </label>
                    <select
                      value={selectedMinistryId}
                      onChange={(e) => setSelectedMinistryId(e.target.value)}
                      className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                    >
                      <option value="">General Membership (All Ministries Available)</option>
                      {ministries.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} ({m.category})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Link Expiration Period *
                    </label>
                    <select
                      value={expirationPreset}
                      onChange={(e) => setExpirationPreset(e.target.value as RegistrationExpirationPreset)}
                      className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                    >
                      <option value="24h">24 Hours (1 Day)</option>
                      <option value="7d">7 Days (1 Week)</option>
                      <option value="30d">30 Days (1 Month)</option>
                      <option value="custom">Custom Expiration Date & Time</option>
                      <option value="never">Never Expires (Until Manually Revoked)</option>
                    </select>
                  </div>

                  {expirationPreset === 'custom' ? (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Custom Expiration Date & Time *
                      </label>
                      <input
                        type="datetime-local"
                        value={customExpiresAt}
                        onChange={(e) => setCustomExpiresAt(e.target.value)}
                        className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Usage Mode (Single-Use vs Multi-Use)
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setSingleUse(false)}
                          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            !singleUse
                              ? 'bg-purple-600 text-white border-purple-600'
                              : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          Multiple-Use Link
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setSingleUse(true);
                            setMaxUsesInput('1');
                          }}
                          className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            singleUse
                              ? 'bg-purple-600 text-white border-purple-600'
                              : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          Single-Use Only
                        </button>
                      </div>
                    </div>
                  )}

                  {!singleUse && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                        Max Registrations Limit (Leave blank for Unlimited)
                      </label>
                      <input
                        type="number"
                        min={1}
                        placeholder="Unlimited registrations"
                        value={maxUsesInput}
                        onChange={(e) => setMaxUsesInput(e.target.value)}
                        className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Onboarding Governance Policy
                    </label>
                    <button
                      type="button"
                      onClick={() => setRequiresApproval(!requiresApproval)}
                      className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                        requiresApproval
                          ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                          : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                      }`}
                    >
                      <span>
                        {requiresApproval
                          ? 'Place in Pastoral Approval Queue (Recommended)'
                          : 'Auto-Approve & Activate Member Immediately'}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] uppercase font-black bg-white/70 dark:bg-slate-900/70">
                        {requiresApproval ? 'Review Required' : 'Direct Active'}
                      </span>
                    </button>
                  </div>
                </div>

                <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    disabled={generating}
                    onClick={() => handleCreateOrRegenerateLink(false)}
                    className="min-h-[44px] px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{generating ? 'Generating...' : 'Generate New Registration Link'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={generating}
                    onClick={() => handleCreateOrRegenerateLink(true)}
                    className="min-h-[44px] px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-4 h-4 ${generating ? 'animate-spin' : ''}`} />
                    <span>Replace & Revoke Previous Link</span>
                  </button>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* TAB 3: ACTIVE & PAST INVITATION LINKS HISTORY */}
            {/* ========================================================= */}
            {activeTab === 'history' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                    Database Registration Invitations ({invitations.length})
                  </h3>
                  <button
                    type="button"
                    onClick={loadInvitations}
                    className="min-h-[36px] px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                    <span>Refresh</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {invitations.map((inv) => {
                    const isSelected = selectedInvitation?.id === inv.id;
                    const invUrl = `${clientOrigin}/register/${inv.token}`;
                    return (
                      <div
                        key={inv.id}
                        className={`p-4 rounded-2xl border transition-all ${
                          isSelected
                            ? 'bg-purple-50/60 dark:bg-purple-950/30 border-purple-400 dark:border-purple-700'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                  inv.status === 'active'
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                    : inv.status === 'revoked'
                                    ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                }`}
                              >
                                {inv.status}
                              </span>
                              <span className="font-extrabold text-xs text-slate-900 dark:text-white truncate">
                                {inv.title}
                              </span>
                            </div>

                            <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 break-all">
                              {invUrl}
                            </p>

                            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-1">
                              <span>Campus: {inv.branchName}</span>
                              <span>•</span>
                              <span>
                                Uses: {inv.usesCount}
                                {inv.singleUse
                                  ? ' / 1 (Single-Use)'
                                  : inv.maxUses
                                  ? ` / ${inv.maxUses}`
                                  : ' (Unlimited)'}
                              </span>
                              <span>•</span>
                              <span>
                                Expires:{' '}
                                {inv.expiresAt
                                  ? new Date(inv.expiresAt).toLocaleDateString()
                                  : 'Never'}
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedInvitation({
                                  ...inv,
                                  registrationUrl: invUrl,
                                });
                                setActiveTab('share');
                              }}
                              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold cursor-pointer"
                            >
                              Select & Share
                            </button>

                            {inv.status === 'active' && (
                              <button
                                type="button"
                                disabled={revokingId === inv.id}
                                onClick={() => handleRevokeInvitation(inv)}
                                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-xs font-bold cursor-pointer"
                              >
                                {revokingId === inv.id ? 'Revoking...' : 'Revoke'}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Footer Bar */}
        <div className="px-4 py-3.5 sm:px-6 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 shrink-0">
          <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              Cryptographically signed token • Submissions sync directly to Member Directory & Approvals Hub
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-white font-bold text-xs cursor-pointer transition-all"
          >
            Done & Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShareRegistrationLinkModal;
