import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useCMMS, ModuleTab } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { triggerGoogleTranslate } from '../utils/googleTranslate';
import {
  Menu,
  Home,
  UsersRound,
  Video,
  BookOpen,
  User,
  LogOut,
  X,
  Shield,
  ShieldCheck,
  ChevronRight,
  Eye,
  Globe,
  Sun,
  Moon,
  Monitor,
  ToggleLeft,
  ToggleRight,
  HeartHandshake,
  ClipboardCheck,
  HeartPulse,
  UserCheck,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import { AccessibilityControlsModal } from './AccessibilityControlsModal';
import { MinistryLiveChatModal } from './MinistryLiveChatModal';
import { MinistryVideoConferenceModal } from './MinistryVideoConferenceModal';

interface MobileBottomNavProps {
  onToggleMobileMenu?: () => void;
  isMobileMenuOpen?: boolean;
}

interface RoleNavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  module: ModuleTab;
  path: string;
  allowedRoles: UserRole[];
}

const ROLE_DYNAMIC_ITEMS: RoleNavItem[] = [
  {
    id: 'ministries',
    label: 'Ministries',
    icon: UsersRound,
    module: 'ministries',
    path: '/ministries',
    allowedRoles: ['REGULAR_MEMBER'],
  },
  {
    id: 'rosters',
    label: 'Rosters',
    icon: ClipboardCheck,
    module: 'ministries',
    path: '/ministries',
    allowedRoles: ['MINISTRY_LEADER'],
  },
  {
    id: 'pastoral',
    label: 'Pastoral',
    icon: HeartPulse,
    module: 'prayer_counseling',
    path: '/prayer-counseling',
    allowedRoles: ['PASTOR'],
  },
  {
    id: 'approvals',
    label: 'Approvals',
    icon: ShieldAlert,
    module: 'approvals',
    path: '/approvals',
    allowedRoles: ['MANAGER', 'SYSTEM_ADMIN'],
  },
  {
    id: 'directory',
    label: 'Directory',
    icon: UserCheck,
    module: 'members',
    path: '/members',
    allowedRoles: ['PASTOR', 'MANAGER', 'SYSTEM_ADMIN'],
  },
  {
    id: 'devotions',
    label: 'Devotions',
    icon: BookOpen,
    module: 'devotions',
    path: '/devotions',
    allowedRoles: ['REGULAR_MEMBER'],
  },
];

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  onToggleMobileMenu,
  isMobileMenuOpen = false,
}) => {
  const {
    activeModule,
    setActiveModule,
    activeRole,
    themeMode,
    setThemeMode,
    language,
    setLanguage,
    addAuditLog,
    systemName,
    logout: cmmsLogout,
    setIsAuthenticated,
    t,
  } = useCMMS();

  const { currentUser, userProfile, logout: authLogout } = useAuth();
  const navigate = useNavigate();

  // Modals & Drawers
  const [isProfileSheetOpen, setIsProfileSheetOpen] = useState(false);
  const [is2FAEnabled, setIs2FAEnabled] = useState(true);
  const [logoutToast, setLogoutToast] = useState('');
  const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isAccessibilityModalOpen, setIsAccessibilityModalOpen] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [selectedMinistryId, setSelectedMinistryId] = useState<string>('min-1');

  // Dynamic system dark mode detection
  const [systemIsDark, setSystemIsDark] = useState<boolean>(() => {
    return typeof window !== 'undefined' && window.matchMedia
      ? window.matchMedia('(prefers-color-scheme: dark)').matches
      : false;
  });

  React.useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const update = () => setSystemIsDark(media.matches);
    update();
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  const isDarkMode =
    themeMode === 'dark' ||
    themeMode === 'advanced-dark' ||
    (themeMode === 'system' && systemIsDark);

  const closeMobileMenu = () => {
    if (isMobileMenuOpen) {
      onToggleMobileMenu?.();
    }
  };

  const contextNavItems = useMemo(() => {
    return ROLE_DYNAMIC_ITEMS.filter((item) =>
      item.allowedRoles.includes(activeRole as UserRole)
    ).slice(0, 2);
  }, [activeRole]);

  const leftRoleItem = contextNavItems[0];
  const rightRoleItem = contextNavItems[1];

  const getInitials = (nameStr?: string) => {
    if (!nameStr || !nameStr.trim()) return 'CM';
    const clean = nameStr.replace(/^(Apostle|Pastor|Dr\.|Rev\.|Elder|Mr|Mrs|Ms|Bro|Sis)\.?\s+/gi, '').trim();
    if (!clean) return 'CM';
    const parts = clean.split(/\s+/).filter(Boolean);
    if (parts.length === 0) return 'CM';
    if (parts.length === 1) return (parts[0] || 'CM').slice(0, 2).toUpperCase();
    return ((parts[0]?.[0] || 'C') + (parts[parts.length - 1]?.[0] || 'M')).toUpperCase();
  };

  const displayName = userProfile?.name || currentUser?.displayName || 'Authenticated User';
  const displayEmail = userProfile?.email || currentUser?.email || '';
  const displayPhoto = userProfile?.photoUrl || userProfile?.avatar || currentUser?.photoURL;
  const tenantName = systemName || 'CMMS';

  const handleLogout = async () => {
    try {
      setIsProfileSheetOpen(false);
      closeMobileMenu();
      setLogoutToast('Signing out of session...');
      addAuditLog('User Logout', 'Authentication', `User ${displayName} signed out from Mobile Navigation`);

      localStorage.removeItem('cmms_token');
      localStorage.removeItem('cmms_auth_token');
      localStorage.removeItem('cmms_active_user');
      localStorage.removeItem('cmms_applicant_data');
      localStorage.removeItem('cmms_onboarding_state');
      localStorage.removeItem('cmms_onboarding_workflow');
      localStorage.removeItem('cmms_rejection_reason');

      setIsAuthenticated(false);
      if (authLogout) await authLogout();
      if (cmmsLogout) cmmsLogout();

      navigate('/login', { replace: true });
    } catch (err) {
      console.error('Mobile logout error:', err);
      setIsAuthenticated(false);
      navigate('/login', { replace: true });
    } finally {
      setTimeout(() => {
        setLogoutToast('');
      }, 500);
    }
  };

  const handleLanguageChange = (langName: string) => {
    setLanguage(langName);
    const l = langName.toLowerCase().trim();
    const isInternal = (
      l === 'en' || l === 'english' ||
      l === 'am' || l === 'amharic' || l === 'አማርኛ' ||
      l === 'ti' || l === 'tigrigna' || l === 'ትግርኛ' ||
      l === 'om' || l === 'afaan oromoo' || l === 'oromo'
    );
    if (!isInternal) {
      triggerGoogleTranslate(langName);
    }
  };

  const isHomeActive = activeModule === 'dashboard' && !isProfileSheetOpen && !isMobileMenuOpen;

  return (
    <>
      <AnimatePresence>
        {logoutToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900 dark:bg-slate-800 border border-slate-700 text-white px-4 py-2.5 rounded-2xl shadow-2xl text-xs font-bold flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
            <span>{logoutToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FLOATING CURVED CENTER NAVIGATION BAR WITH LIGHT & DARK MODE ADAPTATION */}
      <nav
        aria-label="Mobile Navigation Bar"
        className="md:hidden fixed bottom-3 left-0 right-0 z-40 px-4 flex justify-center pointer-events-none pb-[env(safe-area-inset-bottom,0px)]"
      >
        <div className="relative w-full max-w-sm pointer-events-auto filter drop-shadow-2xl">
          
          {/* THEMED SVG BACKGROUND */}
          <svg
            viewBox="0 0 375 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={`w-full h-[64px] backdrop-blur-xl transition-colors duration-200 ${
              isDarkMode
                ? 'text-slate-900/95 fill-current stroke-slate-800/90'
                : 'text-white/95 fill-current stroke-slate-200/90 shadow-lg'
            }`}
            style={{
              filter: isDarkMode
                ? 'drop-shadow(0px 10px 25px rgba(0,0,0,0.5))'
                : 'drop-shadow(0px 8px 20px rgba(0,0,0,0.12))',
            }}
          >
            <path
              d="M 0 24 
                 C 0 10.745 10.745 0 24 0 
                 L 125 0 
                 C 137.5 0 145.5 10 151 18 
                 C 158 28 166.5 36 187.5 36 
                 C 208.5 36 217 28 224 18 
                 C 229.5 10 237.5 0 250 0 
                 L 351 0 
                 C 364.255 0 375 10.745 375 24 
                 L 375 40 
                 C 375 53.255 364.255 64 351 64 
                 L 24 64 
                 C 10.745 64 0 53.255 0 40 
                 Z"
              strokeWidth="1.5"
            />
          </svg>

          {/* ELEVATED CENTER CIRCULAR HOME BUTTON */}
          <div className="absolute -top-5 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center">
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => {
                setIsProfileSheetOpen(false);
                closeMobileMenu();
                setActiveModule('dashboard');
                navigate('/dashboard');
              }}
              style={{
                backgroundColor: isHomeActive
                  ? 'var(--cmms-primary-color, #2563eb)'
                  : 'var(--cmms-primary-hover, #1d4ed8)',
              }}
              className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-xl transition-all cursor-pointer border-4 ${
                isDarkMode ? 'border-slate-950' : 'border-slate-100'
              } ${
                isHomeActive
                  ? 'ring-4 ring-blue-500/30'
                  : 'hover:opacity-95'
              }`}
              aria-label={t('Home Dashboard')}
            >
              <Home className="w-6 h-6" />
            </motion.button>

            {isHomeActive && (
              <motion.div
                layoutId="active_dot"
                style={{ backgroundColor: 'var(--cmms-accent-color, #3b82f6)' }}
                className="w-1.5 h-1.5 rounded-full mt-1 shadow-xs"
              />
            )}
          </div>

          {/* NAV ITEMS ROW */}
          <div className="absolute inset-0 flex items-center justify-between px-2 z-10">
            
            {/* Slot 1: Sidebar Toggle */}
            <button
              onClick={() => {
                setIsProfileSheetOpen(false);
                onToggleMobileMenu?.();
              }}
              aria-label={t('Toggle menu')}
              className={`flex-1 min-h-[44px] flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Menu className={`w-5 h-5 ${isMobileMenuOpen ? 'text-blue-600 dark:text-blue-400 font-bold' : ''}`} />
              {isMobileMenuOpen && (
                <motion.div
                  layoutId="active_dot"
                  className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1"
                />
              )}
            </button>

            {/* Slot 2: Left Dynamic Role Module */}
            {leftRoleItem ? (
              <button
                onClick={() => {
                  setIsProfileSheetOpen(false);
                  closeMobileMenu();
                  setActiveModule(leftRoleItem.module);
                  navigate(leftRoleItem.path);
                }}
                aria-label={t(leftRoleItem.label)}
                className={`flex-1 min-h-[44px] flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                  isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {React.createElement(leftRoleItem.icon, {
                  className: `w-5 h-5 ${
                    activeModule === leftRoleItem.module && !isProfileSheetOpen && !isMobileMenuOpen
                      ? 'text-blue-600 dark:text-blue-400 font-bold'
                      : ''
                  }`,
                })}
                {activeModule === leftRoleItem.module && !isProfileSheetOpen && !isMobileMenuOpen && (
                  <motion.div
                    layoutId="active_dot"
                    className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1"
                  />
                )}
              </button>
            ) : (
              <div className="flex-1" />
            )}

            {/* Slot 3: Empty Center Spacer for Notch */}
            <div className="w-16 shrink-0" />

            {/* Slot 4: Right Dynamic Role Module */}
            {rightRoleItem ? (
              <button
                onClick={() => {
                  setIsProfileSheetOpen(false);
                  closeMobileMenu();
                  setActiveModule(rightRoleItem.module);
                  navigate(rightRoleItem.path);
                }}
                aria-label={t(rightRoleItem.label)}
                className={`flex-1 min-h-[44px] flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                  isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {React.createElement(rightRoleItem.icon, {
                  className: `w-5 h-5 ${
                    activeModule === rightRoleItem.module && !isProfileSheetOpen && !isMobileMenuOpen
                      ? 'text-blue-600 dark:text-blue-400 font-bold'
                      : ''
                  }`,
                })}
                {activeModule === rightRoleItem.module && !isProfileSheetOpen && !isMobileMenuOpen && (
                  <motion.div
                    layoutId="active_dot"
                    className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1"
                  />
                )}
              </button>
            ) : (
              <div className="flex-1" />
            )}

            {/* Slot 5: Profile Drawer Toggle */}
            <button
              onClick={() => {
                closeMobileMenu();
                setIsProfileSheetOpen(!isProfileSheetOpen);
              }}
              aria-label="Open profile menu"
              className={`flex-1 min-h-[44px] flex flex-col items-center justify-center h-full transition-colors cursor-pointer ${
                isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {displayPhoto && !imgError ? (
                <img
                  src={displayPhoto}
                  alt={displayName}
                  onError={() => setImgError(true)}
                  style={
                    isProfileSheetOpen
                      ? { boxShadow: '0 0 0 2px var(--cmms-primary-color, #2563eb)' }
                      : undefined
                  }
                  className={`w-5 h-5 rounded-full object-cover ${
                    isProfileSheetOpen ? '' : isDarkMode ? 'ring-2 ring-slate-700' : 'ring-2 ring-slate-300'
                  }`}
                />
              ) : (
                <User
                  style={
                    isProfileSheetOpen
                      ? { color: 'var(--cmms-primary-color, #2563eb)' }
                      : undefined
                  }
                  className={`w-5 h-5 ${
                    isProfileSheetOpen ? 'font-bold' : ''
                  }`}
                />
              )}
              {isProfileSheetOpen && (
                <motion.div
                  layoutId="active_dot"
                  style={{ backgroundColor: 'var(--cmms-accent-color, #7c3aed)' }}
                  className="w-1.5 h-1.5 rounded-full mt-1"
                />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* THEMED PROFILE BOTTOM SHEET */}
      <AnimatePresence>
        {isProfileSheetOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex flex-col justify-end">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsProfileSheetOpen(false)}
              className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            />

            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 320 }}
              className="relative z-10 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 rounded-t-3xl shadow-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto text-slate-900 dark:text-slate-100 transition-colors pb-[calc(2rem+env(safe-area-inset-bottom,0px))]"
            >
              <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto" />

              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  {displayPhoto && !imgError ? (
                    <img
                      src={displayPhoto}
                      alt={displayName}
                      className="w-12 h-12 rounded-2xl object-cover ring-2 ring-blue-500 shadow-md shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-black text-base flex items-center justify-center ring-2 ring-blue-500 shadow-md shrink-0">
                      {getInitials(displayName)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <h3 className="text-sm font-extrabold text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                      <span>{displayName}</span>
                      <ShieldCheck className="w-4 h-4 text-blue-500" />
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{displayEmail}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                        {activeRole}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 truncate max-w-[120px]">
                        {tenantName}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setIsProfileSheetOpen(false)}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* 2FA Protection Row */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">{t('2FA Protection')}</span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">{t('TOTP Authenticator Active')}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIs2FAEnabled(!is2FAEnabled)}
                  className={`flex items-center gap-1.5 px-3 py-2 min-h-[44px] rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    is2FAEnabled
                      ? 'bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/40'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700'
                  }`}
                >
                  {is2FAEnabled ? <ToggleRight className="w-4 h-4 text-blue-600 dark:text-blue-400" /> : <ToggleLeft className="w-4 h-4" />}
                  <span>{is2FAEnabled ? t('ENABLED') : t('DISABLED')}</span>
                </button>
              </div>

              {/* Actions List */}
              <div className="space-y-1.5 text-xs font-semibold">
                <button
                  onClick={() => {
                    setIsProfileSheetOpen(false);
                    setActiveModule('dashboard');
                    navigate('/dashboard');
                  }}
                  className="w-full min-h-[44px] flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 rounded-2xl transition-all text-slate-900 dark:text-slate-100 cursor-pointer shadow-xs group"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-full bg-blue-600/10 dark:bg-blue-600/20 text-blue-600 dark:text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <Home className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                      <span className="text-sm font-bold block text-slate-900 dark:text-white">{t('Go to Home')}</span>
                      <span className="text-xs text-slate-500 dark:text-slate-400 font-normal">{t('Return to Main Dashboard')}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
                </button>

                <button
                  onClick={() => {
                    setIsProfileSheetOpen(false);
                    setActiveModule('my_profile');
                    navigate('/my-profile');
                  }}
                  className="w-full min-h-[44px] flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-800 dark:text-slate-200 cursor-pointer border border-slate-100 dark:border-transparent"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-lg">
                      <User className="w-4 h-4" />
                    </div>
                    <span>{t('My Member Profile')}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  onClick={() => {
                    setIsProfileSheetOpen(false);
                    setIsLiveChatOpen(true);
                  }}
                  className="w-full min-h-[44px] flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-800 dark:text-slate-200 cursor-pointer border border-slate-100 dark:border-transparent"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-lg">
                      <Video className="w-4 h-4" />
                    </div>
                    <span>{t('Live Broadcast & Chat')}</span>
                  </div>
                  <span className="px-2 py-0.5 text-xs font-bold bg-rose-600 text-white rounded-full animate-pulse">
                    LIVE
                  </span>
                </button>

                <button
                  onClick={() => {
                    setIsProfileSheetOpen(false);
                    setActiveModule('prayer_counseling');
                    navigate('/prayer-counseling');
                  }}
                  className="w-full min-h-[44px] flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-800 dark:text-slate-200 cursor-pointer border border-slate-100 dark:border-transparent"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded-lg">
                      <HeartHandshake className="w-4 h-4" />
                    </div>
                    <span>{t('Prayer & Counseling')}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  onClick={() => {
                    setIsProfileSheetOpen(false);
                    setIsAccessibilityModalOpen(true);
                  }}
                  className="w-full min-h-[44px] flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-800 dark:text-slate-200 cursor-pointer border border-slate-100 dark:border-transparent"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-lg">
                      <Eye className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div>{t('Accessibility & Screen Reader')}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{t('ReachDeck TTS & High Contrast')}</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              {/* Theme Selector (Light, Dark, System) */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    {isDarkMode ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
                    <span>{t('Appearance')}</span>
                  </span>
                  <span className="text-xs font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-400">
                    {themeMode}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-950/80 rounded-xl border border-slate-200 dark:border-slate-800">
                  {[
                    { id: 'light' as const, label: 'Light', icon: Sun },
                    { id: 'dark' as const, label: 'Dark', icon: Moon },
                    { id: 'system' as const, label: 'System', icon: Monitor },
                  ].map((opt) => {
                    const isSelected = themeMode === opt.id || (opt.id === 'dark' && themeMode === 'advanced-dark');
                    const IconComp = opt.icon;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setThemeMode(opt.id)}
                        className={`flex items-center justify-center gap-1.5 py-2.5 min-h-[44px] rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs border border-slate-200 dark:border-slate-700'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        <IconComp className="w-3.5 h-3.5" />
                        <span>{t(opt.label)}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Language Row */}
                <div className="flex items-center justify-between p-3 min-h-[44px] bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-800/80 text-slate-800 dark:text-slate-200 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span>{t('Interface Language')}</span>
                  </span>
                  <select
                    value={language}
                    onChange={(e) => handleLanguageChange(e.target.value)}
                    className="bg-transparent text-xs font-bold text-blue-600 dark:text-blue-400 border-0 focus:outline-none cursor-pointer py-1"
                  >
                    <option value="English">English</option>
                    <option value="Amharic">አማርኛ</option>
                    <option value="Tigrigna">ትግርኛ</option>
                    <option value="Afaan Oromoo">Afaan Oromoo</option>
                  </select>
                </div>
              </div>

              {/* Logout Button */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleLogout}
                  className="w-full min-h-[44px] flex items-center justify-center gap-2.5 p-3.5 bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{t('Sign Out of Account')}</span>
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <MinistryLiveChatModal
        isOpen={isLiveChatOpen}
        onClose={() => setIsLiveChatOpen(false)}
        onSwitchToVideo={(ministryId) => {
          setSelectedMinistryId(ministryId);
          setIsLiveChatOpen(false);
          setIsVideoModalOpen(true);
        }}
      />

      <MinistryVideoConferenceModal
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
        ministryId={selectedMinistryId}
      />

      <AccessibilityControlsModal
        isOpen={isAccessibilityModalOpen}
        onClose={() => setIsAccessibilityModalOpen(false)}
      />
    </>
  );
};

export default MobileBottomNav;
