import React from 'react';
import {
  X,
  RotateCcw,
  Type,
  AlignLeft,
  Maximize2,
  Sun,
  Moon,
  Laptop,
  BookOpen,
  Check,
  ShieldCheck,
  Volume2,
  Sparkles,
  Layers,
  FileText,
  Highlighter,
  Bookmark,
  History,
  CheckCircle2,
} from 'lucide-react';
import {
  BibleReaderSettings,
  BibleFontSize,
  BibleLineSpacing,
  BibleReadingWidth,
  BibleReaderTheme,
  YouVersionBible,
  DEFAULT_BIBLE_READER_SETTINGS,
} from '../types';
import { useBible } from '../context/BibleContext';

interface BibleReaderSettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  settings: BibleReaderSettings;
  onUpdateSettings: (updated: Partial<BibleReaderSettings>) => void;
  onResetSettings: () => void;
  availableBibles: YouVersionBible[];
  isLoadingBibles?: boolean;
}

export const BibleReaderSettingsDrawer: React.FC<BibleReaderSettingsDrawerProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetSettings,
  availableBibles,
  isLoadingBibles = false,
}) => {
  const { otherAvailableBibles } = useBible();
  if (!isOpen) return null;

  const fontSizes: { label: string; value: BibleFontSize; px: string }[] = [
    { label: 'Small', value: 'small', px: '14px' },
    { label: 'Medium', value: 'medium', px: '16px' },
    { label: 'Large', value: 'large', px: '18px' },
    { label: 'Extra Large', value: 'xlarge', px: '22px' },
  ];

  const lineSpacings: { label: string; value: BibleLineSpacing; desc: string }[] = [
    { label: 'Compact', value: 'compact', desc: 'Dense text density' },
    { label: 'Comfortable', value: 'comfortable', desc: 'Balanced standard reading' },
    { label: 'Spacious', value: 'spacious', desc: 'Generous line leading' },
  ];

  const readingWidths: { label: string; value: BibleReadingWidth; desc: string }[] = [
    { label: 'Narrow', value: 'narrow', desc: 'Focus column (640px)' },
    { label: 'Normal', value: 'normal', desc: 'Standard column (860px)' },
    { label: 'Wide', value: 'wide', desc: 'Expansive study (1120px)' },
  ];

  const themes: { label: string; value: BibleReaderTheme; icon: React.FC<{ className?: string }>; bgClass: string; textClass: string }[] = [
    { label: 'Light', value: 'light', icon: Sun, bgClass: 'bg-white border-slate-300', textClass: 'text-slate-900' },
    { label: 'Dark', value: 'dark', icon: Moon, bgClass: 'bg-slate-900 border-slate-700', textClass: 'text-slate-100' },
    { label: 'System', value: 'system', icon: Laptop, bgClass: 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600', textClass: 'text-slate-800 dark:text-slate-200' },
    { label: 'Parchment', value: 'parchment', icon: BookOpen, bgClass: 'bg-[#fbf7ee] border-amber-300', textClass: 'text-amber-950' },
  ];

  // Helper for font stepper
  const currentFontIndex = fontSizes.findIndex((f) => f.value === settings.fontSize);
  const handleDecreaseFont = () => {
    if (currentFontIndex > 0) {
      onUpdateSettings({ fontSize: fontSizes[currentFontIndex - 1].value });
    }
  };
  const handleIncreaseFont = () => {
    if (currentFontIndex < fontSizes.length - 1) {
      onUpdateSettings({ fontSize: fontSizes[currentFontIndex + 1].value });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div
          id="bible-reader-settings-drawer"
          className="w-screen max-w-md bg-white dark:bg-slate-900 shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800"
        >
          {/* Header */}
          <div className="px-6 py-5 bg-gradient-to-r from-blue-700 to-indigo-800 text-white flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 backdrop-blur-xs rounded-lg">
                <BookOpen className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h2 className="text-lg font-bold tracking-tight">Bible Reading Settings</h2>
                <p className="text-xs text-blue-100">Personalize your study, typography & display</p>
              </div>
            </div>
            <button
              id="close-bible-settings-btn"
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
              title="Close Settings"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Privacy Notice Banner */}
          <div className="px-6 py-2.5 bg-blue-50 dark:bg-blue-950/40 border-b border-blue-100 dark:border-blue-900/50 flex items-center gap-2.5 text-xs text-blue-800 dark:text-blue-300">
            <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
            <span>Settings and study data are private to your member profile.</span>
          </div>

          {/* Scrollable Body */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6 text-slate-800 dark:text-slate-200">
            {/* 1. TRANSLATION & VERSION */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Translation & Version
                </label>
                {isLoadingBibles && (
                  <span className="text-xs text-blue-600 dark:text-blue-400 animate-pulse">Syncing YouVersion...</span>
                )}
              </div>

              <div className="space-y-2">
                <select
                  id="bible-version-select"
                  value={settings.preferredVersionId}
                  onChange={(e) => {
                    const selectedId = e.target.value;
                    const found = [...availableBibles, ...otherAvailableBibles].find((b) => String(b.id) === selectedId);
                    let versionName = found ? (found.localized_title || found.title) : selectedId;
                    let abbr = found ? (found.localized_abbreviation || found.abbreviation) : undefined;
                    let langMode = settings.preferredLanguage;

                    if (selectedId === '111') {
                      versionName = 'New International Version 2011 (NIV)';
                      abbr = 'NIV';
                      if (langMode !== 'Parallel') langMode = 'English';
                    } else if (selectedId === '12') {
                      versionName = 'American Standard Version (ASV)';
                      abbr = 'ASV';
                      if (langMode !== 'Parallel') langMode = 'English';
                    } else if (selectedId === '3034') {
                      versionName = 'Berean Standard Bible (BSB)';
                      abbr = 'BSB';
                      if (langMode !== 'Parallel') langMode = 'English';
                    } else if (selectedId === '206') {
                      versionName = 'YouVersion World English Bible (WEB)';
                      abbr = 'WEB';
                      if (langMode !== 'Parallel') langMode = 'English';
                    } else if (selectedId === '1260' || selectedId === 'nasv') {
                      versionName = 'YouVersion New Amharic Standard (አዲሱ መደበኛ ትርጒም)';
                      abbr = 'NASV';
                      if (langMode !== 'Parallel') langMode = 'Amharic';
                    } else if (found) {
                      if (langMode !== 'Parallel') {
                        langMode = found.language_tag === 'am' ? 'Amharic' : 'English';
                      }
                    }

                    onUpdateSettings({
                      preferredVersionId: isNaN(Number(selectedId)) ? selectedId : Number(selectedId),
                      preferredVersionName: versionName,
                      preferredVersionAbbreviation: abbr,
                      preferredLanguage: langMode,
                    });
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                >
                  {availableBibles.length > 0 ? (
                    <optgroup label="Primary Translations (YouVersion)">
                      {availableBibles.map((b) => {
                        const label =
                          b.userDisplayLabel ||
                          `${b.localized_abbreviation || b.abbreviation} — ${b.localized_title || b.title}`;
                        return (
                          <option key={`${b.slotKey || b.id}`} value={b.id}>
                            {label}
                          </option>
                        );
                      })}
                    </optgroup>
                  ) : (
                    <optgroup label="Primary Translations (YouVersion)">
                      <option value="1260">አዲሱ መደበኛ ትርጒም (New Amharic Standard Version 2024) — NASV</option>
                      <option value="111">New International Version (NIV)</option>
                    </optgroup>
                  )}
                  {otherAvailableBibles.length > 0 && (
                    <optgroup label={`More Options — Oromiffa (${otherAvailableBibles.length})`}>
                      {otherAvailableBibles.map((b) => {
                        const label =
                          b.userDisplayLabel ||
                          `${b.localized_abbreviation || b.abbreviation} — ${b.localized_title || b.title}`;
                        return (
                          <option key={`more-${b.id}`} value={b.id}>
                            {label}
                          </option>
                        );
                      })}
                    </optgroup>
                  )}
                </select>

                {/* Preferred Language Mode */}
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  {(['Amharic', 'Parallel', 'English'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      id={`lang-mode-${mode.toLowerCase()}-btn`}
                      onClick={() => onUpdateSettings({ preferredLanguage: mode })}
                      className={`py-1.5 text-xs font-semibold rounded-md transition-all ${
                        settings.preferredLanguage === mode
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {mode === 'Parallel' ? 'Parallel (ሁለቱም)' : mode}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 2. TEXT SIZE */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Type className="w-3.5 h-3.5" /> Text Size
                </label>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  {fontSizes.find((f) => f.value === settings.fontSize)?.label} ({fontSizes.find((f) => f.value === settings.fontSize)?.px})
                </span>
              </div>

              {/* Stepper & Button grid */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  id="font-size-minus-btn"
                  onClick={handleDecreaseFont}
                  disabled={currentFontIndex === 0}
                  className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-bold text-slate-700 dark:text-slate-300 text-base transition-colors"
                  title="Decrease font size"
                >
                  −
                </button>
                <div className="flex-1 grid grid-cols-4 gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                  {fontSizes.map((f) => (
                    <button
                      key={f.value}
                      type="button"
                      id={`font-size-${f.value}-btn`}
                      onClick={() => onUpdateSettings({ fontSize: f.value })}
                      className={`py-1.5 text-xs font-medium rounded transition-all text-center ${
                        settings.fontSize === f.value
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-bold shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {f.label.slice(0, 3)}
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  id="font-size-plus-btn"
                  onClick={handleIncreaseFont}
                  disabled={currentFontIndex === fontSizes.length - 1}
                  className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-bold text-slate-700 dark:text-slate-300 text-base transition-colors"
                  title="Increase font size"
                >
                  +
                </button>
              </div>
            </div>

            {/* 3. LINE SPACING */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <AlignLeft className="w-3.5 h-3.5" /> Line Spacing
              </label>

              <div className="grid grid-cols-3 gap-2">
                {lineSpacings.map((sp) => (
                  <button
                    key={sp.value}
                    type="button"
                    id={`spacing-${sp.value}-btn`}
                    onClick={() => onUpdateSettings({ lineSpacing: sp.value })}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      settings.lineSpacing === sp.value
                        ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 font-semibold ring-1 ring-blue-500'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full border flex items-center justify-center ${
                        settings.lineSpacing === sp.value ? 'border-blue-600 bg-blue-600' : 'border-slate-400'
                      }`}>
                        {settings.lineSpacing === sp.value && <div className="w-1 h-1 bg-white rounded-full" />}
                      </div>
                      <span className="text-xs">{sp.label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. READING WIDTH */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Maximize2 className="w-3.5 h-3.5" /> Reading Width
              </label>

              <div className="grid grid-cols-3 gap-2">
                {readingWidths.map((w) => (
                  <button
                    key={w.value}
                    type="button"
                    id={`width-${w.value}-btn`}
                    onClick={() => onUpdateSettings({ readingWidth: w.value })}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      settings.readingWidth === w.value
                        ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 font-semibold ring-1 ring-blue-500'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full border flex items-center justify-center ${
                        settings.readingWidth === w.value ? 'border-blue-600 bg-blue-600' : 'border-slate-400'
                      }`}>
                        {settings.readingWidth === w.value && <div className="w-1 h-1 bg-white rounded-full" />}
                      </div>
                      <span className="text-xs">{w.label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 5. APPEARANCE / THEME */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Appearance
              </label>

              <div className="grid grid-cols-2 gap-2">
                {themes.map((th) => {
                  const Icon = th.icon;
                  const isSelected = settings.theme === th.value;
                  return (
                    <button
                      key={th.value}
                      type="button"
                      id={`theme-${th.value}-btn`}
                      onClick={() => onUpdateSettings({ theme: th.value })}
                      className={`p-3 rounded-lg border flex items-center justify-between transition-all ${
                        isSelected
                          ? 'border-blue-600 ring-2 ring-blue-500/50 shadow-xs'
                          : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
                      } ${th.bgClass}`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${th.textClass}`} />
                        <span className={`text-xs font-semibold ${th.textClass}`}>{th.label}</span>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-blue-600" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 6. DISPLAY TOGGLES */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Display Elements
              </label>

              <div className="space-y-2">
                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="show-verse-numbers-checkbox"
                      checked={settings.showVerseNumbers}
                      onChange={(e) => onUpdateSettings({ showVerseNumbers: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-xs font-medium">Verse numbers</span>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400">1, 2, 3...</span>
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="show-footnotes-checkbox"
                      checked={settings.showFootnotes}
                      onChange={(e) => onUpdateSettings({ showFootnotes: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-xs font-medium">Footnotes</span>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400">Manuscript notes</span>
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="show-cross-references-checkbox"
                      checked={settings.showCrossReferences}
                      onChange={(e) => onUpdateSettings({ showCrossReferences: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-xs font-medium">Cross references</span>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400">Parallel verses</span>
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="show-red-letters-checkbox"
                      checked={settings.showRedLetters !== false}
                      onChange={(e) => onUpdateSettings({ showRedLetters: e.target.checked })}
                      className="w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500"
                    />
                    <span className="text-xs font-medium text-rose-600 dark:text-rose-400">Words of Christ in Red</span>
                  </div>
                  <span className="text-[10px] font-semibold text-rose-500">Red Letters</span>
                </label>
              </div>
            </div>

            {/* 7. READING TRACKING */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5" /> Reading Location & History
              </label>

              <div className="space-y-2">
                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="remember-position-checkbox"
                      checked={settings.rememberReadingPosition}
                      onChange={(e) => onUpdateSettings({ rememberReadingPosition: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-xs font-medium">Remember reading position</span>
                  </div>
                  <span className="text-[10px] font-semibold text-blue-600 dark:text-blue-400">Auto-resume</span>
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="track-history-checkbox"
                      checked={settings.trackReadingHistory}
                      onChange={(e) => onUpdateSettings({ trackReadingHistory: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-xs font-medium">Reading history</span>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400">Private log</span>
                </label>
              </div>
            </div>

            {/* 8. PERSONAL STUDY TOOLS */}
            <div className="space-y-3 pt-3 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Personal Study Tools
              </label>

              <div className="space-y-2">
                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="enable-notes-checkbox"
                      checked={settings.enableNotes}
                      onChange={(e) => onUpdateSettings({ enableNotes: e.target.checked })}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                    />
                    <span className="text-xs font-medium flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-blue-600" /> Private Notes
                    </span>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="enable-highlights-checkbox"
                      checked={settings.enableHighlights}
                      onChange={(e) => onUpdateSettings({ enableHighlights: e.target.checked })}
                      className="w-4 h-4 text-amber-500 rounded border-slate-300 focus:ring-amber-500"
                    />
                    <span className="text-xs font-medium flex items-center gap-1.5">
                      <Highlighter className="w-3.5 h-3.5 text-amber-500" /> Highlights
                    </span>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </label>

                <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <input
                      type="checkbox"
                      id="enable-bookmarks-checkbox"
                      checked={settings.enableBookmarks}
                      onChange={(e) => onUpdateSettings({ enableBookmarks: e.target.checked })}
                      className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                    />
                    <span className="text-xs font-medium flex items-center gap-1.5">
                      <Bookmark className="w-3.5 h-3.5 text-indigo-600" /> Bookmarks
                    </span>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </label>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="p-5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
            <button
              type="button"
              id="reset-bible-settings-btn"
              onClick={onResetSettings}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors border border-rose-200 dark:border-rose-900"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Settings
            </button>

            <button
              type="button"
              id="done-bible-settings-btn"
              onClick={onClose}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
