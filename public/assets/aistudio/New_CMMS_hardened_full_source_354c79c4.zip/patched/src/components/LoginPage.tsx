import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCMMS } from '../context/CMMSContext';
import { useTranslation } from '../i18n/LanguageContext';
import { apiService } from '../services/api';
import { RegistrationPage } from './RegistrationPage';
import { GoogleAuthOnboarding } from './GoogleAuthOnboarding';
import { QRCodeSVG } from 'qrcode.react';
import {
  Church,
  Lock,
  Mail,
  ShieldCheck,
  Eye,
  EyeOff,
  Globe,
  Building,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Shield,
  Clock,
  UserCheck,
  Users,
  Key,
  RefreshCw,
  Copy,
  Check,
  X,
  Smartphone,
  Search,
  FileText,
  QrCode,
  HeartHandshake,
  BookOpen,
  Sun,
  Moon,
} from 'lucide-react';

interface LoginPageProps {
  onOpenGoogleForm?: () => void;
  defaultTab?: 'member' | 'staff';
  portalLocked?: boolean;
}

function formatFriendlyAuthError(err: any): string {
  const raw = err?.message || (typeof err === 'string' ? err : '');
  if (!raw) return 'Authentication failed. Please check your credentials or reset your password.';
  if (
    raw.includes('Unexpected end of JSON input') ||
    raw.includes('Failed to fetch') ||
    raw.includes('NetworkError') ||
    raw.includes('ECONNREFUSED')
  ) {
    return "We couldn't connect to the authentication service. Please check your internet connection and try again.";
  }
  if (
    raw.includes('Invalid login credentials') ||
    raw.includes('invalid_grant') ||
    raw.includes('User not found') ||
    raw.includes('Invalid password')
  ) {
    return 'Invalid credentials. Please verify your email/phone and password, or use the Forgot Password link.';
  }
  if (raw.includes('401') || raw.includes('Unauthorized')) {
    return 'Incorrect email or password. Please try again.';
  }
  if (raw.includes('403') || raw.includes('Forbidden') || raw.includes('approval')) {
    return 'Your membership account is pending pastoral approval. You can track your status using Check Application Status.';
  }
  return raw;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onOpenGoogleForm, defaultTab, portalLocked = false }) => {
  const {
    loginWithGoogle,
    loginMemberTraditional,
    requestPasswordReset,
    verifyResetCode,
    confirmPasswordReset,
    loginStaff,
    verifyStaffMfa,
    confirmStaffReAuth,
    cancelReAuth,
    reAuthRequired,
    reAuthUser,
    onboardingState,
    userProfile,
    error,
  } = useAuth();

  const {
    login: cmmsLogin,
    branches,
    workflows,
    systemName,
    churchMotto,
    churchLogoUrl,
    themeMode,
    setThemeMode,
  } = useCMMS();
  const { t, language, setLanguage, fontClass } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  const isDark = themeMode === 'dark' || themeMode === 'advanced-dark';
  const toggleTheme = () => {
    setThemeMode(isDark ? 'light' : 'dark');
  };

  // Active Login Tab: 'member' | 'staff'
  const [activeTab, setActiveTab] = useState<'member' | 'staff'>(() => {
    if (defaultTab) return defaultTab;
    if (typeof window !== 'undefined') {
      if (
        window.location.pathname === '/login/staff' ||
        window.location.pathname.startsWith('/staff') ||
        window.location.search.includes('tab=staff')
      ) {
        return 'staff';
      }
    }
    return 'member';
  });

  // Keep the selected authentication flow aligned with the current portal URL.
  useEffect(() => {
    if (defaultTab) {
      setActiveTab(defaultTab);
      return;
    }
    if (location.pathname === '/login/staff' || location.pathname.startsWith('/staff')) {
      setActiveTab('staff');
    } else if (location.pathname === '/login/member' || location.pathname === '/login') {
      setActiveTab('member');
    }
  }, [defaultTab, location.pathname]);

  // Staff Two-Factor Authentication (TOTP) Modal State
  const [staffMfaState, setStaffMfaState] = useState<{
    isOpen: boolean;
    mfaEnrolled: boolean;
    totp?: any;
    factorId?: string;
    challengeId?: string;
    sessionToken?: string;
    user?: any;
  } | null>(null);
  const [staffMfaCode, setStaffMfaCode] = useState<string>('');
  const [staffMfaError, setStaffMfaError] = useState<string>('');
  const [staffMfaSessionExpired, setStaffMfaSessionExpired] = useState<boolean>(false);
  const [isMfaVerifying, setIsMfaVerifying] = useState<boolean>(false);
  const [isCopiedSecret, setIsCopiedSecret] = useState<boolean>(false);

  // Auth Mode for new member registration
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Application & Approval Status Modal
  const [showApprovalStatusModal, setShowApprovalStatusModal] = useState<boolean>(false);
  const [statusSearchQuery, setStatusSearchQuery] = useState<string>('');
  const [searchedWorkflow, setSearchedWorkflow] = useState<any | null>(null);
  const [hasSearchedStatus, setHasSearchedStatus] = useState<boolean>(false);

  // Member Traditional Form State
  const [memberIdentifier, setMemberIdentifier] = useState<string>('');
  const [memberPassword, setMemberPassword] = useState<string>('');
  const [showMemberPassword, setShowMemberPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Password Reset Modal State
  const [showResetModal, setShowResetModal] = useState<boolean>(false);
  const [resetStep, setResetStep] = useState<1 | 2 | 3 | 4>(1);
  const [resetIdentifier, setResetIdentifier] = useState<string>('');
  const [resetMethod, setResetMethod] = useState<'email' | 'phone'>('email');
  const [resetCode, setResetCode] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmNewPassword, setConfirmNewPassword] = useState<string>('');
  const [showResetNewPassword, setShowResetNewPassword] = useState<boolean>(false);
  const [resetLoading, setResetLoading] = useState<boolean>(false);
  const [resetError, setResetError] = useState<string>('');
  const [resetSuccessNotice, setResetSuccessNotice] = useState<string>('');
  const [resetMaskedDest, setResetMaskedDest] = useState<string>('');
  const [resendTimer, setResendTimer] = useState<number>(0);

  // Staff Form State
  const [campusId, setCampusId] = useState<string>('');
  const [staffBranches, setStaffBranches] = useState<Array<{ id: string; name: string }>>([]);
  const [branchesLoading, setBranchesLoading] = useState<boolean>(false);
  const [branchesLoadError, setBranchesLoadError] = useState<string>('');
  const [staffEmail, setStaffEmail] = useState<string>('');
  const [staffPassword, setStaffPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // 30-Day Re-Auth Modal Inputs
  const [reAuthPassword, setReAuthPassword] = useState<string>('');
  const [reAuth2faCode, setReAuth2faCode] = useState<string>('');
  const [showReAuthPassword, setShowReAuthPassword] = useState<boolean>(false);

  // Loading & Alert States
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successNotice, setSuccessNotice] = useState<string>('');

  // Sync context-level auth errors (e.g., WRONG_PORTAL from Google OAuth redirect)
  useEffect(() => {
    if (error && !errorMessage) {
      setErrorMessage(error);
    }
  }, [error, errorMessage]);

  // Load active campuses from the PostgreSQL-backed public lookup.
  // Only active branch IDs and names are exposed before staff authentication.
  useEffect(() => {
    if (activeTab !== 'staff') return;
    let cancelled = false;
    setBranchesLoading(true);
    setBranchesLoadError('');
    apiService.getPublicRegistrationOptions()
      .then((result) => {
        if (cancelled) return;
        const available = Array.isArray(result?.branches) ? result.branches : [];
        setStaffBranches(available);
        setCampusId((current) => available.some((branch) => branch.id === current) ? current : (available[0]?.id || ''));
        if (available.length === 0) setBranchesLoadError('No active campuses are configured. Contact your system administrator.');
      })
      .catch((err: any) => {
        if (cancelled) return;
        setStaffBranches([]);
        setCampusId('');
        setBranchesLoadError(err?.message || 'Unable to load campuses from the database. Please retry.');
      })
      .finally(() => { if (!cancelled) setBranchesLoading(false); });
    return () => { cancelled = true; };
  }, [activeTab]);

  // Resend Timer Countdown Effect
  useEffect(() => {
    let interval: any;
    if (resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [resendTimer]);

  // Google Onboarding Intercept
  if (onboardingState === 'NEW_USER' || onboardingState === 'PENDING' || onboardingState === 'REJECTED') {
    return (
      <GoogleAuthOnboarding
        onSuccessApproved={() => {
          cmmsLogin(userProfile?.email || 'member@gmail.com', userProfile?.role || 'REGULAR_MEMBER', userProfile?.name || 'Member');
          navigate('/devotions');
        }}
        onBackToLogin={() => {
          setActiveTab('member');
        }}
      />
    );
  }

  // Switch to Registration View
  if (authMode === 'register') {
    return <RegistrationPage onSwitchToLogin={() => setAuthMode('login')} />;
  }

  // Member Traditional Login Handler
  const handleMemberTraditionalLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessNotice('');

    if (!memberIdentifier.trim()) {
      setErrorMessage('Please enter your registered email address or phone number.');
      return;
    }
    if (!memberPassword || memberPassword.length < 4) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);

    try {
      const result = await loginMemberTraditional(memberIdentifier, memberPassword, rememberMe);
      setIsLoading(false);

      if (result.success && result.user) {
        cmmsLogin(result.user.email, result.user.role || 'REGULAR_MEMBER', result.user.name);
        if (result.mustChangePassword) {
          setSuccessNotice('Temporary password detected. Redirecting to mandatory password change...');
          setTimeout(() => {
            navigate('/change-password');
          }, 300);
          return;
        }
        setSuccessNotice(`Welcome back, ${result.user.name}! Redirecting to portal...`);
        setTimeout(() => {
          navigate('/devotions');
        }, 300);
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(formatFriendlyAuthError(err));
    }
  };

  // Member Google OAuth Login
  const handleGoogleMemberLogin = async () => {
    setErrorMessage('');
    setSuccessNotice('');
    setIsLoading(true);

    try {
      const result = await loginWithGoogle();
      if (result?.status === 'REDIRECTING') {
        // Browser is redirecting to Google OAuth
        return;
      }
      setIsLoading(false);
      if (result?.status === 'APPROVED' && result.user) {
        cmmsLogin(result.user.email, result.user.role || 'REGULAR_MEMBER', result.user.name);
        setSuccessNotice('Signed in with Google! Redirecting to portal...');
        setTimeout(() => {
          navigate('/devotions');
        }, 300);
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(formatFriendlyAuthError(err));
    }
  };

  // Search Application / Approval Status
  const handleSearchApprovalStatus = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setHasSearchedStatus(true);
    const query = (statusSearchQuery || '').trim();
    if (!query) {
      setSearchedWorkflow(null);
      return;
    }

    try {
      const res = await fetch(`/api/auth/application-status/${encodeURIComponent(query)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.found && data.application) {
          setSearchedWorkflow(data.application);
          return;
        }
      }
    } catch (apiErr) {
      console.info('Server status lookup notice:', apiErr);
    }

    const cleanDigits = query.replace(/[^0-9]/g, '');
    const found = (workflows || []).find((w) => {
      if (w.requestType !== 'Membership Application') return false;
      if (w.requestCode && w.requestCode.toLowerCase().includes(query.toLowerCase())) return true;
      if (w.requesterEmail && w.requesterEmail.toLowerCase().includes(query.toLowerCase())) return true;
      if (w.requesterName && w.requesterName.toLowerCase().includes(query.toLowerCase())) return true;
      if (w.requesterPhone && cleanDigits && w.requesterPhone.replace(/[^0-9]/g, '').includes(cleanDigits)) return true;
      return false;
    });

    setSearchedWorkflow(found || null);
  };

  // Password Reset Handlers
  const handleOpenResetModal = (presetId?: string) => {
    setResetIdentifier(presetId || memberIdentifier || '');
    setResetMethod(presetId?.includes('@') ? 'email' : presetId && !presetId.includes('@') ? 'phone' : 'email');
    setResetStep(1);
    setResetError('');
    setResetSuccessNotice('');
    setResetCode('');
    setNewPassword('');
    setConfirmNewPassword('');
    setShowResetModal(true);
  };

  const handleCloseResetModal = () => {
    setShowResetModal(false);
    setResetError('');
    setResetSuccessNotice('');
  };

  const handleRequestReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError('');
    setResetSuccessNotice('');

    if (!resetIdentifier.trim()) {
      setResetError('Please enter your email address or phone number.');
      return;
    }

    setResetLoading(true);
    try {
      const res = await requestPasswordReset(resetIdentifier, resetMethod);
      setResetLoading(false);
      setResetMaskedDest(res.maskedDestination || resetIdentifier);
      setResendTimer(60);
      setResetSuccessNotice(res.message || 'Verification code sent successfully.');
      setResetStep(2);
    } catch (err: any) {
      setResetLoading(false);
      setResetError(err.message || 'Failed to dispatch verification code. Please try again.');
    }
  };

  const handleVerifyResetCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError('');
    setResetSuccessNotice('');

    if (!resetCode.trim() || resetCode.trim().length < 6) {
      setResetError('Please enter the complete 6-digit verification code.');
      return;
    }

    setResetLoading(true);
    try {
      const res = await verifyResetCode(resetIdentifier, resetCode);
      setResetLoading(false);
      setResetSuccessNotice(res.message || 'Verification code confirmed!');
      setResetStep(3);
    } catch (err: any) {
      setResetLoading(false);
      setResetError(err.message || 'Invalid or expired verification code.');
    }
  };

  const handleConfirmResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError('');
    setResetSuccessNotice('');

    if (!newPassword || newPassword.length < 6) {
      setResetError('Password must be at least 6 characters in length.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setResetError('Passwords do not match. Please re-enter.');
      return;
    }

    setResetLoading(true);
    try {
      const res = await confirmPasswordReset(resetIdentifier, resetCode, newPassword);
      setResetLoading(false);
      setResetSuccessNotice(res.message || 'Password successfully updated!');
      setMemberPassword(newPassword);
      if (resetIdentifier.includes('@') || resetIdentifier.length >= 7) {
        setMemberIdentifier(resetIdentifier);
      }
      setResetStep(4);
    } catch (err: any) {
      setResetLoading(false);
      setResetError(err.message || 'Password reset failed. Please retry.');
    }
  };

  const handleResendCode = async () => {
    if (resendTimer > 0) return;
    setResetError('');
    setResetLoading(true);
    try {
      const res = await requestPasswordReset(resetIdentifier, resetMethod);
      setResetLoading(false);
      setResendTimer(60);
      setResetSuccessNotice(res.message || 'New verification code sent.');
    } catch (err: any) {
      setResetLoading(false);
      setResetError(err.message || 'Failed to resend code.');
    }
  };

  // Staff Login Handler
  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessNotice('');

    if (!campusId || !staffBranches.some((branch) => branch.id === campusId)) {
      setErrorMessage('Select an active campus from the database before signing in.');
      return;
    }

    if (!staffEmail || !staffEmail.includes('@')) {
      setErrorMessage('Please enter a valid leadership email address.');
      return;
    }
    if (!staffPassword || staffPassword.length < 6) {
      setErrorMessage('Please enter your staff security password.');
      return;
    }

    setIsLoading(true);

    try {
      const result = await loginStaff(campusId, staffEmail, staffPassword, rememberMe);
      setIsLoading(false);

      if (result.requiresReAuth) {
        return;
      }

      if (result.mustChangePassword) {
        cmmsLogin(
          result.user?.email || staffEmail,
          result.user?.role,
          result.user?.name || staffEmail.split('@')[0]
        );
        setSuccessNotice('Temporary password detected. Redirecting to mandatory password change...');
        setTimeout(() => {
          navigate('/change-password');
        }, 300);
        return;
      }

      if (result.requiresMfa) {
        setStaffMfaState({
          isOpen: true,
          mfaEnrolled: Boolean(result.mfaEnrolled),
          totp: result.totp,
          factorId: result.factorId,
          challengeId: result.challengeId,
          sessionToken: result.sessionToken,
          user: result.user,
        });
        setStaffMfaCode('');
        setStaffMfaError('');
        setStaffMfaSessionExpired(false);
        return;
      }

      if (result.success && result.targetModule) {
        const targetPath =
          result.targetModule === 'dashboard'
            ? '/dashboard'
            : result.targetModule === 'prayer_counseling' || result.targetModule === 'prayer-counseling'
            ? '/prayer-counseling'
            : result.targetModule === 'attendance'
            ? '/attendance'
            : '/devotions';

        cmmsLogin(
          result.user?.email || staffEmail,
          result.user?.role,
          result.user?.name || staffEmail.split('@')[0]
        );
        setSuccessNotice(`Authentication verified. Redirecting to ${result.targetModule}...`);
        setTimeout(() => {
          navigate(targetPath);
        }, 300);
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(formatFriendlyAuthError(err));
    }
  };

  // Staff MFA Submit
  const handleStaffMfaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffMfaState || !staffMfaCode || staffMfaCode.length < 6 || isMfaVerifying) return;

    setIsMfaVerifying(true);
    setStaffMfaError('');
    setStaffMfaSessionExpired(false);

    try {
      const result = await verifyStaffMfa(staffMfaCode, {
        factorId: staffMfaState.factorId,
        challengeId: staffMfaState.challengeId,
        sessionToken: staffMfaState.sessionToken,
        email: staffMfaState.user?.email || staffEmail,
      });

      setIsMfaVerifying(false);

      if (result.success && result.targetModule) {
        const targetPath =
          result.targetModule === 'dashboard'
            ? '/dashboard'
            : result.targetModule === 'prayer_counseling' || result.targetModule === 'prayer-counseling'
            ? '/prayer-counseling'
            : result.targetModule === 'attendance'
            ? '/attendance'
            : '/devotions';

        cmmsLogin(
          result.user?.email || staffEmail,
          result.user?.role,
          result.user?.name || staffEmail.split('@')[0]
        );
        setStaffMfaState(null);
        setSuccessNotice('Two-Factor Authentication verified. Access granted.');
        setTimeout(() => {
          navigate(targetPath);
        }, 300);
      }
    } catch (err: any) {
      setIsMfaVerifying(false);
      const message = err?.message || '';
      const code = err?.code || '';

      if (code === 'MFA_SESSION_EXPIRED' || message.includes('expired')) {
        setStaffMfaSessionExpired(true);
        setStaffMfaError(t('mfa_session_expired_desc', 'Your 10-minute login session has expired. Please sign in again.'));
      } else if (code === 'MFA_NOT_ENROLLED') {
        setStaffMfaError(t('mfa_not_enrolled', 'Two-factor authentication is not enrolled. Please sign in again to set up 2FA.'));
      } else {
        setStaffMfaError(message || t('verification_failed', 'Verification failed. Please try again.'));
      }
    }
  };

  // 30-Day Re-Auth Submit
  const handleReAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsLoading(true);

    try {
      const result = await confirmStaffReAuth(reAuthPassword, reAuth2faCode);
      setIsLoading(false);

      const targetPath =
        result.targetModule === 'dashboard'
          ? '/dashboard'
          : result.targetModule === 'prayer_counseling'
          ? '/prayer-counseling'
          : result.targetModule === 'attendance'
          ? '/attendance'
          : '/devotions';

      if (reAuthUser) {
        cmmsLogin(reAuthUser.email, reAuthUser.role, reAuthUser.name);
      }

      setSuccessNotice('30-Day Security Re-Authentication verified! Access unlocked.');
      setTimeout(() => {
        navigate(targetPath);
      }, 300);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(formatFriendlyAuthError(err));
    }
  };

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col lg:flex-row overflow-x-hidden selection:bg-blue-600 selection:text-white transition-colors duration-200 ${fontClass}`}>
      {/* =================================================================== */}
      {/* 1. LEFT PANEL: CMMS GRAPHIC & CHURCH IDENTITY (Desktop >= 1024px)   */}
      {/* =================================================================== */}
      <aside
        aria-label="CMMS Platform Overview"
        className="hidden lg:flex lg:w-1/2 xl:w-[48%] min-h-screen relative p-10 xl:p-16 flex-col justify-between overflow-hidden border-r border-[#E5E7EB] dark:border-slate-800/80 cmms-brand-panel"
        style={{
          backgroundColor: 'var(--cmms-login-panel-color, #0f172a)',
          color: 'var(--cmms-over-brand-text, #ffffff)',
        }}
      >
        {/* Soft Radial Ambient Glows (Dynamic Brand Colors) */}
        <div
          aria-hidden="true"
          className="absolute -top-24 -left-24 w-96 h-96 rounded-full blur-3xl opacity-25 pointer-events-none"
          style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
        />
        <div
          aria-hidden="true"
          className="absolute -bottom-24 -right-24 w-96 h-96 rounded-full blur-3xl opacity-20 pointer-events-none"
          style={{ backgroundColor: 'var(--cmms-accent-color, #7c3aed)' }}
        />

        {/* Subtle Geometric Dot Lattice (CSS-only) */}
        <div
          aria-hidden="true"
          className="absolute inset-0 opacity-[0.04] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
            backgroundSize: '24px 24px',
          }}
        />

        {/* Top Header Badge */}
        <div className="relative z-10 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <div
              className="w-10 h-10 rounded-2xl p-0.5 shadow-md flex items-center justify-center shrink-0"
              style={{
                background: 'linear-gradient(135deg, var(--cmms-primary-color, #2563eb), var(--cmms-accent-color, #7c3aed))',
              }}
            >
              {churchLogoUrl ? (
                <img src={churchLogoUrl} alt="Logo" className="w-6 h-6 rounded-lg object-contain" />
              ) : (
                <Church className="w-5 h-5 text-white" />
              )}
            </div>
            <div>
              <span
                className="font-extrabold text-sm tracking-tight block cmms-over-brand-text"
                style={{ color: 'var(--cmms-over-brand-text, #ffffff)' }}
              >
                {systemName || 'CMMS'}
              </span>
              <span
                className="text-[11px] font-medium cmms-over-brand-muted"
                style={{ color: 'var(--cmms-over-brand-muted, #cbd5e1)' }}
              >
                Church Management System (CMMS)
              </span>
            </div>
          </Link>

          <div
            className="flex items-center gap-1.5 text-xs backdrop-blur-sm px-3 py-1.5 rounded-xl cmms-over-brand-card"
            style={{
              backgroundColor: 'var(--cmms-over-brand-card-bg, rgba(255, 255, 255, 0.06))',
              borderColor: 'var(--cmms-over-brand-border, rgba(255, 255, 255, 0.12))',
            }}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span
              className="font-mono text-[11px] cmms-over-brand-muted"
              style={{ color: 'var(--cmms-over-brand-muted, #cbd5e1)' }}
            >
              256-Bit SSL Encrypted
            </span>
          </div>
        </div>

        {/* Center Presentation: Headline & Feature Cards */}
        <div className="relative z-10 my-auto py-8 space-y-7 max-w-lg">
          <div className="space-y-3">
            <h2
              className="text-3xl xl:text-4xl font-black tracking-tight leading-tight cmms-over-brand-text"
              style={{ color: 'var(--cmms-over-brand-text, #ffffff)' }}
            >
              Manage Your Church. Connect Your People.
            </h2>
            <p
              className="text-xs xl:text-sm leading-relaxed font-normal cmms-over-brand-muted"
              style={{ color: 'var(--cmms-over-brand-muted, #cbd5e1)' }}
            >
              {churchMotto ||
                'A modern, trustworthy administrative platform bringing pastors, leaders, and members together under a unified, secure system.'}
            </p>
          </div>

          {/* 3 Real Platform Capabilities Showcase Cards */}
          <div className="space-y-3">
            <div
              className="p-4 rounded-2xl backdrop-blur-sm flex items-center gap-3.5 cmms-over-brand-card"
              style={{
                backgroundColor: 'var(--cmms-over-brand-card-bg, rgba(255, 255, 255, 0.06))',
                borderColor: 'var(--cmms-over-brand-border, rgba(255, 255, 255, 0.12))',
              }}
            >
              <div
                className="w-10 h-10 rounded-xl border border-white/20 text-white flex items-center justify-center shrink-0"
                style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
              >
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h4
                  className="text-xs font-bold cmms-over-brand-text"
                  style={{ color: 'var(--cmms-over-brand-text, #ffffff)' }}
                >
                  Granular Role-Based Access Control
                </h4>
                <p
                  className="text-[11px] leading-relaxed cmms-over-brand-muted"
                  style={{ color: 'var(--cmms-over-brand-muted, #cbd5e1)' }}
                >
                  Tailored permissions for Pastors, Administrators, Managers, and Ministry Heads.
                </p>
              </div>
            </div>

            <div
              className="p-4 rounded-2xl backdrop-blur-sm flex items-center gap-3.5 cmms-over-brand-card"
              style={{
                backgroundColor: 'var(--cmms-over-brand-card-bg, rgba(255, 255, 255, 0.06))',
                borderColor: 'var(--cmms-over-brand-border, rgba(255, 255, 255, 0.12))',
              }}
            >
              <div
                className="w-10 h-10 rounded-xl border border-white/20 text-white flex items-center justify-center shrink-0"
                style={{ backgroundColor: 'var(--cmms-accent-color, #7c3aed)' }}
              >
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h4
                  className="text-xs font-bold cmms-over-brand-text"
                  style={{ color: 'var(--cmms-over-brand-text, #ffffff)' }}
                >
                  Scripture &amp; Pastoral Devotions
                </h4>
                <p
                  className="text-[11px] leading-relaxed cmms-over-brand-muted"
                  style={{ color: 'var(--cmms-over-brand-muted, #cbd5e1)' }}
                >
                  Live YouVersion Bible reading with private study notes and daily church devotions.
                </p>
              </div>
            </div>

            <div
              className="p-4 rounded-2xl backdrop-blur-sm flex items-center gap-3.5 cmms-over-brand-card"
              style={{
                backgroundColor: 'var(--cmms-over-brand-card-bg, rgba(255, 255, 255, 0.06))',
                borderColor: 'var(--cmms-over-brand-border, rgba(255, 255, 255, 0.12))',
              }}
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h4
                  className="text-xs font-bold cmms-over-brand-text"
                  style={{ color: 'var(--cmms-over-brand-text, #ffffff)' }}
                >
                  Member Care &amp; Attendance Tracking
                </h4>
                <p
                  className="text-[11px] leading-relaxed cmms-over-brand-muted"
                  style={{ color: 'var(--cmms-over-brand-muted, #cbd5e1)' }}
                >
                  Family directories, pastoral counseling requests, and multi-campus attendance.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Left Bottom Footer */}
        <div
          className="relative z-10 pt-4 flex items-center justify-between text-[11px] border-t cmms-over-brand-muted"
          style={{
            color: 'var(--cmms-over-brand-muted, #cbd5e1)',
            borderColor: 'var(--cmms-over-brand-border, rgba(255, 255, 255, 0.12))',
          }}
        >
          <span>© {new Date().getFullYear()} {systemName || 'CMMS'}</span>
          <span>Sovereign Security Gateway</span>
        </div>
      </aside>

      {/* =================================================================== */}
      {/* 2. RIGHT PANEL: AUTHENTICATION FORM AREA (Responsive 100% on Mobile) */}
      {/* =================================================================== */}
      <section
        aria-label="Authentication Form"
        className="w-full lg:w-1/2 xl:w-[52%] min-h-screen flex flex-col justify-between p-4 sm:p-8 lg:p-12 xl:p-16 max-w-full overflow-y-auto bg-white dark:bg-slate-950 cmms-form-panel transition-colors duration-200"
      >
        {/* Top Header Controls */}
        <header className="w-full max-w-md mx-auto flex items-center justify-between pb-6 border-b border-[#E5E7EB] dark:border-slate-800/80 gap-2">
          <Link
            to="/"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white border border-slate-200 dark:border-slate-700/80 text-xs font-semibold transition-all cursor-pointer shadow-xs"
            title="Return to Home"
          >
            <ArrowLeft className="w-3.5 h-3.5" style={{ color: 'var(--cmms-primary-color, #2563eb)' }} />
            <span>Back</span>
          </Link>

          <div className="flex items-center gap-2">
            {/* Theme Toggle (Light / Dark) */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition-all cursor-pointer"
            >
              {isDark ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Light</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600" />
                  <span className="hidden sm:inline">Dark</span>
                </>
              )}
            </button>

            {/* Language Selector */}
            <div className="flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs rounded-xl px-2.5 py-1.5 focus:outline-none cursor-pointer cmms-input"
                aria-label="Language selection"
              >
                <option value="en">English (US)</option>
                <option value="am">አማርኛ (Amharic)</option>
                <option value="ti">ትግርኛ (Tigrigna)</option>
                <option value="om">Afaan Oromoo</option>
              </select>
            </div>
          </div>
        </header>

        {/* Main Center Auth Form Box */}
        <main className="w-full max-w-md mx-auto my-auto py-8 space-y-6">
          {/* Brand Welcome */}
          <div className="space-y-1 text-center sm:text-left">
            <div className="lg:hidden flex justify-center mb-3">
              <div
                className="w-12 h-12 rounded-2xl p-0.5 shadow-md flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, var(--cmms-primary-color, #2563eb), var(--cmms-accent-color, #7c3aed))',
                }}
              >
                {churchLogoUrl ? (
                  <img src={churchLogoUrl} alt="Logo" className="w-7 h-7 rounded-lg object-contain" />
                ) : (
                  <Church className="w-6 h-6 text-white" />
                )}
              </div>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              Welcome Back
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Sign in to your CMMS church account
            </p>
          </div>

          {!portalLocked && (
          <>
          {/* Dual-Path Tab Navigation (Segmented Switcher) */}
          <div className="grid grid-cols-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold gap-1">
            <button
              type="button"
              onClick={() => {
                setActiveTab('member');
                setErrorMessage('');
              }}
              style={
                activeTab === 'member'
                  ? { backgroundColor: 'var(--cmms-primary-color, #2563eb)' }
                  : undefined
              }
              className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'member'
                  ? 'text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/70 dark:hover:bg-slate-800/50'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Member Sign In</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('staff');
                setErrorMessage('');
              }}
              style={
                activeTab === 'staff'
                  ? { backgroundColor: 'var(--cmms-primary-color, #2563eb)' }
                  : undefined
              }
              className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'staff'
                  ? 'text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/70 dark:hover:bg-slate-800/50'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Staff &amp; Leadership</span>
            </button>
          </div>
          </>
          )}
          {portalLocked && (
            <p className="text-center text-xs text-slate-500 dark:text-slate-400">
              {activeTab === 'staff' ? 'Are you a church member?' : 'Are you staff or church leadership?'}{' '}
              <Link
                to={activeTab === 'staff' ? '/login/member' : '/login/staff'}
                className="font-bold text-blue-600 dark:text-blue-400 hover:underline"
              >
                {activeTab === 'staff' ? 'Member sign in' : 'Staff sign in'}
              </Link>
            </p>
          )}

          {/* User-Friendly Feedback Alerts */}
          {errorMessage && (
            <div
              role="alert"
              className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/80 flex items-start gap-3 text-rose-800 dark:text-rose-200 text-xs leading-relaxed"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMessage}</div>
            </div>
          )}

          {successNotice && (
            <div
              role="status"
              className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/80 flex items-center gap-3 text-emerald-800 dark:text-emerald-200 text-xs font-medium"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <p>{successNotice}</p>
            </div>
          )}

          {/* TAB 1: MEMBER LOGIN FORM */}
          {activeTab === 'member' && (
            <div className="space-y-5">
              <form onSubmit={handleMemberTraditionalLogin} className="space-y-4">
                {/* Email or Phone Input */}
                <div>
                  <label htmlFor="member-identifier-input" className="block text-xs font-bold text-slate-900 dark:text-slate-100 cmms-form-label mb-1.5">
                    Email Address or Phone Number
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                    <input
                      id="member-identifier-input"
                      type="text"
                      required
                      autoComplete="username"
                      value={memberIdentifier}
                      onChange={(e) => setMemberIdentifier(e.target.value)}
                      placeholder="e.g., member@church.org or +251 91 123 4567"
                      className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm placeholder:text-slate-400 dark:placeholder:text-slate-500 cmms-input"
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label htmlFor="member-password-input" className="block text-xs font-bold text-slate-900 dark:text-slate-100 cmms-form-label">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => handleOpenResetModal(memberIdentifier)}
                      className="text-xs font-semibold underline underline-offset-2 transition-colors cursor-pointer cmms-link-secondary"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                    <input
                      id="member-password-input"
                      type={showMemberPassword ? 'text' : 'password'}
                      required
                      autoComplete="current-password"
                      value={memberPassword}
                      onChange={(e) => setMemberPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-10 pr-10 py-2.5 text-xs sm:text-sm placeholder:text-slate-400 dark:placeholder:text-slate-500 cmms-input"
                    />
                    <button
                      type="button"
                      onClick={() => setShowMemberPassword(!showMemberPassword)}
                      aria-label={showMemberPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-3.5 top-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 cursor-pointer"
                    >
                      {showMemberPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember Me & Security Badge */}
                <div className="flex items-center justify-between text-xs pt-0.5">
                  <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 font-medium cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      style={{ accentColor: 'var(--cmms-primary-color, #2563eb)' }}
                      className="rounded border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                    <span>Remember credentials</span>
                  </label>
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" />
                    Encrypted SSL
                  </span>
                </div>

                {/* Submit Button (Interactive Component States: Default, Hover, Focus Ring, Disabled) */}
                <button
                  type="submit"
                  disabled={isLoading || !memberIdentifier.trim() || !memberPassword}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm shadow-md active:scale-[0.99] cursor-pointer cmms-btn-primary"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Signing in...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In to Member Portal</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* Clean Divider */}
              <div className="relative flex items-center justify-center my-4">
                <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
                <span className="bg-white dark:bg-slate-950 px-3 text-[11px] font-medium text-slate-500 uppercase tracking-wider shrink-0">
                  or continue with
                </span>
                <div className="border-t border-slate-200 dark:border-slate-800 w-full" />
              </div>

              {/* Google OAuth Login Button (Secondary / SSO Action) */}
              <div>
                <button
                  type="button"
                  onClick={handleGoogleMemberLogin}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 hover:text-slate-900 dark:text-slate-200 dark:hover:text-white font-semibold text-xs sm:text-sm transition-all shadow-xs disabled:opacity-50 cursor-pointer cmms-input"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>{isLoading ? 'Verifying with Google...' : 'Continue with Google'}</span>
                </button>
              </div>

              {/* Registration & Application Check Links (Secondary Actions) */}
              <div className="flex flex-col sm:flex-row items-center justify-between pt-2 text-xs border-t border-slate-200 dark:border-slate-800 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowApprovalStatusModal(true);
                    setStatusSearchQuery('');
                    setSearchedWorkflow(null);
                    setHasSearchedStatus(false);
                  }}
                  className="text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 font-medium"
                >
                  <Search className="w-3.5 h-3.5" style={{ color: 'var(--cmms-accent-color, #7c3aed)' }} />
                  <span>Check Application Status</span>
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Don&apos;t have an account?</span>
                  <button
                    type="button"
                    onClick={() => setAuthMode('register')}
                    className="font-bold underline underline-offset-4 cursor-pointer cmms-link-secondary"
                  >
                    Create an Account
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: STAFF & LEADERSHIP LOGIN FORM */}
          {activeTab === 'staff' && (
            <form onSubmit={handleStaffLogin} className="space-y-4">
              {/* Campus Selector */}
              <div>
                <label htmlFor="staff-campus-select" className="block text-xs font-bold text-slate-900 dark:text-slate-100 cmms-form-label mb-1.5">
                  Campus / Branch
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                  <select
                    id="staff-campus-select"
                    value={campusId}
                    onChange={(e) => setCampusId(e.target.value)}
                    disabled={branchesLoading || staffBranches.length === 0}
                    required
                    aria-describedby="staff-campus-help"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm cursor-pointer cmms-input disabled:opacity-60"
                  >
                    <option value="">{branchesLoading ? 'Loading campuses…' : 'Select your campus / branch'}</option>
                    {staffBranches.map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}
                  </select>
                  <p id="staff-campus-help" className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">Active campuses are loaded from the church database.</p>
                  {branchesLoadError && <p role="alert" className="mt-1 text-[11px] text-rose-600 dark:text-rose-400">{branchesLoadError}</p>}
                </div>
              </div>

              {/* Staff Email */}
              <div>
                <label htmlFor="staff-email-input" className="block text-xs font-bold text-slate-900 dark:text-slate-100 cmms-form-label mb-1.5">
                  Leadership Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                  <input
                    id="staff-email-input"
                    type="email"
                    required
                    autoComplete="email"
                    value={staffEmail}
                    onChange={(e) => setStaffEmail(e.target.value)}
                    placeholder="e.g., leader@church.org"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm placeholder:text-slate-400 dark:placeholder:text-slate-500 cmms-input"
                  />
                </div>
              </div>

              {/* Staff Password */}
              <div>
                <label htmlFor="staff-password-input" className="block text-xs font-bold text-slate-900 dark:text-slate-100 cmms-form-label mb-1.5">
                  Security Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                  <input
                    id="staff-password-input"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="current-password"
                    value={staffPassword}
                    onChange={(e) => setStaffPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-10 pr-10 py-2.5 text-xs sm:text-sm placeholder:text-slate-400 dark:placeholder:text-slate-500 cmms-input"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-3.5 top-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Button (Interactive Component States: Default, Hover, Focus Ring, Disabled) */}
              <button
                type="submit"
                disabled={isLoading || !staffEmail.trim() || !staffPassword}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm shadow-md active:scale-[0.99] cursor-pointer cmms-btn-primary"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying Credentials...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Sign In as Staff / Leader</span>
                  </>
                )}
              </button>
            </form>
          )}
        </main>

        {/* Right Footer Bar */}
        <footer className="w-full max-w-md mx-auto pt-6 border-t border-slate-200 dark:border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} {systemName || 'CMMS'}. All rights reserved.</p>
          <span className="font-mono text-slate-500 dark:text-slate-600">Enterprise CMMS</span>
        </footer>
      </section>

      {/* =================================================================== */}
      {/* 3. PASSWORD RESET MODAL WIZARD                                      */}
      {/* =================================================================== */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <button
              type="button"
              onClick={handleCloseResetModal}
              className="absolute right-4 top-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">Reset Member Password</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Recover account via Email or Phone SMS OTP</p>
              </div>
            </div>

            {/* Stepper Progress Bar */}
            <div className="grid grid-cols-3 gap-1.5 mb-5">
              <div className={`h-1.5 rounded-full ${resetStep >= 1 ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-800'}`} />
              <div className={`h-1.5 rounded-full ${resetStep >= 2 ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-800'}`} />
              <div className={`h-1.5 rounded-full ${resetStep >= 3 ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-800'}`} />
            </div>

            {resetError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-start gap-2 text-rose-800 dark:text-rose-200 text-xs">
                <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                <p>{resetError}</p>
              </div>
            )}
            {resetSuccessNotice && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 flex items-start gap-2 text-emerald-800 dark:text-emerald-200 text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                <p>{resetSuccessNotice}</p>
              </div>
            )}

            {/* STEP 1: Enter Identifier & Choose Method */}
            {resetStep === 1 && (
              <form onSubmit={handleRequestReset} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Registered Email Address or Phone Number
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={resetIdentifier}
                      onChange={(e) => setResetIdentifier(e.target.value)}
                      placeholder="e.g. member@gracecathedral.org or +251 91 123 4567"
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Delivery Method</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setResetMethod('email')}
                      className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                        resetMethod === 'email'
                          ? 'bg-blue-50 dark:bg-blue-600/10 border-blue-500 text-blue-700 dark:text-blue-300'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <Mail className="w-4 h-4 shrink-0" />
                      <div className="text-left">
                        <p className="font-bold text-slate-900 dark:text-white">Email</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">Reset code &amp; link</p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setResetMethod('phone')}
                      className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                        resetMethod === 'phone'
                          ? 'bg-blue-50 dark:bg-blue-600/10 border-blue-500 text-blue-700 dark:text-blue-300'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <Smartphone className="w-4 h-4 shrink-0" />
                      <div className="text-left">
                        <p className="font-bold text-slate-900 dark:text-white">SMS Phone</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">Instant 6-digit OTP</p>
                      </div>
                    </button>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleCloseResetModal}
                    className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={resetLoading}
                    style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                    className="flex-1 py-2.5 px-4 rounded-xl hover:opacity-95 text-white text-xs font-bold shadow-md cursor-pointer disabled:opacity-50"
                  >
                    {resetLoading ? 'Sending Code...' : 'Send Verification Code'}
                  </button>
                </div>
              </form>
            )}

            {/* STEP 2: Verify 6-Digit OTP */}
            {resetStep === 2 && (
              <form onSubmit={handleVerifyResetCode} className="space-y-4">
                <div className="bg-slate-50 dark:bg-slate-950/80 rounded-xl p-3 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 space-y-1">
                  <p className="font-medium text-blue-600 dark:text-blue-400">Verification Code Dispatched</p>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                    We sent a 6-digit code to <span className="text-slate-900 dark:text-white font-mono">{resetMaskedDest}</span>.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Enter 6-Digit Verification Code
                  </label>
                  <div className="relative">
                    <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={resetCode}
                      onChange={(e) => setResetCode(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="••••••"
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-center text-sm font-mono tracking-widest focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <button
                    type="button"
                    onClick={() => setResetStep(1)}
                    className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                  >
                    ← Change Email/Phone
                  </button>
                  <button
                    type="button"
                    onClick={handleResendCode}
                    disabled={resendTimer > 0 || resetLoading}
                    className="text-blue-600 dark:text-blue-400 hover:text-blue-500 font-semibold disabled:text-slate-400 dark:disabled:text-slate-600 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {resendTimer > 0 ? `Resend code (${resendTimer}s)` : 'Resend code'}
                  </button>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleCloseResetModal}
                    className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={resetLoading || resetCode.length < 6}
                    style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                    className="flex-1 py-2.5 px-4 rounded-xl hover:opacity-95 text-white text-xs font-bold shadow-md disabled:opacity-50 cursor-pointer"
                  >
                    {resetLoading ? 'Verifying Code...' : 'Verify Code'}
                  </button>
                </div>
              </form>
            )}

            {/* STEP 3: Create & Confirm New Password */}
            {resetStep === 3 && (
              <form onSubmit={handleConfirmResetPassword} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">New Security Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showResetNewPassword ? 'text' : 'password'}
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-slate-200 rounded-xl pl-10 pr-10 py-2.5 text-xs focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowResetNewPassword(!showResetNewPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 cursor-pointer"
                    >
                      {showResetNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Confirm New Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showResetNewPassword ? 'text' : 'password'}
                      required
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="Re-enter new password"
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleCloseResetModal}
                    className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={resetLoading || newPassword.length < 6 || newPassword !== confirmNewPassword}
                    style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                    className="flex-1 py-2.5 px-4 rounded-xl hover:opacity-95 text-white text-xs font-bold shadow-md disabled:opacity-50 cursor-pointer"
                  >
                    {resetLoading ? 'Updating Password...' : 'Save Password'}
                  </button>
                </div>
              </form>
            )}

            {/* STEP 4: Success Notice */}
            {resetStep === 4 && (
              <div className="text-center space-y-4 py-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-base text-slate-900 dark:text-white">Password Updated Successfully!</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Your member security password has been updated. You can now sign in immediately.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    handleCloseResetModal();
                    setActiveTab('member');
                  }}
                  style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                  className="w-full py-3 px-4 rounded-xl hover:opacity-95 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Sign In with New Password
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 4. 30-DAY RE-AUTHENTICATION PROTOCOL MODAL                          */}
      {/* =================================================================== */}
      {reAuthRequired && reAuthUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-500/40 rounded-3xl p-6 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center gap-3 text-blue-600 dark:text-blue-400">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/30 flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">{t('auth.reauth_required_title')}</h3>
                <p className="text-xs text-blue-600 dark:text-blue-400 font-mono">
                  {t('auth.days_since_auth', { days: reAuthUser.daysSinceAuth })}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {t('auth.reauth_required_desc')}
            </p>

            <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Account:</span>
                <span className="font-semibold text-slate-900 dark:text-slate-200">{reAuthUser.name}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Role:</span>
                <span className="font-semibold text-blue-600 dark:text-blue-300">{reAuthUser.role}</span>
              </div>
            </div>

            <form onSubmit={handleReAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Re-enter Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type={showReAuthPassword ? 'text' : 'password'}
                    required
                    value={reAuthPassword}
                    onChange={(e) => setReAuthPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-200 rounded-xl pl-9 pr-9 py-2 text-xs focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowReAuthPassword(!showReAuthPassword)}
                    className="absolute right-2.5 top-2 text-slate-400"
                  >
                    {showReAuthPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">{t('auth.enter_2fa_code')}</label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={reAuth2faCode}
                    onChange={(e) => setReAuth2faCode(e.target.value)}
                    placeholder="••••••"
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs font-mono tracking-widest focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={cancelReAuth}
                  className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                  className="flex-1 py-2.5 px-4 rounded-xl hover:opacity-95 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  {isLoading ? 'Verifying...' : t('auth.verify_and_continue')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 5. STAFF TWO-FACTOR AUTHENTICATION (TOTP / RFC 6238) MODAL          */}
      {/* =================================================================== */}
      {staffMfaState?.isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 dark:bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-500/40 rounded-3xl p-6 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center gap-3 text-blue-600 dark:text-blue-400">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/30 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {!staffMfaState.mfaEnrolled ? 'Enroll Two-Factor Authentication' : 'Enter Authenticator Code'}
                </h3>
                <p className="text-xs text-blue-600 dark:text-blue-300 font-mono">
                  {!staffMfaState.mfaEnrolled ? 'Mandatory Security Setup • AAL2' : 'Two-Factor Authentication • AAL2'}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {!staffMfaState.mfaEnrolled
                ? 'Scan the QR code below with your authenticator app (Google Authenticator, Microsoft Authenticator, 1Password), then enter the 6-digit code to complete setup.'
                : 'Enter the 6-digit verification code from your authenticator app to unlock your leadership session.'}
            </p>

            {!staffMfaState.mfaEnrolled && staffMfaState.totp && (
              <div className="p-4 bg-slate-50 dark:bg-slate-950/90 rounded-2xl border border-blue-200 dark:border-blue-500/30 text-xs space-y-3">
                <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300 font-semibold">
                  <QrCode className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span>Authenticator Setup</span>
                </div>

                {(staffMfaState.totp.uri || staffMfaState.totp.secret) && (
                  <div className="flex flex-col items-center justify-center p-3 bg-white rounded-2xl shadow-inner border border-slate-200">
                    <QRCodeSVG
                            value={
                              staffMfaState.totp.uri ||
                              `otpauth://totp/ChurchStaff:${staffEmail}?secret=${staffMfaState.totp.secret}&issuer=ChurchStaff`
                            }
                            size={168}
                            level="M"
                            includeMargin={false}
                          />
                    <span className="text-[10px] text-slate-500 font-mono mt-2 tracking-tight">
                      Scan with Google Authenticator or 1Password
                    </span>
                  </div>
                )}

                {staffMfaState.totp.secret && (
                  <div>
                    <label className="block text-[11px] text-slate-500 dark:text-slate-400 mb-1">Manual Setup Key:</label>
                    <div className="flex items-center justify-between gap-2 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span className="font-mono text-blue-700 dark:text-blue-200 text-xs tracking-wider break-all select-all">
                        {staffMfaState.totp.secret}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (staffMfaState?.totp?.secret) {
                            navigator.clipboard.writeText(staffMfaState.totp.secret);
                            setIsCopiedSecret(true);
                            setTimeout(() => setIsCopiedSecret(false), 2000);
                          }
                        }}
                        aria-label="Copy secret key"
                        className="px-2.5 py-1.5 rounded-lg bg-blue-100 dark:bg-blue-600/30 hover:bg-blue-200 dark:hover:bg-blue-600/50 text-blue-700 dark:text-blue-300 text-xs flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                      >
                        {isCopiedSecret ? <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{isCopiedSecret ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {staffMfaSessionExpired ? (
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-600/50 text-amber-800 dark:text-amber-200 text-xs space-y-3">
                <div className="flex items-center gap-2 font-bold text-amber-700 dark:text-amber-300">
                  <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>Session Expired</span>
                </div>
                <p className="leading-relaxed">
                  {staffMfaError || 'Your login session has expired. Please return to the login screen and sign in again.'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setStaffMfaState(null);
                    setStaffMfaCode('');
                    setStaffMfaError('');
                    setStaffMfaSessionExpired(false);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Return to Sign In</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleStaffMfaSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    6-Digit Authenticator Code
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={6}
                      autoFocus
                      required
                      value={staffMfaCode}
                      onChange={(e) => {
                        setStaffMfaCode(e.target.value.replace(/[^0-9]/g, ''));
                        if (staffMfaError) setStaffMfaError('');
                      }}
                      placeholder="123456"
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-10 pr-4 py-2.5 text-center text-sm font-mono tracking-widest focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {staffMfaError && (
                  <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">{staffMfaError}</p>
                )}

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setStaffMfaState(null)}
                    className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isMfaVerifying || staffMfaCode.length < 6}
                    style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                    className="flex-1 py-2.5 px-4 rounded-xl hover:opacity-95 text-white font-bold text-xs shadow-md disabled:opacity-50 cursor-pointer"
                  >
                    {isMfaVerifying ? 'Verifying...' : 'Verify & Sign In'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 6. CHECK MEMBERSHIP APPROVAL STATUS MODAL                           */}
      {/* =================================================================== */}
      {showApprovalStatusModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <button
              type="button"
              onClick={() => setShowApprovalStatusModal(false)}
              className="absolute right-4 top-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">Check Application Approval Status</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Track your member registration in the church database</p>
              </div>
            </div>

            <form onSubmit={handleSearchApprovalStatus} className="space-y-3 mb-5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Application Reference Code, Phone, or Email
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <FileText className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={statusSearchQuery}
                    onChange={(e) => setStatusSearchQuery(e.target.value)}
                    placeholder="e.g. MEM-APP-123456 or phone"
                    className="w-full bg-slate-50 dark:bg-slate-950/80 border border-slate-300 dark:border-slate-800 text-slate-900 dark:text-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  />
                </div>
                <button
                  type="submit"
                  style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                  className="px-4 py-2.5 rounded-xl hover:opacity-95 text-white font-bold text-xs shadow-md shrink-0 cursor-pointer transition-all"
                >
                  Lookup
                </button>
              </div>
            </form>

            {hasSearchedStatus && searchedWorkflow && (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/90 border border-slate-200 dark:border-slate-800 space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                    {searchedWorkflow.requestCode || searchedWorkflow.id}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                      searchedWorkflow.status === 'Approved'
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                        : searchedWorkflow.status === 'Rejected'
                        ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                        : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                    }`}
                  >
                    {searchedWorkflow.status === 'Approved' && <CheckCircle2 className="w-3.5 h-3.5" />}
                    {searchedWorkflow.status === 'Pending' && <Clock className="w-3.5 h-3.5" />}
                    {searchedWorkflow.status === 'Rejected' && <AlertCircle className="w-3.5 h-3.5" />}
                    <span>{searchedWorkflow.status}</span>
                  </span>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500 dark:text-slate-400">
                    <span>Applicant:</span>
                    <span className="font-semibold text-slate-900 dark:text-white">{searchedWorkflow.requesterName}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 dark:text-slate-400">
                    <span>Campus:</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{searchedWorkflow.branchName || 'Main Cathedral HQ'}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 dark:text-slate-400">
                    <span>Submitted:</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300">{searchedWorkflow.submittedDate}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 dark:text-slate-400">
                    <span>Current Review Step:</span>
                    <span className="font-semibold text-blue-600 dark:text-blue-300">{searchedWorkflow.currentStep || 'Pastoral & Elder Board Review'}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end">
                  {searchedWorkflow.status === 'Approved' ? (
                    <button
                      type="button"
                      onClick={() => {
                        setShowApprovalStatusModal(false);
                        setActiveTab('member');
                        if (searchedWorkflow.requesterEmail) {
                          setMemberIdentifier(searchedWorkflow.requesterEmail);
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer"
                    >
                      Sign In Now
                    </button>
                  ) : (
                    <span className="text-[11px] text-amber-600 dark:text-amber-400/90 font-medium">
                      Awaiting pastoral confirmation
                    </span>
                  )}
                </div>
              </div>
            )}

            {hasSearchedStatus && !searchedWorkflow && (
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 space-y-3 text-center">
                <AlertCircle className="w-6 h-6 text-amber-500 dark:text-amber-400 mx-auto" />
                <p className="text-xs text-slate-700 dark:text-slate-300">
                  No membership application matching &ldquo;<strong className="text-slate-900 dark:text-white">{statusSearchQuery}</strong>&rdquo; was found in the database.
                </p>
                <div className="pt-1 flex items-center justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      setShowApprovalStatusModal(false);
                      setAuthMode('register');
                    }}
                    style={{ backgroundColor: 'var(--cmms-primary-color, #2563eb)' }}
                    className="px-4 py-2 rounded-xl hover:opacity-95 text-white font-bold text-xs cursor-pointer"
                  >
                    Submit New Member Registration
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
