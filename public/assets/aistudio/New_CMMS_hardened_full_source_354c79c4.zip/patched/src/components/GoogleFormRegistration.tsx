import React, { useState, useEffect } from 'react';
import {
  Church,
  CheckCircle2,
  UserPlus,
  Heart,
  MapPin,
  Briefcase,
  Send,
  ArrowLeft,
  Camera,
  ShieldCheck,
  Sparkles,
  FileSpreadsheet,
  AlertCircle,
  Clock,
  Lock,
  Ban,
  RefreshCw,
  Building2,
} from 'lucide-react';
import { useCMMS } from '../context/CMMSContext';
import { Member } from '../types';
import { EthiopianPhoneInput, validateEthiopianPhone } from './EthiopianPhoneInput';
import { apiService } from '../services/api';

interface GoogleFormRegistrationProps {
  registrationToken?: string;
  initialBranchId?: string;
  preSelectedBranchId?: string;
  onBackToPortal?: () => void;
}

export const GoogleFormRegistration: React.FC<GoogleFormRegistrationProps> = ({
  registrationToken,
  initialBranchId,
  preSelectedBranchId,
  onBackToPortal,
}) => {
  const effectiveInitialBranch = initialBranchId || preSelectedBranchId;
  const { branches, ministries, addMember, addWorkflowRequest, systemName, churchLogoUrl } = useCMMS();

  // Token validation states when accessed via /register/:token
  const [validatingToken, setValidatingToken] = useState<boolean>(Boolean(registrationToken));
  const [tokenState, setTokenState] = useState<{
    valid: boolean;
    status: 'active' | 'expired' | 'revoked' | 'used' | 'not_found' | 'invalid' | 'error';
    reason?: string;
    invitation?: any;
  }>({
    valid: !registrationToken,
    status: 'active',
  });

  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [generatedMemberId, setGeneratedMemberId] = useState('');
  const [generatedAppRef, setGeneratedAppRef] = useState('');
  const [submissionRequiresApproval, setSubmissionRequiresApproval] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeSection, setActiveSection] = useState<number>(1);

  const [formData, setFormData] = useState<Partial<Member>>({
    title: 'Mr',
    firstName: '',
    middleName: '',
    lastName: '',
    gender: 'Male',
    dateOfBirth: '',
    nationality: 'Ethiopian',
    nationalIdNumber: '',
    passportNumber: '',
    photoUrl: '',
    maritalStatus: 'Single',
    marriageDate: '',
    spouseName: '',
    spousePhone: '',
    maleChildrenCount: 0,
    femaleChildrenCount: 0,
    adoptedChildrenCount: 0,
    primaryPhone: '',
    altPhone: '',
    email: '',
    preferredCommChannel: 'SMS',
    streetAddress: '',
    woreda: '',
    kebele: '',
    houseNumber: '',
    subCity: '',
    city: 'Addis Ababa',
    region: 'Addis Ababa',
    postalCode: '',
    branchId:
      effectiveInitialBranch && effectiveInitialBranch !== 'all'
        ? effectiveInitialBranch
        : branches[0]?.id || 'br-1',
    membershipDate: new Date().toISOString().split('T')[0],
    membershipLocation: 'Grace Cathedral International',
    salvationDate: '',
    salvationLocation: '',
    isWaterBaptized: false,
    waterBaptismDate: '',
    waterBaptismLocation: '',
    isHolySpiritBaptized: false,
    foundationCourseCompleted: false,
    ministriesJoinedNow: [],
    ministriesServedBefore: [],
    ministryIds: [],
    educationLevel: 'Bachelor',
    fieldOfStudy: '',
    occupation: '',
    employerName: '',
    employerType: 'Private',
    employerTypeOther: '',
    bloodType: 'O+',
    emergencyContact: {
      name: '',
      relationship: '',
      phone: '',
    },
  });

  // Validate registrationToken against backend when mounted
  useEffect(() => {
    if (!registrationToken) {
      setValidatingToken(false);
      return;
    }

    let cancelled = false;
    const verifyToken = async () => {
      setValidatingToken(true);
      try {
        const res = await apiService.validateRegistrationToken(registrationToken);
        if (cancelled) return;

        if (res.valid && res.invitation) {
          setTokenState({
            valid: true,
            status: 'active',
            invitation: res.invitation,
          });
          setSubmissionRequiresApproval(Boolean(res.invitation.requiresApproval ?? true));
          setFormData((prev) => ({
            ...prev,
            branchId:
              res.invitation.branchId && res.invitation.branchId !== 'all'
                ? res.invitation.branchId
                : prev.branchId,
            membershipLocation:
              res.invitation.branchName && res.invitation.branchId !== 'all'
                ? res.invitation.branchName
                : res.invitation.churchName || prev.membershipLocation,
            ministriesJoinedNow: res.invitation.ministryName
              ? [res.invitation.ministryName]
              : prev.ministriesJoinedNow,
            ministryIds: res.invitation.ministryId
              ? [res.invitation.ministryId]
              : prev.ministryIds,
          }));
        } else {
          setTokenState({
            valid: false,
            status: res.status || 'invalid',
            reason:
              res.reason ||
              'This registration invitation link is no longer valid. Please contact your church administrator.',
            invitation: res.invitation,
          });
        }
      } catch {
        if (!cancelled) {
          setTokenState({
            valid: false,
            status: 'error',
            reason: 'Unable to verify the registration link at this time. Please check your connection and try again.',
          });
        }
      } finally {
        if (!cancelled) {
          setValidatingToken(false);
        }
      }
    };

    verifyToken();
    return () => {
      cancelled = true;
    };
  }, [registrationToken]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({ ...prev, photoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleArrayItem = (field: 'ministriesJoinedNow' | 'ministriesServedBefore', value: string) => {
    const current = formData[field] || [];
    if (current.includes(value)) {
      setFormData({ ...formData, [field]: current.filter((item) => item !== value) });
    } else {
      setFormData({ ...formData, [field]: [...current, value] });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!formData.firstName?.trim() || !formData.lastName?.trim() || !formData.primaryPhone?.trim()) {
      setErrorMsg('Please fill in all required fields: First Name, Last Name, and Primary Phone Number.');
      return;
    }

    const primaryCheck = validateEthiopianPhone(formData.primaryPhone);
    if (!primaryCheck.isValid) {
      setErrorMsg(primaryCheck.error || 'Invalid Primary Ethiopian phone number.');
      return;
    }

    if (formData.altPhone?.trim()) {
      const altCheck = validateEthiopianPhone(formData.altPhone);
      if (!altCheck.isValid) {
        setErrorMsg(`Alternative Phone: ${altCheck.error}`);
        return;
      }
    }

    if (formData.maritalStatus === 'Married' && formData.spousePhone?.trim()) {
      const spouseCheck = validateEthiopianPhone(formData.spousePhone);
      if (!spouseCheck.isValid) {
        setErrorMsg(`Spouse Phone: ${spouseCheck.error}`);
        return;
      }
    }

    if (formData.emergencyContact?.phone?.trim()) {
      const emgCheck = validateEthiopianPhone(formData.emergencyContact.phone);
      if (!emgCheck.isValid) {
        setErrorMsg(`Emergency Contact Phone: ${emgCheck.error}`);
        return;
      }
    }

    setSubmitting(true);
    try {
      // Submit to real backend endpoint POST /api/auth/register-public
      const res = await apiService.registerPublic({
        registrationToken: registrationToken || undefined,
        title: formData.title || 'Mr',
        firstName: formData.firstName.trim(),
        middleName: formData.middleName?.trim() || '',
        lastName: formData.lastName.trim(),
        gender: formData.gender || 'Male',
        dateOfBirth: formData.dateOfBirth || '1990-01-01',
        nationality: formData.nationality || 'Ethiopian',
        nationalIdNumber: formData.nationalIdNumber,
        passportNumber: formData.passportNumber,
        photoUrl: formData.photoUrl,
        maritalStatus: formData.maritalStatus || 'Single',
        marriageDate: formData.marriageDate,
        spouseName: formData.spouseName,
        spousePhone: formData.spousePhone,
        maleChildrenCount: formData.maleChildrenCount || 0,
        femaleChildrenCount: formData.femaleChildrenCount || 0,
        adoptedChildrenCount: formData.adoptedChildrenCount || 0,
        phone: primaryCheck.normalized || formData.primaryPhone.trim(),
        altPhone: formData.altPhone || '',
        email: formData.email || '',
        preferredCommChannel: formData.preferredCommChannel || 'SMS',
        streetAddress: formData.streetAddress || '',
        woreda: formData.woreda || '',
        kebele: formData.kebele || '',
        houseNumber: formData.houseNumber || '',
        city: formData.city || 'Addis Ababa',
        subCity: formData.subCity || '',
        region: formData.region || 'Addis Ababa',
        postalCode: formData.postalCode || '',
        branchId: formData.branchId || branches[0]?.id || 'br-1',
        membershipDate: formData.membershipDate || new Date().toISOString().split('T')[0],
        membershipLocation: formData.membershipLocation || 'Grace Cathedral International',
        salvationDate: formData.salvationDate,
        salvationLocation: formData.salvationLocation,
        isWaterBaptized: Boolean(formData.isWaterBaptized),
        waterBaptized: Boolean(formData.isWaterBaptized),
        waterBaptismDate: formData.waterBaptismDate,
        waterBaptismLocation: formData.waterBaptismLocation,
        isHolySpiritBaptized: Boolean(formData.isHolySpiritBaptized),
        foundationCourseCompleted: Boolean(formData.foundationCourseCompleted),
        ministriesJoinedNow: formData.ministriesJoinedNow || [],
        ministriesServedBefore: formData.ministriesServedBefore || [],
        ministryIds: formData.ministryIds || [],
        educationLevel: formData.educationLevel,
        fieldOfStudy: formData.fieldOfStudy,
        occupation: formData.occupation,
        employerName: formData.employerName,
        employerType: formData.employerType,
        employerTypeOther: formData.employerTypeOther,
        bloodType: formData.bloodType,
        emergencyContact: formData.emergencyContact || { name: '', relationship: '', phone: '' },
      });

      if (res.member) {
        addMember(res.member);
      }
      if (res.workflow) {
        addWorkflowRequest(res.workflow);
      }

      setGeneratedMemberId(res.memberIdNumber || `GC-${new Date().getFullYear()}-1001`);
      setGeneratedAppRef(res.applicationReference || '');
      setSubmissionRequiresApproval(res.requiresApproval ?? true);
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setErrorMsg(
        err?.message ||
          'Failed to submit registration form. Please verify your details and try again.'
      );
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setSubmitting(false);
    }
  };

  // Loading state while validating registration token
  if (validatingToken) {
    return (
      <div className="min-h-screen bg-[#f0ebf8] dark:bg-slate-950 py-16 px-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-purple-200 dark:border-slate-800 p-8 text-center space-y-4">
          <RefreshCw className="w-10 h-10 text-purple-600 animate-spin mx-auto" />
          <h2 className="text-lg font-black text-slate-900 dark:text-white">
            Verifying Official Registration Invitation...
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Validating cryptographic invitation token with {systemName || 'Grace Cathedral International'}...
          </p>
        </div>
      </div>
    );
  }

  // Invalid / Expired / Revoked / Used Token Screen
  if (registrationToken && !tokenState.valid) {
    return (
      <div className="min-h-screen bg-[#f0ebf8] dark:bg-slate-950 py-12 px-4 flex items-center justify-center">
        <div className="max-w-lg w-full bg-white dark:bg-slate-900 rounded-3xl shadow-xl border-t-8 border-t-rose-600 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 text-center space-y-5">
          <div className="w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
            {tokenState.status === 'expired' ? (
              <Clock className="w-8 h-8" />
            ) : tokenState.status === 'revoked' ? (
              <Ban className="w-8 h-8" />
            ) : (
              <Lock className="w-8 h-8" />
            )}
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
              Invitation {tokenState.status.replace('_', ' ')}
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              Registration Link Unavailable
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              {tokenState.reason}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
            Please contact your church office or ministry leader to request a new active registration link.
          </div>

          {onBackToPortal && (
            <button
              type="button"
              onClick={onBackToPortal}
              className="w-full min-h-[44px] px-6 py-3 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to Church Portal</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // Submitted Confirmation View
  if (submitted) {
    return (
      <div className="min-h-screen bg-[#f0ebf8] dark:bg-slate-950 py-8 sm:py-12 px-4 flex items-center justify-center">
        <div className="max-w-2xl w-full bg-white dark:bg-slate-900 rounded-3xl shadow-xl border-t-8 border-t-purple-600 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 animate-in zoom-in-95 duration-200">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-8 h-8 sm:w-10 sm:h-10" />
            </div>
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                {submissionRequiresApproval
                  ? 'Application Queued for Pastoral Review'
                  : 'Membership Active & Verified'}
              </span>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                {systemName || 'Grace Cathedral International'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                Your membership registration response has been recorded.
              </p>
            </div>
          </div>

          <div className="p-4 sm:p-5 bg-purple-50 dark:bg-purple-950/30 rounded-2xl border border-purple-200 dark:border-purple-900/50 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-purple-200/60 dark:border-purple-800/60 pb-2.5">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                  Official Member ID Number
                </p>
                <p className="text-lg sm:text-xl font-mono font-black text-slate-900 dark:text-white mt-0.5">
                  {generatedMemberId}
                </p>
              </div>
              {generatedAppRef && (
                <div className="text-left sm:text-right">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                    Tracking Reference
                  </p>
                  <p className="text-sm font-mono font-black text-purple-700 dark:text-purple-300 mt-0.5">
                    {generatedAppRef}
                  </p>
                </div>
              )}
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Thank you,{' '}
              <strong>
                {formData.title} {formData.firstName} {formData.lastName}
              </strong>
              !{' '}
              {submissionRequiresApproval
                ? 'Your profile has been submitted to the Pastoral & Branch Approvals Queue. Once approved by church leadership, your membership pass will be activated.'
                : 'Your membership profile has been automatically approved and added to the active church directory.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            { !registrationToken || !tokenState.invitation?.singleUse ? (
              <button
                type="button"
                onClick={() => {
                  setSubmitted(false);
                  setFormData({
                    ...formData,
                    firstName: '',
                    middleName: '',
                    lastName: '',
                    primaryPhone: '',
                    email: '',
                  });
                }}
                className="min-h-[44px] px-4 py-2.5 text-xs font-bold text-purple-600 dark:text-purple-400 hover:underline cursor-pointer"
              >
                Submit another family member response
              </button>
            ) : (
              <span className="text-xs text-slate-400">Single-use invitation completed.</span>
            )}

            {onBackToPortal && (
              <button
                type="button"
                onClick={onBackToPortal}
                className="min-h-[44px] px-5 py-2.5 bg-slate-900 dark:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-slate-800 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                Return to Portal Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const effectiveInvitation = tokenState.invitation;
  const isBranchLocked = Boolean(
    effectiveInvitation?.branchId && effectiveInvitation.branchId !== 'all'
  );

  return (
    <div className="min-h-screen bg-[#f0ebf8] dark:bg-slate-950 py-4 sm:py-8 px-3 sm:px-6 font-sans">
      <div className="max-w-3xl mx-auto space-y-5">
        {/* Top Bar Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-2 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-4 py-3 rounded-2xl border border-purple-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-purple-600 flex items-center justify-center text-white shrink-0">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-black text-slate-800 dark:text-slate-200 block truncate">
                {effectiveInvitation?.title || `${systemName || 'Grace Cathedral'} — Public Registration Form`}
              </span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 shrink-0" />
                {effectiveInvitation
                  ? `Verified Invitation • ${effectiveInvitation.branchName}`
                  : 'Official Digital Membership Intake'}
              </span>
            </div>
          </div>

          {onBackToPortal && (
            <button
              type="button"
              onClick={onBackToPortal}
              className="min-h-[38px] px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1.5 hover:bg-slate-200 cursor-pointer transition-all shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Sign In Portal</span>
            </button>
          )}
        </div>

        {/* Google Form Style Header Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-md border-t-[10px] border-t-purple-600 border border-slate-200 dark:border-slate-800 p-5 sm:p-8 space-y-4">
          <div className="flex items-center gap-3.5">
            {churchLogoUrl ? (
              <img
                src={churchLogoUrl}
                alt="Logo"
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl object-cover border border-purple-200"
              />
            ) : (
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-purple-600 text-white flex items-center justify-center shadow-md shrink-0">
                <Church className="w-6 h-6 sm:w-8 sm:h-8" />
              </div>
            )}
            <div className="min-w-0">
              <h1 className="text-xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                {effectiveInvitation?.churchName || systemName || 'Grace Cathedral International'}
              </h1>
              <p className="text-xs sm:text-sm font-semibold text-purple-600 dark:text-purple-400">
                Official Member Registration & Spiritual Census Form
              </p>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed pt-2 border-t border-slate-100 dark:border-slate-800">
            {effectiveInvitation?.description ||
              'Welcome to our church family! Please complete this official registration form so our pastoral team can serve you, connect you with a fellowship group, and issue your digital membership pass.'}
          </p>

          {effectiveInvitation && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="px-3 py-1 rounded-xl bg-purple-50 dark:bg-purple-950/50 border border-purple-200 dark:border-purple-800 text-[11px] font-bold text-purple-800 dark:text-purple-300 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                Campus: {effectiveInvitation.branchName}
              </span>
              {effectiveInvitation.ministryName && (
                <span className="px-3 py-1 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-[11px] font-bold text-indigo-800 dark:text-indigo-300">
                  Ministry: {effectiveInvitation.ministryName}
                </span>
              )}
            </div>
          )}

          <div className="text-xs font-bold text-rose-600 dark:text-rose-400">
            * Indicates required question
          </div>
        </div>

        {errorMsg && (
          <div className="p-4 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 rounded-2xl flex items-center gap-3 text-rose-700 dark:text-rose-300 text-xs font-bold">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Section Progress Pills (Scrollable on Mobile) */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            { num: 1, label: '1. Personal & Family' },
            { num: 2, label: '2. Contact & Residence' },
            { num: 3, label: '3. Spiritual & Ministries' },
            { num: 4, label: '4. Career & Emergency' },
          ].map((sec) => (
            <button
              key={sec.num}
              type="button"
              onClick={() => setActiveSection(sec.num)}
              className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                activeSection === sec.num
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
              }`}
            >
              {sec.label}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* SECTION 1: PERSONAL IDENTITY & FAMILY */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="bg-purple-600 text-white px-5 sm:px-6 py-3.5 flex items-center gap-2">
              <UserPlus className="w-4 h-4" />
              <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider">
                Section 1: Personal Identity & Family Details
              </h2>
            </div>

            <div className="p-5 sm:p-6 space-y-5">
              {/* Profile Photo Upload */}
              <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
                <div className="w-20 h-20 rounded-2xl bg-purple-100 dark:bg-purple-950/60 border-2 border-dashed border-purple-300 dark:border-purple-700 flex items-center justify-center overflow-hidden shrink-0">
                  {formData.photoUrl ? (
                    <img src={formData.photoUrl} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-7 h-7 text-purple-500" />
                  )}
                </div>
                <div className="space-y-1.5 text-center sm:text-left">
                  <label className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                    Upload Member Passport / Profile Photo (Optional)
                  </label>
                  <p className="text-[11px] text-slate-500">
                    Used for your digital church membership ID card and directory profile.
                  </p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="text-xs text-slate-600 file:mr-3 file:py-2 file:px-3.5 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-purple-600 file:text-white hover:file:bg-purple-700 cursor-pointer"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Title *
                  </label>
                  <select
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value as any })}
                    className="w-full min-h-[44px] px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white"
                  >
                    {['Mr', 'Mrs', 'Miss', 'Dr', 'Pastor', 'Deacon', 'Elder', 'Evangelist', 'Prophet', 'Apostle', 'Bishop'].map(
                      (t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      )
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    First Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="Your first name"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Father's / Middle Name
                  </label>
                  <input
                    type="text"
                    value={formData.middleName}
                    onChange={(e) => setFormData({ ...formData, middleName: e.target.value })}
                    placeholder="Middle name"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Last Name / Surname <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="Your surname"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Gender <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Date of Birth <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.dateOfBirth}
                    onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Marital Status
                  </label>
                  <select
                    value={formData.maritalStatus}
                    onChange={(e) => setFormData({ ...formData, maritalStatus: e.target.value as any })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                  </select>
                </div>
              </div>

              {formData.maritalStatus === 'Married' && (
                <div className="p-4 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/50 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Spouse Full Name
                    </label>
                    <input
                      type="text"
                      value={formData.spouseName}
                      onChange={(e) => setFormData({ ...formData, spouseName: e.target.value })}
                      placeholder="Spouse name"
                      className="w-full min-h-[44px] px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <EthiopianPhoneInput
                      label="Spouse Phone Number"
                      value={formData.spousePhone || ''}
                      onChange={(e) => setFormData({ ...formData, spousePhone: e.target.value })}
                      placeholder="0911000000"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Marriage / Wedding Date
                    </label>
                    <input
                      type="date"
                      value={formData.marriageDate}
                      onChange={(e) => setFormData({ ...formData, marriageDate: e.target.value })}
                      className="w-full min-h-[44px] px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Number of Sons (Male Children)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formData.maleChildrenCount}
                    onChange={(e) => setFormData({ ...formData, maleChildrenCount: Number(e.target.value) })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Number of Daughters (Female Children)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formData.femaleChildrenCount}
                    onChange={(e) => setFormData({ ...formData, femaleChildrenCount: Number(e.target.value) })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Adopted Children
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formData.adoptedChildrenCount}
                    onChange={(e) => setFormData({ ...formData, adoptedChildrenCount: Number(e.target.value) })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: CONTACT & RESIDENTIAL LOCATION */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="bg-indigo-600 text-white px-5 sm:px-6 py-3.5 flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider">
                Section 2: Contact & Residential Location
              </h2>
            </div>

            <div className="p-5 sm:p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <EthiopianPhoneInput
                    label="Primary Phone Number"
                    required
                    value={formData.primaryPhone || ''}
                    onChange={(e) => setFormData({ ...formData, primaryPhone: e.target.value })}
                    placeholder="0911234567 or +251911234567"
                    showQuickPrefixes={true}
                  />
                </div>

                <div>
                  <EthiopianPhoneInput
                    label="Alternative Phone"
                    value={formData.altPhone || ''}
                    onChange={(e) => setFormData({ ...formData, altPhone: e.target.value })}
                    placeholder="0711234567"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="you@example.com"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    City / Sub-City
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g., Bole, Addis Ababa"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Woreda
                  </label>
                  <input
                    type="text"
                    value={formData.woreda}
                    onChange={(e) => setFormData({ ...formData, woreda: e.target.value })}
                    placeholder="e.g., Woreda 03"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Kebele
                  </label>
                  <input
                    type="text"
                    value={formData.kebele}
                    onChange={(e) => setFormData({ ...formData, kebele: e.target.value })}
                    placeholder="e.g., Kebele 12"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    House Number
                  </label>
                  <input
                    type="text"
                    value={formData.houseNumber}
                    onChange={(e) => setFormData({ ...formData, houseNumber: e.target.value })}
                    placeholder="e.g., New / 452"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Detailed Street Address / Landmark
                </label>
                <input
                  type="text"
                  value={formData.streetAddress}
                  onChange={(e) => setFormData({ ...formData, streetAddress: e.target.value })}
                  placeholder="Street name, neighborhood landmark..."
                  className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* SECTION 3: SPIRITUAL HISTORY & MINISTRY INTERESTS */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="bg-emerald-600 text-white px-5 sm:px-6 py-3.5 flex items-center gap-2">
              <Heart className="w-4 h-4" />
              <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider">
                Section 3: Spiritual Background & Ministry Service
              </h2>
            </div>

            <div className="p-5 sm:p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Preferred Church Branch / Campus *
                  </label>
                  <select
                    value={formData.branchId}
                    disabled={isBranchLocked}
                    onChange={(e) => setFormData({ ...formData, branchId: e.target.value })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white disabled:opacity-75"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} — {b.city}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Where did you receive Salvation? (Church / City)
                  </label>
                  <input
                    type="text"
                    value={formData.salvationLocation}
                    onChange={(e) => setFormData({ ...formData, salvationLocation: e.target.value })}
                    placeholder="Church name & city"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Salvation Date (Approximate)
                  </label>
                  <input
                    type="date"
                    value={formData.salvationDate}
                    onChange={(e) => setFormData({ ...formData, salvationDate: e.target.value })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div className="flex flex-col justify-end space-y-2">
                  <label className="flex items-center gap-2.5 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.isWaterBaptized}
                      onChange={(e) => setFormData({ ...formData, isWaterBaptized: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                    />
                    <span>I have been Water Baptized by Immersion</span>
                  </label>

                  <label className="flex items-center gap-2.5 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.foundationCourseCompleted}
                      onChange={(e) => setFormData({ ...formData, foundationCourseCompleted: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                    />
                    <span>I have completed Believers Foundation Class</span>
                  </label>
                </div>
              </div>

              {formData.isWaterBaptized && (
                <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Water Baptism Date
                    </label>
                    <input
                      type="date"
                      value={formData.waterBaptismDate}
                      onChange={(e) => setFormData({ ...formData, waterBaptismDate: e.target.value })}
                      className="w-full min-h-[44px] px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Where were you Water Baptized?
                    </label>
                    <input
                      type="text"
                      value={formData.waterBaptismLocation}
                      onChange={(e) => setFormData({ ...formData, waterBaptismLocation: e.target.value })}
                      placeholder="Church or location name"
                      className="w-full min-h-[44px] px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  Which Ministries would you like to join or serve in? (Select all that apply)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {ministries.map((min) => {
                    const selected = (formData.ministriesJoinedNow || []).includes(min.name);
                    return (
                      <button
                        key={min.id}
                        type="button"
                        onClick={() => toggleArrayItem('ministriesJoinedNow', min.name)}
                        className={`min-h-[42px] px-3 py-2 rounded-xl border text-left text-xs font-semibold flex items-center justify-between transition-all cursor-pointer ${
                          selected
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-700 dark:text-emerald-300'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <span className="truncate">{min.name}</span>
                        {selected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 4: EDUCATION, OCCUPATION & EMERGENCY CONTACT */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="bg-amber-600 text-white px-5 sm:px-6 py-3.5 flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider">
                Section 4: Education, Profession & Emergency Contact
              </h2>
            </div>

            <div className="p-5 sm:p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Highest Education Level
                  </label>
                  <select
                    value={formData.educationLevel}
                    onChange={(e) => setFormData({ ...formData, educationLevel: e.target.value as any })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    {[
                      'Primary',
                      'High School',
                      'Certificate / Diploma',
                      'Bachelor’s Degree',
                      'Master’s Degree',
                      'Doctorate (PhD)',
                      'Theological Seminary',
                      'Other',
                    ].map((lvl) => (
                      <option key={lvl} value={lvl}>
                        {lvl}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Occupation / Job Title
                  </label>
                  <input
                    type="text"
                    value={formData.occupation}
                    onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                    placeholder="e.g., Accountant, Engineer, Student"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Employment Sector
                  </label>
                  <select
                    value={formData.employerType}
                    onChange={(e) => setFormData({ ...formData, employerType: e.target.value as any })}
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    {[
                      'Government',
                      'Private Sector',
                      'Self-Employed / Business',
                      'NGO / International Org',
                      'Church / Ministry Full-Time',
                      'Student',
                      'Unemployed',
                      'Retired',
                      'Other',
                    ].map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Employer / Organization / School Name
                  </label>
                  <input
                    type="text"
                    value={formData.employerName}
                    onChange={(e) => setFormData({ ...formData, employerName: e.target.value })}
                    placeholder="Company or Institution Name"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Emergency Contact */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <h3 className="text-xs font-black uppercase tracking-wider text-rose-600 dark:text-rose-400 mb-3">
                  Emergency Contact Person
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Emergency Contact Name
                    </label>
                    <input
                      type="text"
                      value={formData.emergencyContact?.name || ''}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          emergencyContact: { ...formData.emergencyContact!, name: e.target.value },
                        })
                      }
                      placeholder="Full name"
                      className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      Relationship
                    </label>
                    <input
                      type="text"
                      value={formData.emergencyContact?.relationship || ''}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          emergencyContact: { ...formData.emergencyContact!, relationship: e.target.value },
                        })
                      }
                      placeholder="e.g., Spouse, Parent, Sibling"
                      className="w-full min-h-[44px] px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <EthiopianPhoneInput
                      label="Emergency Contact Phone"
                      value={formData.emergencyContact?.phone || ''}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          emergencyContact: { ...formData.emergencyContact!, phone: e.target.value },
                        })
                      }
                      placeholder="0911223344"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Footer */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-2 pb-12">
            <button
              type="submit"
              disabled={submitting}
              className="w-full sm:w-auto min-h-[48px] px-8 py-3.5 bg-purple-600 hover:bg-purple-700 active:scale-95 text-white rounded-2xl font-black text-sm shadow-lg shadow-purple-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{submitting ? 'Submitting Registration...' : 'Submit Official Registration'}</span>
            </button>

            <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
              <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
              <span>Powered by {systemName || 'Grace Cathedral'} Digital Census</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
