import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Search,
  CheckCircle2,
  Layers,
  Code2,
  ExternalLink,
  Sun,
  Globe,
} from 'lucide-react';
import { useBible } from '../context/BibleContext';
import { BiblePassage, normalizeToUsfm } from './bible/BiblePassage';
import { VerseOfTheDayCard } from './bible/VerseOfTheDayCard';
import { useNavigate } from 'react-router-dom';

interface YouVersionSdkPanelProps {
  onJumpToReference?: (bookId: string, chapter: number) => void;
}

export const YouVersionSdkPanel: React.FC<YouVersionSdkPanelProps> = ({ onJumpToReference }) => {
  const {
    selectedVersionId,
    setSelectedVersionId,
    selectedSlotKey,
    setSelectedSlotKey,
    userVisibleBibles,
    otherAvailableBibles,
    jumpToReference,
  } = useBible();
  const navigate = useNavigate();

  const [selectedReference, setSelectedReference] = useState<string>('JHN.3.16');
  const [customRefInput, setCustomRefInput] = useState<string>('');

  const PRESET_REFERENCES = [
    { label: 'John 3:16 (Love of God)', ref: 'JHN.3.16' },
    { label: 'Psalm 23 (The Lord is my shepherd)', ref: 'PSA.23.1-6' },
    { label: 'Romans 8:28 (All things work together)', ref: 'ROM.8.28' },
    { label: 'Philippians 4:13 (I can do all things)', ref: 'PHP.4.13' },
    { label: 'Proverbs 3:5-6 (Trust in the Lord)', ref: 'PRO.3.5-6' },
    { label: 'Matthew 28:19-20 (Great Commission)', ref: 'MAT.28.19-20' },
  ];

  const POPULAR_TRANSLATIONS = userVisibleBibles.map((b) => ({
    id: b.id,
    slotKey: b.slotKey || `CUSTOM_${b.id}`,
    label: b.userDisplayLabel || `${b.localized_abbreviation || b.abbreviation} — ${b.localized_title || b.title}`,
    lang: b.language_tag === 'am' ? 'Amharic' : 'English',
  }));

  const handleCustomSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customRefInput.trim()) return;
    const usfm = normalizeToUsfm(customRefInput.trim());
    setSelectedReference(usfm);
    setCustomRefInput('');
  };

  const handleOpenInReader = (ref: string) => {
    jumpToReference(ref);
    if (onJumpToReference) {
      const match = ref.match(/^([A-Z0-9]{3})\.([0-9]+)/i);
      if (match) {
        onJumpToReference(match[1].toUpperCase(), parseInt(match[2], 10));
        return;
      }
    }
    navigate('/bible');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Official YouVersion Platform Features</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            Scripture Explorer & Verse of the Day
          </h2>
          <p className="text-xs sm:text-sm text-blue-100/80 leading-relaxed">
            Officially rendered scripture cards, daily inspirational verses, and translation selectors powered by the YouVersion Platform SDK.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate('/bible')}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-md transition-all hover:scale-105 cursor-pointer"
        >
          <BookOpen className="w-4 h-4" />
          <span>Go to Bible Reader</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Verse of the Day & Translation Selector */}
        <div className="space-y-6 lg:col-span-1">
          {/* Verse of the Day Card */}
          <VerseOfTheDayCard
            versionId={selectedVersionId}
            size="default"
            showSunIcon={true}
            showShareButton={true}
            showCardHeader={true}
          />

          {/* Active Translation Selector */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-900 dark:text-white">
                  Active Bible Translation
                </h4>
                <p className="text-[11px] text-slate-500">
                  Shared across Reader, Passages & Devotions
                </p>
              </div>
            </div>

            <div className="space-y-2">
              {POPULAR_TRANSLATIONS.map((tr) => {
                const isSelected = selectedVersionId === tr.id && (selectedSlotKey === tr.slotKey || !selectedSlotKey);
                return (
                  <button
                    key={`${tr.slotKey}:${tr.id}`}
                    type="button"
                    onClick={() => {
                      setSelectedSlotKey(tr.slotKey);
                      setSelectedVersionId(tr.id);
                    }}
                    className={`w-full p-3 rounded-2xl text-left text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                        : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-transparent'
                    }`}
                  >
                    <div>
                      <p>{tr.label}</p>
                      <span className="text-[10px] opacity-75">{tr.lang}</span>
                    </div>
                    {isSelected && (
                      <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {otherAvailableBibles.length > 0 && (
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
                  More Options — Oromiffa ({otherAvailableBibles.length})
                </label>
                <select
                  value={
                    otherAvailableBibles.some((b) => Number(b.id) === Number(selectedVersionId))
                      ? `MORE_${selectedVersionId}:${selectedVersionId}`
                      : ''
                  }
                  onChange={(e) => {
                    if (!e.target.value) return;
                    const [slotPart, idPart] = e.target.value.split(':');
                    const numId = Number(idPart);
                    if (!isNaN(numId) && numId > 0) {
                      setSelectedSlotKey(slotPart || `MORE_${numId}`);
                      setSelectedVersionId(numId);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <option value="">Select another Bible version...</option>
                  {otherAvailableBibles.map((b) => {
                    const sKey = b.slotKey || `MORE_${b.id}`;
                    const label =
                      b.userDisplayLabel ||
                      `${b.localized_abbreviation || b.abbreviation} — ${b.localized_title || b.title}`;
                    return (
                      <option key={`${sKey}:${b.id}`} value={`${sKey}:${b.id}`}>
                        {label}
                      </option>
                    );
                  })}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Interactive Bible Passage Explorer */}
        <div className="space-y-6 lg:col-span-2">
          <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  <span>Bible Passage Viewer (YouVersion BibleCard)</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Render any passage or chapter using the official SDK BibleCard
                </p>
              </div>

              <button
                type="button"
                onClick={() => handleOpenInReader(selectedReference)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
              >
                <span>Read Full Chapter</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Custom Reference Search Input */}
            <form onSubmit={handleCustomSearch} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={customRefInput}
                  onChange={(e) => setCustomRefInput(e.target.value)}
                  placeholder="Enter reference e.g. JHN.3.16, Psalms 23:1-6, Romans 8:28..."
                  className="w-full pl-10 pr-4 py-2.5 text-xs rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
              >
                View
              </button>
            </form>

            {/* Presets */}
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="text-[11px] font-bold text-slate-400 self-center">Presets:</span>
              {PRESET_REFERENCES.map((preset) => (
                <button
                  key={preset.ref}
                  type="button"
                  onClick={() => setSelectedReference(preset.ref)}
                  className={`px-3 py-1 rounded-xl text-xs font-medium cursor-pointer transition-all ${
                    selectedReference === preset.ref
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>

            {/* Rendered BibleCard */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
              <BiblePassage
                reference={selectedReference}
                versionId={selectedVersionId}
                showVersionPicker={true}
                maxWidth="100%"
                onReadFullChapter={() => handleOpenInReader(selectedReference)}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YouVersionSdkPanel;
