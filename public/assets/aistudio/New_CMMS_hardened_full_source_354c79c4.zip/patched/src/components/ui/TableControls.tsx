import React from 'react';
import { ChevronLeft, ChevronRight, Plus, Search, X } from 'lucide-react';
import { useTranslation } from '../../i18n/LanguageContext';

/* ─── Responsive Table Toolbar ──────────────────────────────────────────────── */
export interface TableToolbarProps {
  searchQuery?: string;
  onSearchChange?: (val: string) => void;
  searchPlaceholder?: string;
  filters?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}

export const TableToolbar: React.FC<TableToolbarProps> = ({
  searchQuery,
  onSearchChange,
  searchPlaceholder = 'Search records...',
  filters,
  actions,
  className = '',
}) => {
  const { t } = useTranslation();
  return (
    <div
      className={`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 w-full ${className}`}
    >
      {/* Left: Search & Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 flex-1 min-w-0">
        {onSearchChange !== undefined && (
          <div className="relative flex-1 min-w-0 sm:max-w-xs lg:max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery || ''}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={t(searchPlaceholder)}
              className="w-full min-h-[42px] pl-10 pr-9 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                aria-label={t('Clear search')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
        {filters && (
          <div className="flex flex-wrap items-center gap-2 min-w-0">{filters}</div>
        )}
      </div>

      {/* Right: Primary & Secondary Actions */}
      {actions && (
        <div className="flex flex-wrap items-center justify-end gap-2 shrink-0 w-full sm:w-auto">
          {actions}
        </div>
      )}
    </div>
  );
};

/* ─── Responsive Action Group (for inside table cells & mobile cards) ───────── */
export interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon?: React.ReactNode;
  label?: string;
  variant?: 'default' | 'primary' | 'emerald' | 'amber' | 'danger' | 'indigo';
  iconOnlyOnDesktop?: boolean;
}

export const TableActionButton: React.FC<ActionButtonProps> = ({
  icon,
  label,
  variant = 'default',
  iconOnlyOnDesktop = false,
  className = '',
  children,
  ...props
}) => {
  const variantClasses: Record<NonNullable<ActionButtonProps['variant']>, string> = {
    default:
      'text-slate-600 dark:text-slate-300 bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200/80 dark:hover:bg-slate-700 border-slate-200/70 dark:border-slate-700',
    primary:
      'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border-emerald-200/70 dark:border-emerald-800/60',
    emerald:
      'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border-emerald-200/70 dark:border-emerald-800/60',
    amber:
      'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900/60 border-amber-200/70 dark:border-amber-800/60',
    danger:
      'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/60 border-rose-200/70 dark:border-rose-800/60',
    indigo:
      'text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border-indigo-200/70 dark:border-indigo-800/60',
  };

  return (
    <button
      type="button"
      title={props.title || label}
      aria-label={props['aria-label'] || label || props.title}
      className={`inline-flex items-center justify-center gap-1.5 min-h-[38px] min-w-[38px] sm:min-h-[34px] sm:min-w-[34px] px-2.5 py-1.5 rounded-xl border text-xs font-semibold whitespace-nowrap shrink-0 transition-all duration-150 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none ${variantClasses[variant]} ${className}`}
      {...props}
    >
      {icon && <span className="shrink-0 flex items-center justify-center">{icon}</span>}
      {label && (
        <span className={iconOnlyOnDesktop ? 'inline lg:hidden' : 'inline'}>
          {label}
        </span>
      )}
      {children}
    </button>
  );
};

/* ─── Responsive Pagination Bar ─────────────────────────────────────────────── */
export interface TablePaginationProps {
  currentPage: number;
  totalPages: number;
  totalItems?: number;
  pageSize?: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  pageSizeOptions?: number[];
  itemLabel?: string;
  className?: string;
}

export const TablePagination: React.FC<TablePaginationProps> = ({
  currentPage,
  totalPages,
  totalItems,
  pageSize = 10,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 25, 50, 100],
  itemLabel = 'records',
  className = '',
}) => {
  const { t } = useTranslation();
  if (totalPages <= 1 && (!totalItems || totalItems <= pageSize)) return null;

  const startIdx = totalItems ? (currentPage - 1) * pageSize + 1 : 0;
  const endIdx = totalItems ? Math.min(currentPage * pageSize, totalItems) : 0;

  return (
    <div
      className={`flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-3 bg-slate-50/60 dark:bg-slate-900/60 border-t border-slate-200/80 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 ${className}`}
    >
      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 w-full sm:w-auto">
        {totalItems !== undefined ? (
          <span className="font-medium tabular-nums">
            {t('Showing')} <strong className="text-slate-900 dark:text-white">{startIdx}</strong>–
            <strong className="text-slate-900 dark:text-white">{endIdx}</strong> {t('of')}{' '}
            <strong className="text-slate-900 dark:text-white">{totalItems}</strong> {t(itemLabel)}
          </span>
        ) : (
          <span className="font-medium tabular-nums">
            {t('Page')} <strong className="text-slate-900 dark:text-white">{currentPage}</strong> {t('of')}{' '}
            <strong className="text-slate-900 dark:text-white">{Math.max(1, totalPages)}</strong>
          </span>
        )}

        {onPageSizeChange && (
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            aria-label={t('Rows per page')}
            className="min-h-[34px] px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
          >
            {pageSizeOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt} / {t('page')}
              </option>
            ))}
          </select>
        )}
      </div>

      <div className="flex items-center justify-center gap-1.5 w-full sm:w-auto">
        <button
          type="button"
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage <= 1}
          aria-label={t('Previous page')}
          className="inline-flex items-center justify-center gap-1 min-h-[38px] sm:min-h-[34px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-40 disabled:pointer-events-none transition-all whitespace-nowrap shrink-0"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>{t('Prev')}</span>
        </button>

        <span className="px-3 py-1.5 font-semibold text-slate-800 dark:text-slate-200 tabular-nums whitespace-nowrap">
          {currentPage} / {Math.max(1, totalPages)}
        </span>

        <button
          type="button"
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage >= totalPages}
          aria-label={t('Next page')}
          className="inline-flex items-center justify-center gap-1 min-h-[38px] sm:min-h-[34px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-40 disabled:pointer-events-none transition-all whitespace-nowrap shrink-0"
        >
          <span>{t('Next')}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

/* ─── Empty Table State ─────────────────────────────────────────────────────── */
export interface EmptyTableStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyTableState: React.FC<EmptyTableStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction,
}) => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 px-4 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
      {icon && (
        <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 dark:text-slate-500 mb-3">
          {icon}
        </div>
      )}
      <h4 className="text-base font-bold text-slate-900 dark:text-white mb-1">{t(title)}</h4>
      {description && (
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mb-4">
          {t(description)}
        </p>
      )}
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="inline-flex items-center justify-center gap-2 min-h-[42px] px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{t(actionLabel)}</span>
        </button>
      )}
    </div>
  );
};
