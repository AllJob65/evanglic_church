import React from 'react';

export interface ResponsiveContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full' | 'standard';
  withBottomNavPadding?: boolean;
}

export const ResponsiveContainer = React.forwardRef<HTMLDivElement, ResponsiveContainerProps>(
  ({ children, maxWidth = 'standard', withBottomNavPadding = false, className = '', ...props }, ref) => {
    const maxWidthStyles = {
      sm: 'max-w-screen-sm',
      md: 'max-w-screen-md',
      lg: 'max-w-screen-lg',
      xl: 'max-w-screen-xl',
      '2xl': 'max-w-screen-2xl',
      full: 'max-w-full',
      standard: 'max-w-[1600px]',
    };

    return (
      <div
        ref={ref}
        className={`w-full mx-auto px-3.5 sm:px-6 lg:px-8 ${maxWidthStyles[maxWidth]} ${
          withBottomNavPadding ? 'pb-[calc(5rem+env(safe-area-inset-bottom,0px))] md:pb-8' : ''
        } ${className}`}
        {...props}
      >
        {children}
      </div>
    );
  }
);

ResponsiveContainer.displayName = 'ResponsiveContainer';
