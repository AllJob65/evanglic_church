import React, { useState, useRef, useEffect, useId } from 'react';
import { createPortal } from 'react-dom';
import { MoreVertical, X } from 'lucide-react';
import { useTranslation } from '../../i18n/LanguageContext';

export interface ActionMenuItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  variant?: 'default' | 'primary' | 'amber' | 'danger' | 'emerald' | 'indigo';
  disabled?: boolean;
  hidden?: boolean;
  badge?: string | number;
  dividerBefore?: boolean;
}

export interface ActionMenuProps {
  items?: ActionMenuItem[];
  secondaryActions?: ActionMenuItem[];
  triggerLabel?: string;
  triggerTitle?: string;
  recordTitle?: string;
  recordSubtitle?: string;
  primaryAction?: {
    id?: string;
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
    variant?: 'default' | 'primary' | 'amber' | 'danger' | 'emerald' | 'indigo';
    disabled?: boolean;
  };
  secondaryDesktopActions?: ActionMenuItem[];
  align?: 'left' | 'right';
  className?: string;
}

/**
 * Reusable Accessible ActionMenu Component
 * - Groups multiple secondary row/card actions under a single accessible "More actions (⋮)" button.
 * - Renders via React Portal (`document.body`) so dropdown menus are NEVER clipped by table `overflow-x: auto` or card `overflow: hidden`.
 * - On narrow mobile screens (< 640px), opens as an ergonomic full-width bottom sheet with 44px touch targets.
 * - On tablet/desktop (>= 640px), positions dynamically inside the viewport bounds (flips upward if near bottom edge).
 * - Closes automatically when an action is selected, outside click occurs, Escape is pressed, or window scrolls.
 */
export const ActionMenu: React.FC<ActionMenuProps> = ({
  items,
  secondaryActions,
  triggerLabel,
  triggerTitle = 'More actions',
  recordTitle,
  recordSubtitle,
  primaryAction,
  secondaryDesktopActions = [],
  align = 'right',
  className = '',
}) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isMobileViewport, setIsMobileViewport] = useState(false);
  const [coords, setCoords] = useState<{ top: number; left: number; openUpward: boolean }>({
    top: 0,
    left: 0,
    openUpward: false,
  });

  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const menuId = useId();

  const resolvedItems = Array.isArray(items) ? items : Array.isArray(secondaryActions) ? secondaryActions : [];
  const resolvedDesktopInline = Array.isArray(secondaryDesktopActions) ? secondaryDesktopActions : [];
  const visibleItems = resolvedItems.filter((item) => item && !item.hidden);
  const visibleDesktopInline = resolvedDesktopInline.filter((item) => item && !item.hidden);

  const updatePosition = () => {
    if (!triggerRef.current || typeof window === 'undefined') return;
    const rect = triggerRef.current.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const mobile = vw < 640;
    setIsMobileViewport(mobile);

    if (!mobile) {
      const menuWidth = 224; // 14rem (w-56)
      const estimatedHeight = Math.min(360, visibleItems.length * 42 + (recordTitle ? 52 : 16));
      const spaceBelow = vh - rect.bottom;
      const openUpward = spaceBelow < estimatedHeight && rect.top > estimatedHeight;

      let left = align === 'right' ? rect.right - menuWidth : rect.left;
      left = Math.max(12, Math.min(left, vw - menuWidth - 12));

      const top = openUpward ? Math.max(12, rect.top - 6) : Math.min(vh - 16, rect.bottom + 6);
      setCoords({ top, left, openUpward });
    }
  };

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOpen) {
      updatePosition();
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;

    const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node;
      if (
        triggerRef.current &&
        !triggerRef.current.contains(target) &&
        menuRef.current &&
        !menuRef.current.contains(target)
      ) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
        triggerRef.current?.focus();
      }
    };

    const handleScrollOrResize = () => {
      if (window.innerWidth < 640) {
        setIsMobileViewport(true);
      } else {
        updatePosition();
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('touchstart', handleOutsideClick, { passive: true });
    document.addEventListener('keydown', handleKeyDown);
    window.addEventListener('resize', handleScrollOrResize);
    window.addEventListener('scroll', handleScrollOrResize, true);

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('resize', handleScrollOrResize);
      window.removeEventListener('scroll', handleScrollOrResize, true);
    };
  }, [isOpen]);

  const getButtonVariantStyle = (variant: ActionMenuItem['variant'] = 'default') => {
    switch (variant) {
      case 'primary':
        return 'bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/60 dark:hover:bg-blue-900/60 text-blue-600 dark:text-blue-400 border-blue-200/70 dark:border-blue-800/70';
      case 'emerald':
        return 'bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border-emerald-200/70 dark:border-emerald-800/70';
      case 'amber':
        return 'bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 text-amber-700 dark:text-amber-300 border-amber-200/70 dark:border-amber-800/70';
      case 'danger':
        return 'bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/60 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 border-rose-200/70 dark:border-rose-800/70';
      case 'indigo':
        return 'bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border-indigo-200/70 dark:border-indigo-800/70';
      default:
        return 'bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-700';
    }
  };

  const getMenuItemStyle = (variant: ActionMenuItem['variant'] = 'default') => {
    switch (variant) {
      case 'danger':
        return 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50';
      case 'emerald':
        return 'text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/50';
      case 'amber':
        return 'text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/50';
      case 'primary':
        return 'text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50';
      case 'indigo':
        return 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50';
      default:
        return 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800';
    }
  };

  if (visibleItems.length === 0 && !primaryAction) return null;

  return (
    <div
      className={`inline-flex items-center justify-end gap-1.5 shrink-0 max-w-full ${className}`}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Primary direct action button (shown on all breakpoints if provided) */}
      {primaryAction && (
        <button
          type="button"
          disabled={primaryAction.disabled}
          onClick={(e) => {
            e.stopPropagation();
            primaryAction.onClick();
          }}
          className={`min-h-[44px] sm:min-h-[36px] px-3 py-1.5 rounded-xl border text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50 disabled:pointer-events-none ${getButtonVariantStyle(
            primaryAction.variant || 'primary'
          )}`}
        >
          {primaryAction.icon && <span className="shrink-0 flex items-center">{primaryAction.icon}</span>}
          <span>{t(primaryAction.label)}</span>
        </button>
      )}

      {/* Optional inline secondary actions visible only on wide desktop screens (xl+) */}
      {visibleDesktopInline.map((action) => (
        <button
          key={action.id}
          type="button"
          disabled={action.disabled}
          onClick={(e) => {
            e.stopPropagation();
            action.onClick();
          }}
          title={t(action.label)}
          className={`hidden xl:inline-flex min-h-[36px] px-2.5 py-1.5 rounded-xl border text-xs font-bold items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-50 disabled:pointer-events-none ${getButtonVariantStyle(
            action.variant
          )}`}
        >
          {action.icon && <span className="shrink-0 flex items-center">{action.icon}</span>}
          <span>{t(action.label)}</span>
        </button>
      ))}

      {/* More Actions (⋮) Trigger Button */}
      {visibleItems.length > 0 && (
        <button
          ref={triggerRef}
          type="button"
          onClick={handleToggle}
          aria-haspopup="menu"
          aria-expanded={isOpen}
          aria-controls={isOpen ? menuId : undefined}
          aria-label={t(triggerTitle)}
          title={t(triggerTitle)}
          className={`min-h-[44px] min-w-[44px] sm:min-h-[36px] sm:min-w-[36px] px-2.5 py-1.5 rounded-xl border text-xs font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
            isOpen
              ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900 dark:border-white shadow-sm'
              : 'bg-slate-100 hover:bg-slate-200/80 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-700'
          }`}
        >
          <MoreVertical className="w-4 h-4 shrink-0" />
          {triggerLabel && <span className="pr-0.5">{triggerLabel}</span>}
        </button>
      )}

      {/* Portal Menu / Mobile Bottom Sheet */}
      {isOpen &&
        typeof document !== 'undefined' &&
        createPortal(
          isMobileViewport ? (
            /* Mobile Bottom Sheet (< 640px) for effortless thumb reach and zero clipping */
            <div className="fixed inset-0 z-[80] flex flex-col justify-end sm:hidden">
              <div
                className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150"
                onClick={() => setIsOpen(false)}
              />
              <div
                ref={menuRef}
                id={menuId}
                role="menu"
                aria-label={recordTitle || triggerTitle}
                className="relative z-10 w-full bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 shadow-2xl p-4 pb-[max(1.5rem,env(safe-area-inset-bottom,0px))] max-h-[82dvh] flex flex-col animate-drawer-slide-up"
              >
                <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-3 shrink-0" />

                <div className="flex items-center justify-between gap-2 pb-3 mb-2 border-b border-slate-100 dark:border-slate-800 shrink-0">
                  <div className="min-w-0">
                    <p className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                      {recordTitle || 'Available Actions'}
                    </p>
                    {recordSubtitle && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {recordSubtitle}
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsOpen(false)}
                    aria-label="Close actions menu"
                    className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 flex items-center justify-center shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="overflow-y-auto space-y-1 py-1">
                  {visibleItems.map((item) => (
                    <React.Fragment key={item.id}>
                      {item.dividerBefore && (
                        <div className="my-1.5 border-t border-slate-100 dark:border-slate-800" />
                      )}
                      <button
                        type="button"
                        role="menuitem"
                        disabled={item.disabled}
                        onClick={() => {
                          setIsOpen(false);
                          item.onClick();
                        }}
                        className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center justify-between gap-3 transition-colors cursor-pointer text-left disabled:opacity-40 disabled:pointer-events-none ${getMenuItemStyle(
                          item.variant
                        )}`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {item.icon && <span className="shrink-0">{item.icon}</span>}
                          <span className="truncate">{t(item.label)}</span>
                        </div>
                        {item.badge !== undefined && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 shrink-0">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Tablet & Desktop Floating Popover (>= 640px) with viewport collision protection */
            <div
              ref={menuRef}
              id={menuId}
              role="menu"
              aria-label={recordTitle || triggerTitle}
              style={{
                position: 'fixed',
                top: coords.top,
                left: coords.left,
                transform: coords.openUpward ? 'translateY(-100%)' : undefined,
              }}
              className="z-[80] w-56 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-2xl p-1.5 space-y-0.5 text-xs font-semibold animate-in fade-in zoom-in-95 duration-100 max-h-[75vh] overflow-y-auto"
            >
              {recordTitle && (
                <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 mb-1">
                  <p className="font-bold text-slate-900 dark:text-white truncate text-xs">
                    {recordTitle}
                  </p>
                  {recordSubtitle && (
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">{recordSubtitle}</p>
                  )}
                </div>
              )}
              {visibleItems.map((item) => (
                <React.Fragment key={item.id}>
                  {item.dividerBefore && (
                    <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                  )}
                  <button
                    type="button"
                    role="menuitem"
                    disabled={item.disabled}
                    onClick={() => {
                      setIsOpen(false);
                      item.onClick();
                    }}
                    className={`w-full min-h-[36px] px-3 py-2 rounded-xl flex items-center justify-between gap-2.5 transition-colors cursor-pointer text-left disabled:opacity-40 disabled:pointer-events-none ${getMenuItemStyle(
                      item.variant
                    )}`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {item.icon && <span className="shrink-0">{item.icon}</span>}
                      <span className="truncate">{t(item.label)}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0">
                        {item.badge}
                      </span>
                    )}
                  </button>
                </React.Fragment>
              ))}
            </div>
          ),
          document.body
        )}
    </div>
  );
};

export default ActionMenu;
