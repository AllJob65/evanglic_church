import React from 'react';
import { Inbox } from 'lucide-react';
import { useTranslation } from '../../i18n/LanguageContext';

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon = <Inbox className="w-10 h-10 text-slate-400 dark:text-slate-500" />,
  title,
  description,
  action,
  className = '',
}) => {
  const { t } = useTranslation();
  return (
    <div
      className={`w-full flex flex-col items-center justify-center text-center p-8 sm:p-12 bg-white dark:bg-slate-900/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 ${className}`}
    >
      <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-4 text-slate-600 dark:text-slate-300">
        {icon}
      </div>
      <h3 className="text-base sm:text-lg font-semibold text-slate-900 dark:text-white mb-1">
        {t(title)}
      </h3>
      {description && (
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6 leading-relaxed">
          {t(description)}
        </p>
      )}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
};
