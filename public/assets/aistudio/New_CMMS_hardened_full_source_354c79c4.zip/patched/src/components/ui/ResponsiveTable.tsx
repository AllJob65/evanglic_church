import React from 'react';
import { useTranslation } from '../../i18n/LanguageContext';

export interface Column<T> {
  id?: string;
  header: React.ReactNode;
  accessorKey?: keyof T;
  render?: (item: T, index: number) => React.ReactNode;
  className?: string;
  headerClassName?: string;
  mobileHidden?: boolean;
  tabletHidden?: boolean;
  isAction?: boolean;
  mobileLabel?: string;
}

export interface ResponsiveTableProps<T> {
  data: T[];
  columns: Column<T>[];
  keyExtractor: (item: T, index: number) => string | number;
  mobileCardRender?: (item: T, index: number) => React.ReactNode;
  emptyMessage?: React.ReactNode;
  isLoading?: boolean;
  onRowClick?: (item: T, index: number) => void;
  enableAutoMobileCards?: boolean;
}

export function ResponsiveTable<T>({
  data,
  columns,
  keyExtractor,
  mobileCardRender,
  emptyMessage = 'No records found.',
  isLoading = false,
  onRowClick,
  enableAutoMobileCards = true,
}: ResponsiveTableProps<T>) {
  const { t } = useTranslation();
  if (isLoading) {
    return (
      <div className="w-full py-12 flex flex-col items-center justify-center gap-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium">{t('Loading records...')}</span>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="w-full py-12 px-4 text-center text-slate-500 dark:text-slate-400 bg-slate-50/50 dark:bg-slate-900/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-xs sm:text-sm">
        {typeof emptyMessage === 'string' ? t(emptyMessage) : emptyMessage}
      </div>
    );
  }

  const showMobileCards = Boolean(mobileCardRender) || enableAutoMobileCards;

  return (
    <div className="w-full">
      {/* 1. Mobile Card View (renders below md breakpoint) */}
      {showMobileCards ? (
        <div className="md:hidden space-y-3">
          {data.map((item, index) => (
            <div
              key={keyExtractor(item, index)}
              onClick={onRowClick ? () => onRowClick(item, index) : undefined}
              className={`bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs transition-all ${
                onRowClick ? 'cursor-pointer active:scale-[0.99] hover:border-blue-400 dark:hover:border-blue-500' : ''
              }`}
            >
              {mobileCardRender ? (
                mobileCardRender(item, index)
              ) : (
                <div className="space-y-2.5 text-xs">
                  {columns.map((col, colIdx) => {
                    const cellContent = col.render
                      ? col.render(item, index)
                      : col.accessorKey
                      ? (item[col.accessorKey] as unknown as React.ReactNode)
                      : null;

                    if (col.isAction) {
                      return (
                        <div
                          key={col.id || colIdx}
                          className="pt-2.5 mt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-end gap-2"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {cellContent}
                        </div>
                      );
                    }

                    return (
                      <div key={col.id || colIdx} className="flex items-start justify-between gap-3">
                        <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 shrink-0">
                          {typeof (col.mobileLabel || col.header) === 'string'
                            ? t(col.mobileLabel || (col.header as string))
                            : col.mobileLabel || col.header}
                        </span>
                        <div className="text-right font-medium text-slate-900 dark:text-slate-100 min-w-0 break-words">
                          {cellContent}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : null}

      {/* 2. Desktop & Tablet Table Container */}
      <div
        className={`responsive-table-container border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 ${
          showMobileCards ? 'hidden md:block' : 'block'
        }`}
      >
        <table className="w-full text-left text-xs sm:text-sm text-slate-600 dark:text-slate-300 border-collapse">
          <thead className="bg-slate-50/90 dark:bg-slate-800/80 text-[11px] uppercase tracking-wider font-bold text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
            <tr>
              {columns.map((col, idx) => (
                <th
                  key={col.id || idx}
                  scope="col"
                  className={`py-3.5 px-3.5 lg:px-4 whitespace-nowrap ${
                    col.mobileHidden ? 'hidden sm:table-cell' : ''
                  } ${col.tabletHidden ? 'hidden lg:table-cell' : ''} ${
                    col.isAction ? 'text-right sticky right-0 bg-slate-50 dark:bg-slate-800 z-10' : ''
                  } ${col.headerClassName || col.className || ''}`}
                >
                  {typeof col.header === 'string' ? t(col.header) : col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70 bg-white dark:bg-slate-900 tabular-nums">
            {data.map((item, rowIdx) => (
              <tr
                key={keyExtractor(item, rowIdx)}
                onClick={onRowClick ? () => onRowClick(item, rowIdx) : undefined}
                className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${
                  onRowClick ? 'cursor-pointer' : ''
                }`}
              >
                {columns.map((col, colIdx) => (
                  <td
                    key={col.id || colIdx}
                    className={`py-3 px-3.5 lg:px-4 align-middle ${
                      col.mobileHidden ? 'hidden sm:table-cell' : ''
                    } ${col.tabletHidden ? 'hidden lg:table-cell' : ''} ${
                      col.isAction
                        ? 'text-right whitespace-nowrap sticky right-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs z-10'
                        : ''
                    } ${col.className || ''}`}
                  >
                    {col.render
                      ? col.render(item, rowIdx)
                      : col.accessorKey
                      ? (item[col.accessorKey] as unknown as React.ReactNode)
                      : null}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

