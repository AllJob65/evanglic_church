import React from 'react';

export interface LoadingSkeletonProps {
  variant?: 'card' | 'text' | 'table' | 'avatar';
  count?: number;
  className?: string;
}

export const LoadingSkeleton: React.FC<LoadingSkeletonProps> = ({
  variant = 'card',
  count = 1,
  className = '',
}) => {
  const items = Array.from({ length: count });

  if (variant === 'avatar') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        <div className="w-11 h-11 rounded-full bg-slate-200 dark:bg-slate-800 animate-pulse shrink-0" />
        <div className="space-y-1.5 flex-1">
          <div className="h-3.5 bg-slate-200 dark:bg-slate-800 rounded-md w-3/4 animate-pulse" />
          <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded-md w-1/2 animate-pulse" />
        </div>
      </div>
    );
  }

  if (variant === 'table') {
    return (
      <div className={`w-full rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden ${className}`}>
        <div className="h-12 bg-slate-100 dark:bg-slate-800 animate-pulse" />
        <div className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">
          {items.map((_, i) => (
            <div key={i} className="h-14 p-4 flex items-center justify-between gap-4">
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4 animate-pulse" />
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4 animate-pulse" />
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-1/6 animate-pulse" />
              <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-1/8 animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (variant === 'text') {
    return (
      <div className={`space-y-2.5 ${className}`}>
        {items.map((_, i) => (
          <div
            key={i}
            className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md animate-pulse"
            style={{ width: `${Math.max(40, 100 - i * 15)}%` }}
          />
        ))}
      </div>
    );
  }

  // default card skeleton
  return (
    <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 ${className}`}>
      {items.map((_, i) => (
        <div
          key={i}
          className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 animate-pulse"
        >
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-800" />
            <div className="w-16 h-5 rounded-full bg-slate-200 dark:bg-slate-800" />
          </div>
          <div className="h-5 bg-slate-200 dark:bg-slate-800 rounded-md w-3/4" />
          <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-1/2" />
        </div>
      ))}
    </div>
  );
};
