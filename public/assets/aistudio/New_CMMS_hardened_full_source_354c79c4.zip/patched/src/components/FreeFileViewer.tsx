import React, { useEffect, useState } from 'react';
import { FileText, Image as ImageIcon, Presentation, FileCode, Loader2, Download, Printer } from 'lucide-react';

export interface FreeFileViewerProps {
  /** Accepts File object (e.g. from <input type="file" />) or File URL string */
  file: File | string;
  /** File extension type: 'pdf' | 'jpeg' | 'jpg' | 'png' | 'webp' | 'docx' | 'pptx' */
  fileType: string;
  fileName?: string;
  onClose?: () => void;
}

export const FreeFileViewer: React.FC<FreeFileViewerProps> = ({
  file,
  fileType,
  fileName = 'Document',
  onClose,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [objectUrl, setObjectUrl] = useState<string>('');

  const normalizedType = fileType.toLowerCase().replace('.', '');

  // Generate local object URL if input is a File object
  useEffect(() => {
    setLoading(true);
    setError(null);

    let url = '';
    if (file instanceof File) {
      url = URL.createObjectURL(file);
    } else {
      url = file;
    }
    setObjectUrl(url);
    setLoading(false);

    // Cleanup object URL on unmount to prevent memory leaks
    return () => {
      if (file instanceof File && url) {
        URL.revokeObjectURL(url);
      }
    };
  }, [file]);

  const handlePrint = () => {
    try {
      window.print();
    } catch {
      // Fallback
    }
  };

  return (
    <div className="w-full h-full min-h-[600px] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden flex flex-col relative shadow-2xl">
      {/* Header Bar */}
      <div className="px-5 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs font-bold text-slate-200 min-w-0">
          {['jpeg', 'jpg', 'png', 'webp', 'gif'].includes(normalizedType) && <ImageIcon className="w-4 h-4 text-emerald-400 shrink-0" />}
          {normalizedType === 'pdf' && <FileText className="w-4 h-4 text-rose-400 shrink-0" />}
          {normalizedType === 'docx' && <FileCode className="w-4 h-4 text-blue-400 shrink-0" />}
          {normalizedType === 'pptx' && <Presentation className="w-4 h-4 text-amber-400 shrink-0" />}
          <span className="truncate max-w-[250px] sm:max-w-md">{fileName}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            title="Print Document"
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print</span>
          </button>

          {objectUrl && (
            <a
              href={objectUrl}
              download={fileName}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Download</span>
            </a>
          )}

          {onClose && (
            <button
              onClick={onClose}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg text-xs font-bold transition-colors"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 w-full h-full relative overflow-auto p-4 flex items-center justify-center bg-slate-950/50">
        {/* Loading Spinner */}
        {loading && (
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-xs flex flex-col items-center justify-center gap-2 z-10 text-slate-300">
            <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
            <span className="text-xs font-medium">Processing file locally...</span>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="p-6 text-center max-w-md space-y-3">
            <p className="text-xs font-bold text-rose-400">{error}</p>
            {objectUrl && (
              <a
                href={objectUrl}
                download={fileName}
                className="inline-block px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-md hover:bg-blue-500"
              >
                Download {fileName}
              </a>
            )}
          </div>
        )}

        {/* 1. JPEG & IMAGE FORMATS */}
        {['jpeg', 'jpg', 'png', 'webp', 'gif'].includes(normalizedType) && (
          <img
            src={objectUrl}
            alt={fileName}
            onLoad={() => setLoading(false)}
            onError={() => {
              setLoading(false);
              setError('Failed to load image.');
            }}
            className="max-h-[650px] max-w-full object-contain rounded-xl shadow-lg"
          />
        )}

        {/* 2. PDF FORMAT */}
        {normalizedType === 'pdf' && (
          <iframe
            src={`${objectUrl}#toolbar=1`}
            onLoad={() => setLoading(false)}
            className="w-full h-full min-h-[600px] border-0 rounded-xl bg-white"
            title={fileName}
          />
        )}

        {/* 3. DOCX & OFFICE FORMATS */}
        {normalizedType === 'docx' && (
          <div className="w-full max-w-xl mx-auto p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center space-y-4">
            <div className="w-16 h-16 bg-blue-500/10 text-blue-400 rounded-2xl flex items-center justify-center mx-auto ring-1 ring-blue-500/20">
              <FileCode className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">{fileName}</h3>
              <p className="text-xs text-slate-400 mt-1">Microsoft Word Document (.docx)</p>
            </div>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Download this document to view or edit with Microsoft Word, LibreOffice, or Google Docs.
            </p>
            {objectUrl && (
              <a
                href={objectUrl}
                download={fileName}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-600/20 transition-all"
              >
                <Download className="w-4 h-4" /> Download Word Document
              </a>
            )}
          </div>
        )}

        {/* 4. PPTX FORMAT */}
        {normalizedType === 'pptx' && (
          <div className="w-full max-w-xl mx-auto p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center space-y-4">
            <div className="w-16 h-16 bg-amber-500/10 text-amber-400 rounded-2xl flex items-center justify-center mx-auto ring-1 ring-amber-500/20">
              <Presentation className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">{fileName}</h3>
              <p className="text-xs text-slate-400 mt-1">Microsoft PowerPoint Presentation (.pptx)</p>
            </div>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Download this presentation slide deck to open with Microsoft PowerPoint, Keynote, or Google Slides.
            </p>
            {objectUrl && (
              <a
                href={objectUrl}
                download={fileName}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-amber-600/20 transition-all"
              >
                <Download className="w-4 h-4" /> Download Presentation
              </a>
            )}
          </div>
        )}

        {/* Fallback for other document types */}
        {!['jpeg', 'jpg', 'png', 'webp', 'gif', 'pdf', 'docx', 'pptx'].includes(normalizedType) && (
          <div className="text-center p-8 space-y-4">
            <FileText className="w-12 h-12 text-slate-500 mx-auto" />
            <p className="text-sm font-semibold text-slate-300">Preview not available directly for .{normalizedType} files</p>
            {objectUrl && (
              <a
                href={objectUrl}
                download={fileName}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
              >
                <Download className="w-4 h-4" /> Download to View
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
