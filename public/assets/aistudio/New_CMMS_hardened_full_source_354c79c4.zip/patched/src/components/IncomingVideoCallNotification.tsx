import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from '../i18n/LanguageContext';
import { getClientSocket } from '../services/clientSocket';
import { Video, PhoneOff, Shield, BellRing, User } from 'lucide-react';

export interface IncomingCallData {
  conversationId: string;
  callerId: string;
  callerName: string;
  callerRole?: string;
  roomUrl: string;
  startedAt: string;
}

export interface IncomingVideoCallNotificationProps {
  onAcceptCall: (callData: IncomingCallData) => void;
}

export const IncomingVideoCallNotification: React.FC<IncomingVideoCallNotificationProps> = ({
  onAcceptCall,
}) => {
  const { t } = useTranslation();
  const [incomingCall, setIncomingCall] = useState<IncomingCallData | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Play gentle ring tone using browser Web Audio API
  const startRingtone = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const playBeep = () => {
        if (!ctx || ctx.state === 'closed') return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, ctx.currentTime); // A4
        osc.frequency.setValueAtTime(480, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.6);
      };

      playBeep();
      oscillatorIntervalRef.current = setInterval(playBeep, 2500);
    } catch (e) {
      // Audio autoplay policy may prevent ringtone; visual indicator serves as primary notification
    }
  };

  const stopRingtone = () => {
    if (oscillatorIntervalRef.current) {
      clearInterval(oscillatorIntervalRef.current);
      oscillatorIntervalRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
  };

  useEffect(() => {
    const socket = getClientSocket();

    const handleIncomingCall = (data: IncomingCallData) => {
      setIncomingCall(data);
      startRingtone();
    };

    const handleCallEnded = (data: { conversationId: string }) => {
      if (incomingCall?.conversationId === data.conversationId) {
        stopRingtone();
        setIncomingCall(null);
      }
    };

    const handleCallDeclined = (data: { conversationId: string }) => {
      if (incomingCall?.conversationId === data.conversationId) {
        stopRingtone();
        setIncomingCall(null);
      }
    };

    socket.on('direct_video:incoming_call', handleIncomingCall);
    socket.on('direct_video:call_ended', handleCallEnded);
    socket.on('direct_video:call_declined', handleCallDeclined);

    return () => {
      stopRingtone();
      socket.off('direct_video:incoming_call', handleIncomingCall);
      socket.off('direct_video:call_ended', handleCallEnded);
      socket.off('direct_video:call_declined', handleCallDeclined);
    };
  }, [incomingCall]);

  if (!incomingCall) return null;

  const handleAccept = () => {
    stopRingtone();
    const socket = getClientSocket();
    socket.emit('direct_video:accept_call', { conversationId: incomingCall.conversationId });
    onAcceptCall(incomingCall);
    setIncomingCall(null);
  };

  const handleDecline = () => {
    stopRingtone();
    const socket = getClientSocket();
    socket.emit('direct_video:decline_call', {
      conversationId: incomingCall.conversationId,
      reason: 'Declined by recipient',
    });
    setIncomingCall(null);
  };

  return (
    <div className="fixed top-6 right-6 z-50 max-w-sm w-full animate-in slide-in-from-top-4 duration-300">
      <div className="p-4 rounded-3xl bg-slate-900/95 border-2 border-blue-500/80 backdrop-blur-xl shadow-2xl text-white space-y-3.5 ring-4 ring-blue-500/20">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-blue-600/30 border border-blue-400 flex items-center justify-center text-blue-400">
              <User className="w-6 h-6" />
            </div>
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-900 animate-ping"></span>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 text-xs text-blue-400 font-bold uppercase tracking-wider">
              <BellRing className="w-3.5 h-3.5 animate-bounce text-blue-400" />
              <span>{t('incoming_video_call', 'Incoming 1:1 Video Call')}</span>
            </div>
            <h4 className="text-sm font-bold text-white truncate">{incomingCall.callerName}</h4>
            {incomingCall.callerRole && (
              <span className="inline-block mt-0.5 px-2 py-0.2 rounded-md text-[10px] font-semibold bg-blue-950 text-blue-300 border border-blue-800">
                {incomingCall.callerRole}
              </span>
            )}
          </div>
        </div>

        <p className="text-[11px] text-slate-300">
          {t('incoming_call_subtext', 'Leader is initiating a private 1:1 video counseling session with you.')}
        </p>

        {/* 44px min touch target action buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={handleDecline}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-900/40 text-rose-300 hover:text-rose-200 border border-slate-700 hover:border-rose-700/60 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            <span>{t('decline', 'Decline')}</span>
          </button>
          <button
            onClick={handleAccept}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer animate-pulse"
          >
            <Video className="w-4 h-4" />
            <span>{t('accept', 'Accept')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
