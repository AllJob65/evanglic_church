import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Branch } from '../types';
import {
  Building2,
  Plus,
  ArrowRightLeft,
  Users,
  MapPin,
  Clock,
  Globe,
  Phone,
  Mail,
  Shield,
  X,
  CheckCircle,
} from 'lucide-react';

export const BranchModule: React.FC = () => {
  const { branches, addBranch, members, permissions, updateWorkflowStatus, addAuditLog } = useCMMS();
  const [selectedBranch, setSelectedBranch] = useState<Branch | undefined>(branches[0]);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isAddBranchModalOpen, setIsAddBranchModalOpen] = useState(false);

  // Member transfer form
  const [transferMemberId, setTransferMemberId] = useState(members[0]?.id || '');
  const [targetBranchId, setTargetBranchId] = useState(branches[1]?.id || branches[0]?.id || '');
  const [transferReason, setTransferReason] = useState('');
  const [transferSubmitted, setTransferSubmitted] = useState(false);

  // New branch form
  const [newBranchName, setNewBranchName] = useState('');
  const [newBranchType, setNewBranchType] = useState<Branch['type']>('Satellite Campus');
  const [newBranchPastor, setNewBranchPastor] = useState('');
  const [newBranchCity, setNewBranchCity] = useState('');

  const handleInitiateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const mem = members.find((m) => m.id === transferMemberId);
    const targetB = branches.find((b) => b.id === targetBranchId);

    addAuditLog(
      'Requested Inter-Branch Transfer',
      'Branch Management',
      `Requested member transfer for ${mem?.firstName} ${mem?.lastName} to ${targetB?.name}. Reason: ${transferReason}`
    );

    setTransferSubmitted(true);
    setTimeout(() => {
      setTransferSubmitted(false);
      setIsTransferModalOpen(false);
    }, 1500);
  };

  const handleCreateBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchName) return;

    const newB: Branch = {
      id: `br-${Date.now().toString().slice(-4)}`,
      code: `SAT-${Math.floor(100 + Math.random() * 900)}`,
      name: newBranchName,
      type: newBranchType,
      parentBranchId: branches[0]?.id || '',
      seniorPastor: newBranchPastor || '',
      phone: '',
      email: '',
      website: '',
      address: '',
      city: newBranchCity,
      region: '',
      gpsCoordinates: '',
      serviceTimes: [],
      languages: ['English'],
      timezone: 'UTC',
      establishedDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      totalMembersCount: 0,
      monthlyTargetBudget: 0,
    };

    addBranch(newB);
    setSelectedBranch(newB);
    setIsAddBranchModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <Building2 className="w-6 h-6 text-blue-600 shrink-0" />
            <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">Multi-Campus Branch Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
              {branches.length} Campuses
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Headquarters-to-satellite hierarchy, campus staffing, and inter-branch member transfer workflows.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsTransferModalOpen(true)}
            className="min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowRightLeft className="w-4 h-4 text-blue-600 shrink-0" />
            <span>Inter-Branch Member Transfer</span>
          </button>

          {permissions.canManageBranches && (
            <button
              onClick={() => setIsAddBranchModalOpen(true)}
              className="min-h-[44px] px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>Establish New Campus</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Campuses List & Active Campus Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Branch Campuses List */}
        <div className="space-y-3">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white uppercase tracking-wider text-xs">
            Campuses & Outreaches
          </h3>

          <div className="space-y-2">
            {branches.map((b) => {
              const isSelected = selectedBranch?.id === b.id;
              return (
                <div
                  key={b.id}
                  onClick={() => setSelectedBranch(b)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50/80 dark:bg-blue-950/60 border-blue-500 shadow-md ring-2 ring-blue-500/20'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-blue-600 dark:text-blue-400">
                      {b.code}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        b.type === 'Headquarters'
                          ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                          : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                      }`}
                    >
                      {b.type}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">{b.name}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Pastor: {b.seniorPastor} • {b.city}
                  </p>

                  <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-500">{b.totalMembersCount} Active Members</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">
                      Target: ${b.monthlyTargetBudget.toLocaleString()}/mo
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Campus Detail Card */}
        <div className="lg:col-span-2 space-y-6">
          {selectedBranch && (
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">{selectedBranch.name}</h2>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                      {selectedBranch.type}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {selectedBranch.address}, {selectedBranch.city}, {selectedBranch.region}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-right">
                  <span className="text-xs text-slate-500 block">Established</span>
                  <span className="font-bold text-slate-900 dark:text-white">{selectedBranch.establishedDate}</span>
                </div>
              </div>

              {/* Campus Contact & Service Times */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                  <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-blue-600" /> Campus Contact & Leadership
                  </h4>
                  <p><strong>Senior Pastor:</strong> {selectedBranch.seniorPastor}</p>
                  <p><strong>Phone:</strong> {selectedBranch.phone}</p>
                  <p><strong>Official Email:</strong> {selectedBranch.email}</p>
                  <p><strong>Languages Used:</strong> {selectedBranch.languages.join(', ')}</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                  <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-600" /> Weekly Service Schedule
                  </h4>
                  {selectedBranch.serviceTimes.map((st, idx) => (
                    <div key={idx} className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                      <span className="font-semibold">{st.name}</span>
                      <span>
                        {st.day} @ {st.time}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Members Enrolled in Branch */}
              <div className="space-y-3">
                <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center justify-between">
                  <span>Assigned Branch Members ({selectedBranch.totalMembersCount})</span>
                </h3>

                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs">
                  {members
                    .filter((m) => m.branchId === selectedBranch.id)
                    .map((m) => (
                      <div key={m.id} className="p-3 bg-white dark:bg-slate-900 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img src={m.photoUrl} alt="" className="w-8 h-8 rounded-lg object-cover" />
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white">
                              {m.firstName} {m.lastName}
                            </span>
                            <span className="text-slate-400 ml-2">({m.memberIdNumber})</span>
                          </div>
                        </div>
                        <span className="text-slate-600 dark:text-slate-400">{m.occupation}</span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Inter-Branch Member Transfer Modal */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5 text-blue-600" />
                Inter-Branch Transfer Request
              </h3>
              <button onClick={() => setIsTransferModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            {transferSubmitted ? (
              <div className="p-6 text-center space-y-2">
                <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">Transfer Workflow Initiated!</h4>
                <p className="text-xs text-slate-500">
                  Request forwarded to destination Branch Administrator for formal approval.
                </p>
              </div>
            ) : (
              <form onSubmit={handleInitiateTransfer} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold mb-1">Select Member to Transfer</label>
                  <select
                    value={transferMemberId}
                    onChange={(e) => setTransferMemberId(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName} ({m.memberIdNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Destination Campus Branch</label>
                  <select
                    value={targetBranchId}
                    onChange={(e) => setTargetBranchId(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Transfer Reason / Notes</label>
                  <textarea
                    rows={3}
                    required
                    value={transferReason}
                    onChange={(e) => setTransferReason(e.target.value)}
                    placeholder="e.g. Member relocated residence closer to Downtown City Campus."
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsTransferModalOpen(false)}
                    className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold">
                    Submit Transfer Workflow
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Establish Campus Modal */}
      {isAddBranchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Establish New Campus</h3>
              <button onClick={() => setIsAddBranchModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateBranch} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Campus Name</label>
                <input
                  type="text"
                  required
                  value={newBranchName}
                  onChange={(e) => setNewBranchName(e.target.value)}
                  placeholder="e.g. Grace Campus West"
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Campus Designation Type</label>
                <select
                  value={newBranchType}
                  onChange={(e) => setNewBranchType(e.target.value as any)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Satellite Campus">Satellite Campus</option>
                  <option value="Outreach Location">Outreach Location</option>
                  <option value="Regional Center">Regional Center</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Assigned Senior Pastor</label>
                <input
                  type="text"
                  required
                  value={newBranchPastor}
                  onChange={(e) => setNewBranchPastor(e.target.value)}
                  placeholder="Pastor Full Name"
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddBranchModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold">
                  Create Campus
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
