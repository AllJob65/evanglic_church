import React, { useState, Suspense } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from '../Navbar';
import { Sidebar } from '../Sidebar';
import { MobileBottomNav } from '../MobileBottomNav';
import { BreadcrumbNav } from '../BreadcrumbNav';
import { ErrorBoundary } from '../ErrorBoundary';
import { useCMMS } from '../../context/CMMSContext';

const RolePermissionsModal = React.lazy(() =>
  import('../RolePermissionsModal').then((m) => ({ default: m.RolePermissionsModal }))
);

export interface AppShellProps {
  children?: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const { themeMode, language, isSidebarCollapsed } = useCMMS();
  const location = useLocation();
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isEthiopicScript = language === 'Amharic' || language === 'Tigrigna' || language === 'am' || language === 'ti';
  const fontFamilyClass = isEthiopicScript ? 'font-menbere' : 'font-montserrat';
  const currentRouteKey = location.pathname.split('/')[1] || 'dashboard';

  return (
    <div
      className={`min-h-screen min-h-screen-dvh ${
        themeMode === 'dark' || themeMode === 'advanced-dark'
          ? 'dark bg-slate-950 text-slate-100'
          : 'bg-slate-50 text-slate-900'
      } ${fontFamilyClass} antialiased transition-colors duration-200 overflow-x-hidden`}
    >
      {/* Top Navbar */}
      <Navbar
        onOpenRoleModal={() => setIsRoleModalOpen(true)}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      {/* Main Body Layout with Sidebar Flush to Left Edge */}
      <div className="w-full flex flex-col md:flex-row min-h-[calc(100dvh-4rem)]">
        <Sidebar
          isMobileMenuOpen={isMobileMenuOpen}
          onCloseMobileMenu={() => setIsMobileMenuOpen(false)}
        />

        <motion.main
          id="cmms-main-content"
          layout="position"
          transition={{ duration: 0.25, ease: 'easeInOut' }}
          className={`flex-1 min-w-0 w-full overflow-x-hidden transition-all duration-300 pl-safe pr-safe ${
            isSidebarCollapsed
              ? 'p-3 sm:p-5 lg:p-6 pb-[calc(5.5rem+env(safe-area-inset-bottom,0px))] md:pb-8 w-full max-w-none'
              : 'p-3.5 sm:p-6 lg:p-7 pb-[calc(5.5rem+env(safe-area-inset-bottom,0px))] md:pb-8 w-full max-w-none'
          }`}
        >
          {/* Universal Breadcrumb Navigation Across All Modules */}
          <BreadcrumbNav />

          {/* Animated Page / Module Transition via Motion Framework */}
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={currentRouteKey}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className="w-full min-w-0"
            >
              <ErrorBoundary>{children}</ErrorBoundary>
            </motion.div>
          </AnimatePresence>
        </motion.main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* Role & Permissions Modal (Lazy Loaded) */}
      {isRoleModalOpen && (
        <Suspense fallback={null}>
          <RolePermissionsModal
            isOpen={isRoleModalOpen}
            onClose={() => setIsRoleModalOpen(false)}
          />
        </Suspense>
      )}
    </div>
  );
};
