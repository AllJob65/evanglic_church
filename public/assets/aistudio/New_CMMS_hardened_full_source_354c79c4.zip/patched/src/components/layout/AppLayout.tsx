import React, { useState, Suspense } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from '../Navbar';
import { Sidebar } from '../Sidebar';
import { MobileBottomNav } from '../MobileBottomNav';
import { BreadcrumbNav } from '../BreadcrumbNav';
import { ErrorBoundary } from '../ErrorBoundary';
import { IncomingVideoCallNotification, IncomingCallData } from '../IncomingVideoCallNotification';
import { DirectVideoCallModal } from '../DirectVideoCallModal';
import { useCMMS } from '../../context/CMMSContext';

const RolePermissionsModal = React.lazy(() =>
  import('../RolePermissionsModal').then((m) => ({ default: m.RolePermissionsModal }))
);

export interface AppLayoutProps {
  children?: React.ReactNode;
}

/**
 * Global AppLayout Component
 * Enforces the unified architecture:
 *   App
 *   └── AppLayout
 *       ├── Floating Sidebar (fixed full height at left from top: 0 to bottom: 0, 100dvh)
 *       ├── Floating Navbar (fixed at top, aligned to the right of the sidebar: 256px expanded / 80px collapsed)
 *       └── Main Content (.app-main, automatically accounts for navbar/sidebar dimensions)
 */
export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { themeMode, language, isSidebarCollapsed } = useCMMS();
  const location = useLocation();
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [acceptedIncomingCall, setAcceptedIncomingCall] = useState<IncomingCallData | null>(null);

  const isEthiopicScript = language === 'Amharic' || language === 'Tigrigna' || language === 'am' || language === 'ti';
  const fontFamilyClass = isEthiopicScript ? 'font-menbere' : 'font-montserrat';
  const currentRouteKey = location.pathname.split('/')[1] || 'dashboard';

  return (
    <div
      className={`app-layout-root min-h-screen ${
        themeMode === 'dark' || themeMode === 'advanced-dark'
          ? 'dark bg-slate-950 text-slate-100'
          : 'bg-slate-50 text-slate-900'
      } ${fontFamilyClass} antialiased transition-colors duration-200`}
    >
      {/* 1. FLOATING TOP NAVBAR */}
      <Navbar
        onOpenRoleModal={() => setIsRoleModalOpen(true)}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      {/* 2. FLOATING SIDEBAR (DESKTOP FIXED + MOBILE DRAWER) */}
      <Sidebar
        isMobileMenuOpen={isMobileMenuOpen}
        onCloseMobileMenu={() => setIsMobileMenuOpen(false)}
      />

      {/* 3. MAIN CONTENT CONTAINER (Controlled globally via .app-main) */}
      <motion.main
        id="cmms-main-content"
        layout="position"
        transition={{ duration: 0.25, ease: 'easeInOut' }}
        className={`app-main ${isSidebarCollapsed ? 'sidebar-collapsed' : ''}`}
      >
        {/* Universal Breadcrumb Navigation Across All Modules */}
        <BreadcrumbNav />

        {/* Animated Page / Module Transition via Motion Framework */}
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={`${currentRouteKey}-${language}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="w-full min-w-0"
          >
            <div key={language} className="w-full min-w-0">
              {children}
            </div>
          </motion.div>
        </AnimatePresence>
      </motion.main>

      {/* 4. MOBILE FLOATING BOTTOM NAVIGATION */}
      <MobileBottomNav
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* 5. ROLE & PERMISSIONS MODAL */}
      {isRoleModalOpen && (
        <Suspense fallback={null}>
          <ErrorBoundary moduleName="Role & Access Control">
            <RolePermissionsModal
              isOpen={isRoleModalOpen}
              onClose={() => setIsRoleModalOpen(false)}
            />
          </ErrorBoundary>
        </Suspense>
      )}

      {/* 6. 1:1 DIRECT VIDEO CALL REAL-TIME NOTIFICATION & MODAL */}
      <IncomingVideoCallNotification
        onAcceptCall={(callData) => setAcceptedIncomingCall(callData)}
      />

      {acceptedIncomingCall && (
        <DirectVideoCallModal
          isOpen={Boolean(acceptedIncomingCall)}
          onClose={() => setAcceptedIncomingCall(null)}
          conversationId={acceptedIncomingCall.conversationId}
          roomUrl={acceptedIncomingCall.roomUrl}
          remoteParticipantName={acceptedIncomingCall.callerName}
          remoteParticipantRole={acceptedIncomingCall.callerRole}
          isIncomingCall={true}
        />
      )}
    </div>
  );
};

export default AppLayout;
