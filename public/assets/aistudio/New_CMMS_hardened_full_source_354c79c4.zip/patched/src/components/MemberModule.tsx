import React, { useState, useMemo } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Member, MembershipStatus, Gender, MaritalStatus, SystemUser, UserRole } from '../types';
import { apiService } from '../services/api';
const FamilyModule = React.lazy(() =>
  import('./FamilyModule').then((m) => ({ default: m.FamilyModule }))
);
import { EthiopianDateHelper, DEFAULT_MALE_AVATAR, DEFAULT_FEMALE_AVATAR } from './EthiopianDateHelper';
import { PublicRegistrationFormModal } from './PublicRegistrationFormModal';
import { EthiopianPhoneInput } from './EthiopianPhoneInput';
import { ActionMenu } from './ui/ActionMenu';
import {
  sanitizeEthiopianPhoneInput,
  validateEthiopianPhone,
  normalizeEthiopianPhone,
} from '../utils/phoneValidation';
import { formatToE164 } from '../schemas/phone.schema';
import {
  gregorianToEthiopian,
  ethiopianToGregorian,
  ETHIOPIAN_MONTHS,
} from '../utils/ethiopianCalendar';
import {
  Users,
  Search,
  Filter,
  UserPlus,
  QrCode,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Award,
  Heart,
  Briefcase,
  X,
  Eye,
  EyeOff,
  Edit3,
  Trash2,
  Save,
  ShieldCheck,
  Building,
  Home,
  Camera,
  Upload,
  Globe,
  Plus,
  UserX,
  Cross,
  FileText,
  RotateCcw,
  LayoutGrid,
  List,
  Paperclip,
  Download,
  ExternalLink,
  FileCheck,
  MoreVertical,
  Link2,
  Share2,
  ChevronDown,
  Check,
  CheckCircle,
  CheckCircle2,
  Layers,
  Tag,
  AlertTriangle,
  Printer,
  Key,
  Copy,
  Sparkles,
  Lock,
  Shield,
} from 'lucide-react';

type FormTab = 'personal' | 'marital' | 'contact' | 'spiritual' | 'professional' | 'health';

export {
  DEFAULT_MALE_AVATAR,
  DEFAULT_FEMALE_AVATAR,
  EthiopianDateHelper,
  type EthiopianDateHelperProps,
} from './EthiopianDateHelper';

interface MemberModuleProps {
  initialSubTab?: 'members' | 'family' | 'past_members';
}

export const MemberModule: React.FC<MemberModuleProps> = ({ initialSubTab = 'members' }) => {
  const {
    members = [],
    families = [],
    ministries = [],
    addMember,
    updateMember,
    deleteMember,
    addSystemUser,
    systemUsers = [],
    permissions,
    branches = [],
    globalSearchQuery = '',
    addAuditLog,
    t,
  } = useCMMS();

  const [activeSubTab, setActiveSubTab] = useState<'members' | 'family' | 'past_members'>(initialSubTab as any);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [detailTab, setDetailTab] = useState<'personal' | 'family' | 'spiritual' | 'professional' | 'medical' | 'digital_id'>('personal');
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Past Members Departure / Death modal state
  const [isRecordDepartureModalOpen, setIsRecordDepartureModalOpen] = useState(false);
  const [departureTargetMember, setDepartureTargetMember] = useState<Member | null>(null);
  const [departureForm, setDepartureForm] = useState<{
    reason: 'Deceased' | 'Transferred' | 'Moved Away' | 'Resigned' | 'Left Church' | 'Excommunicated' | 'Inactive' | 'On Leave' | 'Other';
    date: string;
    endDate: string;
    excommunicationPaperUrl?: string;
    excommunicationPaperName?: string;
    excommunicationDescription?: string;
  }>({
    reason: 'Deceased',
    date: new Date().toISOString().split('T')[0],
    endDate: '',
    excommunicationPaperUrl: '',
    excommunicationPaperName: '',
    excommunicationDescription: '',
  });

  // Paper Preview Modal state
  const [paperPreviewModal, setPaperPreviewModal] = useState<{
    isOpen: boolean;
    title: string;
    url: string;
    fileName?: string;
  }>({
    isOpen: false,
    title: '',
    url: '',
    fileName: '',
  });

  // Accessible Delete Confirmation Modal state (replaces window.confirm)
  const [deleteTargetMember, setDeleteTargetMember] = useState<{ id: string; name: string; memberIdNumber?: string } | null>(null);

  // View Mode: Grid or List
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [pastViewMode, setPastViewMode] = useState<'grid' | 'list'>('grid');
  // Public Google Form Registration Link Generator Modal State
  const [isShareFormModalOpen, setIsShareFormModalOpen] = useState(false);
  // Local Search Query for Member Search function
  const [localSearch, setLocalSearch] = useState<string>('');

  // Sorting & Pagination States
  const [sortField, setSortField] = useState<string>('fullName');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [openActionMenuId, setOpenActionMenuId] = useState<string | null>(null);
  const pageSize = 100;

  // Form tab state for multi-step or tabbed registration/editing
  const [formTab, setFormTab] = useState<'personal' | 'marital' | 'contact' | 'spiritual' | 'professional' | 'health'>('personal');

  // Filters state
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [filterBranch, setFilterBranch] = useState<string>('All');
  const [filterBaptized, setFilterBaptized] = useState<string>('All');
  const [filterGender, setFilterGender] = useState<string>('All');

  // Member Form State (Shared for Add & Edit)
  const defaultMemberForm: Partial<Member> = {
    title: 'Mr',
    firstName: '',
    middleName: '',
    lastName: '',
    gender: 'Male',
    maritalStatus: 'Single',
    marriageDate: '',
    divorceDate: '',
    spouseName: '',
    spousePhone: '',
    spouseMemberId: '',
    dateOfBirth: '',
    nationality: '',
    nationalIdNumber: '',
    passportNumber: '',
    photoUrl: DEFAULT_MALE_AVATAR,
    primaryPhone: '',
    altPhone: '',
    email: '',
    preferredCommChannel: 'SMS',
    streetAddress: '',
    city: '',
    subCity: '',
    woreda: '',
    kebele: '',
    houseNumber: '',
    region: '',
    postalCode: '',
    maleChildrenCount: 0,
    femaleChildrenCount: 0,
    adoptedChildrenCount: 0,
    salvationDate: '',
    salvationLocation: '',
    isWaterBaptized: false,
    waterBaptismDate: '',
    waterBaptismLocation: '',
    isHolySpiritBaptized: false,
    spiritualGifts: [],
    membershipDate: new Date().toISOString().split('T')[0],
    membershipLocation: '',
    membershipStatus: 'Active',
    branchId: branches[0]?.id || '',
    foundationCourseCompleted: false,
    educationLevel: 'Bachelor',
    employerType: 'Private',
    employerTypeOther: '',
    fieldOfStudy: '',
    occupation: '',
    employerName: '',
    skillsAndTalents: [],
    languagesSpoken: ['English'],
    bloodType: 'A+',
    knownAllergies: [],
    medicalConditions: [],
    emergencyContact: {
      name: '',
      relationship: '',
      phone: '',
    },
    currentMinistryStatus: 'Active Serving Member',
    ministryIds: ministries[0] ? [ministries[0].id] : [],
    ministriesServedBefore: [],
    ministriesJoinedNow: ministries[0] ? [ministries[0].id] : [],
  };

  const [memberForm, setMemberForm] = useState<Partial<Member>>(defaultMemberForm);
  const [ministryDropdownOpen, setMinistryDropdownOpen] = useState<boolean>(false);
  const [ministrySearch, setMinistrySearch] = useState<string>('');
  const [ministriesSectionCollapsed, setMinistriesSectionCollapsed] = useState<boolean>(false);

  // Field-level and section-level validation states
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Optional Account Provisioning State
  const [provisionAccount, setProvisionAccount] = useState<boolean>(false);
  const [accountIdentifierType, setAccountIdentifierType] = useState<'email' | 'phone'>('email');
  const [accountRole, setAccountRole] = useState<UserRole>('REGULAR_MEMBER');
  const [accountTempPassword, setAccountTempPassword] = useState<string>('Grace@2026!Temp');
  const [showAccountPassword, setShowAccountPassword] = useState<boolean>(false);
  const [accountMustChangePassword, setAccountMustChangePassword] = useState<boolean>(true);
  const [credentialCopied, setCredentialCopied] = useState<boolean>(false);

  // Credential summary modal state
  const [createdAccountSummary, setCreatedAccountSummary] = useState<{
    isOpen: boolean;
    memberName: string;
    memberIdNumber: string;
    username: string;
    role: string;
    tempPassword: string;
    mustChangePassword: boolean;
  } | null>(null);

  const handleGenerateTempPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let pass = 'CMMS@';
    for (let i = 0; i < 8; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setAccountTempPassword(pass);
  };

  // Phase 3: Ministry Eligibility & Filtering
  const eligibleMinistries = useMemo(() => {
    return (ministries || []).filter((m) => {
      if (!m.branchId || m.branchId === '*' || m.branchId === 'all') return true;
      if (!memberForm.branchId) return true;
      return m.branchId === memberForm.branchId;
    });
  }, [ministries, memberForm.branchId]);

  const filteredMinistries = useMemo(() => {
    return eligibleMinistries.filter((m) => {
      if (!ministrySearch.trim()) return true;
      const q = ministrySearch.toLowerCase();
      return (
        m.name.toLowerCase().includes(q) ||
        (m.category && m.category.toLowerCase().includes(q)) ||
        (m.description && m.description.toLowerCase().includes(q))
      );
    });
  }, [eligibleMinistries, ministrySearch]);

  const handleToggleMinistry = (id: string) => {
    const current = memberForm.ministryIds || [];
    const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
    setMemberForm({
      ...memberForm,
      ministryIds: next,
      ministriesJoinedNow: next,
    });
  };

  const handleRemoveMinistry = (id: string) => {
    const next = (memberForm.ministryIds || []).filter((x) => x !== id);
    setMemberForm({
      ...memberForm,
      ministryIds: next,
      ministriesJoinedNow: next,
    });
  };

  const handleBranchChange = (newBranchId: string) => {
    const branchEligibleMinistryIds = (ministries || [])
      .filter((m) => !m.branchId || m.branchId === '*' || m.branchId === 'all' || m.branchId === newBranchId)
      .map((m) => m.id);

    const retainedMinistryIds = (memberForm.ministryIds || []).filter((id) =>
      branchEligibleMinistryIds.includes(id)
    );

    setMemberForm({
      ...memberForm,
      branchId: newBranchId,
      ministryIds: retainedMinistryIds,
      ministriesJoinedNow: retainedMinistryIds,
    });
  };

  const handleTogglePastMinistry = (id: string) => {
    const current = memberForm.ministriesServedBefore || [];
    const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
    setMemberForm({
      ...memberForm,
      ministriesServedBefore: next,
    });
  };

  // Active members vs Past members separation
  const activeMembers = members.filter(
    (m) =>
      m.membershipStatus === 'Active' &&
      !['Deceased', 'Transferred', 'Left Church', 'Excommunicated', 'Inactive', 'On Leave'].includes(m.membershipStatus) &&
      !m.departureReason
  );

  const pastMembers = members.filter(
    (m) =>
      m.membershipStatus === 'Deceased' ||
      m.membershipStatus === 'Transferred' ||
      m.membershipStatus === 'Left Church' ||
      m.membershipStatus === 'Excommunicated' ||
      m.membershipStatus === 'Inactive' ||
      m.membershipStatus === 'On Leave' ||
      Boolean(m.departureReason)
  );

  // Active Filter evaluation
  const filteredMembers = activeMembers.filter((m) => {
    const combinedQuery = `${globalSearchQuery} ${localSearch}`.trim().toLowerCase();
    if (combinedQuery) {
      const searchHaystack = `${m.title} ${m.firstName} ${m.middleName || ''} ${m.lastName} ${m.memberIdNumber} ${m.primaryPhone} ${m.altPhone || ''} ${m.email} ${m.occupation} ${m.employerName || ''} ${m.woreda || ''} ${m.kebele || ''} ${m.houseNumber || ''} ${(m.ministryIds || []).join(' ')}`.toLowerCase();
      if (!searchHaystack.includes(combinedQuery)) return false;
    }

    if (filterStatus !== 'All' && m.membershipStatus !== filterStatus) return false;
    if (filterBranch !== 'All' && m.branchId !== filterBranch) return false;
    if (filterGender !== 'All' && m.gender !== filterGender) return false;
    if (filterBaptized === 'Water Baptized' && !m.isWaterBaptized) return false;
    if (filterBaptized === 'Holy Spirit Baptized' && !m.isHolySpiritBaptized) return false;

    return true;
  });

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const sortedMembers = [...filteredMembers].sort((a, b) => {
    let valA: any = '';
    let valB: any = '';
    if (sortField === 'memberIdNumber') {
      valA = a.memberIdNumber || '';
      valB = b.memberIdNumber || '';
    } else if (sortField === 'fullName') {
      valA = `${a.firstName} ${a.lastName}`.toLowerCase();
      valB = `${b.firstName} ${b.lastName}`.toLowerCase();
    } else if (sortField === 'phone') {
      valA = a.primaryPhone || '';
      valB = b.primaryPhone || '';
    } else if (sortField === 'kebele') {
      valA = `${a.woreda} ${a.kebele}`.toLowerCase();
      valB = `${b.woreda} ${b.kebele}`.toLowerCase();
    } else if (sortField === 'status') {
      valA = a.membershipStatus || '';
      valB = b.membershipStatus || '';
    } else if (sortField === 'attendance') {
      valA = a.attendanceScore || 0;
      valB = b.attendanceScore || 0;
    }
    if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
    if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
    return 0;
  });

  const totalPages = Math.ceil(sortedMembers.length / pageSize) || 1;
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, sortedMembers.length);
  const paginatedMembers = sortedMembers.slice(startIndex, endIndex);

  // Past Members Search
  const filteredPastMembers = pastMembers.filter((m) => {
    const combinedQuery = `${globalSearchQuery} ${localSearch}`.trim().toLowerCase();
    if (combinedQuery) {
      const searchHaystack = `${m.title} ${m.firstName} ${m.middleName || ''} ${m.lastName} ${m.memberIdNumber} ${m.primaryPhone} ${m.departureReason || ''}`.toLowerCase();
      if (!searchHaystack.includes(combinedQuery)) return false;
    }

    if (filterBranch !== 'All' && m.branchId !== filterBranch) return false;
    return true;
  });

  const handleGenderChange = (newGender: Gender) => {
    let updatedPhoto = memberForm.photoUrl;
    if (
      !updatedPhoto ||
      updatedPhoto === DEFAULT_MALE_AVATAR ||
      updatedPhoto === DEFAULT_FEMALE_AVATAR
    ) {
      updatedPhoto = newGender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR;
    }
    setMemberForm({ ...memberForm, gender: newGender, photoUrl: updatedPhoto });
  };

  const handleOpenAddModal = () => {
    setMemberForm(defaultMemberForm);
    setFormTab('personal');
    setFieldErrors({});
    setFormValidationError('');
    setProvisionAccount(false);
    handleGenerateTempPassword();
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (member: Member) => {
    const mIds = member.ministryIds?.length ? member.ministryIds : (member.ministriesJoinedNow?.length ? member.ministriesJoinedNow : []);
    setMemberForm({
      ...member,
      ministryIds: mIds,
      ministriesJoinedNow: mIds,
      ministriesServedBefore: member.ministriesServedBefore || [],
      currentMinistryStatus: member.currentMinistryStatus || 'Active Serving Member',
    });
    setFormTab('personal');
    setFieldErrors({});
    setFormValidationError('');
    setProvisionAccount(false);
    setIsEditModalOpen(true);
  };

  const handleOpenDepartureModal = (member: Member) => {
    setDepartureTargetMember(member);
    setDepartureForm({
      reason: (member.departureReason as any) || (member.membershipStatus !== 'Active' ? member.membershipStatus as any : 'Deceased'),
      date: member.departureDate || member.statusStartDate || new Date().toISOString().split('T')[0],
      endDate: member.departureEndDate || member.statusEndDate || '',
      excommunicationPaperUrl: member.excommunicationPaperUrl || '',
      excommunicationPaperName: member.excommunicationPaperName || '',
      excommunicationDescription: member.excommunicationDescription || member.departureNotes || '',
    });
    setIsRecordDepartureModalOpen(true);
  };

  const handleSaveDeparture = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!departureTargetMember) return;

    const statusMap: Record<string, MembershipStatus> = {
      'Deceased': 'Deceased',
      'Transferred': 'Transferred',
      'Excommunicated': 'Excommunicated',
      'Inactive': 'Inactive',
      'On Leave': 'On Leave',
      'Left Church': 'Left Church',
      'Moved Away': 'Left Church',
      'Resigned': 'Left Church',
    };

    const newStatus: MembershipStatus = statusMap[departureForm.reason] || 'Left Church';

    const isExcommunicated = departureForm.reason === 'Excommunicated' || newStatus === 'Excommunicated';
    const endDate = isExcommunicated ? (departureForm.endDate || undefined) : undefined;

    const updated: Member = {
      ...departureTargetMember,
      membershipStatus: newStatus,
      departureReason: departureForm.reason,
      departureDate: departureForm.date,
      departureEndDate: endDate,
      statusStartDate: departureForm.date,
      statusEndDate: endDate,
      excommunicationPaperUrl: isExcommunicated ? (departureForm.excommunicationPaperUrl || undefined) : undefined,
      excommunicationPaperName: isExcommunicated ? (departureForm.excommunicationPaperName || undefined) : undefined,
      excommunicationDescription: isExcommunicated ? (departureForm.excommunicationDescription || undefined) : undefined,
    };

    updateMember(updated);
    addAuditLog(
      'Record Departure / Status Change',
      'Member Directory',
      `Recorded ${departureForm.reason} for ${departureTargetMember.firstName} ${departureTargetMember.lastName}`
    );

    setIsRecordDepartureModalOpen(false);
    setDepartureTargetMember(null);
  };

  const handleRestoreMember = (member: Member) => {
    const updated: Member = {
      ...member,
      membershipStatus: 'Active',
      departureReason: undefined,
      departureDate: undefined,
      departureEndDate: undefined,
      statusStartDate: undefined,
      statusEndDate: undefined,
      departureNotes: undefined,
    };
    updateMember(updated);
    addAuditLog(
      'Re-activate Member',
      'Member Directory',
      `Restored ${member.firstName} ${member.lastName} to Active Member Directory`
    );
  };

  const [formValidationError, setFormValidationError] = useState<string>('');

  // Section-level validation for each of the 6 tabs
  const validateSection = (
    section: FormTab,
    form: Partial<Member>
  ): { isValid: boolean; errors: Record<string, string> } => {
    const errors: Record<string, string> = {};

    if (section === 'personal') {
      if (!form.firstName?.trim() || form.firstName.trim().length < 2) {
        errors.firstName = 'First Name is strictly required (minimum 2 characters).';
      }
      if (!form.lastName?.trim() || form.lastName.trim().length < 2) {
        errors.lastName = 'Last Name / Grandfather Name is strictly required (minimum 2 characters).';
      }
      if (!form.gender) {
        errors.gender = 'Gender must be selected.';
      }
      if (!form.dateOfBirth) {
        errors.dateOfBirth = 'Date of Birth is strictly required.';
      }
    }

    if (section === 'marital') {
      if (!form.maritalStatus) {
        errors.maritalStatus = 'Marital status must be selected.';
      }
      if (form.maritalStatus === 'Married') {
        if (form.spousePhone?.trim()) {
          const spouseCheck = validateEthiopianPhone(form.spousePhone);
          if (!spouseCheck.isValid) {
            errors.spousePhone = spouseCheck.error || 'Invalid Ethiopian phone (+2519/+2517 or 09/07)';
          }
        }
      }
      if (form.maritalStatus !== 'Single') {
        if (Number(form.maleChildrenCount) < 0) errors.maleChildrenCount = 'Children count cannot be negative.';
        if (Number(form.femaleChildrenCount) < 0) errors.femaleChildrenCount = 'Children count cannot be negative.';
        if (Number(form.adoptedChildrenCount) < 0) errors.adoptedChildrenCount = 'Children count cannot be negative.';
      }
    }

    if (section === 'contact') {
      if (!form.primaryPhone?.trim()) {
        errors.primaryPhone = 'Primary Ethiopian mobile number is strictly required.';
      } else {
        const phoneCheck = validateEthiopianPhone(form.primaryPhone);
        if (!phoneCheck.isValid) {
          errors.primaryPhone = phoneCheck.error || 'Invalid Ethiopian phone (+2519/+2517 or 09/07)';
        }
      }

      if (form.altPhone?.trim()) {
        const altCheck = validateEthiopianPhone(form.altPhone);
        if (!altCheck.isValid) {
          errors.altPhone = altCheck.error || 'Invalid alternative Ethiopian phone.';
        }
      }

      if (form.email?.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(form.email.trim())) {
          errors.email = 'Please enter a valid email address (or leave empty).';
        }
      }

      if (!form.woreda?.trim()) {
        errors.woreda = 'Woreda is strictly required for Ethiopian address mapping.';
      }
      if (!form.kebele?.trim()) {
        errors.kebele = 'Kebele is strictly required for Ethiopian address mapping.';
      }
      if (!form.houseNumber?.trim()) {
        errors.houseNumber = 'House Number is strictly required.';
      }
    }

    if (section === 'spiritual') {
      if (!form.branchId) {
        errors.branchId = 'Assigned Campus Branch is required.';
      }
      if (!form.membershipDate) {
        errors.membershipDate = 'Membership Date is required.';
      }
      if (!form.membershipStatus) {
        errors.membershipStatus = 'Membership status is required.';
      }
      if (form.membershipStatus && form.membershipStatus !== 'Active') {
        const depDate = form.departureDate || form.statusStartDate;
        if (!depDate) {
          errors.departureDate = 'Status / Departure Date is required for non-active members.';
        }
      }
      if (form.membershipStatus === 'Excommunicated') {
        if (!form.excommunicationDescription?.trim() && !form.excommunicationPaperUrl) {
          errors.excommunicationDescription = 'Official decree or excommunication description is required.';
        }
      }
    }

    if (section === 'professional') {
      if (!form.educationLevel) {
        errors.educationLevel = 'Education level must be selected.';
      }
      if (form.employerType === 'Other' && !form.employerTypeOther?.trim()) {
        errors.employerTypeOther = 'Please specify the other employer type.';
      }
    }

    if (section === 'health') {
      // Health and medical details remain strictly optional
      if (form.emergencyContact?.phone?.trim()) {
        const ecPhoneCheck = validateEthiopianPhone(form.emergencyContact.phone);
        if (!ecPhoneCheck.isValid) {
          errors.emergencyPhone = ecPhoneCheck.error || 'Invalid emergency contact phone number.';
        }
      }
    }

    return { isValid: Object.keys(errors).length === 0, errors };
  };

  // Section completion status for visual progress and tab indicators
  const sectionStatus = useMemo(() => {
    const tabs: FormTab[] = ['personal', 'marital', 'contact', 'spiritual', 'professional', 'health'];
    const completion: Record<FormTab, boolean> = {
      personal: false,
      marital: false,
      contact: false,
      spiritual: false,
      professional: false,
      health: false,
    };
    for (const t of tabs) {
      completion[t] = validateSection(t, memberForm).isValid;
    }
    const completedCount = Object.values(completion).filter(Boolean).length;
    const progressPercent = Math.round((completedCount / tabs.length) * 100);
    return { completion, completedCount, progressPercent, total: tabs.length };
  }, [memberForm]);

  // Minimum required baseline: valid identity, contact and active campus.
  // Other sections are optional and are saved whenever the user has entered data.
  const validateRequiredBasics = (): {
    isValid: boolean;
    firstInvalidTab?: FormTab;
    firstError?: string;
    allErrors: Record<string, string>;
  } => {
    const errors: Record<string, string> = {};
    Object.assign(errors, validateSection('personal', memberForm).errors);
    if (!memberForm.primaryPhone?.trim()) errors.primaryPhone = 'Primary phone number is required.';
    else {
      const check = validateEthiopianPhone(memberForm.primaryPhone);
      if (!check.isValid) errors.primaryPhone = check.error || 'Enter a valid Ethiopian mobile number.';
    }
    if (memberForm.altPhone?.trim()) {
      const check = validateEthiopianPhone(memberForm.altPhone);
      if (!check.isValid) errors.altPhone = check.error || 'Enter a valid alternative phone number.';
    }
    if (memberForm.email?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(memberForm.email.trim())) {
      errors.email = 'Enter a valid email address or leave it empty.';
    }
    if (!memberForm.branchId || !branches.some((branch) => branch.id === memberForm.branchId)) {
      errors.branchId = 'Select an active campus / branch.';
    }
    if (provisionAccount && !isEditModalOpen) {
      if (accountIdentifierType === 'email' && !memberForm.email?.trim()) errors.accountIdentifier = 'A member email is required for account provisioning.';
      if (accountIdentifierType === 'phone' && !memberForm.primaryPhone?.trim()) errors.accountIdentifier = 'A member phone number is required for account provisioning.';
      if (!accountTempPassword || accountTempPassword.length < 8) errors.accountPassword = 'Temporary password must be at least 8 characters long.';
    }
    const keys = Object.keys(errors);
    const firstInvalidTab: FormTab | undefined =
      keys.some((key) => ['firstName','lastName','gender','dateOfBirth'].includes(key)) ? 'personal' :
      keys.some((key) => ['primaryPhone','altPhone','email'].includes(key)) ? 'contact' :
      keys.includes('branchId') ? 'spiritual' : (provisionAccount ? 'health' : undefined);
    return { isValid: keys.length === 0, firstInvalidTab, firstError: Object.values(errors)[0], allErrors: errors };
  };

  // Validates all 6 sections and accounts provisioning
  const validateAllSections = (): {
    isValid: boolean;
    firstInvalidTab?: FormTab;
    firstError?: string;
    allErrors: Record<string, string>;
  } => {
    const tabs: FormTab[] = ['personal', 'marital', 'contact', 'spiritual', 'professional', 'health'];
    const allErrors: Record<string, string> = {};
    let firstInvalidTab: FormTab | undefined;
    let firstError: string | undefined;

    for (const tab of tabs) {
      const res = validateSection(tab, memberForm);
      if (!res.isValid) {
        Object.assign(allErrors, res.errors);
        if (!firstInvalidTab) {
          firstInvalidTab = tab;
          firstError = Object.values(res.errors)[0];
        }
      }
    }

    // Validate account provisioning if enabled
    if (provisionAccount && !isEditModalOpen) {
      if (accountIdentifierType === 'email') {
        if (!memberForm.email?.trim()) {
          allErrors.accountIdentifier = 'Member email address is required for portal account provisioning. Please enter an email in Section 3 or switch identifier to Phone.';
          if (!firstInvalidTab) {
            firstInvalidTab = 'contact';
            firstError = allErrors.accountIdentifier;
          }
        } else {
          const emailLower = memberForm.email.trim().toLowerCase();
          const existingUser = (systemUsers || []).find(
            (u) => u.email?.toLowerCase() === emailLower
          );
          if (existingUser) {
            allErrors.accountIdentifier = `A user account with email "${memberForm.email}" already exists.`;
            if (!firstInvalidTab) {
              firstInvalidTab = 'health';
              firstError = allErrors.accountIdentifier;
            }
          }
        }
      } else {
        if (!memberForm.primaryPhone?.trim()) {
          allErrors.accountIdentifier = 'Primary phone is required for phone-based portal account provisioning.';
          if (!firstInvalidTab) {
            firstInvalidTab = 'contact';
            firstError = allErrors.accountIdentifier;
          }
        } else {
          const normPhone = formatToE164(memberForm.primaryPhone);
          const existingUser = (systemUsers || []).find(
            (u) => u.phone && formatToE164(u.phone) === normPhone
          );
          if (existingUser) {
            allErrors.accountIdentifier = `A user account with phone "${memberForm.primaryPhone}" already exists.`;
            if (!firstInvalidTab) {
              firstInvalidTab = 'health';
              firstError = allErrors.accountIdentifier;
            }
          }
        }
      }

      if (!accountTempPassword || accountTempPassword.length < 8) {
        allErrors.accountPassword = 'Temporary password must be at least 8 characters long.';
        if (!firstInvalidTab) {
          firstInvalidTab = 'health';
          firstError = allErrors.accountPassword;
        }
      }
    }

    return {
      isValid: Object.keys(allErrors).length === 0,
      firstInvalidTab,
      firstError,
      allErrors,
    };
  };

  const handleSaveNewMember = async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateRequiredBasics();
    if (!validation.isValid) {
      setFieldErrors(validation.allErrors);
      setFormValidationError(validation.firstError || 'Please complete the required basic information before submitting.');
      if (validation.firstInvalidTab) setFormTab(validation.firstInvalidTab);
      return;
    }
    setFieldErrors({});
    setFormValidationError('');

    const newId = `mem-${Date.now().toString().slice(-4)}`;
    const statusNotActive = memberForm.membershipStatus && memberForm.membershipStatus !== 'Active';
    const startDate = memberForm.departureDate || memberForm.statusStartDate || (statusNotActive ? new Date().toISOString().split('T')[0] : undefined);
    const endDate = memberForm.membershipStatus === 'Excommunicated' ? (memberForm.departureEndDate || memberForm.statusEndDate || undefined) : undefined;

    const fullNewMember: Member = {
      id: newId,
      memberIdNumber: `CMMS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      title: memberForm.title || 'Mr',
      firstName: memberForm.firstName!,
      middleName: memberForm.middleName || '',
      lastName: memberForm.lastName!,
      maritalStatus: memberForm.maritalStatus || 'Single',
      marriageDate: memberForm.maritalStatus === 'Married' ? (memberForm.marriageDate || '') : '',
      divorceDate: memberForm.maritalStatus === 'Divorced' ? (memberForm.divorceDate || '') : '',
      spouseName: memberForm.maritalStatus === 'Married' ? (memberForm.spouseName || '') : '',
      spousePhone: memberForm.maritalStatus === 'Married' && memberForm.spousePhone ? formatToE164(memberForm.spousePhone) : '',
      spouseMemberId: memberForm.maritalStatus === 'Married' ? (memberForm.spouseMemberId || '') : '',
      dateOfBirth: memberForm.dateOfBirth || '1995-01-01',
      age: memberForm.dateOfBirth
        ? new Date().getFullYear() - new Date(memberForm.dateOfBirth).getFullYear()
        : 30,
      gender: (memberForm.gender as Gender) || 'Male',
      nationality: memberForm.nationality || 'Ethiopian',
      nationalIdNumber: memberForm.nationalIdNumber || '',
      passportNumber: memberForm.passportNumber || '',
      photoUrl: memberForm.photoUrl || (memberForm.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR),
      primaryPhone: formatToE164(memberForm.primaryPhone || '0911000000'),
      altPhone: memberForm.altPhone ? formatToE164(memberForm.altPhone) : '',
      email: memberForm.email || '',
      preferredCommChannel: memberForm.preferredCommChannel || 'SMS',
      streetAddress: memberForm.streetAddress || '',
      city: memberForm.city || '',
      subCity: memberForm.subCity || '',
      woreda: memberForm.woreda || '',
      kebele: memberForm.kebele || '',
      houseNumber: memberForm.houseNumber || '',
      region: memberForm.region || '',
      postalCode: memberForm.postalCode || '',
      maleChildrenCount: memberForm.maritalStatus === 'Single' ? 0 : (Number(memberForm.maleChildrenCount) || 0),
      femaleChildrenCount: memberForm.maritalStatus === 'Single' ? 0 : (Number(memberForm.femaleChildrenCount) || 0),
      adoptedChildrenCount: memberForm.maritalStatus === 'Single' ? 0 : (Number(memberForm.adoptedChildrenCount) || 0),
      salvationDate: memberForm.salvationDate || '',
      salvationLocation: memberForm.salvationLocation || '',
      isWaterBaptized: memberForm.isWaterBaptized ?? false,
      waterBaptismDate: memberForm.waterBaptismDate || '',
      waterBaptismLocation: memberForm.waterBaptismLocation || '',
      isHolySpiritBaptized: memberForm.isHolySpiritBaptized ?? false,
      spiritualGifts: memberForm.spiritualGifts || [],
      membershipDate: memberForm.membershipDate || new Date().toISOString().split('T')[0],
      membershipLocation: memberForm.membershipLocation || '',
      membershipStatus: (memberForm.membershipStatus as MembershipStatus) || 'Active',
      departureReason: statusNotActive ? ((memberForm.departureReason as any) || (memberForm.membershipStatus as any)) : undefined,
      departureDate: statusNotActive ? startDate : undefined,
      statusStartDate: statusNotActive ? startDate : undefined,
      departureEndDate: statusNotActive ? endDate : undefined,
      statusEndDate: statusNotActive ? endDate : undefined,
      excommunicationPaperUrl: memberForm.membershipStatus === 'Excommunicated' ? memberForm.excommunicationPaperUrl : undefined,
      excommunicationPaperName: memberForm.membershipStatus === 'Excommunicated' ? memberForm.excommunicationPaperName : undefined,
      excommunicationDescription: memberForm.membershipStatus === 'Excommunicated' ? memberForm.excommunicationDescription : undefined,
      branchId: memberForm.branchId || branches[0]?.id || '',
      foundationCourseCompleted: memberForm.foundationCourseCompleted ?? false,
      educationLevel: memberForm.educationLevel || 'Bachelor',
      employerType: memberForm.employerType || 'Private',
      employerTypeOther: memberForm.employerType === 'Other' ? (memberForm.employerTypeOther || '') : '',
      fieldOfStudy: memberForm.fieldOfStudy || '',
      occupation: memberForm.occupation || '',
      employerName: memberForm.employerName || '',
      skillsAndTalents: memberForm.skillsAndTalents || [],
      languagesSpoken: memberForm.languagesSpoken || ['English'],
      bloodType: memberForm.bloodType || 'A+',
      knownAllergies: memberForm.knownAllergies || [],
      medicalConditions: memberForm.medicalConditions || [],
      emergencyContact: memberForm.emergencyContact || {
        name: '',
        relationship: '',
        phone: '',
      },
      currentMinistryStatus: memberForm.currentMinistryStatus || 'Active Serving Member',
      ministryIds: memberForm.ministryIds || [],
      ministriesServedBefore: memberForm.ministriesServedBefore || [],
      ministriesJoinedNow: memberForm.ministriesJoinedNow || (memberForm.ministryIds || []),
      createdAt: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString().split('T')[0],
      attendanceScore: 100,
    };

    let persistedMember: Member;
    try {
      persistedMember = await addMember(fullNewMember);
    } catch (error: any) {
      console.error('[MemberModule] Member registration failed:', error);
      setFormValidationError(
        error?.message || 'The member record could not be saved. Please check your connection and try again.'
      );
      return;
    }

    // Optional Account Provisioning is intentionally performed only after the member
    // record has been persisted, so a login account cannot be created for an unsaved member.
    if (provisionAccount) {
      const loginIdentifier =
        accountIdentifierType === 'email'
          ? memberForm.email!.trim().toLowerCase()
          : formatToE164(memberForm.primaryPhone!);

      const newSysUser: SystemUser = {
        id: `usr-${Date.now()}`,
        name: `${fullNewMember.firstName} ${fullNewMember.lastName}`,
        email: fullNewMember.email?.trim().toLowerCase() || `${fullNewMember.memberIdNumber.toLowerCase().replace(/[^a-z0-9]/g, '')}@portal.gracecathedral.org`,
        phone: fullNewMember.primaryPhone,
        role: accountRole,
        primaryRole: accountRole,
        roles: [accountRole],
        userRoles: [{ role: accountRole, isPrimary: true, assignedAt: new Date().toISOString() }],
        branchId: fullNewMember.branchId,
        branchName: branches.find((b) => b.id === fullNewMember.branchId)?.name || 'Headquarters Campus',
        status: 'Active',
        lastLogin: 'Never',
        must_change_password: accountMustChangePassword,
        mustChangePassword: accountMustChangePassword,
        temporaryPassword: accountTempPassword,
        security: {
          lastLoginAt: 'Never',
        },
      };
      (newSysUser as any).memberId = persistedMember.id;
      (newSysUser as any).password = accountTempPassword;

      addSystemUser(newSysUser);
      apiService
        .createUser({
          ...newSysUser,
          temporaryPassword: accountTempPassword,
        } as any)
        .catch((err) => {
          console.warn('Backend user provisioning error:', err);
        });

      // Display Credential Summary Modal
      setCreatedAccountSummary({
        isOpen: true,
        memberName: `${fullNewMember.firstName} ${fullNewMember.lastName}`,
        memberIdNumber: fullNewMember.memberIdNumber,
        username: loginIdentifier,
        role: accountRole,
        tempPassword: accountTempPassword,
        mustChangePassword: accountMustChangePassword,
      });
    }

    setIsAddModalOpen(false);
  };

  const handleUpdateMemberSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberForm.id) return;
    const validation = validateRequiredBasics();
    if (!validation.isValid) {
      setFieldErrors(validation.allErrors);
      setFormValidationError(validation.firstError || 'Please complete the required basic information.');
      if (validation.firstInvalidTab) setFormTab(validation.firstInvalidTab);
      return;
    }
    setFieldErrors({});
    setFormValidationError('');

    const statusNotActive = memberForm.membershipStatus && memberForm.membershipStatus !== 'Active';
    const startDate = memberForm.departureDate || memberForm.statusStartDate || (statusNotActive ? new Date().toISOString().split('T')[0] : undefined);
    const endDate = memberForm.membershipStatus === 'Excommunicated' ? (memberForm.departureEndDate || memberForm.statusEndDate || undefined) : undefined;

    const updatedMember: Member = {
      ...(memberForm as Member),
      primaryPhone: memberForm.primaryPhone ? formatToE164(memberForm.primaryPhone) : (memberForm.primaryPhone || ''),
      altPhone: memberForm.altPhone ? formatToE164(memberForm.altPhone) : '',
      spousePhone: memberForm.spousePhone ? formatToE164(memberForm.spousePhone) : '',
      emergencyContact: memberForm.emergencyContact ? {
        ...memberForm.emergencyContact,
        phone: memberForm.emergencyContact.phone ? formatToE164(memberForm.emergencyContact.phone) : '',
      } : undefined,
      currentMinistryStatus: memberForm.currentMinistryStatus || 'Active Serving Member',
      ministryIds: memberForm.ministryIds || [],
      ministriesJoinedNow: memberForm.ministriesJoinedNow || (memberForm.ministryIds || []),
      ministriesServedBefore: memberForm.ministriesServedBefore || [],
      membershipStatus: (memberForm.membershipStatus as MembershipStatus) || 'Active',
      departureReason: statusNotActive ? ((memberForm.departureReason as any) || (memberForm.membershipStatus as any)) : undefined,
      departureDate: statusNotActive ? startDate : undefined,
      statusStartDate: statusNotActive ? startDate : undefined,
      departureEndDate: statusNotActive ? endDate : undefined,
      statusEndDate: statusNotActive ? endDate : undefined,
      excommunicationPaperUrl: memberForm.membershipStatus === 'Excommunicated' ? memberForm.excommunicationPaperUrl : undefined,
      excommunicationPaperName: memberForm.membershipStatus === 'Excommunicated' ? memberForm.excommunicationPaperName : undefined,
      excommunicationDescription: memberForm.membershipStatus === 'Excommunicated' ? memberForm.excommunicationDescription : undefined,
    };

    try {
      await updateMember(updatedMember);
    } catch (error: any) {
      setFormValidationError(error?.message || 'The member changes could not be saved. Please retry.');
      return;
    }
    addAuditLog('Update Member Profile', 'Member Directory', `Updated details for member ${memberForm.firstName} ${memberForm.lastName}`);

    if (selectedMember && selectedMember.id === memberForm.id) {
      setSelectedMember(updatedMember);
    }

    setIsEditModalOpen(false);
  };

  const handleDeleteMemberClick = (id: string, name: string, memberIdNumber?: string) => {
    const found = members.find((m) => m.id === id);
    setDeleteTargetMember({
      id,
      name,
      memberIdNumber: memberIdNumber || found?.memberIdNumber,
    });
  };

  const handleConfirmDeleteMember = () => {
    if (!deleteTargetMember) return;
    const { id, name } = deleteTargetMember;
    deleteMember(id);
    addAuditLog('Delete Member Record', 'Member Directory', `Deleted member ID: ${id} (${name})`);
    if (selectedMember?.id === id) {
      setSelectedMember(null);
    }
    setDeleteTargetMember(null);
  };

  const handleExportMembersCSV = (targetList: Member[] = filteredMembers, filenamePrefix: string = 'CMMS_Members_Directory') => {
    const headers = [
      'Member ID',
      'Title',
      'First Name',
      'Middle Name',
      'Last Name',
      'Gender',
      'Primary Phone',
      'Email',
      'Status',
      'Campus Branch',
      'Woreda',
      'Kebele',
      'House No',
      'Occupation',
      'Attendance %',
    ];
    const rows = targetList.map((m) => {
      const branchObj = branches.find((b) => b.id === m.branchId);
      const branchLabel = branchObj?.name || m.membershipLocation || 'Headquarters Campus';
      return [
        m.memberIdNumber || '',
        m.title || '',
        m.firstName || '',
        m.middleName || '',
        m.lastName || '',
        m.gender || '',
        m.primaryPhone || '',
        m.email || '',
        m.membershipStatus || 'Active',
        branchLabel,
        m.woreda || '',
        m.kebele || '',
        m.houseNumber || '',
        m.occupation || '',
        `${m.attendanceScore ?? 100}%`,
      ]
        .map((cell) => `"${String(cell).replace(/"/g, '""')}"`)
        .join(',');
    });
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filenamePrefix}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    addAuditLog('Export Member Directory CSV', 'Member Directory', `Exported ${targetList.length} member records to CSV`);
  };

  const handlePrintDirectory = () => {
    window.print();
  };

  const getBranchName = (branchId?: string, fallbackLocation?: string) => {
    if (branchId) {
      const found = branches.find((b) => b.id === branchId);
      if (found?.name) return found.name;
    }
    return fallbackLocation || branches[0]?.name || 'Headquarters Campus';
  };

  return (
    <div className="space-y-6">
      {/* Subpage Navigation Bar: Member Directory vs Family & Household vs Past Members with Sliding Animation */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="relative p-1.5 bg-slate-100 dark:bg-slate-800/90 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 max-w-2xl w-full shadow-inner select-none overflow-hidden">
          {/* Animated Sliding Background Indicator */}
          <div
            className={`absolute top-1.5 bottom-1.5 left-1.5 rounded-xl transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] shadow-md ${
              activeSubTab === 'members'
                ? 'translate-x-0 bg-blue-600 shadow-blue-500/25'
                : activeSubTab === 'family'
                ? 'translate-x-full bg-indigo-600 shadow-indigo-500/25'
                : 'translate-x-[200%] bg-rose-600 shadow-rose-500/25'
            }`}
            style={{ width: 'calc((100% - 12px) / 3)' }}
          />

          {/* Buttons track: Grid ensures exactly equal 1/3 widths with zero overlap */}
          <div className="relative z-10 grid grid-cols-3">
            {/* Active Members Button */}
            <button
              type="button"
              onClick={() => setActiveSubTab('members')}
              className={`min-h-[44px] flex items-center justify-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-2 rounded-xl text-xs font-bold transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                activeSubTab === 'members'
                  ? 'text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span className="truncate">{t('Active Members')}</span>
              <span
                className={`ml-0.5 sm:ml-1 px-1.5 sm:px-2 py-0.5 rounded-full text-[11px] font-bold transition-colors duration-200 ${
                  activeSubTab === 'members'
                    ? 'bg-white/25 text-white'
                    : 'bg-white/80 dark:bg-slate-700/80 text-slate-700 dark:text-slate-300'
                }`}
              >
                {activeMembers.length}
              </span>
            </button>

            {/* Family & Household Button */}
            <button
              type="button"
              onClick={() => setActiveSubTab('family')}
              className={`min-h-[44px] flex items-center justify-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-2 rounded-xl text-xs font-bold transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                activeSubTab === 'family'
                  ? 'text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Home className="w-4 h-4 shrink-0" />
              <span className="truncate">{t('Family & Household')}</span>
              <span
                className={`ml-0.5 sm:ml-1 px-1.5 sm:px-2 py-0.5 rounded-full text-[11px] font-bold transition-colors duration-200 ${
                  activeSubTab === 'family'
                    ? 'bg-white/25 text-white'
                    : 'bg-white/80 dark:bg-slate-700/80 text-slate-700 dark:text-slate-300'
                }`}
              >
                {families.length}
              </span>
            </button>

            {/* Past & Death Record Button */}
            <button
              type="button"
              onClick={() => setActiveSubTab('past_members')}
              className={`min-h-[44px] flex items-center justify-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-2 rounded-xl text-xs font-bold transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                activeSubTab === 'past_members'
                  ? 'text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <UserX className="w-4 h-4 shrink-0" />
              <span className="truncate">{t('Past and Death', 'Past & Death Record')}</span>
              <span
                className={`ml-0.5 sm:ml-1 px-1.5 sm:px-2 py-0.5 rounded-full text-[11px] font-bold transition-colors duration-200 ${
                  activeSubTab === 'past_members'
                    ? 'bg-white/25 text-white'
                    : 'bg-white/80 dark:bg-slate-700/80 text-slate-700 dark:text-slate-300'
                }`}
              >
                {pastMembers.length}
              </span>
            </button>
          </div>
        </div>
      </div>

      <div key={activeSubTab} className="animate-in fade-in slide-in-from-right-3 duration-300">
      {activeSubTab === 'family' ? (
        <React.Suspense
          fallback={
            <div className="w-full min-h-[300px] flex items-center justify-center p-8">
              <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
          }
        >
          <FamilyModule />
        </React.Suspense>
      ) : activeSubTab === 'past_members' ? (
        /* Past and Death Record View */
        <div className="space-y-6">
          {/* Header Controls for Past and Death Record */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <UserX className="w-6 h-6 text-rose-600 shrink-0" />
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">{t('Past and Death Record')}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200">
                  {pastMembers.length} {t('records')}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Historical records for members who have moved away, transferred, resigned, or passed away (Death Records) with Ethiopian date conversion.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full lg:w-auto">
              <div className="relative flex-1 sm:flex-initial">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  placeholder={t('Search past member name, ID, reason...', 'Search records...')}
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  className="pl-9 pr-3 py-2 min-h-[44px] sm:min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white w-full sm:w-64 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2">
                <ActionMenu
                  triggerLabel="Export"
                  triggerTitle="Export or Print Past Records"
                  items={[
                    {
                      id: 'export-past-csv',
                      label: 'Export Archived CSV',
                      icon: <Download className="w-3.5 h-3.5 text-rose-600" />,
                      onClick: () => handleExportMembersCSV(filteredPastMembers, 'CMMS_Past_And_Death_Records'),
                    },
                    {
                      id: 'print-past',
                      label: 'Print Past Records',
                      icon: <Printer className="w-3.5 h-3.5 text-slate-600" />,
                      onClick: handlePrintDirectory,
                    },
                  ]}
                />

                {/* Grid / List View Toggle */}
                <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0">
                  <button
                    type="button"
                    onClick={() => setPastViewMode('grid')}
                    className={`min-h-[38px] sm:min-h-[34px] px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                      pastViewMode === 'grid'
                        ? 'bg-white dark:bg-slate-700 text-rose-600 dark:text-rose-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                    title={t('Grid')}
                  >
                    <LayoutGrid className="w-4 h-4 shrink-0" />
                    <span className="hidden sm:inline">{t('Grid')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPastViewMode('list')}
                    className={`min-h-[38px] sm:min-h-[34px] px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                      pastViewMode === 'list'
                        ? 'bg-white dark:bg-slate-700 text-rose-600 dark:text-rose-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                    title={t('List')}
                  >
                    <List className="w-4 h-4 shrink-0" />
                    <span className="hidden sm:inline">{t('List')}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* KPI Breakdown Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-semibold block">✝️ Deceased Records</span>
                <span className="text-2xl font-extrabold text-slate-900 dark:text-white mt-0.5 block">
                  {pastMembers.filter((m) => m.membershipStatus === 'Deceased' || m.departureReason === 'Deceased').length}
                </span>
              </div>
              <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-200">
                <UserX className="w-5 h-5 text-slate-800 dark:text-slate-200" />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-semibold block">🔄 Transferred Out</span>
                <span className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 mt-0.5 block">
                  {pastMembers.filter((m) => m.membershipStatus === 'Transferred' || m.departureReason === 'Transferred').length}
                </span>
              </div>
              <div className="p-3 bg-blue-50 dark:bg-blue-950/50 rounded-xl text-blue-600">
                <Users className="w-5 h-5" />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-semibold block">🚪 Left / Moved Away</span>
                <span className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 mt-0.5 block">
                  {pastMembers.filter((m) => m.membershipStatus === 'Left Church' || m.departureReason === 'Left Church' || m.departureReason === 'Moved Away' || m.departureReason === 'Resigned').length}
                </span>
              </div>
              <div className="p-3 bg-amber-50 dark:bg-amber-950/50 rounded-xl text-amber-600">
                <Home className="w-5 h-5" />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500 font-semibold block">📋 Total Past Records</span>
                <span className="text-2xl font-extrabold text-purple-600 dark:text-purple-400 mt-0.5 block">
                  {pastMembers.length}
                </span>
              </div>
              <div className="p-3 bg-purple-50 dark:bg-purple-950/50 rounded-xl text-purple-600">
                <Award className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Past and Death Records Display */}
          {pastMembers.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <UserX className="w-12 h-12 mx-auto text-slate-400" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">No Past or Death Records Found</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                No past members or death records currently archived. Members whose status is set to 'Left Church', 'Deceased', or 'Transferred' will automatically appear in this view.
              </p>
            </div>
          ) : pastViewMode === 'grid' ? (
            /* GRID VIEW */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredPastMembers.map((member) => {
                const startDate = member.departureDate || member.statusStartDate;
                const isExcommunicated = member.membershipStatus === 'Excommunicated' || member.departureReason === 'Excommunicated';
                const endDate = isExcommunicated ? (member.departureEndDate || member.statusEndDate) : undefined;
                const etStartDate = startDate ? gregorianToEthiopian(startDate) : null;
                const etEndDate = endDate ? gregorianToEthiopian(endDate) : null;
                const isDeceased = member.membershipStatus === 'Deceased' || member.departureReason === 'Deceased';

                return (
                  <div
                    key={member.id}
                    className={`bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group ${
                      isExcommunicated
                        ? 'min-h-[440px] border-2 border-purple-300 dark:border-purple-800 ring-2 ring-purple-500/10'
                        : 'min-h-[300px] border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div>
                      {/* ID + Gender Row */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span className="px-2.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 font-mono font-bold text-blue-600 dark:text-blue-400 text-[11px]">
                          {member.memberIdNumber}
                        </span>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          {member.gender || 'Member'}
                        </span>
                      </div>

                      {/* Photo + Name + Phone (Click to view profile) */}
                      <div
                        onClick={() => {
                          setSelectedMember(member);
                          setDetailTab('personal');
                        }}
                        className="flex items-center gap-3 cursor-pointer group-hover:opacity-90 transition-opacity mb-4"
                        title="Click to view full profile details"
                      >
                        <img
                          src={member.photoUrl || (member.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR)}
                          alt={`${member.firstName} ${member.lastName}`}
                          className="w-14 h-14 rounded-2xl object-cover ring-2 ring-slate-200 dark:ring-slate-700 shrink-0"
                        />
                        <div className="min-w-0">
                          <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate hover:text-rose-600 dark:hover:text-rose-400 transition-colors">
                            {member.title} {member.firstName} {member.lastName}
                          </h3>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                            {member.primaryPhone || 'No Phone'}
                          </p>
                        </div>
                      </div>

                      {/* Status Badge */}
                      <div className="mb-3">
                        <span
                          className={`w-full py-1.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 ${
                            isDeceased
                              ? 'bg-slate-900 text-white dark:bg-slate-800 dark:text-rose-200 border border-slate-700'
                              : member.membershipStatus === 'Transferred' || member.departureReason === 'Transferred'
                              ? 'bg-blue-100 text-blue-900 dark:bg-blue-950 dark:text-blue-200 border border-blue-200 dark:border-blue-800'
                              : member.membershipStatus === 'Excommunicated' || member.departureReason === 'Excommunicated'
                              ? 'bg-purple-100 text-purple-900 dark:bg-purple-950 dark:text-purple-200 border border-purple-200 dark:border-purple-800'
                              : member.membershipStatus === 'On Leave' || member.departureReason === 'On Leave'
                              ? 'bg-indigo-100 text-indigo-900 dark:bg-indigo-950 dark:text-indigo-200 border border-indigo-200 dark:border-indigo-800'
                              : member.membershipStatus === 'Inactive' || member.departureReason === 'Inactive'
                              ? 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700'
                              : 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border border-amber-200 dark:border-amber-800'
                          }`}
                        >
                          {isDeceased ? '✝️ Deceased Record' : `🚪 ${member.departureReason || member.membershipStatus}`}
                        </span>
                      </div>

                      {/* Departure / Passing Date Range with Ethiopian conversion */}
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-1 mb-4 border border-slate-100 dark:border-slate-800">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                          {isDeceased ? 'Date of Passing' : 'Status / Departure Date Range'}
                        </span>
                        <p className="font-bold text-slate-800 dark:text-slate-200 text-xs">
                          {startDate ? (
                            <>
                              {startDate} {endDate ? `to ${endDate}` : isDeceased ? '' : 'to Present'}
                            </>
                          ) : (
                            'N/A'
                          )}
                        </p>
                        {etStartDate && (
                          <p className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-400 flex flex-wrap items-center gap-1">
                            <span>🇪🇹</span>
                            <span>
                              {etStartDate.formattedAmharic}
                              {etEndDate ? ` – ${etEndDate.formattedAmharic}` : ''}
                            </span>
                          </p>
                        )}
                      </div>

                      {/* Excommunication Paper & Description (if status is Excommunicated) */}
                      {isExcommunicated && (
                        <div className="p-3 bg-purple-50/90 dark:bg-purple-950/50 rounded-xl border border-purple-200 dark:border-purple-800 space-y-2 mb-3 text-xs">
                          <div className="flex items-center justify-between gap-1">
                            <span className="font-bold text-purple-900 dark:text-purple-200 text-[11px] flex items-center gap-1">
                              <FileText className="w-3.5 h-3.5 text-purple-600" /> Excommunication Details
                            </span>
                            {member.excommunicationPaperUrl ? (
                              <button
                                type="button"
                                onClick={() => setPaperPreviewModal({
                                  isOpen: true,
                                  title: `Paper of Excommunication - ${member.firstName} ${member.lastName}`,
                                  url: member.excommunicationPaperUrl || '',
                                  fileName: member.excommunicationPaperName || 'Excommunication Paper'
                                })}
                                className="px-2 py-0.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-xs cursor-pointer"
                              >
                                <Paperclip className="w-3 h-3" /> View Paper
                              </button>
                            ) : (
                              <label className="cursor-pointer px-2 py-0.5 bg-purple-100 dark:bg-purple-900 hover:bg-purple-200 text-purple-900 dark:text-purple-100 rounded-lg text-[10px] font-bold flex items-center gap-1">
                                <Upload className="w-3 h-3" /> Import Paper
                                <input
                                  type="file"
                                  accept="image/*,.pdf,.doc,.docx"
                                  className="hidden"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onload = (evt) => {
                                        updateMember({
                                          ...member,
                                          excommunicationPaperUrl: evt.target?.result as string,
                                          excommunicationPaperName: file.name,
                                        });
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  }}
                                />
                              </label>
                            )}
                          </div>

                          {member.excommunicationDescription ? (
                            <p className="text-purple-950 dark:text-purple-100 text-xs italic bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg border border-purple-100 dark:border-purple-900/50">
                              "{member.excommunicationDescription}"
                            </p>
                          ) : (
                            <p className="text-purple-700/70 dark:text-purple-400/70 text-[11px] italic">
                              No excommunication description recorded.
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Bar */}
                    <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 truncate">
                        {getBranchName(member.branchId, member.membershipLocation)}
                      </span>
                      <ActionMenu
                        recordTitle={`${member.title} ${member.firstName} ${member.lastName}`}
                        recordSubtitle={`${member.memberIdNumber} • ${member.primaryPhone}`}
                        primaryAction={{
                          label: 'Profile',
                          icon: <Eye className="w-3.5 h-3.5" />,
                          variant: 'primary',
                          onClick: () => {
                            setSelectedMember(member);
                            setDetailTab('personal');
                          },
                        }}
                        items={[
                          {
                            id: 'view-past',
                            label: 'View Full Profile',
                            icon: <Eye className="w-3.5 h-3.5 text-blue-500" />,
                            onClick: () => {
                              setSelectedMember(member);
                              setDetailTab('personal');
                            },
                          },
                          {
                            id: 'reactivate-past',
                            label: 'Reactivate Member',
                            icon: <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />,
                            variant: 'emerald',
                            hidden: !permissions.canEditMembers,
                            onClick: () => handleRestoreMember(member),
                          },
                          {
                            id: 'edit-past',
                            label: 'Edit Member Details',
                            icon: <Edit3 className="w-3.5 h-3.5 text-amber-500" />,
                            hidden: !permissions.canEditMembers,
                            onClick: () => handleOpenEditModal(member),
                          },
                          {
                            id: 'delete-past',
                            label: 'Delete Member Record',
                            icon: <Trash2 className="w-3.5 h-3.5" />,
                            variant: 'danger',
                            dividerBefore: true,
                            hidden: !permissions.canEditMembers,
                            onClick: () =>
                              handleDeleteMemberClick(
                                member.id,
                                `${member.firstName} ${member.lastName}`,
                                member.memberIdNumber
                              ),
                          },
                        ]}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* LIST / TABLE VIEW (Responsive: Table on >=768px, Cards on <768px) */
            <>
              <div className="hidden md:block bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-800/60 font-bold text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="p-3 whitespace-nowrap">Member ID</th>
                        <th className="p-3">Member Name</th>
                        <th className="p-3">Status / Reason</th>
                        <th className="p-3">Date Range (Start to End)</th>
                        <th className="p-3 text-right sticky right-0 bg-slate-50 dark:bg-slate-800/95 z-10">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                      {filteredPastMembers.map((member) => {
                        const startDate = member.departureDate || member.statusStartDate;
                        const isExcommunicated = member.membershipStatus === 'Excommunicated' || member.departureReason === 'Excommunicated';
                        const endDate = isExcommunicated ? (member.departureEndDate || member.statusEndDate) : undefined;
                        const etStartDate = startDate ? gregorianToEthiopian(startDate) : null;
                        const etEndDate = endDate ? gregorianToEthiopian(endDate) : null;
                        const isDeceased = member.membershipStatus === 'Deceased' || member.departureReason === 'Deceased';

                        return (
                          <tr key={member.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                            <td className="p-3 font-mono font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap">
                              {member.memberIdNumber}
                            </td>
                            <td className="p-3">
                              <div
                                onClick={() => {
                                  setSelectedMember(member);
                                  setDetailTab('personal');
                                }}
                                className="flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-opacity"
                                title="Click to view member profile"
                              >
                                <img
                                  src={member.photoUrl || (member.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR)}
                                  alt=""
                                  className="w-9 h-9 rounded-xl object-cover ring-1 ring-slate-300 shrink-0"
                                />
                                <div className="min-w-0">
                                  <p className="font-bold text-slate-900 dark:text-white hover:text-rose-600 dark:hover:text-rose-400 transition-colors truncate">
                                    {member.title} {member.firstName} {member.lastName}
                                  </p>
                                  <p className="text-[10px] text-slate-500">{member.primaryPhone}</p>
                                </div>
                              </div>
                            </td>
                            <td className="p-3">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold inline-flex items-center gap-1 whitespace-nowrap ${
                                  isDeceased
                                    ? 'bg-slate-900 text-white dark:bg-slate-800'
                                    : member.membershipStatus === 'Transferred' || member.departureReason === 'Transferred'
                                    ? 'bg-blue-100 text-blue-900 dark:bg-blue-950 dark:text-blue-200'
                                    : member.membershipStatus === 'Excommunicated' || member.departureReason === 'Excommunicated'
                                    ? 'bg-purple-100 text-purple-900 dark:bg-purple-950 dark:text-purple-200'
                                    : member.membershipStatus === 'On Leave' || member.departureReason === 'On Leave'
                                    ? 'bg-indigo-100 text-indigo-900 dark:bg-indigo-950 dark:text-indigo-200'
                                    : member.membershipStatus === 'Inactive' || member.departureReason === 'Inactive'
                                    ? 'bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-200'
                                    : 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200'
                                }`}
                              >
                                {isDeceased ? '✝️ Deceased' : `🚪 ${member.departureReason || member.membershipStatus}`}
                              </span>

                              {isExcommunicated && (
                                <div className="mt-1.5 space-y-1">
                                  {member.excommunicationDescription && (
                                    <p className="text-[11px] text-purple-900 dark:text-purple-200 italic line-clamp-2 max-w-xs">
                                      "{member.excommunicationDescription}"
                                    </p>
                                  )}
                                  <div>
                                    {member.excommunicationPaperUrl ? (
                                      <button
                                        type="button"
                                        onClick={() => setPaperPreviewModal({
                                          isOpen: true,
                                          title: `Paper of Excommunication - ${member.firstName} ${member.lastName}`,
                                          url: member.excommunicationPaperUrl || '',
                                          fileName: member.excommunicationPaperName || 'Excommunication Paper'
                                        })}
                                        className="inline-flex items-center gap-1 text-[10px] font-bold text-purple-700 dark:text-purple-300 hover:underline cursor-pointer bg-purple-50 dark:bg-purple-950 px-2 py-0.5 rounded-md border border-purple-200 dark:border-purple-800"
                                      >
                                        <Paperclip className="w-3 h-3 text-purple-600" /> {member.excommunicationPaperName || 'View Paper of Excommunication'}
                                      </button>
                                    ) : (
                                      <label className="inline-flex items-center gap-1 text-[10px] font-bold text-purple-700 dark:text-purple-300 hover:text-purple-900 cursor-pointer bg-purple-50 dark:bg-purple-950 px-2 py-0.5 rounded-md border border-purple-200 dark:border-purple-800">
                                        <Upload className="w-3 h-3 text-purple-600" /> Import Paper of Excommunication
                                        <input
                                          type="file"
                                          accept="image/*,.pdf,.doc,.docx"
                                          className="hidden"
                                          onChange={(e) => {
                                            const file = e.target.files?.[0];
                                            if (file) {
                                              const reader = new FileReader();
                                              reader.onload = (evt) => {
                                                updateMember({
                                                  ...member,
                                                  excommunicationPaperUrl: evt.target?.result as string,
                                                  excommunicationPaperName: file.name,
                                                });
                                              };
                                              reader.readAsDataURL(file);
                                            }
                                          }}
                                        />
                                      </label>
                                    )}
                                  </div>
                                </div>
                              )}
                            </td>
                            <td className="p-3">
                              <p className="font-bold">
                                {startDate ? (
                                  <>
                                    {startDate} {endDate ? `to ${endDate}` : ''}
                                  </>
                                ) : (
                                  'N/A'
                                )}
                              </p>
                              {etStartDate && (
                                <p className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-400">
                                  🇪🇹 {etStartDate.formattedAmharic}
                                  {etEndDate ? ` – ${etEndDate.formattedAmharic}` : ''}
                                </p>
                              )}
                            </td>
                            <td className="p-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/90 z-10">
                              <ActionMenu
                                recordTitle={`${member.title} ${member.firstName} ${member.lastName}`}
                                recordSubtitle={`${member.memberIdNumber} • ${member.primaryPhone}`}
                                primaryAction={{
                                  label: 'Profile',
                                  icon: <Eye className="w-3.5 h-3.5" />,
                                  variant: 'primary',
                                  onClick: () => {
                                    setSelectedMember(member);
                                    setDetailTab('personal');
                                  },
                                }}
                                secondaryDesktopActions={
                                  permissions.canEditMembers
                                    ? [
                                        {
                                          id: 'reactivate-inline',
                                          label: 'Reactivate',
                                          icon: <RotateCcw className="w-3.5 h-3.5" />,
                                          variant: 'emerald',
                                          onClick: () => handleRestoreMember(member),
                                        },
                                      ]
                                    : []
                                }
                                items={[
                                  {
                                    id: 'view-past',
                                    label: 'View Full Profile',
                                    icon: <Eye className="w-3.5 h-3.5 text-blue-500" />,
                                    onClick: () => {
                                      setSelectedMember(member);
                                      setDetailTab('personal');
                                    },
                                  },
                                  {
                                    id: 'reactivate-past',
                                    label: 'Reactivate Member',
                                    icon: <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />,
                                    variant: 'emerald',
                                    hidden: !permissions.canEditMembers,
                                    onClick: () => handleRestoreMember(member),
                                  },
                                  {
                                    id: 'edit-past',
                                    label: 'Edit Member Details',
                                    icon: <Edit3 className="w-3.5 h-3.5 text-amber-500" />,
                                    hidden: !permissions.canEditMembers,
                                    onClick: () => handleOpenEditModal(member),
                                  },
                                  {
                                    id: 'delete-past',
                                    label: 'Delete Member Record',
                                    icon: <Trash2 className="w-3.5 h-3.5" />,
                                    variant: 'danger',
                                    dividerBefore: true,
                                    hidden: !permissions.canEditMembers,
                                    onClick: () =>
                                      handleDeleteMemberClick(
                                        member.id,
                                        `${member.firstName} ${member.lastName}`,
                                        member.memberIdNumber
                                      ),
                                  },
                                ]}
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Mobile Stacked Cards (< 768px) when in List mode */}
              <div className="md:hidden grid grid-cols-1 gap-3">
                {filteredPastMembers.map((member) => {
                  const startDate = member.departureDate || member.statusStartDate;
                  const isDeceased = member.membershipStatus === 'Deceased' || member.departureReason === 'Deceased';
                  return (
                    <div
                      key={member.id}
                      className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <img
                          src={member.photoUrl || (member.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR)}
                          alt=""
                          className="w-11 h-11 rounded-xl object-cover ring-1 ring-slate-300 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[11px] font-mono font-bold text-blue-600 dark:text-blue-400">
                              {member.memberIdNumber}
                            </span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200">
                              {isDeceased ? '✝️ Deceased' : member.departureReason || member.membershipStatus}
                            </span>
                          </div>
                          <p className="font-bold text-sm text-slate-900 dark:text-white truncate mt-0.5">
                            {member.title} {member.firstName} {member.lastName}
                          </p>
                          <p className="text-xs text-slate-500">{member.primaryPhone}</p>
                        </div>
                      </div>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                        <span className="text-[11px] text-slate-500 truncate">
                          Date: <strong>{startDate || 'N/A'}</strong>
                        </span>
                        <ActionMenu
                          recordTitle={`${member.title} ${member.firstName} ${member.lastName}`}
                          recordSubtitle={`${member.memberIdNumber} • ${member.primaryPhone}`}
                          primaryAction={{
                            label: 'Profile',
                            icon: <Eye className="w-3.5 h-3.5" />,
                            variant: 'primary',
                            onClick: () => {
                              setSelectedMember(member);
                              setDetailTab('personal');
                            },
                          }}
                          items={[
                            {
                              id: 'view-past-mob',
                              label: 'View Full Profile',
                              icon: <Eye className="w-3.5 h-3.5 text-blue-500" />,
                              onClick: () => {
                                setSelectedMember(member);
                                setDetailTab('personal');
                              },
                            },
                            {
                              id: 'reactivate-past-mob',
                              label: 'Reactivate Member',
                              icon: <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />,
                              variant: 'emerald',
                              hidden: !permissions.canEditMembers,
                              onClick: () => handleRestoreMember(member),
                            },
                            {
                              id: 'delete-past-mob',
                              label: 'Delete Member Record',
                              icon: <Trash2 className="w-3.5 h-3.5" />,
                              variant: 'danger',
                              dividerBefore: true,
                              hidden: !permissions.canEditMembers,
                              onClick: () =>
                                handleDeleteMemberClick(
                                  member.id,
                                  `${member.firstName} ${member.lastName}`,
                                  member.memberIdNumber
                                ),
                            },
                          ]}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      ) : (
        <>
          {/* Read-Only Notice if user has no write permissions */}
          {!permissions.canEditMembers && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <span className="font-semibold">
                  Read-Only Access Active: Your current role permits viewing directory data only. Member creation and profile modifications are restricted.
                </span>
              </div>
              <span className="px-2 py-0.5 bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 rounded text-[10px] font-bold uppercase">
                View-Only Mode
              </span>
            </div>
          )}

          {/* Header Controls & Actions - Responsive Toolbar */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 py-2">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Users className="w-6 h-6 text-blue-600 shrink-0" />
                <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">{t('Member Directory')}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  {filteredMembers.length} {t('records')}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Complete member registration, address & kebele tracking, marriage & baptism dates, ministry history, and Ethiopian Calendar conversion.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2.5 w-full lg:w-auto">
              {/* Member Search Bar - Full width on mobile */}
              <div className="relative w-full sm:w-auto sm:flex-1 lg:flex-initial">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  placeholder={t('Search member name, phone, kebele, woreda...', 'Search Members...')}
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  className="pl-9 pr-3 py-2.5 min-h-[44px] sm:min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white w-full lg:w-64 focus:outline-hidden focus:ring-2 focus:ring-blue-500 shadow-2xs"
                />
              </div>

              <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 w-full sm:w-auto">
                {permissions.canEditMembers && (
                  <button
                    type="button"
                    onClick={handleOpenAddModal}
                    className="col-span-2 sm:col-span-1 min-h-[44px] sm:min-h-[40px] px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-extrabold shadow-md transition-all inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <UserPlus className="w-4 h-4 shrink-0" />
                    <span>{t('Register Member', 'Add Member')}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setIsFilterDrawerOpen(!isFilterDrawerOpen)}
                  className={`min-h-[44px] sm:min-h-[40px] px-3.5 py-2 rounded-xl border text-xs font-bold transition-all inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
                    isFilterDrawerOpen
                      ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <Filter className="w-4 h-4 text-slate-500 shrink-0" />
                  <span>{t('Filter')}</span>
                </button>

                {/* Grouped Secondary Toolbar Operations (Share Form, Export CSV, Print, Family Management) */}
                <div className="flex items-center justify-end sm:justify-start gap-2">
                  {permissions.canEditMembers && (
                    <button
                      type="button"
                      onClick={() => setIsShareFormModalOpen(true)}
                      className="hidden xl:inline-flex min-h-[40px] px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-extrabold shadow-md transition-all items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                      title="Generate & Share Google-Form style public registration link, QR codes & Embed snippet"
                    >
                      <Link2 className="w-4 h-4 shrink-0" />
                      <span>{t('Share Form', 'Share Form')}</span>
                    </button>
                  )}

                  <ActionMenu
                    triggerLabel="More"
                    triggerTitle="Directory Actions & Export"
                    recordTitle="Member Directory Operations"
                    recordSubtitle={`${filteredMembers.length} active member records`}
                    items={[
                      {
                        id: 'toolbar-share-form',
                        label: 'Share Public Registration Form',
                        icon: <Link2 className="w-3.5 h-3.5 text-purple-600" />,
                        variant: 'indigo',
                        hidden: !permissions.canEditMembers,
                        onClick: () => setIsShareFormModalOpen(true),
                      },
                      {
                        id: 'toolbar-export-csv',
                        label: 'Export Directory (CSV)',
                        icon: <Download className="w-3.5 h-3.5 text-emerald-600" />,
                        variant: 'emerald',
                        onClick: () => handleExportMembersCSV(filteredMembers, 'CMMS_Active_Members'),
                      },
                      {
                        id: 'toolbar-print',
                        label: 'Print Member Directory',
                        icon: <Printer className="w-3.5 h-3.5 text-blue-600" />,
                        onClick: handlePrintDirectory,
                      },
                      {
                        id: 'toolbar-manage-families',
                        label: 'Manage Families & Households',
                        icon: <Home className="w-3.5 h-3.5 text-indigo-600" />,
                        dividerBefore: true,
                        onClick: () => setActiveSubTab('family'),
                      },
                      {
                        id: 'toolbar-past-records',
                        label: 'View Past & Death Records',
                        icon: <UserX className="w-3.5 h-3.5 text-rose-600" />,
                        onClick: () => setActiveSubTab('past_members'),
                      },
                    ]}
                  />
                </div>

                <div className="col-span-2 sm:col-span-1 flex items-center justify-center bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0">
                  <button
                    type="button"
                    onClick={() => setViewMode('grid')}
                    className={`flex-1 sm:flex-initial min-h-[38px] sm:min-h-[34px] px-3 py-1.5 text-xs font-bold rounded-lg transition-all inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
                      viewMode === 'grid'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                    title="Grid View"
                  >
                    <LayoutGrid className="w-4 h-4 shrink-0" />
                    <span>Cards</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('list')}
                    className={`flex-1 sm:flex-initial min-h-[38px] sm:min-h-[34px] px-3 py-1.5 text-xs font-bold rounded-lg transition-all inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
                      viewMode === 'list'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                    title="List View"
                  >
                    <List className="w-4 h-4 shrink-0" />
                    <span>Table</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Filter Drawer bar */}
          {isFilterDrawerOpen && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                  Membership Status
                </label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full min-h-[40px] p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                >
                  <option value="All">All Statuses</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                  <option value="Transferred">Transferred</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">Campus Branch</label>
                <select
                  value={filterBranch}
                  onChange={(e) => setFilterBranch(e.target.value)}
                  className="w-full min-h-[40px] p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                >
                  <option value="All">All Campuses</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">Baptism Status</label>
                <select
                  value={filterBaptized}
                  onChange={(e) => setFilterBaptized(e.target.value)}
                  className="w-full min-h-[40px] p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                >
                  <option value="All">All Members</option>
                  <option value="Water Baptized">Water Baptized Only</option>
                  <option value="Holy Spirit Baptized">Holy Spirit Baptized Only</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">Gender</label>
                <select
                  value={filterGender}
                  onChange={(e) => setFilterGender(e.target.value)}
                  className="w-full min-h-[40px] p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                >
                  <option value="All">All Genders</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
            </div>
          )}

          {/* Members Directory Display (Grid vs List) */}
          {viewMode === 'list' ? (
            <>
              {/* Desktop & Tablet Data Table (768px and above) */}
              <div className="hidden md:block bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
                <div className="cmms-table-scroll overflow-x-auto">
                  <table className="cmms-data-table w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
                      <tr>
                        <th onClick={() => handleSort('memberIdNumber')} className="p-3 cursor-pointer select-none hover:text-blue-600 whitespace-nowrap">
                          Member ID {sortField === 'memberIdNumber' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th onClick={() => handleSort('fullName')} className="p-3 cursor-pointer select-none hover:text-blue-600">
                          Full Name {sortField === 'fullName' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th onClick={() => handleSort('phone')} className="p-3 cursor-pointer select-none hover:text-blue-600">
                          Phone & Email {sortField === 'phone' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th onClick={() => handleSort('kebele')} className="hidden lg:table-cell p-3 cursor-pointer select-none hover:text-blue-600">
                          Campus / Woreda {sortField === 'kebele' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th onClick={() => handleSort('status')} className="p-3 cursor-pointer select-none hover:text-blue-600 whitespace-nowrap">
                          Status {sortField === 'status' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th onClick={() => handleSort('attendance')} className="hidden xl:table-cell p-3 cursor-pointer select-none hover:text-blue-600 whitespace-nowrap">
                          Attendance {sortField === 'attendance' && (sortOrder === 'asc' ? '↑' : '↓')}
                        </th>
                        <th className="p-3 text-right sticky right-0 bg-slate-50 dark:bg-slate-800/95 z-10">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                      {paginatedMembers.map((member) => (
                        <tr key={member.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                          <td className="p-3 font-mono font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap tabular-nums">
                            {member.memberIdNumber}
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-2.5 min-w-[170px]">
                              <img src={member.photoUrl} alt="" className="w-8 h-8 rounded-lg object-cover ring-1 ring-blue-500/30 shrink-0" />
                              <div className="min-w-0">
                                <p className="font-bold truncate">{member.title} {member.firstName} {member.lastName}</p>
                                <p className="text-[10px] text-slate-500 truncate">
                                  {member.occupation} • <span className="text-blue-600 dark:text-blue-400 font-semibold">{getBranchName(member.branchId, member.membershipLocation)}</span>
                                </p>
                                {(() => {
                                  const joined = ministries.filter(
                                    (m) =>
                                      member.ministryIds?.includes(m.id) ||
                                      m.memberIds?.includes(member.id) ||
                                      m.leaderMemberId === member.id
                                  );
                                  if (joined.length === 0) return null;
                                  return (
                                    <div className="flex flex-wrap gap-1 mt-1">
                                      {joined.slice(0, 2).map((m) => (
                                        <span
                                          key={m.id}
                                          className="px-1.5 py-0.2 rounded text-[9px] bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-semibold whitespace-nowrap"
                                        >
                                          {m.leaderMemberId === member.id ? '👑 ' : '✓ '}{m.name}
                                        </span>
                                      ))}
                                      {joined.length > 2 && (
                                        <span className="text-[9px] text-slate-400 font-bold">+{joined.length - 2} more</span>
                                      )}
                                    </div>
                                  );
                                })()}
                              </div>
                            </div>
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <p className="tabular-nums font-medium">{member.primaryPhone}</p>
                            <p className="text-[10px] text-slate-500 truncate max-w-[150px]">{member.email}</p>
                          </td>
                          <td className="hidden lg:table-cell p-3">
                            <p className="font-semibold text-blue-700 dark:text-blue-300 truncate max-w-[160px]">
                              {getBranchName(member.branchId, member.membershipLocation)}
                            </p>
                            <p className="text-[10px] text-slate-500">
                              {member.woreda || 'N/A'}, Kebele {member.kebele || 'N/A'}
                            </p>
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${
                              member.membershipStatus === 'Active'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {member.membershipStatus}
                            </span>
                          </td>
                          <td className="hidden xl:table-cell p-3 font-bold text-emerald-600 tabular-nums whitespace-nowrap">{member.attendanceScore}%</td>
                          <td className="p-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/90 z-10">
                            <ActionMenu
                              recordTitle={`${member.title} ${member.firstName} ${member.lastName}`}
                              recordSubtitle={`${member.memberIdNumber} • ${member.primaryPhone}`}
                              primaryAction={{
                                label: 'View',
                                icon: <Eye className="w-3.5 h-3.5" />,
                                variant: 'primary',
                                onClick: () => {
                                  setSelectedMember(member);
                                  setDetailTab('personal');
                                },
                              }}
                              secondaryDesktopActions={
                                permissions.canEditMembers
                                  ? [
                                      {
                                        id: 'edit-inline',
                                        label: 'Edit',
                                        icon: <Edit3 className="w-3.5 h-3.5" />,
                                        variant: 'amber',
                                        onClick: () => handleOpenEditModal(member),
                                      },
                                    ]
                                  : []
                              }
                              items={[
                                {
                                  id: 'view',
                                  label: 'View Full Profile',
                                  icon: <Eye className="w-3.5 h-3.5 text-blue-500" />,
                                  onClick: () => {
                                    setSelectedMember(member);
                                    setDetailTab('personal');
                                  },
                                },
                                {
                                  id: 'edit',
                                  label: 'Edit Member Details',
                                  icon: <Edit3 className="w-3.5 h-3.5 text-amber-500" />,
                                  hidden: !permissions.canEditMembers,
                                  onClick: () => handleOpenEditModal(member),
                                },
                                {
                                  id: 'family',
                                  label: 'Family & Household',
                                  icon: <Home className="w-3.5 h-3.5 text-indigo-500" />,
                                  onClick: () => {
                                    setSelectedMember(member);
                                    setDetailTab('family');
                                  },
                                },
                                {
                                  id: 'digital-id',
                                  label: 'Digital ID Card / Pass',
                                  icon: <QrCode className="w-3.5 h-3.5 text-emerald-600" />,
                                  onClick: () => {
                                    setSelectedMember(member);
                                    setDetailTab('digital_id');
                                  },
                                },
                                {
                                  id: 'departure',
                                  label: 'Status / Departure',
                                  icon: <UserX className="w-3.5 h-3.5 text-amber-600" />,
                                  hidden: !permissions.canEditMembers,
                                  onClick: () => handleOpenDepartureModal(member),
                                },
                                {
                                  id: 'delete',
                                  label: 'Delete Member',
                                  icon: <Trash2 className="w-3.5 h-3.5" />,
                                  variant: 'danger',
                                  dividerBefore: true,
                                  hidden: !permissions.canEditMembers,
                                  onClick: () =>
                                    handleDeleteMemberClick(
                                      member.id,
                                      `${member.firstName} ${member.lastName}`,
                                      member.memberIdNumber
                                    ),
                                },
                              ]}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Mobile Stacked Cards (< 768px) when in Table mode */}
              <div className="md:hidden grid grid-cols-1 gap-3">
                {paginatedMembers.map((member) => (
                  <div
                    key={member.id}
                    className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3"
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={member.photoUrl}
                        alt=""
                        className="w-11 h-11 rounded-xl object-cover ring-1 ring-blue-500/30 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] font-mono font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                            {member.memberIdNumber}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap ${
                              member.membershipStatus === 'Active'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {member.membershipStatus}
                          </span>
                        </div>
                        <p className="font-bold text-sm text-slate-900 dark:text-white truncate mt-0.5">
                          {member.title} {member.firstName} {member.lastName}
                        </p>
                        <p className="text-xs text-slate-500 truncate">{member.occupation}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs">
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block">Phone</span>
                        <span className="font-semibold text-slate-700 dark:text-slate-200 tabular-nums">{member.primaryPhone}</span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block">Campus Branch</span>
                        <span className="font-semibold text-blue-600 dark:text-blue-400 truncate block">
                          {getBranchName(member.branchId, member.membershipLocation)}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block">Location</span>
                        <span className="font-medium text-slate-700 dark:text-slate-300 truncate block">
                          {member.woreda || 'N/A'}, Keb {member.kebele || 'N/A'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block">Attendance</span>
                        <span className="font-bold text-emerald-600 tabular-nums">{member.attendanceScore}%</span>
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                      <span className="text-[11px] text-slate-400 truncate">
                        {member.email || 'No email'}
                      </span>
                      <ActionMenu
                        recordTitle={`${member.title} ${member.firstName} ${member.lastName}`}
                        recordSubtitle={`${member.memberIdNumber} • ${member.primaryPhone}`}
                        primaryAction={{
                          label: 'View',
                          icon: <Eye className="w-3.5 h-3.5" />,
                          variant: 'primary',
                          onClick: () => {
                            setSelectedMember(member);
                            setDetailTab('personal');
                          },
                        }}
                        items={[
                          {
                            id: 'view',
                            label: 'View Full Profile',
                            icon: <Eye className="w-3.5 h-3.5 text-blue-500" />,
                            onClick: () => {
                              setSelectedMember(member);
                              setDetailTab('personal');
                            },
                          },
                          {
                            id: 'edit',
                            label: 'Edit Member Details',
                            icon: <Edit3 className="w-3.5 h-3.5 text-amber-500" />,
                            hidden: !permissions.canEditMembers,
                            onClick: () => handleOpenEditModal(member),
                          },
                          {
                            id: 'family',
                            label: 'Family & Household',
                            icon: <Home className="w-3.5 h-3.5 text-indigo-500" />,
                            onClick: () => {
                              setSelectedMember(member);
                              setDetailTab('family');
                            },
                          },
                          {
                            id: 'digital-id',
                            label: 'Digital ID Card / Pass',
                            icon: <QrCode className="w-3.5 h-3.5 text-emerald-600" />,
                            onClick: () => {
                              setSelectedMember(member);
                              setDetailTab('digital_id');
                            },
                          },
                          {
                            id: 'departure',
                            label: 'Status / Departure',
                            icon: <UserX className="w-3.5 h-3.5 text-amber-600" />,
                            hidden: !permissions.canEditMembers,
                            onClick: () => handleOpenDepartureModal(member),
                          },
                          {
                            id: 'delete',
                            label: 'Delete Member',
                            icon: <Trash2 className="w-3.5 h-3.5" />,
                            variant: 'danger',
                            dividerBefore: true,
                            hidden: !permissions.canEditMembers,
                            onClick: () =>
                              handleDeleteMemberClick(
                                member.id,
                                `${member.firstName} ${member.lastName}`,
                                member.memberIdNumber
                              ),
                          },
                        ]}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            /* Members List Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {paginatedMembers.map((member) => (
                <div
                  key={member.id}
                  className="p-4 sm:p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
                >
                  <div>
                    <div className="flex items-start gap-3">
                      <img
                        src={member.photoUrl}
                        alt={member.firstName}
                        className="w-12 h-12 rounded-xl object-cover ring-2 ring-blue-500/30 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[10px] font-mono font-bold text-blue-600 dark:text-blue-400">
                            {member.memberIdNumber}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                              member.membershipStatus === 'Active'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {member.membershipStatus}
                          </span>
                        </div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate mt-0.5">
                          {member.title} {member.firstName} {member.lastName}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{member.occupation}</p>
                      </div>
                    </div>

                    <div className="mt-4 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="tabular-nums">{member.primaryPhone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Building className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                        <span className="truncate font-medium text-slate-700 dark:text-slate-200">
                          {getBranchName(member.branchId, member.membershipLocation)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">
                          {member.city}, {member.woreda || ''} {member.kebele ? `(Keb: ${member.kebele})` : ''}
                        </span>
                      </div>
                      {member.currentMinistryStatus && (
                        <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-medium">
                          <Award className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">{member.currentMinistryStatus}</span>
                        </div>
                      )}
                    </div>

                    {/* Spiritual gifts tags */}
                    {member.spiritualGifts && member.spiritualGifts.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1">
                        {member.spiritualGifts.slice(0, 3).map((gift) => (
                          <span
                            key={gift}
                            className="px-2 py-0.5 rounded-md text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium"
                          >
                            {gift}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Joined Ministries Badges */}
                    {(() => {
                      const memberJoined = ministries.filter(
                        (m) =>
                          member.ministryIds?.includes(m.id) ||
                          m.memberIds?.includes(member.id) ||
                          m.leaderMemberId === member.id
                      );
                      if (memberJoined.length === 0) return null;
                      return (
                        <div className="mt-2.5 flex flex-wrap gap-1 items-center">
                          <span className="text-[10px] text-slate-400 font-semibold">Ministries:</span>
                          {memberJoined.map((m) => (
                            <span
                              key={m.id}
                              className="px-2 py-0.5 rounded-md text-[10px] bg-indigo-50 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300 font-semibold border border-indigo-200/60 dark:border-indigo-800/60"
                            >
                              {m.leaderMemberId === member.id ? `👑 ${m.name}` : `✓ ${m.name}`}
                            </span>
                          ))}
                        </div>
                      );
                    })()}
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-500">
                      Attendance: <strong className="text-emerald-600">{member.attendanceScore}%</strong>
                    </span>

                    <ActionMenu
                      recordTitle={`${member.title} ${member.firstName} ${member.lastName}`}
                      recordSubtitle={`${member.memberIdNumber} • ${member.primaryPhone}`}
                      primaryAction={{
                        label: 'View',
                        icon: <Eye className="w-3.5 h-3.5" />,
                        variant: 'primary',
                        onClick: () => {
                          setSelectedMember(member);
                          setDetailTab('personal');
                        },
                      }}
                      items={[
                        {
                          id: 'view',
                          label: 'View Full Profile',
                          icon: <Eye className="w-3.5 h-3.5 text-blue-500" />,
                          onClick: () => {
                            setSelectedMember(member);
                            setDetailTab('personal');
                          },
                        },
                        {
                          id: 'edit',
                          label: 'Edit Member Details',
                          icon: <Edit3 className="w-3.5 h-3.5 text-amber-500" />,
                          hidden: !permissions.canEditMembers,
                          onClick: () => handleOpenEditModal(member),
                        },
                        {
                          id: 'family',
                          label: 'Family & Household',
                          icon: <Home className="w-3.5 h-3.5 text-indigo-500" />,
                          onClick: () => {
                            setSelectedMember(member);
                            setDetailTab('family');
                          },
                        },
                        {
                          id: 'digital-id',
                          label: 'Digital ID Card / Pass',
                          icon: <QrCode className="w-3.5 h-3.5 text-emerald-600" />,
                          onClick: () => {
                            setSelectedMember(member);
                            setDetailTab('digital_id');
                          },
                        },
                        {
                          id: 'departure',
                          label: 'Status / Departure',
                          icon: <UserX className="w-3.5 h-3.5 text-amber-600" />,
                          hidden: !permissions.canEditMembers,
                          onClick: () => handleOpenDepartureModal(member),
                        },
                        {
                          id: 'delete',
                          label: 'Delete Member',
                          icon: <Trash2 className="w-3.5 h-3.5" />,
                          variant: 'danger',
                          dividerBefore: true,
                          hidden: !permissions.canEditMembers,
                          onClick: () =>
                            handleDeleteMemberClick(
                              member.id,
                              `${member.firstName} ${member.lastName}`,
                              member.memberIdNumber
                            ),
                        },
                      ]}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Member Directory Pagination Controls */}
          {sortedMembers.length > 0 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs font-medium">
              <div className="text-slate-600 dark:text-slate-400 text-center sm:text-left tabular-nums">
                Showing <strong className="text-slate-900 dark:text-white font-bold">{startIndex + 1}</strong> to{' '}
                <strong className="text-slate-900 dark:text-white font-bold">{endIndex}</strong> of{' '}
                <strong className="text-slate-900 dark:text-white font-bold">{sortedMembers.length}</strong> total members
              </div>
              <div className="flex flex-wrap items-center justify-center gap-1.5 w-full sm:w-auto">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                  className="min-h-[38px] sm:min-h-[34px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer font-bold whitespace-nowrap shrink-0"
                >
                  Previous
                </button>
                <div className="hidden sm:flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .filter((pg) => pg === 1 || pg === totalPages || Math.abs(pg - currentPage) <= 1)
                    .map((pg, idx, arr) => (
                      <React.Fragment key={pg}>
                        {idx > 0 && arr[idx - 1] !== pg - 1 && (
                          <span className="px-1 text-slate-400">…</span>
                        )}
                        <button
                          type="button"
                          onClick={() => setCurrentPage(pg)}
                          className={`min-w-[34px] h-[34px] px-2 rounded-xl font-bold transition-all cursor-pointer tabular-nums ${
                            currentPage === pg
                              ? 'bg-blue-600 text-white shadow-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                          }`}
                        >
                          {pg}
                        </button>
                      </React.Fragment>
                    ))}
                </div>
                <span className="sm:hidden px-3 py-1.5 font-bold text-slate-700 dark:text-slate-200 tabular-nums whitespace-nowrap">
                  Page {currentPage} / {Math.max(1, totalPages)}
                </span>
                <button
                  type="button"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                  className="min-h-[38px] sm:min-h-[34px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer font-bold whitespace-nowrap shrink-0"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}
      </div>

          {/* REGISTER / EDIT MEMBER MODAL (FULL DETAILED REGISTRATION & EDITING) */}
          {(isAddModalOpen || isEditModalOpen) && (
            <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 overflow-y-auto">
              <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-3xl border-0 sm:border border-slate-200 dark:border-slate-800 p-4 sm:p-6 my-0 sm:my-8 space-y-4 max-h-[92vh] sm:max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <h3 className="font-bold text-base sm:text-lg text-slate-900 dark:text-white flex items-center gap-2">
                    {isEditModalOpen ? <Edit3 className="w-5 h-5 text-amber-500 shrink-0" /> : <UserPlus className="w-5 h-5 text-blue-600 shrink-0" />}
                    <span className="truncate">{isEditModalOpen ? `Edit Member: ${memberForm.firstName} ${memberForm.lastName}` : 'Detailed Member Registration'}</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddModalOpen(false);
                      setIsEditModalOpen(false);
                    }}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Visual Registration Progress Indicator */}
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span>Registration Progress: <strong>{sectionStatus.completedCount} of {sectionStatus.total}</strong> sections completed</span>
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                      sectionStatus.progressPercent === 100
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                    }`}>
                      {sectionStatus.progressPercent}% Complete
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-linear-to-r from-blue-600 to-indigo-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${sectionStatus.progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Form Section Navigation Tabs with Completion Status Badges */}
                <div className="flex border-b border-slate-200 dark:border-slate-800 gap-1.5 sm:gap-3 text-xs font-semibold overflow-x-auto pb-1">
                  <button
                    type="button"
                    onClick={() => setFormTab('personal')}
                    className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      formTab === 'personal' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                    }`}
                  >
                    {sectionStatus.completion.personal ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] flex items-center justify-center font-bold text-slate-600 dark:text-slate-400 shrink-0">1</span>
                    )}
                    <span>1. Personal & Identity</span>
                    {(fieldErrors.firstName || fieldErrors.lastName || fieldErrors.gender || fieldErrors.dateOfBirth) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Section has errors" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormTab('marital')}
                    className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      formTab === 'marital' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                    }`}
                  >
                    {sectionStatus.completion.marital ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] flex items-center justify-center font-bold text-slate-600 dark:text-slate-400 shrink-0">2</span>
                    )}
                    <span>2. Marital & Family Status</span>
                    {(fieldErrors.maritalStatus || fieldErrors.spousePhone) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Section has errors" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormTab('contact')}
                    className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      formTab === 'contact' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                    }`}
                  >
                    {sectionStatus.completion.contact ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] flex items-center justify-center font-bold text-slate-600 dark:text-slate-400 shrink-0">3</span>
                    )}
                    <span>3. Address (Woreda & Kebele)</span>
                    {(fieldErrors.primaryPhone || fieldErrors.woreda || fieldErrors.kebele || fieldErrors.houseNumber || fieldErrors.email) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Section has errors" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormTab('spiritual')}
                    className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      formTab === 'spiritual' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                    }`}
                  >
                    {sectionStatus.completion.spiritual ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] flex items-center justify-center font-bold text-slate-600 dark:text-slate-400 shrink-0">4</span>
                    )}
                    <span>4. Spiritual, Baptism & Ministry</span>
                    {(fieldErrors.branchId || fieldErrors.membershipDate || fieldErrors.departureDate || fieldErrors.excommunicationDescription) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Section has errors" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormTab('professional')}
                    className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      formTab === 'professional' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                    }`}
                  >
                    {sectionStatus.completion.professional ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] flex items-center justify-center font-bold text-slate-600 dark:text-slate-400 shrink-0">5</span>
                    )}
                    <span>5. Education & Work</span>
                    {(fieldErrors.educationLevel || fieldErrors.employerTypeOther) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Section has errors" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormTab('health')}
                    className={`min-h-[44px] px-2.5 pb-2 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      formTab === 'health' ? 'border-blue-600 text-blue-600 font-bold' : 'border-transparent text-slate-500'
                    }`}
                  >
                    {sectionStatus.completion.health ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] flex items-center justify-center font-bold text-slate-600 dark:text-slate-400 shrink-0">6</span>
                    )}
                    <span>6. Emergency & Health</span>
                    {(fieldErrors.emergencyPhone || fieldErrors.accountIdentifier || fieldErrors.accountPassword) && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Section has errors" />
                    )}
                  </button>
                </div>

                <form onSubmit={isEditModalOpen ? handleUpdateMemberSubmit : handleSaveNewMember} className="space-y-4 text-xs">
                  {/* Strict Validation Error Alert Banner */}
                  {formValidationError && (
                    <div className="p-3 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center justify-between gap-2 text-xs text-rose-700 dark:text-rose-200 animate-in fade-in">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span className="font-semibold">{formValidationError}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setFormValidationError('')}
                        className="text-rose-600 dark:text-rose-300 font-bold hover:underline cursor-pointer"
                      >
                        Dismiss
                      </button>
                    </div>
                  )}

                  {/* TAB 1: PERSONAL & IDENTITY DETAILS */}
                  {formTab === 'personal' && (
                    <div className="space-y-4">
                      {/* Photo Upload & Image Editor Panel */}
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                        <label className="block font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <Camera className="w-4 h-4 text-blue-600" /> Member Photo & Profile Avatar
                        </label>

                        <div className="flex flex-col sm:flex-row items-center gap-4">
                          <div className="relative shrink-0">
                            <img
                              src={memberForm.photoUrl || (memberForm.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR)}
                              alt="Member Preview"
                              className="w-20 h-20 rounded-2xl object-cover ring-4 ring-blue-500/20 shadow-md"
                            />
                          </div>

                          <div className="flex-1 w-full space-y-2 text-xs">
                            <div className="flex items-center gap-2">
                              <label className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold cursor-pointer transition-all flex items-center gap-1.5 shadow-sm">
                                <Upload className="w-4 h-4" /> Upload Custom Photo
                                <input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onloadend = () => {
                                        setMemberForm({ ...memberForm, photoUrl: reader.result as string });
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  }}
                                />
                              </label>
                              <span className="text-[11px] text-slate-500">Auto-defaults to gender avatar if not uploaded</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                        <div>
                          <label className="block font-semibold mb-1">Title</label>
                          <select
                            value={memberForm.title || 'Mr'}
                            onChange={(e) => setMemberForm({ ...memberForm, title: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                          >
                            <option value="Mr">Mr</option>
                            <option value="Mrs">Mrs</option>
                            <option value="Ms">Ms</option>
                            <option value="Dr">Dr</option>
                            <option value="Pastor">Pastor</option>
                            <option value="Evangelist">Evangelist</option>
                            <option value="Teacher">Teacher</option>
                            <option value="Professor">Professor</option>
                          </select>
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">
                            First Name <span className="text-rose-500 font-bold">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            value={memberForm.firstName || ''}
                            onChange={(e) => {
                              setMemberForm({ ...memberForm, firstName: e.target.value });
                              if (fieldErrors.firstName) setFieldErrors((prev) => ({ ...prev, firstName: '' }));
                            }}
                            className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 transition-all ${
                              fieldErrors.firstName
                                ? 'border-rose-400 ring-2 ring-rose-500/20'
                                : 'border-slate-300 dark:border-slate-700'
                            }`}
                          />
                          {fieldErrors.firstName && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.firstName}</p>
                          )}
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">Middle Name</label>
                          <input
                            type="text"
                            value={memberForm.middleName || ''}
                            onChange={(e) => setMemberForm({ ...memberForm, middleName: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">
                            Last Name / Grandfather <span className="text-rose-500 font-bold">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            value={memberForm.lastName || ''}
                            onChange={(e) => {
                              setMemberForm({ ...memberForm, lastName: e.target.value });
                              if (fieldErrors.lastName) setFieldErrors((prev) => ({ ...prev, lastName: '' }));
                            }}
                            className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 transition-all ${
                              fieldErrors.lastName
                                ? 'border-rose-400 ring-2 ring-rose-500/20'
                                : 'border-slate-300 dark:border-slate-700'
                            }`}
                          />
                          {fieldErrors.lastName && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.lastName}</p>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block font-semibold mb-1">
                            Gender <span className="text-rose-500 font-bold">*</span>
                          </label>
                          <select
                            value={memberForm.gender || 'Male'}
                            onChange={(e) => {
                              handleGenderChange(e.target.value as Gender);
                              if (fieldErrors.gender) setFieldErrors((prev) => ({ ...prev, gender: '' }));
                            }}
                            className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 font-semibold ${
                              fieldErrors.gender
                                ? 'border-rose-400 ring-2 ring-rose-500/20'
                                : 'border-slate-300 dark:border-slate-700'
                            }`}
                          >
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                          </select>
                          {fieldErrors.gender && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.gender}</p>
                          )}
                        </div>

                        {/* Date of Birth with Ethiopian Calendar Converter */}
                        <div>
                          <EthiopianDateHelper
                            label="Date of Birth *"
                            value={memberForm.dateOfBirth || '1995-05-15'}
                            onChange={(val) => {
                              setMemberForm({ ...memberForm, dateOfBirth: val });
                              if (fieldErrors.dateOfBirth) setFieldErrors((prev) => ({ ...prev, dateOfBirth: '' }));
                            }}
                          />
                          {fieldErrors.dateOfBirth && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.dateOfBirth}</p>
                          )}
                        </div>

                        <div>
                          <label className="block font-semibold mb-1">Nationality</label>
                          <select
                            value={memberForm.nationality || 'Ethiopian'}
                            onChange={(e) => setMemberForm({ ...memberForm, nationality: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                          >
                            <option value="Ethiopian">🇪🇹 Ethiopian</option>
                            <option value="Eritrean">🇪🇷 Eritrean</option>
                            <option value="Kenyan">🇰🇪 Kenyan</option>
                            <option value="Ugandan">🇺🇬 Ugandan</option>
                            <option value="Sudanese">🇸🇩 Sudanese</option>
                            <option value="South Sudanese">🇸🇸 South Sudanese</option>
                            <option value="Somali">🇸🇴 Somali</option>
                            <option value="Djiboutian">🇩🇯 Djiboutian</option>
                            <option value="American">🇺🇸 American</option>
                            <option value="Canadian">🇨🇦 Canadian</option>
                            <option value="British">🇬🇧 British</option>
                            <option value="German">🇩🇪 German</option>
                            <option value="Australian">🇦🇺 Australian</option>
                            <option value="Other">🌍 Other</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: MARITAL STATUS & FAMILY MEMBERS STATUS (CHILDREN BREAKDOWN) */}
                  {formTab === 'marital' && (
                    <div className="space-y-4">
                      {/* Section 1: Marital Status & Marriage / Divorce Details */}
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                          <div className="flex items-center gap-2">
                            <Heart className="w-4 h-4 text-rose-500" />
                            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                              1. Marital Status & Partner Details
                            </h4>
                          </div>
                          <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                            memberForm.maritalStatus === 'Married'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          }`}>
                            {memberForm.maritalStatus || 'Single'}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                          <div>
                            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                              Marital Status *
                            </label>
                            <select
                              value={memberForm.maritalStatus || 'Single'}
                              onChange={(e) =>
                                setMemberForm({
                                  ...memberForm,
                                  maritalStatus: e.target.value as MaritalStatus,
                                })
                              }
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-slate-900 dark:text-white"
                            >
                              <option value="Single">Single</option>
                              <option value="Married">Married</option>
                              <option value="Widowed">Widowed</option>
                              <option value="Divorced">Divorced</option>
                              <option value="Separated">Separated</option>
                            </select>
                          </div>

                          {memberForm.maritalStatus === 'Married' && (
                            <EthiopianDateHelper
                              label="Marriage Date (Wedding Date)"
                              value={memberForm.marriageDate || ''}
                              onChange={(val) => setMemberForm({ ...memberForm, marriageDate: val })}
                            />
                          )}

                          {memberForm.maritalStatus === 'Divorced' && (
                            <EthiopianDateHelper
                              label="Divorce Date"
                              value={memberForm.divorceDate || ''}
                              onChange={(val) => setMemberForm({ ...memberForm, divorceDate: val })}
                            />
                          )}
                        </div>

                        {/* Married Details: Spouse Name, Spouse Phone, and Auto-Mapping */}
                        {memberForm.maritalStatus === 'Married' && (
                          <div className="p-3.5 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900/60 space-y-3 mt-2">
                            <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-300 font-bold text-xs">
                              <Users className="w-4 h-4 text-emerald-600" />
                              <span>Spouse Information & Phone Mapping</span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div>
                                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                                  Spouse Full Name
                                </label>
                                <input
                                  type="text"
                                  placeholder="e.g., Almaz Bekele"
                                  value={memberForm.spouseName || ''}
                                  onChange={(e) => setMemberForm({ ...memberForm, spouseName: e.target.value })}
                                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                                />
                              </div>

                               <div>
                                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                                  Spouse Phone Number
                                </label>
                                <EthiopianPhoneInput
                                  value={memberForm.spousePhone || ''}
                                  onChange={(e) => setMemberForm({ ...memberForm, spousePhone: e.target.value })}
                                  placeholder="0911223344 or +251911223344"
                                />
                              </div>
                            </div>

                            {/* Auto Spouse Mapping by Phone */}
                            {(() => {
                              if (!memberForm.spousePhone || memberForm.spousePhone.length < 8) return null;
                              const cleanSearch = (memberForm.spousePhone || '').replace(/[\s\-\(\)\+]/g, '');
                              if (cleanSearch.length < 8) return null;
                              const matchedSpouse = (members || []).find((m) => {
                                if (m.id === memberForm.id) return false;
                                const cleanMemberPhone = (m.primaryPhone || '').replace(/[\s\-\(\)\+]/g, '');
                                if (cleanMemberPhone.length < 8) return false;
                                return cleanMemberPhone.endsWith(cleanSearch.slice(-8)) || cleanSearch.endsWith(cleanMemberPhone.slice(-8));
                              });

                              if (matchedSpouse) {
                                return (
                                  <div className="p-2.5 bg-emerald-100 dark:bg-emerald-900/60 rounded-xl border border-emerald-300 dark:border-emerald-700 flex items-center justify-between gap-2 text-xs">
                                    <div className="flex items-center gap-2">
                                      <img src={matchedSpouse.photoUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
                                      <div>
                                        <span className="font-bold text-emerald-950 dark:text-emerald-200">
                                          Mapped Church Member Found: {matchedSpouse.title} {matchedSpouse.firstName} {matchedSpouse.lastName}
                                        </span>
                                        <div className="text-[10px] text-emerald-800 dark:text-emerald-300">
                                          ID: {matchedSpouse.memberIdNumber} • Phone: {matchedSpouse.primaryPhone}
                                        </div>
                                      </div>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setMemberForm({
                                          ...memberForm,
                                          spouseName: `${matchedSpouse.firstName} ${matchedSpouse.lastName}`,
                                          spouseMemberId: matchedSpouse.id,
                                          spousePhone: matchedSpouse.primaryPhone,
                                        });
                                      }}
                                      className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-[11px] shadow-sm transition-all"
                                    >
                                      ✓ Link Spouse
                                    </button>
                                  </div>
                                );
                              }
                              return null;
                            })()}
                          </div>
                        )}
                      </div>

                      {/* Section 2: Family Members Status (Children Breakdown) - ONLY ACTIVE IF NOT SINGLE */}
                      {memberForm.maritalStatus !== 'Single' ? (
                        <div className="p-4 bg-indigo-50/60 dark:bg-indigo-950/30 rounded-2xl border border-indigo-200 dark:border-indigo-800/60 space-y-3">
                          <div className="flex items-center justify-between border-b border-indigo-200 dark:border-indigo-800/60 pb-2">
                            <div className="flex items-center gap-2">
                              <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                              <h4 className="font-bold text-indigo-950 dark:text-indigo-200 text-xs uppercase tracking-wider">
                                2. Family Members Status (Children Breakdown)
                              </h4>
                            </div>
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-200 text-indigo-900 dark:bg-indigo-900 dark:text-indigo-200">
                              Total: {(memberForm.maleChildrenCount || 0) + (memberForm.femaleChildrenCount || 0) + (memberForm.adoptedChildrenCount || 0)} Children
                            </span>
                          </div>

                          <p className="text-[11px] text-slate-600 dark:text-slate-400">
                            Specify count of biological and adopted children for family records, sunday school placement, and ministry tracking.
                          </p>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 space-y-1">
                              <label className="block text-[11px] font-bold text-blue-700 dark:text-blue-300">
                                Male Children
                              </label>
                              <input
                                type="number"
                                min="0"
                                value={memberForm.maleChildrenCount ?? 0}
                                onChange={(e) =>
                                  setMemberForm({
                                    ...memberForm,
                                    maleChildrenCount: parseInt(e.target.value) || 0,
                                  })
                                }
                                className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-center text-blue-700 dark:text-blue-300 text-sm"
                              />
                            </div>

                            <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 space-y-1">
                              <label className="block text-[11px] font-bold text-pink-700 dark:text-pink-300">
                                Female Children
                              </label>
                              <input
                                type="number"
                                min="0"
                                value={memberForm.femaleChildrenCount ?? 0}
                                onChange={(e) =>
                                  setMemberForm({
                                    ...memberForm,
                                    femaleChildrenCount: parseInt(e.target.value) || 0,
                                  })
                                }
                                className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-center text-pink-600 dark:text-pink-400 text-sm"
                              />
                            </div>

                            <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900/60 space-y-1">
                              <label className="block text-[11px] font-bold text-amber-700 dark:text-amber-300">
                                Adopted Children
                              </label>
                              <input
                                type="number"
                                min="0"
                                value={memberForm.adoptedChildrenCount ?? 0}
                                onChange={(e) =>
                                  setMemberForm({
                                    ...memberForm,
                                    adoptedChildrenCount: parseInt(e.target.value) || 0,
                                  })
                                }
                                className="w-full p-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-center text-amber-600 dark:text-amber-400 text-sm"
                              />
                            </div>
                          </div>

                          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-200/80 dark:border-indigo-900/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
                            <span className="font-semibold text-slate-700 dark:text-slate-300">Children Summary:</span>
                            <div className="flex flex-wrap items-center gap-1.5 font-bold text-[11px]">
                              <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 dark:bg-blue-950 dark:text-blue-200">
                                👦 {memberForm.maleChildrenCount || 0} Male
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-pink-50 text-pink-800 dark:bg-pink-950 dark:text-pink-200">
                                👧 {memberForm.femaleChildrenCount || 0} Female
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 dark:bg-amber-950 dark:text-amber-200">
                                👶 {memberForm.adoptedChildrenCount || 0} Adopted
                              </span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-slate-500 text-xs">
                          <Users className="w-6 h-6 mx-auto mb-1 text-slate-400" />
                          <p className="font-semibold">Family & Children breakdown is active for Married, Widowed, Divorced, or Separated members.</p>
                          <p className="text-[10px] mt-0.5">Currently registered as <strong>Single</strong>.</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 3: CONTACT & ADDRESS (Woreda, Kebele, House Number) */}
                  {formTab === 'contact' && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <EthiopianPhoneInput
                            label="Primary Phone Number"
                            required
                            value={memberForm.primaryPhone || ''}
                            onChange={(e) => {
                              setMemberForm({ ...memberForm, primaryPhone: e.target.value });
                              if (fieldErrors.primaryPhone) setFieldErrors((prev) => ({ ...prev, primaryPhone: '' }));
                            }}
                            placeholder="0911234567 or +251911234567"
                            helperText="Ethiopian mobile number for member identification and official SMS notifications."
                            showQuickPrefixes={true}
                          />
                          {fieldErrors.primaryPhone && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.primaryPhone}</p>
                          )}
                        </div>

                        <div>
                          <EthiopianPhoneInput
                            label="Alternative Phone (Optional)"
                            value={memberForm.altPhone || ''}
                            onChange={(e) => {
                              setMemberForm({ ...memberForm, altPhone: e.target.value });
                              if (fieldErrors.altPhone) setFieldErrors((prev) => ({ ...prev, altPhone: '' }));
                            }}
                            placeholder="0912345678 or 0712345678"
                            helperText="Secondary contact number."
                            showQuickPrefixes={false}
                          />
                          {fieldErrors.altPhone && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.altPhone}</p>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold mb-1">Email Address <span className="text-slate-400 font-normal">(Optional)</span></label>
                          <input
                            type="email"
                            placeholder="member@example.com (optional)"
                            value={memberForm.email || ''}
                            onChange={(e) => {
                              setMemberForm({ ...memberForm, email: e.target.value });
                              if (fieldErrors.email) setFieldErrors((prev) => ({ ...prev, email: '' }));
                            }}
                            className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 ${
                              fieldErrors.email ? 'border-rose-400 ring-2 ring-rose-500/20' : 'border-slate-300 dark:border-slate-700'
                            }`}
                          />
                          {fieldErrors.email && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.email}</p>
                          )}
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">Preferred Communication</label>
                          <select
                            value={memberForm.preferredCommChannel || 'SMS'}
                            onChange={(e) => setMemberForm({ ...memberForm, preferredCommChannel: e.target.value as any })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                          >
                            <option value="SMS">SMS (Text Message)</option>
                            <option value="Email">Email</option>
                            <option value="WhatsApp">WhatsApp</option>
                            <option value="Phone">Phone Call</option>
                          </select>
                        </div>
                      </div>

                      {/* Contact Address Fields: Kebele, House Number, Woreda */}
                      <div className="p-3.5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-200 dark:border-blue-900/60 space-y-3">
                        <label className="block font-bold text-blue-950 dark:text-blue-200 text-xs">
                          Residential Address Details (Ethiopia Standard)
                        </label>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div>
                            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                              Woreda (Worda) <span className="text-rose-500 font-bold">*</span>
                            </label>
                            <input
                              type="text"
                              placeholder="e.g., Woreda 03"
                              value={memberForm.woreda || ''}
                              onChange={(e) => {
                                setMemberForm({ ...memberForm, woreda: e.target.value });
                                if (fieldErrors.woreda) setFieldErrors((prev) => ({ ...prev, woreda: '' }));
                              }}
                              className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 ${
                                fieldErrors.woreda ? 'border-rose-400 ring-2 ring-rose-500/20' : 'border-slate-300 dark:border-slate-700'
                              }`}
                            />
                            {fieldErrors.woreda && (
                              <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.woreda}</p>
                            )}
                          </div>

                          <div>
                            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                              Kebele <span className="text-rose-500 font-bold">*</span>
                            </label>
                            <input
                              type="text"
                              placeholder="e.g., Kebele 05"
                              value={memberForm.kebele || ''}
                              onChange={(e) => {
                                setMemberForm({ ...memberForm, kebele: e.target.value });
                                if (fieldErrors.kebele) setFieldErrors((prev) => ({ ...prev, kebele: '' }));
                              }}
                              className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 ${
                                fieldErrors.kebele ? 'border-rose-400 ring-2 ring-rose-500/20' : 'border-slate-300 dark:border-slate-700'
                              }`}
                            />
                            {fieldErrors.kebele && (
                              <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.kebele}</p>
                            )}
                          </div>

                          <div>
                            <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                              House Number <span className="text-rose-500 font-bold">*</span>
                            </label>
                            <input
                              type="text"
                              placeholder="e.g., House No. 124"
                              value={memberForm.houseNumber || ''}
                              onChange={(e) => {
                                setMemberForm({ ...memberForm, houseNumber: e.target.value });
                                if (fieldErrors.houseNumber) setFieldErrors((prev) => ({ ...prev, houseNumber: '' }));
                              }}
                              className={`w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 ${
                                fieldErrors.houseNumber ? 'border-rose-400 ring-2 ring-rose-500/20' : 'border-slate-300 dark:border-slate-700'
                              }`}
                            />
                            {fieldErrors.houseNumber && (
                              <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.houseNumber}</p>
                            )}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div>
                            <label className="block font-semibold mb-1">Street Address</label>
                            <input
                              type="text"
                              placeholder="e.g. Bole Road, Near Mall"
                              value={memberForm.streetAddress}
                              onChange={(e) => setMemberForm({ ...memberForm, streetAddress: e.target.value })}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                          <div>
                            <label className="block font-semibold mb-1">Sub-City / City</label>
                            <input
                              type="text"
                              placeholder="e.g. Bole, Addis Ababa"
                              value={memberForm.city}
                              onChange={(e) => setMemberForm({ ...memberForm, city: e.target.value })}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                          <div>
                            <label className="block font-semibold mb-1">Region / State</label>
                            <input
                              type="text"
                              value={memberForm.region}
                              onChange={(e) => setMemberForm({ ...memberForm, region: e.target.value })}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 3: SPIRITUAL, BAPTISM, MEMBERSHIP & MINISTRY */}
                  {formTab === 'spiritual' && (
                    <div className="space-y-4">
                      {/* Membership Details (Date & Location) */}
                      <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                        <label className="block font-bold text-slate-900 dark:text-white text-xs">
                          Membership Details
                        </label>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div>
                            <label className="block font-semibold mb-1">Assigned Campus Branch</label>
                            <select
                              value={memberForm.branchId}
                              onChange={(e) => handleBranchChange(e.target.value)}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            >
                              {branches.map((b) => (
                                <option key={b.id} value={b.id}>
                                  {b.name}
                                </option>
                              ))}
                            </select>
                          </div>

                          <EthiopianDateHelper
                            label="Membership Date"
                            value={memberForm.membershipDate}
                            onChange={(val) => setMemberForm({ ...memberForm, membershipDate: val })}
                          />

                          <div>
                            <label className="block font-semibold mb-1">Membership Received Location / Church</label>
                            <input
                              type="text"
                              placeholder="e.g. Grace Cathedral Main Church"
                              value={memberForm.membershipLocation || ''}
                              onChange={(e) => setMemberForm({ ...memberForm, membershipLocation: e.target.value })}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Salvation Details (Where saved & Date) */}
                      <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/60 space-y-3">
                        <label className="block font-bold text-amber-950 dark:text-amber-200 text-xs">
                          Salvation Details
                        </label>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <EthiopianDateHelper
                            label="Salvation Date"
                            value={memberForm.salvationDate}
                            onChange={(val) => setMemberForm({ ...memberForm, salvationDate: val })}
                          />

                          <div>
                            <label className="block font-semibold mb-1">Where Saved (Church / City / Location)</label>
                            <input
                              type="text"
                              placeholder="e.g. Full Gospel Church, Addis Ababa"
                              value={memberForm.salvationLocation || ''}
                              onChange={(e) => setMemberForm({ ...memberForm, salvationLocation: e.target.value })}
                              className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Water Baptism Details (Church & Date) */}
                      <div className="p-3.5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-200 dark:border-blue-900/60 space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="block font-bold text-blue-950 dark:text-blue-200 text-xs">
                            Water Baptism Status & Details
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer font-bold">
                            <input
                              type="checkbox"
                              checked={memberForm.isWaterBaptized}
                              onChange={(e) => setMemberForm({ ...memberForm, isWaterBaptized: e.target.checked })}
                              className="w-4 h-4 text-blue-600 rounded"
                            />
                            <span>Is Water Baptized?</span>
                          </label>
                        </div>

                        {memberForm.isWaterBaptized && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                            <EthiopianDateHelper
                              label="Baptism Date"
                              value={memberForm.waterBaptismDate}
                              onChange={(val) => setMemberForm({ ...memberForm, waterBaptismDate: val })}
                            />

                            <div>
                              <label className="block font-semibold mb-1">Where Baptized (Church / Lake / Location)</label>
                              <input
                                type="text"
                                placeholder="e.g. Grace Cathedral Church / Lake Bishoftu"
                                value={memberForm.waterBaptismLocation || ''}
                                onChange={(e) => setMemberForm({ ...memberForm, waterBaptismLocation: e.target.value })}
                                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                        <label className="block font-bold text-slate-900 dark:text-white text-xs">
                          Membership Status & Active Record Status
                        </label>
                        <div>
                          <label className="block font-semibold mb-1">Membership Status</label>
                          <select
                            value={memberForm.membershipStatus || 'Active'}
                            onChange={(e) => {
                              const newStatus = e.target.value as MembershipStatus;
                              setMemberForm({
                                ...memberForm,
                                membershipStatus: newStatus,
                                departureReason: newStatus !== 'Active' ? (newStatus as any) : undefined,
                              });
                            }}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold"
                          >
                            <option value="Active">🟢 Active Member</option>
                            <option value="Inactive">⏸️ Inactive Status</option>
                            <option value="Transferred">🔄 Transferred to Another Church</option>
                            <option value="On Leave">🏖️ On Leave</option>
                            <option value="Left Church">🚪 Left Church</option>
                            <option value="Excommunicated">⛔ Excommunicated</option>
                            <option value="Deceased">✝️ Deceased (Passed Away)</option>
                          </select>
                        </div>

                        {memberForm.membershipStatus && memberForm.membershipStatus !== 'Active' && (
                          <div className="p-3 bg-amber-50/80 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 space-y-3 pt-2">
                            <div className="flex items-center gap-1.5 text-amber-900 dark:text-amber-200 font-bold text-xs">
                              <Calendar className="w-4 h-4 text-amber-600" />
                              <span>Non-Active Status Details ({memberForm.membershipStatus})</span>
                            </div>
                            <div className={memberForm.membershipStatus === 'Excommunicated' ? "grid grid-cols-1 sm:grid-cols-2 gap-3" : "grid grid-cols-1 gap-3"}>
                              <EthiopianDateHelper
                                label={memberForm.membershipStatus === 'Excommunicated' ? "Excommunication Start Date *" : "Status / Departure Date *"}
                                value={memberForm.departureDate || memberForm.statusStartDate || new Date().toISOString().split('T')[0]}
                                onChange={(val) =>
                                  setMemberForm({
                                    ...memberForm,
                                    departureDate: val,
                                    statusStartDate: val,
                                    departureReason: (memberForm.membershipStatus as any) || 'Inactive',
                                  })
                                }
                              />

                              {memberForm.membershipStatus === 'Excommunicated' && (
                                <EthiopianDateHelper
                                  label="Excommunication End Date (Optional)"
                                  value={memberForm.departureEndDate || memberForm.statusEndDate || ''}
                                  onChange={(val) =>
                                    setMemberForm({
                                      ...memberForm,
                                      departureEndDate: val,
                                      statusEndDate: val,
                                    })
                                  }
                                />
                              )}
                            </div>

                            {memberForm.membershipStatus === 'Excommunicated' && (
                              <div className="space-y-3 pt-2 border-t border-purple-200 dark:border-purple-800/60">
                                <div>
                                  <label className="block text-xs font-bold text-purple-950 dark:text-purple-200 mb-1 flex items-center gap-1">
                                    <FileText className="w-3.5 h-3.5 text-purple-600" />
                                    Excommunication Description & Official Decree
                                  </label>
                                  <textarea
                                    rows={3}
                                    value={memberForm.excommunicationDescription || ''}
                                    onChange={(e) => setMemberForm({ ...memberForm, excommunicationDescription: e.target.value })}
                                    placeholder="Enter official reason, description, or decree for excommunication..."
                                    className="w-full px-3 py-2 text-xs rounded-xl border border-purple-200 dark:border-purple-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500"
                                  />
                                </div>

                                <div>
                                  <label className="block text-xs font-bold text-purple-950 dark:text-purple-200 mb-1 flex items-center gap-1">
                                    <Paperclip className="w-3.5 h-3.5 text-purple-600" />
                                    Paper of Excommunication (Import Document / Letter)
                                  </label>
                                  {memberForm.excommunicationPaperUrl ? (
                                    <div className="flex items-center justify-between p-2.5 bg-purple-100/70 dark:bg-purple-950/80 rounded-xl border border-purple-300 dark:border-purple-700 text-xs">
                                      <div className="flex items-center gap-2 min-w-0">
                                        <FileText className="w-4 h-4 text-purple-700 shrink-0" />
                                        <span className="font-bold text-purple-900 dark:text-purple-200 truncate">
                                          {memberForm.excommunicationPaperName || 'Excommunication_Paper.pdf'}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2 shrink-0">
                                        <button
                                          type="button"
                                          onClick={() => setPaperPreviewModal({
                                            isOpen: true,
                                            title: 'Paper of Excommunication',
                                            url: memberForm.excommunicationPaperUrl || '',
                                            fileName: memberForm.excommunicationPaperName || 'Excommunication Paper'
                                          })}
                                          className="px-2.5 py-1 bg-purple-700 text-white rounded-lg font-bold text-[11px] hover:bg-purple-800 flex items-center gap-1"
                                        >
                                          <Eye className="w-3 h-3" /> View
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => setMemberForm({ ...memberForm, excommunicationPaperUrl: '', excommunicationPaperName: '' })}
                                          className="p-1 text-rose-600 hover:text-rose-800 dark:text-rose-400"
                                          title="Remove document"
                                        >
                                          <X className="w-4 h-4" />
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <label className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-purple-300 dark:border-purple-700 rounded-xl cursor-pointer hover:bg-purple-50/50 dark:hover:bg-purple-950/30 transition-colors text-xs font-bold text-purple-800 dark:text-purple-300">
                                      <Upload className="w-4 h-4 text-purple-600" />
                                      <span>Import / Upload Paper of Excommunication (PDF, Image, Scan)</span>
                                      <input
                                        type="file"
                                        accept="image/*,.pdf,.doc,.docx"
                                        className="hidden"
                                        onChange={(e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            const reader = new FileReader();
                                            reader.onload = (evt) => {
                                              setMemberForm({
                                                ...memberForm,
                                                excommunicationPaperUrl: evt.target?.result as string,
                                                excommunicationPaperName: file.name,
                                              });
                                            };
                                            reader.readAsDataURL(file);
                                          }
                                        }}
                                      />
                                    </label>
                                  )}
                                </div>
                              </div>
                            )}
                            <p className="text-[11px] text-amber-800 dark:text-amber-300 italic">
                              Note: Members with non-active statuses will automatically be archived under the <strong>Past and Death Record</strong> tab.
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Ministry Selection & Service Section */}
                      <div className="p-3.5 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-2xl border border-indigo-200 dark:border-indigo-900/60 space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="block font-bold text-indigo-950 dark:text-indigo-200 text-xs flex items-center gap-1.5">
                            <Layers className="w-4 h-4 text-indigo-600" />
                            <span>Ministry Involvement & Assignments</span>
                          </label>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-300">
                            {(memberForm.ministryIds || []).length} Ministries Assigned
                          </span>
                        </div>

                        {/* Current Ministry Status */}
                        <div>
                          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                            Current Ministry Status
                          </label>
                          <select
                            value={memberForm.currentMinistryStatus || 'Active Serving Member'}
                            onChange={(e) => setMemberForm({ ...memberForm, currentMinistryStatus: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                          >
                            <option value="Active Serving Member">Active Serving Member</option>
                            <option value="Serving (Leadership)">Serving (Leadership / Department Head)</option>
                            <option value="In Training">In Ministry Training / Probation</option>
                            <option value="On Sabbatical">On Sabbatical / Temporary Leave</option>
                            <option value="Retired from Ministry">Retired from Ministry</option>
                          </select>
                        </div>

                        {/* Selected Ministry Chips */}
                        <div>
                          <label className="block font-semibold mb-1.5 text-slate-700 dark:text-slate-300 flex items-center justify-between">
                            <span>Assigned Ministries (Current)</span>
                            <span className="text-[11px] text-slate-500 font-normal">Click &times; to remove</span>
                          </label>
                          <div className="flex flex-wrap gap-1.5 min-h-[38px] p-2 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700">
                            {(memberForm.ministryIds || []).length === 0 ? (
                              <span className="text-slate-400 italic text-[11px] self-center">No ministries assigned yet. Select from the catalog below.</span>
                            ) : (
                              (memberForm.ministryIds || []).map((id) => {
                                const m = (ministries || []).find((item) => item.id === id);
                                return (
                                  <span
                                    key={id}
                                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-100 text-indigo-900 dark:bg-indigo-900/60 dark:text-indigo-200 border border-indigo-200 dark:border-indigo-800 animate-in fade-in"
                                  >
                                    <Tag className="w-3 h-3 text-indigo-600 dark:text-indigo-400 shrink-0" />
                                    <span>{m ? m.name : id}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleRemoveMinistry(id)}
                                      className="hover:text-rose-600 dark:hover:text-rose-400 p-0.5 rounded cursor-pointer transition-colors"
                                      title="Remove ministry assignment"
                                    >
                                      <X className="w-3.5 h-3.5" />
                                    </button>
                                  </span>
                                );
                              })
                            )}
                          </div>
                        </div>

                        {/* Searchable Ministry Multi-Select Catalog */}
                        <div className="space-y-2 pt-1">
                          <div className="relative">
                            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                            <input
                              type="text"
                              value={ministrySearch}
                              onChange={(e) => setMinistrySearch(e.target.value)}
                              placeholder="Search eligible ministries by name, department, or keywords..."
                              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                            />
                            {ministrySearch && (
                              <button
                                type="button"
                                onClick={() => setMinistrySearch('')}
                                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs font-bold"
                              >
                                Clear
                              </button>
                            )}
                          </div>

                          {/* List / Cards of Eligible Ministries */}
                          <div className="max-h-48 overflow-y-auto space-y-1.5 p-1 rounded-xl bg-slate-50/70 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800">
                            {filteredMinistries.length === 0 ? (
                              <div className="p-3 text-center text-slate-400 text-xs italic">
                                {eligibleMinistries.length === 0
                                  ? 'No ministries found for the selected campus branch.'
                                  : 'No ministries match your search query.'}
                              </div>
                            ) : (
                              filteredMinistries.map((m) => {
                                const isSelected = (memberForm.ministryIds || []).includes(m.id);
                                return (
                                  <div
                                    key={m.id}
                                    onClick={() => handleToggleMinistry(m.id)}
                                    className={`flex items-center justify-between p-2 rounded-xl text-xs cursor-pointer transition-all border ${
                                      isSelected
                                        ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-300 dark:border-indigo-700 text-indigo-950 dark:text-indigo-100 shadow-xs'
                                        : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2 min-w-0">
                                      <div
                                        className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                                          isSelected
                                            ? 'bg-indigo-600 border-indigo-600 text-white'
                                            : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700'
                                        }`}
                                      >
                                        {isSelected && <Check className="w-3 h-3 stroke-3" />}
                                      </div>
                                      <div className="min-w-0">
                                        <p className="font-bold truncate">{m.name}</p>
                                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                                          {m.category && <span className="truncate">{m.category}</span>}
                                          {m.leaderName && <span>• Leader: {m.leaderName}</span>}
                                        </div>
                                      </div>
                                    </div>
                                    {m.memberCount !== undefined && (
                                      <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400 shrink-0 font-medium">
                                        {m.memberCount} members
                                      </span>
                                    )}
                                  </div>
                                );
                              })
                            )}
                          </div>
                        </div>

                        {/* Past Ministries Served (Optional Multi-Select) */}
                        <div className="pt-2 border-t border-indigo-200 dark:border-indigo-900/60 space-y-2">
                          <label className="block font-semibold text-slate-700 dark:text-slate-300 text-xs flex items-center justify-between">
                            <span>Past Ministries Served Before (Optional)</span>
                            <span className="text-[10px] text-slate-400 font-normal">Track historical service</span>
                          </label>

                          <div className="flex flex-wrap gap-1.5 min-h-[34px] p-2 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700">
                            {(memberForm.ministriesServedBefore || []).length === 0 ? (
                              <span className="text-slate-400 italic text-[11px] self-center">No previous ministries recorded.</span>
                            ) : (
                              (memberForm.ministriesServedBefore || []).map((past) => {
                                const m = (ministries || []).find((item) => item.id === past || item.name === past);
                                const displayName = m ? m.name : past;
                                return (
                                  <span
                                    key={past}
                                    className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg text-xs font-semibold bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border border-amber-200 dark:border-amber-800"
                                  >
                                    <span>{displayName}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleTogglePastMinistry(past)}
                                      className="hover:text-rose-600 dark:hover:text-rose-400 p-0.5 rounded cursor-pointer"
                                      title="Remove past ministry"
                                    >
                                      <X className="w-3 h-3" />
                                    </button>
                                  </span>
                                );
                              })
                            )}
                          </div>

                          {/* Quick selection chips for past ministries */}
                          <div className="flex flex-wrap gap-1 pt-0.5">
                            {(ministries || []).slice(0, 8).map((m) => {
                              const isPast = (memberForm.ministriesServedBefore || []).includes(m.id);
                              return (
                                <button
                                  type="button"
                                  key={m.id}
                                  onClick={() => handleTogglePastMinistry(m.id)}
                                  className={`px-2 py-0.5 rounded-md text-[10px] font-medium transition-colors cursor-pointer border ${
                                    isPast
                                      ? 'bg-amber-200 dark:bg-amber-900 text-amber-950 dark:text-amber-100 border-amber-300 dark:border-amber-700'
                                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
                                  }`}
                                >
                                  {isPast ? '✓ ' : '+ '}{m.name}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 4: EDUCATION & WORK */}
                  {formTab === 'professional' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold mb-1">Education Level</label>
                          <select
                            value={memberForm.educationLevel}
                            onChange={(e) => setMemberForm({ ...memberForm, educationLevel: e.target.value as any })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          >
                            <option value="No Formal Education">No Formal Education</option>
                            <option value="Primary">Primary</option>
                            <option value="Secondary">Secondary</option>
                            <option value="Diploma">Diploma</option>
                            <option value="Bachelor">Bachelor Degree</option>
                            <option value="Master">Master Degree</option>
                            <option value="Doctorate">Doctorate</option>
                          </select>
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">Field of Study</label>
                          <input
                            type="text"
                            value={memberForm.fieldOfStudy}
                            onChange={(e) => setMemberForm({ ...memberForm, fieldOfStudy: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block font-semibold mb-1">Occupation / Profession</label>
                          <input
                            type="text"
                            value={memberForm.occupation}
                            onChange={(e) => setMemberForm({ ...memberForm, occupation: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">Employer / Organization</label>
                          <input
                            type="text"
                            value={memberForm.employerName}
                            onChange={(e) => setMemberForm({ ...memberForm, employerName: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">Employer Type</label>
                          <select
                            value={memberForm.employerType || 'Individual'}
                            onChange={(e) => setMemberForm({ ...memberForm, employerType: e.target.value as any })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          >
                            <option value="Individual">Individual</option>
                            <option value="Private">Private</option>
                            <option value="Government">Government</option>
                            <option value="NGO (Non-Profit)">NGO (Non-Profit)</option>
                            <option value="Other">Other</option>
                          </select>
                        </div>
                      </div>

                      {memberForm.employerType === 'Other' && (
                        <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 animate-in fade-in">
                          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                            Specify Other Employer Type *
                          </label>
                          <input
                            type="text"
                            placeholder="e.g., Freelance / Cooperative / Self-Employed / Missionary Organization"
                            value={memberForm.employerTypeOther || ''}
                            onChange={(e) => setMemberForm({ ...memberForm, employerTypeOther: e.target.value })}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 5: HEALTH & EMERGENCY */}
                  {formTab === 'health' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block font-semibold mb-1">Emergency Contact Name</label>
                          <input
                            type="text"
                            value={memberForm.emergencyContact?.name}
                            onChange={(e) =>
                              setMemberForm({
                                ...memberForm,
                                emergencyContact: {
                                  ...memberForm.emergencyContact!,
                                  name: e.target.value,
                                },
                              })
                            }
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold mb-1">Relationship</label>
                          <input
                            type="text"
                            value={memberForm.emergencyContact?.relationship}
                            onChange={(e) =>
                              setMemberForm({
                                ...memberForm,
                                emergencyContact: {
                                  ...memberForm.emergencyContact!,
                                  relationship: e.target.value,
                                },
                              })
                            }
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                        <div>
                          <EthiopianPhoneInput
                            label="Emergency Phone"
                            value={memberForm.emergencyContact?.phone || ''}
                            onChange={(e) =>
                              setMemberForm({
                                ...memberForm,
                                emergencyContact: {
                                  ...memberForm.emergencyContact!,
                                  phone: e.target.value,
                                },
                              })
                            }
                            placeholder="0911223344 or +251911223344"
                            showQuickPrefixes={false}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-semibold mb-1">Blood Type</label>
                        <select
                          value={memberForm.bloodType}
                          onChange={(e) => setMemberForm({ ...memberForm, bloodType: e.target.value as any })}
                          className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        >
                          <option value="A+">A+</option>
                          <option value="A-">A-</option>
                          <option value="B+">B+</option>
                          <option value="B-">B-</option>
                          <option value="O+">O+</option>
                          <option value="O-">O-</option>
                          <option value="AB+">AB+</option>
                          <option value="AB-">AB-</option>
                        </select>
                      </div>

                      {/* Optional Health Information (Allergies & Medical Conditions) */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                            Known Allergies <span className="text-slate-400 font-normal">(Optional)</span>
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Penicillin, Peanuts (comma-separated, optional)"
                            value={(memberForm.knownAllergies || []).join(', ')}
                            onChange={(e) => {
                              const allergies = e.target.value.split(',').map((s) => s.trim()).filter(Boolean);
                              setMemberForm({ ...memberForm, knownAllergies: allergies });
                            }}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                            Medical Conditions <span className="text-slate-400 font-normal">(Optional)</span>
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Asthma, Hypertension (comma-separated, optional)"
                            value={(memberForm.medicalConditions || []).join(', ')}
                            onChange={(e) => {
                              const conditions = e.target.value.split(',').map((s) => s.trim()).filter(Boolean);
                              setMemberForm({ ...memberForm, medicalConditions: conditions });
                            }}
                            className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                          />
                        </div>
                      </div>

                      {/* Optional Account Provisioning Section (New Registration Only) */}
                      {!isEditModalOpen && (
                        <div className="mt-4 p-4 rounded-2xl border transition-all duration-200 bg-slate-50/90 dark:bg-slate-800/50 border-purple-200 dark:border-purple-900/60 shadow-xs">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-2.5">
                              <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 mt-0.5 shrink-0">
                                <Key className="w-4 h-4" />
                              </div>
                              <div>
                                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                                  <span>Portal Login Account Provisioning</span>
                                  <span className="text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-900/50 text-purple-800 dark:text-purple-200">
                                    Optional
                                  </span>
                                </h4>
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                                  Create system portal credentials so this member can log in to view their profile, attendance, and member services.
                                </p>
                              </div>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                              <input
                                type="checkbox"
                                checked={provisionAccount}
                                onChange={(e) => setProvisionAccount(e.target.checked)}
                                className="sr-only peer"
                              />
                              <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                            </label>
                          </div>

                          {provisionAccount && (
                            <div className="mt-4 pt-4 border-t border-purple-200/80 dark:border-purple-800/60 space-y-3.5 animate-in fade-in">
                              {/* Identifier Selection: Email vs Phone */}
                              <div>
                                <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5">
                                  Portal Username / Login Identifier <span className="text-rose-500">*</span>
                                </label>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                  <button
                                    type="button"
                                    onClick={() => setAccountIdentifierType('email')}
                                    className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all cursor-pointer ${
                                      accountIdentifierType === 'email'
                                        ? 'bg-purple-50 dark:bg-purple-950/60 border-purple-500 text-purple-950 dark:text-purple-100 font-bold ring-1 ring-purple-500'
                                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                                    }`}
                                  >
                                    <Mail className="w-4 h-4 mt-0.5 shrink-0 text-purple-600" />
                                    <div className="min-w-0">
                                      <div className="text-xs font-bold">Use Email Address</div>
                                      <div className="text-[11px] truncate opacity-80">
                                        {memberForm.email?.trim() || '(No email entered in Section 3)'}
                                      </div>
                                    </div>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => setAccountIdentifierType('phone')}
                                    className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all cursor-pointer ${
                                      accountIdentifierType === 'phone'
                                        ? 'bg-purple-50 dark:bg-purple-950/60 border-purple-500 text-purple-950 dark:text-purple-100 font-bold ring-1 ring-purple-500'
                                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                                    }`}
                                  >
                                    <Phone className="w-4 h-4 mt-0.5 shrink-0 text-purple-600" />
                                    <div className="min-w-0">
                                      <div className="text-xs font-bold">Use Phone Number</div>
                                      <div className="text-[11px] truncate opacity-80">
                                        {memberForm.primaryPhone?.trim() || '(No phone entered in Section 3)'}
                                      </div>
                                    </div>
                                  </button>
                                </div>
                                {fieldErrors.accountIdentifier && (
                                  <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold flex items-center gap-1">
                                    <AlertTriangle className="w-3.5 h-3.5" />
                                    {fieldErrors.accountIdentifier}
                                  </p>
                                )}
                              </div>

                              {/* System Role Selection */}
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                                    Assigned System Role
                                  </label>
                                  <select
                                    value={accountRole}
                                    onChange={(e) => setAccountRole(e.target.value as UserRole)}
                                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-xs"
                                  >
                                    <option value="REGULAR_MEMBER">👤 Regular Member</option>
                                    <option value="VOLUNTEER">🤝 Ministry Volunteer</option>
                                    <option value="MINISTRY_LEADER">👥 Ministry Department Leader</option>
                                    <option value="BRANCH_PASTOR">⛪ Campus / Branch Pastor</option>
                                    <option value="FINANCE_OFFICER">💳 Finance Officer</option>
                                    <option value="BRANCH_ADMIN">⚙️ Branch Administrator</option>
                                  </select>
                                </div>

                                {/* Temporary Password Input & Generator */}
                                <div>
                                  <div className="flex items-center justify-between mb-1">
                                    <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                                      Temporary Password <span className="text-rose-500">*</span>
                                    </label>
                                    <button
                                      type="button"
                                      onClick={handleGenerateTempPassword}
                                      className="text-[11px] font-bold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1 cursor-pointer"
                                    >
                                      <Sparkles className="w-3 h-3" />
                                      Generate Random
                                    </button>
                                  </div>
                                  <div className="relative">
                                    <input
                                      type={showAccountPassword ? 'text' : 'password'}
                                      value={accountTempPassword}
                                      onChange={(e) => {
                                        setAccountTempPassword(e.target.value);
                                        if (fieldErrors.accountPassword) setFieldErrors((prev) => ({ ...prev, accountPassword: '' }));
                                      }}
                                      className={`w-full pl-3 pr-16 py-2 text-xs font-mono rounded-xl border bg-white dark:bg-slate-800 ${
                                        fieldErrors.accountPassword
                                          ? 'border-rose-400 ring-2 ring-rose-500/20'
                                          : 'border-slate-300 dark:border-slate-700'
                                      }`}
                                      placeholder="Minimum 8 characters"
                                    />
                                    <div className="absolute right-1 top-1 flex items-center">
                                      <button
                                        type="button"
                                        onClick={() => setShowAccountPassword(!showAccountPassword)}
                                        className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                                        title={showAccountPassword ? 'Hide password' : 'Show password'}
                                      >
                                        {showAccountPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          navigator.clipboard.writeText(accountTempPassword);
                                          setCredentialCopied(true);
                                          setTimeout(() => setCredentialCopied(false), 2000);
                                        }}
                                        className="p-1.5 text-purple-600 hover:text-purple-700 dark:text-purple-400 cursor-pointer"
                                        title="Copy temporary password"
                                      >
                                        {credentialCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                                      </button>
                                    </div>
                                  </div>
                                  {fieldErrors.accountPassword && (
                                    <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1 font-semibold">{fieldErrors.accountPassword}</p>
                                  )}
                                </div>
                              </div>

                              {/* Mandatory First-Login Password Change Checkbox */}
                              <div className="p-3 bg-purple-50/70 dark:bg-purple-950/40 rounded-xl border border-purple-200/70 dark:border-purple-900/60">
                                <label className="flex items-start gap-2.5 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={accountMustChangePassword}
                                    onChange={(e) => setAccountMustChangePassword(e.target.checked)}
                                    className="w-4 h-4 mt-0.5 text-purple-600 rounded"
                                  />
                                  <div className="text-xs">
                                    <span className="font-bold text-purple-950 dark:text-purple-200">
                                      Require password change upon first login (Mandatory Security Policy)
                                    </span>
                                    <p className="text-[11px] text-purple-800/80 dark:text-purple-300/80 mt-0.5">
                                      When enabled, the user will be forced to choose their own confidential password as soon as they log into the CMMS portal.
                                    </p>
                                  </div>
                                </label>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
                    <div className="flex gap-2">
                      {formTab !== 'personal' && (
                        <button
                          type="button"
                          onClick={() => {
                            if (formTab === 'marital') setFormTab('personal');
                            if (formTab === 'contact') setFormTab('marital');
                            if (formTab === 'spiritual') setFormTab('contact');
                            if (formTab === 'professional') setFormTab('spiritual');
                            if (formTab === 'health') setFormTab('professional');
                          }}
                          className="px-3 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-xl font-semibold"
                        >
                          &larr; Back
                        </button>
                      )}
                      {formTab !== 'health' && (
                        <button
                          type="button"
                          onClick={() => {
                            if (formTab === 'personal') setFormTab('marital');
                            if (formTab === 'marital') setFormTab('contact');
                            if (formTab === 'contact') setFormTab('spiritual');
                            if (formTab === 'spiritual') setFormTab('professional');
                            if (formTab === 'professional') setFormTab('health');
                          }}
                          className="px-3 py-1.5 bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 rounded-xl font-semibold"
                        >
                          Next Section &rarr;
                        </button>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddModalOpen(false);
                          setIsEditModalOpen(false);
                        }}
                        className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-md flex items-center gap-1.5"
                      >
                        <Save className="w-4 h-4" />
                        {isEditModalOpen ? 'Save Updated Member Details' : 'Save Member'}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* CREDENTIAL SUMMARY MODAL (Rendered after Account Provisioning) */}
          {createdAccountSummary && createdAccountSummary.isOpen && (
            <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in fade-in">
              <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-lg border border-slate-200 dark:border-slate-800 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-slate-900 dark:text-white">
                        Portal Account Provisioned
                      </h3>
                      <p className="text-xs text-slate-500">
                        New member account created successfully
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setCreatedAccountSummary(null)}
                    className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Member Name:</span>
                      <span className="font-bold text-slate-900 dark:text-white">{createdAccountSummary.memberName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Member ID:</span>
                      <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{createdAccountSummary.memberIdNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Assigned Role:</span>
                      <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 font-bold text-[11px]">
                        {createdAccountSummary.role}
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 bg-blue-50/70 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-blue-950 dark:text-blue-200">Username / Login ID:</span>
                      <span className="font-mono font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800">
                        {createdAccountSummary.username}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-blue-950 dark:text-blue-200">Temporary Password:</span>
                      <span className="font-mono font-bold text-rose-600 dark:text-rose-400 bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 tracking-wider">
                        {createdAccountSummary.tempPassword}
                      </span>
                    </div>
                  </div>

                  {createdAccountSummary.mustChangePassword && (
                    <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 flex items-start gap-2 text-amber-800 dark:text-amber-200 text-[11px]">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <span>
                        <strong>Mandatory Action:</strong> The user is required to reset this temporary password immediately on their first login.
                      </span>
                    </div>
                  )}
                </div>

                <div className="pt-2 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const text = `Grace Cathedral CMMS Member Portal Credentials\nName: ${createdAccountSummary.memberName}\nMember ID: ${createdAccountSummary.memberIdNumber}\nRole: ${createdAccountSummary.role}\nUsername: ${createdAccountSummary.username}\nTemporary Password: ${createdAccountSummary.tempPassword}\nNote: You must change your password on first login.`;
                      navigator.clipboard.writeText(text);
                      setCredentialCopied(true);
                      setTimeout(() => setCredentialCopied(false), 2000);
                    }}
                    className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-xs"
                  >
                    {credentialCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    <span>{credentialCopied ? 'Credentials Copied!' : 'Copy All Credentials'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCreatedAccountSummary(null)}
                    className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-colors cursor-pointer text-xs text-center"
                  >
                    Done & Return
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Record Departure / Death Modal */}
          {isRecordDepartureModalOpen && departureTargetMember && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
              <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <UserX className="w-5 h-5 text-rose-600" />
                    <h3 className="font-bold text-base text-slate-900 dark:text-white">Record Departure or Passing</h3>
                  </div>
                  <button
                    onClick={() => {
                      setIsRecordDepartureModalOpen(false);
                      setDepartureTargetMember(null);
                    }}
                    className="text-slate-400 hover:text-slate-600 p-1"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                  <img
                    src={departureTargetMember.photoUrl || (departureTargetMember.gender === 'Female' ? DEFAULT_FEMALE_AVATAR : DEFAULT_MALE_AVATAR)}
                    alt=""
                    className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-300"
                  />
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                      {departureTargetMember.title} {departureTargetMember.firstName} {departureTargetMember.lastName}
                    </h4>
                    <p className="text-xs text-slate-500">ID: {departureTargetMember.memberIdNumber} • {departureTargetMember.primaryPhone}</p>
                  </div>
                </div>

                <form onSubmit={handleSaveDeparture} className="space-y-3 text-xs">
                  <div>
                    <label className="block font-bold mb-1 text-slate-900 dark:text-white">Reason for Departure / Status Change *</label>
                    <select
                      value={departureForm.reason}
                      onChange={(e) => setDepartureForm({ ...departureForm, reason: e.target.value as any })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
                    >
                      <option value="Deceased">✝️ Deceased (Passed Away)</option>
                      <option value="Transferred">🔄 Transferred to Another Church</option>
                      <option value="Inactive">⏸️ Inactive Status</option>
                      <option value="On Leave">🏖️ On Leave</option>
                      <option value="Excommunicated">⛔ Excommunicated</option>
                      <option value="Left Church">🚪 Left Church</option>
                      <option value="Moved Away">✈️ Relocated / Moved Away</option>
                      <option value="Resigned">📋 Resigned Membership</option>
                    </select>
                  </div>

                  <EthiopianDateHelper
                    label={departureForm.reason === 'Excommunicated' ? "Excommunication Start Date *" : "Status / Departure / Passing Date *"}
                    value={departureForm.date}
                    onChange={(val) => setDepartureForm({ ...departureForm, date: val })}
                  />

                  {departureForm.reason === 'Excommunicated' && (
                    <>
                      <EthiopianDateHelper
                        label="Excommunication End Date (Optional)"
                        value={departureForm.endDate}
                        onChange={(val) => setDepartureForm({ ...departureForm, endDate: val })}
                      />

                      <div className="space-y-3 pt-2 border-t border-purple-200 dark:border-purple-800/60">
                        <div>
                          <label className="block text-xs font-bold text-purple-950 dark:text-purple-200 mb-1 flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-purple-600" />
                            Excommunication Description & Official Decree
                          </label>
                          <textarea
                            rows={3}
                            value={departureForm.excommunicationDescription || ''}
                            onChange={(e) => setDepartureForm({ ...departureForm, excommunicationDescription: e.target.value })}
                            placeholder="Enter official reason, description, or decree for excommunication..."
                            className="w-full px-3 py-2 text-xs rounded-xl border border-purple-200 dark:border-purple-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-purple-950 dark:text-purple-200 mb-1 flex items-center gap-1">
                            <Paperclip className="w-3.5 h-3.5 text-purple-600" />
                            Paper of Excommunication (Import Document / Letter)
                          </label>
                          {departureForm.excommunicationPaperUrl ? (
                            <div className="flex items-center justify-between p-2.5 bg-purple-100/70 dark:bg-purple-950/80 rounded-xl border border-purple-300 dark:border-purple-700 text-xs">
                              <div className="flex items-center gap-2 min-w-0">
                                <FileText className="w-4 h-4 text-purple-700 shrink-0" />
                                <span className="font-bold text-purple-900 dark:text-purple-200 truncate">
                                  {departureForm.excommunicationPaperName || 'Excommunication_Paper.pdf'}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => setPaperPreviewModal({
                                    isOpen: true,
                                    title: 'Paper of Excommunication',
                                    url: departureForm.excommunicationPaperUrl || '',
                                    fileName: departureForm.excommunicationPaperName || 'Excommunication Paper'
                                  })}
                                  className="px-2.5 py-1 bg-purple-700 text-white rounded-lg font-bold text-[11px] hover:bg-purple-800 flex items-center gap-1"
                                >
                                  <Eye className="w-3 h-3" /> View
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDepartureForm({ ...departureForm, excommunicationPaperUrl: '', excommunicationPaperName: '' })}
                                  className="p-1 text-rose-600 hover:text-rose-800 dark:text-rose-400"
                                  title="Remove document"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          ) : (
                            <label className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-purple-300 dark:border-purple-700 rounded-xl cursor-pointer hover:bg-purple-50/50 dark:hover:bg-purple-950/30 transition-colors text-xs font-bold text-purple-800 dark:text-purple-300">
                              <Upload className="w-4 h-4 text-purple-600" />
                              <span>Import / Upload Paper of Excommunication (PDF, Image, Scan)</span>
                              <input
                                type="file"
                                accept="image/*,.pdf,.doc,.docx"
                                className="hidden"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const reader = new FileReader();
                                    reader.onload = (evt) => {
                                      setDepartureForm({
                                        ...departureForm,
                                        excommunicationPaperUrl: evt.target?.result as string,
                                        excommunicationPaperName: file.name,
                                      });
                                    };
                                    reader.readAsDataURL(file);
                                  }
                                }}
                              />
                            </label>
                          )}
                        </div>
                      </div>
                    </>
                  )}

                  <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => {
                        setIsRecordDepartureModalOpen(false);
                        setDepartureTargetMember(null);
                      }}
                      className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-md transition-all"
                    >
                      Save Status Record
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Member Full Detail Modal */}
          {selectedMember && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
              <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col border border-slate-200 dark:border-slate-800 my-8">
                {/* Modal Header */}
                <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between bg-slate-50 dark:bg-slate-800/50">
                  <div className="flex items-center gap-4">
                    <img
                      src={selectedMember.photoUrl}
                      alt={selectedMember.firstName}
                      className="w-16 h-16 rounded-2xl object-cover ring-2 ring-blue-500 shadow-md"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                          {selectedMember.title} {selectedMember.firstName} {selectedMember.middleName} {selectedMember.lastName}
                        </h2>
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                          {selectedMember.memberIdNumber}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Status: <strong>{selectedMember.membershipStatus}</strong> • Age {selectedMember.age} • {selectedMember.maritalStatus || 'Single'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {permissions.canEditMembers && (
                      <button
                        onClick={() => {
                          const m = selectedMember;
                          setSelectedMember(null);
                          handleOpenEditModal(m);
                        }}
                        className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-bold text-xs flex items-center gap-1 shadow-md"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Edit Details
                      </button>
                    )}
                    <button
                      onClick={() => setSelectedMember(null)}
                      className="p-2 text-slate-400 hover:text-slate-600 rounded-lg"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                </div>

                {/* Sub-tabs nav */}
                <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 gap-6 bg-white dark:bg-slate-900 text-xs font-semibold overflow-x-auto">
                  <button
                    onClick={() => setDetailTab('personal')}
                    className={`py-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      detailTab === 'personal'
                        ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Users className="w-4 h-4" /> Personal & Contact
                  </button>

                  <button
                    onClick={() => setDetailTab('family')}
                    className={`py-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      detailTab === 'family'
                        ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Home className="w-4 h-4" /> Family & Children
                  </button>

                  <button
                    onClick={() => setDetailTab('spiritual')}
                    className={`py-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      detailTab === 'spiritual'
                        ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Award className="w-4 h-4" /> Spiritual & Ministry
                  </button>

                  <button
                    onClick={() => setDetailTab('professional')}
                    className={`py-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      detailTab === 'professional'
                        ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Briefcase className="w-4 h-4" /> Profession & Work
                  </button>

                  <button
                    onClick={() => setDetailTab('medical')}
                    className={`py-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      detailTab === 'medical'
                        ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Heart className="w-4 h-4" /> Health & Emergency
                  </button>

                  <button
                    onClick={() => setDetailTab('digital_id')}
                    className={`py-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
                      detailTab === 'digital_id'
                        ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <QrCode className="w-4 h-4" /> Digital ID Card
                  </button>
                </div>

                {/* Tab Body Content */}
                <div className="p-6 overflow-y-auto flex-1 text-xs space-y-4">
                  {detailTab === 'personal' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Identity & Demographics
                        </h4>
                        <p><strong>Full Name:</strong> {selectedMember.title} {selectedMember.firstName} {selectedMember.middleName} {selectedMember.lastName}</p>
                        <p>
                          <strong>Date of Birth:</strong> {selectedMember.dateOfBirth} ({selectedMember.age} yrs)
                          {selectedMember.dateOfBirth && gregorianToEthiopian(selectedMember.dateOfBirth) && (
                            <span className="block text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                              🇪🇹 {gregorianToEthiopian(selectedMember.dateOfBirth)?.formattedAmharic}
                            </span>
                          )}
                        </p>
                        <p><strong>Gender:</strong> {selectedMember.gender}</p>
                        <p><strong>Marital Status:</strong> {selectedMember.maritalStatus || 'Single'}</p>
                        {selectedMember.maritalStatus === 'Married' && selectedMember.marriageDate && (
                          <p>
                            <strong>Marriage Date:</strong> {selectedMember.marriageDate}
                            {gregorianToEthiopian(selectedMember.marriageDate) && (
                              <span className="block text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                                🇪🇹 {gregorianToEthiopian(selectedMember.marriageDate)?.formattedAmharic}
                              </span>
                            )}
                          </p>
                        )}
                        <p><strong>Nationality:</strong> {selectedMember.nationality}</p>
                        <p><strong>National ID:</strong> {selectedMember.nationalIdNumber}</p>
                        {selectedMember.passportNumber && <p><strong>Passport No:</strong> {selectedMember.passportNumber}</p>}
                      </div>

                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Contact & Resident Address
                        </h4>
                        <p><strong>Primary Phone:</strong> {selectedMember.primaryPhone}</p>
                        <p><strong>Alt Phone:</strong> {selectedMember.altPhone || 'N/A'}</p>
                        <p><strong>Email Address:</strong> {selectedMember.email}</p>
                        <p><strong>Preferred Comm:</strong> {selectedMember.preferredCommChannel}</p>
                        <p><strong>Street Address:</strong> {selectedMember.streetAddress}</p>
                        <p><strong>City / Sub-City:</strong> {selectedMember.city}, {selectedMember.subCity || 'N/A'}</p>
                        <p className="p-2 bg-blue-50 dark:bg-blue-950/40 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200">
                          <strong>Woreda:</strong> {selectedMember.woreda || 'N/A'} • <strong>Kebele:</strong> {selectedMember.kebele || 'N/A'} • <strong>House No:</strong> {selectedMember.houseNumber || 'N/A'}
                        </p>
                        <p><strong>Region / Province:</strong> {selectedMember.region} {selectedMember.postalCode}</p>
                      </div>
                    </div>
                  )}

                  {detailTab === 'family' && (
                    <div className="space-y-4">
                      {/* Marital Status & Marriage Details Card */}
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                          <Heart className="w-4 h-4 text-rose-500" /> Marital Status & Details
                        </h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                            <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Marital Status</span>
                            <span className="font-extrabold text-slate-900 dark:text-white text-sm">
                              {selectedMember.maritalStatus || 'Single'}
                            </span>
                          </div>
                          {selectedMember.maritalStatus === 'Married' ? (
                            <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                              <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Marriage Date</span>
                              <span className="font-bold text-slate-900 dark:text-white text-sm">
                                {selectedMember.marriageDate || 'N/A'}
                                {selectedMember.marriageDate && gregorianToEthiopian(selectedMember.marriageDate) && (
                                  <span className="block text-xs text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                                    🇪🇹 {gregorianToEthiopian(selectedMember.marriageDate)?.formattedAmharic}
                                  </span>
                                )}
                              </span>
                            </div>
                          ) : (
                            <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center">
                              <span className="text-slate-400 text-xs italic">No marriage record registered</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Family Members Status Breakdown Card */}
                      <div className="p-4 bg-indigo-50/60 dark:bg-indigo-950/40 rounded-2xl border border-indigo-200 dark:border-indigo-800 space-y-3">
                        <div className="flex items-center justify-between border-b border-indigo-200 dark:border-indigo-800 pb-2">
                          <h4 className="font-bold text-xs text-indigo-950 dark:text-indigo-200 uppercase tracking-wider flex items-center gap-2">
                            <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /> Family Members Status (Children Breakdown)
                          </h4>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-indigo-200 text-indigo-900 dark:bg-indigo-900 dark:text-indigo-200">
                            Total: {(selectedMember.maleChildrenCount || 0) + (selectedMember.femaleChildrenCount || 0) + (selectedMember.adoptedChildrenCount || 0)} Children
                          </span>
                        </div>

                        <div className="grid grid-cols-3 gap-3 text-center">
                          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900">
                            <span className="text-xl font-extrabold text-blue-600 dark:text-blue-400 block">
                              {selectedMember.maleChildrenCount || 0}
                            </span>
                            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">Male Children</span>
                          </div>
                          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900">
                            <span className="text-xl font-extrabold text-pink-600 dark:text-pink-400 block">
                              {selectedMember.femaleChildrenCount || 0}
                            </span>
                            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">Female Children</span>
                          </div>
                          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-indigo-100 dark:border-indigo-900">
                            <span className="text-xl font-extrabold text-amber-600 dark:text-amber-400 block">
                              {selectedMember.adoptedChildrenCount || 0}
                            </span>
                            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">Adopted Children</span>
                          </div>
                        </div>
                      </div>

                      {/* Linked Household Details */}
                      {(() => {
                        const memberFam = families.find(
                          (f) => f.memberIds.includes(selectedMember.id) || f.headOfHouseholdMemberId === selectedMember.id
                        );
                        if (!memberFam) {
                          return (
                            <div className="p-6 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 space-y-2">
                              <Home className="w-8 h-8 mx-auto text-slate-400" />
                              <h4 className="font-bold text-xs text-slate-900 dark:text-white">No Assigned Family Unit</h4>
                              <p className="text-[11px] text-slate-500 max-w-md mx-auto">
                                Member is registered with individual children status above, but not assigned to a household cluster yet.
                              </p>
                            </div>
                          );
                        }
                        const head = members.find((m) => m.id === memberFam.headOfHouseholdMemberId);
                        const householdMembers = members.filter((m) => memberFam.memberIds.includes(m.id));

                        return (
                          <div className="space-y-3">
                            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                              <div>
                                <h4 className="font-bold text-xs text-slate-900 dark:text-white">{memberFam.householdName} ({memberFam.familyCode})</h4>
                                <p className="text-[11px] text-slate-500 mt-0.5">
                                  Head of Household: <strong>{head ? `${head.firstName} ${head.lastName}` : 'Unassigned'}</strong> • {memberFam.familyType}
                                </p>
                              </div>
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                {memberFam.status} Household
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {householdMembers.map((fm) => (
                                <div key={fm.id} className="p-2.5 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-3 text-xs">
                                  <img src={fm.photoUrl} alt="" className="w-9 h-9 rounded-lg object-cover" />
                                  <div>
                                    <h6 className="font-bold">{fm.firstName} {fm.lastName}</h6>
                                    <p className="text-[10px] text-slate-500">{fm.primaryPhone}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}

                  {detailTab === 'spiritual' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2.5">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Salvation & Baptism Details
                        </h4>
                        <p>
                          <strong>Salvation Date:</strong> {selectedMember.salvationDate || 'N/A'}
                          {selectedMember.salvationDate && gregorianToEthiopian(selectedMember.salvationDate) && (
                            <span className="block text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                              🇪🇹 {gregorianToEthiopian(selectedMember.salvationDate)?.formattedAmharic}
                            </span>
                          )}
                        </p>
                        <p><strong>Salvation Location / Saved At:</strong> {selectedMember.salvationLocation || 'N/A'}</p>
                        
                        <div className="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-1">
                          <p><strong>Water Baptized:</strong> {selectedMember.isWaterBaptized ? 'Yes ✅' : 'No ❌'}</p>
                          {selectedMember.isWaterBaptized && (
                            <>
                              <p>
                                <strong>Water Baptism Date:</strong> {selectedMember.waterBaptismDate || 'N/A'}
                                {selectedMember.waterBaptismDate && gregorianToEthiopian(selectedMember.waterBaptismDate) && (
                                  <span className="block text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                                    🇪🇹 {gregorianToEthiopian(selectedMember.waterBaptismDate)?.formattedAmharic}
                                  </span>
                                )}
                              </p>
                              <p><strong>Baptism Church / Location:</strong> {selectedMember.waterBaptismLocation || 'N/A'}</p>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2.5">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Membership & Status Details
                        </h4>
                        <p>
                          <strong>Membership Status:</strong>{' '}
                          <span className="font-extrabold px-2 py-0.5 rounded-md bg-blue-100 text-blue-900 dark:bg-blue-950 dark:text-blue-200 text-xs">
                            {selectedMember.membershipStatus}
                          </span>
                        </p>
                        <p>
                          <strong>Membership Joining Date:</strong> {selectedMember.membershipDate}
                          {selectedMember.membershipDate && gregorianToEthiopian(selectedMember.membershipDate) && (
                            <span className="block text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                              🇪🇹 {gregorianToEthiopian(selectedMember.membershipDate)?.formattedAmharic}
                            </span>
                          )}
                        </p>
                        <p><strong>Membership Location / Church:</strong> {selectedMember.membershipLocation || 'Main Church'}</p>

                        {(selectedMember.departureDate || selectedMember.statusStartDate) && (
                          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 space-y-1">
                            <span className="text-[10px] font-bold text-amber-900 dark:text-amber-200 uppercase tracking-wider block">
                              {selectedMember.membershipStatus === 'Excommunicated' ? 'Excommunication Period' : 'Status / Departure Date'}
                            </span>
                            <p className="font-bold text-xs text-amber-950 dark:text-amber-100">
                              Date: {selectedMember.departureDate || selectedMember.statusStartDate}
                              {selectedMember.membershipStatus === 'Excommunicated' && (selectedMember.departureEndDate || selectedMember.statusEndDate)
                                ? ` to ${selectedMember.departureEndDate || selectedMember.statusEndDate}`
                                : ''}
                            </p>
                            {gregorianToEthiopian(selectedMember.departureDate || selectedMember.statusStartDate!) && (
                              <p className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-400">
                                🇪🇹 {gregorianToEthiopian(selectedMember.departureDate || selectedMember.statusStartDate!)?.formattedAmharic}
                                {selectedMember.membershipStatus === 'Excommunicated' && (selectedMember.departureEndDate || selectedMember.statusEndDate) && gregorianToEthiopian(selectedMember.departureEndDate || selectedMember.statusEndDate!) ? (
                                  ` – ${gregorianToEthiopian(selectedMember.departureEndDate || selectedMember.statusEndDate!)?.formattedAmharic}`
                                ) : ''}
                              </p>
                            )}
                          </div>
                        )}

                        {selectedMember.membershipStatus === 'Excommunicated' && (
                          <div className="p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-900/60 space-y-2">
                            <span className="text-[10px] font-bold text-purple-900 dark:text-purple-200 uppercase tracking-wider block flex items-center gap-1">
                              <FileText className="w-3.5 h-3.5 text-purple-600" /> Excommunication Decree & Paper
                            </span>
                            {selectedMember.excommunicationDescription && (
                              <p className="text-xs text-purple-950 dark:text-purple-100 italic bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg border border-purple-100 dark:border-purple-900/50">
                                "{selectedMember.excommunicationDescription}"
                              </p>
                            )}
                            {selectedMember.excommunicationPaperUrl ? (
                              <button
                                type="button"
                                onClick={() => setPaperPreviewModal({
                                  isOpen: true,
                                  title: `Paper of Excommunication - ${selectedMember.firstName} ${selectedMember.lastName}`,
                                  url: selectedMember.excommunicationPaperUrl || '',
                                  fileName: selectedMember.excommunicationPaperName || 'Excommunication Paper'
                                })}
                                className="w-full py-2 px-3 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                              >
                                <Paperclip className="w-3.5 h-3.5" /> View Paper of Excommunication ({selectedMember.excommunicationPaperName || 'Document'})
                              </button>
                            ) : (
                              <p className="text-[11px] text-purple-700 dark:text-purple-300 italic">
                                No physical paper uploaded yet.
                              </p>
                            )}
                          </div>
                        )}

                        <div className="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 block">
                            Active Ministry Involvement (Synced from Ministries Roster)
                          </span>
                          {(() => {
                            const joined = ministries.filter(
                              (m) =>
                                selectedMember.ministryIds?.includes(m.id) ||
                                m.memberIds?.includes(selectedMember.id) ||
                                m.leaderMemberId === selectedMember.id
                            );
                            if (joined.length === 0) {
                              return (
                                <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-500 text-xs italic">
                                  No active ministry involvement registered in church roster.
                                </div>
                              );
                            }
                            return (
                              <div className="space-y-1.5">
                                {joined.map((min) => {
                                  const isLeader = min.leaderMemberId === selectedMember.id;
                                  return (
                                    <div
                                      key={min.id}
                                      className="p-2.5 bg-indigo-50/80 dark:bg-indigo-950/50 rounded-xl border border-indigo-200 dark:border-indigo-800 flex items-center justify-between"
                                    >
                                      <div>
                                        <span className="font-bold text-indigo-950 dark:text-indigo-100 text-xs block">
                                          {min.name}
                                        </span>
                                        <span className="text-[10px] text-slate-500 block">
                                          {min.meetingSchedule || 'Weekly'} • {min.meetingLocation || 'Church Hall'}
                                        </span>
                                      </div>
                                      <span
                                        className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${
                                          isLeader
                                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200'
                                            : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-200'
                                        }`}
                                      >
                                        {isLeader ? '👑 Ministry Leader' : 'Active Member'}
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  )}

                  {detailTab === 'professional' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Education & Work
                        </h4>
                        <p><strong>Education Level:</strong> {selectedMember.educationLevel}</p>
                        <p><strong>Field of Study:</strong> {selectedMember.fieldOfStudy || 'N/A'}</p>
                        <p><strong>Occupation:</strong> {selectedMember.occupation}</p>
                        <p><strong>Employer Name:</strong> {selectedMember.employerName || 'N/A'}</p>
                        <p><strong>Employer Type:</strong> {selectedMember.employerType || 'N/A'}</p>
                      </div>

                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Talents & Languages
                        </h4>
                        <p><strong>Skills & Talents:</strong> {selectedMember.skillsAndTalents?.join(', ') || 'None'}</p>
                        <p><strong>Languages Spoken:</strong> {selectedMember.languagesSpoken?.join(', ') || 'Amharic'}</p>
                      </div>
                    </div>
                  )}

                  {detailTab === 'medical' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Medical Profile
                        </h4>
                        <p><strong>Blood Type:</strong> {selectedMember.bloodType || 'A+'}</p>
                        <p><strong>Known Allergies:</strong> {selectedMember.knownAllergies?.join(', ') || 'None'}</p>
                        <p><strong>Medical Conditions:</strong> {selectedMember.medicalConditions?.join(', ') || 'None'}</p>
                      </div>

                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-2">
                        <h4 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                          Emergency Contact
                        </h4>
                        <p><strong>Contact Name:</strong> {selectedMember.emergencyContact?.name || 'N/A'}</p>
                        <p><strong>Relationship:</strong> {selectedMember.emergencyContact?.relationship || 'N/A'}</p>
                        <p><strong>Phone Number:</strong> {selectedMember.emergencyContact?.phone || 'N/A'}</p>
                      </div>
                    </div>
                  )}

                  {detailTab === 'digital_id' && (
                    <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-blue-900 to-slate-900 text-white rounded-2xl max-w-md mx-auto shadow-xl space-y-4">
                      <div className="flex items-center justify-between w-full border-b border-white/20 pb-3">
                        <span className="font-bold text-sm tracking-wider uppercase">GRACE CATHEDRAL CMMS</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-blue-500 font-bold">DIGITAL MEMBER ID</span>
                      </div>

                      <div className="flex items-center gap-4 w-full">
                        <img
                          src={selectedMember.photoUrl}
                          alt={selectedMember.firstName}
                          className="w-20 h-20 rounded-xl object-cover ring-2 ring-white"
                        />
                        <div>
                          <h3 className="font-bold text-base">
                            {selectedMember.firstName} {selectedMember.lastName}
                          </h3>
                          <p className="text-xs text-blue-200">{selectedMember.memberIdNumber}</p>
                          <p className="text-[11px] text-slate-300 mt-1">{selectedMember.woreda || ''} {selectedMember.kebele ? `Keb ${selectedMember.kebele}` : ''}</p>
                        </div>
                      </div>

                      <div className="p-4 bg-white rounded-xl text-black flex flex-col items-center space-y-2 w-full">
                        <div className="w-32 h-32 bg-slate-900 p-2 rounded-lg flex items-center justify-center text-white text-[10px] font-mono text-center">
                          [QR CODE TERMINAL PASS]
                          <br />
                          {selectedMember.memberIdNumber}
                        </div>
                        <span className="text-[10px] font-semibold text-slate-600">Scan at Entrance / Event Check-in</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
                  {permissions.canDeleteMembers ? (
                    <button
                      onClick={() => handleDeleteMemberClick(selectedMember.id, `${selectedMember.firstName} ${selectedMember.lastName}`)}
                      className="px-3 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-800 rounded-xl font-bold text-xs flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete Member Record
                    </button>
                  ) : <div />}

                  <button
                    onClick={() => setSelectedMember(null)}
                    className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-xl font-semibold text-xs"
                  >
                    Close Profile
                  </button>
                </div>
              </div>
            </div>
          )}

      {/* Paper Preview / Document Viewing Modal */}
      {paperPreviewModal.isOpen && (
        <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-600" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {paperPreviewModal.title}
                </h3>
              </div>
              <button
                onClick={() => setPaperPreviewModal({ isOpen: false, title: '', url: '', fileName: '' })}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 flex flex-col items-center justify-center min-h-[300px] bg-slate-100 dark:bg-slate-950">
              {paperPreviewModal.url.startsWith('data:image') || paperPreviewModal.url.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? (
                <img
                  src={paperPreviewModal.url}
                  alt={paperPreviewModal.fileName || 'Excommunication Paper'}
                  className="max-w-full max-h-[60vh] object-contain rounded-xl shadow-md border border-slate-200 dark:border-slate-800"
                />
              ) : paperPreviewModal.url.startsWith('data:application/pdf') ? (
                <iframe
                  src={paperPreviewModal.url}
                  title="PDF Preview"
                  className="w-full h-[60vh] rounded-xl border border-slate-200 dark:border-slate-800"
                />
              ) : (
                <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 max-w-md">
                  <FileText className="w-16 h-16 text-purple-600 mx-auto" />
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-base">
                      {paperPreviewModal.fileName || 'Excommunication Paper Document'}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">Official decree paper / document uploaded</p>
                  </div>
                  <a
                    href={paperPreviewModal.url}
                    download={paperPreviewModal.fileName || 'Paper_of_Excommunication'}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold text-xs shadow-md transition-all"
                  >
                    <Download className="w-4 h-4" /> Download / Open Document
                  </a>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">
                {paperPreviewModal.fileName || 'Official Excommunication Paper'}
              </span>
              <div className="flex items-center gap-2">
                {paperPreviewModal.url && (
                  <a
                    href={paperPreviewModal.url}
                    download={paperPreviewModal.fileName || 'Paper_of_Excommunication'}
                    className="px-3 py-1.5 bg-purple-100 hover:bg-purple-200 dark:bg-purple-950 dark:hover:bg-purple-900 text-purple-900 dark:text-purple-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" /> Download
                  </a>
                )}
                <button
                  onClick={() => setPaperPreviewModal({ isOpen: false, title: '', url: '', fileName: '' })}
                  className="px-4 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-xl font-semibold text-xs hover:bg-slate-300 dark:hover:bg-slate-700"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Member Confirmation Modal */}
      {deleteTargetMember && (
        <div className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Delete Member Record?
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  Are you sure you want to permanently delete the member record for{' '}
                  <strong className="text-slate-900 dark:text-white">{deleteTargetMember.name}</strong>
                  {deleteTargetMember.memberIdNumber ? ` (${deleteTargetMember.memberIdNumber})` : ''}? This action cannot be undone.
                </p>
              </div>
            </div>

            <div className="flex flex-col-reverse sm:flex-row sm:items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteTargetMember(null)}
                className="min-h-[44px] sm:min-h-[38px] px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-semibold text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteMember}
                className="min-h-[44px] sm:min-h-[38px] px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold text-xs shadow-md flex items-center justify-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Permanently Delete Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Public Google-Form Style Registration Link Generator & QR Modal */}
      <PublicRegistrationFormModal
        isOpen={isShareFormModalOpen}
        onClose={() => setIsShareFormModalOpen(false)}
      />
    </div>
  );
};
