import React from 'react';
import {
  ShareRegistrationLinkModal,
  ShareRegistrationLinkModalProps,
} from './ShareRegistrationLinkModal';

/**
 * Re-exports ShareRegistrationLinkModal as PublicRegistrationFormModal
 * so existing callers in ApprovalsModule and MemberModule reuse the exact
 * unified registration link & invitation architecture without duplication.
 */
export const PublicRegistrationFormModal: React.FC<ShareRegistrationLinkModalProps> = (props) => {
  return <ShareRegistrationLinkModal {...props} />;
};

export default PublicRegistrationFormModal;
