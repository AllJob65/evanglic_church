import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { LmsCourse } from '../types';
import {
  GraduationCap,
  BookOpen,
  Award,
  CheckCircle2,
  X,
  Sparkles,
  Plus,
  Trash2,
  Edit3,
  Search,
  Users,
  TrendingUp,
  FileCheck,
  ShieldCheck,
  ShieldAlert,
  Printer,
  Calendar,
  Check,
  BarChart3,
  Book,
  Clock,
  AlertCircle,
} from 'lucide-react';

interface StudentEnrollment {
  id: string;
  studentName: string;
  memberId: string;
  courseId: string;
  courseTitle: string;
  completedModules: number;
  totalModules: number;
  attendancePct: number;
  gradeScore: number | null;
  letterGrade: string | null;
  certificateId: string | null;
  status: 'Enrolled' | 'In Progress' | 'Passed & Graduated' | 'Failed';
}

interface ExamSubmission {
  id: string;
  studentName: string;
  courseTitle: string;
  examDate: string;
  scorePct: number;
  letterGrade: string;
  status: 'Passed' | 'Failed' | 'Pending Review';
  certificateId: string;
  feedback?: string;
}

interface CertificateRecord {
  certificateId: string;
  studentName: string;
  courseTitle: string;
  issueDate: string;
  instructorName: string;
  passingScore: number;
  campusName: string;
  verificationHash: string;
  isValid: boolean;
}

export const LmsModule: React.FC = () => {
  const { courses, addCourse, updateCourse, deleteCourse, members, churchLogoUrl, systemName } = useCMMS();
  const [activeTab, setActiveTab] = useState<'catalog' | 'tracking' | 'grades' | 'certificates'>('catalog');

  // Selected course for detail & exam
  const [selectedCourse, setSelectedCourse] = useState<LmsCourse>(courses[0] || {
    id: '',
    courseCode: '',
    title: '',
    category: 'Discipleship & Foundations',
    instructorName: '',
    description: '',
    totalModules: 0,
    durationWeeks: 0,
    enrolledStudentsCount: 0,
    passPercentage: 80,
  });

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Modal States
  const [isCourseModalOpen, setIsCourseModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<LmsCourse | null>(null);

  // Form Fields for Create / Edit Course
  const [courseCode, setCourseCode] = useState('');
  const [courseTitle, setCourseTitle] = useState('');
  const [courseCategory, setCourseCategory] = useState<LmsCourse['category']>('Discipleship & Foundations');
  const [instructorName, setInstructorName] = useState('');
  const [description, setDescription] = useState('');
  const [durationWeeks, setDurationWeeks] = useState(6);
  const [totalModules, setTotalModules] = useState(4);
  const [passPercentage, setPassPercentage] = useState(80);

  // Student Enrollments State
  const [enrollments, setEnrollments] = useState<StudentEnrollment[]>([]);

  // Exam Submissions State
  const [examSubmissions, setExamSubmissions] = useState<ExamSubmission[]>([]);

  // Certificate Verification Database State
  const [verifiedCertificates, setVerifiedCertificates] = useState<CertificateRecord[]>([]);

  // Search input for Certificate Verification Portal
  const [verifySearchId, setVerifySearchId] = useState('');
  const [verifyResult, setVerifyResult] = useState<CertificateRecord | null>(null);
  const [hasSearchedCert, setHasSearchedCert] = useState(false);

  // Exam Simulator Modal State
  const [isExamModalOpen, setIsExamModalOpen] = useState(false);
  const [examCourseId, setExamCourseId] = useState<string>(courses[0]?.id || '');
  const [examStudentName, setExamStudentName] = useState(members[0]?.firstName ? `${members[0].firstName} ${members[0].lastName}` : '');
  const [examAnswers, setExamAnswers] = useState<Record<number, number>>({});
  const [examSubmittedResult, setExamSubmittedResult] = useState<{ score: number; passed: boolean; certId: string; letter: string } | null>(null);

  // Helper: Get active course object for exam
  const examActiveCourse = courses.find((c) => c.id === examCourseId) || selectedCourse || courses[0];

  // Helper: Get course-specific exam questions generator
  const getCourseExamQuestions = (course: LmsCourse) => {
    const titleLower = (course?.title || '').toLowerCase();

    if (titleLower.includes('leadership') || titleLower.includes('servant')) {
      return [
        {
          question: '1. What is the primary biblical model of Christian leadership demonstrated by Christ in John 13?',
          options: [
            { label: 'Servant leadership through humility and washing feet', isCorrect: true },
            { label: 'Top-down authoritarian management without consultation', isCorrect: false },
            { label: 'Popularity-driven decision making based on public opinion', isCorrect: false },
          ],
        },
        {
          question: '2. According to Matthew 18:15-17, how should ministry leaders resolve interpersonal conflict?',
          options: [
            { label: 'Publicly denounce the individual on social media or in sermons', isCorrect: false },
            { label: 'Go privately to the individual first before escalating', isCorrect: true },
            { label: 'Ignore the conflict indefinitely and hope it resolves itself', isCorrect: false },
          ],
        },
        {
          question: '3. What key practice ensures sustainable volunteer coordination in local church operations?',
          options: [
            { label: 'Clear role description, spiritual encouragement, and active appreciation', isCorrect: true },
            { label: 'Assigning maximum shift hours without rest or feedback', isCorrect: false },
            { label: 'Requiring financial penalties for missed shifts', isCorrect: false },
          ],
        },
      ];
    }

    if (titleLower.includes('old testament') || titleLower.includes('covenant') || titleLower.includes('survey')) {
      return [
        {
          question: '1. What was God’s solemn covenant promise to Abraham in Genesis 12 & 15?',
          options: [
            { label: 'A land, a great nation, and a blessing to all families of the earth', isCorrect: true },
            { label: 'Immediate worldly wealth without trials or relocation', isCorrect: false },
            { label: 'Exemption from all physical suffering and mortality', isCorrect: false },
          ],
        },
        {
          question: '2. What is the prophetic significance of the Passover lamb in the book of Exodus?',
          options: [
            { label: 'Foreshadowing the substitutionary sacrifice of Jesus Christ, the Lamb of God', isCorrect: true },
            { label: 'A seasonal agricultural celebration of spring harvests', isCorrect: false },
            { label: 'A political decree issued by Pharaoh', isCorrect: false },
          ],
        },
        {
          question: '3. The Davidic Covenant in 2 Samuel 7 promises that David’s royal throne would:',
          options: [
            { label: 'End permanently with the Babylonian exile', isCorrect: false },
            { label: 'Be established forever through the coming Messiah', isCorrect: true },
            { label: 'Be transferred to Egyptian monarchs', isCorrect: false },
          ],
        },
      ];
    }

    if (titleLower.includes('theology') || titleLower.includes('paul') || titleLower.includes('new testament')) {
      return [
        {
          question: '1. What central doctrine does Apostle Paul defend in his Epistle to the Romans?',
          options: [
            { label: 'Justification by faith in Jesus Christ apart from the works of the Law', isCorrect: true },
            { label: 'Re-establishing Mosaic ritual sacrifices in Gentile cities', isCorrect: false },
            { label: 'Earning eternal salvation purely through human philosophical debate', isCorrect: false },
          ],
        },
        {
          question: '2. According to 1 Corinthians 13, spiritual gifts exercised without Christian love are:',
          options: [
            { label: 'Fully acceptable as long as supernatural signs occur', isCorrect: false },
            { label: 'Like noisy gongs or clanging cymbals, profiting nothing', isCorrect: true },
            { label: 'Superior to all moral virtues', isCorrect: false },
          ],
        },
        {
          question: '3. The Fruit of the Holy Spirit listed in Galatians 5:22-23 includes:',
          options: [
            { label: 'Love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, self-control', isCorrect: true },
            { label: 'Financial prosperity and political dominance', isCorrect: false },
            { label: 'Academic degrees and social rank', isCorrect: false },
          ],
        },
      ];
    }

    if (titleLower.includes('worship') || titleLower.includes('music') || titleLower.includes('liturgy')) {
      return [
        {
          question: '1. According to John 4:23-24, how must true worshippers worship God the Father?',
          options: [
            { label: 'In spirit and in truth', isCorrect: true },
            { label: 'Only in specific geographical temple buildings', isCorrect: false },
            { label: 'Exclusively using ancient stringed instruments', isCorrect: false },
          ],
        },
        {
          question: '2. What is the primary objective of a church worship ministry team?',
          options: [
            { label: 'Providing musical entertainment to draw secular media attention', isCorrect: false },
            { label: 'Exalting Jesus Christ and facilitating authentic congregational worship', isCorrect: true },
            { label: 'Showcasing individual performer talent', isCorrect: false },
          ],
        },
        {
          question: '3. What does Psalm 150 instruct regarding praising God in the sanctuary?',
          options: [
            { label: 'Praise Him with trumpets, harps, timbrels, stringed instruments, and cymbals', isCorrect: true },
            { label: 'Only sing in complete silence without instruments', isCorrect: false },
            { label: 'Limit praise to once per calendar year', isCorrect: false },
          ],
        },
      ];
    }

    if (titleLower.includes('care') || titleLower.includes('counseling') || titleLower.includes('visitation')) {
      return [
        {
          question: '1. What is the ultimate source of authority and comfort in Christian pastoral counseling?',
          options: [
            { label: 'The inspired Word of God and the work of the Holy Spirit', isCorrect: true },
            { label: 'Speculative secular astrology charts', isCorrect: false },
            { label: 'Personal opinions and ungrounded advice', isCorrect: false },
          ],
        },
        {
          question: '2. When conducting pastoral care visits for hospitalized or homebound members, caregivers should:',
          options: [
            { label: 'Show compassionate presence, pray scripture, and listen attentively', isCorrect: true },
            { label: 'Condemn the suffering individual as lacking faith', isCorrect: false },
            { label: 'Discuss private member confessions with church visitors', isCorrect: false },
          ],
        },
        {
          question: '3. According to Galatians 6:2, believers fulfill the law of Christ when they:',
          options: [
            { label: 'Bear one another’s burdens in active Christian love', isCorrect: true },
            { label: 'Isolate themselves from struggling brothers and sisters', isCorrect: false },
            { label: 'Judge struggling members harshly in public', isCorrect: false },
          ],
        },
      ];
    }

    // Default / Foundations of Faith
    return [
      {
        question: `1. In the course "${course?.title || 'Discipleship'}", what is the foundation of Christian salvation?`,
        options: [
          { label: 'Salvation by grace through faith in Jesus Christ (Ephesians 2:8-9)', isCorrect: true },
          { label: 'Achieving perfection through human ritual effort alone', isCorrect: false },
          { label: 'Personal financial wealth and social status', isCorrect: false },
        ],
      },
      {
        question: `2. What is the biblical expectation for believers regarding spiritual growth in ${course?.title || 'this course'}?`,
        options: [
          { label: 'Daily prayer, Bible study, fellowship, and active witness', isCorrect: true },
          { label: 'Attending church once a year with no personal devotion', isCorrect: false },
          { label: 'Avoiding Christian community and living in isolation', isCorrect: false },
        ],
      },
      {
        question: `3. What is the role of Christian stewardship in ministry operations?`,
        options: [
          { label: 'Managing time, talent, and treasure faithfully for God’s kingdom', isCorrect: true },
          { label: 'Accumulating personal luxury at church expense', isCorrect: false },
          { label: 'Ignoring church financial responsibilities entirely', isCorrect: false },
        ],
      },
    ];
  };

  // Certificate Modal Preview State
  const [activeCertPreview, setActiveCertPreview] = useState<CertificateRecord | null>(verifiedCertificates[0]);
  const [isCertDiplomaOpen, setIsCertDiplomaOpen] = useState(false);

  // New Student Enrollment Modal
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [enrollStudentName, setEnrollStudentName] = useState('');
  const [enrollCourseId, setEnrollCourseId] = useState(courses[0]?.id || 'c1');

  // Open Create Course Modal
  const handleOpenCreateCourse = () => {
    setEditingCourse(null);
    setCourseCode(`DISC-${101 + courses.length * 5}`);
    setCourseTitle('');
    setCourseCategory('Discipleship & Foundations');
    setInstructorName('');
    setDescription('');
    setDurationWeeks(6);
    setTotalModules(4);
    setPassPercentage(80);
    setIsCourseModalOpen(true);
  };

  // Open Edit Course Modal
  const handleOpenEditCourse = (course: LmsCourse) => {
    setEditingCourse(course);
    setCourseCode(course.courseCode);
    setCourseTitle(course.title);
    setCourseCategory(course.category);
    setInstructorName(course.instructorName);
    setDescription(course.description);
    setDurationWeeks(course.durationWeeks);
    setTotalModules(course.totalModules);
    setPassPercentage(course.passPercentage);
    setIsCourseModalOpen(true);
  };

  // Save Course Handler
  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseTitle || !courseCode) return;

    if (editingCourse) {
      updateCourse({
        ...editingCourse,
        courseCode,
        title: courseTitle,
        category: courseCategory,
        instructorName,
        description,
        durationWeeks,
        totalModules,
        passPercentage,
      });
    } else {
      addCourse({
        id: `crs-${Date.now()}`,
        courseCode,
        title: courseTitle,
        category: courseCategory,
        instructorName,
        description,
        totalModules,
        durationWeeks,
        enrolledStudentsCount: 0,
        passPercentage,
      });
    }
    setIsCourseModalOpen(false);
  };

  // Submit Exam Handler
  const handleCalculateExamScore = (e: React.FormEvent) => {
    e.preventDefault();
    const currentQuestions = getCourseExamQuestions(examActiveCourse);
    let correctCount = 0;

    currentQuestions.forEach((q, idx) => {
      const selectedOptIdx = examAnswers[idx];
      if (selectedOptIdx !== undefined && q.options[selectedOptIdx]?.isCorrect) {
        correctCount++;
      }
    });

    const score = Math.round((correctCount / currentQuestions.length) * 100);
    const threshold = examActiveCourse.passPercentage || 80;
    const passed = score >= threshold;
    const letter = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : 'F';
    const certId = `CERT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const resultObj = { score, passed, certId, letter };
    setExamSubmittedResult(resultObj);

    // Save submission to gradebook
    const newSub: ExamSubmission = {
      id: `sub-${Date.now()}`,
      studentName: examStudentName,
      courseTitle: examActiveCourse.title,
      examDate: new Date().toISOString().split('T')[0],
      scorePct: score,
      letterGrade: letter,
      status: passed ? 'Passed' : 'Failed',
      certificateId: passed ? certId : 'N/A',
      feedback: passed ? 'Graduated course with official certificate issued.' : 'Scored below pass threshold. Eligible for retake.',
    };
    setExamSubmissions((prev) => [newSub, ...prev]);

    // If passed, register in verification registry
    if (passed) {
      const newCert: CertificateRecord = {
        certificateId: certId,
        studentName: examStudentName,
        courseTitle: examActiveCourse.title,
        issueDate: new Date().toISOString().split('T')[0],
        instructorName: examActiveCourse.instructorName,
        passingScore: score,
        campusName: systemName || 'CMMS',
        verificationHash: Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2),
        isValid: true,
      };
      setVerifiedCertificates((prev) => [newCert, ...prev]);

      // Update enrollment status
      setEnrollments((prev) =>
        prev.map((e) =>
          e.studentName.toLowerCase() === examStudentName.toLowerCase()
            ? { ...e, status: 'Passed & Graduated', gradeScore: score, letterGrade: letter, certificateId: certId, completedModules: e.totalModules }
            : e
        )
      );
    }
  };

  // Certificate Search Validation Handler
  const handleVerifyCertificateSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearchedCert(true);
    const found = verifiedCertificates.find(
      (c) => c.certificateId.trim().toUpperCase() === verifySearchId.trim().toUpperCase()
    );
    setVerifyResult(found || null);
  };

  // Add Enrollment Handler
  const handleEnrollStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!enrollStudentName) return;
    const targetCrs = courses.find((c) => c.id === enrollCourseId) || selectedCourse;
    const newEnr: StudentEnrollment = {
      id: `enr-${Date.now()}`,
      studentName: enrollStudentName,
      memberId: `CMMS-2025-${Math.floor(1000 + Math.random() * 9000)}`,
      courseId: targetCrs.id,
      courseTitle: targetCrs.title,
      completedModules: 1,
      totalModules: targetCrs.totalModules,
      attendancePct: 100,
      gradeScore: null,
      letterGrade: null,
      certificateId: null,
      status: 'In Progress',
    };
    setEnrollments((prev) => [newEnr, ...prev]);
    setIsEnrollModalOpen(false);
    setEnrollStudentName('');
  };

  // Stats
  const totalStudents = enrollments.length;
  const graduatedStudents = enrollments.filter((e) => e.status === 'Passed & Graduated').length;
  const avgScore = Math.round(
    examSubmissions.reduce((acc, curr) => acc + curr.scorePct, 0) / (examSubmissions.length || 1)
  );

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-purple-600" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Discipleship Academy & LMS</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200">
              {courses.length} Active Courses
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Complete curriculum management, student progress tracking, automated module grading, diploma certification, and official validation portal.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsEnrollModalOpen(true)}
            className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
          >
            <Users className="w-4 h-4 text-purple-600" /> Enroll Student
          </button>

          <button
            onClick={handleOpenCreateCourse}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Create New Course
          </button>
        </div>
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3">
          <div className="p-3 bg-purple-100 dark:bg-purple-950 text-purple-600 rounded-xl shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-semibold uppercase">Total Courses</span>
            <p className="text-lg font-extrabold text-slate-900 dark:text-white">{courses.length}</p>
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3">
          <div className="p-3 bg-blue-100 dark:bg-blue-950 text-blue-600 rounded-xl shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-semibold uppercase">Active Enrolled</span>
            <p className="text-lg font-extrabold text-slate-900 dark:text-white">{totalStudents}</p>
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-xl shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-semibold uppercase">Avg Exam Score</span>
            <p className="text-lg font-extrabold text-slate-900 dark:text-white">{avgScore}%</p>
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3">
          <div className="p-3 bg-amber-100 dark:bg-amber-950 text-amber-600 rounded-xl shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-500 font-semibold uppercase">Verified Diplomas</span>
            <p className="text-lg font-extrabold text-slate-900 dark:text-white">{verifiedCertificates.length}</p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 text-xs font-bold gap-2">
        <button
          onClick={() => setActiveTab('catalog')}
          className={`pb-3 px-4 transition-all flex items-center gap-2 border-b-2 ${
            activeTab === 'catalog'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Book className="w-4 h-4" /> Course Catalog & Creation
        </button>

        <button
          onClick={() => setActiveTab('tracking')}
          className={`pb-3 px-4 transition-all flex items-center gap-2 border-b-2 ${
            activeTab === 'tracking'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <BarChart3 className="w-4 h-4" /> Student Progress & Analytics
        </button>

        <button
          onClick={() => setActiveTab('grades')}
          className={`pb-3 px-4 transition-all flex items-center gap-2 border-b-2 ${
            activeTab === 'grades'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileCheck className="w-4 h-4" /> Gradebook & Exam Portal
        </button>

        <button
          onClick={() => setActiveTab('certificates')}
          className={`pb-3 px-4 transition-all flex items-center gap-2 border-b-2 ${
            activeTab === 'certificates'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <ShieldCheck className="w-4 h-4" /> Certification & Validation Portal
        </button>
      </div>

      {/* TAB 1: COURSE CATALOG & CREATION */}
      {activeTab === 'catalog' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Catalog Sidebar */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Course Curriculum ({courses.length})
              </h3>
            </div>

            {/* Filter & Search */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search course title or code..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
                />
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="w-full p-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 font-semibold"
              >
                <option value="All">All Categories</option>
                <option value="Biblical Studies">Biblical Studies</option>
                <option value="Discipleship & Foundations">Discipleship & Foundations</option>
                <option value="Leadership Training">Leadership Training</option>
                <option value="Theology">Theology</option>
                <option value="Ministry Skills">Ministry Skills</option>
              </select>
            </div>

            {/* Course List */}
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {courses
                .filter((crs) =>
                  categoryFilter === 'All' ? true : crs.category === categoryFilter
                )
                .filter((crs) =>
                  searchQuery
                    ? crs.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      crs.courseCode.toLowerCase().includes(searchQuery.toLowerCase())
                    : true
                )
                .map((crs) => {
                  const isSelected = selectedCourse?.id === crs.id;
                  return (
                    <div
                      key={crs.id}
                      onClick={() => setSelectedCourse(crs)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                        isSelected
                          ? 'bg-purple-50/80 dark:bg-purple-950/60 border-purple-500 shadow-md ring-2 ring-purple-500/20'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                          {crs.courseCode}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">{crs.category}</span>
                      </div>

                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{crs.title}</h4>
                      <p className="text-xs text-slate-500 font-medium">Instructor: {crs.instructorName}</p>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
                        <span>{crs.totalModules} Modules • {crs.durationWeeks} Wks</span>
                        <span className="font-bold text-purple-600">{crs.enrolledStudentsCount} Enrolled</span>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Selected Course Detail & Lesson Modules */}
          <div className="lg:col-span-2 space-y-6">
            {selectedCourse && (
              <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-200">
                        {selectedCourse.courseCode}
                      </span>
                      <span className="text-xs text-slate-400 font-semibold">{selectedCourse.category}</span>
                    </div>
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">{selectedCourse.title}</h2>
                    <p className="text-xs text-slate-500 mt-1">{selectedCourse.description}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleOpenEditCourse(selectedCourse)}
                      className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold"
                      title="Edit Course Details"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete course ${selectedCourse.title}?`)) {
                          deleteCourse(selectedCourse.id);
                        }
                      }}
                      className="p-2 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 rounded-xl text-xs font-bold"
                      title="Delete Course"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        setExamCourseId(selectedCourse.id);
                        setExamAnswers({});
                        setExamSubmittedResult(null);
                        setIsExamModalOpen(true);
                      }}
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
                    >
                      <Award className="w-4 h-4" /> Take Course Online Exam
                    </button>
                  </div>
                </div>

                {/* Course Metadata Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Instructor</span>
                    <p className="font-bold text-slate-900 dark:text-white mt-0.5">{selectedCourse.instructorName}</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Duration</span>
                    <p className="font-bold text-slate-900 dark:text-white mt-0.5">{selectedCourse.durationWeeks} Weeks</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Modules</span>
                    <p className="font-bold text-slate-900 dark:text-white mt-0.5">{selectedCourse.totalModules} Lessons</p>
                  </div>

                  <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Pass Threshold</span>
                    <p className="font-bold text-purple-600 mt-0.5">{selectedCourse.passPercentage}% Minimum</p>
                  </div>
                </div>

                {/* Modules Breakdown */}
                <div className="space-y-3">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center justify-between">
                    <span>Curriculum Syllabus Modules</span>
                    <span className="text-xs text-slate-400 font-normal">{selectedCourse.totalModules} Total Modules</span>
                  </h3>

                  <div className="space-y-2 text-xs">
                    <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl flex items-center justify-between border border-slate-200 dark:border-slate-700">
                      <div className="flex items-center gap-3">
                        <BookOpen className="w-4 h-4 text-purple-600" />
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white">Module 1: Salvation, Repentance & Divine Grace</span>
                          <p className="text-[11px] text-slate-500">Understanding Biblical salvation and assurance in Christ.</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        Active Module
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl flex items-center justify-between border border-slate-200 dark:border-slate-700">
                      <div className="flex items-center gap-3">
                        <BookOpen className="w-4 h-4 text-purple-600" />
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white">Module 2: Water Baptism & Holy Spirit Empowerment</span>
                          <p className="text-[11px] text-slate-500">Spiritual significance of immersion baptism and spiritual gifts.</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                        Active Module
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl flex items-center justify-between border border-slate-200 dark:border-slate-700">
                      <div className="flex items-center gap-3">
                        <BookOpen className="w-4 h-4 text-purple-600" />
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white">Module 3: Stewardship, Tithes & Christian Character</span>
                          <p className="text-[11px] text-slate-500">Integrity, financial wisdom, and servant leadership principles.</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                        Exam Required
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PROGRESS TRACKING & STUDENT ANALYTICS */}
      {activeTab === 'tracking' && (
        <div className="space-y-6">
          <div className="p-4 sm:p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Enrolled Students & Progress Roster
                </h3>
                <p className="text-xs text-slate-500">
                  Real-time monitoring of student attendance, completed modules, and graduation status.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsEnrollModalOpen(true)}
                className="min-h-[40px] px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs inline-flex items-center justify-center gap-1.5 shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="w-4 h-4 shrink-0" />
                <span>Enroll New Student</span>
              </button>
            </div>

            {/* Roster Table */}
            <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-200/80 dark:border-slate-800">
              <table className="cmms-data-table w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 bg-slate-50 dark:bg-slate-800/50 uppercase text-[10px] font-bold">
                    <th className="py-3 px-3 min-w-[150px]">Student Name</th>
                    <th className="py-3 px-3 whitespace-nowrap">Member ID</th>
                    <th className="py-3 px-3 min-w-[160px]">Course Title</th>
                    <th className="py-3 px-3 min-w-[150px]">Module Progress</th>
                    <th className="py-3 px-3 whitespace-nowrap">Attendance</th>
                    <th className="py-3 px-3 whitespace-nowrap">Exam Score</th>
                    <th className="py-3 px-3 whitespace-nowrap">Status</th>
                    <th className="py-3 px-3 text-right whitespace-nowrap sticky right-0 bg-slate-50 dark:bg-slate-800/95 z-10">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                  {enrollments.map((student) => {
                    const pct = Math.round((student.completedModules / student.totalModules) * 100);
                    return (
                      <tr key={student.id} className="group hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-3 px-3 font-bold">{student.studentName}</td>
                        <td className="py-3 px-3 text-slate-500 font-mono text-[11px] whitespace-nowrap tabular-nums">{student.memberId}</td>
                        <td className="py-3 px-3 font-medium">{student.courseTitle}</td>
                        <td className="py-3 px-3">
                          <div className="w-32 space-y-1">
                            <div className="flex justify-between text-[10px] font-bold tabular-nums">
                              <span>Module {student.completedModules}/{student.totalModules}</span>
                              <span className="text-purple-600">{pct}%</span>
                            </div>
                            <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                              <div
                                className="bg-purple-600 h-full rounded-full transition-all"
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-3 font-bold text-emerald-600 whitespace-nowrap tabular-nums">{student.attendancePct}%</td>
                        <td className="py-3 px-3 font-bold whitespace-nowrap tabular-nums">
                          {student.gradeScore ? (
                            <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 whitespace-nowrap">
                              {student.gradeScore}% ({student.letterGrade})
                            </span>
                          ) : (
                            <span className="text-slate-400 italic">Pending Exam</span>
                          )}
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          {student.status === 'Passed & Graduated' ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 inline-flex items-center gap-1 whitespace-nowrap">
                              <CheckCircle2 className="w-3 h-3 shrink-0" /> Graduated
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 inline-flex items-center gap-1 whitespace-nowrap">
                              <Clock className="w-3 h-3 shrink-0" /> In Progress
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right whitespace-nowrap sticky right-0 bg-white dark:bg-slate-900 group-hover:bg-slate-50 dark:group-hover:bg-slate-800/90 z-10">
                          {student.certificateId ? (
                            <button
                              type="button"
                              onClick={() => {
                                const certObj = verifiedCertificates.find((c) => c.certificateId === student.certificateId);
                                if (certObj) {
                                  setActiveCertPreview(certObj);
                                  setIsCertDiplomaOpen(true);
                                }
                              }}
                              className="min-h-[32px] px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-[11px] inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                            >
                              <Award className="w-3 h-3 shrink-0" /> View Diploma
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setEnrollments((prev) =>
                                  prev.map((e) =>
                                    e.id === student.id
                                      ? {
                                          ...e,
                                          completedModules: Math.min(e.totalModules, e.completedModules + 1),
                                        }
                                      : e
                                  )
                                );
                              }}
                              className="min-h-[32px] px-2.5 py-1 bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200 font-bold rounded-lg text-[11px] inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
                            >
                              + Module Progress
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GRADE MANAGEMENT & EXAM PORTAL */}
      {activeTab === 'grades' && (
        <div className="space-y-6">
          <div className="p-4 sm:p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Instructor Gradebook & Exam Submissions
                </h3>
                <p className="text-xs text-slate-500">
                  Manage exam grades, pass/fail thresholds, instructor feedback, and diploma issuance.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setExamCourseId(courses[0]?.id || 'c1');
                  setExamAnswers({});
                  setExamSubmittedResult(null);
                  setIsExamModalOpen(true);
                }}
                className="min-h-[40px] px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs inline-flex items-center justify-center gap-1.5 shadow-md whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Award className="w-4 h-4 shrink-0" />
                <span>Launch Online Exam Portal</span>
              </button>
            </div>

            {/* Exam Submissions Table */}
            <div className="cmms-table-scroll overflow-x-auto rounded-xl border border-slate-200/80 dark:border-slate-800">
              <table className="cmms-data-table w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 bg-slate-50 dark:bg-slate-800/50 uppercase text-[10px] font-bold">
                    <th className="py-3 px-3 min-w-[150px]">Student Name</th>
                    <th className="py-3 px-3 min-w-[160px]">Course Title</th>
                    <th className="py-3 px-3 whitespace-nowrap">Exam Date</th>
                    <th className="py-3 px-3 whitespace-nowrap">Raw Score</th>
                    <th className="py-3 px-3 whitespace-nowrap">Grade</th>
                    <th className="py-3 px-3 whitespace-nowrap">Status</th>
                    <th className="py-3 px-3 whitespace-nowrap">Certificate ID</th>
                    <th className="py-3 px-3 min-w-[180px]">Instructor Feedback</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                  {examSubmissions.map((sub) => (
                    <tr key={sub.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-3 font-bold">{sub.studentName}</td>
                      <td className="py-3 px-3 font-medium">{sub.courseTitle}</td>
                      <td className="py-3 px-3 text-slate-500 whitespace-nowrap tabular-nums">{sub.examDate}</td>
                      <td className="py-3 px-3 font-extrabold text-purple-600 whitespace-nowrap tabular-nums">{sub.scorePct}%</td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                          {sub.letterGrade}
                        </span>
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        {sub.status === 'Passed' ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 inline-flex items-center gap-1 whitespace-nowrap">
                            <CheckCircle2 className="w-3 h-3 shrink-0" /> Passed
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 inline-flex items-center gap-1 whitespace-nowrap">
                            <AlertCircle className="w-3 h-3 shrink-0" /> Failed
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-amber-600 whitespace-nowrap tabular-nums">{sub.certificateId}</td>
                      <td className="py-3 px-3 text-slate-500 italic text-[11px] max-w-xs">{sub.feedback || 'N/A'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CERTIFICATION & VALIDATION PORTAL */}
      {activeTab === 'certificates' && (
        <div className="space-y-6">
          {/* Validation Tool Card */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-purple-600" />
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Official Diploma Verification & Validation Registry
                </h3>
                <p className="text-xs text-slate-500">
                  Enter any Certificate ID (e.g., <code className="font-mono text-purple-600 font-bold">CERT-2026-8831</code>) to perform real-time cryptographic validation against official church academy records.
                </p>
              </div>
            </div>

            <form onSubmit={handleVerifyCertificateSearch} className="flex gap-2 max-w-lg pt-2">
              <input
                type="text"
                placeholder="Enter Certificate ID (e.g. CERT-2026-8831)"
                value={verifySearchId}
                onChange={(e) => setVerifySearchId(e.target.value)}
                className="flex-1 p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
              >
                <Search className="w-4 h-4" /> Verify Diploma
              </button>
            </form>

            {/* Search Verification Result */}
            {hasSearchedCert && (
              <div className="pt-2">
                {verifyResult ? (
                  <div className="p-5 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border-2 border-emerald-500 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                        <span className="font-bold text-sm text-emerald-900 dark:text-emerald-300 uppercase tracking-wider">
                          AUTHENTIC & VERIFIED DIPLOMA
                        </span>
                      </div>
                      <span className="px-2.5 py-1 bg-emerald-200 text-emerald-900 font-mono text-xs font-bold rounded-lg">
                        {verifyResult.certificateId}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
                      <div>
                        <span className="text-slate-500 font-semibold">Graduate Student:</span>
                        <p className="font-bold text-slate-900 dark:text-white">{verifyResult.studentName}</p>
                      </div>

                      <div>
                        <span className="text-slate-500 font-semibold">Course Title:</span>
                        <p className="font-bold text-slate-900 dark:text-white">{verifyResult.courseTitle}</p>
                      </div>

                      <div>
                        <span className="text-slate-500 font-semibold">Graduation Date:</span>
                        <p className="font-bold text-slate-900 dark:text-white">{verifyResult.issueDate}</p>
                      </div>
                    </div>

                    <div className="text-[11px] font-mono text-emerald-800 dark:text-emerald-400 pt-2 border-t border-emerald-200 dark:border-emerald-800/60 truncate">
                      Verification Hash: {verifyResult.verificationHash}
                    </div>
                  </div>
                ) : (
                  <div className="p-5 bg-rose-50 dark:bg-rose-950/40 rounded-2xl border-2 border-rose-400 flex items-center gap-3">
                    <ShieldAlert className="w-6 h-6 text-rose-600 shrink-0" />
                    <div>
                      <h4 className="font-bold text-sm text-rose-900 dark:text-rose-200">
                        UNVERIFIED CERTIFICATE ID
                      </h4>
                      <p className="text-xs text-rose-700 dark:text-rose-300">
                        No record matching certificate ID "{verifySearchId}" exists in the official Grace Cathedral Registry.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Verified Certificates List & Preview */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Recently Issued Academy Diplomas ({verifiedCertificates.length})
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {verifiedCertificates.map((cert) => (
                <div
                  key={cert.certificateId}
                  className="p-5 bg-gradient-to-b from-amber-50/60 to-orange-50/30 dark:from-amber-950/20 dark:to-slate-900 rounded-2xl border border-amber-200 dark:border-amber-900/60 space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-amber-200/60 dark:border-amber-900/40 pb-2">
                    <span className="font-mono text-xs font-bold text-amber-800 dark:text-amber-400">
                      {cert.certificateId}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Validated
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">{cert.studentName}</h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">{cert.courseTitle}</p>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-2 border-t border-amber-200/60 dark:border-amber-900/40">
                    <span className="text-slate-500 font-semibold">{cert.issueDate}</span>
                    <button
                      onClick={() => {
                        setActiveCertPreview(cert);
                        setIsCertDiplomaOpen(true);
                      }}
                      className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1 shadow-xs"
                    >
                      <Award className="w-3.5 h-3.5" /> Inspect Diploma
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CREATE / EDIT COURSE */}
      {isCourseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-lg border border-slate-200 dark:border-slate-800 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {editingCourse ? 'Edit Discipleship Course' : 'Create New Academy Course'}
              </h3>
              <button onClick={() => setIsCourseModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCourse} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Course Code</label>
                  <input
                    type="text"
                    required
                    value={courseCode}
                    onChange={(e) => setCourseCode(e.target.value)}
                    placeholder="e.g. DISC-101"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Category</label>
                  <select
                    value={courseCategory}
                    onChange={(e) => setCourseCategory(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Biblical Studies">Biblical Studies</option>
                    <option value="Discipleship & Foundations">Discipleship & Foundations</option>
                    <option value="Leadership Training">Leadership Training</option>
                    <option value="Theology">Theology</option>
                    <option value="Ministry Skills">Ministry Skills</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Course Title</label>
                <input
                  type="text"
                  required
                  value={courseTitle}
                  onChange={(e) => setCourseTitle(e.target.value)}
                  placeholder="e.g. New Believers Foundations"
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Instructor Name</label>
                  <input
                    type="text"
                    required
                    value={instructorName}
                    onChange={(e) => setInstructorName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Pass Score Threshold (%)</label>
                  <input
                    type="number"
                    min="50"
                    max="100"
                    value={passPercentage}
                    onChange={(e) => setPassPercentage(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Total Modules</label>
                  <input
                    type="number"
                    min="1"
                    value={totalModules}
                    onChange={(e) => setTotalModules(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Duration (Weeks)</label>
                  <input
                    type="number"
                    min="1"
                    value={durationWeeks}
                    onChange={(e) => setDurationWeeks(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Description & Overview</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Overview of curriculum goals, requirements, and outcomes..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCourseModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-md"
                >
                  {editingCourse ? 'Save Changes' : 'Publish Course'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ENROLL NEW STUDENT */}
      {isEnrollModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Enroll Student in Course</h3>
              <button onClick={() => setIsEnrollModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEnrollStudent} className="space-y-4">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Student Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="Select or enter student name..."
                  value={enrollStudentName}
                  onChange={(e) => setEnrollStudentName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Target Course</label>
                <select
                  value={enrollCourseId}
                  onChange={(e) => setEnrollCourseId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.courseCode} - {c.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsEnrollModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 text-white font-bold rounded-xl shadow-md"
                >
                  Enroll Student
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EXAM SIMULATOR */}
      {isExamModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 text-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Online Exam: {examActiveCourse?.title}
                </h3>
                <span className="text-[11px] text-purple-600 font-bold">Pass Threshold: {examActiveCourse?.passPercentage}% Minimum Required</span>
              </div>
              <button onClick={() => setIsExamModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {examSubmittedResult ? (
              <div className="p-6 text-center space-y-4">
                {examSubmittedResult.passed ? (
                  <div className="space-y-3">
                    <Award className="w-14 h-14 text-amber-500 mx-auto animate-bounce" />
                    <h4 className="font-extrabold text-xl text-emerald-600">
                      EXAM PASSED! Score: {examSubmittedResult.score}% (Grade {examSubmittedResult.letter})
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      Congratulations! Official Certificate ID <code className="font-bold text-purple-600">{examSubmittedResult.certId}</code> has been registered in the CMMS registry.
                    </p>

                    <button
                      onClick={() => {
                        const newCertObj: CertificateRecord = {
                          certificateId: examSubmittedResult.certId,
                          studentName: examStudentName,
                          courseTitle: examActiveCourse.title,
                          issueDate: new Date().toISOString().split('T')[0],
                          instructorName: examActiveCourse.instructorName,
                          passingScore: examSubmittedResult.score,
                          campusName: 'Grace Cathedral Headquarters',
                          verificationHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                          isValid: true,
                        };
                        setActiveCertPreview(newCertObj);
                        setIsExamModalOpen(false);
                        setIsCertDiplomaOpen(true);
                      }}
                      className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl shadow-md text-xs"
                    >
                      View & Print Official Graduation Diploma
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <AlertCircle className="w-14 h-14 text-rose-500 mx-auto" />
                    <h4 className="font-bold text-lg text-rose-600">
                      Exam Score: {examSubmittedResult.score}% (Grade {examSubmittedResult.letter})
                    </h4>
                    <p className="text-xs text-slate-500">
                      Score is below the required {examActiveCourse?.passPercentage}% pass threshold. You can review the module materials and retake the exam.
                    </p>

                    <button
                      onClick={() => {
                        setExamSubmittedResult(null);
                        setExamAnswers({});
                      }}
                      className="px-4 py-2 bg-slate-200 text-slate-800 font-bold rounded-xl"
                    >
                      Retake Exam
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <form onSubmit={handleCalculateExamScore} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Target Course Exam</label>
                    <select
                      value={examCourseId}
                      onChange={(e) => {
                        setExamCourseId(e.target.value);
                        setExamAnswers({});
                      }}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                    >
                      {courses.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.courseCode} - {c.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Student Full Name</label>
                    <input
                      type="text"
                      required
                      value={examStudentName}
                      onChange={(e) => setExamStudentName(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                    />
                  </div>
                </div>

                {/* Render Dynamic Questions for Active Course */}
                <div className="space-y-3">
                  {getCourseExamQuestions(examActiveCourse).map((qObj, qIdx) => (
                    <div
                      key={qIdx}
                      className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl space-y-2 border border-slate-200 dark:border-slate-700"
                    >
                      <p className="font-bold text-slate-900 dark:text-white leading-snug">
                        {qObj.question}
                      </p>
                      <div className="space-y-1.5 pt-1">
                        {qObj.options.map((opt, optIdx) => (
                          <label
                            key={optIdx}
                            className="flex items-start gap-2 cursor-pointer font-medium text-slate-700 dark:text-slate-300 p-2 rounded-lg hover:bg-slate-200/50 dark:hover:bg-slate-700/50 transition-colors"
                          >
                            <input
                              type="radio"
                              name={`course-q-${qIdx}`}
                              checked={examAnswers[qIdx] === optIdx}
                              onChange={() => setExamAnswers({ ...examAnswers, [qIdx]: optIdx })}
                              className="mt-0.5 accent-purple-600 shrink-0"
                            />
                            <span>{opt.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsExamModalOpen(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-md transition-all"
                  >
                    Submit Online Exam
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* MODAL: OFFICIAL DIPLOMA CERTIFICATE VIEW & PRINT */}
      {isCertDiplomaOpen && activeCertPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-2xl border-4 border-amber-400 p-8 space-y-6 relative overflow-hidden">
            <button
              onClick={() => setIsCertDiplomaOpen(false)}
              className="absolute top-4 right-4 p-2 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-8 bg-gradient-to-br from-amber-50/50 via-white to-amber-50/30 dark:from-slate-900 dark:via-slate-950 dark:to-slate-900 rounded-2xl border-2 border-dashed border-amber-300 dark:border-amber-800/60 text-center space-y-4">
              {/* Certificate Header */}
              <div className="space-y-1">
                {churchLogoUrl ? (
                  <img src={churchLogoUrl} alt="Logo" className="w-16 h-16 object-contain mx-auto mb-2" />
                ) : (
                  <GraduationCap className="w-12 h-12 text-amber-500 mx-auto" />
                )}
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-amber-700 dark:text-amber-400 block">
                  GRACE CATHEDRAL BIBLE & DISCIPLESHIP ACADEMY
                </span>
                <h2 className="text-2xl font-serif font-extrabold text-slate-900 dark:text-amber-100 tracking-tight">
                  CERTIFICATE OF DISCIPLESHIP COMPLETION
                </h2>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 italic">
                This is to officially certify that
              </p>

              <h3 className="text-2xl font-serif font-extrabold text-purple-900 dark:text-purple-300 tracking-wide border-b-2 border-purple-200 dark:border-purple-900/50 pb-2 max-w-md mx-auto">
                {activeCertPreview.studentName}
              </h3>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-lg mx-auto">
                has satisfactorily fulfilled all curriculum requirements, attended all syllabus modules, and successfully passed the final examination for
              </p>

              <h4 className="text-base font-bold text-slate-900 dark:text-white">
                "{activeCertPreview.courseTitle}"
              </h4>

              <div className="grid grid-cols-2 gap-4 text-xs pt-4 border-t border-amber-200/80 dark:border-amber-900/60 max-w-md mx-auto">
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Issued Date</span>
                  <p className="font-bold text-slate-800 dark:text-slate-200">{activeCertPreview.issueDate}</p>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Instructor Signature</span>
                  <p className="font-serif italic font-bold text-purple-700 dark:text-purple-400">{activeCertPreview.instructorName}</p>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>ID: {activeCertPreview.certificateId}</span>
                <span className="text-emerald-600 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Official CMMS Seal
                </span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <span className="text-xs text-slate-400 font-mono">Verify at: /lms#certificates</span>
              <button
                onClick={() => alert('Printing Diploma Certificate... PDF ready for official church printing.')}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl shadow-md text-xs flex items-center gap-2"
              >
                <Printer className="w-4 h-4" /> Print / Export Official Diploma
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
