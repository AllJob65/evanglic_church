import React from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { normalizeUserRole } from '../utils/rbac';
import { SuperAdminSystemDashboard } from './dashboards/SuperAdminSystemDashboard';
import { ChurchAdminDashboard } from './dashboards/ChurchAdminDashboard';
import { PastoralDashboard } from './dashboards/PastoralDashboard';
import { MinistryDashboard } from './dashboards/MinistryDashboard';
import { MemberPortalDashboard } from './dashboards/MemberPortalDashboard';

/**
 * Role-Customized Dynamic Dashboard Container
 * Renders distinct, tailored KPI panels and metrics based on the active user's role.
 */
export const DashboardView: React.FC = () => {
  const { activeRole } = useCMMS();
  const { userRole } = useAuth();

  const currentRole = normalizeUserRole(userRole || activeRole);

  switch (currentRole) {
    case 'SYSTEM_ADMIN':
      return <SuperAdminSystemDashboard />;

    case 'MANAGER':
      return <ChurchAdminDashboard />;

    case 'PASTOR':
      return <PastoralDashboard />;

    case 'MINISTRY_LEADER':
      return <MinistryDashboard />;

    case 'REGULAR_MEMBER':
    default:
      return <MemberPortalDashboard />;
  }
};

export default DashboardView;
