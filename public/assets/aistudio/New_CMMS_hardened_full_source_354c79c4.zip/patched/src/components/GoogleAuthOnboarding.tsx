import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { useCMMS } from '../context/CMMSContext';
import { validateEthiopianPhone, normalizeEthiopianPhone } from '../utils/phoneValidation';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  Mail,
  User,
  Phone,
  Building,
  Briefcase,
  MapPin,
  FileText,
  Send,
  RefreshCw,
  LogOut,
  Sparkles,
  Layers,
  ArrowRight,
  Shield,
  HelpCircle,
  Check,
  Heart,
  MessageSquare,
  Users,
  Compass,
  Radio,
  ExternalLink,
} from 'lucide-react';

interface GoogleAuthOnboardingProps {
  onSuccessApproved?: () => void;
  onBackToLogin?: () => void;
}

export const GoogleAuthOnboarding: React.FC<GoogleAuthOnboardingProps> = ({
  onSuccessApproved,
  onBackToLogin,
}) => {
  const {
    onboardingState,
    googleApplicantData,
    onboardingWorkflow,
    rejectionReason,
    setOnboardingState,
    submitGoogleOnboarding,
    checkGoogleApprovalStatus,
    logout,
    userProfile,
  } = useAuth();

  const { branches, systemName, logout: cmmsLogout, setIsAuthenticated } = useCMMS();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      localStorage.removeItem('cmms_token');
      localStorage.removeItem('cmms_auth_token');
      localStorage.removeItem('cmms_active_user');
      localStorage.removeItem('cmms_applicant_data');
      localStorage.removeItem('cmms_onboarding_state');
      localStorage.removeItem('cmms_onboarding_workflow');
      localStorage.removeItem('cmms_rejection_reason');

      setIsAuthenticated(false);
      await logout();
      if (cmmsLogout) {
        cmmsLogout();
      }
      navigate('/login', { replace: true });
    } catch (e) {
      console.error('Sign out error:', e);
      setIsAuthenticated(false);
      navigate('/login', { replace: true });
    }
  };

  // Form inputs for STATE A (New User Registration)
  const [fullName, setFullName] = useState(googleApplicantData?.name || '');
  const [email] = useState(googleApplicantData?.email || '');
  const [phone, setPhone] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [maritalStatus, setMaritalStatus] = useState<'Single' | 'Married' | 'Widowed' | 'Divorced'>('Single');
  
  // Emergency Contact
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [emergencyRelationship, setEmergencyRelationship] = useState('Sibling');

  // Ministry & Department Selection
  const [department, setDepartment] = useState('');
  const [role, setRole] = useState('Regular Member');
  const [selectedBranchId, setSelectedBranchId] = useState(branches[0]?.id || '');

  // Address
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');

  // Preferred Communication Channel
  const [commChannel, setCommChannel] = useState<'Telegram' | 'SMS' | 'Email' | 'WhatsApp'>('Telegram');

  // Spiritual Details
  const [isBaptized, setIsBaptized] = useState<'Yes' | 'No'>('Yes');
  const [previousChurch, setPreviousChurch] = useState('');
  const [notes, setNotes] = useState('');

  // Form Validation & Loading State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [formError, setFormError] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  // Handle Form Submission for State A
  const handleRegistrationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setStatusMessage('');

    if (!fullName.trim()) {
      setFormError('Please enter your full legal name.');
      return;
    }

    if (!validateEthiopianPhone(phone)) {
      setFormError('Please enter a valid Ethiopian phone number (e.g., +251 91 123 4567 or 0911234567).');
      return;
    }

    if (emergencyContactPhone && !validateEthiopianPhone(emergencyContactPhone)) {
      setFormError('Please enter a valid Ethiopian phone number for the emergency contact.');
      return;
    }

    setIsSubmitting(true);
    try {
      const sanitizedPhone = normalizeEthiopianPhone(phone);
      const sanitizedEmergency = emergencyContactPhone ? normalizeEthiopianPhone(emergencyContactPhone) : '';
      
      await submitGoogleOnboarding({
        name: fullName.trim(),
        email,
        phone: sanitizedPhone,
        department: `${department} (Comm: ${commChannel})`,
        role,
        address: `${address}, ${city} | Emergency: ${emergencyContactName} (${emergencyRelationship}, ${sanitizedEmergency}) | Baptized: ${isBaptized}`,
        city,
        notes: `${notes} | Prev Church: ${previousChurch}`,
      });
      setIsSubmitting(false);
      setStatusMessage('Registration submitted successfully! Your application is now in the pastoral review queue.');
    } catch (err: any) {
      setIsSubmitting(false);
      setFormError(err.message || 'Failed to submit registration. Please try again.');
    }
  };

  // Handle Status Check for State B
  const handleCheckStatus = async () => {
    setIsCheckingStatus(true);
    setStatusMessage('');
    try {
      const currentStatus = await checkGoogleApprovalStatus(email);
      setIsCheckingStatus(false);
      if (currentStatus === 'APPROVED') {
        setStatusMessage('Your application has been approved! Redirecting to your dashboard...');
        if (onSuccessApproved) {
          setTimeout(onSuccessApproved, 1000);
        }
      } else if (currentStatus === 'REJECTED') {
        setStatusMessage('Application decision updated: Access Denied.');
      } else {
        setStatusMessage('Status checked: Your application remains under review by Pastoral Administration.');
      }
    } catch {
      setIsCheckingStatus(false);
      setStatusMessage('Unable to check status at this time. Please try again later.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative antialiased font-montserrat selection:bg-blue-600 selection:text-white">
      
      {/* ========================================================================= */}
      {/* STATE A: NEW USER ONBOARDING REGISTRATION VIEW                            */}
      {/* ========================================================================= */}
      {onboardingState === 'NEW_USER' && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="w-full max-w-3xl bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl text-slate-100"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
            <div className="flex items-center gap-3.5">
              {googleApplicantData?.picture ? (
                <img
                  src={googleApplicantData.picture}
                  alt={googleApplicantData.name}
                  className="w-12 h-12 rounded-2xl object-cover ring-2 ring-blue-500 shadow-md"
                />
              ) : (
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-black text-lg shadow-md ring-2 ring-blue-400">
                  <User className="w-6 h-6" />
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                    Member Onboarding Registration
                  </h2>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-400/30">
                    GOOGLE VERIFIED
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Complete your church fellowship profile to request portal access.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-400 font-semibold">{systemName || 'CMMS'}</span>
            </div>
          </div>

          {/* Alert / Errors */}
          {formError && (
            <div className="mt-4 p-3.5 rounded-2xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{formError}</span>
            </div>
          )}

          {statusMessage && (
            <div className="mt-4 p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Registration Form */}
          <form onSubmit={handleRegistrationSubmit} className="mt-6 space-y-6">
            {/* 1. Identity & Google Account Info */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 flex items-center gap-2">
                <User className="w-3.5 h-3.5" />
                <span>1. Personal & Contact Information</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Full Legal Name <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="First and Last Name"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Google Account Email <span className="text-slate-500">(Verified)</span>
                  </label>
                  <input
                    type="email"
                    disabled
                    value={email}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400 text-xs cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Phone Number (Ethiopia) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="+251 91 123 4567 or 0911234567"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Gender</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as any)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Marital Status</label>
                    <select
                      value={maritalStatus}
                      onChange={(e) => setMaritalStatus(e.target.value as any)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    >
                      <option value="Single">Single</option>
                      <option value="Married">Married</option>
                      <option value="Widowed">Widowed</option>
                      <option value="Divorced">Divorced</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. Emergency Contact */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 flex items-center gap-2">
                <Heart className="w-3.5 h-3.5 text-rose-400" />
                <span>2. Emergency Contact</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Contact Name</label>
                  <input
                    type="text"
                    value={emergencyContactName}
                    onChange={(e) => setEmergencyContactName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="Emergency Contact Name"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Relationship</label>
                  <input
                    type="text"
                    value={emergencyRelationship}
                    onChange={(e) => setEmergencyRelationship(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="e.g. Spouse, Parent, Sibling"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Emergency Phone</label>
                  <input
                    type="text"
                    value={emergencyContactPhone}
                    onChange={(e) => setEmergencyContactPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="+251 92 345 6789"
                  />
                </div>
              </div>
            </div>

            {/* 3. Ministry, Department & Preferred Communication Channel */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 flex items-center gap-2">
                <Briefcase className="w-3.5 h-3.5" />
                <span>3. Ministry & Fellowship Preferences</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Primary Ministry Interest
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="Media & Tech Production">Media & Tech Production</option>
                    <option value="Worship & Choir">Worship & Choir</option>
                    <option value="Youth & Campus Fellowship">Youth & Campus Fellowship</option>
                    <option value="Ushers & Hospitality">Ushers & Hospitality</option>
                    <option value="Children & Sunday School">Children & Sunday School</option>
                    <option value="Prayer & Intercession">Prayer & Intercession</option>
                    <option value="Evangelism & Outreach">Evangelism & Outreach</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Campus Branch</label>
                  <select
                    value={selectedBranchId}
                    onChange={(e) => setSelectedBranchId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Preferred Communication Channel
                  </label>
                  <select
                    value={commChannel}
                    onChange={(e) => setCommChannel(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="Telegram">Telegram (Recommended)</option>
                    <option value="SMS">SMS Text Notification</option>
                    <option value="WhatsApp">WhatsApp</option>
                    <option value="Email">Email Digest</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 4. Address & Residency */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5" />
                <span>4. Residency & Address</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Street / Subcity / Woreda
                  </label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="e.g., Bole Subcity, Woreda 03"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">City / Region</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                    placeholder="e.g., Addis Ababa"
                  />
                </div>
              </div>
            </div>

            {/* 5. Additional Spiritual Notes */}
            <div className="space-y-2 pt-4 border-t border-slate-800">
              <label className="block text-xs font-semibold text-slate-300">
                Spiritual Background & Fellowship Notes
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-hidden"
                placeholder="Share any background details or ministry areas you'd like to join..."
              />
            </div>

            {/* Submit Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => {
                  if (onBackToLogin) {
                    onBackToLogin();
                  } else {
                    logout();
                    navigate('/login');
                  }
                }}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 rounded-xl text-xs font-bold border border-slate-700 transition-all cursor-pointer"
              >
                Back To Sign in
              </button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Submitting Application...</span>
                  </>
                ) : (
                  <>
                    <span>Submit for Pastoral Review</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </motion.button>
            </div>
          </form>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* STATE B: PENDING PASTORAL APPROVAL VIEW                                   */}
      {/* ========================================================================= */}
      {onboardingState === 'PENDING' && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="w-full max-w-xl bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl text-center space-y-6"
        >
          {/* Animated Status Icon */}
          <div className="relative mx-auto w-20 h-20">
            <div className="absolute inset-0 rounded-3xl bg-amber-500/20 animate-ping rounded-full" />
            <div className="relative w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white shadow-xl shadow-amber-500/20 border border-amber-400/40">
              <Clock className="w-10 h-10 animate-pulse" />
            </div>
          </div>

          <div>
            <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-500/10 text-amber-300 border border-amber-500/30 inline-block mb-3">
              APPLICATION UNDER REVIEW
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Pending Pastoral Approval
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-md mx-auto leading-relaxed">
              Your Google Onboarding registration has been received and queued in the Pastoral Approval Workflow.
            </p>
          </div>

          {/* Applicant Snapshot Box */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-left space-y-2.5 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400 font-semibold">Applicant:</span>
              <span className="text-white font-bold">{userProfile?.name || googleApplicantData?.name || 'Applicant'}</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400 font-semibold">Registered Email:</span>
              <span className="text-blue-400 font-mono">{userProfile?.email || googleApplicantData?.email}</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400 font-semibold">Application Reference:</span>
              <span className="text-amber-400 font-mono font-bold">{onboardingWorkflow?.requestCode || 'APP-2026-9812'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400 font-semibold">Campus:</span>
              <span className="text-slate-300 font-semibold">{userProfile?.branchName || 'Headquarters Campus'}</span>
            </div>
          </div>

          {/* Live Status Refresh Message */}
          {statusMessage && (
            <div className="p-3 rounded-xl bg-blue-950/50 border border-blue-800 text-blue-300 text-xs">
              {statusMessage}
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleCheckStatus}
              disabled={isCheckingStatus}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isCheckingStatus ? 'animate-spin' : ''}`} />
              <span>{isCheckingStatus ? 'Checking Status...' : 'Check Approval Status'}</span>
            </motion.button>
          </div>

          <button
            type="button"
            onClick={handleSignOut}
            className="text-xs text-slate-500 hover:text-slate-300 transition-colors pt-2 block mx-auto cursor-pointer"
          >
            Sign Out of Account
          </button>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* STATE C: APPROVED NOTIFICATION VIEW                                      */}
      {/* ========================================================================= */}
      {onboardingState === 'APPROVED' && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="w-full max-w-lg bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl text-center space-y-6"
        >
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xl shadow-emerald-500/20 border border-emerald-400/40">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div>
            <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 inline-block mb-3">
              MEMBERSHIP APPROVED
            </span>
            <h2 className="text-2xl font-black text-white tracking-tight">
              Welcome to the Fellowship!
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-md mx-auto leading-relaxed">
              Your member account is fully active with tenant-scoped permissions and real-time collaboration privileges.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onSuccessApproved}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-sm shadow-xl shadow-blue-600/40 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Enter Member Portal Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </motion.button>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* STATE D: ACCESS REJECTED / SUSPENDED VIEW                                */}
      {/* ========================================================================= */}
      {onboardingState === 'REJECTED' && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="w-full max-w-lg bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl text-center space-y-6"
        >
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-rose-600 to-red-500 flex items-center justify-center text-white shadow-xl shadow-rose-500/20 border border-rose-400/40">
            <XCircle className="w-10 h-10" />
          </div>

          <div>
            <span className="px-3 py-1 rounded-full text-xs font-black bg-rose-500/10 text-rose-300 border border-rose-500/30 inline-block mb-3">
              ACCESS NOT APPROVED
            </span>
            <h2 className="text-2xl font-black text-white tracking-tight">
              Application Declined
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-md mx-auto leading-relaxed">
              Pastoral Administration was unable to approve your membership request at this time.
            </p>
          </div>

          {rejectionReason && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-900/60 text-left">
              <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wider block mb-1">
                Reason Provided by Pastoral Review:
              </span>
              <p className="text-xs text-rose-200">{rejectionReason}</p>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setOnboardingState('NEW_USER')}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 cursor-pointer"
            >
              Re-apply with Updated Info
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSignOut}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 cursor-pointer"
            >
              Sign Out
            </motion.button>
          </div>
        </motion.div>
      )}
    </div>
  );
};
