import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useAuth } from '../context/AuthContext';
import { ProfileChangeRequest, WorkflowRequest, Member } from '../types';
import { ShareRegistrationLinkModal } from './ShareRegistrationLinkModal';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  AlertCircle,
  AlertTriangle,
  FileCheck,
  Filter,
  Search,
  ArrowRight,
  Sparkles,
  Eye,
  Check,
  X,
  Building,
  UserCheck,
  Briefcase,
  Heart,
  Activity,
  Award,
  Layers,
  MessageSquare,
  Send,
  ExternalLink,
  ChevronRight,
  Shield,
  FileText,
  UserPlus,
  Compass,
  Link2,
} from 'lucide-react';

export const ApprovalsModule: React.FC = () => {
  const {
    profileChangeRequests,
    approveProfileChangeRequest,
    rejectProfileChangeRequest,
    workflows,
    updateWorkflowStatus,
    members,
    currentUser,
    permissions,
    activeRole,
    branches,
    ministries,
  } = useCMMS();

  const { onboardingState } = useAuth();

  // Top Section View Mode & Directional Slide Animation
  type ApprovalTabId = 'members' | 'profile_changes' | 'workflows';
  const APPROVAL_TAB_ORDER: ApprovalTabId[] = ['members', 'profile_changes', 'workflows'];
  const [activeTab, setActiveTab] = useState<ApprovalTabId>('members');
  const [tabSlideDirection, setTabSlideDirection] = useState<'left' | 'right'>('right');
  const [tabAnimKey, setTabAnimKey] = useState(0);
  const tabScrollContainerRef = useRef<HTMLDivElement | null>(null);
  const swipeTouchStartXRef = useRef<number | null>(null);
  const swipeTouchStartYRef = useRef<number | null>(null);

  const handleSelectTab = (nextTab: ApprovalTabId) => {
    if (nextTab === activeTab) return;
    const prevIdx = APPROVAL_TAB_ORDER.indexOf(activeTab);
    const nextIdx = APPROVAL_TAB_ORDER.indexOf(nextTab);
    setTabSlideDirection(nextIdx >= prevIdx ? 'right' : 'left');
    setTabAnimKey((k) => k + 1);
    setActiveTab(nextTab);
  };

  useEffect(() => {
    const container = tabScrollContainerRef.current;
    if (!container) return;
    const activeBtn = container.querySelector<HTMLElement>(`[data-approval-tab="${activeTab}"]`);
    if (activeBtn) {
      activeBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }, [activeTab]);

  const handlePanelTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1) return;
    swipeTouchStartXRef.current = e.touches[0].clientX;
    swipeTouchStartYRef.current = e.touches[0].clientY;
  };

  const handlePanelTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (swipeTouchStartXRef.current === null || swipeTouchStartYRef.current === null) return;
    const deltaX = e.changedTouches[0].clientX - swipeTouchStartXRef.current;
    const deltaY = e.changedTouches[0].clientY - swipeTouchStartYRef.current;
    swipeTouchStartXRef.current = null;
    swipeTouchStartYRef.current = null;

    // Trigger horizontal tab change on deliberate horizontal swipe
    if (Math.abs(deltaX) > 65 && Math.abs(deltaX) > Math.abs(deltaY) * 1.6) {
      const currentIdx = APPROVAL_TAB_ORDER.indexOf(activeTab);
      if (deltaX < 0 && currentIdx < APPROVAL_TAB_ORDER.length - 1) {
        handleSelectTab(APPROVAL_TAB_ORDER[currentIdx + 1]);
      } else if (deltaX > 0 && currentIdx > 0) {
        handleSelectTab(APPROVAL_TAB_ORDER[currentIdx - 1]);
      }
    }
  };

  // Filter & Search states
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('Pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [actionSuccessMsg, setActionSuccessMsg] = useState('');
  const [actionErrorMsg, setActionErrorMsg] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Approval page now shows strictly Pending membership applications
  const memberWorkflows = useMemo(
    () => workflows.filter((w) => w.requestType === 'Membership Application' && w.status === 'Pending'),
    [workflows]
  );

  // Synchronized Selection
  const [selectedMemberWf, setSelectedMemberWf] = useState<WorkflowRequest | null>(null);

  useEffect(() => {
    if (!selectedMemberWf) {
      if (memberWorkflows.length > 0) {
        setSelectedMemberWf(memberWorkflows[0]);
      }
    } else {
      const match = memberWorkflows.find((w) => w.id === selectedMemberWf.id);
      if (!match) {
        // Current item was approved or rejected (no longer pending), advance to next pending item
        setSelectedMemberWf(memberWorkflows[0] || null);
      } else if (match !== selectedMemberWf) {
        setSelectedMemberWf(match);
      }
    }
  }, [memberWorkflows, selectedMemberWf]);

  // Profile Change Selection
  const [selectedProfileReq, setSelectedProfileReq] = useState<ProfileChangeRequest | null>(
    profileChangeRequests[0] || null
  );

  useEffect(() => {
    if (!selectedProfileReq) {
      if (profileChangeRequests.length > 0) {
        setSelectedProfileReq(profileChangeRequests[0]);
      }
    } else {
      const match = profileChangeRequests.find((r) => r.id === selectedProfileReq.id);
      if (!match) {
        setSelectedProfileReq(profileChangeRequests[0] || null);
      } else if (match !== selectedProfileReq) {
        setSelectedProfileReq(match);
      }
    }
  }, [profileChangeRequests, selectedProfileReq]);

  // General Workflow Selection
  const generalWorkflows = workflows.filter((w) => w.requestType !== 'Membership Application');
  const [selectedGenWf, setSelectedGenWf] = useState<WorkflowRequest | null>(
    generalWorkflows[0] || null
  );

  // Modals
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [rejectTargetType, setRejectTargetType] = useState<'member' | 'profile' | 'workflow'>('member');
  const [rejectTargetId, setRejectTargetId] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [smsModalOpen, setSmsModalOpen] = useState(false);
  const [smsText, setSmsText] = useState('');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Member Tab Sub-navigation for Detailed Dossier
  const [dossierTab, setDossierTab] = useState<'personal' | 'contact' | 'spiritual' | 'emergency' | 'covenant'>('personal');

  // Count summaries
  const pendingMemberCount = memberWorkflows.length;
  const pendingProfileCount = profileChangeRequests.filter((r) => r.status === 'Pending').length;
  const pendingGeneralWfCount = generalWorkflows.filter((w) => w.status === 'Pending').length;

  const handleApproveMember = async (wfId: string) => {
    setIsProcessing(true);
    setActionErrorMsg('');
    setActionSuccessMsg('');
    try {
      await updateWorkflowStatus(
        wfId,
        'Approved',
        'Approved by Elder Board & Pastoral Council',
        currentUser?.name || currentUser?.email || 'Authorized Pastor / Admin'
      );
      setActionSuccessMsg('Membership application successfully approved! Member ID activated & welcome SMS dispatched.');
      setTimeout(() => setActionSuccessMsg(''), 4000);
    } catch (err: any) {
      console.error('[Approvals] Membership approval failed:', err);
      setActionErrorMsg(err?.message || 'Failed to approve application. Backend persistence error.');
      setTimeout(() => setActionErrorMsg(''), 6000);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApproveProfile = (reqId: string) => {
    approveProfileChangeRequest(reqId, currentUser?.name || 'System Administrator');
    setActionSuccessMsg('Profile change request approved and database updated successfully!');
    setTimeout(() => setActionSuccessMsg(''), 4000);
  };

  const handleApproveGenWf = async (wfId: string) => {
    setIsProcessing(true);
    setActionErrorMsg('');
    setActionSuccessMsg('');
    try {
      await updateWorkflowStatus(
        wfId,
        'Approved',
        'Approved by administration',
        currentUser?.name || 'System Administrator'
      );
      setActionSuccessMsg('Workflow request approved and marked in governance audit ledger.');
      setTimeout(() => setActionSuccessMsg(''), 4000);
    } catch (err: any) {
      console.error('[Approvals] Workflow approval failed:', err);
      setActionErrorMsg(err?.message || 'Failed to approve workflow request on backend.');
      setTimeout(() => setActionErrorMsg(''), 6000);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleOpenReject = (type: 'member' | 'profile' | 'workflow', id: string) => {
    setRejectTargetType(type);
    setRejectTargetId(id);
    setRejectReason('');
    setRejectModalOpen(true);
  };

  const handleConfirmReject = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setActionErrorMsg('');
    setActionSuccessMsg('');
    try {
      if (rejectTargetType === 'member' || rejectTargetType === 'workflow') {
        await updateWorkflowStatus(
          rejectTargetId,
          'Rejected',
          rejectReason || 'Application rejected by administration.',
          currentUser?.name || 'System Administrator'
        );
        setActionSuccessMsg('Request rejected with feedback logged to audit trail.');
      } else if (rejectTargetType === 'profile') {
        rejectProfileChangeRequest(
          rejectTargetId,
          rejectReason || 'Details could not be verified by administration'
        );
        setActionSuccessMsg('Profile update rejected with feedback logged.');
      }
      setRejectModalOpen(false);
      setTimeout(() => setActionSuccessMsg(''), 4000);
    } catch (err: any) {
      console.error('[Approvals] Rejection failed:', err);
      setActionErrorMsg(err?.message || 'Failed to reject request. Backend persistence error.');
      setTimeout(() => setActionErrorMsg(''), 6000);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendVerificationSms = (e: React.FormEvent) => {
    e.preventDefault();
    setSmsModalOpen(false);
    setActionSuccessMsg(`Verification request and security PIN sent to candidate's mobile phone.`);
    setTimeout(() => setActionSuccessMsg(''), 4000);
  };

  // Helper for formatting field keys
  const formatFieldLabel = (key: string) => {
    switch (key) {
      case 'primaryPhone': return 'Primary Phone Number';
      case 'altPhone': return 'Alternative Phone';
      case 'email': return 'Email Address';
      case 'maritalStatus': return 'Marital Status';
      case 'spouseName': return 'Spouse Full Name';
      case 'spousePhone': return 'Spouse Phone Number';
      case 'streetAddress': return 'Street / Residence Address';
      case 'city': return 'City';
      case 'subCity': return 'Sub-City';
      case 'woreda': return 'Woreda';
      case 'kebele': return 'Kebele';
      case 'houseNumber': return 'House Number';
      case 'occupation': return 'Current Occupation';
      case 'emergencyContact': return 'Emergency Contact';
      case 'preferredCommChannel': return 'Communication Channel';
      default: return key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());
    }
  };

  const renderFieldValue = (val: any, fieldName?: string) => {
    if (val === null || val === undefined || val === '') return <span className="text-slate-400 italic">Not Provided</span>;
    if (typeof val === 'boolean') return val ? 'Yes' : 'No';
    if (fieldName === 'branchId' && typeof val === 'string') {
      const b = branches.find((br) => br.id === val);
      return b ? b.name : val;
    }
    if (fieldName === 'ministryIds' && Array.isArray(val)) {
      if (val.length === 0) return <span className="text-slate-400 italic">None</span>;
      return val
        .map((id) => ministries.find((m) => m.id === id)?.name || id)
        .join(', ');
    }
    if (fieldName === 'profilePhoto' && typeof val === 'string') {
      return (
        <div className="flex items-center gap-2 mt-1">
          <img
            src={val}
            alt="Profile preview"
            className="w-12 h-12 rounded-xl object-cover border border-slate-300 dark:border-slate-700"
          />
          <span className="text-[11px] opacity-75">Photo Updated</span>
        </div>
      );
    }
    if (Array.isArray(val)) {
      if (val.length === 0) return <span className="text-slate-400 italic">None</span>;
      if (typeof val[0] === 'object' && val[0] !== null) {
        return val
          .map((item: any) =>
            item.name
              ? `${item.name} (${item.relationshipType || item.relationship || 'Relation'}${item.phone ? ` - ${item.phone}` : ''})`
              : JSON.stringify(item)
          )
          .join('; ');
      }
      return val.join(', ');
    }
    if (typeof val === 'object') {
      if (val.name) return `${val.name} (${val.relationship || 'Contact'} - ${val.phone || ''})`;
      return JSON.stringify(val);
    }
    return String(val);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-purple-500/10 text-purple-600 dark:bg-purple-950 dark:text-purple-400 border border-purple-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
               Approvals Hub
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Review pending membership applications, member profile modifications, and multi-campus requisitions.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="p-3 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-900 text-xs font-semibold text-purple-900 dark:text-purple-300">
            Current Sign-off Power: <strong>{activeRole}</strong>
          </div>
        </div>
      </div>

      {/* Persistence Error Notification Alert */}
      {actionErrorMsg && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/50 border border-rose-300 dark:border-rose-800 rounded-2xl text-xs font-bold text-rose-800 dark:text-rose-300 flex items-center gap-2 shadow-xs animate-in fade-in slide-in-from-top-2">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{actionErrorMsg}</span>
        </div>
      )}

      {/* Success Notification Alert */}
      {actionSuccessMsg && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2 shadow-xs animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Primary Tab Selector - Single-Row Horizontal Swipe/Slide Scroll with Animation on Mobile */}
      <div
        ref={tabScrollContainerRef}
        role="tablist"
        aria-label="Approval categories"
        className="flex flex-nowrap items-center gap-1.5 sm:gap-2 bg-slate-100/95 dark:bg-slate-800/70 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory touch-pan-x max-w-full select-none"
      >
        <button
          type="button"
          role="tab"
          aria-selected={activeTab === 'members'}
          data-approval-tab="members"
          onClick={() => handleSelectTab('members')}
          className={`relative shrink-0 whitespace-nowrap snap-center flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-bold transition-all duration-300 ease-out active:scale-95 cursor-pointer ${
            activeTab === 'members'
              ? `bg-white dark:bg-slate-900 text-purple-700 dark:text-purple-300 shadow-sm ring-1 ring-purple-500/20 scale-[1.01] animate-in fade-in ${
                  tabSlideDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
                }`
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-900/40'
          }`}
        >
          <UserPlus className={`w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0 transition-transform duration-300 ${activeTab === 'members' ? 'scale-110 text-purple-600 dark:text-purple-400' : ''}`} />
          <span>Pending Member Registrations</span>
          {pendingMemberCount > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-600 text-white shrink-0">
              {pendingMemberCount}
            </span>
          )}
          {activeTab === 'members' && (
            <span className="absolute bottom-0.5 left-4 right-4 h-0.5 rounded-full bg-purple-600 dark:bg-purple-400" />
          )}
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={activeTab === 'profile_changes'}
          data-approval-tab="profile_changes"
          onClick={() => handleSelectTab('profile_changes')}
          className={`relative shrink-0 whitespace-nowrap snap-center flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-bold transition-all duration-300 ease-out active:scale-95 cursor-pointer ${
            activeTab === 'profile_changes'
              ? `bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-300 shadow-sm ring-1 ring-blue-500/20 scale-[1.01] animate-in fade-in ${
                  tabSlideDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
                }`
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-900/40'
          }`}
        >
          <FileCheck className={`w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0 transition-transform duration-300 ${activeTab === 'profile_changes' ? 'scale-110 text-blue-600 dark:text-blue-400' : ''}`} />
          <span>Member Profile Change Requests</span>
          {pendingProfileCount > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-600 text-white shrink-0">
              {pendingProfileCount}
            </span>
          )}
          {activeTab === 'profile_changes' && (
            <span className="absolute bottom-0.5 left-4 right-4 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400" />
          )}
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={activeTab === 'workflows'}
          data-approval-tab="workflows"
          onClick={() => handleSelectTab('workflows')}
          className={`relative shrink-0 whitespace-nowrap snap-center flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-[11px] sm:text-xs font-bold transition-all duration-300 ease-out active:scale-95 cursor-pointer ${
            activeTab === 'workflows'
              ? `bg-white dark:bg-slate-900 text-amber-700 dark:text-amber-300 shadow-sm ring-1 ring-amber-500/20 scale-[1.01] animate-in fade-in ${
                  tabSlideDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
                }`
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-900/40'
          }`}
        >
          <Layers className={`w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0 transition-transform duration-300 ${activeTab === 'workflows' ? 'scale-110 text-amber-600 dark:text-amber-400' : ''}`} />
          <span>Governance & Budget Workflows</span>
          {pendingGeneralWfCount > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-600 text-white shrink-0">
              {pendingGeneralWfCount}
            </span>
          )}
          {activeTab === 'workflows' && (
            <span className="absolute bottom-0.5 left-4 right-4 h-0.5 rounded-full bg-amber-600 dark:bg-amber-400" />
          )}
        </button>
      </div>

      {/* Animated Swipeable Content Wrapper */}
      <div
        key={`${activeTab}-${tabAnimKey}`}
        onTouchStart={handlePanelTouchStart}
        onTouchEnd={handlePanelTouchEnd}
        className={`animate-in fade-in duration-300 ease-out ${
          tabSlideDirection === 'right' ? 'slide-in-from-right' : 'slide-in-from-left'
        }`}
      >

      {/* ========================================================================= */}
      {/* TAB 1: PENDING MEMBER REGISTRATIONS & FULL DOSSIER INSPECTION */}
      {/* ========================================================================= */}
      {activeTab === 'members' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: List of Pending Member Applications */}
          <div className="lg:col-span-4 space-y-3">
            <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                  Applications Queue ({memberWorkflows.length})
                </h3>
                <button
                  onClick={() => setIsShareModalOpen(true)}
                  className="px-2.5 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 dark:bg-purple-950 dark:hover:bg-purple-900 text-purple-700 dark:text-purple-300 text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                  title="Share Google-Form Style Registration Link"
                >
                  <Link2 className="w-3 h-3" />
                  <span>Share Form Link</span>
                </button>
              </div>

              {/* Search Bar */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search applicant name, phone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            {/* Candidate List Cards */}
            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {memberWorkflows
                .filter((w) =>
                  w.requesterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  (w.requesterPhone && w.requesterPhone.includes(searchQuery)) ||
                  w.requestCode.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .map((wf) => {
                  const isSelected = selectedMemberWf?.id === wf.id;
                  const pData = wf.pendingMemberData;

                  return (
                    <div
                      key={wf.id}
                      onClick={() => setSelectedMemberWf(wf)}
                      className={`p-4 rounded-3xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-purple-50/80 dark:bg-purple-950/30 border-purple-500 shadow-md ring-1 ring-purple-400/50'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-purple-300 dark:hover:border-purple-800'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <img
                          src={
                            pData?.photoUrl ||
                            'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'
                          }
                          alt={wf.requesterName}
                          className="w-12 h-12 rounded-2xl object-cover border border-purple-200 dark:border-purple-800 shrink-0"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-[10px] font-black text-purple-600 dark:text-purple-400">
                              {wf.requestCode}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                wf.status === 'Approved'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : wf.status === 'Rejected'
                                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              }`}
                            >
                              {wf.status}
                            </span>
                          </div>

                          <h4 className="font-bold text-xs text-slate-900 dark:text-white mt-1 truncate">
                            {pData?.title && <span className="text-purple-600 font-normal">{pData.title} </span>}
                            {wf.requesterName}
                          </h4>

                          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                            {wf.branchName}
                          </p>

                          <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" /> {wf.submittedDate}
                            </span>
                            <span>•</span>
                            <span className="font-mono text-purple-600 dark:text-purple-400 font-bold">
                              {pData?.memberIdNumber || 'ID Pending'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

              {memberWorkflows.length === 0 && (
                <div className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-400">
                  No membership registration applications pending.
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Full Candidate Information Dossier */}
          <div className="lg:col-span-8">
            {selectedMemberWf ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden space-y-6">
                {/* Dossier Top Banner & Identity Header */}
                <div className="p-6 bg-gradient-to-r from-purple-900 via-indigo-950 to-slate-950 text-white">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img
                        src={
                          selectedMemberWf.pendingMemberData?.photoUrl ||
                          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
                        }
                        alt={selectedMemberWf.requesterName}
                        className="w-20 h-20 rounded-3xl object-cover border-2 border-purple-400/50 shadow-xl"
                      />

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-purple-500/30 text-purple-200 border border-purple-400/40">
                            {selectedMemberWf.pendingMemberData?.membershipType || 'Candidate For Membership'}
                          </span>
                          <span className="font-mono text-xs text-purple-300 font-bold">
                            {selectedMemberWf.requestCode}
                          </span>
                        </div>

                        <h2 className="text-xl sm:text-2xl font-black mt-1">
                          {selectedMemberWf.pendingMemberData?.title}{' '}
                          {selectedMemberWf.requesterName}
                        </h2>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-purple-200 mt-1">
                          <span className="flex items-center gap-1">
                            <Building className="w-3.5 h-3.5" /> {selectedMemberWf.branchName}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Phone className="w-3.5 h-3.5" /> {selectedMemberWf.requesterPhone || selectedMemberWf.pendingMemberData?.primaryPhone}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Quick Status Tag */}
                    <div className="text-right">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                          selectedMemberWf.status === 'Approved'
                            ? 'bg-emerald-500 text-white'
                            : selectedMemberWf.status === 'Rejected'
                            ? 'bg-rose-500 text-white'
                            : 'bg-amber-500 text-slate-950 font-black'
                        }`}
                      >
                        {selectedMemberWf.status} Review
                      </span>
                      <p className="text-[11px] text-purple-300 mt-1">
                        Step: {selectedMemberWf.currentStep}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Dossier Navigation Tabs */}
                <div className="px-6 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-2 text-xs">
                  {[
                    { id: 'personal', label: 'Personal & Demographic Profile', icon: User },
                    { id: 'contact', label: 'Contact & Residential Location', icon: MapPin },
                    { id: 'spiritual', label: 'Spiritual Background & Ministries', icon: Award },
                    { id: 'emergency', label: 'Emergency Contact & Health', icon: Heart },
                    { id: 'covenant', label: 'Statement of Faith & Security Tier', icon: ShieldCheck },
                  ].map((tab) => {
                    const Icon = tab.icon;
                    const isActive = dossierTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setDossierTab(tab.id as any)}
                        className={`flex items-center gap-1.5 py-3 px-3 font-bold border-b-2 transition-all cursor-pointer ${
                          isActive
                            ? 'border-purple-600 text-purple-600 dark:text-purple-400'
                            : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Dossier Content Body */}
                <div className="p-6 pt-0 space-y-6">
                  {/* SUB-TAB 1: PERSONAL & DEMOGRAPHIC */}
                  {dossierTab === 'personal' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Full Name & Title</span>
                        <p className="font-extrabold text-sm text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.title} {selectedMemberWf.pendingMemberData?.firstName} {selectedMemberWf.pendingMemberData?.middleName} {selectedMemberWf.pendingMemberData?.lastName}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Assigned Member ID Number</span>
                        <p className="font-mono font-bold text-sm text-purple-600 dark:text-purple-400">
                          {selectedMemberWf.pendingMemberData?.memberIdNumber || 'To Be Generated Upon Approval'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Gender & Date of Birth</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.gender} • Born {selectedMemberWf.pendingMemberData?.dateOfBirth}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Marital Status & Family</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.maritalStatus}
                          {selectedMemberWf.pendingMemberData?.spouseName && (
                            <span> (Spouse: {selectedMemberWf.pendingMemberData.spouseName})</span>
                          )}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Occupation & Profession</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.occupation || 'Not Specified'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Employer & Sector</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.employer || 'Self-Employed / Independent'} ({selectedMemberWf.pendingMemberData?.employerType || 'Private'})
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1 sm:col-span-2">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Languages Spoken</span>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {selectedMemberWf.pendingMemberData?.languagesSpoken?.map((lang) => (
                            <span key={lang} className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold text-slate-800 dark:text-slate-200">
                              {lang}
                            </span>
                          )) || <span className="text-slate-400">English, Amharic</span>}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SUB-TAB 2: CONTACT & RESIDENCE */}
                  {dossierTab === 'contact' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Primary Mobile Phone</span>
                        <p className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                          <Phone className="w-4 h-4 text-purple-600" />
                          {selectedMemberWf.pendingMemberData?.primaryPhone || selectedMemberWf.requesterPhone}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Email Address</span>
                        <p className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                          <Mail className="w-4 h-4 text-purple-600" />
                          {selectedMemberWf.pendingMemberData?.email || selectedMemberWf.requesterEmail}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1 sm:col-span-2">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Residential Street Address</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.streetAddress || 'No Street Address Submitted'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">City & Sub-City</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.city}, {selectedMemberWf.pendingMemberData?.subCity || 'N/A'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Woreda, Kebele & House #</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.woreda || 'Woreda'} • {selectedMemberWf.pendingMemberData?.kebele || 'Kebele'} • House #{selectedMemberWf.pendingMemberData?.houseNumber || 'N/A'}
                        </p>
                      </div>

                      <div className="p-4 bg-purple-50 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-900 space-y-1 sm:col-span-2">
                        <span className="text-purple-700 dark:text-purple-400 font-bold uppercase text-[10px]">Assigned Campus Branch</span>
                        <p className="font-black text-sm text-purple-950 dark:text-purple-200">
                          {selectedMemberWf.branchName}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* SUB-TAB 3: SPIRITUAL BACKGROUND & MINISTRIES */}
                  {dossierTab === 'spiritual' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Water Baptism Status</span>
                        <div className="flex items-center gap-2 pt-0.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <p className="font-extrabold text-slate-900 dark:text-white">
                            {selectedMemberWf.pendingMemberData?.waterBaptized ? 'Baptized in Water' : 'Pending Water Baptism'}
                            {selectedMemberWf.pendingMemberData?.baptismDate && (
                              <span className="text-slate-400 font-normal"> ({selectedMemberWf.pendingMemberData.baptismDate})</span>
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Salvation / Born-Again Date</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.salvationDate || 'Confirmed by Pastoral Interview'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Previous Church Fellowship</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.previousChurch || 'New Believer (First Church Home)'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Discipleship & Foundations Class</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.discipleshipLevel || 'Foundations Class Enrolled'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 sm:col-span-2">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Ministry Placements & Volunteering Interests</span>
                        <div className="flex flex-wrap gap-2">
                          {selectedMemberWf.pendingMemberData?.skillsAndTalents?.map((skill) => (
                            <span key={skill} className="px-3 py-1.5 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 font-bold border border-purple-200 dark:border-purple-800">
                              ★ {skill}
                            </span>
                          )) || <span className="text-slate-400">Ushering, Choir, Media & Audio</span>}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SUB-TAB 4: EMERGENCY CONTACT & HEALTH */}
                  {dossierTab === 'emergency' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Next of Kin / Emergency Contact Name</span>
                        <p className="font-bold text-sm text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.emergencyContact?.name || 'Parent / Relative'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Emergency Phone Number</span>
                        <p className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                          <Phone className="w-4 h-4 text-rose-500" />
                          {selectedMemberWf.pendingMemberData?.emergencyContact?.phone || 'Not Provided'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Blood Type Group</span>
                        <p className="font-mono font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.bloodType || 'O+'}
                        </p>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <span className="text-slate-400 font-bold uppercase text-[10px]">Known Allergies & Medical Notes</span>
                        <p className="font-bold text-slate-900 dark:text-white">
                          {selectedMemberWf.pendingMemberData?.knownAllergies?.join(', ') || 'No Known Medical Allergies'}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* SUB-TAB 5: COVENANT & SECURITY */}
                  {dossierTab === 'covenant' && (
                    <div className="space-y-4 text-xs">
                      <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 flex items-start gap-3">
                        <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                        <div className="space-y-1">
                          <h4 className="font-bold text-emerald-900 dark:text-emerald-200">
                            Covenant of Fellowship & Statement of Faith Digitally Accepted
                          </h4>
                          <p className="text-emerald-800 dark:text-emerald-300 text-[11px]">
                            Candidate agreed to the Scripture doctrines, biblical governance, financial transparency, and active ministry participation guidelines of Grace Cathedral Sovereign CMMS.
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700">
                          <span className="text-slate-400 font-bold uppercase text-[10px] block">Role Clearance</span>
                          <span className="font-bold text-slate-900 dark:text-white">Regular Member</span>
                        </div>
                        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700">
                          <span className="text-slate-400 font-bold uppercase text-[10px] block">Financial Authority Limit</span>
                          <span className="font-bold text-slate-900 dark:text-white">$0.00 (Standard Member)</span>
                        </div>
                        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700">
                          <span className="text-slate-400 font-bold uppercase text-[10px] block">Self-Service Portal Access</span>
                          <span className="font-bold text-emerald-600">Enabled</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Administrative Action Control Bar */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setSmsText(`Dear ${selectedMemberWf.requesterName}, your Grace Cathedral membership application is under pastoral review. Please present your verification ID at the church admin office.`);
                          setSmsModalOpen(true);
                        }}
                        className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Send SMS Prompt</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      {selectedMemberWf.status === 'Pending' ? (
                        <>
                          <button
                            onClick={() => handleOpenReject('member', selectedMemberWf.id)}
                            disabled={isProcessing}
                            className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 disabled:opacity-50 dark:bg-rose-950/50 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                          >
                            <XCircle className="w-4 h-4" />
                            <span>Reject With Reason</span>
                          </button>

                          <button
                            onClick={() => handleApproveMember(selectedMemberWf.id)}
                            disabled={isProcessing}
                            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-black flex items-center gap-2 shadow-md transition-all cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{isProcessing ? 'Committing Approval...' : 'Approve & Activate Member ID'}</span>
                          </button>
                        </>
                      ) : (
                        <span className="text-slate-400 font-bold">
                          Decision recorded: {selectedMemberWf.status} by {selectedMemberWf.approvedBy || 'System Administrator'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
                <UserCheck className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm">Select Candidate to View Dossier</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Click any applicant from the left queue to inspect their complete personal, spiritual, contact, and ministry records.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: PROFILE MODIFICATION REQUESTS (FIELD-BY-FIELD DIFF) */}
      {/* ========================================================================= */}
      {activeTab === 'profile_changes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Request List */}
          <div className="lg:col-span-4 space-y-3">
            <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                  Profile Change Queue ({profileChangeRequests.length})
                </h3>
                <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400">
                  {pendingProfileCount} Pending Sign-off
                </span>
              </div>
            </div>

            <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
              {profileChangeRequests.map((req) => {
                const isSelected = selectedProfileReq?.id === req.id;
                return (
                  <div
                    key={req.id}
                    onClick={() => setSelectedProfileReq(req)}
                    className={`p-4 rounded-3xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50/80 dark:bg-blue-950/30 border-blue-500 shadow-md ring-1 ring-blue-400/50'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] font-bold text-blue-600 dark:text-blue-400">
                        {req.id}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          req.status === 'Approved'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : req.status === 'Rejected'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <h4 className="font-bold text-xs text-slate-900 dark:text-white mt-1.5 truncate">
                      {req.memberName}
                    </h4>
                    <p className="text-[11px] text-slate-500 truncate">
                      {req.memberIdNumber} • {req.changedFields.length} field modifications
                    </p>
                    <p className="text-[10px] text-slate-400 mt-1">Submitted {req.submittedAt}</p>
                  </div>
                );
              })}

              {profileChangeRequests.length === 0 && (
                <div className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-400">
                  No profile modification requests submitted.
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Field Difference Comparison */}
          <div className="lg:col-span-8">
            {selectedProfileReq ? (
              <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
                  <div>
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                      {selectedProfileReq.id} • {selectedProfileReq.memberIdNumber}
                    </span>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                      {selectedProfileReq.memberName}
                    </h3>
                  </div>

                  {selectedProfileReq.status === 'Pending' ? (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleOpenReject('profile', selectedProfileReq.id)}
                        className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleApproveProfile(selectedProfileReq.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                      >
                        Approve Changes
                      </button>
                    </div>
                  ) : (
                    <div className="text-right">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold ${
                          selectedProfileReq.status === 'Approved'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {selectedProfileReq.status}
                      </span>
                      {selectedProfileReq.reviewedAt && (
                        <p className="text-[11px] text-slate-400 mt-1">
                          Reviewed {selectedProfileReq.reviewedAt}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Diff View Cards */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs uppercase text-slate-400">
                    Field Modifications ({selectedProfileReq.changedFields.length})
                  </h4>

                  {selectedProfileReq.changedFields.map((f, i) => (
                    <div key={i} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
                      <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                        {f.fieldLabel}
                      </span>
                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900/50">
                          <span className="text-[10px] font-bold text-rose-700 dark:text-rose-400 block uppercase">Previous Value</span>
                          <span className="font-semibold text-rose-950 dark:text-rose-200 break-words">{renderFieldValue(f.oldValue, f.fieldKey)}</span>
                        </div>
                        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900/50">
                          <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 block uppercase">Requested Value</span>
                          <span className="font-extrabold text-emerald-950 dark:text-emerald-200 break-words">{renderFieldValue(f.newValue, f.fieldKey)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
                <FileCheck className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm">Select Profile Request</h3>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: GOVERNANCE & BUDGET WORKFLOWS */}
      {/* ========================================================================= */}
      {activeTab === 'workflows' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Active Sign-off Queue</h3>
              <p className="text-xs text-slate-500">Multi-campus authorizations for branch transfers, equipment requisitions, and budget items.</p>
            </div>
          </div>

          <div className="space-y-3">
            {generalWorkflows.map((wf) => (
              <div
                key={wf.id}
                className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-purple-600 dark:text-purple-400">
                    {wf.requestCode}
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                      wf.status === 'Approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : wf.status === 'Rejected'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {wf.status}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">{wf.requestType}</h4>
                  <p className="text-slate-500 text-xs mt-0.5">{wf.details}</p>
                  <p className="text-slate-400 text-[11px] mt-1">
                    Requested by: <strong>{wf.requesterName}</strong> • Branch: {wf.branchName}
                  </p>
                </div>

                {wf.amountRequested && (
                  <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-900 dark:text-white text-xs">
                    Requested Expenditure Amount: ${wf.amountRequested.toLocaleString()}
                  </div>
                )}

                <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Current Step: {wf.currentStep} (Assigned to {wf.assignedApproverRole})</span>

                  {wf.status === 'Pending' && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleApproveGenWf(wf.id)}
                        disabled={isProcessing}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> {isProcessing ? 'Processing...' : 'Approve'}
                      </button>
                      <button
                        onClick={() => handleOpenReject('workflow', wf.id)}
                        disabled={isProcessing}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      </div>

      {/* Reject Reason Modal */}
      {rejectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-rose-600">
                <XCircle className="w-5 h-5" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Reject Application
                </h3>
              </div>
              <button onClick={() => setRejectModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmReject} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Reason for Rejection *
                </label>
                <textarea
                  required
                  rows={3}
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="e.g. Could not verify church transfer letter or applicant identity documents."
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-xs cursor-pointer"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SMS Prompt Modal */}
      {smsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-purple-600">
                <Send className="w-5 h-5" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Send Verification SMS
                </h3>
              </div>
              <button onClick={() => setSmsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendVerificationSms} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  SMS Message Body
                </label>
                <textarea
                  required
                  rows={4}
                  value={smsText}
                  onChange={(e) => setSmsText(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSmsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Dispatch SMS</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Public Registration Link Generator Modal */}
      <ShareRegistrationLinkModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
    </div>
  );
};
