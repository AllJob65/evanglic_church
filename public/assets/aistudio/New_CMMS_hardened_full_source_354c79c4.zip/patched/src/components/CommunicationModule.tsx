import React, { useState, useEffect, useRef } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { useTranslation } from '../i18n/LanguageContext';
import { CommunicationMessage, Member } from '../types';
import { EventMessagingTab } from './EventMessagingTab';
import { ApiIntegrationsTab } from './ApiIntegrationsTab';
import { DirectMessagePanel } from './DirectMessagePanel';
import { DirectVideoCallModal } from './DirectVideoCallModal';
import { useMinistryRealtime } from '../hooks/useMinistryRealtime';
import { RealtimeConnectionIndicator } from './RealtimeConnectionIndicator';
import {
  Send,
  Plus,
  Mail,
  MessageSquare,
  Bell,
  Smartphone,
  CheckCircle2,
  X,
  PieChart,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Monitor,
  Hand,
  Copy,
  Users,
  User,
  Paperclip,
  Smile,
  PhoneOff,
  Search,
  Sparkles,
  Image as ImageIcon,
  Check,
  Radio,
  Volume2,
  Cake,
  Zap,
  Share2,
  BookOpen,
} from 'lucide-react';

export const CommunicationModule: React.FC = () => {
  const { t } = useTranslation();
  const { communications, sendCommunication, permissions, members, currentUser, ministries, activeRole } = useCMMS();
  const currentUserRole = activeRole || currentUser?.role || 'Staff Member';

  // Top-Level Communication Mode Tab
  const [activeTab, setActiveTab] = useState<
    'broadcast' | 'event_messages' | 'api_integrations' | 'livechat' | 'videomeet' | 'direct_chat'
  >('broadcast');

  // Direct video call modal state from direct message thread
  const [directVideoState, setDirectVideoState] = useState<{
    conversationId: string;
    roomUrl: string;
    member: Member;
  } | null>(null);

  // Broadcast campaign state
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [channel, setChannel] = useState<CommunicationMessage['channel']>('SMS');
  const [targetAudience, setTargetAudience] = useState('All Active Members');

  // ---------------- LIVE CHAT ROOMS STATE (SUPABASE REALTIME) ----------------
  const [selectedChannelId, setSelectedChannelId] = useState<string>(ministries[0]?.id || 'min-1');
  const [chatSearch, setChatSearch] = useState('');
  const [chatInputText, setChatInputText] = useState('');

  const currentUserInfo = {
    id: currentUser?.memberId || currentUser?.email || 'usr-admin',
    name: currentUser?.name || 'Administrator',
    email: currentUser?.email || '',
    role: currentUserRole,
    avatar: currentUser?.photoUrl || '',
  };

  const {
    messages: liveMessages,
    members: channelMembers,
    typingUsers,
    isLoading: isChatLoading,
    sendMessage: sendRealtimeMessage,
    addReaction: addRealtimeReaction,
    sendTyping: broadcastTyping,
  } = useMinistryRealtime(selectedChannelId, currentUserInfo);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [liveMessages]);

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInputText.trim()) return;

    const textToSend = chatInputText.trim();
    setChatInputText('');
    await sendRealtimeMessage(textToSend);
  };

  const handleChatInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setChatInputText(e.target.value);
    broadcastTyping(e.target.value.length > 0);
  };

  // ---------------- VIDEO CONFERENCING (GOOGLE MEET STYLE) STATE ----------------
  const [isInMeeting, setIsInMeeting] = useState(false);
  const [meetingCode, setMeetingCode] = useState('GRACE-LIVE-2026');
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCamOn, setIsCamOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [showInMeetingChat, setShowInMeetingChat] = useState(false);
  const [showParticipantsDrawer, setShowParticipantsDrawer] = useState(false);
  const [copiedLinkMessage, setCopiedLinkMessage] = useState(false);

  const [inMeetingMessages, setInMeetingMessages] = useState<{ id: string; user: string; text: string; time: string }[]>([]);
  const [inMeetingChatInput, setInMeetingChatInput] = useState('');

  const meetingParticipants: { name: string; role: string; avatar: string; isMuted: boolean; isSpeaking: boolean }[] = [];

  const handleSendInMeetingChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inMeetingChatInput.trim()) return;
    setInMeetingMessages((prev) => [
      ...prev,
      {
        id: `inm-${Date.now()}`,
        user: 'You',
        text: inMeetingChatInput.trim(),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setInMeetingChatInput('');
  };

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !body) return;

    const newComm: CommunicationMessage = {
      id: `comm-${Date.now().toString().slice(-4)}`,
      subject,
      body,
      channel,
      triggerType: 'Manual Broadcast',
      targetAudience,
      recipientCount: members.length,
      sentAt: new Date().toLocaleString(),
      status: 'Sent',
      deliveryRatePercentage: members.length > 0 ? 100 : 0,
    };

    sendCommunication(newComm);
    setIsComposerOpen(false);
    setSubject('');
    setBody('');
  };

  const handleCopyMeetingLink = () => {
    navigator.clipboard?.writeText(`https://gracecathedral.org/meet/${meetingCode}`);
    setCopiedLinkMessage(true);
    setTimeout(() => setCopiedLinkMessage(false), 3000);
  };

  return (
    <div className="space-y-6 text-base">
      {/* Top Title Banner */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs min-w-0">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <Send className="w-6 h-6 text-blue-600 shrink-0" />
            <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">Multi-Channel Communication Hub</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
              Live Interactive & Broadcast
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Broadcast SMS & Email, Real-Time Fellowship Live Chat, and Google Meet-Style Video Conferencing.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl text-xs font-bold max-w-full">
          <button
            onClick={() => setActiveTab('broadcast')}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'broadcast'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-4 h-4 shrink-0" /> <span>Broadcast SMS & Email</span>
          </button>
          <button
            onClick={() => setActiveTab('event_messages')}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'event_messages'
                ? 'bg-pink-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Cake className="w-4 h-4 shrink-0" /> <span>Event Messages</span>
          </button>
          <button
            onClick={() => setActiveTab('api_integrations')}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'api_integrations'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Zap className="w-4 h-4 shrink-0" /> <span>API Integrations</span>
          </button>
          <button
            onClick={() => setActiveTab('livechat')}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'livechat'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-4 h-4 shrink-0" /> <span>Live Chat Channels</span>
          </button>
          <button
            onClick={() => setActiveTab('videomeet')}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'videomeet'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Video className="w-4 h-4 shrink-0" /> <span>Video Conferencing</span>
          </button>
          <button
            onClick={() => setActiveTab('direct_chat')}
            className={`min-h-[44px] px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'direct_chat'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4 shrink-0" /> <span>{t('direct_messaging_tab', '1:1 Direct & Video')}</span>
          </button>
        </div>
      </div>

      {/* ================= TAB: 1:1 DIRECT MESSAGING & VIDEO ================= */}
      {activeTab === 'direct_chat' && (
        <DirectMessagePanel
          onStartVideoCall={(conversationId, member, roomUrl) => {
            setDirectVideoState({
              conversationId,
              member,
              roomUrl,
            });
          }}
        />
      )}

      {/* ================= TAB: EVENT MESSAGES (BIRTHDAYS & ANNIVERSARIES) ================= */}
      {activeTab === 'event_messages' && <EventMessagingTab />}

      {/* ================= TAB: API INTEGRATIONS (SMS & BIBLE) ================= */}
      {activeTab === 'api_integrations' && <ApiIntegrationsTab />}

      {/* ================= TAB 1: BROADCAST CAMPAIGNS ================= */}
      {activeTab === 'broadcast' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Broadcast Campaign Log & Delivery Metrics</h3>
            {permissions.canEditMembers && (
              <button
                onClick={() => setIsComposerOpen(true)}
                className="min-h-[44px] px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> <span>Compose Broadcast Campaign</span>
              </button>
            )}
          </div>

          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            {communications.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No data available
              </div>
            ) : (
              communications.map((comm) => (
                <div
                  key={comm.id}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-200">
                        {comm.channel}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white text-sm">{comm.subject}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-xs">{comm.body}</p>
                    <p className="text-[11px] text-slate-400">
                      Target Audience: <strong>{comm.targetAudience}</strong> • Sent at: {comm.sentAt}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 block">
                      {comm.deliveryRatePercentage}% Delivered
                    </span>
                    <span className="text-[10px] text-slate-400">{comm.recipientCount} Recipients</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 2: LIVE CHAT ROOMS & CHANNELS ================= */}
      {activeTab === 'livechat' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[550px]">
          {/* Channels Sidebar */}
          <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-blue-600" />
                Church Channels
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                Live
              </span>
            </div>

            {/* Search channels */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search channels..."
                value={chatSearch}
                onChange={(e) => setChatSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              />
            </div>

            {/* Channel List */}
            <div className="space-y-1">
              {ministries.map((min) => (
                <button
                  key={min.id}
                  onClick={() => setSelectedChannelId(min.id)}
                  className={`w-full text-left p-2.5 rounded-xl transition-all cursor-pointer ${
                    selectedChannelId === min.id
                      ? 'bg-blue-50 dark:bg-blue-950/60 border border-blue-500 text-blue-900 dark:text-blue-200 font-bold shadow-xs'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold truncate"># {min.name.toLowerCase().replace(/\s+/g, '-')}</p>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                  <p className="text-[10px] text-slate-400 truncate">{min.description || 'Ministry Team Channel'}</p>
                </button>
              ))}
            </div>

            {/* Online Members Box */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Channel Roster ({channelMembers.length})
              </h4>
              <div className="space-y-2 text-xs">
                {channelMembers.slice(0, 5).map((m) => (
                  <div key={m.id} className="flex items-center gap-2">
                    <div className="relative">
                      <img
                        src={m.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
                        alt=""
                        className="w-6 h-6 rounded-full object-cover"
                      />
                      <span className="w-2 h-2 rounded-full bg-emerald-500 absolute bottom-0 right-0 border border-white dark:border-slate-900" />
                    </div>
                    <span className="truncate text-slate-800 dark:text-slate-200 font-medium">{m.userName}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Chat Feed Area */}
          <div className="lg:col-span-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between">
            {/* Channel Header */}
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    #{ministries.find((m) => m.id === selectedChannelId)?.name || 'fellowship-channel'}
                  </h3>
                  <RealtimeConnectionIndicator
                    channelName={`channel-health-${selectedChannelId}`}
                    tableName="ministry_chat_messages"
                    variant="pill"
                  />
                </div>
                <p className="text-[11px] text-slate-500">Persistent realtime church collaboration backed by Supabase.</p>
              </div>

              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 flex items-center gap-1">
                <Users className="w-3 h-3" /> {channelMembers.length || 1} Roster Members
              </span>
            </div>

            {/* Messages Feed */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4 max-h-[380px] pr-2">
              {isChatLoading ? (
                <div className="py-12 text-center text-slate-400 text-xs">Loading channel messages...</div>
              ) : liveMessages.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No fellowship messages in this channel yet. Post the first message below!
                </div>
              ) : (
                liveMessages.map((msg) => {
                  const isMe = msg.senderEmail === currentUserInfo.email || msg.senderName === currentUserInfo.name;

                  return (
                    <div key={msg.id} className={`flex gap-3 text-xs ${isMe ? 'flex-row-reverse' : ''}`}>
                      <img
                        src={msg.senderAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
                        alt=""
                        className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5 ring-1 ring-indigo-500/20"
                      />
                      <div className={`space-y-1 max-w-xl ${isMe ? 'items-end' : ''}`}>
                        <div className={`flex items-center gap-2 ${isMe ? 'justify-end' : ''}`}>
                          <span className="font-bold text-slate-900 dark:text-white">{msg.senderName}</span>
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                            {msg.senderRole}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        {msg.scriptureRef && (
                          <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200 text-[11px] font-serif">
                            📖 {msg.scriptureRef}
                          </div>
                        )}

                        <p
                          className={`p-3 rounded-2xl leading-relaxed ${
                            isMe
                              ? 'bg-blue-600 text-white rounded-tr-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-xs'
                          }`}
                        >
                          {msg.text}
                        </p>

                        <div className={`flex items-center gap-1 pt-0.5 ${isMe ? 'justify-end' : ''}`}>
                          {msg.reactions && msg.reactions.map((r, idx) => (
                            <button
                              key={idx}
                              onClick={() => addRealtimeReaction(msg.id, r.emoji)}
                              className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-[10px] font-bold cursor-pointer transition-all"
                            >
                              {r.emoji} {r.count}
                            </button>
                          ))}
                          <div className="flex items-center gap-0.5">
                            {['🙏', '❤️', '🙌'].map((em) => (
                              <button
                                key={em}
                                onClick={() => addRealtimeReaction(msg.id, em)}
                                className="p-1 text-[11px] hover:bg-slate-200 dark:hover:bg-slate-800 rounded-md cursor-pointer"
                              >
                                {em}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}

              {typingUsers.length > 0 && (
                <div className="text-[11px] text-blue-600 dark:text-blue-400 italic animate-pulse flex items-center gap-1 font-semibold">
                  <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                  {typingUsers.join(', ')} is typing...
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Message Input Bar */}
            <form onSubmit={handleSendChatMessage} className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <input
                type="text"
                placeholder="Type a message to this channel in realtime..."
                value={chatInputText}
                onChange={handleChatInputChange}
                className="flex-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs"
              />
              <button
                type="submit"
                disabled={!chatInputText.trim()}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold text-xs shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" /> Send
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ================= TAB 3: VIDEO CONFERENCING (GOOGLE MEET STYLE) ================= */}
      {activeTab === 'videomeet' && (
        <div className="space-y-6">
          {!isInMeeting ? (
            /* Meeting Pre-Join / Lobby Screen */
            <div className="p-8 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-8 border border-slate-800">
              <div className="space-y-4 max-w-xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
                  <Video className="w-4 h-4 text-blue-400" />
                  Grace Meet • Google Meet Style Video Room
                </div>
                <h2 className="text-3xl font-black tracking-tight leading-tight">
                  High-Definition Live Church Video Calls & Prayer Meetings
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Host virtual Bible studies, prayer marathons, leadership meetings, and pastoral counseling sessions with real-time video grid, screen sharing, and hand raise queue.
                </p>

                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    onClick={() => setIsInMeeting(true)}
                    className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Video className="w-4 h-4" /> Start NOW
                  </button>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <input
                      type="text"
                      value={meetingCode}
                      onChange={(e) => setMeetingCode(e.target.value)}
                      placeholder="Enter meeting code..."
                      className="p-3 rounded-xl bg-white/10 border border-white/20 text-white text-xs font-mono placeholder-slate-400 focus:outline-none"
                    />
                    <button
                      onClick={() => setIsInMeeting(true)}
                      className="px-4 py-3 bg-white/20 hover:bg-white/30 text-white font-bold text-xs rounded-xl transition-all"
                    >
                      Join
                    </button>
                  </div>
                </div>
              </div>

              {/* Lobby Camera Preview Box */}
              <div className="w-full md:w-80 h-52 rounded-2xl bg-slate-800 border border-slate-700 relative overflow-hidden flex flex-col items-center justify-center shadow-2xl shrink-0">
                {isCamOn ? (
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80"
                    alt="Self Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center space-y-2">
                    <div className="w-16 h-16 rounded-full bg-blue-600 text-white text-xl font-bold flex items-center justify-center mx-auto">
                      SY
                    </div>
                    <p className="text-xs font-bold text-slate-300">Camera Off</p>
                  </div>
                )}

                {/* Pre-join camera controls */}
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
                  <button
                    onClick={() => setIsMicOn(!isMicOn)}
                    className={`p-2 rounded-full ${isMicOn ? 'bg-white/20 text-white' : 'bg-rose-600 text-white'}`}
                  >
                    {isMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => setIsCamOn(!isCamOn)}
                    className={`p-2 rounded-full ${isCamOn ? 'bg-white/20 text-white' : 'bg-rose-600 text-white'}`}
                  >
                    {isCamOn ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* ACTIVE GOOGLE MEET STYLE VIDEO CONFERENCING INTERFACE */
            <div className="bg-slate-950 text-white rounded-3xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col min-h-[600px] relative">
              {/* Meeting Header Bar */}
              <div className="p-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                  <div>
                    <h3 className="font-bold text-sm text-white">Grace Cathedral Live Prayer & Fellowship</h3>
                    <p className="text-[10px] text-slate-400 font-mono">Room Code: {meetingCode}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyMeetingLink}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center gap-1.5 transition-all text-xs"
                  >
                    {copiedLinkMessage ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedLinkMessage ? 'Copied Invite Link!' : 'Copy Meeting Link'}
                  </button>
                </div>
              </div>

              {/* Main Video Call Content Layout */}
              <div className="flex-1 flex overflow-hidden">
                {/* Video Grid */}
                <div className="flex-1 p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 auto-rows-fr">
                  {/* Local User Camera Box */}
                  <div className="relative rounded-2xl overflow-hidden bg-slate-900 border-2 border-blue-500/50 shadow-lg">
                    {isCamOn ? (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900">
                        <div className="w-16 h-16 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xl">
                          YOU
                        </div>
                        <span className="text-xs text-emerald-400 mt-2">Camera Active</span>
                      </div>
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900">
                        <div className="w-16 h-16 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xl">
                          YOU
                        </div>
                        <span className="text-xs text-slate-400 mt-2">Camera Off</span>
                      </div>
                    )}
                    <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-md text-white px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-2">
                      {isMicOn ? <Mic className="w-3.5 h-3.5 text-emerald-400" /> : <MicOff className="w-3.5 h-3.5 text-rose-400" />}
                      You (Admin) {isHandRaised && '✋ Hand Raised'}
                    </div>
                  </div>
                </div>

                {/* Side Drawer Panel (In-Meeting Live Chat or Participant List) */}
                {(showInMeetingChat || showParticipantsDrawer) && (
                  <div className="w-80 bg-slate-900 border-l border-slate-800 p-4 flex flex-col justify-between shrink-0">
                    {showInMeetingChat && (
                      <div className="flex-1 flex flex-col justify-between h-full">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                          <h4 className="font-bold text-xs text-white">In-Call Live Chat</h4>
                          <button onClick={() => setShowInMeetingChat(false)} className="text-slate-400">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="flex-1 overflow-y-auto space-y-3 py-3 text-xs pr-1">
                          {inMeetingMessages.map((m) => (
                            <div key={m.id} className="p-2.5 rounded-xl bg-slate-800 space-y-1">
                              <div className="flex items-center justify-between font-bold text-blue-400">
                                <span>{m.user}</span>
                                <span className="text-[10px] text-slate-500">{m.time}</span>
                              </div>
                              <p className="text-slate-200">{m.text}</p>
                            </div>
                          ))}
                        </div>

                        <form onSubmit={handleSendInMeetingChat} className="pt-2 border-t border-slate-800 flex gap-2">
                          <input
                            type="text"
                            placeholder="Send message to room..."
                            value={inMeetingChatInput}
                            onChange={(e) => setInMeetingChatInput(e.target.value)}
                            className="flex-1 p-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                          />
                          <button type="submit" className="px-3 py-2 bg-blue-600 rounded-xl font-bold text-xs">
                            Send
                          </button>
                        </form>
                      </div>
                    )}

                    {showParticipantsDrawer && (
                      <div className="flex-1 flex flex-col justify-between h-full">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                          <h4 className="font-bold text-xs text-white">Meeting Participants (4)</h4>
                          <button onClick={() => setShowParticipantsDrawer(false)} className="text-slate-400">
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="space-y-3 py-3 flex-1 overflow-y-auto text-xs">
                          {meetingParticipants.map((p, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60">
                              <div className="flex items-center gap-2">
                                <img src={p.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                                <div>
                                  <p className="font-bold text-white">{p.name}</p>
                                  <p className="text-[10px] text-slate-400">{p.role}</p>
                                </div>
                              </div>
                              {p.isMuted ? <MicOff className="w-3.5 h-3.5 text-rose-400" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom Google Meet Style Control Toolbar */}
              <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
                <div className="hidden sm:block text-xs font-semibold text-slate-400">
                  Grace Meet • Live Session
                </div>

                {/* Central Control Buttons */}
                <div className="flex items-center gap-3 mx-auto sm:mx-0">
                  {/* Mic Toggle */}
                  <button
                    onClick={() => setIsMicOn(!isMicOn)}
                    className={`p-3 rounded-full transition-all ${
                      isMicOn ? 'bg-slate-800 hover:bg-slate-700 text-white' : 'bg-rose-600 text-white ring-2 ring-rose-500/50'
                    }`}
                    title={isMicOn ? 'Mute Microphone' : 'Unmute Microphone'}
                  >
                    {isMicOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                  </button>

                  {/* Camera Toggle */}
                  <button
                    onClick={() => setIsCamOn(!isCamOn)}
                    className={`p-3 rounded-full transition-all ${
                      isCamOn ? 'bg-slate-800 hover:bg-slate-700 text-white' : 'bg-rose-600 text-white ring-2 ring-rose-500/50'
                    }`}
                    title={isCamOn ? 'Turn Off Camera' : 'Turn On Camera'}
                  >
                    {isCamOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                  </button>

                  {/* Screen Share */}
                  <button
                    onClick={() => setIsScreenSharing(!isScreenSharing)}
                    className={`p-3 rounded-full transition-all ${
                      isScreenSharing ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                    title="Share Screen"
                  >
                    <Monitor className="w-5 h-5" />
                  </button>

                  {/* Raise Hand */}
                  <button
                    onClick={() => setIsHandRaised(!isHandRaised)}
                    className={`p-3 rounded-full transition-all ${
                      isHandRaised ? 'bg-amber-500 text-white ring-2 ring-amber-400/50' : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                    title="Raise Hand"
                  >
                    <Hand className="w-5 h-5" />
                  </button>

                  {/* Toggle Chat Drawer */}
                  <button
                    onClick={() => {
                      setShowInMeetingChat(!showInMeetingChat);
                      setShowParticipantsDrawer(false);
                    }}
                    className={`p-3 rounded-full transition-all ${
                      showInMeetingChat ? 'bg-blue-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                    title="In-call Chat"
                  >
                    <MessageSquare className="w-5 h-5" />
                  </button>

                  {/* Toggle Participants Drawer */}
                  <button
                    onClick={() => {
                      setShowParticipantsDrawer(!showParticipantsDrawer);
                      setShowInMeetingChat(false);
                    }}
                    className={`p-3 rounded-full transition-all ${
                      showParticipantsDrawer ? 'bg-blue-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                    title="Participants"
                  >
                    <Users className="w-5 h-5" />
                  </button>

                  {/* Leave Call */}
                  <button
                    onClick={() => setIsInMeeting(false)}
                    className="p-3 rounded-full bg-rose-600 hover:bg-rose-500 text-white transition-all shadow-lg ml-2"
                    title="Leave Call"
                  >
                    <PhoneOff className="w-5 h-5" />
                  </button>
                </div>

                <div className="hidden md:block text-xs text-slate-400 font-mono">
                  1080p HD • Encrypted
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Broadcast Composer Modal */}
      {isComposerOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-md border-0 sm:border border-slate-200 dark:border-slate-800 p-4 sm:p-6 space-y-4 max-h-[92vh] sm:max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Compose Broadcast</h3>
              <button
                type="button"
                onClick={() => setIsComposerOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-slate-600 rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendBroadcast} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Communication Channel</label>
                <select
                  value={channel}
                  onChange={(e) => setChannel(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="SMS">SMS Text Message</option>
                  <option value="Email">Email Broadcast</option>
                  <option value="WhatsApp">WhatsApp Business API</option>
                  <option value="Push Notification">Mobile App Push Notification</option>
                  <option value="Multi-Channel">All Channels Simultaneously</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Target Segment Audience</label>
                <select
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="All Active Members">All Active Members</option>
                  <option value="Judah Praise Worship Ministry">Judah Praise Worship Ministry</option>
                  <option value="Youth & Teen Ministry">Youth & Teen Ministry</option>
                  <option value="Grace Cathedral HQ Campus">Grace Cathedral HQ Campus</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Subject / Headline</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Special Revival Night Reminder"
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Message Content</label>
                <textarea
                  rows={4}
                  required
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Type message text..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsComposerOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-xl font-semibold">
                  Send Broadcast
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1:1 Direct Video Call Modal from Message Thread */}
      {directVideoState && (
        <DirectVideoCallModal
          isOpen={Boolean(directVideoState)}
          onClose={() => setDirectVideoState(null)}
          conversationId={directVideoState.conversationId}
          roomUrl={directVideoState.roomUrl}
          remoteParticipantName={`${directVideoState.member.title || ''} ${directVideoState.member.firstName} ${directVideoState.member.lastName}`.trim()}
          remoteParticipantRole={directVideoState.member.membershipStatus || 'Member'}
          remoteParticipantAvatar={directVideoState.member.photoUrl}
        />
      )}
    </div>
  );
};
