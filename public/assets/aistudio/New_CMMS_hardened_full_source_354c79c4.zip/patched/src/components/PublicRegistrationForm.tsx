import React, { useState, useEffect } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Member } from '../types';
import { apiService } from '../services/api';
import { EthiopianDateHelper } from './EthiopianDateHelper';
import {
  Church,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Copy,
  Check,
  QrCode,
  Share2,
  Download,
  Calendar,
  Sparkles,
  ShieldCheck,
  Globe,
  HeartHandshake,
  Users,
  MapPin,
  Phone,
  Mail,
  User,
  ExternalLink,
  Printer,
  ChevronDown,
  Building,
  Heart,
  HelpCircle,
  FileCheck
} from 'lucide-react';

interface PublicRegistrationFormProps {
  onReturnToLogin?: () => void;
  defaultBranchId?: string;
}

export const PublicRegistrationForm: React.FC<PublicRegistrationFormProps> = ({
  onReturnToLogin,
  defaultBranchId,
}) => {
  const {
    branches,
    systemName,
    churchLogoUrl,
    churchMotto,
    language,
    setLanguage,
  } = useCMMS();

  // Multi-Section Google Form Steps:
  // 1: Personal Demographics & Identity
  // 2: Contact, Residence & Church Campus
  // 3: Spiritual Journey & Ministry Callings
  // 4: Family, Health & Emergency Contacts
  const [currentSection, setCurrentSection] = useState<number>(1);
  const totalSections = 4;

  // Form State
  const [title, setTitle] = useState<'Mr' | 'Mrs' | 'Ms' | 'Dr' | 'Pastor' | 'Elder' | 'Brother' | 'Sister'>('Brother');
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [amharicName, setAmharicName] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [dateOfBirth, setDateOfBirth] = useState('1998-04-15');
  const [maritalStatus, setMaritalStatus] = useState<'Single' | 'Married' | 'Widowed' | 'Divorced'>('Single');
  const [nationality, setNationality] = useState('Ethiopian');
  const [occupation, setOccupation] = useState('');
  const [employer, setEmployer] = useState('');

  // Contact State
  const [primaryPhone, setPrimaryPhone] = useState('');
  const [altPhone, setAltPhone] = useState('');
  const [email, setEmail] = useState('');
  const [preferredCommChannel, setPreferredCommChannel] = useState<'SMS' | 'Email' | 'Telegram' | 'Phone Call'>('SMS');
  const [city, setCity] = useState('Addis Ababa');
  const [subCity, setSubCity] = useState('Bole');
  const [woreda, setWoreda] = useState('Woreda 03');
  const [kebele, setKebele] = useState('Kebele 05');
  const [houseNumber, setHouseNumber] = useState('');
  const [streetAddress, setStreetAddress] = useState('');
  const [selectedBranchId, setSelectedBranchId] = useState(defaultBranchId || '');
  const [registrationBranches, setRegistrationBranches] = useState<{ id: string; name: string; location?: string }[]>([]);

  useEffect(() => {
    let mounted = true;
    apiService.getPublicRegistrationOptions().then((result) => {
      if (!mounted) return;
      const options = Array.isArray(result?.branches) ? result.branches : [];
      setRegistrationBranches(options);
      setSelectedBranchId((current) => options.some((branch) => branch.id === current) ? current : options[0]?.id || '');
    }).catch((error) => {
      console.error('[PublicRegistrationForm] Failed to load active campuses:', error);
      if (mounted) setErrorMsg('Church campuses could not be loaded. Please refresh the page or contact the church office.');
    });
    return () => { mounted = false; };
  }, []);

  const registrationToken = typeof window !== 'undefined'
    ? decodeURIComponent(window.location.pathname.match(/^\/register\/([^/]+)/)?.[1] || '')
    : '';

  // Spiritual Journey
  const [salvationDate, setSalvationDate] = useState('2018-05-20');
  const [salvationLocation, setSalvationLocation] = useState('');
  const [isWaterBaptized, setIsWaterBaptized] = useState(true);
  const [waterBaptismDate, setWaterBaptismDate] = useState('2018-09-12');
  const [isHolySpiritBaptized, setIsHolySpiritBaptized] = useState(true);
  const [selectedMinistries, setSelectedMinistries] = useState<string[]>(['Worship & Choir']);
  const [previousChurch, setPreviousChurch] = useState('');

  // Emergency & Family
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyRelationship, setEmergencyRelationship] = useState('Parent / Spouse');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [knownAllergies, setKnownAllergies] = useState('');
  const [specialPrayerNeeds, setSpecialPrayerNeeds] = useState('');
  const [covenantAgreed, setCovenantAgreed] = useState(true);

  // Status & Feedback
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [registeredMember, setRegisteredMember] = useState<Member | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  const availableMinistries = [
    { id: 'worship', name: 'Worship & Choir (መዘምራን)', desc: 'Vocalists, instrumentalists, and song leaders.' },
    { id: 'ushering', name: 'Ushering & Protocol (ስነ-ስርዓት)', desc: 'Sanctuary order, hospitality, and welcoming guests.' },
    { id: 'media', name: 'Media, Sound & Tech (ሚዲያ እና ቴክኖሎጂ)', desc: 'Audio engineering, broadcast, lighting, and cameras.' },
    { id: 'youth', name: 'Youth & Campus (ወጣቶች)', desc: 'Mentorship, high school, and campus fellowships.' },
    { id: 'children', name: 'Sunday School (የልጆች አገልግሎት)', desc: 'Children discipleship, crafts, and biblical foundations.' },
    { id: 'prayer', name: 'Intercessory Prayer (ምልጃና ጸሎት)', desc: 'Prayer warriors, fasting chains, and hospital visitations.' },
    { id: 'outreach', name: 'Evangelism & Outreach (ወንጌል ስርጭት)', desc: 'Community relief, street missions, and mission trips.' },
    { id: 'counseling', name: 'Pastoral Care & Counseling (የምክር አገልግሎት)', desc: 'Family counseling, grief support, and visitations.' }
  ];

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (currentSection === 1) {
      if (!firstName.trim() || !lastName.trim()) {
        setErrorMsg('First Name and Last Name are required fields.');
        return;
      }
      setCurrentSection(2);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (currentSection === 2) {
      if (!primaryPhone.trim()) {
        setErrorMsg('Primary Phone number is required for church communication.');
        return;
      }
      setCurrentSection(3);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (currentSection === 3) {
      setCurrentSection(4);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!covenantAgreed) {
      setErrorMsg('Please confirm agreement to the Church Member Fellowship Covenant & Statement of Faith.');
      return;
    }
    if (!selectedBranchId || !registrationBranches.some((branch) => branch.id === selectedBranchId)) {
      setErrorMsg('Please select an available church campus. Refresh the page if no campus is listed.');
      return;
    }

    setIsSubmitting(true);
    const branchName = registrationBranches.find((branch) => branch.id === selectedBranchId)?.name || 'Church Campus';
    const phone = primaryPhone.trim();
    const emailAddress = email.trim().toLowerCase();
    const receiptMember: Member = {
      id: `application-${Date.now()}`,
      memberIdNumber: '',
      title,
      firstName: firstName.trim(),
      middleName: middleName.trim(),
      lastName: lastName.trim(),
      amharicName: amharicName.trim() || `${firstName.trim()} ${lastName.trim()}`,
      gender,
      maritalStatus,
      dateOfBirth,
      nationality,
      occupation: occupation || '',
      employerName: employer || '',
      primaryPhone: phone,
      altPhone: altPhone.trim(),
      email: emailAddress,
      preferredCommChannel,
      streetAddress: streetAddress || `${subCity}, ${woreda}`,
      city,
      subCity,
      woreda,
      kebele,
      houseNumber,
      region: city,
      postalCode: '1000',
      branchId: selectedBranchId,
      membershipStatus: 'Pending Approval',
      membershipType: 'Full Member',
      membershipDate: new Date().toISOString().slice(0, 10),
      membershipLocation: branchName,
      isWaterBaptized,
      waterBaptismDate: isWaterBaptized ? waterBaptismDate : undefined,
      isHolySpiritBaptized,
      salvationDate,
      salvationLocation: salvationLocation || branchName,
      ministryIds: [],
      ministriesJoinedNow: selectedMinistries,
      attendanceScore: 0,
      createdAt: new Date().toISOString(),
      lastActive: 'Registration submitted',
      emergencyContact: {
        name: emergencyName || 'Next of Kin',
        relationship: emergencyRelationship || 'Family',
        phone: emergencyPhone || phone,
      },
      knownAllergies: knownAllergies ? knownAllergies.split(',').map((item) => item.trim()).filter(Boolean) : [],
      notes: specialPrayerNeeds ? `Online Registration Notes / Prayer Needs: ${specialPrayerNeeds}` : 'Registered via Public Online Link',
    } as Member;

    try {
      const result = await apiService.registerPublic({
        firstName: receiptMember.firstName,
        middleName: receiptMember.middleName,
        lastName: receiptMember.lastName,
        title,
        gender,
        maritalStatus,
        dateOfBirth,
        nationality,
        occupation,
        employer,
        phone,
        altPhone,
        email: emailAddress,
        streetAddress,
        address: receiptMember.streetAddress,
        city,
        subCity,
        woreda,
        kebele,
        houseNumber,
        branchId: selectedBranchId,
        registrationToken: registrationToken || undefined,
        ministriesJoinedNow: selectedMinistries,
        ministryIds: [],
        isWaterBaptized,
        isHolySpiritBaptized,
        waterBaptismDate,
        salvationDate,
        salvationLocation,
        emergencyContact: receiptMember.emergencyContact,
        knownAllergies: receiptMember.knownAllergies,
        notes: receiptMember.notes,
      });
      if (!result?.success || !result.applicationReference) {
        throw new Error(result?.message || 'The registration server did not confirm your application.');
      }
      setRegisteredMember({
        ...receiptMember,
        id: result.workflow?.id || result.applicationReference,
        memberIdNumber: result.memberIdNumber || result.applicationReference,
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error: any) {
      console.error('[PublicRegistrationForm] Registration persistence failed:', error);
      setErrorMsg(error?.message || 'Your registration could not be saved. Please check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyRegistrationLink = () => {
    const link = typeof window !== 'undefined' ? `${window.location.origin}/?view=register` : 'https://church.app/?view=register';
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const handleResetForm = () => {
    setRegisteredMember(null);
    setCurrentSection(1);
    setFirstName('');
    setMiddleName('');
    setLastName('');
    setPrimaryPhone('');
    setEmail('');
    setSpecialPrayerNeeds('');
  };

  return (
    <div className="min-h-screen bg-slate-900/95 text-slate-100 py-6 sm:py-10 px-3 sm:px-6 flex flex-col justify-between font-sans">
      
      {/* Top Floating Branding Bar (Google Form Theme Header) */}
      <header className="max-w-3xl w-full mx-auto mb-4 flex items-center justify-between bg-slate-800/90 backdrop-blur-md px-4 py-3 rounded-2xl border border-slate-700 shadow-xl">
        <div className="flex items-center gap-3">
          {churchLogoUrl ? (
            <img src={churchLogoUrl} alt="Logo" className="w-9 h-9 rounded-xl object-cover bg-white p-0.5" />
          ) : (
            <div className="p-2 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-xl text-white">
              <Church className="w-5 h-5" />
            </div>
          )}
          <div>
            <h1 className="text-sm sm:text-base font-black text-white leading-tight">
              {systemName || 'Grace Cathedral'}
            </h1>
            <p className="text-[11px] text-blue-300 font-medium">
              Official Member Registration Form Link
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Language Selector */}
          <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-700 text-xs">
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-transparent text-white font-bold cursor-pointer border-0 py-0.5 focus:outline-hidden text-xs"
            >
              <option value="English" className="bg-slate-900 text-white">EN</option>
              <option value="Amharic" className="bg-slate-900 text-white">አማ (Amharic)</option>
              <option value="Tigrigna" className="bg-slate-900 text-white">ትግ (Tigrigna)</option>
              <option value="Afaan Oromoo" className="bg-slate-900 text-white">OM (Oromoo)</option>
            </select>
          </div>

          {onReturnToLogin && (
            <button
              onClick={onReturnToLogin}
              className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Sign In
            </button>
          )}
        </div>
      </header>

      {/* Main Google-Form Card Container */}
      <main className="max-w-3xl w-full mx-auto space-y-4">
        
        {registeredMember ? (
          /* ====================================================================
             COMPLETION / SUCCESS CARD (Google Form Response Confirmation)
             ==================================================================== */
          <div className="bg-slate-800 border-t-8 border-t-emerald-500 rounded-3xl p-6 sm:p-10 shadow-2xl border border-slate-700 space-y-6 animate-in zoom-in-95 duration-200 text-center">
            
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                Response Recorded Successfully
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-3">
                Welcome to {systemName || 'Our Church Family'}!
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-lg mx-auto">
                Thank you, <span className="font-bold text-white">{registeredMember.firstName} {registeredMember.lastName}</span>. Your membership application has been submitted to the pastoral leadership.
              </p>
            </div>

            {/* Official Registration Receipt Card */}
            <div className="p-5 bg-slate-900/90 rounded-2xl border border-slate-700 max-w-md mx-auto text-left space-y-3 shadow-inner">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Official Member ID</span>
                  <span className="font-mono text-base sm:text-lg font-black text-blue-400">{registeredMember.memberIdNumber}</span>
                </div>
                <div className="p-2 bg-blue-600/20 text-blue-300 rounded-xl border border-blue-500/30">
                  <QrCode className="w-8 h-8" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Assigned Campus:</span>
                  <span className="font-bold text-white truncate block">
                    {registrationBranches.find(b => b.id === registeredMember.branchId)?.name || 'Main Cathedral'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Primary Phone:</span>
                  <span className="font-bold text-white block">{registeredMember.primaryPhone}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Baptism Status:</span>
                  <span className="font-semibold text-emerald-400 block">
                    {registeredMember.isWaterBaptized ? 'Water Baptized' : 'Needs Baptism Class'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Application Status:</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800 inline-block">
                    Pending Pastoral Review
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handlePrintReceipt}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-blue-500/25 cursor-pointer transition-all"
              >
                <Printer className="w-4 h-4" /> Print / Save Confirmation Slip
              </button>

              <button
                onClick={handleResetForm}
                className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Submit Another Response
              </button>

              {onReturnToLogin && (
                <button
                  onClick={onReturnToLogin}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-950 text-blue-400 rounded-xl text-xs font-bold border border-slate-700 transition-all cursor-pointer"
                >
                  Return to Main Portal
                </button>
              )}
            </div>
          </div>
        ) : (
          /* ====================================================================
             ACTIVE GOOGLE-FORM QUESTIONNAIRE
             ==================================================================== */
          <div className="space-y-4">
            
            {/* Header Form Banner Card (Google Forms Top Hero) */}
            <div className="bg-slate-800 border-t-8 border-t-blue-600 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-700 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Church Member Registration Questionnaire
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1">
                    Please fill out this official registration form to become a registered member of {systemName || 'Grace Cathedral Ministries'}. All information is held in strict pastoral confidentiality.
                  </p>
                </div>
                <div className="hidden sm:block p-3 rounded-2xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  <FileCheck className="w-7 h-7" />
                </div>
              </div>

              {/* Sharable Link Quick Bar */}
              <div className="pt-2 border-t border-slate-700/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-slate-400">
                  <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                  <span>Public Form Link Active • Multi-Campus Integrated</span>
                </div>

                <button
                  type="button"
                  onClick={handleCopyRegistrationLink}
                  className="px-2.5 py-1 bg-slate-900 hover:bg-slate-950 text-blue-300 rounded-lg font-bold border border-slate-700 flex items-center gap-1.5 cursor-pointer text-[11px] transition-all"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedLink ? 'Link Copied to Clipboard!' : 'Copy Form Link'}
                </button>
              </div>

              {/* Progress Indicator */}
              <div className="pt-2">
                <div className="flex justify-between items-center text-xs font-bold mb-1.5">
                  <span className="text-blue-400">
                    Section {currentSection} of {totalSections}: {
                      currentSection === 1 ? 'Personal Demographics' :
                      currentSection === 2 ? 'Contact & Church Campus' :
                      currentSection === 3 ? 'Spiritual Milestones & Ministries' :
                      'Emergency Contacts & Covenant'
                    }
                  </span>
                  <span className="text-slate-400">{Math.round((currentSection / totalSections) * 100)}% Completed</span>
                </div>
                <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-500 transition-all duration-300"
                    style={{ width: `${(currentSection / totalSections) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Error Notification */}
            {errorMsg && (
              <div className="p-4 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-2xl text-xs font-bold flex items-center gap-3 animate-in fade-in">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* SECTION 1: Personal Demographics & Identity */}
            {currentSection === 1 && (
              <form onSubmit={handleNext} className="space-y-4 animate-in fade-in">
                <div className="bg-slate-800 rounded-3xl p-5 sm:p-7 border border-slate-700 shadow-xl space-y-4">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-700 pb-2">
                    <User className="w-4 h-4 text-blue-400" />
                    1. Personal Identity & Background
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Title</label>
                      <select
                        value={title}
                        onChange={(e) => setTitle(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-bold focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Brother">Brother (ወንድም)</option>
                        <option value="Sister">Sister (እህት)</option>
                        <option value="Mr">Mr</option>
                        <option value="Mrs">Mrs</option>
                        <option value="Ms">Ms</option>
                        <option value="Dr">Dr</option>
                        <option value="Pastor">Pastor (ፓስተር)</option>
                        <option value="Elder">Elder (ሽማግሌ)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">First Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Dawit (ዳዊት)"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Middle Name (Father)</label>
                      <input
                        type="text"
                        placeholder="e.g. Yohannes"
                        value={middleName}
                        onChange={(e) => setMiddleName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Last Name (Grandfather) *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Wolde"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Full Name in Amharic Script (ሙሉ ስም በፊደል)</label>
                    <input
                      type="text"
                      placeholder="ምሳሌ፡ ዳዊት ዮሐንስ ወልደ"
                      value={amharicName}
                      onChange={(e) => setAmharicName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-amharic focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Gender *</label>
                      <select
                        value={gender}
                        onChange={(e) => setGender(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Male">Male (ወንድ)</option>
                        <option value="Female">Female (ሴት)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Marital Status</label>
                      <select
                        value={maritalStatus}
                        onChange={(e) => setMaritalStatus(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Single">Single (ያላገባ/ች)</option>
                        <option value="Married">Married (ያገባ/ች)</option>
                        <option value="Widowed">Widowed (ባለቤቱ/ቷ ያረፈ/ች)</option>
                        <option value="Divorced">Divorced (የተፋታ/ች)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Nationality</label>
                      <input
                        type="text"
                        value={nationality}
                        onChange={(e) => setNationality(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  {/* Ethiopian Date of Birth helper */}
                  <EthiopianDateHelper
                    label="Date of Birth"
                    value={dateOfBirth}
                    onChange={(val) => setDateOfBirth(val)}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Profession / Field of Work</label>
                      <input
                        type="text"
                        placeholder="e.g. Teacher, Civil Engineer, Medical Doctor"
                        value={occupation}
                        onChange={(e) => setOccupation(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Employer / Organization</label>
                      <input
                        type="text"
                        placeholder="e.g. Ministry of Health, Private Business"
                        value={employer}
                        onChange={(e) => setEmployer(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-500/25 cursor-pointer transition-all"
                  >
                    Next: Contact & Campus <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* SECTION 2: Contact, Residence & Church Campus */}
            {currentSection === 2 && (
              <form onSubmit={handleNext} className="space-y-4 animate-in fade-in">
                <div className="bg-slate-800 rounded-3xl p-5 sm:p-7 border border-slate-700 shadow-xl space-y-4">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-700 pb-2">
                    <MapPin className="w-4 h-4 text-emerald-400" />
                    2. Contact Details & Residential Address
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Primary Phone Number (Ethiopian) *</label>
                      <input
                        type="tel"
                        required
                        placeholder="0911234567 or +251 91 123 4567"
                        value={primaryPhone}
                        onChange={(e) => setPrimaryPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Alternative Phone / Telegram</label>
                      <input
                        type="tel"
                        placeholder="0922000000"
                        value={altPhone}
                        onChange={(e) => setAltPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Email Address</label>
                      <input
                        type="email"
                        placeholder="dawit.wolde@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Preferred Communication</label>
                      <select
                        value={preferredCommChannel}
                        onChange={(e) => setPreferredCommChannel(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="SMS">SMS Text Message</option>
                        <option value="Telegram">Telegram</option>
                        <option value="Email">Email</option>
                        <option value="Phone Call">Direct Phone Call</option>
                      </select>
                    </div>
                  </div>

                  {/* Campus Selection */}
                  <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-700">
                    <label className="block text-xs font-black text-blue-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <Building className="w-4 h-4" />
                      Select Church Campus / Branch *
                    </label>
                    <select
                      value={selectedBranchId}
                      onChange={(e) => setSelectedBranchId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-blue-500/50 text-white text-xs font-bold focus:ring-2 focus:ring-blue-500"
                    >
                      {registrationBranches.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name} — {b.location || 'Ethiopia'}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Detailed Ethiopian Address */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">City</label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Sub-City (ክፍለ ከተማ)</label>
                      <input
                        type="text"
                        value={subCity}
                        onChange={(e) => setSubCity(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Woreda (ወረዳ)</label>
                      <input
                        type="text"
                        value={woreda}
                        onChange={(e) => setWoreda(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">House Number (የቤት ቁጥር)</label>
                      <input
                        type="text"
                        placeholder="e.g. 452"
                        value={houseNumber}
                        onChange={(e) => setHouseNumber(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Specific Neighborhood Landmark</label>
                    <input
                      type="text"
                      placeholder="e.g. Near Bole Medhanialem Church, Behind Edna Mall"
                      value={streetAddress}
                      onChange={(e) => setStreetAddress(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                    />
                  </div>
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setCurrentSection(1)}
                    className="px-5 py-3 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-2xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-500/25 cursor-pointer transition-all"
                  >
                    Next: Spiritual Milestones <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* SECTION 3: Spiritual Journey & Ministry Callings */}
            {currentSection === 3 && (
              <form onSubmit={handleNext} className="space-y-4 animate-in fade-in">
                <div className="bg-slate-800 rounded-3xl p-5 sm:p-7 border border-slate-700 shadow-xl space-y-4">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-700 pb-2">
                    <HeartHandshake className="w-4 h-4 text-purple-400" />
                    3. Spiritual Journey & Ministry Callings
                  </h3>

                  {/* Water Baptism & Holy Spirit */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-between">
                      <div>
                        <label className="font-bold text-xs text-white block">Water Baptized (በውሃ ተጠምቀዋል?)</label>
                        <span className="text-[11px] text-slate-400">By full immersion in the name of the Lord Jesus</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={isWaterBaptized}
                        onChange={(e) => setIsWaterBaptized(e.target.checked)}
                        className="w-5 h-5 rounded text-blue-600 cursor-pointer"
                      />
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-between">
                      <div>
                        <label className="font-bold text-xs text-white block">Holy Spirit Baptized (የመንፈስ ቅዱስ ጥምቀት)</label>
                        <span className="text-[11px] text-slate-400">With the evidence of spiritual gifts</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={isHolySpiritBaptized}
                        onChange={(e) => setIsHolySpiritBaptized(e.target.checked)}
                        className="w-5 h-5 rounded text-blue-600 cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Salvation Date (ጌታን የተቀበሉበት ቀን)</label>
                      <input
                        type="date"
                        value={salvationDate}
                        onChange={(e) => setSalvationDate(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Previous Church / Background</label>
                      <input
                        type="text"
                        placeholder="e.g. Mulu Wongel, Kale Heywet, Orthodox"
                        value={previousChurch}
                        onChange={(e) => setPreviousChurch(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                  </div>

                  {/* Ministry Interests Grid */}
                  <div className="pt-2">
                    <label className="block text-xs font-black text-slate-200 uppercase tracking-wider mb-2">
                      Ministries & Departments You Wish to Serve In (የሚያገለግሉበት ዘርፍ)
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {availableMinistries.map((min) => {
                        const isSelected = selectedMinistries.includes(min.name);
                        return (
                          <button
                            key={min.id}
                            type="button"
                            onClick={() => {
                              if (isSelected) {
                                setSelectedMinistries(selectedMinistries.filter((m) => m !== min.name));
                              } else {
                                setSelectedMinistries([...selectedMinistries, min.name]);
                              }
                            }}
                            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-blue-600/25 border-blue-500 text-white shadow-md'
                                : 'bg-slate-900 border-slate-700/80 text-slate-300 hover:border-slate-600'
                            }`}
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <p className="font-bold text-xs text-white">{min.name}</p>
                                <p className="text-[11px] text-slate-400 mt-0.5">{min.desc}</p>
                              </div>
                              <div className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 mt-0.5 ${
                                isSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-600'
                              }`}>
                                {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setCurrentSection(2)}
                    className="px-5 py-3 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-2xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-500/25 cursor-pointer transition-all"
                  >
                    Next: Final Step <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* SECTION 4: Emergency Contacts & Covenant Agreement */}
            {currentSection === 4 && (
              <form onSubmit={handleSubmit} className="space-y-4 animate-in fade-in">
                <div className="bg-slate-800 rounded-3xl p-5 sm:p-7 border border-slate-700 shadow-xl space-y-4">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-700 pb-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    4. Emergency Contact & Church Fellowship Covenant
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Emergency Contact Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Almaz Bekele"
                        value={emergencyName}
                        onChange={(e) => setEmergencyName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Relationship</label>
                      <input
                        type="text"
                        placeholder="e.g. Spouse, Parent, Sibling"
                        value={emergencyRelationship}
                        onChange={(e) => setEmergencyRelationship(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Emergency Phone Number</label>
                      <input
                        type="tel"
                        placeholder="0911000000"
                        value={emergencyPhone}
                        onChange={(e) => setEmergencyPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Special Prayer Requests or Pastoral Notes</label>
                    <textarea
                      rows={2}
                      placeholder="Share any special prayer requests, spiritual needs, or questions for our pastors..."
                      value={specialPrayerNeeds}
                      onChange={(e) => setSpecialPrayerNeeds(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Church Membership Covenant */}
                  <div className="p-4 bg-slate-900/90 rounded-2xl border border-blue-500/40 space-y-2.5">
                    <span className="font-black text-xs text-blue-300 uppercase tracking-wider block">
                      📜 Church Member Fellowship Covenant
                    </span>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      "Having accepted the Lord Jesus Christ as my personal Savior, and being in agreement with the doctrinal statement, vision, and leadership of {systemName || 'Grace Cathedral'}, I solemnly commit myself to fellowship, mutual edification, regular prayer, faithful stewardship, and honoring God in all aspects of my daily walk."
                    </p>
                    <label className="flex items-center gap-2.5 pt-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={covenantAgreed}
                        onChange={(e) => setCovenantAgreed(e.target.checked)}
                        className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-xs font-bold text-white">
                        I agree to this Fellowship Covenant and consent to church membership record storage.
                      </span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setCurrentSection(3)}
                    className="px-5 py-3 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-2xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-7 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 cursor-pointer transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? 'Recording Response...' : 'Submit Registration Questionnaire'}
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="max-w-3xl w-full mx-auto mt-6 text-center text-xs text-slate-500 space-y-1">
        <p>© 2026 {systemName || 'Grace Cathedral International Ministries'}. Powered by CMMS Digital Church Engine.</p>
        <p className="text-[11px] text-slate-600">Never submit passwords or sensitive financial credentials through this form.</p>
      </footer>
    </div>
  );
};
