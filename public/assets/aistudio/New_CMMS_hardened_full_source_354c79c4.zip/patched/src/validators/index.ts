import { z } from 'zod';
import {
  ETHIOPIAN_PHONE_REGEX,
  formatToE164,
  formatEthioPhone,
  validateEthiopianPhone,
  ethiopianPhoneSchema,
  ethiopianPhoneRawSchema,
  optionalEthiopianPhoneSchema,
} from '../schemas/phone.schema';

export {
  ETHIOPIAN_PHONE_REGEX,
  formatToE164,
  formatEthioPhone,
  validateEthiopianPhone,
  ethiopianPhoneSchema,
  ethiopianPhoneRawSchema,
  optionalEthiopianPhoneSchema,
};

export const LoginSchema = z.object({
  email: z.string().email({ message: 'Invalid email address format' }),
  password: z.string().optional(),
  mfaCode: z.string().optional(),
});

export const MemberCreateSchema = z.object({
  firstName: z.string().trim().min(2, 'First name must be at least 2 characters').max(100),
  middleName: z.string().trim().max(100).optional(),
  lastName: z.string().trim().min(2, 'Last name must be at least 2 characters').max(100),
  primaryPhone: ethiopianPhoneSchema,
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  gender: z.enum(['Male', 'Female']),
  maritalStatus: z.enum(['Single', 'Married', 'Divorced', 'Widowed', 'Separated']).optional(),
  dateOfBirth: z.string().optional(),
  membershipStatus: z.enum(['Active', 'Inactive', 'Under Discipline', 'Deceased', 'Transferred', 'Visiting', 'Pending Verification']).default('Active'),
  branchId: z.string().default('br-1'),
  branchName: z.string().optional(),
  ministryIds: z.array(z.string()).default([]),
  fellowshipGroup: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  occupation: z.string().optional(),
  emergencyContact: z.object({
    name: z.string().optional(),
    phone: z.string().optional(),
    relationship: z.string().optional(),
  }).optional(),
});

export const PastoralRecordSchema = z.object({
  memberId: z.string().min(1, 'Member ID is required'),
  memberName: z.string().optional(),
  counselorId: z.string().optional(),
  counselorName: z.string().optional(),
  category: z.enum([
    'Counseling',
    'Prayer Request',
    'Hospital Visitation',
    'Home Visitation',
    'Spiritual Guidance',
    'Marriage Preparation',
    'Bereavement Support',
    'Disciplinary'
  ]),
  confidentiality: z.enum([
    'PUBLIC',
    'MINISTERIAL',
    'CONFIDENTIAL',
    'STRICTLY_CONFIDENTIAL',
    'SEALED'
  ]).default('MINISTERIAL'),
  summary: z.string().min(3, 'Summary is required'),
  details: z.string().min(5, 'Details are required'),
  actionItems: z.string().optional(),
  followUpDate: z.string().optional(),
  status: z.enum(['Open', 'In Progress', 'Resolved', 'Closed']).default('Open'),
  branchId: z.string().default('br-1'),
});

export const AttendanceCheckinSchema = z.object({
  eventId: z.string().optional(),
  eventName: z.string().default('Sunday Main Celebration Service'),
  serviceType: z.string().default('Sunday Morning Service'),
  branchId: z.string().default('br-1'),
  memberId: z.string().optional(),
  visitorName: z.string().optional(),
  visitorPhone: z.string().optional(),
  checkinMethod: z.enum(['Manual', 'QR', 'Mobile', 'NFC', 'Kiosk', 'FacialBiometric']).default('Manual'),
  temperatureCelsius: z.number().optional(),
  notes: z.string().optional(),
});

export const WorkflowRequestSchema = z.object({
  requestType: z.string().min(2, 'Request type is required'),
  requesterName: z.string().min(2, 'Requester name is required'),
  requesterEmail: z.string().email().optional(),
  branchId: z.string().default('br-1'),
  amount: z.number().optional(),
  details: z.string().min(5, 'Details are required'),
  category: z.string().optional(),
});
