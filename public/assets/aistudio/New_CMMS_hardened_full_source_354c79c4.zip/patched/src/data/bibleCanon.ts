import type { BibleVerseItem, BibleChapterData } from './bibleData';
export type { BibleVerseItem, BibleChapterData };

export interface BibleBookInfo {
  id: string;
  nameEnglish: string;
  nameAmharic: string;
  shortCode: string;
  testament: 'Old' | 'New';
  category: 'Law' | 'History' | 'Poetry' | 'Major Prophets' | 'Minor Prophets' | 'Gospels' | 'Church History' | 'Pauline Epistles' | 'General Epistles' | 'Prophecy';
  categoryAmharic: string;
  chaptersCount: number;
}

export const BIBLE_CANON: BibleBookInfo[] = [
  // OLD TESTAMENT (39 Books / ብሉይ ኪዳን)
  // Law / ኦሪት
  { id: 'GEN', nameEnglish: 'Genesis', nameAmharic: 'ኦሪት ዘፍጥረት', shortCode: 'ዘፍ', testament: 'Old', category: 'Law', categoryAmharic: 'የሕግ መጻሕፍት (ኦሪት)', chaptersCount: 50 },
  { id: 'EXO', nameEnglish: 'Exodus', nameAmharic: 'ኦሪት ዘጸአት', shortCode: 'ዘጸ', testament: 'Old', category: 'Law', categoryAmharic: 'የሕግ መጻሕፍት (ኦሪት)', chaptersCount: 40 },
  { id: 'LEV', nameEnglish: 'Leviticus', nameAmharic: 'ኦሪት ዘሌዋውያን', shortCode: 'ዘሌ', testament: 'Old', category: 'Law', categoryAmharic: 'የሕግ መጻሕፍት (ኦሪት)', chaptersCount: 27 },
  { id: 'NUM', nameEnglish: 'Numbers', nameAmharic: 'ኦሪት ዘኍልቍ', shortCode: 'ዘኍ', testament: 'Old', category: 'Law', categoryAmharic: 'የሕግ መጻሕፍት (ኦሪት)', chaptersCount: 36 },
  { id: 'DEU', nameEnglish: 'Deuteronomy', nameAmharic: 'ኦሪት ዘዳግም', shortCode: 'ዘዳ', testament: 'Old', category: 'Law', categoryAmharic: 'የሕግ መጻሕፍት (ኦሪት)', chaptersCount: 34 },
  
  // Historical Books / ታሪክ
  { id: 'JOS', nameEnglish: 'Joshua', nameAmharic: 'መጽሐፈ ኢያሱ', shortCode: 'ኢያ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 24 },
  { id: 'JDG', nameEnglish: 'Judges', nameAmharic: 'መጽሐፈ መሳፍንት', shortCode: 'መሳ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 21 },
  { id: 'RUT', nameEnglish: 'Ruth', nameAmharic: 'መጽሐፈ ሩት', shortCode: 'ሩት', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 4 },
  { id: '1SA', nameEnglish: '1 Samuel', nameAmharic: 'መጽሐፈ ሳሙኤል ቀዳማዊ', shortCode: '1ሳሙ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 31 },
  { id: '2SA', nameEnglish: '2 Samuel', nameAmharic: 'መጽሐፈ ሳሙኤል ካልዕ', shortCode: '2ሳሙ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 24 },
  { id: '1KI', nameEnglish: '1 Kings', nameAmharic: 'መጽሐፈ ነገሥት ቀዳማዊ', shortCode: '1ነገ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 22 },
  { id: '2KI', nameEnglish: '2 Kings', nameAmharic: 'መጽሐፈ ነገሥት ካልዕ', shortCode: '2ነገ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 25 },
  { id: '1CH', nameEnglish: '1 Chronicles', nameAmharic: 'መጽሐፈ ዜና መዋዕል ቀዳማዊ', shortCode: '1ዜና', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 29 },
  { id: '2CH', nameEnglish: '2 Chronicles', nameAmharic: 'መጽሐፈ ዜና መዋዕል ካልዕ', shortCode: '2ዜና', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 36 },
  { id: 'EZR', nameEnglish: 'Ezra', nameAmharic: 'መጽሐፈ ዕዝራ', shortCode: 'ዕዝ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 10 },
  { id: 'NEH', nameEnglish: 'Nehemiah', nameAmharic: 'መጽሐፈ ነህምያ', shortCode: 'ነህ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 13 },
  { id: 'EST', nameEnglish: 'Esther', nameAmharic: 'መጽሐፈ አስቴር', shortCode: 'አስ', testament: 'Old', category: 'History', categoryAmharic: 'የታሪክ መጻሕፍት', chaptersCount: 10 },

  // Poetry & Wisdom / ቅኔና ጥበብ
  { id: 'JOB', nameEnglish: 'Job', nameAmharic: 'መጽሐፈ ኢዮብ', shortCode: 'ኢዮ', testament: 'Old', category: 'Poetry', categoryAmharic: 'የቅኔና ጥበብ መጻሕፍት', chaptersCount: 42 },
  { id: 'PSA', nameEnglish: 'Psalms', nameAmharic: 'መዝሙረ ዳዊት', shortCode: 'መዝ', testament: 'Old', category: 'Poetry', categoryAmharic: 'የቅኔና ጥበብ መጻሕፍት', chaptersCount: 150 },
  { id: 'PRO', nameEnglish: 'Proverbs', nameAmharic: 'መጽሐፈ ምሳሌ', shortCode: 'ምሳ', testament: 'Old', category: 'Poetry', categoryAmharic: 'የቅኔና ጥበብ መጻሕፍት', chaptersCount: 31 },
  { id: 'ECC', nameEnglish: 'Ecclesiastes', nameAmharic: 'መጽሐፈ መክብብ', shortCode: 'መክ', testament: 'Old', category: 'Poetry', categoryAmharic: 'የቅኔና ጥበብ መጻሕፍት', chaptersCount: 12 },
  { id: 'SNG', nameEnglish: 'Song of Solomon', nameAmharic: 'መኃልየ መኃልይ ዘሰሎሞን', shortCode: 'መኃ', testament: 'Old', category: 'Poetry', categoryAmharic: 'የቅኔና ጥበብ መጻሕፍት', chaptersCount: 8 },

  // Major Prophets / ዓበይት ነቢያት
  { id: 'ISA', nameEnglish: 'Isaiah', nameAmharic: 'ትንቢተ ኢሳይያስ', shortCode: 'ኢሳ', testament: 'Old', category: 'Major Prophets', categoryAmharic: 'ዓበይት ነቢያት', chaptersCount: 66 },
  { id: 'JER', nameEnglish: 'Jeremiah', nameAmharic: 'ትንቢተ ኤርምያስ', shortCode: 'ኤር', testament: 'Old', category: 'Major Prophets', categoryAmharic: 'ዓበይት ነቢያት', chaptersCount: 52 },
  { id: 'LAM', nameEnglish: 'Lamentations', nameAmharic: 'ሰቆቃወ ኤርምያስ', shortCode: 'ሰቆ', testament: 'Old', category: 'Major Prophets', categoryAmharic: 'ዓበይት ነቢያት', chaptersCount: 5 },
  { id: 'EZK', nameEnglish: 'Ezekiel', nameAmharic: 'ትንቢተ ሕዝቅኤል', shortCode: 'ሕዝ', testament: 'Old', category: 'Major Prophets', categoryAmharic: 'ዓበይት ነቢያት', chaptersCount: 48 },
  { id: 'DAN', nameEnglish: 'Daniel', nameAmharic: 'ትንቢተ ዳንኤል', shortCode: 'ዳን', testament: 'Old', category: 'Major Prophets', categoryAmharic: 'ዓበይት ነቢያት', chaptersCount: 12 },

  // Minor Prophets / ደቂቀ ነቢያት
  { id: 'HOS', nameEnglish: 'Hosea', nameAmharic: 'ትንቢተ ሆሴዕ', shortCode: 'ሆሴ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 14 },
  { id: 'JOL', nameEnglish: 'Joel', nameAmharic: 'ትንቢተ ኢዩኤል', shortCode: 'ኢዩ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 3 },
  { id: 'AMO', nameEnglish: 'Amos', nameAmharic: 'ትንቢተ አሞጽ', shortCode: 'አሞ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 9 },
  { id: 'OBA', nameEnglish: 'Obadiah', nameAmharic: 'ትንቢተ አብድዩ', shortCode: 'አብ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 1 },
  { id: 'JON', nameEnglish: 'Jonah', nameAmharic: 'ትንቢተ ዮናስ', shortCode: 'ዮና', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 4 },
  { id: 'MIC', nameEnglish: 'Micah', nameAmharic: 'ትንቢተ ሚክያስ', shortCode: 'ሚክ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 7 },
  { id: 'NAH', nameEnglish: 'Nahum', nameAmharic: 'ትንቢተ ናሆም', shortCode: 'ናሆ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 3 },
  { id: 'HAB', nameEnglish: 'Habakkuk', nameAmharic: 'ትንቢተ ዕንባቆም', shortCode: 'ዕን', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 3 },
  { id: 'ZEP', nameEnglish: 'Zephaniah', nameAmharic: 'ትንቢተ ሶፎንያስ', shortCode: 'ሶፎ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 3 },
  { id: 'HAG', nameEnglish: 'Haggai', nameAmharic: 'ትንቢተ ሐጌ', shortCode: 'ሐጌ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 2 },
  { id: 'ZEC', nameEnglish: 'Zechariah', nameAmharic: 'ትንቢተ ዘካርያስ', shortCode: 'ዘካ', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 14 },
  { id: 'MAL', nameEnglish: 'Malachi', nameAmharic: 'ትንቢተ ሚልክያስ', shortCode: 'ሚል', testament: 'Old', category: 'Minor Prophets', categoryAmharic: 'ደቂቀ ነቢያት', chaptersCount: 4 },

  // NEW TESTAMENT (27 Books / ሐዲስ ኪዳን)
  // Gospels / ወንጌላት
  { id: 'MAT', nameEnglish: 'Matthew', nameAmharic: 'የማቴዎስ ወንጌል', shortCode: 'ማቴ', testament: 'New', category: 'Gospels', categoryAmharic: 'ወንጌላት', chaptersCount: 28 },
  { id: 'MRK', nameEnglish: 'Mark', nameAmharic: 'የማርቆስ ወንጌል', shortCode: 'ማር', testament: 'New', category: 'Gospels', categoryAmharic: 'ወንጌላት', chaptersCount: 16 },
  { id: 'LUK', nameEnglish: 'Luke', nameAmharic: 'የሉቃስ ወንጌል', shortCode: 'ሉቃ', testament: 'New', category: 'Gospels', categoryAmharic: 'ወንጌላት', chaptersCount: 24 },
  { id: 'JHN', nameEnglish: 'John', nameAmharic: 'የዮሐንስ ወንጌል', shortCode: 'ዮሐ', testament: 'New', category: 'Gospels', categoryAmharic: 'ወንጌላት', chaptersCount: 21 },

  // Church History / የታሪክ መጽሐፍ
  { id: 'ACT', nameEnglish: 'Acts', nameAmharic: 'የሐዋርያት ሥራ', shortCode: 'ሐዋ', testament: 'New', category: 'Church History', categoryAmharic: 'የታሪክ መጽሐፍ', chaptersCount: 28 },

  // Pauline Epistles / የጳውሎስ መልእክታት
  { id: 'ROM', nameEnglish: 'Romans', nameAmharic: 'ወደ ሮሜ ሰዎች', shortCode: 'ሮሜ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 16 },
  { id: '1CO', nameEnglish: '1 Corinthians', nameAmharic: '1ኛ ወደ ቆሮንቶስ ሰዎች', shortCode: '1ቆሮ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 16 },
  { id: '2CO', nameEnglish: '2 Corinthians', nameAmharic: '2ኛ ወደ ቆሮንቶስ ሰዎች', shortCode: '2ቆሮ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 13 },
  { id: 'GAL', nameEnglish: 'Galatians', nameAmharic: 'ወደ ገላትያ ሰዎች', shortCode: 'ገላ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 6 },
  { id: 'EPH', nameEnglish: 'Ephesians', nameAmharic: 'ወደ ኤፌሶን ሰዎች', shortCode: 'ኤፌ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 6 },
  { id: 'PHP', nameEnglish: 'Philippians', nameAmharic: 'ወደ ፊልጵስዩስ ሰዎች', shortCode: 'ፊል', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 4 },
  { id: 'COL', nameEnglish: 'Colossians', nameAmharic: 'ወደ ቆላስይስ ሰዎች', shortCode: 'ቆላ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 4 },
  { id: '1TH', nameEnglish: '1 Thessalonians', nameAmharic: '1ኛ ወደ ተሰሎንቄ ሰዎች', shortCode: '1ተሰ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 5 },
  { id: '2TH', nameEnglish: '2 Thessalonians', nameAmharic: '2ኛ ወደ ተሰሎንቄ ሰዎች', shortCode: '2ተሰ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 3 },
  { id: '1TI', nameEnglish: '1 Timothy', nameAmharic: '1ኛ ወደ ጢሞቴዎስ', shortCode: '1ጢሞ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 6 },
  { id: '2TI', nameEnglish: '2 Timothy', nameAmharic: '2ኛ ወደ ጢሞቴዎስ', shortCode: '2ጢሞ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 4 },
  { id: 'TIT', nameEnglish: 'Titus', nameAmharic: 'ወደ ቲቶ', shortCode: 'ቲቶ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 3 },
  { id: 'PHM', nameEnglish: 'Philemon', nameAmharic: 'ወደ ፊልሞና', shortCode: 'ፊልሞ', testament: 'New', category: 'Pauline Epistles', categoryAmharic: 'የጳውሎስ መልእክታት', chaptersCount: 1 },

  // General Epistles / የሐዋርያት መልእክታት
  { id: 'HEB', nameEnglish: 'Hebrews', nameAmharic: 'ወደ ዕብራውያን', shortCode: 'ዕብ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 13 },
  { id: 'JAS', nameEnglish: 'James', nameAmharic: 'የያዕቆብ መልእክት', shortCode: 'ያዕ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 5 },
  { id: '1PE', nameEnglish: '1 Peter', nameAmharic: '1ኛ የጴጥሮስ መልእክት', shortCode: '1ጴጥ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 5 },
  { id: '2PE', nameEnglish: '2 Peter', nameAmharic: '2ኛ የጴጥሮስ መልእክት', shortCode: '2ጴጥ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 3 },
  { id: '1JN', nameEnglish: '1 John', nameAmharic: '1ኛ የዮሐንስ መልእክት', shortCode: '1ዮሐ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 5 },
  { id: '2JN', nameEnglish: '2 John', nameAmharic: '2ኛ የዮሐንስ መልእክት', shortCode: '2ዮሐ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 1 },
  { id: '3JN', nameEnglish: '3 John', nameAmharic: '3ኛ የዮሐንስ መልእክት', shortCode: '3ዮሐ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 1 },
  { id: 'JUD', nameEnglish: 'Jude', nameAmharic: 'የይሁዳ መልእክት', shortCode: 'ይሁ', testament: 'New', category: 'General Epistles', categoryAmharic: 'የሐዋርያት መልእክታት', chaptersCount: 1 },

  // Prophecy / የትንቢት መጽሐፍ
  { id: 'REV', nameEnglish: 'Revelation', nameAmharic: 'የዮሐንስ ራእይ', shortCode: 'ራእ', testament: 'New', category: 'Prophecy', categoryAmharic: 'የትንቢት መጽሐፍ', chaptersCount: 22 },
];
