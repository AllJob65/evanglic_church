/**
 * CMMS Holy Bible Data Types & Interfaces
 *
 * NOTE: The Holy Bible reader uses YouVersion Bible API/content as the single authoritative Scripture source.
 * All locally stored/generated Scripture databases (such as FULL_CHAPTERS_DATABASE and hardcoded fallback verses)
 * have been completely removed to prevent unauthorized or fabricated Scripture text from ever being displayed.
 */

import { BIBLE_CANON, BibleBookInfo } from './bibleCanon';

export interface BibleVerseItem {
  verseKey?: string;
  verseNumber: number;
  textAmharic: string;
  textEnglish: string;
  verse?: number;
  amharic?: string;
  english?: string;
  textKJV?: string;
  textNIV?: string;
  isRedLetter?: boolean; // Words of Jesus
}

export interface BibleChapterData {
  bookId: string;
  bookEnglish: string;
  bookAmharic: string;
  chapter: number;
  testament: 'Old' | 'New';
  summary?: string;
  verses: BibleVerseItem[];
}

export interface ReadingPlan {
  id: string;
  titleEnglish: string;
  titleAmharic: string;
  description: string;
  durationDays: number;
  category: 'Gospel' | 'Wisdom' | 'Faith' | 'Complete';
  readings: {
    day: number;
    passage: string;
    passageAmharic: string;
    bookId: string;
    chapter: number;
  }[];
}

export const BIBLE_READING_PLANS: ReadingPlan[] = [];

// Canonical book lookup helper
export function getBibleBook(bookIdOrName: string): BibleBookInfo | undefined {
  return BIBLE_CANON.find(
    (b) =>
      b.id.toLowerCase() === bookIdOrName.toLowerCase() ||
      b.nameEnglish.toLowerCase() === bookIdOrName.toLowerCase() ||
      b.nameAmharic === bookIdOrName ||
      b.shortCode === bookIdOrName
  );
}
