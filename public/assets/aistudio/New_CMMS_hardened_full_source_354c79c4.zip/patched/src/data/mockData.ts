import {
  Member,
  Family,
  Branch,
  Ministry,
  AttendanceRecord,
  AttendanceSession,
  EventItem,
  CommunicationMessage,
  PrayerRequest,
  CounselingSession,
  VisitationRecord,
  VolunteerShift,
  Asset,
  DocumentItem,
  LmsCourse,
  WorkflowRequest,
  AuditLog,
  ProfileChangeRequest,
  SystemUser,
} from '../types';

/**
 * Authoritative Empty Collections
 * No fake, demo, or placeholder records are seeded.
 * All application records are loaded from the authoritative backend/PostgreSQL database.
 */
export const initialBranches: Branch[] = [];
export const initialMembers: Member[] = [];
export const initialFamilies: Family[] = [];
export const initialMinistries: Ministry[] = [];
export const initialAttendanceRecords: AttendanceRecord[] = [];
export const initialAttendanceSessions: AttendanceSession[] = [];
export const initialEvents: EventItem[] = [];
export const initialCommunications: CommunicationMessage[] = [];
export const initialPrayerRequests: PrayerRequest[] = [];
export const initialCounselingSessions: CounselingSession[] = [];
export const initialVisitations: VisitationRecord[] = [];
export const initialVolunteerShifts: VolunteerShift[] = [];
export const initialAssets: Asset[] = [];
export const initialDocuments: DocumentItem[] = [];
export const initialCourses: LmsCourse[] = [];
export const initialWorkflows: WorkflowRequest[] = [];
export const initialAuditLogs: AuditLog[] = [];
export const initialSystemUsers: SystemUser[] = [];
export const initialProfileChangeRequests: ProfileChangeRequest[] = [];
