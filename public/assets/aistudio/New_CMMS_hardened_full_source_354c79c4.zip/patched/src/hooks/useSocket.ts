import { useEffect, useState } from 'react';
import { getClientSocket } from '../services/clientSocket';
import { AttendanceRecord, WorkflowRequest } from '../types';

export function useRealtimeUpdates(options?: {
  onAttendanceCheckIn?: (record: AttendanceRecord) => void;
  onPendingApproval?: (workflow: WorkflowRequest) => void;
  onApprovalStatusChanged?: (workflow: WorkflowRequest) => void;
}) {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [lastCheckIn, setLastCheckIn] = useState<AttendanceRecord | null>(null);
  const [lastApproval, setLastApproval] = useState<WorkflowRequest | null>(null);

  useEffect(() => {
    const socket = getClientSocket();

    const handleConnect = () => setIsConnected(true);
    const handleDisconnect = () => setIsConnected(false);

    if (socket.connected) {
      setIsConnected(true);
    }

    socket.on('connect', handleConnect);
    socket.on('disconnect', handleDisconnect);

    socket.on('attendance:checkin', (data: { record: AttendanceRecord }) => {
      if (data?.record) {
        setLastCheckIn(data.record);
        options?.onAttendanceCheckIn?.(data.record);
      }
    });

    socket.on('approval:new_pending', (data: { workflow: WorkflowRequest }) => {
      if (data?.workflow) {
        setLastApproval(data.workflow);
        options?.onPendingApproval?.(data.workflow);
      }
    });

    socket.on('approval:status_changed', (data: { workflow: WorkflowRequest }) => {
      if (data?.workflow) {
        setLastApproval(data.workflow);
        options?.onApprovalStatusChanged?.(data.workflow);
      }
    });

    return () => {
      socket.off('connect', handleConnect);
      socket.off('disconnect', handleDisconnect);
      socket.off('attendance:checkin');
      socket.off('approval:new_pending');
      socket.off('approval:status_changed');
    };
  }, []);

  return {
    isConnected,
    lastCheckIn,
    lastApproval,
  };
}
