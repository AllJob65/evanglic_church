import { useState, useEffect, useCallback, useRef } from 'react';
import { supabaseMinistryService } from '../services/supabaseMinistryService';
import { MinistryChatMessage, MinistryMemberRecord, MinistryActivityLog } from '../types';

interface RealtimeUser {
  id?: string;
  name: string;
  email?: string;
  role?: string;
  avatar?: string;
}

export function useMinistryRealtime(ministryId: string, currentUser?: RealtimeUser) {
  const [messages, setMessages] = useState<MinistryChatMessage[]>([]);
  const [members, setMembers] = useState<MinistryMemberRecord[]>([]);
  const [activityLogs, setActivityLogs] = useState<MinistryActivityLog[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isConnected, setIsConnected] = useState<boolean>(true);

  const typingTimeoutRef = useRef<Record<string, NodeJS.Timeout>>({});
  const broadcastTypingRef = useRef<((userName: string, isTyping: boolean) => void) | null>(null);

  // Load initial data
  const loadData = useCallback(async () => {
    if (!ministryId) return;
    setIsLoading(true);
    try {
      const [fetchedMessages, fetchedMembers, fetchedLogs] = await Promise.all([
        supabaseMinistryService.getMinistryMessages(ministryId),
        supabaseMinistryService.getMinistryMembers(ministryId),
        supabaseMinistryService.getActivityLogs(ministryId),
      ]);
      setMessages(fetchedMessages);
      setMembers(fetchedMembers);
      setActivityLogs(fetchedLogs);
    } catch (err) {
      console.warn('Error loading ministry realtime data:', err);
    } finally {
      setIsLoading(false);
    }
  }, [ministryId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Set up Supabase Realtime Channel
  useEffect(() => {
    if (!ministryId) return;

    const chatSubscription = supabaseMinistryService.subscribeToMinistryMessages(ministryId, {
      onNewMessage: (newMsg) => {
        setMessages((prev) => {
          // Avoid duplicate insertion
          if (prev.some((m) => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
      },
      onReactionUpdated: (messageId, reactions) => {
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, reactions } : m))
        );
      },
      onMessageDeleted: (deletedId) => {
        setMessages((prev) => prev.filter((m) => m.id !== deletedId));
      },
      onTyping: (userName, isTyping) => {
        if (!userName || (currentUser && userName === currentUser.name)) return;
        if (isTyping) {
          setTypingUsers((prev) => (prev.includes(userName) ? prev : [...prev, userName]));
          // Clear after 3 seconds
          if (typingTimeoutRef.current[userName]) {
            clearTimeout(typingTimeoutRef.current[userName]);
          }
          typingTimeoutRef.current[userName] = setTimeout(() => {
            setTypingUsers((prev) => prev.filter((u) => u !== userName));
          }, 3000);
        } else {
          setTypingUsers((prev) => prev.filter((u) => u !== userName));
        }
      },
    });

    broadcastTypingRef.current = chatSubscription.broadcastTyping;

    const activitySubscription = supabaseMinistryService.subscribeToMinistryActivity(
      ministryId,
      (newActivity) => {
        setActivityLogs((prev) => [newActivity, ...prev.slice(0, 30)]);
      }
    );

    return () => {
      chatSubscription.unsubscribe();
      activitySubscription.unsubscribe();
      Object.values(typingTimeoutRef.current).forEach(clearTimeout);
    };
  }, [ministryId, currentUser]);

  // Send message with optimistic update
  const sendMessage = useCallback(
    async (text: string, scriptureRef?: string, attachmentUrl?: string, attachmentName?: string) => {
      if (!text.trim() || !ministryId) return;

      const senderName = currentUser?.name || 'Fellowship Member';
      const senderRole = currentUser?.role || 'Member';
      const senderEmail = currentUser?.email;
      const senderAvatar = currentUser?.avatar;
      const senderId = currentUser?.id || `usr-${Date.now()}`;

      // Optimistic message
      const tempId = `temp-${Date.now()}`;
      const optimisticMsg: MinistryChatMessage = {
        id: tempId,
        tenantId: 'tenant-grace-main',
        ministryId,
        ministryName: 'Ministry Fellowship',
        senderId,
        senderName,
        senderEmail: senderEmail || '',
        senderRole,
        senderAvatar,
        text,
        scriptureRef,
        attachmentUrl,
        attachmentName,
        timestamp: new Date().toISOString(),
        reactions: [],
      };

      setMessages((prev) => [...prev, optimisticMsg]);

      // Stop typing broadcast
      if (broadcastTypingRef.current) {
        broadcastTypingRef.current(senderName, false);
      }

      try {
        const savedMsg = await supabaseMinistryService.sendMinistryMessage(ministryId, {
          text,
          scriptureRef,
          attachmentUrl,
          attachmentName,
          senderId,
          senderName,
          senderEmail,
          senderRole,
          senderAvatar,
        });

        // Replace optimistic msg with real ID
        setMessages((prev) => prev.map((m) => (m.id === tempId ? savedMsg : m)));
      } catch (err) {
        console.error('Failed to send message:', err);
      }
    },
    [ministryId, currentUser]
  );

  // Add or toggle emoji reaction
  const addReaction = useCallback(
    async (messageId: string, emoji: string) => {
      if (!ministryId || !messageId || !emoji) return;
      const userId = currentUser?.id || 'usr-current';
      const userName = currentUser?.name || 'Member';

      // Optimistic update
      setMessages((prev) =>
        prev.map((msg) => {
          if (msg.id !== messageId) return msg;
          const currentReactions = [...(msg.reactions || [])];
          const existing = currentReactions.find((r) => r.emoji === emoji);
          if (existing) {
            if (!existing.users.includes(userId)) {
              existing.users = [...existing.users, userId];
              existing.count += 1;
            }
          } else {
            currentReactions.push({ emoji, count: 1, users: [userId] });
          }
          return { ...msg, reactions: currentReactions };
        })
      );

      try {
        const updatedReactions = await supabaseMinistryService.reactToMinistryMessage(
          ministryId,
          messageId,
          emoji,
          userId,
          userName
        );
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, reactions: updatedReactions } : m))
        );
      } catch (err) {
        console.error('Reaction sync failed:', err);
      }
    },
    [ministryId, currentUser]
  );

  // Delete message
  const deleteMessage = useCallback(
    async (messageId: string) => {
      setMessages((prev) => prev.filter((m) => m.id !== messageId));
      await supabaseMinistryService.deleteMinistryMessage(ministryId, messageId);
    },
    [ministryId]
  );

  // Send typing notification
  const sendTyping = useCallback(
    (isTyping: boolean) => {
      if (broadcastTypingRef.current && currentUser?.name) {
        broadcastTypingRef.current(currentUser.name, isTyping);
      }
    },
    [currentUser]
  );

  return {
    messages,
    members,
    activityLogs,
    typingUsers,
    isLoading,
    isConnected,
    sendMessage,
    addReaction,
    deleteMessage,
    sendTyping,
    reload: loadData,
  };
}
