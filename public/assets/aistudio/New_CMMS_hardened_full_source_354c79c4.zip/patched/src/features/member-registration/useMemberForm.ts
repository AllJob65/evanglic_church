import { useState, useCallback } from 'react';
import { RegistrationFormValues } from './memberForm.types';
import { MEMBER_FIELDS_MAP } from './memberForm.schema';
import { validateEthiopianPhone } from '../../schemas/phone.schema';
import { validateEmail } from '../../schemas/email.schema';

export interface UseMemberFormOptions {
  initialValues?: Partial<RegistrationFormValues>;
  activeFields?: string[];
  onSubmit?: (values: RegistrationFormValues) => Promise<void> | void;
}

export function useMemberForm({
  initialValues = {},
  activeFields,
  onSubmit,
}: UseMemberFormOptions = {}) {
  const [values, setValues] = useState<RegistrationFormValues>(() => ({
    title: 'Brother',
    gender: 'Male',
    maritalStatus: 'Single',
    nationality: 'Ethiopian',
    city: 'Addis Ababa',
    preferredCommChannel: 'SMS',
    membershipStatus: 'Pending',
    membershipType: 'Full Member',
    isWaterBaptized: true,
    isHolySpiritBaptized: true,
    agreeTerms: true,
    ...initialValues,
  }));

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  /**
   * Updates a single field value and clears its error if valid
   */
  const setField = useCallback((field: string, value: any) => {
    setValues((prev) => {
      const next = { ...prev, [field]: value };

      // Automatic synchronization between alias and canonical properties
      if (field === 'phone') next.primaryPhone = value;
      if (field === 'primaryPhone') next.phone = value;
      if (field === 'dob') next.dateOfBirth = value;
      if (field === 'dateOfBirth') next.dob = value;
      if (field === 'address') next.streetAddress = value;
      if (field === 'streetAddress') next.address = value;
      if (field === 'isBaptized') next.isWaterBaptized = value;
      if (field === 'isWaterBaptized') next.isBaptized = value;
      if (field === 'emergencyRelation') next.emergencyRelationship = value;
      if (field === 'emergencyRelationship') next.emergencyRelation = value;
      if (field === 'specialPrayerNeeds' || field === 'prayerNotes') next.notes = value;
      if (field === 'covenantAgreed') next.agreeTerms = value;
      if (field === 'selectedBranchId') next.branchId = value;
      if (field === 'selectedMinistries') next.ministryIds = value;

      return next;
    });

    setTouched((prev) => ({ ...prev, [field]: true }));
  }, []);

  /**
   * Sets multiple fields at once
   */
  const setFields = useCallback((newFields: Partial<RegistrationFormValues>) => {
    setValues((prev) => ({ ...prev, ...newFields }));
  }, []);

  /**
   * Validates a single field
   */
  const validateField = useCallback(
    (field: string, valOverride?: any): string | null => {
      const val = valOverride !== undefined ? valOverride : (values as any)[field];
      const def = MEMBER_FIELDS_MAP.get(field);

      // Check conditional visibility
      if (def?.showWhen && !def.showWhen(values)) {
        return null;
      }

      // 1. Required check
      if (def?.required) {
        if (val === undefined || val === null || val === '') {
          return `${def.defaultLabel} is required`;
        }
        if (typeof val === 'string' && !val.trim()) {
          return `${def.defaultLabel} is required`;
        }
        if (typeof val === 'boolean' && !val) {
          return `${def.defaultLabel} is required`;
        }
      }

      // 2. Specialized phone checks
      if (field === 'primaryPhone' || field === 'phone' || field === 'emergencyPhone' || field === 'spousePhone') {
        if (val && typeof val === 'string' && val.trim()) {
          const check = validateEthiopianPhone(val);
          if (!check.isValid) {
            return check.error || 'Invalid Ethiopian phone format';
          }
        }
      }

      // 3. Specialized email check
      if (field === 'email' && val && typeof val === 'string' && val.trim()) {
        const check = validateEmail(val);
        if (!check.isValid) {
          return check.error || 'Invalid email format';
        }
      }

      // 4. Custom field validator from schema definition
      if (def?.validate) {
        const customErr = def.validate(val, values);
        if (customErr) return customErr;
      }

      return null;
    },
    [values]
  );

  /**
   * Validates all active fields or all schema fields
   */
  const validateAll = useCallback((): boolean => {
    const fieldsToValidate =
      activeFields && activeFields.length > 0
        ? activeFields
        : Array.from(MEMBER_FIELDS_MAP.keys());

    const newErrors: Record<string, string> = {};
    const newTouched: Record<string, boolean> = {};

    for (const fieldId of fieldsToValidate) {
      newTouched[fieldId] = true;
      const err = validateField(fieldId);
      if (err) {
        newErrors[fieldId] = err;
      }
    }

    setTouched((prev) => ({ ...prev, ...newTouched }));
    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  }, [activeFields, validateField]);

  /**
   * Reset form to initial state
   */
  const reset = useCallback(
    (newValues?: Partial<RegistrationFormValues>) => {
      setValues({
        title: 'Brother',
        gender: 'Male',
        maritalStatus: 'Single',
        nationality: 'Ethiopian',
        city: 'Addis Ababa',
        preferredCommChannel: 'SMS',
        membershipStatus: 'Pending',
        membershipType: 'Full Member',
        isWaterBaptized: true,
        isHolySpiritBaptized: true,
        agreeTerms: true,
        ...(newValues || initialValues),
      });
      setErrors({});
      setTouched({});
      setIsSubmitting(false);
    },
    [initialValues]
  );

  /**
   * Form submit handler that preserves values on error
   */
  const handleSubmit = useCallback(
    async (e?: React.FormEvent): Promise<boolean> => {
      if (e) e.preventDefault();

      const isValid = validateAll();
      if (!isValid) {
        // Values are strictly preserved when validation fails
        return false;
      }

      if (onSubmit) {
        try {
          setIsSubmitting(true);
          await onSubmit(values);
          return true;
        } catch (err: any) {
          setErrors((prev) => ({
            ...prev,
            _submit: err.message || 'Submission failed. Please try again.',
          }));
          return false;
        } finally {
          setIsSubmitting(false);
        }
      }

      return true;
    },
    [validateAll, onSubmit, values]
  );

  return {
    values,
    errors,
    touched,
    isSubmitting,
    setIsSubmitting,
    setField,
    setFields,
    validateField,
    validateAll,
    reset,
    handleSubmit,
  };
}
