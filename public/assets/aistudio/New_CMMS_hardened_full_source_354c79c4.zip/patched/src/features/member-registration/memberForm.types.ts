import { Member, Gender, MaritalStatus, MembershipStatus, MembershipType, EmergencyContact } from '../../types';

/**
 * Account-only fields for self-service portal registration and signup
 */
export interface AccountFormValues {
  password?: string;
  confirmPassword?: string;
  agreeTerms?: boolean;
}

/**
 * Canonical form values for member registration and management.
 * Based on Partial<Member> from src/types.ts.
 */
export interface MemberFormValues extends Partial<Member> {
  // Flattened Emergency Contact fields for form binding convenience
  emergencyName?: string;
  emergencyPhone?: string;
  emergencyRelationship?: string;
  emergencyRelation?: string; // Legacy alias for emergencyRelationship
  
  // Legacy aliases mapped canonically
  phone?: string;             // Legacy alias for primaryPhone
  dob?: string;               // Legacy alias for dateOfBirth
  address?: string;           // Legacy alias for streetAddress
  isBaptized?: boolean;       // Legacy alias for isWaterBaptized
  specialPrayerNeeds?: string; // Mapped to notes
  prayerNotes?: string;        // Mapped to notes
  covenantAgreed?: boolean;    // Mapped to agreeTerms

  // Form helper / selection fields
  selectedBranchId?: string;   // Canonical: branchId
  selectedMinistries?: string[]; // Canonical: ministryIds / ministriesJoinedNow
}

/**
 * Combined type used by self-service public registration forms requiring login credentials
 */
export type RegistrationFormValues = MemberFormValues & AccountFormValues;

/**
 * Form section categorization for multi-step, tabbed, card, or single-page views
 */
export type FormSection =
  | 'account'
  | 'personal'
  | 'contact'
  | 'address'
  | 'family'
  | 'spiritual'
  | 'education_profession'
  | 'emergency'
  | 'pastoral_care'
  | 'church_admin';

/**
 * Supported field input component types
 */
export type FormFieldType =
  | 'text'
  | 'tel'
  | 'email'
  | 'date'
  | 'select'
  | 'multi-select'
  | 'radio'
  | 'checkbox'
  | 'textarea'
  | 'password'
  | 'number';

export interface SelectOption {
  value: string;
  labelKey: string;
  defaultLabel: string;
}

/**
 * Field definition schema item
 */
export interface MemberFormFieldDefinition {
  id: string; // Matches a Member property (or AccountFormValues / flattened helper property)
  section: FormSection;
  type: FormFieldType;
  labelKey: string;
  defaultLabel: string;
  placeholderKey?: string;
  defaultPlaceholder?: string;
  helperTextKey?: string;
  defaultHelperText?: string;
  required?: boolean;
  options?: SelectOption[];
  inputMode?: 'text' | 'tel' | 'email' | 'numeric' | 'decimal' | 'search' | 'url';
  colSpan?: 1 | 2; // 1 = half width on sm+, 2 = full width
  validate?: (value: any, allValues: Record<string, any>) => string | null | undefined;
  showWhen?: (values: Record<string, any>) => boolean;
  componentOverride?: React.ComponentType<any>;
}

/**
 * Helper to sync between flattened emergency fields and Member.emergencyContact
 */
export function normalizeEmergencyContact(values: MemberFormValues): EmergencyContact {
  if (values.emergencyContact && values.emergencyContact.name) {
    return values.emergencyContact;
  }
  return {
    name: values.emergencyName?.trim() || values.emergencyContact?.name || '',
    relationship: values.emergencyRelationship?.trim() || values.emergencyContact?.relationship || 'Family',
    phone: values.emergencyPhone?.trim() || values.emergencyContact?.phone || '',
    altPhone: values.emergencyContact?.altPhone || '',
  };
}
