import { MemberFormFieldDefinition } from './memberForm.types';
import { validateEthiopianPhone } from '../../schemas/phone.schema';
import { validateEmail } from '../../schemas/email.schema';

/**
 * Complete union of all fields collected across:
 * 1. MemberModule.tsx (Admin add/edit modal)
 * 2. PublicRegistrationForm.tsx (Public web registration)
 * 3. GoogleFormRegistration.tsx (Card-by-card / Google Form style registration)
 * 4. RegistrationPage.tsx (Self-service member signup with password)
 */
export const MEMBER_FIELDS: MemberFormFieldDefinition[] = [
  // ==========================================
  // SECTION: ACCOUNT & CREDENTIALS
  // ==========================================
  {
    id: 'password',
    section: 'account',
    type: 'password',
    labelKey: 'account.password',
    defaultLabel: 'Account Password',
    placeholderKey: 'account.passwordPlaceholder',
    defaultPlaceholder: 'Min. 6 characters',
    required: true,
    colSpan: 1,
    validate: (val) => {
      if (!val || val.length < 6) {
        return 'Password must be at least 6 characters';
      }
      return null;
    },
  },
  {
    id: 'confirmPassword',
    section: 'account',
    type: 'password',
    labelKey: 'account.confirmPassword',
    defaultLabel: 'Confirm Password',
    placeholderKey: 'account.confirmPasswordPlaceholder',
    defaultPlaceholder: 'Re-enter your password',
    required: true,
    colSpan: 1,
    validate: (val, allVals) => {
      if (!val) return 'Please confirm your password';
      if (val !== allVals.password) return 'Passwords do not match';
      return null;
    },
  },
  {
    id: 'agreeTerms',
    section: 'account',
    type: 'checkbox',
    labelKey: 'account.agreeTerms',
    defaultLabel: 'I agree to the Church Statement of Faith & Fellowship Covenant',
    required: true,
    colSpan: 2,
    validate: (val) => {
      if (!val) return 'You must accept the Church terms & covenant';
      return null;
    },
  },

  // ==========================================
  // SECTION: PERSONAL IDENTIFICATION
  // ==========================================
  {
    id: 'title',
    section: 'personal',
    type: 'select',
    labelKey: 'member.title',
    defaultLabel: 'Title / Honorific',
    colSpan: 1,
    options: [
      { value: 'Brother', labelKey: 'title.brother', defaultLabel: 'Brother' },
      { value: 'Sister', labelKey: 'title.sister', defaultLabel: 'Sister' },
      { value: 'Mr', labelKey: 'title.mr', defaultLabel: 'Mr.' },
      { value: 'Mrs', labelKey: 'title.mrs', defaultLabel: 'Mrs.' },
      { value: 'Ms', labelKey: 'title.ms', defaultLabel: 'Ms.' },
      { value: 'Pastor', labelKey: 'title.pastor', defaultLabel: 'Pastor' },
      { value: 'Elder', labelKey: 'title.elder', defaultLabel: 'Elder' },
      { value: 'Deacon', labelKey: 'title.deacon', defaultLabel: 'Deacon' },
      { value: 'Evangelist', labelKey: 'title.evangelist', defaultLabel: 'Evangelist' },
      { value: 'Minister', labelKey: 'title.minister', defaultLabel: 'Minister' },
      { value: 'Dr', labelKey: 'title.dr', defaultLabel: 'Dr.' },
    ],
  },
  {
    id: 'firstName',
    section: 'personal',
    type: 'text',
    labelKey: 'member.firstName',
    defaultLabel: 'First Name (Baptismal / Christian Name)',
    placeholderKey: 'member.firstNamePlaceholder',
    defaultPlaceholder: 'e.g., Yohannes',
    required: true,
    inputMode: 'text',
    colSpan: 1,
    validate: (val) => {
      if (!val || !val.trim()) return 'First name is required';
      if (val.trim().length < 2) return 'First name must be at least 2 characters';
      return null;
    },
  },
  {
    id: 'middleName',
    section: 'personal',
    type: 'text',
    labelKey: 'member.middleName',
    defaultLabel: "Father's Name (Middle Name)",
    placeholderKey: 'member.middleNamePlaceholder',
    defaultPlaceholder: 'e.g., Berhanu',
    inputMode: 'text',
    colSpan: 1,
  },
  {
    id: 'lastName',
    section: 'personal',
    type: 'text',
    labelKey: 'member.lastName',
    defaultLabel: "Grandfather's Name (Last Name)",
    placeholderKey: 'member.lastNamePlaceholder',
    defaultPlaceholder: 'e.g., Tesfaye',
    required: true,
    inputMode: 'text',
    colSpan: 1,
    validate: (val) => {
      if (!val || !val.trim()) return 'Last name is required';
      if (val.trim().length < 2) return 'Last name must be at least 2 characters';
      return null;
    },
  },
  {
    id: 'amharicName',
    section: 'personal',
    type: 'text',
    labelKey: 'member.amharicName',
    defaultLabel: "Full Name in Ge'ez / Amharic (የአማርኛ ስም)",
    placeholderKey: 'member.amharicNamePlaceholder',
    defaultPlaceholder: 'ምሳሌ: ዮሐንስ ብርሃኑ ተስፋዬ',
    inputMode: 'text',
    colSpan: 1,
  },
  {
    id: 'preferredName',
    section: 'personal',
    type: 'text',
    labelKey: 'member.preferredName',
    defaultLabel: 'Preferred Name / Nickname',
    placeholderKey: 'member.preferredNamePlaceholder',
    defaultPlaceholder: 'e.g., Yoni',
    colSpan: 1,
  },
  {
    id: 'gender',
    section: 'personal',
    type: 'select',
    labelKey: 'member.gender',
    defaultLabel: 'Gender',
    required: true,
    colSpan: 1,
    options: [
      { value: 'Male', labelKey: 'gender.male', defaultLabel: 'Male' },
      { value: 'Female', labelKey: 'gender.female', defaultLabel: 'Female' },
    ],
    validate: (val) => (!val ? 'Gender is required' : null),
  },
  {
    id: 'dateOfBirth',
    section: 'personal',
    type: 'date',
    labelKey: 'member.dateOfBirth',
    defaultLabel: 'Date of Birth (EC / GC)',
    placeholderKey: 'member.dateOfBirthPlaceholder',
    defaultPlaceholder: 'YYYY-MM-DD',
    required: true,
    colSpan: 1,
    validate: (val) => (!val ? 'Date of birth is required' : null),
  },
  {
    id: 'nationality',
    section: 'personal',
    type: 'text',
    labelKey: 'member.nationality',
    defaultLabel: 'Nationality',
    placeholderKey: 'member.nationalityPlaceholder',
    defaultPlaceholder: 'e.g., Ethiopian',
    colSpan: 1,
  },
  {
    id: 'nationalIdNumber',
    section: 'personal',
    type: 'text',
    labelKey: 'member.nationalIdNumber',
    defaultLabel: 'National ID / Fayda / Resident Card',
    placeholderKey: 'member.nationalIdPlaceholder',
    defaultPlaceholder: 'e.g., ET-FAYDA-982341',
    colSpan: 1,
  },
  {
    id: 'passportNumber',
    section: 'personal',
    type: 'text',
    labelKey: 'member.passportNumber',
    defaultLabel: 'Passport Number',
    placeholderKey: 'member.passportPlaceholder',
    defaultPlaceholder: 'e.g., EP1234567',
    colSpan: 1,
  },
  {
    id: 'photoUrl',
    section: 'personal',
    type: 'text',
    labelKey: 'member.photoUrl',
    defaultLabel: 'Profile Photo URL',
    placeholderKey: 'member.photoUrlPlaceholder',
    defaultPlaceholder: 'https://...',
    colSpan: 2,
  },

  // ==========================================
  // SECTION: MARITAL STATUS & FAMILY
  // ==========================================
  {
    id: 'maritalStatus',
    section: 'family',
    type: 'select',
    labelKey: 'member.maritalStatus',
    defaultLabel: 'Marital Status',
    required: true,
    colSpan: 1,
    options: [
      { value: 'Single', labelKey: 'marital.single', defaultLabel: 'Single' },
      { value: 'Married', labelKey: 'marital.married', defaultLabel: 'Married' },
      { value: 'Divorced', labelKey: 'marital.divorced', defaultLabel: 'Divorced' },
      { value: 'Widowed', labelKey: 'marital.widowed', defaultLabel: 'Widowed' },
      { value: 'Separated', labelKey: 'marital.separated', defaultLabel: 'Separated' },
    ],
    validate: (val) => (!val ? 'Marital status is required' : null),
  },
  {
    id: 'spouseName',
    section: 'family',
    type: 'text',
    labelKey: 'member.spouseName',
    defaultLabel: 'Spouse Name',
    placeholderKey: 'member.spouseNamePlaceholder',
    defaultPlaceholder: 'Full name of husband / wife',
    colSpan: 1,
    showWhen: (vals) => vals.maritalStatus === 'Married',
  },
  {
    id: 'spousePhone',
    section: 'family',
    type: 'tel',
    labelKey: 'member.spousePhone',
    defaultLabel: 'Spouse Phone Number',
    placeholderKey: 'member.spousePhonePlaceholder',
    defaultPlaceholder: '0910109191 or +251910109191',
    colSpan: 1,
    inputMode: 'tel',
    showWhen: (vals) => vals.maritalStatus === 'Married',
    validate: (val, vals) => {
      if (vals.maritalStatus === 'Married' && val && val.trim()) {
        const check = validateEthiopianPhone(val);
        if (!check.isValid) return check.error || 'Invalid Ethiopian phone format';
      }
      return null;
    },
  },
  {
    id: 'spouseMemberId',
    section: 'family',
    type: 'text',
    labelKey: 'member.spouseMemberId',
    defaultLabel: 'Spouse Member ID (if already a member)',
    placeholderKey: 'member.spouseMemberIdPlaceholder',
    defaultPlaceholder: 'e.g., GC-2025-0104',
    colSpan: 1,
    showWhen: (vals) => vals.maritalStatus === 'Married',
  },
  {
    id: 'marriageDate',
    section: 'family',
    type: 'date',
    labelKey: 'member.marriageDate',
    defaultLabel: 'Date of Holy Matrimony',
    colSpan: 1,
    showWhen: (vals) => vals.maritalStatus === 'Married',
  },
  {
    id: 'divorceDate',
    section: 'family',
    type: 'date',
    labelKey: 'member.divorceDate',
    defaultLabel: 'Date of Legal Divorce',
    colSpan: 1,
    showWhen: (vals) => vals.maritalStatus === 'Divorced',
  },
  {
    id: 'familyRole',
    section: 'family',
    type: 'select',
    labelKey: 'member.familyRole',
    defaultLabel: 'Role in Household',
    colSpan: 1,
    options: [
      { value: 'Head', labelKey: 'family.head', defaultLabel: 'Head of Household' },
      { value: 'Spouse', labelKey: 'family.spouse', defaultLabel: 'Spouse' },
      { value: 'Child', labelKey: 'family.child', defaultLabel: 'Child' },
      { value: 'Dependent', labelKey: 'family.dependent', defaultLabel: 'Dependent' },
      { value: 'Relative', labelKey: 'family.relative', defaultLabel: 'Relative' },
    ],
  },
  {
    id: 'maleChildrenCount',
    section: 'family',
    type: 'number',
    labelKey: 'member.maleChildrenCount',
    defaultLabel: 'Number of Sons',
    colSpan: 1,
    inputMode: 'numeric',
  },
  {
    id: 'femaleChildrenCount',
    section: 'family',
    type: 'number',
    labelKey: 'member.femaleChildrenCount',
    defaultLabel: 'Number of Daughters',
    colSpan: 1,
    inputMode: 'numeric',
  },
  {
    id: 'adoptedChildrenCount',
    section: 'family',
    type: 'number',
    labelKey: 'member.adoptedChildrenCount',
    defaultLabel: 'Number of Adopted Children',
    colSpan: 1,
    inputMode: 'numeric',
  },

  // ==========================================
  // SECTION: CONTACT & COMMUNICATION
  // ==========================================
  {
    id: 'primaryPhone',
    section: 'contact',
    type: 'tel',
    labelKey: 'member.primaryPhone',
    defaultLabel: 'Primary Mobile Phone (Ethiopian Number)',
    placeholderKey: 'member.primaryPhonePlaceholder',
    defaultPlaceholder: '0910109191 or +251910109191',
    required: true,
    inputMode: 'tel',
    colSpan: 1,
    validate: (val) => {
      if (!val || !val.trim()) return 'Primary phone number is required';
      const check = validateEthiopianPhone(val);
      if (!check.isValid) return check.error || 'Invalid Ethiopian phone number';
      return null;
    },
  },
  {
    id: 'altPhone',
    section: 'contact',
    type: 'tel',
    labelKey: 'member.altPhone',
    defaultLabel: 'Alternate / Work Phone Number',
    placeholderKey: 'member.altPhonePlaceholder',
    defaultPlaceholder: 'Optional alternative number',
    inputMode: 'tel',
    colSpan: 1,
    validate: (val) => {
      if (val && val.trim()) {
        const check = validateEthiopianPhone(val);
        if (!check.isValid) return check.error || 'Invalid Ethiopian phone format';
      }
      return null;
    },
  },
  {
    id: 'email',
    section: 'contact',
    type: 'email',
    labelKey: 'member.email',
    defaultLabel: 'Email Address',
    placeholderKey: 'member.emailPlaceholder',
    defaultPlaceholder: 'member@example.com',
    inputMode: 'email',
    colSpan: 1,
    validate: (val) => {
      if (val && val.trim()) {
        const check = validateEmail(val);
        if (!check.isValid) return check.error || 'Invalid email address';
      }
      return null;
    },
  },
  {
    id: 'preferredCommChannel',
    section: 'contact',
    type: 'select',
    labelKey: 'member.preferredCommChannel',
    defaultLabel: 'Preferred Communication Channel',
    colSpan: 1,
    options: [
      { value: 'SMS', labelKey: 'comm.sms', defaultLabel: 'SMS (Short Message Service)' },
      { value: 'Email', labelKey: 'comm.email', defaultLabel: 'Email' },
      { value: 'Phone', labelKey: 'comm.phone', defaultLabel: 'Direct Voice Call' },
      { value: 'Telegram', labelKey: 'comm.telegram', defaultLabel: 'Telegram Channel' },
      { value: 'WhatsApp', labelKey: 'comm.whatsapp', defaultLabel: 'WhatsApp' },
    ],
  },

  // ==========================================
  // SECTION: RESIDENCE & ADDRESS
  // ==========================================
  {
    id: 'city',
    section: 'address',
    type: 'text',
    labelKey: 'member.city',
    defaultLabel: 'City / Municipality',
    placeholderKey: 'member.cityPlaceholder',
    defaultPlaceholder: 'e.g., Addis Ababa',
    required: true,
    colSpan: 1,
    validate: (val) => (!val || !val.trim() ? 'City is required' : null),
  },
  {
    id: 'subCity',
    section: 'address',
    type: 'text',
    labelKey: 'member.subCity',
    defaultLabel: 'Sub-City (ክፍለ ከተማ)',
    placeholderKey: 'member.subCityPlaceholder',
    defaultPlaceholder: 'e.g., Bole, Kirkos, Yeka, Nifas Silk',
    colSpan: 1,
  },
  {
    id: 'woreda',
    section: 'address',
    type: 'text',
    labelKey: 'member.woreda',
    defaultLabel: 'Woreda (ወረዳ)',
    placeholderKey: 'member.woredaPlaceholder',
    defaultPlaceholder: 'e.g., Woreda 03',
    colSpan: 1,
  },
  {
    id: 'kebele',
    section: 'address',
    type: 'text',
    labelKey: 'member.kebele',
    defaultLabel: 'Kebele (ቀበሌ)',
    placeholderKey: 'member.kebelePlaceholder',
    defaultPlaceholder: 'e.g., Kebele 05',
    colSpan: 1,
  },
  {
    id: 'houseNumber',
    section: 'address',
    type: 'text',
    labelKey: 'member.houseNumber',
    defaultLabel: 'House Number (የቤት ቁጥር)',
    placeholderKey: 'member.houseNumberPlaceholder',
    defaultPlaceholder: 'e.g., House No. 124 / New',
    colSpan: 1,
  },
  {
    id: 'streetAddress',
    section: 'address',
    type: 'text',
    labelKey: 'member.streetAddress',
    defaultLabel: 'Street Address & Specific Landmark',
    placeholderKey: 'member.streetAddressPlaceholder',
    defaultPlaceholder: 'e.g., Near Friendship Mall / St. Joseph School',
    colSpan: 2,
  },
  {
    id: 'region',
    section: 'address',
    type: 'text',
    labelKey: 'member.region',
    defaultLabel: 'Regional State',
    placeholderKey: 'member.regionPlaceholder',
    defaultPlaceholder: 'e.g., Addis Ababa, Oromia, Amhara',
    colSpan: 1,
  },
  {
    id: 'postalCode',
    section: 'address',
    type: 'text',
    labelKey: 'member.postalCode',
    defaultLabel: 'Postal Code / P.O. Box',
    placeholderKey: 'member.postalCodePlaceholder',
    defaultPlaceholder: 'e.g., 1000',
    colSpan: 1,
  },

  // ==========================================
  // SECTION: CHURCH & SPIRITUAL JOURNEY
  // ==========================================
  {
    id: 'branchId',
    section: 'spiritual',
    type: 'select',
    labelKey: 'member.branchId',
    defaultLabel: 'Church Branch / Campus Fellowship',
    required: true,
    colSpan: 1,
    validate: (val) => (!val ? 'Branch is required' : null),
  },
  {
    id: 'salvationDate',
    section: 'spiritual',
    type: 'date',
    labelKey: 'member.salvationDate',
    defaultLabel: 'Salvation / Born Again Date',
    colSpan: 1,
  },
  {
    id: 'salvationLocation',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.salvationLocation',
    defaultLabel: 'Place Where You Received Christ',
    placeholderKey: 'member.salvationLocationPlaceholder',
    defaultPlaceholder: 'e.g., Youth Camp, Sunday Service, Home Fellowship',
    colSpan: 1,
  },
  {
    id: 'ledToChristBy',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.ledToChristBy',
    defaultLabel: 'Led to Christ By',
    placeholderKey: 'member.ledToChristByPlaceholder',
    defaultPlaceholder: 'Name of Evangelist / Friend / Pastor',
    colSpan: 1,
  },
  {
    id: 'isWaterBaptized',
    section: 'spiritual',
    type: 'checkbox',
    labelKey: 'member.isWaterBaptized',
    defaultLabel: 'Have you been Water Baptized by Immersion?',
    colSpan: 1,
  },
  {
    id: 'waterBaptismDate',
    section: 'spiritual',
    type: 'date',
    labelKey: 'member.waterBaptismDate',
    defaultLabel: 'Water Baptism Date',
    colSpan: 1,
    showWhen: (vals) => !!vals.isWaterBaptized,
  },
  {
    id: 'waterBaptismLocation',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.waterBaptismLocation',
    defaultLabel: 'Church or River Where Baptized',
    placeholderKey: 'member.waterBaptismLocationPlaceholder',
    defaultPlaceholder: 'e.g., Grace Cathedral Main Sanctuary',
    colSpan: 1,
    showWhen: (vals) => !!vals.isWaterBaptized,
  },
  {
    id: 'baptizedBy',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.baptizedBy',
    defaultLabel: 'Baptizing Pastor / Minister',
    placeholderKey: 'member.baptizedByPlaceholder',
    defaultPlaceholder: 'e.g., Pastor Daniel',
    colSpan: 1,
    showWhen: (vals) => !!vals.isWaterBaptized,
  },
  {
    id: 'isHolySpiritBaptized',
    section: 'spiritual',
    type: 'checkbox',
    labelKey: 'member.isHolySpiritBaptized',
    defaultLabel: 'Have you received Holy Spirit Baptism (Evidence of Tongues)?',
    colSpan: 1,
  },
  {
    id: 'holySpiritBaptismDate',
    section: 'spiritual',
    type: 'date',
    labelKey: 'member.holySpiritBaptismDate',
    defaultLabel: 'Holy Spirit Baptism Date',
    colSpan: 1,
    showWhen: (vals) => !!vals.isHolySpiritBaptized,
  },
  {
    id: 'spiritualGifts',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.spiritualGifts',
    defaultLabel: 'Spiritual Gifts & Callings',
    placeholderKey: 'member.spiritualGiftsPlaceholder',
    defaultPlaceholder: 'e.g., Prophecy, Teaching, Intercession, Administration',
    colSpan: 2,
  },
  {
    id: 'ministryIds',
    section: 'spiritual',
    type: 'multi-select',
    labelKey: 'member.ministryIds',
    defaultLabel: 'Ministries Desired / Currently Serving',
    colSpan: 2,
  },
  {
    id: 'previousChurch',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.previousChurch',
    defaultLabel: 'Previous Church Background / Transfer Church',
    placeholderKey: 'member.previousChurchPlaceholder',
    defaultPlaceholder: 'e.g., Mulu Wengel, Addis Ababa',
    colSpan: 1,
  },
  {
    id: 'discipleshipStatus',
    section: 'spiritual',
    type: 'select',
    labelKey: 'member.discipleshipStatus',
    defaultLabel: 'Discipleship Status',
    colSpan: 1,
    options: [
      { value: 'New Convert', labelKey: 'disc.newConvert', defaultLabel: 'New Convert' },
      { value: 'In Foundation Class', labelKey: 'disc.foundation', defaultLabel: 'In Foundation Class' },
      { value: 'Discipled', labelKey: 'disc.discipled', defaultLabel: 'Discipled' },
      { value: 'Discipler / Leader', labelKey: 'disc.leader', defaultLabel: 'Discipler / Cell Leader' },
    ],
  },
  {
    id: 'foundationCourseCompleted',
    section: 'spiritual',
    type: 'checkbox',
    labelKey: 'member.foundationCourseCompleted',
    defaultLabel: 'Completed Foundation / Believers Course',
    colSpan: 1,
  },
  {
    id: 'membershipType',
    section: 'spiritual',
    type: 'select',
    labelKey: 'member.membershipType',
    defaultLabel: 'Membership Type',
    colSpan: 1,
    options: [
      { value: 'Full Member', labelKey: 'memtype.full', defaultLabel: 'Full Covenant Member' },
      { value: 'Associate Member', labelKey: 'memtype.associate', defaultLabel: 'Associate Member' },
      { value: 'Youth Member', labelKey: 'memtype.youth', defaultLabel: 'Youth Member' },
      { value: 'Visiting Member', labelKey: 'memtype.visiting', defaultLabel: 'Visiting Member' },
    ],
  },
  {
    id: 'membershipStatus',
    section: 'spiritual',
    type: 'select',
    labelKey: 'member.membershipStatus',
    defaultLabel: 'Membership Status',
    colSpan: 1,
    options: [
      { value: 'Active', labelKey: 'status.active', defaultLabel: 'Active' },
      { value: 'Pending', labelKey: 'status.pending', defaultLabel: 'Pending' },
      { value: 'Pending Approval', labelKey: 'status.pendingApproval', defaultLabel: 'Pending Approval' },
      { value: 'Inactive', labelKey: 'status.inactive', defaultLabel: 'Inactive' },
      { value: 'Visiting', labelKey: 'status.visiting', defaultLabel: 'Visiting' },
      { value: 'Transferred', labelKey: 'status.transferred', defaultLabel: 'Transferred' },
      { value: 'Under Discipline', labelKey: 'status.discipline', defaultLabel: 'Under Discipline' },
      { value: 'Deceased', labelKey: 'status.deceased', defaultLabel: 'Deceased' },
    ],
  },
  {
    id: 'membershipDate',
    section: 'spiritual',
    type: 'date',
    labelKey: 'member.membershipDate',
    defaultLabel: 'Date of Official Admission',
    colSpan: 1,
  },
  {
    id: 'membershipLocation',
    section: 'spiritual',
    type: 'text',
    labelKey: 'member.membershipLocation',
    defaultLabel: 'Sanctuary Where Membership Was Received',
    placeholderKey: 'member.membershipLocationPlaceholder',
    defaultPlaceholder: 'e.g., Main Cathedral Auditorium',
    colSpan: 1,
  },

  // ==========================================
  // SECTION: EDUCATION & PROFESSION
  // ==========================================
  {
    id: 'educationLevel',
    section: 'education_profession',
    type: 'select',
    labelKey: 'member.educationLevel',
    defaultLabel: 'Highest Level of Education',
    colSpan: 1,
    options: [
      { value: 'No Formal Education', labelKey: 'edu.none', defaultLabel: 'No Formal Education' },
      { value: 'Primary', labelKey: 'edu.primary', defaultLabel: 'Primary Education' },
      { value: 'Secondary', labelKey: 'edu.secondary', defaultLabel: 'Secondary / High School' },
      { value: 'Diploma', labelKey: 'edu.diploma', defaultLabel: 'Technical / Vocational Diploma' },
      { value: 'Bachelor', labelKey: 'edu.bachelor', defaultLabel: 'Bachelor Degree' },
      { value: 'Master', labelKey: 'edu.master', defaultLabel: 'Master Degree' },
      { value: 'Doctorate', labelKey: 'edu.doctorate', defaultLabel: 'Doctorate / PhD' },
      { value: 'Other', labelKey: 'edu.other', defaultLabel: 'Other Qualification' },
    ],
  },
  {
    id: 'fieldOfStudy',
    section: 'education_profession',
    type: 'text',
    labelKey: 'member.fieldOfStudy',
    defaultLabel: 'Major / Field of Study',
    placeholderKey: 'member.fieldOfStudyPlaceholder',
    defaultPlaceholder: 'e.g., Computer Science, Theology, Nursing, Accounting',
    colSpan: 1,
  },
  {
    id: 'occupation',
    section: 'education_profession',
    type: 'text',
    labelKey: 'member.occupation',
    defaultLabel: 'Current Occupation / Profession',
    placeholderKey: 'member.occupationPlaceholder',
    defaultPlaceholder: 'e.g., Civil Engineer, Teacher, Merchant, Student',
    colSpan: 1,
  },
  {
    id: 'employerName',
    section: 'education_profession',
    type: 'text',
    labelKey: 'member.employerName',
    defaultLabel: 'Employer / Business Name',
    placeholderKey: 'member.employerNamePlaceholder',
    defaultPlaceholder: 'e.g., Ministry of Health, Private Firm, Self-Employed',
    colSpan: 1,
  },
  {
    id: 'employerType',
    section: 'education_profession',
    type: 'select',
    labelKey: 'member.employerType',
    defaultLabel: 'Employment Sector',
    colSpan: 1,
    options: [
      { value: 'Government', labelKey: 'emp.gov', defaultLabel: 'Government / Public Sector' },
      { value: 'Private', labelKey: 'emp.priv', defaultLabel: 'Private Enterprise' },
      { value: 'NGO (Non-Profit)', labelKey: 'emp.ngo', defaultLabel: 'NGO / International Non-Profit' },
      { value: 'Individual', labelKey: 'emp.self', defaultLabel: 'Self-Employed / Business Owner' },
      { value: 'Other', labelKey: 'emp.other', defaultLabel: 'Other Sector' },
    ],
  },
  {
    id: 'skillsAndTalents',
    section: 'education_profession',
    type: 'text',
    labelKey: 'member.skillsAndTalents',
    defaultLabel: 'Practical Skills & Talents',
    placeholderKey: 'member.skillsPlaceholder',
    defaultPlaceholder: 'e.g., Graphic Design, Sound Engineering, First Aid, Translation',
    colSpan: 2,
  },

  // ==========================================
  // SECTION: EMERGENCY CONTACT
  // ==========================================
  {
    id: 'emergencyName',
    section: 'emergency',
    type: 'text',
    labelKey: 'member.emergencyName',
    defaultLabel: 'Emergency Contact Full Name',
    placeholderKey: 'member.emergencyNamePlaceholder',
    defaultPlaceholder: 'e.g., Aster Mamo',
    required: true,
    colSpan: 1,
    validate: (val) => (!val || !val.trim() ? 'Emergency contact name is required' : null),
  },
  {
    id: 'emergencyRelationship',
    section: 'emergency',
    type: 'select',
    labelKey: 'member.emergencyRelationship',
    defaultLabel: 'Relationship to Member',
    colSpan: 1,
    options: [
      { value: 'Spouse', labelKey: 'rel.spouse', defaultLabel: 'Spouse' },
      { value: 'Parent', labelKey: 'rel.parent', defaultLabel: 'Parent' },
      { value: 'Sibling', labelKey: 'rel.sibling', defaultLabel: 'Sibling' },
      { value: 'Child', labelKey: 'rel.child', defaultLabel: 'Child' },
      { value: 'Relative', labelKey: 'rel.relative', defaultLabel: 'Relative' },
      { value: 'Friend', labelKey: 'rel.friend', defaultLabel: 'Friend' },
      { value: 'Guardian', labelKey: 'rel.guardian', defaultLabel: 'Guardian' },
      { value: 'Pastor / Elder', labelKey: 'rel.pastor', defaultLabel: 'Pastor / Elder' },
    ],
  },
  {
    id: 'emergencyPhone',
    section: 'emergency',
    type: 'tel',
    labelKey: 'member.emergencyPhone',
    defaultLabel: 'Emergency Contact Phone Number',
    placeholderKey: 'member.emergencyPhonePlaceholder',
    defaultPlaceholder: '0910109191 or +251910109191',
    required: true,
    inputMode: 'tel',
    colSpan: 1,
    validate: (val) => {
      if (!val || !val.trim()) return 'Emergency contact phone is required';
      const check = validateEthiopianPhone(val);
      if (!check.isValid) return check.error || 'Invalid Ethiopian phone format';
      return null;
    },
  },

  // ==========================================
  // SECTION: PASTORAL CARE, MEDICAL & NOTES
  // ==========================================
  {
    id: 'bloodType',
    section: 'pastoral_care',
    type: 'select',
    labelKey: 'member.bloodType',
    defaultLabel: 'Blood Type',
    colSpan: 1,
    options: [
      { value: 'A+', labelKey: 'blood.ap', defaultLabel: 'A+' },
      { value: 'A-', labelKey: 'blood.an', defaultLabel: 'A-' },
      { value: 'B+', labelKey: 'blood.bp', defaultLabel: 'B+' },
      { value: 'B-', labelKey: 'blood.bn', defaultLabel: 'B-' },
      { value: 'AB+', labelKey: 'blood.abp', defaultLabel: 'AB+' },
      { value: 'AB-', labelKey: 'blood.abn', defaultLabel: 'AB-' },
      { value: 'O+', labelKey: 'blood.op', defaultLabel: 'O+' },
      { value: 'O-', labelKey: 'blood.on', defaultLabel: 'O-' },
    ],
  },
  {
    id: 'knownAllergies',
    section: 'pastoral_care',
    type: 'text',
    labelKey: 'member.knownAllergies',
    defaultLabel: 'Known Allergies / Medical Sensitivities',
    placeholderKey: 'member.knownAllergiesPlaceholder',
    defaultPlaceholder: 'e.g., Penicillin, Peanuts, Pollen',
    colSpan: 1,
  },
  {
    id: 'notes',
    section: 'pastoral_care',
    type: 'textarea',
    labelKey: 'member.notes',
    defaultLabel: 'Pastoral Notes & Special Prayer Needs',
    placeholderKey: 'member.notesPlaceholder',
    defaultPlaceholder: 'Enter any special prayer requests or pastoral guidance requirements...',
    colSpan: 2,
  },
];

/**
 * Fast lookup map of fields by their unique ID
 */
export const MEMBER_FIELDS_MAP = new Map<string, MemberFormFieldDefinition>(
  MEMBER_FIELDS.map((f) => [f.id, f])
);
