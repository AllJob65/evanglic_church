/**
 * Ordered field IDs for Self-Service Member Signup with Account (RegistrationPage.tsx)
 */
export const selfSignupFields: string[] = [
  'firstName',
  'lastName',
  'gender',
  'dateOfBirth',
  'maritalStatus',
  'spouseName',
  'spousePhone',
  'occupation',
  'email',
  'primaryPhone',
  'streetAddress',
  'city',
  'branchId',
  'isWaterBaptized',
  'salvationDate',
  'ministryIds',
  'password',
  'confirmPassword',
  'emergencyName',
  'emergencyPhone',
  'agreeTerms',
];
