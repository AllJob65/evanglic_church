import React, { useState, useMemo } from 'react';
import { useTranslation } from '../../i18n/LanguageContext';
import { useCMMS } from '../../context/CMMSContext';
import { EthiopianPhoneInput } from '../../components/EthiopianPhoneInput';
import { EthiopianDateHelper } from '../../components/EthiopianDateHelper';
import {
  RegistrationFormValues,
  MemberFormFieldDefinition,
  FormSection,
} from './memberForm.types';
import { MEMBER_FIELDS_MAP } from './memberForm.schema';
import { useMemberForm } from './useMemberForm';
import {
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  AlertCircle,
  Loader2,
  User,
  Phone,
  MapPin,
  Heart,
  BookOpen,
  GraduationCap,
  ShieldAlert,
  Church,
} from 'lucide-react';

export interface MemberFormProps {
  mode?: 'wizard' | 'cards' | 'tabs' | 'single';
  fields: string[];
  initialValues?: Partial<RegistrationFormValues>;
  onSubmit?: (values: RegistrationFormValues) => Promise<void> | void;
  submitLabel?: string;
  readOnly?: boolean;
  className?: string;
}

const SECTION_METADATA: Record<
  FormSection,
  { labelKey: string; defaultLabel: string; icon: React.ComponentType<{ className?: string }> }
> = {
  account: { labelKey: 'section.account', defaultLabel: 'Portal Account & Security', icon: ShieldAlert },
  personal: { labelKey: 'section.personal', defaultLabel: 'Personal Identification', icon: User },
  contact: { labelKey: 'section.contact', defaultLabel: 'Contact Information', icon: Phone },
  address: { labelKey: 'section.address', defaultLabel: 'Residential Address', icon: MapPin },
  family: { labelKey: 'section.family', defaultLabel: 'Family & Marital Status', icon: Heart },
  spiritual: { labelKey: 'section.spiritual', defaultLabel: 'Church & Spiritual Profile', icon: Church },
  education_profession: { labelKey: 'section.education', defaultLabel: 'Education & Profession', icon: GraduationCap },
  emergency: { labelKey: 'section.emergency', defaultLabel: 'Emergency Contact', icon: ShieldAlert },
  pastoral_care: { labelKey: 'section.pastoral', defaultLabel: 'Pastoral Care & Medical', icon: BookOpen },
  church_admin: { labelKey: 'section.admin', defaultLabel: 'Administrative Records', icon: Church },
};

export const MemberForm: React.FC<MemberFormProps> = ({
  mode = 'single',
  fields,
  initialValues,
  onSubmit,
  submitLabel,
  readOnly = false,
  className = '',
}) => {
  const { t } = useTranslation();
  const { branches = [], ministries = [] } = useCMMS();

  const {
    values,
    errors,
    touched,
    isSubmitting,
    setField,
    validateField,
    handleSubmit,
  } = useMemberForm({
    initialValues,
    activeFields: fields,
    onSubmit,
  });

  // Filter definitions for only active requested fields
  const activeFieldDefs = useMemo(() => {
    return fields
      .map((id) => MEMBER_FIELDS_MAP.get(id))
      .filter((def): def is MemberFormFieldDefinition => def !== undefined);
  }, [fields]);

  // Group fields by section preserving order
  const sections = useMemo(() => {
    const map = new Map<FormSection, MemberFormFieldDefinition[]>();
    for (const def of activeFieldDefs) {
      if (!map.has(def.section)) {
        map.set(def.section, []);
      }
      map.get(def.section)!.push(def);
    }
    return Array.from(map.entries()).map(([section, items]) => ({
      section,
      metadata: SECTION_METADATA[section],
      items,
    }));
  }, [activeFieldDefs]);

  // Stepper / Tab state
  const [activeStep, setActiveStep] = useState<number>(0);
  const totalSteps = sections.length;

  // Handle next step in wizard/cards mode with section-level validation
  const handleNextStep = (e: React.MouseEvent) => {
    e.preventDefault();
    if (activeStep < totalSteps - 1) {
      // Validate current section fields before moving forward
      const currentSectionFields = sections[activeStep]?.items || [];
      let sectionHasErrors = false;
      for (const field of currentSectionFields) {
        const err = validateField(field.id);
        if (err) {
          sectionHasErrors = true;
          break;
        }
      }
      if (!sectionHasErrors) {
        setActiveStep((prev) => prev + 1);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  const handlePrevStep = (e: React.MouseEvent) => {
    e.preventDefault();
    if (activeStep > 0) {
      setActiveStep((prev) => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Render individual field widget
  const renderField = (field: MemberFormFieldDefinition) => {
    if (field.showWhen && !field.showWhen(values)) {
      return null;
    }

    const value = (values as any)[field.id];
    const fieldError = touched[field.id] ? errors[field.id] : undefined;
    const fieldLabel = t(field.labelKey, field.defaultLabel);
    const placeholder = field.placeholderKey
      ? t(field.placeholderKey, field.defaultPlaceholder || '')
      : field.defaultPlaceholder;

    // Custom Component Override if specified
    if (field.componentOverride) {
      const CustomComp = field.componentOverride;
      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} w-full`}
        >
          <CustomComp
            value={value}
            onChange={(val: any) => setField(field.id, val)}
            error={fieldError}
            readOnly={readOnly}
          />
        </div>
      );
    }

    // Specialized Ethiopian Phone input
    if (field.type === 'tel') {
      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} w-full`}
        >
          <EthiopianPhoneInput
            id={`field-${field.id}`}
            name={field.id}
            label={fieldLabel}
            value={value || ''}
            onChange={(e) => setField(field.id, e.target.value)}
            onValueChange={(val) => setField(field.id, val)}
            placeholder={placeholder}
            required={field.required}
            disabled={readOnly}
            error={fieldError}
            className="w-full"
          />
        </div>
      );
    }

    // Specialized Ethiopian Date input with calendar converter
    if (field.type === 'date') {
      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} w-full`}
        >
          <EthiopianDateHelper
            label={fieldLabel}
            value={value || ''}
            onChange={(val) => setField(field.id, val)}
            required={field.required}
            className="w-full"
          />
          {fieldError && (
            <p className="mt-1 text-xs text-rose-500 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              {t(fieldError, fieldError)}
            </p>
          )}
        </div>
      );
    }

    // Checkbox input
    if (field.type === 'checkbox') {
      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} flex items-start gap-3 pt-2`}
        >
          <input
            id={`field-${field.id}`}
            type="checkbox"
            checked={!!value}
            onChange={(e) => setField(field.id, e.target.checked)}
            disabled={readOnly}
            className="w-5 h-5 min-h-[20px] rounded border-slate-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 mt-0.5 cursor-pointer disabled:cursor-not-allowed"
          />
          <div className="flex-1">
            <label
              htmlFor={`field-${field.id}`}
              className="text-sm font-medium text-slate-800 dark:text-slate-200 cursor-pointer select-none"
            >
              {fieldLabel} {field.required && <span className="text-rose-500">*</span>}
            </label>
            {fieldError && (
              <p className="mt-1 text-xs text-rose-500 flex items-center gap-1 font-medium">
                <AlertCircle className="w-3.5 h-3.5" />
                {t(fieldError, fieldError)}
              </p>
            )}
          </div>
        </div>
      );
    }

    // Textarea input
    if (field.type === 'textarea') {
      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} space-y-1.5`}
        >
          <label
            htmlFor={`field-${field.id}`}
            className="block text-sm font-semibold text-slate-700 dark:text-slate-300"
          >
            {fieldLabel} {field.required && <span className="text-rose-500">*</span>}
          </label>
          <textarea
            id={`field-${field.id}`}
            rows={3}
            value={value || ''}
            onChange={(e) => setField(field.id, e.target.value)}
            placeholder={placeholder}
            disabled={readOnly}
            className={`w-full min-h-[44px] text-base px-3.5 py-2.5 rounded-xl border ${
              fieldError
                ? 'border-rose-400 focus:border-rose-500 ring-rose-200'
                : 'border-slate-200 dark:border-slate-700 focus:border-blue-500'
            } bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
          />
          {fieldError && (
            <p className="text-xs text-rose-500 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              {t(fieldError, fieldError)}
            </p>
          )}
        </div>
      );
    }

    // Select input (e.g. Branch, Gender, Marital Status, Education, Title)
    if (field.type === 'select') {
      let options = field.options || [];

      // Dynamic branch options
      if (field.id === 'branchId') {
        options = branches.map((b) => ({
          value: b.id,
          labelKey: `branch.${b.id}`,
          defaultLabel: b.name,
        }));
      }

      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} space-y-1.5`}
        >
          <label
            htmlFor={`field-${field.id}`}
            className="block text-sm font-semibold text-slate-700 dark:text-slate-300"
          >
            {fieldLabel} {field.required && <span className="text-rose-500">*</span>}
          </label>
          <select
            id={`field-${field.id}`}
            value={value || ''}
            onChange={(e) => setField(field.id, e.target.value)}
            disabled={readOnly}
            className={`w-full h-11 min-h-[44px] text-base px-3.5 rounded-xl border ${
              fieldError
                ? 'border-rose-400 focus:border-rose-500'
                : 'border-slate-200 dark:border-slate-700 focus:border-blue-500'
            } bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
          >
            <option value="">{t('common.selectOption', '-- Select an option --')}</option>
            {options.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {t(opt.labelKey, opt.defaultLabel)}
              </option>
            ))}
          </select>
          {fieldError && (
            <p className="text-xs text-rose-500 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              {t(fieldError, fieldError)}
            </p>
          )}
        </div>
      );
    }

    // Multi-Select for Ministries
    if (field.type === 'multi-select') {
      const selectedList: string[] = Array.isArray(value) ? value : [];

      const toggleItem = (itemId: string) => {
        if (readOnly) return;
        if (selectedList.includes(itemId)) {
          setField(
            field.id,
            selectedList.filter((id) => id !== itemId)
          );
        } else {
          setField(field.id, [...selectedList, itemId]);
        }
      };

      return (
        <div
          key={field.id}
          className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} space-y-2`}
        >
          <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
            {fieldLabel} {field.required && <span className="text-rose-500">*</span>}
          </label>
          <div className="flex flex-wrap gap-2 pt-1">
            {ministries.map((min) => {
              const isSelected = selectedList.includes(min.id) || selectedList.includes(min.name);
              return (
                <button
                  key={min.id}
                  type="button"
                  onClick={() => toggleItem(min.id)}
                  disabled={readOnly}
                  className={`min-h-[44px] px-3.5 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20 ring-1 ring-blue-600'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {isSelected && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                  <span>{min.name}</span>
                </button>
              );
            })}
          </div>
          {fieldError && (
            <p className="text-xs text-rose-500 flex items-center gap-1 font-medium">
              <AlertCircle className="w-3.5 h-3.5" />
              {t(fieldError, fieldError)}
            </p>
          )}
        </div>
      );
    }

    // Default text, password, number, email input
    return (
      <div
        key={field.id}
        className={`${field.colSpan === 2 ? 'sm:col-span-2' : 'sm:col-span-1'} space-y-1.5`}
      >
        <label
          htmlFor={`field-${field.id}`}
          className="block text-sm font-semibold text-slate-700 dark:text-slate-300"
        >
          {fieldLabel} {field.required && <span className="text-rose-500">*</span>}
        </label>
        <input
          id={`field-${field.id}`}
          type={field.type}
          inputMode={field.inputMode || 'text'}
          value={value ?? ''}
          onChange={(e) =>
            setField(
              field.id,
              field.type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value
            )
          }
          placeholder={placeholder}
          disabled={readOnly}
          className={`w-full h-11 min-h-[44px] text-base px-3.5 rounded-xl border ${
            fieldError
              ? 'border-rose-400 focus:border-rose-500 ring-rose-200'
              : 'border-slate-200 dark:border-slate-700 focus:border-blue-500'
          } bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all`}
        />
        {fieldError && (
          <p className="text-xs text-rose-500 flex items-center gap-1 font-medium">
            <AlertCircle className="w-3.5 h-3.5" />
            {t(fieldError, fieldError)}
          </p>
        )}
      </div>
    );
  };

  // Section Header Component
  const renderSectionHeader = (meta: (typeof SECTION_METADATA)[FormSection], idx?: number) => {
    const IconComp = meta.icon;
    return (
      <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
        <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
          <IconComp className="w-4 h-4" />
        </div>
        <h3 className="font-bold text-slate-900 dark:text-white text-base">
          {idx !== undefined && `${idx + 1}. `}
          {t(meta.labelKey, meta.defaultLabel)}
        </h3>
      </div>
    );
  };

  return (
    <form onSubmit={handleSubmit} className={`space-y-6 ${className}`}>
      {/* Top Level Error Banner if submit fails */}
      {errors._submit && (
        <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-500" />
          <p className="text-sm font-medium">{errors._submit}</p>
        </div>
      )}

      {/* TABS MODE */}
      {mode === 'tabs' && (
        <div className="space-y-6">
          <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800 scrollbar-none">
            {sections.map((sec, idx) => {
              const Icon = sec.metadata.icon;
              const isActive = activeStep === idx;
              return (
                <button
                  key={sec.section}
                  type="button"
                  onClick={() => setActiveStep(idx)}
                  className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{t(sec.metadata.labelKey, sec.metadata.defaultLabel)}</span>
                </button>
              );
            })}
          </div>

          <div className="space-y-4">
            {sections[activeStep] && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {sections[activeStep].items.map(renderField)}
              </div>
            )}
          </div>
        </div>
      )}

      {/* WIZARD & CARDS MODE */}
      {(mode === 'wizard' || mode === 'cards') && (
        <div className="space-y-6">
          {/* Progress Indicator */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
              <span>
                {t('common.step', 'Step')} {activeStep + 1} {t('common.of', 'of')} {totalSteps}
              </span>
              <span>{Math.round(((activeStep + 1) / totalSteps) * 100)}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-300"
                style={{ width: `${((activeStep + 1) / totalSteps) * 100}%` }}
              />
            </div>
          </div>

          {/* Current Section Fields */}
          {sections[activeStep] && (
            <div className="p-5 sm:p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
              {renderSectionHeader(sections[activeStep].metadata, activeStep)}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {sections[activeStep].items.map(renderField)}
              </div>
            </div>
          )}

          {/* Step Navigation Controls */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrevStep}
              disabled={activeStep === 0 || isSubmitting}
              className="min-h-[44px] px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>{t('common.previous', 'Previous')}</span>
            </button>

            {activeStep < totalSteps - 1 ? (
              <button
                type="button"
                onClick={handleNextStep}
                className="min-h-[44px] px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-1.5 cursor-pointer shadow-md shadow-blue-500/20 transition-all"
              >
                <span>{t('common.next', 'Next Step')}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              !readOnly && (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="min-h-[44px] px-7 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-2 cursor-pointer shadow-md shadow-blue-500/25 transition-all disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{t('common.submitting', 'Submitting...')}</span>
                    </>
                  ) : (
                    <span>{submitLabel || t('common.submit', 'Submit Registration')}</span>
                  )}
                </button>
              )
            )}
          </div>
        </div>
      )}

      {/* SINGLE MODE */}
      {mode === 'single' && (
        <div className="space-y-8">
          {sections.map((sec, idx) => (
            <div
              key={sec.section}
              className="p-5 sm:p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4"
            >
              {renderSectionHeader(sec.metadata, idx)}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {sec.items.map(renderField)}
              </div>
            </div>
          ))}

          {!readOnly && (
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto min-h-[44px] px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-blue-500/25 transition-all disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>{t('common.submitting', 'Submitting...')}</span>
                  </>
                ) : (
                  <span>{submitLabel || t('common.saveMember', 'Save Member Profile')}</span>
                )}
              </button>
            </div>
          )}
        </div>
      )}
    </form>
  );
};
