import { z } from 'zod';

/**
 * Strict Email Regex Specification:
 * - RFC 5322 standard compliant structure
 * - Explicitly permits '+' sub-addressing / aliases (e.g. user+alias@domain.com)
 * - Restricts whitespace, consecutive periods, and invalid domain segments
 * - Max 254 total characters (RFC 5321), max 64 chars local-part
 */
const EMAIL_REGEX =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

/**
 * Sanitizes and normalizes raw email inputs:
 * 1. Strips leading and trailing whitespace
 * 2. Normalizes to lowercase
 */
export function sanitizeEmail(email: string | null | undefined): string {
  if (!email || typeof email !== 'string') return '';
  return email.trim().toLowerCase();
}

/**
 * Zod Schema for strict email validation and runtime sanitization
 */
export const emailSchema = z
  .string({ message: 'Email address must be a string' })
  .transform((val) => sanitizeEmail(val))
  .pipe(
    z
      .string()
      .min(1, { message: 'Email address cannot be empty' })
      .max(254, { message: 'Email address cannot exceed 254 characters (RFC 5321 limit)' })
      .refine(
        (val) => {
          const atIndex = val.indexOf('@');
          if (atIndex <= 0) return false;
          const localPart = val.slice(0, atIndex);
          return localPart.length <= 64;
        },
        { message: 'Email local part cannot exceed 64 characters' }
      )
      .refine(
        (val) => !/\s/.test(val),
        { message: 'Email address cannot contain whitespace' }
      )
      .refine(
        (val) => !/\.{2,}/.test(val),
        { message: 'Email address cannot contain consecutive periods' }
      )
      .refine(
        (val) => EMAIL_REGEX.test(val),
        { message: 'Please enter a valid email address format (e.g. user@example.com or user+alias@church.org)' }
      )
  );

/**
 * Optional email schema allowing empty strings to resolve to undefined/empty
 */
export const optionalEmailSchema = z
  .string()
  .optional()
  .transform((val) => (val ? sanitizeEmail(val) : ''))
  .pipe(
    z.union([
      z.literal(''),
      emailSchema,
    ])
  );

/**
 * Reusable runtime validation helper function
 */
export function validateEmail(email: unknown): {
  isValid: boolean;
  normalized?: string;
  error?: string;
} {
  const result = emailSchema.safeParse(email);
  if (result.success) {
    return {
      isValid: true,
      normalized: result.data,
    };
  }
  const firstIssue = result.error.issues?.[0];
  return {
    isValid: false,
    error: firstIssue?.message || 'Invalid email address',
  };
}

export type Email = z.infer<typeof emailSchema>;
