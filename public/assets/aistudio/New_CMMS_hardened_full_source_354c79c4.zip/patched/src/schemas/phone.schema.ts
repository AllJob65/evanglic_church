import { z } from 'zod';

/**
 * Strict Regex pattern for Ethiopian mobile phone numbers:
 * - Local 10-digit starting with '09' (e.g., 0910109191)
 * - Local 10-digit starting with '07' (e.g., 0712345678)
 * - International 13-character starting with '+2519' or '+2517' (e.g., +251910109191, +251712345678)
 */
export const ETHIOPIAN_PHONE_REGEX = /^(09|07|\+2519|\+2517)\d{8}$/;

/**
 * Normalizes any valid local Ethiopian number (09..., 07...) or international format (+2519..., +2517...)
 * into the standard E.164 international format (+2519... or +2517...).
 */
export function formatToE164(phone: string): string {
  if (!phone) return '';
  const cleaned = phone.trim().replace(/[\s\-\(\)]/g, '');

  // Local format: 09XXXXXXXX -> +2519XXXXXXXX
  if (/^09\d{8}$/.test(cleaned)) {
    return `+2519${cleaned.slice(2)}`;
  }

  // Local format: 07XXXXXXXX -> +2517XXXXXXXX
  if (/^07\d{8}$/.test(cleaned)) {
    return `+2517${cleaned.slice(2)}`;
  }

  // International format: +2519XXXXXXXX or +2517XXXXXXXX
  if (/^\+251(9|7)\d{8}$/.test(cleaned)) {
    return cleaned;
  }

  // 251 without leading + : 2519XXXXXXXX or 2517XXXXXXXX
  if (/^251(9|7)\d{8}$/.test(cleaned)) {
    return `+${cleaned}`;
  }

  return cleaned;
}

/**
 * Normalizes any valid Ethiopian mobile number into the exact numeric string format
 * required by Ethio Telecom's SMS API: 12 digits starting with '2519' or '2517' (e.g. '251910109191' or '251712345678').
 *
 * Converts:
 * - Local 09XXXXXXXX -> 2519XXXXXXXX
 * - Local 07XXXXXXXX -> 2517XXXXXXXX
 * - Intl +2519XXXXXXXX -> 2519XXXXXXXX
 * - Intl +2517XXXXXXXX -> 2517XXXXXXXX
 * - Clean 2519XXXXXXXX -> 2519XXXXXXXX
 * - Clean 2517XXXXXXXX -> 2517XXXXXXXX
 *
 * Strictly rejects invalid prefixes or inputs failing length checks.
 */
export function formatEthioPhone(phone: string): string {
  if (!phone || typeof phone !== 'string') {
    throw new Error('Phone number must be a non-empty string');
  }

  const cleaned = phone.trim().replace(/[\s\-\(\)]/g, '');

  if (!cleaned) {
    throw new Error('Phone number cannot be empty');
  }

  // Pattern 1: Local 10-digit (09XXXXXXXX or 07XXXXXXXX)
  if (/^09\d{8}$/.test(cleaned)) {
    return `2519${cleaned.slice(2)}`;
  }
  if (/^07\d{8}$/.test(cleaned)) {
    return `2517${cleaned.slice(2)}`;
  }

  // Pattern 2: International with leading '+' (+2519XXXXXXXX or +2517XXXXXXXX)
  if (/^\+251(9|7)\d{8}$/.test(cleaned)) {
    return cleaned.slice(1);
  }

  // Pattern 3: Exact 12-digit without leading '+' (2519XXXXXXXX or 2517XXXXXXXX)
  if (/^251(9|7)\d{8}$/.test(cleaned)) {
    return cleaned;
  }

  throw new Error(
    `Invalid Ethiopian phone number: "${phone}". Expected local 10-digit (09..., 07...), international (+2519..., +2517...), or 12-digit numeric (2519..., 2517...).`
  );
}

/**
 * Detailed validator helper returning validation state and human-readable feedback.
 */
export function validateEthiopianPhone(phone: string): {
  isValid: boolean;
  error?: string;
  normalized?: string;
  carrier?: 'Ethio Telecom' | 'Safaricom Ethiopia';
  format?: 'local' | 'international';
} {
  if (!phone || phone.trim() === '') {
    return { isValid: false, error: 'Phone number is required' };
  }

  const cleaned = phone.trim().replace(/[\s\-\(\)]/g, '');

  if (!/^\+?\d+$/.test(cleaned)) {
    return {
      isValid: false,
      error: 'Phone number can only contain digits and an optional leading "+"',
    };
  }

  if (cleaned.startsWith('+')) {
    if (cleaned.length < 13) {
      return {
        isValid: false,
        error: `Incomplete international number (${cleaned.length}/13 characters). Must start with +2519 or +2517`,
      };
    }
    if (cleaned.length > 13) {
      return {
        isValid: false,
        error: `International number exceeds 13 characters (${cleaned.length}/13). Expected: +2519XXXXXXXX or +2517XXXXXXXX`,
      };
    }
  } else {
    if (cleaned.length < 10) {
      return {
        isValid: false,
        error: `Incomplete local number (${cleaned.length}/10 digits). Must start with 09 or 07`,
      };
    }
    if (cleaned.length > 10) {
      return {
        isValid: false,
        error: `Local phone number exceeds 10 digits (${cleaned.length}/10). Expected 09... or 07...`,
      };
    }
  }

  if (!ETHIOPIAN_PHONE_REGEX.test(cleaned)) {
    return {
      isValid: false,
      error: 'Invalid Ethiopian prefix. Valid prefixes are 09, 07 (local) or +2519, +2517 (international)',
    };
  }

  const normalized = formatToE164(cleaned);
  const isSafaricom = normalized.startsWith('+2517');

  return {
    isValid: true,
    normalized,
    carrier: isSafaricom ? 'Safaricom Ethiopia' : 'Ethio Telecom',
    format: cleaned.startsWith('+') ? 'international' : 'local',
  };
}

/**
 * Raw Zod string validator for Ethiopian mobile phone numbers.
 */
export const ethiopianPhoneRawSchema = z
  .string({
    message: 'Ethiopian phone number is required',
  })
  .trim()
  .min(10, { message: 'Phone number must be at least 10 characters (e.g., 0910109191)' })
  .max(13, { message: 'Phone number cannot exceed 13 characters (e.g., +251910109191)' })
  .regex(ETHIOPIAN_PHONE_REGEX, {
    message: 'Invalid Ethiopian phone number. Must be local (09..., 07...) or international (+2519..., +2517...) followed by 8 digits.',
  });

/**
 * Strongly typed Zod schema with automatic E.164 normalization transform (+2519... / +2517...).
 */
export const ethiopianPhoneSchema = ethiopianPhoneRawSchema.transform((val) => formatToE164(val));

/**
 * Optional / Nullable Ethiopian phone number Zod schema with normalization.
 */
export const optionalEthiopianPhoneSchema = z
  .string()
  .trim()
  .optional()
  .or(z.literal(''))
  .refine(
    (val) => {
      if (!val || val === '') return true;
      return ETHIOPIAN_PHONE_REGEX.test(val);
    },
    {
      message: 'Invalid Ethiopian phone number. Must be local (09..., 07...) or international (+2519..., +2517...) followed by 8 digits.',
    }
  )
  .transform((val) => {
    if (!val || val === '') return '';
    return formatToE164(val);
  });

/**
 * Schema specifically dedicated to validating and normalizing Spouse Phone Numbers.
 */
export const spousePhoneSchema = optionalEthiopianPhoneSchema;

/**
 * Validates spouse phone number with clear feedback in marriage and family contexts.
 */
export function validateSpousePhone(
  spousePhone: string | undefined | null,
  maritalStatus?: string
): {
  isValid: boolean;
  error?: string;
  normalized?: string;
} {
  if (!spousePhone || spousePhone.trim() === '') {
    return { isValid: true, normalized: '' };
  }
  const check = validateEthiopianPhone(spousePhone);
  if (!check.isValid) {
    return {
      isValid: false,
      error: `Invalid Spouse Phone Number: ${check.error || 'Must be Ethiopian mobile (09/07 or +2519/+2517)'}`,
    };
  }
  return {
    isValid: true,
    normalized: check.normalized,
  };
}

export type EthiopianPhone = z.infer<typeof ethiopianPhoneSchema>;

