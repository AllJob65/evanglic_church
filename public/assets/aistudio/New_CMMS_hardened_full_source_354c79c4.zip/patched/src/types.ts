export type UserRole =
  | 'SYSTEM_ADMIN'
  | 'MANAGER'
  | 'PASTOR'
  | 'MINISTRY_LEADER'
  | 'REGULAR_MEMBER';

export interface RolePermissions {
  role: UserRole;
  financialApprovalLimit: number; // in USD or ETB
  canManageUsers: boolean;
  canAssignRoles: boolean;
  canViewAllMembers: boolean;
  canCreateMembers: boolean;
  canEditMembers: boolean;
  canDeleteMembers: boolean;
  canManageAttendance: boolean;
  canManageEvents: boolean;
  canViewFinances: boolean;
  canManageFinances: boolean;
  canApproveExpenses: boolean;
  canManageBudgets: boolean;
  canManagePrayerRequests: boolean;
  canManageCounseling: boolean;
  canManageMinistries: boolean;
  canManageBranches: boolean;
  canGenerateReports: boolean;
  canViewReports: boolean;
  canExportData: boolean;
  canManageCommunication: boolean;
  canManageSystem: boolean;
  canManageWorkflows: boolean;
  canViewAuditLogs: boolean;
  canViewCounseling: boolean;
  canAccessBackupAndRestore: boolean;
  canAccessSystemSettings: boolean;
  canHostLiveBroadcast: boolean;
  dataExportScope: 'Unlimited' | 'HQ Data' | 'Branch Data' | 'Ministry Data' | 'Personal Only' | 'None';
}

export type MembershipStatus =
  | 'Active'
  | 'Inactive'
  | 'Transferred'
  | 'Deceased'
  | 'On Leave'
  | 'Left Church'
  | 'Excommunicated'
  | 'Pending'
  | 'Pending Approval'
  | 'Rejected';

export type MembershipType =
  | 'Full Member'
  | 'Associate Member'
  | 'Affiliate Member'
  | 'Youth Member'
  | 'Honorary'
  | 'Full Communicant Member'
  | 'Probationary Member';
export type Gender = 'Male' | 'Female';
export type MaritalStatus = 'Single' | 'Married' | 'Widowed' | 'Divorced' | 'Separated';

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
  altPhone?: string;
}

export interface Member {
  id: string;
  tenantId?: string;
  memberIdNumber: string; // e.g., CMMS-2025-0104
  memberCode?: string;
  title: string;
  name?: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  preferredName?: string;
  dateOfBirth: string;
  age?: number;
  gender: Gender;
  nationality?: string;
  nationalIdNumber?: string;
  passportNumber?: string;
  photoUrl?: string;
  amharicName?: string;
  
  // Marital Status & Spouse Info
  maritalStatus?: MaritalStatus;
  marriageDate?: string;
  divorceDate?: string;
  spouseName?: string;
  spousePhone?: string;
  spouseMemberId?: string;
  
  // Contact
  primaryPhone: string;
  altPhone?: string;
  email?: string;
  preferredCommChannel?: 'Email' | 'SMS' | 'WhatsApp' | 'Phone' | 'Telegram' | string;
  
  // Address
  streetAddress: string;
  city: string;
  subCity?: string;
  woreda?: string;
  kebele?: string;
  houseNumber?: string;
  village?: string;
  region?: string;
  country?: string;
  postalCode?: string;
  gpsCoordinates?: string;

  // Family & Household
  familyId?: string;
  familyRole?: 'Head' | 'Spouse' | 'Child' | 'Dependent' | 'Relative';
  maleChildrenCount?: number;
  femaleChildrenCount?: number;
  adoptedChildrenCount?: number;

  // Spiritual
  salvationDate?: string;
  salvationLocation?: string;
  ledToChristBy?: string;
  salvationTestimony?: string;
  isWaterBaptized?: boolean;
  waterBaptized?: boolean;
  waterBaptismDate?: string;
  baptismDate?: string;
  waterBaptismLocation?: string; // Church where baptized
  baptizedBy?: string;
  waterBaptismCertUrl?: string;
  isHolySpiritBaptized?: boolean;
  holySpiritBaptismDate?: string;
  spiritualGifts?: string[];
  membershipDate?: string;
  membershipLocation?: string; // Where membership was received / church
  membershipStatus: MembershipStatus;
  membershipType?: MembershipType;
  branchId: string;
  discipleshipStatus?: 'New Convert' | 'In Foundation Class' | 'Discipled' | 'Discipler / Leader';
  discipleshipLevel?: string;
  previousChurch?: string;
  foundationCourseCompleted?: boolean;
  bibleStudyGroupId?: string;
  mentorName?: string;
  currentMinistryStatus?: string; // Ministry status now
  previousMinistryStatus?: string; // Ministry status before
  ministriesServedBefore?: string[]; // Past ministries served before
  ministriesJoinedNow?: string[]; // Current / Newly joined ministries (Now joined for)

  // Professional & Education
  educationLevel?: 'No Formal Education' | 'Primary' | 'Secondary' | 'Diploma' | 'Bachelor' | 'Master' | 'Doctorate' | 'Other';
  institutionName?: string;
  fieldOfStudy?: string;
  occupation?: string;
  employer?: string;
  employerName?: string;
  employerType?: 'Individual' | 'Private' | 'Government' | 'NGO (Non-Profit)' | 'Other';
  employerTypeOther?: string;
  employerContact?: string;
  skillsAndTalents?: string[];
  languagesSpoken?: string[];

  // Past Member / Death Record details
  departureReason?: 'Deceased' | 'Transferred' | 'Moved Away' | 'Resigned' | 'Left Church' | 'Excommunicated' | 'Inactive' | 'On Leave' | 'Other';
  departureDate?: string; // Departure or status start date
  departureEndDate?: string; // Departure or status end date
  statusStartDate?: string;
  statusEndDate?: string;
  departureNotes?: string;
  excommunicationPaperUrl?: string; // Base64 or document URL for Paper of Excommunication
  excommunicationPaperName?: string; // Original filename of paper
  excommunicationDescription?: string; // Detailed description for excommunication

  // Medical & Pastoral Care
  bloodType?: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  knownAllergies?: string[];
  medicalConditions?: string[];
  specialNeeds?: string;
  emergencyContact: EmergencyContact;
  notes?: string;

  // System
  ministryIds: string[];
  createdAt: string;
  lastActive: string;
  attendanceScore: number; // 0 - 100
  status?: string; role?: string; ministry?: string; phone?: string; joinDate?: string;
}

export interface Family {
  id: string;
  tenantId?: string;
  branchId?: string;
  familyCode: string;
  householdName: string; // e.g., The Johnson Household
  headOfHouseholdMemberId: string;
  primaryHouseholdPhone?: string; // Shared family primary phone identifier
  familyType: 'Nuclear Family' | 'Extended Family' | 'Single Parent' | 'Blended Family' | 'Other';
  familyPhotoUrl?: string;
  primaryLanguage: string;
  address: string;
  woreda?: string;
  kebele?: string;
  houseNumber?: string;
  city: string;
  region: string;
  memberIds: string[];
  relationships: {
    fromMemberId: string;
    toMemberId: string;
    relationType: 'Spouse' | 'Parent' | 'Child' | 'Sibling' | 'Grandparent' | 'Guardian' | 'Relative';
  }[];
  registrationDate: string;
  status: 'Active' | 'Inactive' | 'Archived';
  familyName?: string; memberCount?: number;
}

export interface ProfileChangeRequest {
  id: string;
  memberId: string;
  memberIdNumber: string;
  memberName: string;
  memberEmail?: string;
  submittedAt: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  reviewedBy?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  requestedChanges?: any;
  changedFields: {
    fieldKey: string;
    fieldLabel: string;
    oldValue: any;
    newValue: any;
  }[];
  newSnapshot: Partial<Member>;
}

export interface SystemBrandingConfig {
  churchName: string;
  systemName: string;
  titleBadge: string;
  churchMotto: string;
  faviconUrl: string;
  churchLogoUrl: string;
  darkLogoUrl?: string;
  primaryColorHex: string;
  accentColorHex: string;
  loginPanelColorHex?: string;
  defaultThemeMode?: 'light' | 'dark' | 'advanced-dark' | 'system';
  headquartersAddress: string;
  contactPhone: string;
  contactEmail: string;
  taxIdNumber: string;
}

export interface UserRoleAssignment {
  role: UserRole;
  isPrimary: boolean;
  assignedAt?: string;
  assignedBy?: string;
}

export interface SystemUser {
  id: string;
  tenantId?: string;
  name: string;
  email: string;
  phone?: string;
  photoUrl?: string;
  avatar?: string;
  role: UserRole;
  primaryRole?: UserRole;
  additionalRoles?: UserRole[];
  roles?: UserRole[];
  userRoles?: UserRoleAssignment[];
  permissions?: string[];
  effectivePermissions?: string[];
  deniedPermissions?: string[];
  branchId?: string;
  branchName: string;
  branchIds?: string[];
  assignedCampuses?: string[];
  status: 'Active' | 'Inactive' | 'Disabled' | 'Suspended' | 'Pending' | 'Locked';
  lastLogin: string;
  isMfaEnabled?: boolean;
  mfaEnabled?: boolean;
  mfa_enabled?: boolean;
  mfaEnrolled?: boolean;
  mfa_enrolled?: boolean;
  mfaFactorId?: string;
  mfaQrUri?: string;
  approvalLimit?: number;
  approvalRoleLevel?: 'Junior Approver' | 'Senior Approver' | 'Executive Sign-off' | 'Board Trustee' | 'Standard Staff' | string;
  allowedApprovalTypes?: string[];
  notes?: string;
  must_change_password?: boolean;
  mustChangePassword?: boolean;
  password_changed_at?: string;
  password_reset_at?: string;
  password_reset_by?: string;
  temp_password_expires_at?: string;
  temporary_password_expires_at?: string;
  temporaryPassword?: string;
  session_revoked_at?: string;
  last_max_auth_at?: string;
  totpSecret?: string;
  mfaSecret?: string;
  security?: {
    lastMaxAuthAt?: string;
    lastLoginAt?: string;
    sessionRevokedAt?: string;
  };
}

export interface MonthlyBudgetItem {
  month: string;
  amount: number;
  purpose: string;
  status: 'Allocated' | 'Disbursed' | 'Pending';
  todos: {
    id: string;
    task: string;
    isCompleted: boolean;
    actionType: 'Do' | 'Not Do';
  }[];
}

export interface Branch {
  id: string;
  tenantId?: string;
  code: string;
  name: string;
  type: 'Headquarters' | 'Satellite Campus' | 'Outreach Location' | 'Regional Center';
  parentBranchId?: string;
  seniorPastor: string;
  pastorName?: string;
  phone: string;
  email: string;
  website: string;
  address: string;
  location?: string;
  city: string;
  region: string;
  gpsCoordinates: string;
  serviceTimes: { day: string; time: string; name: string }[];
  languages: string[];
  timezone: string;
  establishedDate: string;
  status: 'Active' | 'Under Construction' | 'Merged' | 'Inactive';
  totalMembersCount: number;
  capacity?: number;
  monthlyTargetBudget: number;
}

export interface Ministry {
  id: string;
  tenantId?: string;
  name: string;
  category?: string;
  description: string;
  branchId: string;
  directorMemberId: string;
  coordinatorMemberId?: string;
  leaderMemberId?: string;
  leaderUserId?: string;
  leaderMemberName?: string;
  leaderName?: string;
  memberIds?: string[];
  meetingSchedule?: string;
  meetingTime?: string;
  meetingLocation?: string;
  budgetYearToDate?: number;
  parentMinistryId?: string;
  establishedDate: string;
  status: 'Active' | 'Inactive' | 'Pending';
  memberCount: number;
  annualBudget: number;
  spentBudget: number;
  subMinistries?: { id: string; name: string; leaderName: string; memberCount: number }[];
  monthlyAllocations?: MonthlyBudgetItem[];
  budgetAllocated?: number; budgetSpent?: number; leadName?: string;
}

export interface AttendanceSession {
  id: string;
  tenantId?: string;
  sessionId: string;
  groupId: string; // ministryId or groupId
  groupName?: string;
  branchId?: string;
  leaderId: string;
  leaderName?: string;
  type: 'instant' | 'scheduled';
  title: string;
  serviceType?: string;
  status: 'active' | 'closed';
  startTime: string;
  endTime?: string | null;
  qrPayloadToken: string;
  location?: string;
  attendeeCount?: number;
  date?: string; presentCount?: number; totalCount?: number;
}

export interface AttendanceRecord {
  id: string;
  tenantId?: string;
  recordId?: string;
  sessionId?: string;
  serviceName?: string;
  serviceType?: 'Sunday Main Service' | 'Midweek Service' | 'Prayer Meeting' | 'Bible Study Group' | 'Youth Service' | 'Special Event' | 'Ministry Attendance' | string;
  serviceSession?: string;
  eventName?: string;
  eventId?: string;
  branchId: string;
  date: string;
  time?: string;
  memberId: string;
  memberName?: string;
  checkInTime?: string;
  checkedInTime?: string;
  checkInType?: 'qr' | 'manual' | string;
  checkInMethod?: 'Manual Web Click' | 'QR Code Scanning' | 'QR Code' | 'Face Recognition' | 'NFC Card' | 'Mobile App' | 'Manual Headcount' | 'Excel Import' | 'Self QR Scan' | string;
  status: 'Present' | 'Late' | 'Absent Excused' | 'Absent Unexcused' | 'Absent' | 'present' | string;
  absenceReason?: string;
  notes?: string;
}

export interface EventItem {
  id: string;
  tenantId?: string;
  title: string;
  type: 'Conference' | 'Crusade' | 'Retreat' | 'Wedding' | 'Baptism Ceremony' | 'Leadership Meeting' | 'Seminar' | 'Outreach';
  category?: string;
  branchId: string;
  ministryId?: string;
  startDate: string;
  endDate: string;
  date?: string;
  time?: string;
  location: string;
  description: string;
  posterUrl?: string;
  speakerNames: string[];
  organizer?: string;
  capacity: number;
  registeredCount: number;
  isPaid: boolean;
  ticketPrice?: number;
  ticketTypes?: { name: string; price: number; quota: number }[];
  status: 'Upcoming' | 'In Progress' | 'Completed' | 'Cancelled';
}

export interface CommunicationMessage {
  id: string;
  tenantId?: string;
  branchId?: string;
  subject: string;
  body: string;
  senderRole?: string;
  channel: 'Email' | 'SMS' | 'Push Notification' | 'WhatsApp' | 'Telegram' | 'Multi-Channel';
  triggerType?: 'Manual Broadcast' | 'Birthday Greeting' | 'Anniversary' | 'Event Reminder' | 'Emergency Alert' | 'Daily Devotional' | 'Drip Campaign' | string;
  targetAudience: string; // e.g., 'All Active Members', 'Youth Ministry', 'Branch: City Campus'
  recipientCount: number;
  sentAt: string;
  status: 'Sent' | 'Scheduled' | 'Draft' | 'Failed';
  deliveryRatePercentage?: number;
  deliveryStats?: { sent: number; delivered: number; opened: number; failed: number };
}

export interface PrayerRequest {
  id: string;
  tenantId?: string;
  branchId?: string;
  requestNumber: string;
  memberId: string;
  memberName: string;
  requesterName?: string;
  phone?: string;
  email?: string;
  category: 'Physical Health' | 'Emotional Well-being' | 'Family Situation' | 'Financial Need' | 'Spiritual Concern' | 'Church Matter' | 'Personal Member Care' | 'Pastoral Care' | 'Other' | string;
  title: string;
  topic?: string;
  description: string;
  details?: string;
  isConfidential: boolean;
  confidentialityLevel?: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Emergency';
  urgencyLevel?: string;
  priority?: string;
  assignedIntercessorId?: string;
  status: 'Pending' | 'Praying' | 'Answered' | 'Closed';
  submittedDate: string;
  submittedAt?: string;
  testimonyNotes?: string;
}

export interface CounselingSession {
  id: string;
  tenantId?: string;
  branchId?: string;
  memberId?: string;
  counselorId?: string;
  sessionCode: string;
  memberName?: string; category?: string; scheduledDate?: string; scheduledTime?: string;
  clientMemberId: string;
  clientName: string;
  counselorName: string;
  counselingType: 'Marriage' | 'Premarital' | 'Youth' | 'Family' | 'Individual' | 'Grief' | 'Addiction' | 'Crisis' | 'Spiritual';
  sessionDate: string;
  sessionTime: string;
  mode: 'In-Person' | 'Virtual Video Call';
  status: 'Requested' | 'Scheduled' | 'Completed' | 'Cancelled';
  encryptedCaseNotes: string;
  treatmentGoals?: string[];
}

export interface VisitationRecord {
  id: string;
  tenantId?: string;
  branchId?: string;
  visitationCode: string;
  memberId: string;
  memberName: string;
  visitorNames: string[];
  visitationType: 'New Convert' | 'Sick Member / Hospital' | 'Home Care' | 'Bereavement' | 'Inactive Re-engagement' | 'Missing Member' | 'Elderly Care';
  visitDate: string;
  location: string;
  summaryNotes: string;
  prayerPoints: string[];
  followUpRequired: boolean;
  followUpDueDate?: string;
  status: 'Completed' | 'Follow-up Pending' | 'Closed';
}

export interface VolunteerShift {
  id: string;
  tenantId?: string;
  branchId?: string;
  volunteerId?: string;
  volunteerMemberId: string;
  volunteerName: string;
  ministryId: string;
  ministryName: string;
  roleTitle: string;
  shiftDate: string;
  startTime: string;
  endTime: string;
  status: 'Scheduled' | 'Confirmed' | 'Completed' | 'Swapped / Substitute';
  memberName?: string; role?: string; serviceDate?: string; shiftTime?: string;
  hoursLogged: number;
}

export interface Asset {
  id: string;
  tenantId?: string;
  assetCode: string;
  name: string;
  category: 'Musical Instrument' | 'Furniture' | 'Electronics & Displays' | 'Vehicles' | 'Sound & Audio' | 'IT Equipment' | 'Office & Admin';
  branchId: string;
  custodianMemberName: string;
  purchaseDate: string;
  purchasePrice: number;
  currentValue: number;
  condition: 'Excellent' | 'Good' | 'Fair' | 'Needs Repair' | 'Disposed';
  nextMaintenanceDate: string;
}

export interface DocumentItem {
  id: string;
  tenantId?: string;
  branchId?: string;
  title: string;
  category: 'Sermon Outlines & Media' | 'Board Meeting Minutes' | 'Church Policies & Handbooks' | 'Financial Statements' | 'Legal & Registration' | 'Training Materials';
  fileFormat: 'PDF' | 'DOCX' | 'MP3' | 'MP4' | 'ZIP' | 'PPTX' | string;
  fileSizeMb: number;
  uploadedBy: string;
  uploadDate: string;
  version: string;
  isConfidential: boolean;
  tags: string[];
  downloadCount: number;
  fileUrl?: string;
}

export interface LmsCourse {
  id: string;
  courseCode: string;
  title: string;
  category: 'Biblical Studies' | 'Discipleship & Foundations' | 'Leadership Training' | 'Theology' | 'Ministry Skills';
  instructorName: string;
  description: string;
  totalModules: number;
  durationWeeks: number;
  enrolledStudentsCount: number;
  passPercentage: number;
}

export interface WorkflowRequest {
  id: string;
  tenantId?: string;
  requesterId?: string;
  requestCode: string;
  requestType: 'Membership Application' | 'Branch Transfer' | 'Leave Request' | 'Event Authorization' | 'Budget Request' | 'Purchase Approval';
  requesterName: string;
  requesterPhone?: string;
  requesterEmail?: string;
  branchName: string;
  branchId?: string;
  details: string;
  amountRequested?: number;
  currentStep: string;
  assignedApproverRole: UserRole;
  submittedDate: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Escalated';
  comments?: string;
  pendingMemberId?: string;
  pendingMemberData?: Partial<Member>;
  approvedBy?: string;
  approvedAt?: string;
  rejectedReason?: string;
  decisionNotes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userEmail: string;
  userName?: string;
  user?: string;
  userRole: UserRole;
  actorId?: string;
  eventType?: string;
  outcome?: 'SUCCESS' | 'FAILURE' | 'BLOCKED' | 'WARNING';
  severity?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  correlationId?: string;
  action: string;
  module: string;
  targetUserId?: string;
  targetUserEmail?: string;
  ipAddress: string;
  userAgent?: string;
  deviceFingerprint?: string;
  sessionId?: string;
  location?: string;
  details: string;
  commitData?: string;
  device?: string;
  prevHash?: string;
  integrityHash?: string;
  schemaVersion?: string;
}

export interface TenantJWTPayload {
  sub: string; // user_id
  user_id: string;
  email: string;
  name: string;
  role: UserRole;
  tenant_id: string;
  branch_id: string;
  branchName: string;
  permissions: string[];
  status: string;
  iat: number;
  exp: number;
}

export interface MinistryChatMessage {
  id: string;
  tenantId: string;
  ministryId: string;
  ministryName: string;
  senderId: string;
  senderName: string;
  senderEmail: string;
  senderRole: string;
  senderAvatar?: string;
  text: string;
  scriptureRef?: string;
  attachmentUrl?: string;
  attachmentName?: string;
  timestamp: string;
  reactions?: { emoji: string; count: number; users: string[] }[];
}

export interface VideoParticipant {
  id: string;
  userId: string;
  name: string;
  role: string;
  email?: string;
  avatar?: string;
  isMuted: boolean;
  isVideoOff: boolean;
  isScreenSharing: boolean;
  isHandRaised?: boolean;
  isSpeaking?: boolean;
  joinedAt: string;
}

export interface MinistryVideoRoom {
  roomId: string;
  tenantId: string;
  ministryId: string;
  ministryName: string;
  title: string;
  hostId: string;
  hostName: string;
  participants: VideoParticipant[];
  isActive: boolean;
  startedAt: string;
}

export interface MinistryMemberRecord {
  id: string;
  ministryId: string;
  userId: string;
  userName: string;
  userEmail?: string;
  userAvatar?: string;
  role: 'Leader' | 'CoLeader' | 'Member' | 'Volunteer';
  status: 'Active' | 'Inactive' | 'Pending';
  joinedAt: string;
}

export interface MinistryActivityLog {
  id: string;
  ministryId: string;
  userId?: string;
  userName?: string;
  actionType: 'message_posted' | 'reaction_added' | 'member_joined' | 'member_left' | 'video_started' | 'video_joined' | 'budget_updated' | 'todo_completed';
  title: string;
  description?: string;
  createdAt: string;
}

export interface ApiKeyRecord {
  id: string;
  name: string;
  keyPrefix: string;
  apiKey?: string; // full key returned only upon creation
  scopes: ('read:members' | 'write:members' | 'read:attendance' | 'write:attendance' | 'read:events' | 'send:sms' | 'read:branches' | 'admin:full')[];
  createdAt: string;
  lastUsedAt?: string;
  status: 'Active' | 'Revoked';
  rateLimitPerMin: number;
  description?: string;
}

export interface WebhookSubscription {
  id: string;
  name: string;
  targetUrl: string;
  events: ('member.created' | 'member.updated' | 'attendance.recorded' | 'event.created' | 'prayer.submitted' | 'sms.dispatched')[];
  secretToken: string;
  active: boolean;
  createdAt: string;
  lastTriggeredAt?: string;
  lastStatusCode?: number;
  failureCount: number;
}

export interface SupabaseConnectionStatus {
  isConfigured: boolean;
  url: string;
  anonKeyConfigured: boolean;
  isConnected: boolean;
  latencyMs?: number;
  tablesFound?: string[];
  lastChecked: string;
  error?: string;
  rowCountEstimates?: {
    members: number;
    branches: number;
    attendance: number;
    auditLogs: number;
  };
}

export interface SmsGatewayConfig {
  provider: 'EthioTelecom';
  senderId: string;
  enabled: boolean;
  smsUrl?: string;
  appId?: string;
  appSecret?: string;
  balanceCredits: number;
  monthlyQuota: number;
  usedCredits: number;
}

export interface GroupChatSession {
  id: string;
  groupId: string;
  leaderId: string;
  isActive: boolean;
  startedAt: string | Date;
  endedAt?: string | Date;
}

export interface VideoConference {
  id: string;
  groupId: string;
  leaderId: string;
  title: string;
  roomUrl: string; // Dynamic WebRTC link (Jitsi, Agora, Daily.co)
  status: 'active' | 'ended';
  createdAt: string | Date;
}

// ==========================================
// DEVOTIONS & BIBLE DATA TYPES
// ==========================================

export type DevotionStatus = 'draft' | 'published' | 'scheduled' | 'archived';
export type DevotionReactionType = 'heart' | 'amen' | 'praying' | 'inspiring';

export interface Devotion {
  id: string;
  title: string;
  amharicTitle?: string;
  topic: string;
  scriptureReference: string;
  bibleVersionId?: number;
  keyVerse?: string;
  body: string;
  prayer?: string;
  authorId?: string;
  authorName: string;
  audioUrl?: string;
  status: DevotionStatus;
  scheduledFor?: string;
  publishedAt: string;
  createdAt: string;
  updatedAt: string;
  reactionsCount?: {
    heart: number;
    amen: number;
    praying: number;
    inspiring: number;
  };
  userReactions?: DevotionReactionType[];
  commentsCount?: number;
}

export interface DevotionReaction {
  id: string;
  devotionId: string;
  userId: string;
  reactionType: DevotionReactionType;
  createdAt: string;
}

export interface DevotionComment {
  id: string;
  devotionId: string;
  userId: string;
  userName: string;
  userPhotoUrl?: string;
  commentText: string;
  createdAt: string;
  isModerated?: boolean;
}

export interface BibleNote {
  id: string;
  userId: string;
  bookId: string;
  chapter: number;
  verse?: number;
  passageTitle?: string;
  noteText: string;
  createdAt: string;
  updatedAt: string;
}

export interface BibleHighlight {
  id: string;
  userId: string;
  bookId: string;
  chapter: number;
  verse: number;
  color: 'yellow' | 'green' | 'blue' | 'rose' | 'purple';
  createdAt: string;
}

export interface BibleBookmark {
  id: string;
  userId: string;
  bookId: string;
  bookNameAmharic: string;
  bookNameEnglish: string;
  chapter: number;
  verse: number;
  verseText: string;
  createdAt: string;
}

export interface BibleReadingHistoryEntry {
  id: string;
  userId: string;
  bookId: string;
  bookName: string;
  chapter: number;
  readAt: string;
}

export interface BibleReadingPlanProgress {
  id: string;
  userId: string;
  planId: string;
  completedDays: number[];
  streakCount: number;
  lastCompletedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface YouVersionBible {
  id: number;
  abbreviation: string;
  title: string;
  localized_title?: string;
  localized_abbreviation?: string;
  language_tag: string;
  promotional_content?: string | null;
  copyright?: string | null;
  info?: string | null;
  publisher_url?: string | null;
  books?: string[];
  youversion_deep_link?: string | null;
  slotKey?: string;
  organization_id?: string | null;
  enabled?: boolean;
  displayOrder?: number;
  isDefault?: boolean;
  isFeatured?: boolean;
  requestedSlot?: string;
  userDisplayLabel?: string;
}

export interface BibleTranslationConfigItem {
  slotKey: string;
  requestedAbbreviation: string;
  requestedTitle: string;
  youversionBibleId: number | null;
  matchedAbbreviation: string | null;
  matchedLocalizedAbbreviation: string | null;
  matchedTitle: string | null;
  matchedLocalizedTitle: string | null;
  languageTag: string;
  enabled: boolean;
  displayOrder: number;
  isDefault: boolean;
  isFeatured: boolean;
  availableInApi: boolean;
  matchStatus: 'matched' | 'unmatched_license_restricted';
  matchNotes?: string;
}

export interface BibleTranslationAdminConfig {
  enabledBibleIds: number[];
  defaultBibleId: number;
  featuredBibleId: number;
  displayOrderMap: Record<number, number>;
  configuredSlots: BibleTranslationConfigItem[];
  updatedAt: string;
  updatedBy?: string;
}

export interface YouVersionPassage {
  id: string;
  content: string;
  reference?: string;
  version_id?: number;
  copyright?: string;
}

export interface YouVersionVerseOfTheDay {
  day: number;
  passageId: string;
  textAmharic: string;
  textEnglish: string;
  reference?: string;
}

export type BibleFontSize = 'small' | 'medium' | 'large' | 'xlarge' | 'sm' | 'base' | 'lg' | 'xl';
export type BibleFontFamily = 'serif' | 'sans' | 'mono';
export type BibleLineSpacing = 'compact' | 'comfortable' | 'spacious' | 'normal' | 'relaxed';
export type BibleReadingWidth = 'narrow' | 'normal' | 'wide' | 'standard';
export type BibleReaderTheme = 'light' | 'dark' | 'system' | 'parchment' | 'midnight';

export interface BibleReadingPosition {
  bookId: string;
  bookEnglish: string;
  bookAmharic: string;
  chapter: number;
  verse?: number;
  timestamp: string;
}

export interface BibleReaderSettings {
  id?: string;
  userId?: string;
  // Bible Version
  preferredVersionId: number | string;
  preferredVersionName?: string;
  preferredVersionAbbreviation?: string;
  preferredLanguage?: 'Amharic' | 'English' | 'Parallel';
  // Typography & Layout
  fontSize: BibleFontSize;
  fontFamily?: BibleFontFamily;
  lineSpacing: BibleLineSpacing;
  readingWidth: BibleReadingWidth;
  theme: BibleReaderTheme;
  // Display Options
  showVerseNumbers: boolean;
  showFootnotes: boolean;
  showCrossReferences: boolean;
  showRedLetters?: boolean;
  // Reading tracking
  rememberReadingPosition: boolean;
  trackReadingHistory: boolean;
  lastReadingPosition?: BibleReadingPosition;
  // Personal Study Toggles
  enableNotes: boolean;
  enableHighlights: boolean;
  enableBookmarks: boolean;
  updatedAt?: string;
}

export const DEFAULT_BIBLE_READER_SETTINGS: BibleReaderSettings = {
  preferredVersionId: 111,
  preferredVersionName: 'New International Version (NIV)',
  preferredVersionAbbreviation: 'NIV',
  preferredLanguage: 'English',
  fontSize: 'medium',
  fontFamily: 'serif',
  lineSpacing: 'comfortable',
  readingWidth: 'normal',
  theme: 'light',
  showVerseNumbers: true,
  showFootnotes: true,
  showCrossReferences: true,
  showRedLetters: true,
  rememberReadingPosition: true,
  trackReadingHistory: true,
  enableNotes: true,
  enableHighlights: true,
  enableBookmarks: true,
  lastReadingPosition: {
    bookId: 'JHN',
    bookEnglish: 'John',
    bookAmharic: 'የዮሐንስ ወንጌል',
    chapter: 3,
    verse: 16,
    timestamp: new Date().toISOString(),
  },
};

// ==========================================
// PASTOR / MANAGER BIBLE MESSAGES & SCHEDULED SHARING
// ==========================================

export type BibleMessageStatus = 'draft' | 'scheduled' | 'sent' | 'cancelled';
export type BibleRecipientType = 'all' | 'ministry' | 'group' | 'branch' | 'members';

export interface BibleMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  translationId: string | number;
  translationName: string;
  translationAbbreviation: string;
  bookId: string;
  bookName: string;
  chapter: number;
  verseStart: number;
  verseEnd?: number;
  reference: string;
  passageText: string;
  note: string; // Separate pastor/leader message from passage
  recipientType: BibleRecipientType;
  recipientTargetIds?: string[];
  recipientTargetNames?: string[];
  recipientCount: number;
  status: BibleMessageStatus;
  scheduledAt?: string;
  sentAt?: string;
  timezone?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BibleMessageRecipient {
  id: string;
  messageId: string;
  memberId: string;
  memberName?: string;
  memberEmail?: string;
  isRead: boolean;
  readAt?: string;
  deliveredAt: string;
}

export interface BibleNotification {
  id: string;
  userId: string;
  messageId: string;
  title: string;
  body: string;
  reference: string;
  note: string;
  senderName: string;
  senderRole: string;
  isRead: boolean;
  createdAt: string;
}

// ==============================================================================
// AD-HOC AND CROSS-GROUP CONVERSATIONS (CHAT & VIDEO) - PHASE 20
// Explicit participant list, independent of ministry/group membership
// ==============================================================================
export type ConversationType = 'direct' | 'ad_hoc_group' | 'video';
export type ConversationStatus = 'active' | 'ended';

export interface DirectVideoSession {
  roomUrl: string;
  startedAt: string;
  startedBy: string;
  callerName?: string;
  callerRole?: string;
  recipientId?: string;
  recipientName?: string;
  status: 'calling' | 'active' | 'ended';
}

export interface Conversation {
  id: string;
  type: ConversationType;
  title: string | null;
  createdBy: string;
  tenantId: string;
  branchId?: string | null;
  status: ConversationStatus;
  createdAt: string;
  endedAt?: string | null;
  roomUrl?: string | null;
  activeVideoCall?: DirectVideoSession | null;
  participants?: ConversationParticipant[];
  lastMessage?: ConversationMessage | null;
  unreadCount?: number;
}

export interface ConversationParticipant {
  id?: string;
  conversationId: string;
  userId: string;
  addedBy: string;
  addedAt: string;
  leftAt?: string | null;
  userName?: string;
  userEmail?: string;
  userRole?: string;
}

export interface ConversationMessage {
  id: string;
  conversationId: string;
  senderId: string;
  body: string;
  createdAt: string;
  editedAt?: string | null;
  deletedAt?: string | null;
  senderName?: string;
  senderRole?: string;
}

// ==============================================================================
// MINISTRY ANNUAL PLANNING & REPORTING SYSTEM (WORKFLOW & GOVERNANCE)
// ==============================================================================
export type MinistryPlanWorkflowStatus =
  | 'Draft'
  | 'Submitted'
  | 'Under Review'
  | 'Returned for Revision'
  | 'Approved'
  | 'Active'
  | 'Completed'
  | 'Rejected';

export interface MinistryPlanObjective {
  id: string;
  title: string;
  description: string;
  priority: 'High' | 'Medium' | 'Low';
  targetQuarter: 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'All Quarters';
  targetMetric?: string;
}

export interface MinistryPlanActivityItem {
  id: string;
  title: string;
  description: string;
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  month: string;
  responsiblePerson: string;
  targetAudience: string;
  monthIndex?: number;
  expectedParticipants: number;
  requiredResources: string;
  estimatedBudget: number;
  status: 'Planned' | 'In Progress' | 'Completed' | 'Deferred';
}

export interface MinistryPlanKpiItem {
  id: string;
  name: string;
  unit: string;
  baselineValue: number;
  targetValue: number;
  actualValue?: number;
  weightPercentage: number;
  baseline?: number; target?: number; currentActual?: number; frequency?: string;
}

export interface MinistryPlanRiskItem {
  id: string;
  riskDescription: string;
  severity: 'High' | 'Medium' | 'Low';
  likelihood: 'High' | 'Medium' | 'Low';
  mitigationPlan: string;
  owner: string;
  impact?: string;
}

export interface MinistryQuarterMilestone {
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  title: string;
  months: string[];
  milestoneSummary: string;
  deliverables: string[];
  plannedActivitiesCount: number;
  expectedParticipants: number;
  allocatedBudget: number;
  responsiblePerson: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  keyDeliverables?: string[];
}

export interface MinistryMonthlyTimelineItem {
  monthIndex: number;
  month: string;
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  focusTheme: string;
  activities: string[];
  responsiblePerson: string;
  expectedParticipants: number;
  allocatedBudget: number;
  requiredResources: string;
  status: 'Planned' | 'In Progress' | 'Completed';
}

export interface MinistryPlanReviewComment {
  id: string;
  planId: string;
  reviewerId: string;
  reviewerName: string;
  reviewerRole: UserRole | string;
  action:
    | 'Comment'
    | 'Start Review'
    | 'Return for Revision'
    | 'Approve'
    | 'Reject'
    | 'Activate'
    | 'Complete'
    | 'Submit'
    | 'Revise & Resubmit';
  comment: string;
  createdAt: string;
}

export interface MinistryQuarterlyKpiResult {
  kpiId: string;
  kpiName: string;
  unit: string;
  quarterlyTarget: number;
  actualAchieved: number;
  achievementRate: number;
  remarks?: string;
}

export interface MinistryQuarterlyReport {
  id: string;
  planId: string;
  ministryId: string;
  ministryName: string;
  branchId: string;
  year: number;
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  plannedActivity: string;
  actualActivity: string;
  plannedParticipants: number;
  actualParticipants: number;
  results: string;
  kpiPerformance: MinistryQuarterlyKpiResult[];
  overallKpiScore: number;
  challenges: string;
  allocatedBudget: number;
  actualExpense: number;
  budgetVariance: number;
  budgetExpenseNotes: string;
  lessonsLearned: string;
  nextQuarterAction: string;
  status: 'Draft' | 'Submitted' | 'Reviewed' | 'Approved' | 'Returned';
  submittedBy: string;
  submittedByName: string;
  submittedAt: string;
  reviewedByName?: string;
  reviewedAt?: string;
  pastorFeedback?: string;
}

export interface MinistryAnnualReport {
  id: string;
  planId: string;
  ministryId: string;
  ministryName: string;
  branchId: string;
  year: number;
  executiveSummary: string;
  quartersIncluded: ('Q1' | 'Q2' | 'Q3' | 'Q4')[];
  totalPlannedActivities: number;
  totalActualActivitiesCompleted: number;
  totalExpectedParticipants: number;
  totalActualParticipants: number;
  participantAchievementRate: number;
  totalAllocatedBudget: number;
  totalActualExpense: number;
  totalBudgetVariance: number;
  budgetUtilizationRate: number;
  overallKpiAchievementRate: number;
  aggregatedKpiResults: {
    kpiName: string;
    unit: string;
    annualTarget: number;
    totalActual: number;
    achievementRate: number;
  }[];
  quarterlyBreakdown: {
    quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
    plannedActivity: string;
    actualActivity: string;
    plannedParticipants: number;
    actualParticipants: number;
    allocatedBudget: number;
    actualExpense: number;
    kpiScore: number;
    results: string;
    challenges: string;
    lessonsLearned: string;
  }[];
  keyAchievements: string;
  majorChallenges: string;
  lessonsLearned: string;
  strategicRecommendationsNextYear: string;
  status: 'Draft' | 'Submitted' | 'Approved';
  submittedBy: string;
  submittedByName: string;
  submittedAt: string;
  approvedByName?: string;
  approvedAt?: string;
  pastorComments?: string;
}

export type MinistryQuarter = 'Q1' | 'Q2' | 'Q3' | 'Q4';
export type MinistryQuarterlyActivityReportItem = any;
export type MinistryQuarterlyKpiReportItem = any;

export interface MinistryAnnualPlan {
  id: string;
  planCode: string;
  tenantId: string;
  branchId: string;
  ministryId: string;
  ministryName: string;
  year: number;
  title: string;
  visionStatement: string;
  objectives: MinistryPlanObjective[];
  activities: MinistryPlanActivityItem[];
  responsiblePerson: string;
  responsiblePersonId?: string;
  targetAudience: string;
  expectedParticipants: number;
  requiredResources: string;
  optionalBudget: number;
  currency: string;
  kpis: MinistryPlanKpiItem[];
  expectedOutcomes: string[];
  risks: MinistryPlanRiskItem[];
  mitigationSummary: string;
  quarterlyMilestones: MinistryQuarterMilestone[];
  monthlyActivities: MinistryMonthlyTimelineItem[];
  status: MinistryPlanWorkflowStatus;
  revisionNumber: number;
  submittedBy: string;
  submittedByName: string;
  submittedAt?: string;
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  returnedReason?: string;
  rejectedReason?: string;
  reviewHistory: MinistryPlanReviewComment[];
  quarterlyReports: MinistryQuarterlyReport[];
  annualReport?: MinistryAnnualReport | null;
  createdAt: string;
  updatedAt: string;
}

// ==============================================================================
// PRODUCTION EMAIL + SMS COMMUNICATION SYSTEM TYPES
// ==============================================================================
export type CommunicationChannel = 'SMS' | 'EMAIL';
export type CommunicationStatus = 'QUEUED' | 'SENT' | 'FAILED' | 'DELIVERED';

export interface CommunicationLog {
  id: string;
  tenant_id?: string;
  branch_id?: string;
  channel: CommunicationChannel;
  recipient: string;
  recipient_name?: string | null;
  member_id?: string | null;
  family_id?: string | null;
  ministry_id?: string | null;
  subject?: string | null;
  message: string;
  status: CommunicationStatus;
  provider: string;
  provider_message_id?: string | null;
  error_message?: string | null;
  trigger_type?: string | null;
  sent_at?: string | null;
  delivered_at?: string | null;
  created_at: string;
  created_by?: string | null;
  created_by_name?: string | null;
}

export interface CommunicationLogsSummary {
  total: number;
  smsCount: number;
  emailCount: number;
  sentCount: number;
  deliveredCount: number;
  failedCount: number;
  queuedCount: number;
  deliverySuccessRate: number;
}

export interface CommunicationSystemStatus {
  sms: {
    provider: string;
    senderId: string;
    configured: boolean;
    endpointConfigured: boolean;
  };
  email: {
    provider: string;
    fromAddress: string;
    configured: boolean;
    smtpConfigured: boolean;
    apiConfigured: boolean;
  };
}

// ==============================================================================
// REGISTRATION INVITATION & PUBLIC LINK SYSTEM TYPES
// ==============================================================================
export type RegistrationInvitationStatus = 'active' | 'expired' | 'revoked' | 'used';
export type RegistrationExpirationPreset = '24h' | '7d' | '30d' | 'custom' | 'never';

export interface RegistrationInvitationUsageItem {
  id: string;
  applicantName: string;
  applicantEmail?: string;
  applicantPhone?: string;
  memberIdNumber: string;
  applicationReference: string;
  submittedAt: string;
  ipAddress?: string;
}

export interface RegistrationInvitationRecord {
  id: string;
  token: string;
  title: string;
  description?: string;
  tenantId: string;
  churchName: string;
  branchId: string; // 'all' or specific branch ID
  branchName: string;
  ministryId?: string;
  ministryName?: string;
  defaultRole: UserRole;
  requiresApproval: boolean;
  singleUse: boolean;
  maxUses: number | null; // null = unlimited
  usesCount: number;
  expirationPreset: RegistrationExpirationPreset;
  expiresAt: string | null; // ISO timestamp or null for never
  status: RegistrationInvitationStatus;
  createdBy: string;
  createdByName: string;
  createdByEmail: string;
  createdByRole: UserRole;
  createdAt: string;
  updatedAt: string;
  revokedAt?: string | null;
  revokedBy?: string | null;
  revokedReason?: string | null;
  lastUsedAt?: string | null;
  usageHistory?: RegistrationInvitationUsageItem[];
}






