import { prisma } from '../prisma';
import { db } from '../../server/db';
import { WorkflowRequest, UserRole } from '../types';
import { socketService } from './socketService';

export class ApprovalService {
  public async getQueue(status?: string, branchId?: string) {
    let list = await prisma.workflow.findMany({ where: { status, branchId } });
    return list;
  }

  public async submitRequest(request: WorkflowRequest) {
    const created = await prisma.workflow.create({
      data: {
        ...request,
        id: request.id || `wf-${Date.now()}`,
        requestCode: request.requestCode || `REQ-${Date.now().toString().substring(7)}`,
        status: 'Pending',
        submittedDate: request.submittedDate || new Date().toISOString(),
      },
    });

    // Notify connected administrators via WebSocket
    socketService.broadcastPendingApproval(created);

    await prisma.auditLog.create({
      data: {
        userEmail: request.requesterEmail || 'member@grace.org',
        userRole: 'Regular Member' as UserRole,
        action: 'Workflow Approval Submitted',
        module: 'Approvals Queue',
        details: `Submitted ${request.requestType} for ${request.requesterName}`,
      },
    });

    return created;
  }

  public async approveRequest(id: string, approverEmail: string = 'admin@gracecathedral.org', comment?: string) {
    const updated = await prisma.workflow.update({
      where: { id },
      data: {
        status: 'Approved',
        approvedAt: new Date().toISOString(),
        approvedBy: approverEmail,
        comments: comment,
      },
    });

    // Broadcast status change
    socketService.broadcastApprovalStatusChanged(updated);

    await prisma.auditLog.create({
      data: {
        userEmail: approverEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Workflow Request Approved',
        module: 'Approvals Queue',
        details: `Approved ${updated.requestType} (${updated.requestCode}) with comment: ${comment || 'Approved'}`,
      },
    });

    return updated;
  }

  public async rejectRequest(id: string, approverEmail: string = 'admin@gracecathedral.org', reason: string) {
    const updated = await prisma.workflow.update({
      where: { id },
      data: {
        status: 'Rejected',
        approvedAt: new Date().toISOString(),
        approvedBy: approverEmail,
        rejectedReason: reason,
        comments: reason,
      },
    });

    socketService.broadcastApprovalStatusChanged(updated);

    await prisma.auditLog.create({
      data: {
        userEmail: approverEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Workflow Request Rejected',
        module: 'Approvals Queue',
        details: `Rejected ${updated.requestType} (${updated.requestCode}). Reason: ${reason}`,
      },
    });

    return updated;
  }
}

export const approvalService = new ApprovalService();
