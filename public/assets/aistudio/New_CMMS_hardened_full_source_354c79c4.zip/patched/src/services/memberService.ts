import { prisma } from '../prisma';
import { db } from '../../server/db';
import { Member, Family, UserRole } from '../types';

export class MemberService {
  public async getMembers(filters?: { branchId?: string; search?: string; membershipStatus?: string }) {
    return prisma.member.findMany({ where: filters });
  }

  public async getMemberById(id: string) {
    const member = await prisma.member.findUnique({ where: { id } });
    if (!member) {
      throw new Error(`Member with ID ${id} not found`);
    }
    return member;
  }

  public async createMember(data: Member, operatorEmail: string = 'admin@gracecathedral.org') {
    if (!data.firstName || !data.lastName || !data.primaryPhone) {
      throw new Error('First name, last name, and primary phone are mandatory');
    }

    const member = await prisma.member.create({ data });

    await prisma.auditLog.create({
      data: {
        userEmail: operatorEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Member Registered',
        module: 'Members',
        details: `Registered ${member.firstName} ${member.lastName} (${member.memberIdNumber}) to branch ${member.branchId}`,
      },
    });

    return member;
  }

  public async updateMember(id: string, data: Partial<Member>, operatorEmail: string = 'admin@gracecathedral.org') {
    const updated = await prisma.member.update({ where: { id }, data });

    await prisma.auditLog.create({
      data: {
        userEmail: operatorEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Member Profile Updated',
        module: 'Members',
        details: `Updated demographic details for ${updated.firstName} ${updated.lastName}`,
      },
    });

    return updated;
  }

  public async deleteMember(id: string, operatorEmail: string = 'admin@gracecathedral.org') {
    const deleted = await prisma.member.delete({ where: { id } });

    await prisma.auditLog.create({
      data: {
        userEmail: operatorEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Member Record Deleted',
        module: 'Members',
        details: `Deleted member record ${deleted.firstName} ${deleted.lastName} (${deleted.id})`,
      },
    });

    return deleted;
  }

  public async updateProfilePhoto(id: string, photoUrlOrBase64: string) {
    const member = await prisma.member.findUnique({ where: { id } });
    if (!member) {
      throw new Error(`Member with ID ${id} not found`);
    }

    const updated = await prisma.member.update({
      where: { id },
      data: { photoUrl: photoUrlOrBase64 },
    });

    return { success: true, photoUrl: updated.photoUrl, memberId: id };
  }

  public async bulkImport(members: Member[], operatorEmail: string = 'admin@gracecathedral.org') {
    const result = await prisma.member.createMany({ data: members });

    await prisma.auditLog.create({
      data: {
        userEmail: operatorEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Bulk Member Import',
        module: 'Members',
        details: `Imported ${result.count} member records across campuses`,
      },
    });

    return result;
  }

  // Families
  public async getFamilies(branchId?: string) {
    let list = [...db.getState().families];
    if (branchId && branchId !== 'all') {
      list = list.filter((f) => (f as any).branchId === branchId);
    }
    return list;
  }

  public async createFamily(family: Family) {
    db.getState().families.unshift(family);
    db.persist();
    return family;
  }

  public async updateFamily(id: string, data: Partial<Family>) {
    const fam = db.getState().families.find((f) => f.id === id);
    if (!fam) throw new Error(`Family with ID ${id} not found`);
    Object.assign(fam, data);
    db.persist();
    return fam;
  }
}

export const memberService = new MemberService();
