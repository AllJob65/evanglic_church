import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { WorkflowRequest } from '../types';

export const supabaseWorkflowService = {
  async getWorkflows(params?: { status?: string; branchId?: string }): Promise<WorkflowRequest[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('workflow_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (params?.status && params.status !== 'all') {
      query = query.eq('status', params.status);
    }
    if (params?.branchId && params.branchId !== 'all') {
      query = query.eq('branch_id', params.branchId);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getWorkflows notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      requestCode: row.request_code || `REQ-${row.id.substring(0, 5)}`,
      requestType: row.request_type as any,
      requesterName: row.requester_name || 'Staff Requester',
      requesterPhone: row.requester_phone,
      requesterEmail: row.requester_email,
      branchName: row.branch_name || 'Headquarters Campus',
      branchId: row.branch_id,
      details: row.details || '',
      amountRequested: row.amount_requested ? Number(row.amount_requested) : undefined,
      currentStep: row.current_step || 'Review Pending',
      assignedApproverRole: (row.assigned_role || 'BRANCH_PASTOR') as any,
      submittedDate: row.created_at?.substring(0, 10) || new Date().toISOString().substring(0, 10),
      status: (row.status || 'Pending') as any,
      comments: row.comments,
      approvedBy: row.approved_by,
      approvedAt: row.approved_at,
      rejectedReason: row.rejected_reason,
      decisionNotes: row.decision_notes,
    } as WorkflowRequest));
  },

  async createWorkflow(req: Partial<WorkflowRequest>, tenantId?: string): Promise<WorkflowRequest> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: req.branchId || 'br-1',
      request_code: req.requestCode || `REQ-${Math.floor(10000 + Math.random() * 90000)}`,
      request_type: req.requestType || 'Membership Application',
      requester_name: req.requesterName || 'Applicant',
      requester_phone: req.requesterPhone || '',
      requester_email: req.requesterEmail || '',
      branch_name: req.branchName || 'Headquarters Campus',
      details: req.details || '',
      amount_requested: req.amountRequested || null,
      current_step: req.currentStep || 'Submitted for Review',
      assigned_role: req.assignedApproverRole || 'BRANCH_PASTOR',
      status: req.status || 'Pending',
    };

    const { data, error } = await supabase
      .from('workflow_requests')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      requestCode: data.request_code,
      requestType: data.request_type as any,
      requesterName: data.requester_name,
      requesterPhone: data.requester_phone,
      requesterEmail: data.requester_email,
      branchName: data.branch_name,
      branchId: data.branch_id,
      details: data.details,
      amountRequested: data.amount_requested ? Number(data.amount_requested) : undefined,
      currentStep: data.current_step,
      assignedApproverRole: data.assigned_role as any,
      submittedDate: data.created_at.substring(0, 10),
      status: data.status as any,
    };
  },

  async approveWorkflow(id: string, approverName: string, comment?: string): Promise<WorkflowRequest> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const { data, error } = await supabase
      .from('workflow_requests')
      .update({
        status: 'Approved',
        approved_by: approverName,
        approved_at: new Date().toISOString(),
        comments: comment || 'Approved by authorized officer',
        current_step: 'Completed & Archived',
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      requestCode: data.request_code,
      requestType: data.request_type as any,
      requesterName: data.requester_name,
      branchName: data.branch_name,
      details: data.details,
      amountRequested: data.amount_requested ? Number(data.amount_requested) : undefined,
      currentStep: data.current_step,
      assignedApproverRole: data.assigned_role as any,
      submittedDate: data.created_at.substring(0, 10),
      status: 'Approved',
      comments: data.comments,
      approvedBy: data.approved_by,
      approvedAt: data.approved_at,
    };
  },

  async rejectWorkflow(id: string, reason: string): Promise<WorkflowRequest> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const { data, error } = await supabase
      .from('workflow_requests')
      .update({
        status: 'Rejected',
        rejected_reason: reason,
        decision_notes: reason,
        current_step: 'Rejected',
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      requestCode: data.request_code,
      requestType: data.request_type as any,
      requesterName: data.requester_name,
      branchName: data.branch_name,
      details: data.details,
      amountRequested: data.amount_requested ? Number(data.amount_requested) : undefined,
      currentStep: data.current_step,
      assignedApproverRole: data.assigned_role as any,
      submittedDate: data.created_at.substring(0, 10),
      status: 'Rejected',
      rejectedReason: data.rejected_reason,
    };
  },
};
