import { prisma } from '../prisma';
import { db } from '../../server/db';
import { PrayerRequest, CounselingSession, VisitationRecord, UserRole } from '../types';
import { checkPastoralConfidentiality } from '../middleware/rbacMiddleware';

export class PastoralService {
  public async getNotes(
    filters?: { branchId?: string; memberId?: string },
    userRole: UserRole = 'REGULAR_MEMBER',
    userId?: string
  ) {
    const notes = await prisma.pastoralNote.findMany({ where: filters });
    // Filter confidential notes based on role and counselor assignment
    return notes.filter((n: any) =>
      checkPastoralConfidentiality(n.confidentiality || 'MINISTERIAL', userRole, n.pastorUserId, userId)
    );
  }

  public async createNote(data: any, pastorEmail: string = 'pastor@gracecathedral.org') {
    const created = await prisma.pastoralNote.create({ data });

    await prisma.auditLog.create({
      data: {
        userEmail: pastorEmail,
        userRole: 'Pastor' as UserRole,
        action: 'Pastoral Counseling Note Created',
        module: 'Pastoral Care',
        details: `Recorded note for member ID ${data.memberId} with confidentiality [${data.confidentiality || 'Confidential'}]`,
      },
    });

    return created;
  }

  // Prayer Requests
  public async getPrayerRequests(branchId?: string, isPublicOnly: boolean = false) {
    let list = [...db.getState().prayerRequests];
    if (branchId && branchId !== 'all') {
      list = list.filter((p: any) => p.branchId === branchId || !p.branchId);
    }
    if (isPublicOnly) {
      list = list.filter((p) => !p.isConfidential || p.confidentialityLevel === 'Public');
    }
    return list;
  }

  public async createPrayerRequest(req: Partial<PrayerRequest>) {
    const newReq: PrayerRequest = {
      id: req.id || `pray-${Date.now()}`,
      requestNumber: req.requestNumber || `REQ-${Date.now().toString(36).toUpperCase()}`,
      memberId: req.memberId || '',
      memberName: req.memberName || req.requesterName || 'Member',
      requesterName: req.requesterName || req.memberName,
      category: req.category || 'Spiritual Concern',
      title: req.title || 'Prayer Request',
      description: req.description || req.details || '',
      isConfidential: Boolean(req.isConfidential),
      confidentialityLevel: req.confidentialityLevel || (req.isConfidential ? 'Confidential' : 'Public'),
      urgency: req.urgency || 'Medium',
      status: req.status || 'Pending',
      submittedDate: req.submittedDate || new Date().toISOString(),
      testimonyNotes: req.testimonyNotes || '',
    };
    db.getState().prayerRequests.unshift(newReq);
    db.persist();
    return newReq;
  }

  public async updatePrayerStatus(id: string, status: string, notes?: string) {
    const req = db.getState().prayerRequests.find((p) => p.id === id);
    if (!req) throw new Error(`Prayer request with ID ${id} not found`);
    req.status = status as any;
    if (notes) {
      req.testimonyNotes = `${req.testimonyNotes || ''}\n[Update ${new Date().toLocaleDateString()}]: ${notes}`;
    }
    db.persist();
    return req;
  }

  // Counseling Sessions with Strict Pastoral Confidentiality
  public async getCounselingSessions(
    branchId?: string,
    userRole: UserRole = 'REGULAR_MEMBER',
    userId?: string
  ) {
    let list = [...db.getState().counselingSessions];
    if (branchId && branchId !== 'all') {
      list = list.filter((s: any) => s.branchId === branchId || !s.branchId);
    }

    // Confidentiality Check:
    // Non-pastors cannot view sensitive counseling session details unless they are the client
    if (userRole !== 'PASTOR' && userRole !== 'SYSTEM_ADMIN') {
      list = list.filter((s: any) => s.clientMemberId === userId || s.counselorName === userId);
    }

    return list;
  }

  public async createCounselingSession(session: Partial<CounselingSession>, operatorEmail: string = 'pastor@gracecathedral.org') {
    const newSession: CounselingSession = {
      id: session.id || `cs-${Date.now()}`,
      sessionCode: session.sessionCode || `CS-${Date.now().toString(36).toUpperCase()}`,
      clientMemberId: session.clientMemberId || '',
      clientName: session.clientName || 'Client Member',
      counselorName: session.counselorName || 'Pastor',
      counselingType: session.counselingType || 'Individual',
      sessionDate: session.sessionDate || new Date().toISOString().split('T')[0],
      sessionTime: session.sessionTime || '10:00 AM',
      mode: session.mode || 'In-Person',
      status: session.status || 'Scheduled',
      encryptedCaseNotes: session.encryptedCaseNotes || (session as any).notes || '',
    };
    db.getState().counselingSessions.unshift(newSession);
    db.persist();

    db.addAuditLog(
      'Counseling Session Scheduled',
      'Pastoral Care',
      `Scheduled counseling session for ${newSession.clientName} (${newSession.counselingType})`,
      operatorEmail
    );

    return newSession;
  }

  public async updateCounselingStatus(id: string, status: string, notes?: string, operatorEmail: string = 'pastor@gracecathedral.org') {
    const session = db.getState().counselingSessions.find((s) => s.id === id);
    if (!session) throw new Error(`Counseling session ${id} not found`);
    session.status = status as any;
    if (notes) session.encryptedCaseNotes = `${session.encryptedCaseNotes || ''}\n[Resolution Notes]: ${notes}`;
    db.persist();

    db.addAuditLog(
      'Counseling Session Updated',
      'Pastoral Care',
      `Updated session ${id} to status ${status}`,
      operatorEmail
    );

    return session;
  }

  // Visitation Care
  public async getVisitations(branchId?: string) {
    let list = [...db.getState().visitations];
    if (branchId && branchId !== 'all') {
      list = list.filter((v: any) => v.branchId === branchId || !v.branchId);
    }
    return list;
  }

  public async createVisitation(visitation: Partial<VisitationRecord>, operatorEmail: string = 'pastor@gracecathedral.org') {
    const newV: VisitationRecord = {
      id: visitation.id || `vis-${Date.now()}`,
      visitationCode: visitation.visitationCode || `VIS-${Date.now().toString(36).toUpperCase()}`,
      memberId: visitation.memberId || '',
      memberName: visitation.memberName || 'Member',
      visitorNames: visitation.visitorNames || ['Pastor'],
      visitationType: visitation.visitationType || 'Home Care',
      visitDate: visitation.visitDate || new Date().toISOString().split('T')[0],
      location: visitation.location || 'Member Residence',
      summaryNotes: visitation.summaryNotes || '',
      prayerPoints: visitation.prayerPoints || [],
      followUpRequired: Boolean(visitation.followUpRequired),
      status: visitation.status || 'Completed',
    };
    db.getState().visitations.unshift(newV);
    db.persist();

    db.addAuditLog(
      'Visitation Record Logged',
      'Pastoral Care',
      `Logged ${newV.visitationType} for ${newV.memberName}`,
      operatorEmail
    );

    return newV;
  }
}

export const pastoralService = new PastoralService();
