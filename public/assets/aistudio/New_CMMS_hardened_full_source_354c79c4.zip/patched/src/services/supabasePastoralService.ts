import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { PrayerRequest, CounselingSession } from '../types';

export const supabasePastoralService = {
  async getPrayerRequests(branchId?: string): Promise<PrayerRequest[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('pastoral_records')
      .select('*')
      .eq('category', 'Prayer Request')
      .order('created_at', { ascending: false });

    if (branchId && branchId !== 'all') {
      query = query.eq('branch_id', branchId);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase prayer requests notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      requestNumber: `PR-${row.id.substring(0, 5)}`,
      memberId: row.member_id || 'mem-1',
      memberName: row.summary?.split(' - ')[0] || 'Church Member',
      requesterName: row.summary?.split(' - ')[0] || 'Church Member',
      category: 'Spiritual Concern',
      title: row.summary || 'Prayer Support Request',
      description: row.details || '',
      isConfidential: row.confidentiality === 'CONFIDENTIAL',
      urgency: 'Medium',
      status: (row.status === 'Answered' ? 'Answered' : row.status === 'In Prayer' ? 'Praying' : 'Pending') as any,
      submittedDate: row.created_at?.substring(0, 10) || new Date().toISOString().substring(0, 10),
    } as PrayerRequest));
  },

  async createPrayerRequest(req: Partial<PrayerRequest>, tenantId?: string): Promise<PrayerRequest> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: 'br-1',
      category: 'Prayer Request',
      confidentiality: req.isConfidential ? 'CONFIDENTIAL' : 'PUBLIC',
      summary: `${req.memberName || req.requesterName || 'Member'} - ${req.title || 'General Prayer'}`,
      details: req.description || '',
      status: req.status || 'Pending',
    };

    const { data, error } = await supabase
      .from('pastoral_records')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      requestNumber: `PR-${data.id.substring(0, 5)}`,
      memberId: req.memberId || 'mem-1',
      memberName: req.memberName || 'Member',
      requesterName: req.requesterName || 'Member',
      category: req.category || 'Spiritual Concern',
      title: req.title || 'Prayer Request',
      description: data.details,
      isConfidential: data.confidentiality === 'CONFIDENTIAL',
      urgency: req.urgency || 'Medium',
      status: (data.status === 'Answered' ? 'Answered' : 'Pending') as any,
      submittedDate: data.created_at.substring(0, 10),
    };
  },

  async getCounselingSessions(branchId?: string): Promise<CounselingSession[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('pastoral_records')
      .select('*')
      .eq('category', 'Counseling')
      .order('created_at', { ascending: false });

    if (branchId && branchId !== 'all') {
      query = query.eq('branch_id', branchId);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase counseling sessions notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      sessionCode: `CS-${row.id.substring(0, 5)}`,
      clientMemberId: row.member_id || 'mem-1',
      clientName: row.summary?.split(' - ')[0] || 'Member',
      counselorName: 'Pastor John Miller',
      counselingType: 'Individual',
      sessionDate: row.created_at?.substring(0, 10) || new Date().toISOString().substring(0, 10),
      sessionTime: '02:00 PM',
      mode: 'In-Person',
      status: (row.status === 'Completed' ? 'Completed' : 'Scheduled') as any,
      encryptedCaseNotes: row.details || '',
    } as CounselingSession));
  },

  async createCounselingSession(session: Partial<CounselingSession>, tenantId?: string): Promise<CounselingSession> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: 'br-1',
      member_id: session.clientMemberId || null,
      category: 'Counseling',
      confidentiality: 'CONFIDENTIAL',
      summary: `${session.clientName || 'Member'} - ${session.counselingType || 'Counseling'}`,
      details: session.encryptedCaseNotes || '',
      status: session.status || 'Scheduled',
    };

    const { data, error } = await supabase
      .from('pastoral_records')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      sessionCode: `CS-${data.id.substring(0, 5)}`,
      clientMemberId: session.clientMemberId || 'mem-1',
      clientName: session.clientName || 'Member',
      counselorName: session.counselorName || 'Pastor John Miller',
      counselingType: session.counselingType || 'Individual',
      sessionDate: data.created_at.substring(0, 10),
      sessionTime: session.sessionTime || '02:00 PM',
      mode: session.mode || 'In-Person',
      status: data.status as any,
      encryptedCaseNotes: data.details,
    };
  },
};
