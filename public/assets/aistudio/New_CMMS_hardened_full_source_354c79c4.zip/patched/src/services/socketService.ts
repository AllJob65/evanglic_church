import { Server as SocketIOServer, Socket } from 'socket.io';
import { Server as HTTPServer } from 'http';
import { z } from 'zod';
import { AttendanceRecord, WorkflowRequest, UserRole } from '../types';
import { resolveTrustedUserSession, AuthenticatedUserPayload, hasPermission } from '../security/authorization';
import { isOriginAllowed } from '../../server/middleware/httpSecurity';
import { db } from '../../server/db';
import { canHostLiveBroadcast } from '../utils/rbac';
import {
  isMemberOfGroup,
  isLeaderOfGroup,
  isMemberOfMinistry,
  logPermissionDenied,
  extractMinistryOrGroupIdFromVideoRoom,
} from '../../server/services/membershipService';
import {
  isActiveParticipant,
  resolveUserRole,
  isDirectChatAllowed,
  validateDirectConversationTierAndScope,
} from '../../server/services/conversationService';
import { ConversationMessage, Conversation } from '../types';

// Real-time Event Validation Schemas
const joinGroupChannelSchema = z.object({
  groupId: z.string().trim().min(1).max(100),
});

const startChatSchema = z.object({
  groupId: z.string().trim().min(1).max(100),
});

const startVideoSchema = z.object({
  groupId: z.string().trim().min(1).max(100),
  title: z.string().trim().min(1).max(200),
  roomUrl: z.string().trim().max(500).optional(),
});

const joinMinistryChatSchema = z.object({
  ministryId: z.string().trim().min(1).max(100),
});

const chatTypingSchema = z.object({
  ministryId: z.string().trim().min(1).max(100),
  isTyping: z.boolean(),
});

const videoRoomSchema = z.object({
  roomId: z.string().trim().min(1).max(100),
  ministryId: z.string().trim().max(100).optional(),
});

const videoActionSchema = z.object({
  roomId: z.string().trim().min(1).max(100),
  isMuted: z.boolean().optional(),
  isVideoOff: z.boolean().optional(),
  isRaised: z.boolean().optional(),
  isScreenSharing: z.boolean().optional(),
});

const privateMessageSchema = z.object({
  recipientUserId: z.string().trim().min(1).max(100),
  message: z.string().trim().min(1).max(2000),
});

const conversationJoinSchema = z.object({
  conversationId: z.string().trim().min(1).max(100),
});

const conversationMessageSchema = z.object({
  conversationId: z.string().trim().min(1).max(100),
  body: z.string().trim().min(1).max(4000),
});

const conversationLeaveSchema = z.object({
  conversationId: z.string().trim().min(1).max(100),
});

const directVideoCallSchema = z.object({
  conversationId: z.string().trim().min(1).max(100),
  recipientUserId: z.string().trim().min(1).max(100).optional(),
});

const directVideoRespondSchema = z.object({
  conversationId: z.string().trim().min(1).max(100),
  reason: z.string().trim().max(200).optional(),
});

// In-memory sliding-window rate limit trackers
const ipConnectionTracker = new Map<string, { count: number; resetTime: number }>();
const socketMessageTracker = new Map<string, { count: number; resetTime: number }>();

export class SocketService {
  private io: SocketIOServer | null = null;
  private connectedClients: Map<string, { socketId: string; user?: AuthenticatedUserPayload }> = new Map();

  public init(httpServer: HTTPServer) {
    this.io = new SocketIOServer(httpServer, {
      cors: {
        origin: (origin, callback) => {
          if (isOriginAllowed(origin)) {
            callback(null, true);
          } else {
            console.warn(`[Socket.io CORS] Rejected unauthorized origin: ${origin}`);
            callback(new Error('CORS origin unauthorized for WebSocket'));
          }
        },
        credentials: true,
        methods: ['GET', 'POST'],
      },
      path: '/socket.io',
      allowEIO3: false,
      maxHttpBufferSize: 1e6, // 1MB payload limit
    });

    // 1. Connection Rate Limiting Middleware (30 handshakes / min per IP)
    this.io.use((socket: Socket, next) => {
      const clientIp = socket.handshake.address || 'unknown';
      const now = Date.now();
      const tracker = ipConnectionTracker.get(clientIp) || { count: 0, resetTime: now + 60000 };

      if (now > tracker.resetTime) {
        tracker.count = 1;
        tracker.resetTime = now + 60000;
      } else {
        tracker.count++;
      }
      ipConnectionTracker.set(clientIp, tracker);

      if (tracker.count > 30) {
        console.warn(`[Socket.io Security] Connection rate limit exceeded for IP ${clientIp}`);
        return next(new Error('RATE_LIMIT_EXCEEDED: Too many connection attempts.'));
      }

      next();
    });

    // 2. Authoritative Supabase Token Verification & Identity Resolution Middleware
    this.io.use(async (socket: Socket, next) => {
      try {
        const rawToken =
          socket.handshake.auth?.token ||
          socket.handshake.headers?.authorization?.replace(/^Bearer\s+/i, '');

        if (!rawToken) {
          // Allow connection as guest if no token, but lock down all rooms
          socket.data.isGuest = true;
          socket.data.user = null;
          return next();
        }

        // Authoritatively verify token and load trusted profile server-side
        const trustedUser = await resolveTrustedUserSession(rawToken);
        socket.data.isGuest = false;
        socket.data.user = trustedUser;

        return next();
      } catch (err: any) {
        console.warn(`[Socket.io Auth] Token verification rejected: ${err.message}`);
        // Allow socket as guest instead of hard-failing initial connect, but protect all rooms
        socket.data.isGuest = true;
        socket.data.user = null;
        return next();
      }
    });

    // 3. Socket Connection Lifecycle & Authoritative Room Assignment
    this.io.on('connection', (socket: Socket) => {
      const getUser = (): AuthenticatedUserPayload | null => socket.data.user || null;
      const getIsGuest = (): boolean => Boolean(socket.data.isGuest || !socket.data.user);

      const initialUser = getUser();
      const initialGuest = getIsGuest();

      this.connectedClients.set(socket.id, {
        socketId: socket.id,
        user: initialUser || undefined,
      });

      // 3A. Server-side authoritative room provisioning
      if (!initialGuest && initialUser) {
        console.log(`[Socket.io] Authenticated connection: ${initialUser.email} (Role: ${initialUser.role}, Tenant: ${initialUser.tenantId})`);

        // Join tenant room
        socket.join(`tenant:${initialUser.tenantId}`);

        // Join authorized branch rooms
        for (const bId of initialUser.branchIds) {
          socket.join(`branch:${bId}`);
        }

        // Join personal private notification room
        socket.join(`user:${initialUser.id}`);

        // Join role-specific broadcast room
        socket.join(`role:${initialUser.role}`);

        // Join approvals queue ONLY if user holds approval/workflow permissions
        if (hasPermission(initialUser.role, 'workflows.manage') || hasPermission(initialUser.role, 'workflows.read')) {
          socket.join('approvals-queue');
        }

        // Join attendance feed ONLY if user holds attendance read or update permissions
        if (hasPermission(initialUser.role, 'attendance.update') || hasPermission(initialUser.role, 'attendance.read')) {
          socket.join('attendance-feed');
        }

        socket.emit('authenticated', {
          userId: initialUser.id,
          tenantId: initialUser.tenantId,
          role: initialUser.role,
          authorizedBranches: initialUser.branchIds,
        });
      } else {
        console.log(`[Socket.io] Guest connection: ${socket.id} (Restricted access)`);
        socket.join('public:announcements');
      }

      // 3B. Message Rate Limiting Helper (60 messages / min per socket)
      const checkMessageRateLimit = (): boolean => {
        const now = Date.now();
        const tracker = socketMessageTracker.get(socket.id) || { count: 0, resetTime: now + 60000 };
        if (now > tracker.resetTime) {
          tracker.count = 1;
          tracker.resetTime = now + 60000;
        } else {
          tracker.count++;
        }
        socketMessageTracker.set(socket.id, tracker);

        if (tracker.count > 60) {
          socket.emit('error', {
            code: 'RATE_LIMIT_EXCEEDED',
            message: 'Message rate limit exceeded. Please slow down.',
          });
          return false;
        }
        return true;
      };

      // 3C. Explicit Room Join Requests (Zero-Trust Validation)
      socket.on('join', (data: { tenantId?: string; branchId?: string; requestedBranchId?: string }) => {
        if (!checkMessageRateLimit()) return;

        const user = getUser();
        const isGuest = getIsGuest();

        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required to join church rooms.' });
          return;
        }

        // Detect and reject client attempts to spoof tenantId
        if (data.tenantId && data.tenantId !== user.tenantId) {
          console.warn(`[Security Alert] Socket ${socket.id} attempted cross-tenant join: claimed="${data.tenantId}", actual="${user.tenantId}"`);
          db.addAuditLog(
            'Cross-Tenant Access Attempt Blocked',
            'Realtime Security',
            `User ${user.email} attempted unauthorized join to tenant "${data.tenantId}"`,
            user.email
          );
          socket.emit('error', { code: 'FORBIDDEN_TENANT', message: 'Cross-tenant access prohibited.' });
          return;
        }

        // Validate branch access
        const targetBranch = data.requestedBranchId || data.branchId || user.branchId;
        const hasBranchAccess = user.branchIds.includes('*') || user.branchIds.includes(targetBranch);

        if (!hasBranchAccess) {
          console.warn(`[Security Alert] Socket ${socket.id} attempted unauthorized branch join: target="${targetBranch}"`);
          socket.emit('error', { code: 'FORBIDDEN_BRANCH', message: 'Access denied for requested branch.' });
          return;
        }

        socket.join(`branch:${targetBranch}`);
        socket.emit('joined', {
          status: 'ok',
          socketId: socket.id,
          rooms: Array.from(socket.rooms),
        });
      });

      // 3D. Group / Ministry Channel Join with Schema Validation & Membership Check
      socket.on('join_group_channel', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = joinGroupChannelSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Malformed group channel request.' });
          return;
        }

        const { groupId } = parseResult.data;

        // Verify group / ministry membership (SYSTEM_ADMIN, MANAGER, PASTOR can oversee any group)
        const isMember = await isMemberOfGroup(user.id, groupId, user.role, user.email);
        if (!isMember) {
          console.warn(`[Security Alert] Socket ${socket.id} (user: ${user.email}, role: ${user.role}) denied join to group "${groupId}"`);
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'join_group_channel',
            targetType: 'group',
            targetId: groupId,
            reason: 'User is not an active member of this group/fellowship.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_GROUP',
            message: 'Access denied: You are not an enrolled member of this fellowship group.',
            groupId,
          });
          return;
        }

        // Tenant-scoped room key prevents cross-tenant sniffing
        const roomName = `group:${user.tenantId}:${groupId}`;
        socket.join(roomName);
      });

      // 3E. Privileged Action: Leader Start Live Chat
      socket.on('leader_start_chat', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        // Verify leader role
        const allowedRoles: UserRole[] = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'];
        if (!allowedRoles.includes(user.role)) {
          socket.emit('error', { code: 'FORBIDDEN', message: 'Only ministry leaders and pastors can initiate chat.' });
          return;
        }

        const parseResult = startChatSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Invalid start chat parameters.' });
          return;
        }

        const { groupId } = parseResult.data;

        // Verify user is assigned leader of this specific group or administrative supervisor
        const isLeader = await isLeaderOfGroup(user.id, groupId, user.role, user.email);
        if (!isLeader) {
          console.warn(`[Security Alert] Socket ${socket.id} (user: ${user.email}) denied leader_start_chat for group "${groupId}"`);
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'leader_start_chat',
            targetType: 'group',
            targetId: groupId,
            reason: 'User is not the assigned leader or administrator of this group.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_LEADER',
            message: 'Access denied: You are not the assigned leader for this group.',
            groupId,
          });
          return;
        }

        const roomName = `group:${user.tenantId}:${groupId}`;
        const sessionId = `chat-session-${groupId}-${Date.now()}`;

        // Persist to database state
        const dbState = db.getState();
        if (!dbState.groupChatSessions) {
          dbState.groupChatSessions = [];
        }
        dbState.groupChatSessions.push({
          id: sessionId,
          groupId,
          leaderId: user.id,
          isActive: true,
          startedAt: new Date().toISOString(),
        });
        db.save();

        db.addAuditLog(
          'Start Realtime Chat Session',
          'Ministry Collaboration',
          `Leader ${user.name} initiated live chat session for group "${groupId}"`,
          user.email
        );

        this.io?.to(roomName).emit('chat_session_started', {
          sessionId,
          groupId,
          leaderId: user.id,
          leaderName: user.name,
          isActive: true,
          startedAt: new Date().toISOString(),
        });
        this.io?.to(`group_${groupId}`).emit('chat_session_started', {
          sessionId,
          groupId,
          leaderId: user.id,
          leaderName: user.name,
          isActive: true,
          startedAt: new Date().toISOString(),
        });
      });

      // 3F. Privileged Action: Leader Start Video Conference
      socket.on('leader_start_video', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        if (!canHostLiveBroadcast(user.role)) {
          socket.emit('error', { code: 'FORBIDDEN', message: 'Broadcasting privileges required.' });
          return;
        }

        const parseResult = startVideoSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Invalid video parameters.' });
          return;
        }

        const { groupId, title, roomUrl } = parseResult.data;

        // Verify user is assigned leader of this specific group or supervisor
        const isLeader = await isLeaderOfGroup(user.id, groupId, user.role, user.email);
        if (!isLeader) {
          console.warn(`[Security Alert] Socket ${socket.id} (user: ${user.email}) denied leader_start_video for group "${groupId}"`);
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'leader_start_video',
            targetType: 'group',
            targetId: groupId,
            reason: 'User is not the assigned leader or administrator of this video group.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_LEADER',
            message: 'Access denied: You are not the assigned leader for this video conference.',
            groupId,
          });
          return;
        }

        const conferenceId = `conf-${groupId}-${Date.now()}`;
        const roomName = `group:${user.tenantId}:${groupId}`;

        db.addAuditLog(
          'Start Video Conference',
          'Live Broadcast',
          `Leader ${user.name} initiated video conference "${title}" (Group: ${groupId})`,
          user.email
        );

        this.io?.to(roomName).emit('video_conference_started', {
          id: conferenceId,
          groupId,
          leaderId: user.id,
          leaderName: user.name,
          title,
          roomUrl: roomUrl || '',
          status: 'active',
          createdAt: new Date().toISOString(),
        });
      });

      // 3G. Ministry Live Chat Subscription (Tenant Scoped & Membership Enforced)
      socket.on('chat:join_ministry', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = joinMinistryChatSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Invalid ministry ID.' });
          return;
        }

        const { ministryId } = parseResult.data;

        // Verify ministry membership before joining or broadcasting
        const isMember = await isMemberOfMinistry(user.id, ministryId, user.role, user.email);
        if (!isMember) {
          console.warn(`[Security Alert] Socket ${socket.id} (user: ${user.email}, role: ${user.role}) denied join to ministry "${ministryId}"`);
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'chat:join_ministry',
            targetType: 'ministry',
            targetId: ministryId,
            reason: 'User is not an active member of this ministry.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_MINISTRY',
            message: 'Access denied: You are not an enrolled member of this ministry.',
            ministryId,
          });
          return;
        }

        const roomKey = `ministry:${user.tenantId}:${ministryId}`;
        socket.join(roomKey);

        // Broadcast ONLY after verified membership check
        socket.to(roomKey).emit('chat:user_entered', {
          ministryId,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          timestamp: new Date().toISOString(),
        });
      });

      // 3H. Typing Indicator Event
      socket.on('chat:typing', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = chatTypingSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const { ministryId, isTyping } = parseResult.data;

        const isMember = await isMemberOfMinistry(user.id, ministryId, user.role, user.email);
        if (!isMember) return;

        const roomKey = `ministry:${user.tenantId}:${ministryId}`;

        socket.to(roomKey).emit('chat:user_typing', {
          ministryId,
          userId: user.id,
          userName: user.name,
          isTyping,
        });
      });

      // 3I. Video Conference Interaction Events (Tenant Scoped & Membership Enforced)
      socket.on('video:join_room', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = videoRoomSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const { roomId, ministryId } = parseResult.data;
        const targetId = extractMinistryOrGroupIdFromVideoRoom(roomId, ministryId);

        if (targetId) {
          const isMember = await isMemberOfGroup(user.id, targetId, user.role, user.email);
          if (!isMember) {
            console.warn(`[Security Alert] Socket ${socket.id} (user: ${user.email}) denied video room "${roomId}" (target: ${targetId})`);
            logPermissionDenied({
              userId: user.id,
              userEmail: user.email,
              userRole: user.role,
              action: 'video:join_room',
              targetType: 'video_room',
              targetId: roomId,
              reason: `User is not an active member of the hosting ministry/group "${targetId}".`,
              ipAddress: socket.handshake.address,
            });
            socket.emit('error', {
              code: 'FORBIDDEN_ROOM',
              message: 'Access denied: You are not an enrolled member of the ministry/group hosting this video room.',
              roomId,
              targetId,
            });
            return;
          }
        }

        const roomKey = `video:${user.tenantId}:${roomId}`;
        socket.join(roomKey);
        socket.to(roomKey).emit('video:participant_joined', {
          roomId,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
        });
      });

      socket.on('video:leave_room', (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = videoRoomSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const roomKey = `video:${user.tenantId}:${parseResult.data.roomId}`;
        socket.leave(roomKey);
        socket.to(roomKey).emit('video:participant_left', {
          roomId: parseResult.data.roomId,
          userId: user.id,
          userName: user.name,
        });
      });

      socket.on('video:action', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = videoActionSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const targetId = extractMinistryOrGroupIdFromVideoRoom(parseResult.data.roomId);
        if (targetId) {
          const isMember = await isMemberOfGroup(user.id, targetId, user.role, user.email);
          if (!isMember) return;
        }

        const roomKey = `video:${user.tenantId}:${parseResult.data.roomId}`;
        socket.to(roomKey).emit('video:participant_action', {
          ...parseResult.data,
          userId: user.id,
          userName: user.name,
        });
      });

      // 3J. Private Messaging (Strict Tenant Isolation & Staff<->Member Role Rule Enforced)
      socket.on('private:message', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = privateMessageSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Invalid private message.' });
          return;
        }

        const { recipientUserId, message } = parseResult.data;

        // Verify recipient belongs to the exact same tenant
        const systemUsers = db.getState().systemUsers || [];
        const recipient = systemUsers.find((u) => u.id === recipientUserId);

        if (recipient && (recipient as any).tenantId && (recipient as any).tenantId !== user.tenantId) {
          console.warn(`[Security Alert] Blocked cross-tenant private message from ${user.email} to ${recipient.email}`);
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'private:message',
            targetType: 'conversation',
            targetId: recipientUserId,
            reason: 'Cross-tenant private messaging prohibited.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', { code: 'CROSS_TENANT_BLOCKED', message: 'Cross-tenant messaging is prohibited.' });
          return;
        }

        // Resolve both users' roles server-side (not from client payload)
        const senderRole = await resolveUserRole(user.id);
        const recipientRole = await resolveUserRole(recipientUserId);

        const tierCheck = validateDirectConversationTierAndScope(
          user.id,
          senderRole,
          recipientUserId,
          recipientRole
        );

        if (!tierCheck.allowed) {
          console.warn(
            `[Security Alert] Blocked direct message from ${user.email} (${senderRole}) to ${recipientUserId} (${recipientRole}) - ${tierCheck.code}`
          );
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: senderRole,
            action: 'private:message',
            targetType: 'conversation',
            targetId: recipientUserId,
            reason: tierCheck.error || 'Direct messaging prohibited by tier or ministry-scope rule.',
            ipAddress: socket.handshake.address,
          });
          db.addAuditLog(
            'Unauthorized Access Attempt Blocked',
            'Conversations & Messaging',
            tierCheck.details ||
              `Blocked direct message from ${user.email} (${senderRole}) to ${recipientUserId} (${recipientRole}): ${tierCheck.code}`,
            user.email,
            socket.handshake.address
          );
          socket.emit('error', {
            code: tierCheck.code,
            message: tierCheck.error,
          });
          return;
        }

        // Deliver to recipient's private user channel
        this.io?.to(`user:${recipientUserId}`).emit('private:message_received', {
          senderId: user.id,
          senderName: user.name,
          message,
          timestamp: new Date().toISOString(),
        });

        // Persist direct message to conversation_messages
        try {
          const dbState = db.getState();
          const tenantId = user.tenantId || 'tenant-grace-main';
          if (!dbState.conversations) dbState.conversations = [];
          if (!dbState.conversationParticipants) dbState.conversationParticipants = [];
          if (!dbState.conversationMessages) dbState.conversationMessages = [];

          let directConv = dbState.conversations.find((c) => {
            if (c.type !== 'direct' || c.tenantId !== tenantId || c.status !== 'active') return false;
            const parts = dbState.conversationParticipants!.filter(
              (p) => p.conversationId === c.id && !p.leftAt
            );
            const userIds = parts.map((p) => p.userId);
            return userIds.includes(user.id) && userIds.includes(recipientUserId);
          });

          const now = new Date().toISOString();
          if (!directConv) {
            const newConvId = `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
            directConv = {
              id: newConvId,
              type: 'direct',
              title: null,
              createdBy: user.id,
              tenantId,
              branchId: user.branchId || null,
              status: 'active',
              createdAt: now,
              endedAt: null,
            };
            dbState.conversations.unshift(directConv);
            dbState.conversationParticipants.push(
              {
                id: `cp-${newConvId}-${user.id}`,
                conversationId: newConvId,
                userId: user.id,
                addedBy: user.id,
                addedAt: now,
                leftAt: null,
              },
              {
                id: `cp-${newConvId}-${recipientUserId}`,
                conversationId: newConvId,
                userId: recipientUserId,
                addedBy: user.id,
                addedAt: now,
                leftAt: null,
              }
            );
          }

          const newMsg: ConversationMessage = {
            id: `cmsg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            conversationId: directConv.id,
            senderId: user.id,
            body: message,
            createdAt: now,
            editedAt: null,
            deletedAt: null,
            senderName: user.name,
            senderRole: user.role,
          };
          dbState.conversationMessages.push(newMsg);
          db.save();

          // Relay to conversation room if anyone joined it
          this.io?.to(`conversation:${tenantId}:${directConv.id}`).emit('conversation:message_received', {
            conversationId: directConv.id,
            message: newMsg,
          });
        } catch (persistErr) {
          console.error('[Socket.io] Error persisting private message to conversation:', persistErr);
        }
      });

      // 3K. Conversation: Join Room (Active Participancy Enforced)
      socket.on('conversation:join', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = conversationJoinSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Malformed conversation join request.' });
          return;
        }

        const { conversationId } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';

        // Authoritative zero-trust check: query active participancy
        const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
        if (!isParticipant) {
          console.warn(
            `[Security Alert] Socket ${socket.id} (user: ${user.email}, role: ${user.role}) denied join to conversation "${conversationId}"`
          );
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'conversation:join',
            targetType: 'conversation',
            targetId: conversationId,
            reason: 'User is not an active participant in this conversation.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_CONVERSATION',
            message: 'Access denied: You are not an active participant in this conversation.',
            conversationId,
          });
          return;
        }

        const roomKey = `conversation:${tenantId}:${conversationId}`;
        socket.join(roomKey);
        socket.emit('conversation:joined', {
          status: 'ok',
          conversationId,
          room: roomKey,
        });

        socket.to(roomKey).emit('conversation:user_joined', {
          conversationId,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          joinedAt: new Date().toISOString(),
        });
      });

      // 3L. Conversation: Send Message (Active Participancy Enforced & Persisted)
      socket.on('conversation:message', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = conversationMessageSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Malformed conversation message request.' });
          return;
        }

        const { conversationId, body } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';

        // Authoritative zero-trust check: query active participancy
        const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
        if (!isParticipant) {
          console.warn(
            `[Security Alert] Socket ${socket.id} (user: ${user.email}) denied message to conversation "${conversationId}"`
          );
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'conversation:message',
            targetType: 'conversation',
            targetId: conversationId,
            reason: 'User is not an active participant in this conversation.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_CONVERSATION',
            message: 'Access denied: You cannot send messages to a conversation you are not an active participant of.',
            conversationId,
          });
          return;
        }

        const state = db.getState();
        const conv = (state.conversations || []).find((c) => c.id === conversationId);
        if (!conv || conv.status === 'ended') {
          socket.emit('error', {
            code: 'CONVERSATION_ENDED',
            message: 'This conversation has ended.',
            conversationId,
          });
          return;
        }

        // Re-scope direct conversation tier and ministry-scope rules on every message attempt
        if (conv.type === 'direct') {
          const activeParts = (state.conversationParticipants || []).filter(
            (p) => p.conversationId === conversationId && !p.leftAt
          );
          const otherPart = activeParts.find((p) => p.userId !== user.id);
          if (otherPart) {
            const senderRole = await resolveUserRole(user.id);
            const recipientRole = await resolveUserRole(otherPart.userId);
            const tierCheck = validateDirectConversationTierAndScope(
              user.id,
              senderRole,
              otherPart.userId,
              recipientRole
            );

            if (!tierCheck.allowed) {
              logPermissionDenied({
                userId: user.id,
                userEmail: user.email,
                userRole: senderRole,
                action: 'conversation:message',
                targetType: 'conversation',
                targetId: conversationId,
                reason: tierCheck.error || 'Access denied by tier or ministry scope rule.',
                ipAddress: socket.handshake.address,
              });

              db.addAuditLog(
                'Unauthorized Access Attempt Blocked',
                'Conversations & Messaging',
                tierCheck.details || `Blocked direct message in ${conversationId}: ${tierCheck.code}`,
                user.email,
                socket.handshake.address
              );

              socket.emit('error', {
                code: tierCheck.code,
                message: tierCheck.error,
                conversationId,
              });
              return;
            }
          }
        }

        // Persist message to database
        const now = new Date().toISOString();
        const newMessage: ConversationMessage = {
          id: `cmsg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          conversationId,
          senderId: user.id,
          body,
          createdAt: now,
          editedAt: null,
          deletedAt: null,
          senderName: user.name,
          senderRole: user.role,
        };

        if (!state.conversationMessages) {
          state.conversationMessages = [];
        }
        state.conversationMessages.push(newMessage);
        db.save();

        // Relay to conversation room
        const roomKey = `conversation:${tenantId}:${conversationId}`;
        this.io?.to(roomKey).emit('conversation:message_received', {
          conversationId,
          message: newMessage,
        });
      });

      // 3M. Conversation: Leave Room
      socket.on('conversation:leave', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = conversationLeaveSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const { conversationId } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';
        const roomKey = `conversation:${tenantId}:${conversationId}`;

        socket.leave(roomKey);
        socket.to(roomKey).emit('conversation:user_left', {
          conversationId,
          userId: user.id,
          userName: user.name,
          leftAt: new Date().toISOString(),
        });
      });

      // 3N. 1:1 Direct Video Call (Tier-Gated Staff<->Member & Zero-Trust Enforced)
      socket.on('direct_video:start_call', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) {
          socket.emit('error', { code: 'UNAUTHORIZED', message: 'Authentication required.' });
          return;
        }

        const parseResult = directVideoCallSchema.safeParse(rawPayload);
        if (!parseResult.success) {
          socket.emit('error', { code: 'INVALID_PAYLOAD', message: 'Invalid direct video call payload.' });
          return;
        }

        const { conversationId } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';

        const state = db.getState();
        const conv = (state.conversations || []).find((c) => c.id === conversationId);

        if (!conv || conv.tenantId !== tenantId) {
          socket.emit('error', { code: 'CONVERSATION_NOT_FOUND', message: 'Direct conversation not found.' });
          return;
        }

        if (conv.type !== 'direct') {
          socket.emit('error', {
            code: 'DIRECT_CONVERSATION_REQUIRED',
            message: '1:1 video calls are strictly for direct conversations. Use group video conferencing for groups.',
          });
          return;
        }

        if (conv.status !== 'active') {
          socket.emit('error', { code: 'CONVERSATION_INACTIVE', message: 'Conversation is inactive or ended.' });
          return;
        }

        // Zero-trust active participant check
        const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
        if (!isParticipant) {
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: user.role,
            action: 'direct_video:start_call',
            targetType: 'conversation',
            targetId: conversationId,
            reason: 'User is not an active participant in this direct conversation.',
            ipAddress: socket.handshake.address,
          });
          socket.emit('error', {
            code: 'FORBIDDEN_CONVERSATION',
            message: 'Access denied: You are not an active participant in this conversation.',
            conversationId,
          });
          return;
        }

        // Find other active participant
        const participants = (state.conversationParticipants || []).filter(
          (p) => p.conversationId === conversationId && !p.leftAt
        );
        const otherParticipant = participants.find((p) => p.userId !== user.id);
        const recipientUserId = parseResult.data.recipientUserId || otherParticipant?.userId;

        if (!recipientUserId) {
          socket.emit('error', { code: 'NO_RECIPIENT_FOUND', message: 'No recipient found for this video call.' });
          return;
        }

        // Cross-tenant verification
        const systemUsers = state.systemUsers || [];
        const recipientUser = systemUsers.find((u) => u.id === recipientUserId);
        if (recipientUser && (recipientUser as any).tenantId && (recipientUser as any).tenantId !== tenantId) {
          console.warn(`[Security Alert] Blocked cross-tenant video call from ${user.email} to ${recipientUser.email}`);
          socket.emit('error', { code: 'CROSS_TENANT_BLOCKED', message: 'Cross-tenant video calling is prohibited.' });
          return;
        }

        // Authoritative server-side role resolution
        const callerRole = await resolveUserRole(user.id);
        const recipientRole = await resolveUserRole(recipientUserId);

        // Enforce Phase 21 & 21b tier and ministry-scope rules
        const tierCheck = validateDirectConversationTierAndScope(
          user.id,
          callerRole,
          recipientUserId,
          recipientRole
        );

        if (!tierCheck.allowed) {
          console.warn(
            `[Security Alert] Blocked 1:1 video call from ${user.email} (${callerRole}) to ${recipientUserId} (${recipientRole}) - ${tierCheck.code}`
          );
          logPermissionDenied({
            userId: user.id,
            userEmail: user.email,
            userRole: callerRole,
            action: 'direct_video:start_call',
            targetType: 'conversation',
            targetId: conversationId,
            reason: tierCheck.error || 'Direct 1:1 video call prohibited by tier or ministry-scope rule.',
            ipAddress: socket.handshake.address,
          });
          db.addAuditLog(
            'Unauthorized Access Attempt Blocked',
            'Conversations & Messaging',
            tierCheck.details ||
              `Blocked 1:1 video call attempt between ${user.email} (${callerRole}) and ${recipientUserId} (${recipientRole}) in conversation ${conversationId}: ${tierCheck.code}`,
            user.email,
            socket.handshake.address
          );
          socket.emit('error', {
            code: tierCheck.code,
            message: tierCheck.error,
          });
          return;
        }

        // Generate Jitsi-style room URL reusing group video conference mechanism
        const roomUrl = `https://meet.jit.si/CMMS-Direct-${tenantId}-${conversationId}-${Date.now().toString(36)}`;
        const now = new Date().toISOString();

        conv.roomUrl = roomUrl;
        conv.activeVideoCall = {
          roomUrl,
          startedAt: now,
          startedBy: user.id,
          callerName: user.name,
          callerRole,
          recipientId: recipientUserId,
          recipientName: otherParticipant?.userName || 'Member',
          status: 'calling',
        };
        db.save();

        db.addAuditLog(
          'Start 1:1 Video Call',
          'Conversations & Messaging',
          `Staff/Leader ${user.name} (${callerRole}) started 1:1 video call with ${recipientUserId} (${recipientRole}) in conversation ${conversationId}`,
          user.email,
          socket.handshake.address
        );

        // Notify recipient ONLY via their user:{id} socket room (NEVER blast to any group room!)
        this.io?.to(`user:${recipientUserId}`).emit('direct_video:incoming_call', {
          conversationId,
          callerId: user.id,
          callerName: user.name,
          callerRole,
          roomUrl,
          startedAt: now,
        });

        // Notify caller
        socket.emit('direct_video:call_started', {
          conversationId,
          roomUrl,
          recipientUserId,
          activeVideoCall: conv.activeVideoCall,
        });
      });

      socket.on('direct_video:accept_call', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = directVideoRespondSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const { conversationId } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';

        const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
        if (!isParticipant) return;

        const state = db.getState();
        const conv = (state.conversations || []).find((c) => c.id === conversationId);
        if (!conv || !conv.activeVideoCall) return;

        conv.activeVideoCall.status = 'active';
        db.save();

        const callerId = conv.activeVideoCall.startedBy;
        this.io?.to(`user:${callerId}`).emit('direct_video:call_accepted', {
          conversationId,
          roomUrl: conv.roomUrl,
          accepterId: user.id,
          accepterName: user.name,
        });

        socket.emit('direct_video:call_accepted', {
          conversationId,
          roomUrl: conv.roomUrl,
          accepterId: user.id,
          accepterName: user.name,
        });
      });

      socket.on('direct_video:decline_call', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = directVideoRespondSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const { conversationId, reason } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';

        const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
        if (!isParticipant) return;

        const state = db.getState();
        const conv = (state.conversations || []).find((c) => c.id === conversationId);
        if (!conv) return;

        const callerId = conv.activeVideoCall?.startedBy;
        conv.roomUrl = null;
        conv.activeVideoCall = null;
        db.save();

        if (callerId) {
          this.io?.to(`user:${callerId}`).emit('direct_video:call_declined', {
            conversationId,
            declinerId: user.id,
            declinerName: user.name,
            reason: reason || 'Call declined',
          });
        }
      });

      socket.on('direct_video:end_call', async (rawPayload: unknown) => {
        if (!checkMessageRateLimit()) return;
        const user = getUser();
        const isGuest = getIsGuest();
        if (isGuest || !user) return;

        const parseResult = directVideoRespondSchema.safeParse(rawPayload);
        if (!parseResult.success) return;

        const { conversationId } = parseResult.data;
        const tenantId = user.tenantId || 'tenant-grace-main';

        const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
        if (!isParticipant) return;

        const state = db.getState();
        const conv = (state.conversations || []).find((c) => c.id === conversationId);
        if (!conv) return;

        conv.roomUrl = null;
        conv.activeVideoCall = null;
        db.save();

        const participants = (state.conversationParticipants || []).filter(
          (p) => p.conversationId === conversationId && !p.leftAt
        );

        for (const p of participants) {
          this.io?.to(`user:${p.userId}`).emit('direct_video:call_ended', {
            conversationId,
            endedBy: user.id,
            endedByName: user.name,
          });
        }
      });

      socket.on('disconnect', () => {
        this.connectedClients.delete(socket.id);
        socketMessageTracker.delete(socket.id);
        console.log(`[Socket.io] Client disconnected: ${socket.id}`);
      });
    });

    console.log('[Socket.io] Enterprise secured real-time engine initialized.');
  }

  public getIO(): SocketIOServer | null {
    return this.io;
  }

  // Push live attendance check-in (Scoped to authorized branch & tenant)
  public broadcastAttendanceCheckIn(record: AttendanceRecord) {
    if (!this.io) return;
    // Approvals/attendance feed receives verified update
    this.io.to('attendance-feed').emit('attendance:checkin', {
      type: 'CHECK_IN',
      record,
      timestamp: new Date().toISOString(),
    });
    // Branch-specific listeners receive live update
    this.io.to(`branch:${record.branchId}`).emit('attendance:live_count_update', {
      branchId: record.branchId,
      serviceName: record.serviceName,
      increment: 1,
    });
  }

  // Push new pending approval notification (Sent strictly to approvals-queue)
  public broadcastPendingApproval(workflow: WorkflowRequest) {
    if (!this.io) return;
    this.io.to('approvals-queue').emit('approval:new_pending', {
      workflow,
      timestamp: new Date().toISOString(),
    });
  }

  // Push approval status change (Sent strictly to approvals-queue and target user)
  public broadcastApprovalStatusChanged(workflow: WorkflowRequest) {
    if (!this.io) return;
    this.io.to('approvals-queue').emit('approval:status_changed', {
      workflow,
      timestamp: new Date().toISOString(),
    });
    if (workflow.requesterId) {
      this.io.to(`user:${workflow.requesterId}`).emit('approval:user_notified', {
        workflow,
        timestamp: new Date().toISOString(),
      });
    }
  }

  // Generic broadcast to all connected clients
  public emitToAll(event: string, payload: any) {
    if (!this.io) return;
    this.io.emit(event, payload);
  }

  // Generic Tenant broadcast
  public broadcastToTenant(tenantId: string, event: string, payload: any) {
    if (!this.io) return;
    this.io.to(`tenant:${tenantId}`).emit(event, payload);
  }
}

export const socketService = new SocketService();
