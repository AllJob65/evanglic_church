import { prisma } from '../prisma';
import { db } from '../../server/db';
import { AttendanceRecord, EventItem, UserRole } from '../types';
import { socketService } from './socketService';

export class AttendanceService {
  public async getAttendance(filters?: { branchId?: string; date?: string; memberId?: string }) {
    return prisma.attendance.findMany({ where: filters });
  }

  public async recordCheckIn(record: AttendanceRecord) {
    const saved = await prisma.attendance.create({ data: record });

    // Broadcast live check-in via WebSocket
    socketService.broadcastAttendanceCheckIn(saved);

    return saved;
  }

  public async bulkRecordAttendance(records: AttendanceRecord[], operatorEmail: string = 'admin@gracecathedral.org') {
    const result = await prisma.attendance.createMany({ data: records });

    await prisma.auditLog.create({
      data: {
        userEmail: operatorEmail,
        userRole: 'Branch Administrator' as UserRole,
        action: 'Bulk Attendance Fast Write',
        module: 'Attendance',
        details: `Recorded ${result.count} check-ins for service`,
      },
    });

    // Notify connected dashboards of the influx
    if (records.length > 0) {
      socketService.broadcastToTenant('tenant-grace-main', 'attendance:bulk_update', {
        count: result.count,
        branchId: records[0].branchId,
        serviceName: records[0].serviceName,
      });
    }

    return result;
  }

  public async getLiveCounts(branchId?: string, date?: string) {
    const targetDate = date || new Date().toISOString().split('T')[0];
    const records = await prisma.attendance.findMany({
      where: {
        branchId: branchId && branchId !== 'all' ? branchId : undefined,
        date: targetDate,
      },
    });

    const presentCount = records.filter((r) => r.status === 'Present').length;
    const lateCount = records.filter((r) => r.status === 'Late').length;
    const qrCount = records.filter((r) => r.checkInMethod === 'QR Code').length;
    const manualCount = records.filter((r) => r.checkInMethod !== 'QR Code').length;

    return {
      date: targetDate,
      totalCheckIns: records.length,
      presentCount,
      lateCount,
      qrCount,
      manualCount,
      recentCheckIns: records.slice(0, 10),
    };
  }

  public async getEvents() {
    return db.getState().events;
  }

  public async createEvent(event: EventItem) {
    db.getState().events.unshift(event);
    db.persist();
    return event;
  }
}

export const attendanceService = new AttendanceService();
