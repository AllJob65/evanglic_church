import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Member } from '../types';

export const supabaseMemberService = {
  async getMembers(params?: {
    branchId?: string;
    search?: string;
    tenantId?: string;
    page?: number;
    pageSize?: number;
  }): Promise<Member[]> {
    if (!isSupabaseConfigured) {
      return [];
    }

    let query = supabase
      .from('members')
      .select('*')
      .order('created_at', { ascending: false });

    if (params?.branchId && params.branchId !== 'all') {
      query = query.eq('branch_id', params.branchId);
    }
    if (params?.tenantId) {
      query = query.eq('tenant_id', params.tenantId);
    }
    if (params?.search) {
      query = query.or(`first_name.ilike.%${params.search}%,last_name.ilike.%${params.search}%,member_number.ilike.%${params.search}%`);
    }

    if (params?.page && params?.pageSize) {
      const from = (params.page - 1) * params.pageSize;
      const to = from + params.pageSize - 1;
      query = query.range(from, to);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getMembers notice:', error.message);
      throw error;
    }

    return (data || []).map(row => ({
      id: row.id,
      memberIdNumber: row.member_number || `MEM-${row.id.substring(0, 5)}`,
      title: 'Brother/Sister',
      firstName: row.first_name,
      middleName: row.middle_name || '',
      lastName: row.last_name,
      gender: row.gender || 'Male',
      dateOfBirth: row.date_of_birth || '1990-01-01',
      maritalStatus: row.marital_status || 'Single',
      primaryPhone: row.phone || '+251 91 100 0000',
      email: row.email || '',
      streetAddress: row.address || 'Bole Sub-City',
      city: row.city || 'Addis Ababa',
      branchId: row.branch_id || 'br-1',
      membershipStatus: (row.membership_status || 'Active') as any,
      ministryIds: row.ministries || [],
      emergencyContact: {
        name: 'Family Contact',
        relationship: 'Relative',
        phone: row.phone || '+251 91 100 0000',
      },
      createdAt: row.created_at || new Date().toISOString(),
      lastActive: row.updated_at || new Date().toISOString(),
      attendanceScore: 90,
    } as Member));
  },

  async getMembersPaginated(params?: {
    branchId?: string;
    search?: string;
    tenantId?: string;
    page?: number;
    pageSize?: number;
  }): Promise<{ members: Member[]; totalCount: number; page: number; pageSize: number; totalPages: number }> {
    if (!isSupabaseConfigured) {
      return { members: [], totalCount: 0, page: 1, pageSize: 50, totalPages: 0 };
    }

    const page = Math.max(1, params?.page || 1);
    const pageSize = Math.max(1, Math.min(100, params?.pageSize || 50));
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let countQuery = supabase
      .from('members')
      .select('*', { count: 'exact', head: true });

    let dataQuery = supabase
      .from('members')
      .select('*')
      .order('created_at', { ascending: false })
      .range(from, to);

    if (params?.branchId && params.branchId !== 'all') {
      countQuery = countQuery.eq('branch_id', params.branchId);
      dataQuery = dataQuery.eq('branch_id', params.branchId);
    }
    if (params?.tenantId) {
      countQuery = countQuery.eq('tenant_id', params.tenantId);
      dataQuery = dataQuery.eq('tenant_id', params.tenantId);
    }
    if (params?.search) {
      const searchFilter = `first_name.ilike.%${params.search}%,last_name.ilike.%${params.search}%,member_number.ilike.%${params.search}%`;
      countQuery = countQuery.or(searchFilter);
      dataQuery = dataQuery.or(searchFilter);
    }

    const [{ count, error: countError }, { data, error: dataError }] = await Promise.all([
      countQuery,
      dataQuery,
    ]);

    if (countError) throw countError;
    if (dataError) throw dataError;

    const totalCount = count || 0;
    const totalPages = Math.ceil(totalCount / pageSize);

    const members = (data || []).map(row => ({
      id: row.id,
      memberIdNumber: row.member_number || `MEM-${row.id.substring(0, 5)}`,
      title: 'Brother/Sister',
      firstName: row.first_name,
      middleName: row.middle_name || '',
      lastName: row.last_name,
      gender: row.gender || 'Male',
      dateOfBirth: row.date_of_birth || '1990-01-01',
      maritalStatus: row.marital_status || 'Single',
      primaryPhone: row.phone || '+251 91 100 0000',
      email: row.email || '',
      streetAddress: row.address || 'Bole Sub-City',
      city: row.city || 'Addis Ababa',
      branchId: row.branch_id || 'br-1',
      membershipStatus: (row.membership_status || 'Active') as any,
      ministryIds: row.ministries || [],
      emergencyContact: {
        name: 'Family Contact',
        relationship: 'Relative',
        phone: row.phone || '+251 91 100 0000',
      },
      createdAt: row.created_at || new Date().toISOString(),
      lastActive: row.updated_at || new Date().toISOString(),
      attendanceScore: 90,
    } as Member));

    return {
      members,
      totalCount,
      page,
      pageSize,
      totalPages,
    };
  },

  async createMember(member: Partial<Member>, tenantId?: string): Promise<Member> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase not configured');
    }

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: member.branchId || 'br-1',
      member_number: member.memberIdNumber || `MEM-${Math.floor(10000 + Math.random() * 90000)}`,
      first_name: member.firstName || 'Member',
      middle_name: member.middleName || '',
      last_name: member.lastName || 'User',
      gender: member.gender || 'Male',
      marital_status: member.maritalStatus || 'Single',
      date_of_birth: member.dateOfBirth || null,
      phone: member.primaryPhone || member.altPhone || '',
      email: member.email || '',
      address: member.streetAddress || '',
      city: member.city || 'Addis Ababa',
      membership_status: member.membershipStatus || 'Active',
      fellowship_group: member.foundationCourseCompleted ? 'Foundation' : 'General',
    };

    const { data, error } = await supabase
      .from('members')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;
    return {
      id: data.id,
      memberIdNumber: data.member_number,
      title: member.title || 'Brother/Sister',
      firstName: data.first_name,
      middleName: data.middle_name || '',
      lastName: data.last_name,
      gender: data.gender,
      dateOfBirth: data.date_of_birth || '1990-01-01',
      maritalStatus: data.marital_status,
      primaryPhone: data.phone || '+251 91 100 0000',
      email: data.email,
      streetAddress: data.address || '',
      city: data.city || 'Addis Ababa',
      branchId: data.branch_id,
      membershipStatus: data.membership_status as any,
      ministryIds: member.ministryIds || [],
      emergencyContact: member.emergencyContact || {
        name: 'Family Contact',
        relationship: 'Relative',
        phone: data.phone || '+251 91 100 0000',
      },
      createdAt: data.created_at,
      lastActive: data.created_at,
      attendanceScore: 90,
    } as Member;
  },

  async updateMember(id: string, updates: Partial<Member>): Promise<Member> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload: any = {
      updated_at: new Date().toISOString(),
    };
    if (updates.firstName) payload.first_name = updates.firstName;
    if (updates.lastName) payload.last_name = updates.lastName;
    if (updates.middleName !== undefined) payload.middle_name = updates.middleName;
    if (updates.gender) payload.gender = updates.gender;
    if (updates.primaryPhone !== undefined) payload.phone = updates.primaryPhone;
    if (updates.email !== undefined) payload.email = updates.email;
    if (updates.streetAddress !== undefined) payload.address = updates.streetAddress;
    if (updates.city !== undefined) payload.city = updates.city;
    if (updates.membershipStatus) payload.membership_status = updates.membershipStatus;
    if (updates.branchId) payload.branch_id = updates.branchId;

    const { data, error } = await supabase
      .from('members')
      .update(payload)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return {
      id: data.id,
      memberIdNumber: data.member_number,
      title: updates.title || 'Brother/Sister',
      firstName: data.first_name,
      middleName: data.middle_name || '',
      lastName: data.last_name,
      gender: data.gender,
      dateOfBirth: data.date_of_birth || '1990-01-01',
      maritalStatus: data.marital_status || 'Single',
      primaryPhone: data.phone || '+251 91 100 0000',
      email: data.email,
      streetAddress: data.address || '',
      city: data.city || 'Addis Ababa',
      branchId: data.branch_id,
      membershipStatus: data.membership_status as any,
      ministryIds: updates.ministryIds || [],
      emergencyContact: updates.emergencyContact || {
        name: 'Family Contact',
        relationship: 'Relative',
        phone: data.phone || '+251 91 100 0000',
      },
      createdAt: data.created_at || new Date().toISOString(),
      lastActive: data.updated_at || new Date().toISOString(),
      attendanceScore: 90,
    } as Member;
  },

  async deleteMember(id: string): Promise<boolean> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');
    const { error } = await supabase.from('members').delete().eq('id', id);
    if (error) throw error;
    return true;
  },
};
