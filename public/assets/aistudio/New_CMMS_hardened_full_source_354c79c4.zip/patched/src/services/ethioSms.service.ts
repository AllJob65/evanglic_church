/**
 * Ethio Telecom SMS Gateway Engine & Service Client
 * 
 * Exclusively integrated with Ethio Telecom HTTP REST SMS Gateway via server proxy.
 * Strictly validates Ethiopian numbers (09/07, +2519/+2517) and proxies dispatches securely.
 */

import { formatEthioPhone } from '../schemas/phone.schema';

/**
 * Strongly typed response returned by the Ethio Telecom SMS service
 */
export interface EthioSmsResponse {
  success: boolean;
  messageId?: string;
  error?: string;
  statusCode?: number;
  normalizedPhone?: string;
  gatewayUsed?: string;
  timestamp?: string;
}

/**
 * Ethio Telecom Gateway Configuration Schema
 */
export interface EthioTelecomConfig {
  endpoint?: string;
  senderId?: string;
  timeoutMs?: number;
}

/**
 * Resolves Ethio Telecom client configuration safely
 */
export function getEthioTelecomConfig(): EthioTelecomConfig {
  return {
    endpoint: '/api/integrations/sms/send',
    senderId: 'GRACECATH',
    timeoutMs: 10000,
  };
}

/**
 * Core Ethio Telecom SMS Gateway Service
 * Dispatches SMS requests securely through server-side /api/integrations/sms/send proxy
 */
export class EthioTelecomSmsService {
  private config: EthioTelecomConfig;

  constructor(customConfig?: Partial<EthioTelecomConfig>) {
    this.config = {
      ...getEthioTelecomConfig(),
      ...customConfig,
    };
  }

  /**
   * Dispatches a single SMS message via Ethio Telecom REST Gateway (server-side proxied)
   * 
   * @param toPhone Recipient phone number (local 09/07, intl +2519/+2517, or 2519/2517)
   * @param message Message body to transmit
   * @param customSenderId Optional registered alphanumeric sender ID override
   */
  async sendSms(
    toPhone: string,
    message: string,
    customSenderId?: string
  ): Promise<EthioSmsResponse> {
    const timestamp = new Date().toISOString();
    const sender_id = customSenderId || this.config.senderId || 'GRACECATH';

    // 1. Phone number validation and normalization to Ethio Telecom format (2519... / 2517...)
    let formattedTo: string;
    try {
      formattedTo = formatEthioPhone(toPhone);
    } catch (validationErr: any) {
      return {
        success: false,
        error: `Phone validation failed: ${validationErr.message}`,
        gatewayUsed: 'Ethio Telecom Gateway',
        timestamp,
      };
    }

    // 2. Validate message content
    if (!message || message.trim() === '') {
      return {
        success: false,
        error: 'SMS message body cannot be empty',
        normalizedPhone: formattedTo,
        gatewayUsed: 'Ethio Telecom Gateway',
        timestamp,
      };
    }

    // 3. Setup AbortController for network timeout handling
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeoutMs || 10000);

    try {
      // Securely dispatch through server-side proxy
      const targetEndpoint = this.config.endpoint || '/api/integrations/sms/send';
      const bodyPayload = JSON.stringify({
        recipients: [formattedTo],
        message: message.trim(),
        senderId: sender_id,
        gateway: 'EthioTelecom',
      });

      const response = await fetch(targetEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: bodyPayload,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // Handle Rate Limiting (HTTP 429)
      if (response.status === 429) {
        return {
          success: false,
          statusCode: 429,
          error: 'Ethio Telecom rate limit exceeded. Please throttle requests and try again.',
          normalizedPhone: formattedTo,
          gatewayUsed: 'Ethio Telecom Gateway',
          timestamp,
        };
      }

      // Handle Unauthorized / Invalid Credentials (HTTP 401, 403)
      if (response.status === 401 || response.status === 403) {
        return {
          success: false,
          statusCode: response.status,
          error: 'Ethio Telecom authentication failed: Invalid APP_ID or APP_SECRET credentials.',
          normalizedPhone: formattedTo,
          gatewayUsed: 'Ethio Telecom Gateway',
          timestamp,
        };
      }

      const responseData = await response.json().catch(() => ({}));

      if (!response.ok) {
        return {
          success: false,
          statusCode: response.status,
          error: responseData.error || responseData.message || `Ethio Telecom API returned status ${response.status}`,
          normalizedPhone: formattedTo,
          gatewayUsed: 'Ethio Telecom Gateway',
          timestamp,
        };
      }

      const messageId =
        responseData.messageId ||
        responseData.dispatchId ||
        responseData.msg_id ||
        `ETHIO-${Date.now().toString().slice(-6)}`;

      return {
        success: true,
        messageId,
        statusCode: response.status,
        normalizedPhone: formattedTo,
        gatewayUsed: 'Ethio Telecom Gateway',
        timestamp,
      };
    } catch (err: any) {
      clearTimeout(timeoutId);

      // Timeout detection
      if (err.name === 'AbortError') {
        return {
          success: false,
          error: `Ethio Telecom connection timed out after ${this.config.timeoutMs || 10000}ms`,
          normalizedPhone: formattedTo,
          gatewayUsed: 'Ethio Telecom Gateway',
          timestamp,
        };
      }

      // Network connection error
      return {
        success: false,
        error: `Network failure connecting to Ethio Telecom Gateway: ${err.message || 'Connection dropped'}`,
        normalizedPhone: formattedTo,
        gatewayUsed: 'Ethio Telecom Gateway',
        timestamp,
      };
    }
  }

  /**
   * Dispatches bulk SMS messages to multiple Ethiopian recipients
   */
  async sendBatchSms(
    toPhones: string[],
    message: string,
    customSenderId?: string
  ): Promise<{
    total: number;
    successful: number;
    failed: number;
    results: EthioSmsResponse[];
  }> {
    const results: EthioSmsResponse[] = [];
    let successful = 0;
    let failed = 0;

    for (const phone of toPhones) {
      const res = await this.sendSms(phone, message, customSenderId);
      results.push(res);
      if (res.success) {
        successful++;
      } else {
        failed++;
      }
    }

    return {
      total: toPhones.length,
      successful,
      failed,
      results,
    };
  }
}

/**
 * Singleton instance for direct usage
 */
export const ethioSmsService = new EthioTelecomSmsService();

/**
 * Helper to dispatch SMS via Ethio Telecom
 */
export async function sendEthioSms(
  toPhone: string,
  message: string,
  senderId?: string
): Promise<EthioSmsResponse> {
  return ethioSmsService.sendSms(toPhone, message, senderId);
}

/**
 * Integration & Testing Handler:
 * Formats OTP verification message in accordance with Ethio Telecom sender rules
 * and transmits payload via ethioSms.service.ts
 *
 * @param userPhone Target Ethiopian mobile phone number
 * @param otpCode 4 to 6 digit OTP security code
 */
export async function sendOtpNotification(
  userPhone: string,
  otpCode: string
): Promise<EthioSmsResponse> {
  const sanitizedOtp = String(otpCode).trim();
  if (!sanitizedOtp || sanitizedOtp.length < 4) {
    return {
      success: false,
      error: 'Invalid OTP code. Must be at least 4 digits.',
      timestamp: new Date().toISOString(),
    };
  }

  // Ethio Telecom Compliant Template (Strictly ASCII/Unicode compliant)
  const otpMessage = `Your Church CMMS verification code is: ${sanitizedOtp}. Valid for 5 minutes. Do not share this OTP with anyone.`;

  return ethioSmsService.sendSms(userPhone, otpMessage, 'GRACECATH');
}
