import { io, Socket } from 'socket.io-client';

let socket: Socket | null = null;

export function getClientSocket(): Socket {
  if (!socket) {
    const token =
      typeof window !== 'undefined'
        ? localStorage.getItem('cmms_token') || localStorage.getItem('cmms_auth_token') || ''
        : '';

    socket = io(typeof window !== 'undefined' ? window.location.origin : '', {
      path: '/socket.io',
      transports: ['websocket', 'polling'],
      autoConnect: true,
      auth: {
        token,
      },
    });

    socket.on('connect', () => {
      console.log('[Client Socket] Connected to real-time server with ID:', socket?.id);
      if (token) {
        socket?.emit('join', {});
      }
    });

    socket.on('connect_error', (err) => {
      console.warn('[Client Socket] Connection notice:', err?.message || err);
    });

    socket.on('authenticated', (authContext) => {
      console.log('[Client Socket] Authenticated real-time session:', authContext);
    });

    socket.on('error', (err) => {
      console.warn('[Client Socket] Security event from server:', err);
    });

    socket.on('disconnect', () => {
      console.log('[Client Socket] Disconnected from server');
    });
  }

  return socket;
}
