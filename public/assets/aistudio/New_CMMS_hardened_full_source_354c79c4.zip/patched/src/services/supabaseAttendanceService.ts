import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { AttendanceRecord } from '../types';

export const supabaseAttendanceService = {
  async getAttendance(params?: { branchId?: string; date?: string; eventName?: string }): Promise<AttendanceRecord[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('attendance_records')
      .select('*')
      .order('checkin_time', { ascending: false });

    if (params?.branchId && params.branchId !== 'all') {
      query = query.eq('branch_id', params.branchId);
    }
    if (params?.eventName) {
      query = query.ilike('event_name', `%${params.eventName}%`);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getAttendance notice:', error.message);
      throw error;
    }

    return (data || []).map(row => ({
      id: row.id,
      date: row.checkin_time?.substring(0, 10) || new Date().toISOString().substring(0, 10),
      eventId: row.event_id || 'evt-1',
      eventName: row.event_name,
      serviceType: row.service_type || 'Sunday Main Service',
      serviceName: row.event_name || 'Sunday Worship',
      memberId: row.member_id || 'mem-anon',
      memberName: row.visitor_name || 'Checked-in Attendee',
      branchId: row.branch_id || 'br-1',
      status: 'Present',
      checkInTime: row.checkin_time ? new Date(row.checkin_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '09:00 AM',
      checkInMethod: row.checkin_method || 'Manual Headcount',
    } as AttendanceRecord));
  },

  async recordAttendance(record: Partial<AttendanceRecord>, tenantId?: string): Promise<AttendanceRecord> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: record.branchId || 'br-1',
      event_name: record.eventName || record.serviceName || 'Sunday Celebration Service',
      service_type: record.serviceType || 'Sunday Main Service',
      member_id: record.memberId || null,
      visitor_name: record.memberName || null,
      checkin_method: (record.checkInMethod === 'QR Code Scanning' || record.checkInMethod === 'QR Code' || record.checkInMethod === 'Self QR Scan') ? 'QR Code Scanning' : 'Manual Web Click',
      checkin_time: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('attendance_records')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      date: data.checkin_time.substring(0, 10),
      eventId: record.eventId || 'evt-1',
      eventName: data.event_name,
      serviceName: data.event_name,
      serviceType: data.service_type,
      memberId: data.member_id || 'mem-anon',
      memberName: data.visitor_name || 'Member',
      branchId: data.branch_id,
      status: 'Present',
      checkInTime: new Date(data.checkin_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      checkInMethod: data.checkin_method,
    } as AttendanceRecord;
  },

  /**
   * Execute RPC checkin_member on Postgres directly
   */
  async checkinMemberRpc(params: {
    eventName: string;
    serviceType?: string;
    checkInMethod: 'Manual Web Click' | 'QR Code Scanning';
  }): Promise<{ data: any; error: any }> {
    if (!isSupabaseConfigured) {
      // Graceful local emulation when Supabase credentials are pending
      const mockRecord = {
        id: `att-rpc-${Date.now()}`,
        event_name: params.eventName,
        service_type: params.serviceType || 'Sunday Celebration Service',
        checkin_method: params.checkInMethod,
        checkin_time: new Date().toISOString(),
      };
      return { data: mockRecord, error: null };
    }

    try {
      const { data, error } = await supabase.rpc('checkin_member', {
        p_event_name: params.eventName,
        p_service_type: params.serviceType || 'Sunday Celebration Service',
        p_checkin_method: params.checkInMethod,
      });

      if (error) {
        // Fallback to table insert if RPC function isn't yet migrated in remote project
        console.warn('RPC checkin_member returned error, attempting direct insert fallback:', error.message);
        const { data: insertData, error: insertError } = await supabase
          .from('attendance_records')
          .insert([
            {
              event_name: params.eventName,
              service_type: params.serviceType || 'Sunday Celebration Service',
              checkin_method: params.checkInMethod,
              checkin_time: new Date().toISOString(),
            },
          ])
          .select()
          .single();

        if (insertError) return { data: null, error: insertError };
        return { data: insertData, error: null };
      }

      return { data, error: null };
    } catch (err: any) {
      console.warn('Exception during checkin_member RPC execution:', err);
      return { data: null, error: err };
    }
  },

  subscribeToLiveAttendance(branchId: string, onNewRecord: (record: AttendanceRecord) => void) {
    if (!isSupabaseConfigured) return () => {};

    const channelName = `attendance_live_${branchId || 'all'}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'attendance_records',
          filter: branchId && branchId !== 'all' ? `branch_id=eq.${branchId}` : undefined,
        },
        payload => {
          const row = payload.new as any;
          onNewRecord({
            id: row.id,
            date: row.checkin_time?.substring(0, 10),
            eventId: row.event_id || 'evt-1',
            eventName: row.event_name,
            serviceName: row.event_name,
            serviceType: row.service_type,
            memberId: row.member_id || 'mem-anon',
            memberName: row.visitor_name || 'Live Attendee',
            branchId: row.branch_id || 'br-1',
            status: 'Present',
            checkInTime: new Date(row.checkin_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            checkInMethod: row.checkin_method,
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};
