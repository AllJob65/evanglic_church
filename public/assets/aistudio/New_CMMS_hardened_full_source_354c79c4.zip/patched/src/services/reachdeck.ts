// ReachDeck (formerly Texthelp Browsealoud) Speech Synthesis & Accessibility Engine
// Integrates Web Speech API, ReachDeck script loader, audio translation, reading ruler, and screen mask

export interface ReachDeckVoice {
  id: string;
  name: string;
  lang: string;
  gender: 'female' | 'male';
}

export interface ReachDeckSettings {
  enabled: boolean;
  rate: number; // 0.5 to 2.0
  pitch: number; // 0.5 to 1.5
  volume: number; // 0.0 to 1.0
  voiceUri: string;
  hoverToSpeak: boolean;
  touchToSpeak: boolean;
  highlightWords: boolean;
  readingRuler: boolean;
  screenMask: boolean;
  textMagnifier: boolean;
  magnifierSize: number; // font size px
}

const DEFAULT_SETTINGS: ReachDeckSettings = {
  enabled: false,
  rate: 1.0,
  pitch: 1.0,
  volume: 1.0,
  voiceUri: '',
  hoverToSpeak: false,
  touchToSpeak: false, // Default is stopped / disabled
  highlightWords: true,
  readingRuler: false,
  screenMask: false,
  textMagnifier: false,
  magnifierSize: 24,
};

class ReachDeckService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking: boolean = false;
  private isPaused: boolean = false;
  private settings: ReachDeckSettings = DEFAULT_SETTINGS;
  private voices: SpeechSynthesisVoice[] = [];
  private listeners: ((state: { isSpeaking: boolean; isPaused: boolean; currentWord: string }) => void)[] = [];
  private currentWord: string = '';

  private touchStartX: number = 0;
  private touchStartY: number = 0;
  private touchStartTime: number = 0;
  private lastTapTime: number = 0;

  constructor() {
    if (typeof window !== 'undefined') {
      this.loadSettings();
      if ('speechSynthesis' in window) {
        this.synth = window.speechSynthesis;
        this.updateVoices();
        if (speechSynthesis.onvoiceschanged !== undefined) {
          speechSynthesis.onvoiceschanged = () => this.updateVoices();
        }
      }
      this.injectReachDeckScript();
      this.initTouchToSpeak();
      this.initKeyboardShortcuts();
    }
  }

  private initKeyboardShortcuts() {
    if (typeof window === 'undefined') return;
    window.addEventListener('keydown', (e) => {
      // Alt + X or Escape to immediately stop speech
      if ((e.altKey && (e.key === 'x' || e.key === 'X')) || e.key === 'Escape') {
        if (this.isSpeaking) {
          e.preventDefault();
          this.stop();
        }
      }
      // Alt + R to read page or selection
      if (e.altKey && (e.key === 'r' || e.key === 'R')) {
        e.preventDefault();
        this.speakSelection();
      }
    });
  }

  private initTouchToSpeak() {
    if (typeof window === 'undefined') return;

    // Multi-touch stop (2 fingers tap on screen = immediate stop, equivalent to Alt+X on phone)
    window.addEventListener(
      'touchstart',
      (e: TouchEvent) => {
        // Two-finger tap instantly stops speech on phone
        if (e.touches.length >= 2) {
          if (this.isSpeaking) {
            this.stop();
            return;
          }
        }

        if (e.touches.length === 1) {
          this.touchStartX = e.touches[0].clientX;
          this.touchStartY = e.touches[0].clientY;
          this.touchStartTime = Date.now();
        }
      },
      { passive: true }
    );

    window.addEventListener(
      'touchend',
      (e: TouchEvent) => {
        const now = Date.now();

        // Double tap on phone while speaking acts as instant stop (Alt+X)
        if (this.isSpeaking && (now - this.lastTapTime < 300)) {
          this.stop();
          this.lastTapTime = 0;
          return;
        }
        this.lastTapTime = now;

        if (!this.settings.touchToSpeak) return;

        if (e.changedTouches.length === 1) {
          const endX = e.changedTouches[0].clientX;
          const endY = e.changedTouches[0].clientY;
          const deltaTime = now - this.touchStartTime;
          const deltaX = Math.abs(endX - this.touchStartX);
          const deltaY = Math.abs(endY - this.touchStartY);

          // Only process clean taps (not scrolling/swiping)
          if (deltaX < 18 && deltaY < 18 && deltaTime < 450) {
            const target = document.elementFromPoint(endX, endY) as HTMLElement | null;
            if (!target) return;

            // Skip ReachDeck control toolbar itself and modal close buttons
            if (
              target.closest('#reachdeck-toolbar-container') ||
              target.closest('[data-reachdeck-ignore="true"]')
            ) {
              return;
            }

            // If user is actively typing in an input/textarea, do not disrupt typing
            const activeTag = document.activeElement?.tagName.toLowerCase();
            if (['input', 'textarea'].includes(activeTag || '') && target === document.activeElement) {
              return;
            }

            // Extract readable text from the tapped element or nearest block
            let textToRead = '';
            let highlightEl: HTMLElement | null = target;

            // Check if element has aria-label or title
            const ariaLabel = target.getAttribute('aria-label') || target.getAttribute('title');
            if (ariaLabel && ariaLabel.trim().length > 1) {
              textToRead = ariaLabel.trim();
            } else {
              // Find best text container
              const readableContainer = target.closest('button, a, h1, h2, h3, h4, h5, h6, p, li, label, tr, th, td, [role="button"]') as HTMLElement | null;
              if (readableContainer) {
                highlightEl = readableContainer;
                textToRead = readableContainer.innerText?.trim() || readableContainer.textContent?.trim() || '';
              } else {
                textToRead = target.innerText?.trim() || target.textContent?.trim() || '';
              }
            }

            // Clean text
            textToRead = textToRead.replace(/\s+/g, ' ').trim();

            if (textToRead && textToRead.length >= 1 && textToRead.length < 800) {
              // Highlight tapped element briefly
              if (highlightEl) {
                // Remove previous highlight
                document.querySelectorAll('.reachdeck-touch-active').forEach((el) => el.classList.remove('reachdeck-touch-active'));
                highlightEl.classList.add('reachdeck-touch-active');
                setTimeout(() => {
                  highlightEl?.classList.remove('reachdeck-touch-active');
                }, 2000);
              }

              this.speak(textToRead);
            }
          }
        }
      },
      { passive: true }
    );
  }

  public toggleTouchToSpeak(enabled?: boolean) {
    const nextVal = enabled !== undefined ? enabled : !this.settings.touchToSpeak;
    this.saveSettings({ touchToSpeak: nextVal });
    return nextVal;
  }

  private loadSettings() {
    try {
      const saved = localStorage.getItem('cmms_reachdeck_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        // By default, touchToSpeak must remain false so screen touches and scrolling do not trigger speech unexpectedly
        this.settings = { ...DEFAULT_SETTINGS, ...parsed, touchToSpeak: false };
      } else {
        this.settings = { ...DEFAULT_SETTINGS, touchToSpeak: false };
      }
    } catch (e) {
      console.warn('Failed to load ReachDeck settings from localStorage', e);
      this.settings = { ...DEFAULT_SETTINGS, touchToSpeak: false };
    }
  }

  public saveSettings(newSettings: Partial<ReachDeckSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    try {
      localStorage.setItem('cmms_reachdeck_settings', JSON.stringify(this.settings));
    } catch (e) {
      console.warn('Failed to save ReachDeck settings', e);
    }
    this.applyVisualAssistants();
  }

  public getSettings(): ReachDeckSettings {
    return { ...this.settings };
  }

  private updateVoices() {
    if (this.synth) {
      this.voices = this.synth.getVoices();
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    return this.voices;
  }

  public subscribe(callback: (state: { isSpeaking: boolean; isPaused: boolean; currentWord: string }) => void) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notify() {
    this.listeners.forEach((cb) =>
      cb({
        isSpeaking: this.isSpeaking,
        isPaused: this.isPaused,
        currentWord: this.currentWord,
      })
    );
  }

  // Built-in native Web Speech API & integrated toolbar engine (self-contained, zero external script dependencies)
  private injectReachDeckScript() {
    // Native Web Speech API and integrated toolbar are fully built-in without requiring external script downloads
  }

  // Speak arbitrary text or active page content
  public speak(text?: string) {
    if (!this.synth) {
      console.warn('Speech synthesis not supported in this browser.');
      return;
    }

    this.stop();

    const contentToRead = text || this.extractPageContent();
    if (!contentToRead.trim()) return;

    this.currentUtterance = new SpeechSynthesisUtterance(contentToRead);
    this.currentUtterance.rate = this.settings.rate;
    this.currentUtterance.pitch = this.settings.pitch;
    this.currentUtterance.volume = this.settings.volume;

    // Pick configured voice or appropriate language
    if (this.settings.voiceUri) {
      const selectedVoice = this.voices.find((v) => v.voiceURI === this.settings.voiceUri);
      if (selectedVoice) this.currentUtterance.voice = selectedVoice;
    }

    this.currentUtterance.onstart = () => {
      this.isSpeaking = true;
      this.isPaused = false;
      this.notify();
    };

    this.currentUtterance.onboundary = (event) => {
      if (event.name === 'word') {
        const spokenWord = contentToRead.substr(event.charIndex, event.charLength || 10);
        this.currentWord = spokenWord;
        this.notify();
      }
    };

    this.currentUtterance.onend = () => {
      this.isSpeaking = false;
      this.isPaused = false;
      this.currentWord = '';
      this.notify();
    };

    this.currentUtterance.onerror = (e) => {
      console.warn('[ReachDeck] Speech synthesis error:', e);
      this.isSpeaking = false;
      this.isPaused = false;
      this.notify();
    };

    this.synth.speak(this.currentUtterance);
  }

  public pause() {
    if (this.synth && this.isSpeaking && !this.isPaused) {
      this.synth.pause();
      this.isPaused = true;
      this.notify();
    }
  }

  public resume() {
    if (this.synth && this.isPaused) {
      this.synth.resume();
      this.isPaused = false;
      this.notify();
    }
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
      this.isPaused = false;
      this.currentWord = '';
      this.notify();
    }
  }

  // Reads currently selected text in browser
  public speakSelection() {
    const selection = window.getSelection()?.toString();
    if (selection && selection.trim().length > 0) {
      this.speak(selection);
    } else {
      this.speak();
    }
  }

  // Extract readable text from main application container, excluding scripts/nav boilerplate
  public extractPageContent(): string {
    const mainEl = document.querySelector('main') || document.body;
    const textNodes: string[] = [];

    const walker = document.createTreeWalker(
      mainEl,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tag = parent.tagName.toLowerCase();
          if (['script', 'style', 'noscript', 'svg'].includes(tag)) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.getAttribute('aria-hidden') === 'true') {
            return NodeFilter.FILTER_REJECT;
          }
          const text = node.textContent?.trim();
          return text && text.length > 1 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        },
      }
    );

    let currentNode = walker.nextNode();
    while (currentNode) {
      if (currentNode.textContent) {
        textNodes.push(currentNode.textContent.trim());
      }
      currentNode = walker.nextNode();
    }

    return textNodes.slice(0, 150).join('. ');
  }

  // Apply Visual Accessibility Tools: Reading Ruler & Screen Mask
  public applyVisualAssistants() {
    const rulerId = 'reachdeck-reading-ruler';
    const maskId = 'reachdeck-screen-mask';

    let ruler = document.getElementById(rulerId);
    let mask = document.getElementById(maskId);

    // Reading Ruler
    if (this.settings.readingRuler) {
      if (!ruler) {
        ruler = document.createElement('div');
        ruler.id = rulerId;
        ruler.className = 'fixed left-0 right-0 pointer-events-none z-[9999] bg-yellow-400/25 border-y-2 border-yellow-500/70 backdrop-blur-[0.5px] transition-all duration-75';
        ruler.style.height = '48px';
        ruler.style.top = '50%';
        document.body.appendChild(ruler);

        const onMouseMove = (e: MouseEvent) => {
          if (ruler) {
            ruler.style.top = `${e.clientY - 24}px`;
          }
        };
        window.addEventListener('mousemove', onMouseMove);
      }
    } else if (ruler) {
      ruler.remove();
    }

    // Screen Mask
    if (this.settings.screenMask) {
      if (!mask) {
        mask = document.createElement('div');
        mask.id = maskId;
        mask.className = 'fixed inset-0 pointer-events-none z-[9998] transition-all duration-75';
        mask.innerHTML = `
          <div id="mask-top" class="bg-black/65 absolute left-0 right-0 top-0 transition-all"></div>
          <div id="mask-slot" class="absolute left-0 right-0 h-20 border-y-2 border-blue-400/80 shadow-[0_0_15px_rgba(59,130,246,0.5)]"></div>
          <div id="mask-bottom" class="bg-black/65 absolute left-0 right-0 bottom-0 transition-all"></div>
        `;
        document.body.appendChild(mask);

        const onMaskMove = (e: MouseEvent) => {
          const topEl = document.getElementById('mask-top');
          const slotEl = document.getElementById('mask-slot');
          const botEl = document.getElementById('mask-bottom');
          if (topEl && slotEl && botEl) {
            const slotHeight = 80;
            const topHeight = Math.max(0, e.clientY - slotHeight / 2);
            topEl.style.height = `${topHeight}px`;
            slotEl.style.top = `${topHeight}px`;
            botEl.style.top = `${topHeight + slotHeight}px`;
          }
        };
        window.addEventListener('mousemove', onMaskMove);
      }
    } else if (mask) {
      mask.remove();
    }
  }

  // Generate downloadable audio file placeholder / export
  public async generateAudioDownload(text: string): Promise<string> {
    // Return speech synth stream or mock mp3 audio blob
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve('data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAA=');
      }, 500);
    });
  }
}

export const reachDeck = new ReachDeckService();
