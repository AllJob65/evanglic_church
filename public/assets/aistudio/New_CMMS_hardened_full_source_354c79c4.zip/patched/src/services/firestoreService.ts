import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Member, Branch, Family, Ministry, AttendanceRecord, AuditLog, WorkflowRequest } from '../types';

export const firestoreService = {
  // 1. Members
  async getAllMembers(): Promise<Member[]> {
    const path = 'members';
    try {
      const snap = await getDocs(collection(db, path));
      const members: Member[] = [];
      snap.forEach((d) => {
        members.push({ id: d.id, ...(d.data() as any) });
      });
      return members;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async getMemberById(id: string): Promise<Member | null> {
    const path = `members/${id}`;
    try {
      const snap = await getDoc(doc(db, 'members', id));
      if (!snap.exists()) return null;
      return { id: snap.id, ...(snap.data() as any) };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
    }
  },

  async saveMember(member: Member): Promise<void> {
    const path = `members/${member.id}`;
    try {
      await setDoc(doc(db, 'members', member.id), member, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async deleteMember(id: string): Promise<void> {
    const path = `members/${id}`;
    try {
      await deleteDoc(doc(db, 'members', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // 2. Users
  async getAllUsers(): Promise<any[]> {
    const path = 'users';
    try {
      const snap = await getDocs(collection(db, path));
      const users: any[] = [];
      snap.forEach((d) => {
        users.push({ id: d.id, ...d.data() });
      });
      return users;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async saveUser(userId: string, data: any): Promise<void> {
    const path = `users/${userId}`;
    try {
      await setDoc(doc(db, 'users', userId), data, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // 3. Branches
  async getAllBranches(): Promise<Branch[]> {
    const path = 'branches';
    try {
      const snap = await getDocs(collection(db, path));
      const branches: Branch[] = [];
      snap.forEach((d) => {
        branches.push({ id: d.id, ...(d.data() as any) });
      });
      return branches;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async saveBranch(branch: Branch): Promise<void> {
    const path = `branches/${branch.id}`;
    try {
      await setDoc(doc(db, 'branches', branch.id), branch, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // 4. Audit Logs
  async getAuditLogs(max = 100): Promise<AuditLog[]> {
    const path = 'audit_logs';
    try {
      const q = query(collection(db, path), limit(max));
      const snap = await getDocs(q);
      const logs: AuditLog[] = [];
      snap.forEach((d) => {
        logs.push({ id: d.id, ...(d.data() as any) });
      });
      return logs;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async logAction(action: string, module: string, userEmail: string, details?: string): Promise<void> {
    const path = 'audit_logs';
    try {
      const newDocRef = doc(collection(db, path));
      await setDoc(newDocRef, {
        action,
        module,
        userEmail,
        details: details || '',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // 5. Workflows
  async getAllWorkflows(): Promise<WorkflowRequest[]> {
    const path = 'workflows';
    try {
      const snap = await getDocs(collection(db, path));
      const workflows: WorkflowRequest[] = [];
      snap.forEach((d) => {
        workflows.push({ id: d.id, ...(d.data() as any) });
      });
      return workflows;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  // 6. Attendance
  async getAttendanceRecords(): Promise<AttendanceRecord[]> {
    const path = 'attendance';
    try {
      const snap = await getDocs(collection(db, path));
      const recs: AttendanceRecord[] = [];
      snap.forEach((d) => {
        recs.push({ id: d.id, ...(d.data() as any) });
      });
      return recs;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  // 7. Test write/read
  async ping(): Promise<boolean> {
    const path = 'test/ping';
    try {
      await setDoc(doc(db, 'test', 'ping'), { timestamp: Date.now() }, { merge: true });
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
};
