import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { LmsCourse } from '../types';

export const supabaseLmsService = {
  async getCourses(): Promise<LmsCourse[]> {
    if (!isSupabaseConfigured) return [];

    const { data, error } = await supabase
      .from('lms_courses')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getCourses notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      courseCode: row.course_code || `LMS-${row.id.substring(0, 5)}`,
      title: row.title,
      category: (row.category || 'Discipleship & Foundations') as any,
      instructorName: row.instructor_name || 'Pastor Teacher',
      description: row.description || '',
      totalModules: Number(row.total_modules || 8),
      durationWeeks: Number(row.duration_weeks || 6),
      enrolledStudentsCount: Number(row.enrolled_count || 12),
      passPercentage: Number(row.pass_percentage || 85),
    } as LmsCourse));
  },

  async createCourse(course: Partial<LmsCourse>, tenantId?: string): Promise<LmsCourse> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      course_code: course.courseCode || `LMS-${Math.floor(1000 + Math.random() * 9000)}`,
      title: course.title || 'New Discipleship Course',
      category: course.category || 'Discipleship & Foundations',
      instructor_name: course.instructorName || 'Pastor',
      description: course.description || '',
      total_modules: course.totalModules || 8,
      duration_weeks: course.durationWeeks || 6,
      enrolled_count: course.enrolledStudentsCount || 0,
      pass_percentage: course.passPercentage || 80,
    };

    const { data, error } = await supabase
      .from('lms_courses')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      courseCode: data.course_code,
      title: data.title,
      category: data.category as any,
      instructorName: data.instructor_name,
      description: data.description,
      totalModules: Number(data.total_modules),
      durationWeeks: Number(data.duration_weeks),
      enrolledStudentsCount: Number(data.enrolled_count),
      passPercentage: Number(data.pass_percentage),
    };
  },

  async updateCourse(id: string, updates: Partial<LmsCourse>): Promise<LmsCourse> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload: any = {};
    if (updates.title) payload.title = updates.title;
    if (updates.category) payload.category = updates.category;
    if (updates.instructorName) payload.instructor_name = updates.instructorName;
    if (updates.description !== undefined) payload.description = updates.description;
    if (updates.totalModules !== undefined) payload.total_modules = updates.totalModules;
    if (updates.durationWeeks !== undefined) payload.duration_weeks = updates.durationWeeks;
    if (updates.passPercentage !== undefined) payload.pass_percentage = updates.passPercentage;

    const { data, error } = await supabase
      .from('lms_courses')
      .update(payload)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      courseCode: data.course_code,
      title: data.title,
      category: data.category as any,
      instructorName: data.instructor_name,
      description: data.description,
      totalModules: Number(data.total_modules),
      durationWeeks: Number(data.duration_weeks),
      enrolledStudentsCount: Number(data.enrolled_count),
      passPercentage: Number(data.pass_percentage),
    };
  },

  async deleteCourse(id: string): Promise<boolean> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');
    const { error } = await supabase.from('lms_courses').delete().eq('id', id);
    if (error) throw error;
    return true;
  },
};
