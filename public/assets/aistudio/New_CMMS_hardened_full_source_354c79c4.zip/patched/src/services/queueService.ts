/**
 * Background queue safety boundary.
 *
 * This repository does not currently contain a durable Redis/BullMQ adapter.
 * Do not simulate delivery, backups, or financial aggregation in process memory:
 * callers must receive an explicit unavailable response until a real adapter is
 * configured and health-checked.
 */

export type QueueJobName =
  | 'bulk_sms'
  | 'bulk_email'
  | 'nightly_rollup'
  | 'pastoral_followup'
  | 'data_backup';

export class QueueBackendUnavailableError extends Error {
  public readonly code = 'QUEUE_BACKEND_UNAVAILABLE';

  constructor() {
    super('Durable background processing is not configured.');
    this.name = 'QueueBackendUnavailableError';
  }
}

export class QueueService {
  public getStats() {
    return {
      backend: 'unavailable' as const,
      available: false,
      redisConnected: false,
      totalJobs: 0,
      queued: 0,
      processing: 0,
      completed: 0,
      failed: 0,
    };
  }

  public getJobs(_status?: string) {
    return [];
  }

  public async addJob<T>(_name: QueueJobName, _data: T): Promise<never> {
    throw new QueueBackendUnavailableError();
  }
}

export const queueService = new QueueService();
