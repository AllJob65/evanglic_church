import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Asset } from '../types';

export const supabaseAssetService = {
  async getAssets(branchId?: string): Promise<Asset[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('assets')
      .select('*')
      .order('created_at', { ascending: false });

    if (branchId && branchId !== 'all') {
      query = query.eq('branch_id', branchId);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getAssets notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      assetCode: row.asset_code || `AST-${row.id.substring(0, 5)}`,
      name: row.name,
      category: (row.category || 'Sound & Audio') as any,
      branchId: row.branch_id || 'br-1',
      custodianMemberName: row.custodian_name || 'Church Property Trustee',
      purchaseDate: row.purchase_date || '2023-01-01',
      purchasePrice: Number(row.purchase_price || 0),
      currentValue: Number(row.current_value || 0),
      condition: (row.condition || 'Excellent') as any,
      nextMaintenanceDate: row.next_maintenance || '2026-12-31',
    } as Asset));
  },

  async createAsset(asset: Partial<Asset>, tenantId?: string): Promise<Asset> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: asset.branchId || 'br-1',
      asset_code: asset.assetCode || `AST-${Math.floor(10000 + Math.random() * 90000)}`,
      name: asset.name || 'Church Asset',
      category: asset.category || 'Sound & Audio',
      custodian_name: asset.custodianMemberName || 'Property Trustee',
      purchase_date: asset.purchaseDate || new Date().toISOString().substring(0, 10),
      purchase_price: asset.purchasePrice || 0,
      current_value: asset.currentValue || asset.purchasePrice || 0,
      condition: asset.condition || 'Good',
      next_maintenance: asset.nextMaintenanceDate || '2026-12-31',
    };

    const { data, error } = await supabase
      .from('assets')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      assetCode: data.asset_code,
      name: data.name,
      category: data.category as any,
      branchId: data.branch_id,
      custodianMemberName: data.custodian_name,
      purchaseDate: data.purchase_date,
      purchasePrice: Number(data.purchase_price),
      currentValue: Number(data.current_value),
      condition: data.condition as any,
      nextMaintenanceDate: data.next_maintenance,
    };
  },
};
