import { BibleChapterData, BibleVerseItem, ReadingPlan } from '../data/bibleData';
import { BibleBookInfo, BIBLE_CANON } from '../data/bibleCanon';
import {
  BibleNote,
  BibleHighlight,
  BibleBookmark,
  BibleReadingHistoryEntry,
  BibleReadingPlanProgress,
  YouVersionBible,
  YouVersionPassage,
  YouVersionVerseOfTheDay,
  BibleReaderSettings,
  DEFAULT_BIBLE_READER_SETTINGS,
  BibleReadingPosition,
} from '../types';
import { supabase, isSupabaseConfigured, getStoredAuthToken } from '../lib/supabase';

interface UserHeaders {
  userId?: string;
  userName?: string;
  userRole?: string;
}

function getHeaders(_user?: UserHeaders): HeadersInit {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  const token = typeof window !== 'undefined'
    ? (getStoredAuthToken() || localStorage.getItem('cmms_token') || localStorage.getItem('cmms_access_token'))
    : null;
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export const bibleService = {
  // ==========================================
  // YOUVERSION PLATFORM API METHODS
  // ==========================================

  /**
   * Checks the health of the YouVersion API & Server Proxy
   */
  async getHealth(fresh: boolean = false): Promise<{
    status: 'healthy' | 'degraded' | 'down';
    message: string;
    latencyMs?: number;
    checkedAt?: string;
    cached?: boolean;
    staleCacheAvailable?: boolean;
  }> {
    try {
      const res = await fetch(`/api/bible/health${fresh ? '?fresh=true' : ''}`);
      if (!res.ok) {
        return {
          status: 'down',
          message: `Health check returned HTTP ${res.status}`,
          staleCacheAvailable: true,
        };
      }
      return await res.json();
    } catch (err: any) {
      return {
        status: 'down',
        message: err.message || 'Bible health check failed to respond',
        staleCacheAvailable: true,
      };
    }
  },

  /**
   * Fetches available Bibles directly from the YouVersion Platform API through the secure server proxy
   * Normal users receive the enabled translations (`scope=user`), while System Admin can request `scope=admin`.
   */
  async getYouVersionBibles(languages: string = '*', scope: 'user' | 'admin' = 'user'): Promise<YouVersionBible[]> {
    const cacheKey = `cmms_cache_yvp_bibles_${scope}_${languages}`;
    try {
      const res = await fetch(
        `/api/bible/youversion/bibles?languages=${encodeURIComponent(languages)}&scope=${encodeURIComponent(scope)}`
      );
      if (!res.ok) throw new Error(`Failed to fetch YouVersion bibles: ${res.status}`);
      const data = await res.json();
      const bibles = data.bibles || [];
      if (bibles.length > 0) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(bibles));
        } catch {}
      }
      return bibles;
    } catch (e) {
      console.warn('[BibleService] Error fetching YouVersion bibles, checking stale cache:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      return [];
    }
  },

  async getAvailableBibles(languages?: string, scope: 'user' | 'admin' = 'user'): Promise<YouVersionBible[]> {
    return this.getYouVersionBibles(languages, scope);
  },

  /**
   * System Admin: Retrieves the complete paginated YouVersion catalog (all pages via next_page_token)
   * along with the 6 configured translation slots and admin settings.
   */
  async getAdminBibleTranslations(fresh: boolean = false, user?: UserHeaders): Promise<{
    totalCatalogCount: number;
    userVisibleBibles: YouVersionBible[];
    configuredSlots: any[];
    adminConfig: any;
    allYouVersionBibles: YouVersionBible[];
  }> {
    const res = await fetch(`/api/bible/admin/translations${fresh ? '?fresh=true' : ''}`, {
      headers: getHeaders(user),
    });
    if (!res.ok) throw new Error(`Failed to fetch admin Bible translations: ${res.status}`);
    const data = await res.json();
    return {
      totalCatalogCount: data.totalCatalogCount || 0,
      userVisibleBibles: data.userVisibleBibles || [],
      configuredSlots: data.configuredSlots || [],
      adminConfig: data.adminConfig || null,
      allYouVersionBibles: data.allYouVersionBibles || [],
    };
  },

  /**
   * System Admin: Updates enabled/disabled translations, default Bible, display order, or featured translation
   * without deleting or modifying any Bible study data.
   */
  async updateAdminBibleTranslations(
    user: UserHeaders,
    payload: {
      enabledBibleIds?: number[];
      defaultBibleId?: number;
      featuredBibleId?: number;
      displayOrderMap?: Record<number, number>;
      slotUpdates?: any[];
      toggleBibleId?: number;
      toggleEnabled?: boolean;
      toggleSlotKey?: string;
    }
  ) {
    const res = await fetch('/api/bible/admin/translations', {
      method: 'PUT',
      headers: getHeaders(user),
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`Failed to update admin Bible translations: ${res.status}`);
    return await res.json();
  },

  async getVerseOfTheDay(day?: number): Promise<YouVersionVerseOfTheDay | null> {
    return this.getYouVersionVerseOfTheDay(day);
  },

  /**
   * Fetches metadata for a specific Bible from YouVersion Platform API
   */
  async getYouVersionBibleDetails(bibleId: number | string): Promise<YouVersionBible | null> {
    const cacheKey = `cmms_cache_yvp_bible_${bibleId}`;
    try {
      const res = await fetch(`/api/bible/youversion/bibles/${encodeURIComponent(bibleId)}`);
      if (!res.ok) throw new Error(`Failed to fetch YouVersion bible ${bibleId}`);
      const data = await res.json();
      const bible = data.bible || null;
      if (bible) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(bible));
        } catch {}
      }
      return bible;
    } catch (e) {
      console.warn('[BibleService] Error fetching YouVersion bible details, checking stale cache:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      return null;
    }
  },

  /**
   * Fetches the book structure and chapter breakdown from YouVersion for a Bible
   */
  async getYouVersionBooks(bibleId: number | string): Promise<any[]> {
    const cacheKey = `cmms_cache_yvp_books_${bibleId}`;
    try {
      const res = await fetch(`/api/bible/youversion/bibles/${encodeURIComponent(bibleId)}/books`);
      if (!res.ok) throw new Error(`Failed to fetch books for bible ${bibleId}`);
      const data = await res.json();
      const books = data.books || [];
      if (books.length > 0) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(books));
        } catch {}
      }
      return books;
    } catch (e) {
      console.warn('[BibleService] Error fetching YouVersion books, using stale/canonical fallback:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      return BIBLE_CANON.map((b) => ({
        id: b.id,
        name: b.nameEnglish,
        name_long: `${b.nameEnglish} (${b.nameAmharic})`,
        testament: b.testament,
        category: b.category,
        chapters_count: b.chaptersCount,
      }));
    }
  },

  /**
   * Fetches raw or formatted passage text from YouVersion API
   */
  async getYouVersionPassage(bibleId: number | string, passageId: string): Promise<YouVersionPassage | null> {
    const cacheKey = `cmms_cache_yvp_passage_${bibleId}_${passageId}`;
    try {
      const res = await fetch(`/api/bible/youversion/bibles/${encodeURIComponent(bibleId)}/passages/${encodeURIComponent(passageId)}`);
      if (!res.ok) throw new Error(`Failed to fetch passage ${passageId}`);
      const data = await res.json();
      const passage = data.passage || null;
      if (passage) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(passage));
        } catch {}
      }
      return passage;
    } catch (e) {
      console.warn('[BibleService] Error fetching YouVersion passage, checking stale cache:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      return null;
    }
  },

  /**
   * Fetches the official YouVersion Verse of the Day in Amharic & English
   * Genuine live call with explicit error handling so caller can show inline outage state
   */
  async getYouVersionVerseOfTheDay(day?: number): Promise<YouVersionVerseOfTheDay | null> {
    try {
      const url = day ? `/api/bible/youversion/verse-of-the-day?day=${day}` : '/api/bible/youversion/verse-of-the-day';
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch YouVersion Verse of the Day`);
      const data = await res.json();
      if (!data || (!data.textAmharic && !data.textEnglish)) {
        throw new Error('Verse of the day returned empty content');
      }
      return data;
    } catch (e: any) {
      console.warn('[BibleService] Error fetching YouVersion VOTD:', e.message || e);
      throw e;
    }
  },

  // Public Bible Scripture Fetching
  async getVersions() {
    const cacheKey = 'cmms_cache_bible_versions';
    try {
      const res = await fetch('/api/bible/versions');
      if (!res.ok) throw new Error('Failed to load Bible versions');
      const data = await res.json();
      const result = {
        versions: data.versions || [],
        youversionBibles: (data.youversionBibles || []) as YouVersionBible[],
      };
      if (result.versions.length > 0) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(result));
        } catch {}
      }
      return result;
    } catch (e) {
      console.warn('[BibleService] Error fetching versions, checking stale cache:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      return {
        versions: [
          { id: 'amharic-nasv', youversionBibleId: 1260, name: 'አዲሱ መደበኛ ትርጉም (አማ05)', language: 'Amharic', languageCode: 'am', abbreviation: 'አማ05' },
          { id: 'niv', youversionBibleId: 111, name: 'YouVersion New International Version (NIV)', language: 'English', languageCode: 'en', abbreviation: 'NIV' },
        ],
        youversionBibles: [],
      };
    }
  },

  async getBooks(testament?: string, category?: string): Promise<BibleBookInfo[]> {
    const cacheKey = `cmms_cache_bible_books_${testament || 'all'}_${category || 'all'}`;
    try {
      const params = new URLSearchParams();
      if (testament && testament !== 'All') params.set('testament', testament);
      if (category && category !== 'All') params.set('category', category);

      const res = await fetch(`/api/bible/books?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to load Bible books');
      const data = await res.json();
      const books = data.books || [];
      if (books.length > 0) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(books));
        } catch {}
      }
      return books;
    } catch (e) {
      console.warn('[BibleService] Error fetching books, checking stale cache:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      let fallback = [...BIBLE_CANON];
      if (testament && testament !== 'All') {
        fallback = fallback.filter((b) => b.testament.toLowerCase() === testament.toLowerCase());
      }
      if (category && category !== 'All') {
        fallback = fallback.filter((b) => b.category.toLowerCase() === category.toLowerCase());
      }
      return fallback;
    }
  },

  async getPassage(bookId: string, chapter: number, version: string = 'Parallel'): Promise<BibleChapterData | null> {
    const cacheKey = `cmms_cache_passage_v2_${bookId}_${chapter}_${version}`;
    try {
      const params = new URLSearchParams({
        book: bookId,
        chapter: String(chapter),
        version,
      });
      const res = await fetch(`/api/bible/passage?${params.toString()}`);
      if (!res.ok) throw new Error('Failed to fetch scripture passage');
      const json = await res.json();
      const data = json.data || null;
      if (data) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(data));
        } catch {}
      }
      return data;
    } catch (e) {
      console.warn('[BibleService] Error fetching passage, checking stale cache:', e);
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
      } catch {}
      return null;
    }
  },

  async searchScripture(query: string, testament: string = 'All') {
    try {
      const params = new URLSearchParams({
        q: query,
        testament,
      });
      const res = await fetch(`/api/bible/search?${params.toString()}`);
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json();
      return data.results || [];
    } catch (e) {
      console.warn('[BibleService] Error searching scripture:', e);
      return [];
    }
  },

  async getPlans(): Promise<ReadingPlan[]> {
    try {
      const res = await fetch('/api/bible/plans');
      if (!res.ok) throw new Error('Failed to fetch reading plans');
      const data = await res.json();
      return data.plans || [];
    } catch (e) {
      console.warn('[BibleService] Error fetching plans:', e);
      return [];
    }
  },

  // ==========================================
  // PRIVATE PERSONAL BIBLE ENDPOINTS
  // ==========================================

  // NOTES
  async getUserNotes(user: UserHeaders): Promise<BibleNote[]> {
    try {
      const res = await fetch('/api/bible/user/notes', { headers: getHeaders(user) });
      if (!res.ok) throw new Error('Failed to fetch notes');
      const data = await res.json();
      return data.notes || [];
    } catch (e) {
      console.warn('[BibleService] Error fetching user notes, reading localStorage:', e);
      const saved = localStorage.getItem(`cmms_bible_notes_${user.userId || 'default'}`);
      return saved ? JSON.parse(saved) : [];
    }
  },

  async createNote(user: UserHeaders, note: { bookId: string; chapter: number; verse?: number; passageTitle?: string; noteText: string }): Promise<BibleNote | null> {
    try {
      const res = await fetch('/api/bible/user/notes', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(note),
      });
      if (!res.ok) throw new Error('Failed to create note');
      const data = await res.json();
      return data.note;
    } catch (e) {
      console.error('[BibleService] Error creating note:', e);
      return null;
    }
  },

  async updateNote(user: UserHeaders, id: string, noteText: string, passageTitle?: string): Promise<BibleNote | null> {
    try {
      const res = await fetch(`/api/bible/user/notes/${id}`, {
        method: 'PUT',
        headers: getHeaders(user),
        body: JSON.stringify({ noteText, passageTitle }),
      });
      if (!res.ok) throw new Error('Failed to update note');
      const data = await res.json();
      return data.note;
    } catch (e) {
      console.error('[BibleService] Error updating note:', e);
      return null;
    }
  },

  async deleteNote(user: UserHeaders, id: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/bible/user/notes/${id}`, {
        method: 'DELETE',
        headers: getHeaders(user),
      });
      return res.ok;
    } catch (e) {
      console.error('[BibleService] Error deleting note:', e);
      return false;
    }
  },

  // HIGHLIGHTS
  async getUserHighlights(user: UserHeaders): Promise<BibleHighlight[]> {
    try {
      const res = await fetch('/api/bible/user/highlights', { headers: getHeaders(user) });
      if (!res.ok) throw new Error('Failed to fetch highlights');
      const data = await res.json();
      return data.highlights || [];
    } catch (e) {
      console.warn('[BibleService] Error fetching highlights:', e);
      return [];
    }
  },

  async saveHighlight(user: UserHeaders, highlight: { bookId: string; chapter: number; verse: number; color: string }) {
    try {
      const res = await fetch('/api/bible/user/highlights', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(highlight),
      });
      return res.ok;
    } catch (e) {
      console.error('[BibleService] Error saving highlight:', e);
      return false;
    }
  },

  // BOOKMARKS
  async getUserBookmarks(user: UserHeaders): Promise<BibleBookmark[]> {
    try {
      const res = await fetch('/api/bible/user/bookmarks', { headers: getHeaders(user) });
      if (!res.ok) throw new Error('Failed to fetch bookmarks');
      const data = await res.json();
      return data.bookmarks || [];
    } catch (e) {
      console.warn('[BibleService] Error fetching bookmarks:', e);
      return [];
    }
  },

  async toggleBookmark(user: UserHeaders, bookmark: { bookId: string; bookNameAmharic: string; bookNameEnglish: string; chapter: number; verse: number; verseText: string }) {
    try {
      const res = await fetch('/api/bible/user/bookmarks', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(bookmark),
      });
      if (!res.ok) throw new Error('Failed to toggle bookmark');
      return await res.json();
    } catch (e) {
      console.error('[BibleService] Error toggling bookmark:', e);
      return { success: false };
    }
  },

  async deleteBookmark(user: UserHeaders, id: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/bible/user/bookmarks/${id}`, {
        method: 'DELETE',
        headers: getHeaders(user),
      });
      return res.ok;
    } catch (e) {
      console.error('[BibleService] Error deleting bookmark:', e);
      return false;
    }
  },

  async saveBookmark(user: UserHeaders, bookmark: any) {
    return this.toggleBookmark(user, {
      bookId: bookmark.bookId,
      bookNameAmharic: bookmark.bookAmharic || '',
      bookNameEnglish: bookmark.bookEnglish || '',
      chapter: bookmark.chapter,
      verse: bookmark.verse,
      verseText: bookmark.text || '',
    });
  },

  async saveNote(user: UserHeaders, noteData: { bookId: string; chapter: number; verse: number; note: string; passageTitle?: string }) {
    return this.createNote(user, {
      bookId: noteData.bookId,
      chapter: noteData.chapter,
      verse: noteData.verse,
      noteText: noteData.note,
      passageTitle: noteData.passageTitle,
    });
  },

  // HISTORY
  async getUserHistory(user: UserHeaders): Promise<BibleReadingHistoryEntry[]> {
    try {
      const res = await fetch('/api/bible/user/history', { headers: getHeaders(user) });
      if (!res.ok) throw new Error('Failed to fetch reading history');
      const data = await res.json();
      const history = data.history || [];
      if (user.userId) {
        try { localStorage.setItem(`cmms_bible_history_${user.userId}`, JSON.stringify(history)); } catch {}
      }
      return history;
    } catch (e) {
      console.warn('[BibleService] Error fetching history, checking user-isolated storage:', e);
      if (user.userId) {
        try {
          const saved = localStorage.getItem(`cmms_bible_history_${user.userId}`);
          if (saved) return JSON.parse(saved);
        } catch {}
      }
      return [];
    }
  },

  async recordHistory(user: UserHeaders, bookId: string, bookName: string, chapter: number) {
    if (user.userId) {
      try {
        const key = `cmms_bible_history_${user.userId}`;
        const existing = JSON.parse(localStorage.getItem(key) || '[]');
        const entry = {
          id: `hist-${Date.now()}`,
          userId: user.userId,
          bookId,
          bookName,
          chapter,
          readAt: new Date().toISOString(),
        };
        const updated = [entry, ...existing.filter((h: any) => !(h.bookId === bookId && h.chapter === chapter))].slice(0, 50);
        localStorage.setItem(key, JSON.stringify(updated));
      } catch {}
    }
    try {
      await fetch('/api/bible/user/history', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify({ bookId, bookName, chapter }),
      });
    } catch (e) {
      console.warn('[BibleService] Error recording history:', e);
    }
  },

  // PLAN PROGRESS
  async getUserPlanProgress(user: UserHeaders): Promise<BibleReadingPlanProgress[]> {
    try {
      const res = await fetch('/api/bible/user/plan-progress', { headers: getHeaders(user) });
      if (!res.ok) throw new Error('Failed to fetch plan progress');
      const data = await res.json();
      return data.plans || [];
    } catch (e) {
      console.warn('[BibleService] Error fetching plan progress:', e);
      return [];
    }
  },

  async togglePlanDay(user: UserHeaders, planId: string, day: number) {
    try {
      const res = await fetch('/api/bible/user/plan-progress', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify({ planId, day }),
      });
      if (!res.ok) throw new Error('Failed to toggle plan progress');
      return await res.json();
    } catch (e) {
      console.error('[BibleService] Error toggling plan day:', e);
      return { success: false };
    }
  },

  // ==========================================
  // BIBLE READER SETTINGS & READING POSITION
  // ==========================================

  /**
   * Fetches member's private Bible Reader settings from Supabase / API / Local
   */
  async getUserSettings(user: UserHeaders): Promise<BibleReaderSettings> {
    const userId = user.userId || 'default';
    const localKey = `cmms_bible_settings_${userId}`;

    // 1. Try Supabase if configured
    if (isSupabaseConfigured && user.userId) {
      try {
        const { data, error } = await supabase
          .from('bible_reader_settings')
          .select('*')
          .eq('user_id', user.userId)
          .maybeSingle();

        if (!error && data) {
          const mapped: BibleReaderSettings = {
            id: data.id,
            userId: data.user_id,
            preferredVersionId: data.preferred_version_id || DEFAULT_BIBLE_READER_SETTINGS.preferredVersionId,
            preferredVersionName: data.preferred_version_name,
            preferredVersionAbbreviation: data.preferred_version_abbreviation,
            preferredLanguage: data.preferred_language || DEFAULT_BIBLE_READER_SETTINGS.preferredLanguage,
            fontSize: data.font_size || DEFAULT_BIBLE_READER_SETTINGS.fontSize,
            lineSpacing: data.line_spacing || DEFAULT_BIBLE_READER_SETTINGS.lineSpacing,
            readingWidth: data.reading_width || DEFAULT_BIBLE_READER_SETTINGS.readingWidth,
            theme: data.theme || DEFAULT_BIBLE_READER_SETTINGS.theme,
            showVerseNumbers: data.show_verse_numbers !== undefined ? data.show_verse_numbers : true,
            showFootnotes: data.show_footnotes !== undefined ? data.show_footnotes : true,
            showCrossReferences: data.show_cross_references !== undefined ? data.show_cross_references : true,
            showRedLetters: data.show_red_letters !== undefined ? data.show_red_letters : true,
            rememberReadingPosition: data.remember_reading_position !== undefined ? data.remember_reading_position : true,
            trackReadingHistory: data.track_reading_history !== undefined ? data.track_reading_history : true,
            enableNotes: data.enable_notes !== undefined ? data.enable_notes : true,
            enableHighlights: data.enable_highlights !== undefined ? data.enable_highlights : true,
            enableBookmarks: data.enable_bookmarks !== undefined ? data.enable_bookmarks : true,
            lastReadingPosition: data.last_reading_position || DEFAULT_BIBLE_READER_SETTINGS.lastReadingPosition,
            updatedAt: data.updated_at,
          };
          localStorage.setItem(localKey, JSON.stringify(mapped));
          return mapped;
        }
      } catch (sbErr) {
        console.warn('[BibleService] Supabase settings query skipped:', sbErr);
      }
    }

    // 2. Try Server API Proxy
    try {
      const res = await fetch('/api/bible/user/settings', { headers: getHeaders(user) });
      if (res.ok) {
        const data = await res.json();
        if (data.settings) {
          localStorage.setItem(localKey, JSON.stringify(data.settings));
          return data.settings;
        }
      }
    } catch (apiErr) {
      console.warn('[BibleService] Server settings fetch skipped:', apiErr);
    }

    // 3. Fallback to LocalStorage or Default
    const saved = localStorage.getItem(localKey);
    if (saved) {
      try {
        return { ...DEFAULT_BIBLE_READER_SETTINGS, ...JSON.parse(saved), userId };
      } catch {}
    }

    return { ...DEFAULT_BIBLE_READER_SETTINGS, userId };
  },

  /**
   * Saves member's private Bible Reader settings to Supabase, server DB, and local cache
   */
  async saveUserSettings(user: UserHeaders, partial: Partial<BibleReaderSettings>): Promise<BibleReaderSettings> {
    const userId = user.userId || 'default';
    const localKey = `cmms_bible_settings_${userId}`;
    const current = await this.getUserSettings(user);
    const updated: BibleReaderSettings = {
      ...current,
      ...partial,
      userId,
      updatedAt: new Date().toISOString(),
    };

    localStorage.setItem(localKey, JSON.stringify(updated));

    // 1. Try Supabase upsert
    if (isSupabaseConfigured && user.userId) {
      try {
        await supabase.from('bible_reader_settings').upsert({
          user_id: user.userId,
          preferred_version_id: updated.preferredVersionId,
          preferred_version_name: updated.preferredVersionName,
          preferred_version_abbreviation: updated.preferredVersionAbbreviation,
          preferred_language: updated.preferredLanguage,
          font_size: updated.fontSize,
          line_spacing: updated.lineSpacing,
          reading_width: updated.readingWidth,
          theme: updated.theme,
          show_verse_numbers: updated.showVerseNumbers,
          show_footnotes: updated.showFootnotes,
          show_cross_references: updated.showCrossReferences,
          show_red_letters: updated.showRedLetters,
          remember_reading_position: updated.rememberReadingPosition,
          track_reading_history: updated.trackReadingHistory,
          enable_notes: updated.enableNotes,
          enable_highlights: updated.enableHighlights,
          enable_bookmarks: updated.enableBookmarks,
          last_reading_position: updated.lastReadingPosition,
          updated_at: updated.updatedAt,
        }, { onConflict: 'user_id' });
      } catch (sbErr) {
        console.warn('[BibleService] Supabase settings save error:', sbErr);
      }
    }

    // 2. Save via Server API
    try {
      const res = await fetch('/api/bible/user/settings', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.settings) return data.settings;
      }
    } catch (apiErr) {
      console.warn('[BibleService] Server settings save error:', apiErr);
    }

    return updated;
  },

  /**
   * Resets member's Bible Reader settings to system defaults
   */
  async resetUserSettings(user: UserHeaders): Promise<BibleReaderSettings> {
    const userId = user.userId || 'default';
    const localKey = `cmms_bible_settings_${userId}`;
    const resetSettings: BibleReaderSettings = {
      ...DEFAULT_BIBLE_READER_SETTINGS,
      userId,
      updatedAt: new Date().toISOString(),
    };

    localStorage.setItem(localKey, JSON.stringify(resetSettings));

    // Save to server
    try {
      await fetch('/api/bible/user/settings/reset', {
        method: 'POST',
        headers: getHeaders(user),
      });
    } catch (e) {
      console.warn('[BibleService] Server reset error:', e);
    }

    if (isSupabaseConfigured && user.userId) {
      try {
        await supabase.from('bible_reader_settings').upsert({
          user_id: user.userId,
          preferred_version_id: DEFAULT_BIBLE_READER_SETTINGS.preferredVersionId,
          preferred_version_name: DEFAULT_BIBLE_READER_SETTINGS.preferredVersionName,
          preferred_version_abbreviation: DEFAULT_BIBLE_READER_SETTINGS.preferredVersionAbbreviation,
          preferred_language: DEFAULT_BIBLE_READER_SETTINGS.preferredLanguage,
          font_size: DEFAULT_BIBLE_READER_SETTINGS.fontSize,
          line_spacing: DEFAULT_BIBLE_READER_SETTINGS.lineSpacing,
          reading_width: DEFAULT_BIBLE_READER_SETTINGS.readingWidth,
          theme: DEFAULT_BIBLE_READER_SETTINGS.theme,
          show_verse_numbers: DEFAULT_BIBLE_READER_SETTINGS.showVerseNumbers,
          show_footnotes: DEFAULT_BIBLE_READER_SETTINGS.showFootnotes,
          show_cross_references: DEFAULT_BIBLE_READER_SETTINGS.showCrossReferences,
          show_red_letters: DEFAULT_BIBLE_READER_SETTINGS.showRedLetters,
          remember_reading_position: DEFAULT_BIBLE_READER_SETTINGS.rememberReadingPosition,
          track_reading_history: DEFAULT_BIBLE_READER_SETTINGS.trackReadingHistory,
          enable_notes: DEFAULT_BIBLE_READER_SETTINGS.enableNotes,
          enable_highlights: DEFAULT_BIBLE_READER_SETTINGS.enableHighlights,
          enable_bookmarks: DEFAULT_BIBLE_READER_SETTINGS.enableBookmarks,
          last_reading_position: DEFAULT_BIBLE_READER_SETTINGS.lastReadingPosition,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });
      } catch (sbErr) {
        console.warn('[BibleService] Supabase reset error:', sbErr);
      }
    }

    return resetSettings;
  },

  /**
   * Save last reading location
   */
  async saveReadingPosition(user: UserHeaders, position: BibleReadingPosition): Promise<void> {
    try {
      await fetch('/api/bible/user/position', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(position),
      });
    } catch (e) {
      console.warn('[BibleService] Error saving reading position:', e);
    }
  },

  // ==========================================
  // PASTOR / MANAGER BIBLE MESSAGES & INBOX
  // ==========================================

  /**
   * Calculate recipient count for message targeting
   */
  async getRecipientCount(type: string, targetIds: string[] = []): Promise<{ count: number; sampleNames: string[] }> {
    try {
      const q = new URLSearchParams({
        type,
        targetIds: targetIds.join(','),
      });
      const res = await fetch(`/api/bible/recipient-count?${q.toString()}`);
      if (!res.ok) throw new Error(`Recipient count failed: ${res.status}`);
      const data = await res.json();
      return { count: data.count || 0, sampleNames: data.sampleNames || [] };
    } catch (e) {
      console.warn('[BibleService] Error calculating recipient count:', e);
      return { count: 0, sampleNames: [] };
    }
  },

  /**
   * Fetch Bible messages for management dashboard
   */
  async getMessages(params?: { status?: string; search?: string; translation?: string; book?: string }): Promise<{ messages: any[]; stats: any }> {
    try {
      const q = new URLSearchParams();
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.translation) q.append('translation', params.translation);
      if (params?.book) q.append('book', params.book);

      const res = await fetch(`/api/bible/messages?${q.toString()}`);
      if (!res.ok) throw new Error(`Failed to fetch messages: ${res.status}`);
      const data = await res.json();
      return {
        messages: data.messages || [],
        stats: data.stats || { total: 0, sent: 0, scheduled: 0, drafts: 0, cancelled: 0 },
      };
    } catch (e) {
      console.warn('[BibleService] Error fetching messages:', e);
      return { messages: [], stats: { total: 0, sent: 0, scheduled: 0, drafts: 0, cancelled: 0 } };
    }
  },

  /**
   * Fetch single message details with delivery metrics
   */
  async getMessageById(id: string): Promise<any> {
    try {
      const res = await fetch(`/api/bible/messages/${encodeURIComponent(id)}`);
      if (!res.ok) throw new Error(`Message ${id} not found`);
      return await res.json();
    } catch (e) {
      console.warn('[BibleService] Error fetching message by id:', e);
      return null;
    }
  },

  /**
   * Create (Draft, Schedule, or Send) a new Bible message
   */
  async createMessage(user: UserHeaders, payload: any): Promise<any> {
    try {
      const res = await fetch('/api/bible/messages', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || `Failed to create message: ${res.status}`);
      }
      return await res.json();
    } catch (e: any) {
      console.error('[BibleService] Create message error:', e);
      throw e;
    }
  },

  /**
   * Update an existing draft or scheduled message
   */
  async updateMessage(user: UserHeaders, id: string, payload: any): Promise<any> {
    try {
      const res = await fetch(`/api/bible/messages/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: getHeaders(user),
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || `Failed to update message: ${res.status}`);
      }
      return await res.json();
    } catch (e: any) {
      console.error('[BibleService] Update message error:', e);
      throw e;
    }
  },

  /**
   * Send a draft or scheduled message immediately
   */
  async sendMessageNow(user: UserHeaders, id: string): Promise<any> {
    try {
      const res = await fetch(`/api/bible/messages/${encodeURIComponent(id)}/send`, {
        method: 'POST',
        headers: getHeaders(user),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || `Failed to send message: ${res.status}`);
      }
      return await res.json();
    } catch (e: any) {
      console.error('[BibleService] Send message error:', e);
      throw e;
    }
  },

  /**
   * Cancel a scheduled message
   */
  async cancelMessage(user: UserHeaders, id: string): Promise<any> {
    try {
      const res = await fetch(`/api/bible/messages/${encodeURIComponent(id)}/cancel`, {
        method: 'POST',
        headers: getHeaders(user),
      });
      if (!res.ok) throw new Error(`Failed to cancel message: ${res.status}`);
      return await res.json();
    } catch (e: any) {
      console.error('[BibleService] Cancel message error:', e);
      throw e;
    }
  },

  /**
   * Duplicate a message as a new draft
   */
  async duplicateMessage(user: UserHeaders, id: string): Promise<any> {
    try {
      const res = await fetch(`/api/bible/messages/${encodeURIComponent(id)}/duplicate`, {
        method: 'POST',
        headers: getHeaders(user),
      });
      if (!res.ok) throw new Error(`Failed to duplicate message: ${res.status}`);
      return await res.json();
    } catch (e: any) {
      console.error('[BibleService] Duplicate message error:', e);
      throw e;
    }
  },

  /**
   * Delete a draft or scheduled message
   */
  async deleteMessage(user: UserHeaders, id: string): Promise<any> {
    try {
      const res = await fetch(`/api/bible/messages/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getHeaders(user),
      });
      if (!res.ok) throw new Error(`Failed to delete message: ${res.status}`);
      return await res.json();
    } catch (e: any) {
      console.error('[BibleService] Delete message error:', e);
      throw e;
    }
  },

  /**
   * Fetch member's personal Bible message inbox
   */
  async getUserInbox(user: UserHeaders): Promise<{ items: any[]; unreadCount: number }> {
    try {
      const res = await fetch('/api/bible/user/inbox', {
        headers: getHeaders(user),
      });
      if (!res.ok) throw new Error(`Failed to fetch inbox: ${res.status}`);
      const data = await res.json();
      return {
        items: data.items || [],
        unreadCount: data.unreadCount || 0,
      };
    } catch (e) {
      console.warn('[BibleService] Error fetching member inbox:', e);
      return { items: [], unreadCount: 0 };
    }
  },

  /**
   * Mark a message as read in member's inbox
   */
  async markInboxMessageRead(user: UserHeaders, messageId: string): Promise<void> {
    try {
      await fetch(`/api/bible/user/inbox/${encodeURIComponent(messageId)}/read`, {
        method: 'POST',
        headers: getHeaders(user),
      });
    } catch (e) {
      console.warn('[BibleService] Error marking inbox message read:', e);
    }
  },
};

