import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { EventItem } from '../types';

export const supabaseEventService = {
  async getEvents(branchId?: string): Promise<EventItem[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('events')
      .select('*')
      .order('start_date', { ascending: true });

    if (branchId && branchId !== 'all') {
      query = query.eq('branch_id', branchId);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getEvents notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      title: row.title,
      type: (row.event_type || 'Conference') as any,
      branchId: row.branch_id || 'br-1',
      startDate: row.start_date || new Date().toISOString(),
      endDate: row.end_date || new Date().toISOString(),
      location: row.location || 'Main Auditorium',
      description: row.description || '',
      speakerNames: row.speakers || [],
      capacity: row.capacity || 500,
      registeredCount: row.registered_count || 0,
      isPaid: row.is_paid || false,
      ticketPrice: Number(row.ticket_price || 0),
      status: (row.status || 'Upcoming') as any,
    } as EventItem));
  },

  async createEvent(event: Partial<EventItem>, tenantId?: string): Promise<EventItem> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      branch_id: event.branchId || 'br-1',
      title: event.title || 'Church Event',
      event_type: event.type || 'Conference',
      start_date: event.startDate || new Date().toISOString(),
      end_date: event.endDate || new Date().toISOString(),
      location: event.location || 'Main Auditorium',
      description: event.description || '',
      speakers: event.speakerNames || [],
      capacity: event.capacity || 500,
      registered_count: event.registeredCount || 0,
      is_paid: event.isPaid || false,
      ticket_price: event.ticketPrice || 0,
      status: event.status || 'Upcoming',
    };

    const { data, error } = await supabase
      .from('events')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      title: data.title,
      type: data.event_type as any,
      branchId: data.branch_id,
      startDate: data.start_date,
      endDate: data.end_date,
      location: data.location,
      description: data.description,
      speakerNames: data.speakers || [],
      capacity: data.capacity,
      registeredCount: data.registered_count,
      isPaid: data.is_paid,
      ticketPrice: Number(data.ticket_price),
      status: data.status as any,
    };
  },

  async updateEvent(id: string, updates: Partial<EventItem>): Promise<EventItem> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload: any = {};
    if (updates.title) payload.title = updates.title;
    if (updates.type) payload.event_type = updates.type;
    if (updates.startDate) payload.start_date = updates.startDate;
    if (updates.endDate) payload.end_date = updates.endDate;
    if (updates.location) payload.location = updates.location;
    if (updates.description !== undefined) payload.description = updates.description;
    if (updates.speakerNames) payload.speakers = updates.speakerNames;
    if (updates.capacity !== undefined) payload.capacity = updates.capacity;
    if (updates.registeredCount !== undefined) payload.registered_count = updates.registeredCount;
    if (updates.status) payload.status = updates.status;

    const { data, error } = await supabase
      .from('events')
      .update(payload)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      title: data.title,
      type: data.event_type as any,
      branchId: data.branch_id,
      startDate: data.start_date,
      endDate: data.end_date,
      location: data.location,
      description: data.description,
      speakerNames: data.speakers || [],
      capacity: data.capacity,
      registeredCount: data.registered_count,
      isPaid: data.is_paid,
      ticketPrice: Number(data.ticket_price),
      status: data.status as any,
    };
  },

  async deleteEvent(id: string): Promise<boolean> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');
    const { error } = await supabase.from('events').delete().eq('id', id);
    if (error) throw error;
    return true;
  },
};
