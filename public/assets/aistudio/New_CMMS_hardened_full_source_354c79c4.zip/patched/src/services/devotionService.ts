import { Devotion, DevotionReaction, DevotionComment, DevotionReactionType, DevotionStatus } from '../types';
import { getStoredAuthToken } from '../lib/supabase';

interface UserHeaders {
  userId?: string;
  userName?: string;
  userRole?: string;
}

function getHeaders(_user?: UserHeaders): HeadersInit {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  const token = typeof window !== 'undefined'
    ? (getStoredAuthToken() || localStorage.getItem('cmms_token') || localStorage.getItem('cmms_access_token'))
    : null;
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export const devotionService = {
  async getDevotions(user?: UserHeaders, filter?: { topic?: string; status?: string; search?: string }): Promise<Devotion[]> {
    try {
      const params = new URLSearchParams();
      if (filter?.topic && filter.topic !== 'All') params.set('topic', filter.topic);
      if (filter?.status && filter.status !== 'all') params.set('status', filter.status);
      if (filter?.search) params.set('search', filter.search);

      const res = await fetch(`/api/devotions?${params.toString()}`, {
        headers: getHeaders(user),
      });
      if (!res.ok) throw new Error('Failed to fetch devotions');
      const data = await res.json();
      return data.devotions || [];
    } catch (e) {
      console.warn('[DevotionService] Error fetching devotions:', e);
      return [];
    }
  },

  async getTodayDevotion(user?: UserHeaders): Promise<Devotion | null> {
    try {
      const res = await fetch('/api/devotions/today', {
        headers: getHeaders(user),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.devotion || null;
    } catch (e) {
      console.warn('[DevotionService] Error fetching today devotion:', e);
      return null;
    }
  },

  async getDevotionById(id: string, user?: UserHeaders): Promise<Devotion | null> {
    try {
      const res = await fetch(`/api/devotions/${id}`, {
        headers: getHeaders(user),
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.devotion || null;
    } catch (e) {
      console.error('[DevotionService] Error fetching devotion by ID:', e);
      return null;
    }
  },

  async createDevotion(user: UserHeaders, devotion: Partial<Devotion>): Promise<Devotion | null> {
    try {
      const res = await fetch('/api/devotions', {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify(devotion),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to create devotion');
      }
      const data = await res.json();
      return data.devotion;
    } catch (e) {
      console.error('[DevotionService] Error creating devotion:', e);
      throw e;
    }
  },

  async updateDevotion(user: UserHeaders, id: string, devotion: Partial<Devotion>): Promise<Devotion | null> {
    try {
      const res = await fetch(`/api/devotions/${id}`, {
        method: 'PUT',
        headers: getHeaders(user),
        body: JSON.stringify(devotion),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to update devotion');
      }
      const data = await res.json();
      return data.devotion;
    } catch (e) {
      console.error('[DevotionService] Error updating devotion:', e);
      throw e;
    }
  },

  async updateStatus(user: UserHeaders, id: string, status: DevotionStatus): Promise<Devotion | null> {
    try {
      const res = await fetch(`/api/devotions/${id}/status`, {
        method: 'PUT',
        headers: getHeaders(user),
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error('Failed to update status');
      const data = await res.json();
      return data.devotion;
    } catch (e) {
      console.error('[DevotionService] Error updating devotion status:', e);
      return null;
    }
  },

  async deleteDevotion(user: UserHeaders, id: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/devotions/${id}`, {
        method: 'DELETE',
        headers: getHeaders(user),
      });
      return res.ok;
    } catch (e) {
      console.error('[DevotionService] Error deleting devotion:', e);
      return false;
    }
  },

  async toggleReaction(user: UserHeaders, devotionId: string, reactionType: DevotionReactionType) {
    try {
      const res = await fetch(`/api/devotions/${devotionId}/reactions`, {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify({ reactionType }),
      });
      if (!res.ok) throw new Error('Reaction failed');
      return await res.json();
    } catch (e) {
      console.error('[DevotionService] Error toggling reaction:', e);
      return null;
    }
  },

  async getComments(devotionId: string): Promise<DevotionComment[]> {
    try {
      const res = await fetch(`/api/devotions/${devotionId}/comments`);
      if (!res.ok) throw new Error('Failed to fetch comments');
      const data = await res.json();
      return data.comments || [];
    } catch (e) {
      console.warn('[DevotionService] Error fetching comments:', e);
      return [];
    }
  },

  async addComment(user: UserHeaders, devotionId: string, commentText: string): Promise<DevotionComment | null> {
    try {
      const res = await fetch(`/api/devotions/${devotionId}/comments`, {
        method: 'POST',
        headers: getHeaders(user),
        body: JSON.stringify({ commentText }),
      });
      if (!res.ok) throw new Error('Failed to post comment');
      const data = await res.json();
      return data.comment;
    } catch (e) {
      console.error('[DevotionService] Error adding comment:', e);
      return null;
    }
  },

  async deleteComment(user: UserHeaders, devotionId: string, commentId: string): Promise<boolean> {
    try {
      const res = await fetch(`/api/devotions/${devotionId}/comments/${commentId}`, {
        method: 'DELETE',
        headers: getHeaders(user),
      });
      return res.ok;
    } catch (e) {
      console.error('[DevotionService] Error deleting comment:', e);
      return false;
    }
  },
};
