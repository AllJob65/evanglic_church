import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Family } from '../types';

export const supabaseFamilyService = {
  async getFamilies(): Promise<Family[]> {
    if (!isSupabaseConfigured) return [];

    const { data, error } = await supabase
      .from('families')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getFamilies notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      familyCode: row.family_code || `FAM-${row.id.substring(0, 5)}`,
      householdName: row.household_name || 'Family Household',
      headOfHouseholdMemberId: row.head_member_id || 'mem-head',
      primaryHouseholdPhone: row.primary_phone || '+251 91 100 0000',
      familyType: (row.family_type || 'Nuclear Family') as any,
      primaryLanguage: row.primary_language || 'Amharic',
      address: row.address || 'Addis Ababa',
      city: row.city || 'Addis Ababa',
      region: row.region || 'Addis Ababa',
      memberIds: row.member_ids || [],
      relationships: row.relationships || [],
      registrationDate: row.created_at?.substring(0, 10) || new Date().toISOString().substring(0, 10),
      status: (row.status || 'Active') as any,
    } as Family));
  },

  async createFamily(family: Partial<Family>, tenantId?: string): Promise<Family> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      family_code: family.familyCode || `FAM-${Math.floor(10000 + Math.random() * 90000)}`,
      household_name: family.householdName || 'Household',
      head_member_id: family.headOfHouseholdMemberId || null,
      primary_phone: family.primaryHouseholdPhone || '',
      family_type: family.familyType || 'Nuclear Family',
      primary_language: family.primaryLanguage || 'Amharic',
      address: family.address || '',
      city: family.city || 'Addis Ababa',
      region: family.region || 'Addis Ababa',
      member_ids: family.memberIds || [],
      relationships: family.relationships || [],
      status: family.status || 'Active',
    };

    const { data, error } = await supabase
      .from('families')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      familyCode: data.family_code,
      householdName: data.household_name,
      headOfHouseholdMemberId: data.head_member_id || 'mem-head',
      primaryHouseholdPhone: data.primary_phone,
      familyType: data.family_type as any,
      primaryLanguage: data.primary_language,
      address: data.address,
      city: data.city,
      region: data.region,
      memberIds: data.member_ids || [],
      relationships: data.relationships || [],
      registrationDate: data.created_at?.substring(0, 10),
      status: data.status as any,
    };
  },

  async updateFamily(id: string, updates: Partial<Family>): Promise<Family> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload: any = {};
    if (updates.householdName) payload.household_name = updates.householdName;
    if (updates.headOfHouseholdMemberId) payload.head_member_id = updates.headOfHouseholdMemberId;
    if (updates.primaryHouseholdPhone !== undefined) payload.primary_phone = updates.primaryHouseholdPhone;
    if (updates.familyType) payload.family_type = updates.familyType;
    if (updates.primaryLanguage) payload.primary_language = updates.primaryLanguage;
    if (updates.address !== undefined) payload.address = updates.address;
    if (updates.city !== undefined) payload.city = updates.city;
    if (updates.memberIds) payload.member_ids = updates.memberIds;
    if (updates.relationships) payload.relationships = updates.relationships;
    if (updates.status) payload.status = updates.status;

    const { data, error } = await supabase
      .from('families')
      .update(payload)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      familyCode: data.family_code,
      householdName: data.household_name,
      headOfHouseholdMemberId: data.head_member_id || 'mem-head',
      primaryHouseholdPhone: data.primary_phone,
      familyType: data.family_type as any,
      primaryLanguage: data.primary_language,
      address: data.address,
      city: data.city,
      region: data.region,
      memberIds: data.member_ids || [],
      relationships: data.relationships || [],
      registrationDate: data.created_at?.substring(0, 10),
      status: data.status as any,
    };
  },

  async deleteFamily(id: string): Promise<boolean> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');
    const { error } = await supabase.from('families').delete().eq('id', id);
    if (error) throw error;
    return true;
  },
};
