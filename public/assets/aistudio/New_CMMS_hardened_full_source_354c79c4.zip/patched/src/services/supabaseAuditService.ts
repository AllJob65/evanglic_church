import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { AuditLog } from '../types';

export const supabaseAuditService = {
  async getAuditLogs(): Promise<AuditLog[]> {
    if (!isSupabaseConfigured) return [];

    const { data, error } = await supabase
      .from('audit_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      console.warn('Supabase getAuditLogs notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      timestamp: row.created_at || new Date().toISOString(),
      userEmail: row.user_email || 'admin@gracechurch.org',
      userName: row.user_name || 'System Admin',
      userRole: (row.user_role || 'SUPER_ADMIN') as any,
      action: row.action || 'ACCESS',
      module: row.module || 'System',
      ipAddress: row.ip_address || '197.156.104.22',
      location: row.location || 'Addis Ababa, ET',
      details: row.details || 'Audit event logged',
    } as AuditLog));
  },

  async addAuditLog(log: {
    action: string;
    moduleName: string;
    details: string;
    user?: string;
    userRole?: string;
    tenantId?: string;
  }): Promise<boolean> {
    if (!isSupabaseConfigured) return false;

    const payload = {
      tenant_id: log.tenantId || 'tenant-grace-main',
      user_email: log.user || 'admin@gracechurch.org',
      user_name: log.user || 'System User',
      user_role: log.userRole || 'SUPER_ADMIN',
      action: log.action,
      module: log.moduleName,
      details: log.details,
      ip_address: '197.156.104.22',
      location: 'Addis Ababa, ET',
    };

    const { error } = await supabase.from('audit_logs').insert([payload]);
    if (error) {
      console.warn('Supabase addAuditLog error:', error.message);
      return false;
    }
    return true;
  },
};
