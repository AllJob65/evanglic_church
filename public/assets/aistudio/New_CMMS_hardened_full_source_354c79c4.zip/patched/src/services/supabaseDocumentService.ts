import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DocumentItem } from '../types';

export const supabaseDocumentService = {
  async getDocuments(category?: string): Promise<DocumentItem[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('documents')
      .select('*')
      .order('created_at', { ascending: false });

    if (category && category !== 'all') {
      query = query.eq('category', category);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getDocuments notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      title: row.title,
      category: (row.category || 'Church Policies & Handbooks') as any,
      fileFormat: row.file_format || 'PDF',
      fileSizeMb: Number(row.file_size_mb || 1.2),
      uploadedBy: row.uploaded_by || 'Church Secretary',
      uploadDate: row.created_at?.substring(0, 10) || new Date().toISOString().substring(0, 10),
      version: row.version || 'v1.0',
      isConfidential: row.is_confidential || false,
      tags: row.tags || ['Policy', 'Church'],
      downloadCount: Number(row.download_count || 0),
      fileUrl: row.file_url,
    } as DocumentItem));
  },

  async createDocument(doc: Partial<DocumentItem>, tenantId?: string): Promise<DocumentItem> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      title: doc.title || 'Church Document',
      category: doc.category || 'Church Policies & Handbooks',
      file_format: doc.fileFormat || 'PDF',
      file_size_mb: doc.fileSizeMb || 1.0,
      uploaded_by: doc.uploadedBy || 'Administrator',
      version: doc.version || 'v1.0',
      is_confidential: doc.isConfidential || false,
      tags: doc.tags || [],
      file_url: doc.fileUrl || '',
    };

    const { data, error } = await supabase
      .from('documents')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      title: data.title,
      category: data.category as any,
      fileFormat: data.file_format,
      fileSizeMb: Number(data.file_size_mb),
      uploadedBy: data.uploaded_by,
      uploadDate: data.created_at.substring(0, 10),
      version: data.version,
      isConfidential: data.is_confidential,
      tags: data.tags || [],
      downloadCount: 0,
      fileUrl: data.file_url,
    };
  },

  async deleteDocument(id: string): Promise<boolean> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');
    const { error } = await supabase.from('documents').delete().eq('id', id);
    if (error) throw error;
    return true;
  },
};
