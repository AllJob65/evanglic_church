import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Ministry, MinistryChatMessage, MinistryMemberRecord, MinistryActivityLog, MinistryVideoRoom, VideoParticipant } from '../types';

// Fallback stores (empty by default; authoritative data comes from backend/PostgreSQL)
const fallbackMessages: Record<string, MinistryChatMessage[]> = {};

const fallbackMembers: Record<string, MinistryMemberRecord[]> = {};

const fallbackActivityLogs: Record<string, MinistryActivityLog[]> = {};

export const supabaseMinistryService = {
  // 1. GET ALL MINISTRIES
  async getMinistries(branchId?: string): Promise<Ministry[]> {
    if (!isSupabaseConfigured) return this.getDefaultMinistries();

    try {
      let query = supabase.from('ministries').select('*').order('created_at', { ascending: true });
      if (branchId && branchId !== 'all') {
        query = query.eq('branch_id', branchId);
      }

      const { data, error } = await query;
      if (error || !data || data.length === 0) {
        return this.getDefaultMinistries();
      }

      return data.map((row: any) => ({
        id: row.id,
        name: row.name,
        category: row.category || 'General',
        leaderName: row.leader_name || '',
        directorMemberId: row.director_member_id || '',
        description: row.description || '',
        branchId: row.branch_id || '',
        establishedDate: row.established_date || '',
        status: row.status || 'Active',
        memberCount: Number(row.member_count) || 0,
        annualBudget: Number(row.annual_budget) || 0,
        spentBudget: Number(row.spent_budget) || 0,
      } as Ministry));
    } catch (err) {
      console.warn('Supabase ministries fetch fallback:', err);
      return this.getDefaultMinistries();
    }
  },

  getDefaultMinistries(): Ministry[] {
    return [];
  },

  // 2. CREATE A NEW MINISTRY
  async createMinistry(ministry: Partial<Ministry>, tenantId?: string): Promise<Ministry> {
    if (!isSupabaseConfigured) {
      const newM: Ministry = {
        id: `min-${Date.now().toString().slice(-4)}`,
        name: ministry.name || 'New Ministry',
        category: ministry.category || 'General',
        leaderName: ministry.leaderName || 'Leader',
        directorMemberId: ministry.directorMemberId || 'mem-director',
        description: ministry.description || '',
        branchId: ministry.branchId || 'br-1',
        establishedDate: new Date().toISOString().substring(0, 10),
        status: 'Active',
        memberCount: 1,
        annualBudget: ministry.annualBudget || 15000,
        spentBudget: 0,
      };
      return newM;
    }

    try {
      const payload = {
        branch_id: ministry.branchId || 'br-001',
        name: ministry.name || 'New Ministry',
        description: ministry.description || '',
        category: ministry.category || 'General',
        leader_name: ministry.leaderName || 'Leader',
        director_member_id: ministry.directorMemberId || null,
        annual_budget: ministry.annualBudget || 15000,
        spent_budget: 0,
        status: 'Active',
      };

      const { data, error } = await supabase
        .from('ministries')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;

      await this.createActivityLog(data.id, {
        title: 'Ministry Established',
        description: `${data.name} was successfully created.`,
        actionType: 'budget_updated',
      });

      return {
        id: data.id,
        name: data.name,
        category: data.category,
        leaderName: data.leader_name,
        directorMemberId: data.director_member_id || 'mem-director',
        description: data.description || '',
        branchId: data.branch_id,
        establishedDate: data.established_date || new Date().toISOString().substring(0, 10),
        status: data.status || 'Active',
        memberCount: 1,
        annualBudget: Number(data.annual_budget) || 15000,
        spentBudget: 0,
      };
    } catch (err) {
      console.warn('Supabase createMinistry fallback:', err);
      return {
        id: `min-${Date.now().toString().slice(-4)}`,
        name: ministry.name || 'New Ministry',
        category: ministry.category || 'General',
        leaderName: ministry.leaderName || 'Leader',
        directorMemberId: ministry.directorMemberId || 'mem-director',
        description: ministry.description || '',
        branchId: ministry.branchId || 'br-1',
        establishedDate: new Date().toISOString().substring(0, 10),
        status: 'Active',
        memberCount: 1,
        annualBudget: ministry.annualBudget || 15000,
        spentBudget: 0,
      };
    }
  },

  // 3. GET MINISTRY MEMBERS
  async getMinistryMembers(ministryId: string): Promise<MinistryMemberRecord[]> {
    if (!isSupabaseConfigured) return fallbackMembers[ministryId] || [];

    try {
      const { data, error } = await supabase
        .from('ministry_members')
        .select(`
          id,
          ministry_id,
          user_id,
          role,
          status,
          joined_at,
          profiles:user_id (full_name, email, avatar_url)
        `)
        .eq('ministry_id', ministryId)
        .order('joined_at', { ascending: true });

      if (error || !data || data.length === 0) {
        return fallbackMembers[ministryId] || [];
      }

      return data.map((row: any) => ({
        id: row.id,
        ministryId: row.ministry_id,
        userId: row.user_id,
        userName: row.profiles?.full_name || 'Ministry Member',
        userEmail: row.profiles?.email || undefined,
        userAvatar: row.profiles?.avatar_url || undefined,
        role: row.role || 'Member',
        status: row.status || 'Active',
        joinedAt: row.joined_at,
      }));
    } catch (err) {
      console.warn('Supabase getMinistryMembers fallback:', err);
      return fallbackMembers[ministryId] || [];
    }
  },

  // 4. ADD MINISTRY MEMBER
  async addMinistryMember(
    ministryId: string,
    userId: string,
    role: 'Leader' | 'CoLeader' | 'Member' | 'Volunteer' = 'Member',
    userName?: string,
    userEmail?: string,
    userAvatar?: string
  ): Promise<MinistryMemberRecord> {
    const newRecord: MinistryMemberRecord = {
      id: `mm-${Date.now()}`,
      ministryId,
      userId,
      userName: userName || 'Fellowship Member',
      userEmail,
      userAvatar,
      role,
      status: 'Active',
      joinedAt: new Date().toISOString(),
    };

    if (!isSupabaseConfigured) {
      if (!fallbackMembers[ministryId]) fallbackMembers[ministryId] = [];
      fallbackMembers[ministryId].push(newRecord);
      return newRecord;
    }

    try {
      const { data, error } = await supabase
        .from('ministry_members')
        .upsert(
          [
            {
              ministry_id: ministryId,
              user_id: userId,
              role,
              status: 'Active',
            },
          ],
          { onConflict: 'ministry_id,user_id' }
        )
        .select()
        .single();

      if (error) throw error;

      await this.createActivityLog(ministryId, {
        userId,
        userName: userName || 'Member',
        actionType: 'member_joined',
        title: 'New Member Joined',
        description: `${userName || 'A member'} joined as ${role}.`,
      });

      return {
        id: data.id,
        ministryId: data.ministry_id,
        userId: data.user_id,
        userName: userName || 'Ministry Member',
        userEmail,
        userAvatar,
        role: data.role,
        status: data.status,
        joinedAt: data.joined_at,
      };
    } catch (err) {
      console.warn('Supabase addMinistryMember fallback:', err);
      if (!fallbackMembers[ministryId]) fallbackMembers[ministryId] = [];
      fallbackMembers[ministryId].push(newRecord);
      return newRecord;
    }
  },

  // 5. GET MINISTRY MESSAGES (WITH REACTIONS)
  async getMinistryMessages(ministryId: string, limit = 100): Promise<MinistryChatMessage[]> {
    if (!isSupabaseConfigured) return fallbackMessages[ministryId] || [];

    try {
      const { data: messagesData, error: msgError } = await supabase
        .from('ministry_messages')
        .select('*')
        .eq('ministry_id', ministryId)
        .order('created_at', { ascending: true })
        .limit(limit);

      if (msgError || !messagesData || messagesData.length === 0) {
        return fallbackMessages[ministryId] || [];
      }

      // Fetch reactions for these messages
      const messageIds = messagesData.map((m: any) => m.id);
      const { data: reactionsData } = await supabase
        .from('ministry_message_reactions')
        .select('*')
        .in('message_id', messageIds);

      // Group reactions by message_id
      const reactionsByMsg: Record<string, { emoji: string; count: number; users: string[] }[]> = {};
      (reactionsData || []).forEach((r: any) => {
        if (!reactionsByMsg[r.message_id]) reactionsByMsg[r.message_id] = [];
        const existing = reactionsByMsg[r.message_id].find((x) => x.emoji === r.emoji);
        if (existing) {
          existing.count += 1;
          if (r.user_id && !existing.users.includes(r.user_id)) {
            existing.users.push(r.user_id);
          }
        } else {
          reactionsByMsg[r.message_id].push({
            emoji: r.emoji,
            count: 1,
            users: r.user_id ? [r.user_id] : [],
          });
        }
      });

      return messagesData.map((row: any) => ({
        id: row.id,
        tenantId: 'tenant-grace-main',
        ministryId: row.ministry_id,
        ministryName: 'Ministry Fellowship',
        senderId: row.sender_id || 'usr-anon',
        senderName: row.sender_name || 'Member',
        senderEmail: row.sender_email || '',
        senderRole: row.sender_role || 'Member',
        senderAvatar: row.sender_avatar || undefined,
        text: row.text,
        scriptureRef: row.scripture_ref || undefined,
        attachmentUrl: row.attachment_url || undefined,
        attachmentName: row.attachment_name || undefined,
        timestamp: row.created_at,
        reactions: reactionsByMsg[row.id] || [],
      }));
    } catch (err) {
      console.warn('Supabase getMinistryMessages fallback:', err);
      return fallbackMessages[ministryId] || [];
    }
  },

  // 6. SEND MINISTRY MESSAGE
  async sendMinistryMessage(
    ministryId: string,
    payload: {
      text: string;
      scriptureRef?: string;
      attachmentUrl?: string;
      attachmentName?: string;
      senderId?: string;
      senderName: string;
      senderEmail?: string;
      senderRole?: string;
      senderAvatar?: string;
    }
  ): Promise<MinistryChatMessage> {
    const fallbackNewMsg: MinistryChatMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      tenantId: 'tenant-grace-main',
      ministryId,
      ministryName: 'Ministry Fellowship',
      senderId: payload.senderId || 'usr-current',
      senderName: payload.senderName,
      senderEmail: payload.senderEmail || '',
      senderRole: payload.senderRole || 'Member',
      senderAvatar: payload.senderAvatar,
      text: payload.text,
      scriptureRef: payload.scriptureRef,
      attachmentUrl: payload.attachmentUrl,
      attachmentName: payload.attachmentName,
      timestamp: new Date().toISOString(),
      reactions: [],
    };

    if (!isSupabaseConfigured) {
      if (!fallbackMessages[ministryId]) fallbackMessages[ministryId] = [];
      fallbackMessages[ministryId].push(fallbackNewMsg);
      return fallbackNewMsg;
    }

    try {
      const insertData = {
        ministry_id: ministryId,
        sender_id: payload.senderId || null,
        sender_name: payload.senderName,
        sender_email: payload.senderEmail || null,
        sender_role: payload.senderRole || 'Member',
        sender_avatar: payload.senderAvatar || null,
        text: payload.text,
        scripture_ref: payload.scriptureRef || null,
        attachment_url: payload.attachmentUrl || null,
        attachment_name: payload.attachmentName || null,
        is_pinned: false,
      };

      const { data, error } = await supabase
        .from('ministry_messages')
        .insert([insertData])
        .select()
        .single();

      if (error) throw error;

      // Activity log
      await this.createActivityLog(ministryId, {
        userId: payload.senderId,
        userName: payload.senderName,
        actionType: 'message_posted',
        title: 'New Fellowship Message',
        description: payload.scriptureRef ? `Shared scripture: ${payload.scriptureRef}` : payload.text.substring(0, 60),
      });

      return {
        id: data.id,
        tenantId: 'tenant-grace-main',
        ministryId: data.ministry_id,
        ministryName: 'Ministry Fellowship',
        senderId: data.sender_id || 'usr-current',
        senderName: data.sender_name,
        senderEmail: data.sender_email || '',
        senderRole: data.sender_role,
        senderAvatar: data.sender_avatar || undefined,
        text: data.text,
        scriptureRef: data.scripture_ref || undefined,
        attachmentUrl: data.attachment_url || undefined,
        attachmentName: data.attachment_name || undefined,
        timestamp: data.created_at,
        reactions: [],
      };
    } catch (err) {
      console.warn('Supabase sendMinistryMessage fallback:', err);
      if (!fallbackMessages[ministryId]) fallbackMessages[ministryId] = [];
      fallbackMessages[ministryId].push(fallbackNewMsg);
      return fallbackNewMsg;
    }
  },

  // 7. REACT TO MINISTRY MESSAGE
  async reactToMinistryMessage(
    ministryId: string,
    messageId: string,
    emoji: string,
    userId: string,
    userName: string
  ): Promise<{ emoji: string; count: number; users: string[] }[]> {
    if (!isSupabaseConfigured) {
      const list = fallbackMessages[ministryId] || [];
      const msg = list.find((m) => m.id === messageId);
      if (msg) {
        if (!msg.reactions) msg.reactions = [];
        const existing = msg.reactions.find((r) => r.emoji === emoji);
        if (existing) {
          if (!existing.users.includes(userId)) {
            existing.users.push(userId);
            existing.count += 1;
          }
        } else {
          msg.reactions.push({ emoji, count: 1, users: [userId] });
        }
        return msg.reactions;
      }
      return [{ emoji, count: 1, users: [userId] }];
    }

    try {
      // Upsert reaction
      await supabase
        .from('ministry_message_reactions')
        .upsert(
          [
            {
              message_id: messageId,
              user_id: userId,
              user_name: userName,
              emoji,
            },
          ],
          { onConflict: 'message_id,user_id,emoji' }
        );

      // Re-fetch all reactions for this message
      const { data } = await supabase
        .from('ministry_message_reactions')
        .select('*')
        .eq('message_id', messageId);

      const reactions: { emoji: string; count: number; users: string[] }[] = [];
      (data || []).forEach((r: any) => {
        const item = reactions.find((x) => x.emoji === r.emoji);
        if (item) {
          item.count += 1;
          if (r.user_id && !item.users.includes(r.user_id)) item.users.push(r.user_id);
        } else {
          reactions.push({
            emoji: r.emoji,
            count: 1,
            users: r.user_id ? [r.user_id] : [],
          });
        }
      });

      return reactions;
    } catch (err) {
      console.warn('Supabase reactToMinistryMessage fallback:', err);
      return [{ emoji, count: 1, users: [userId] }];
    }
  },

  // 8. DELETE MINISTRY MESSAGE (Admins, Leaders, or Senders)
  async deleteMinistryMessage(ministryId: string, messageId: string): Promise<boolean> {
    if (!isSupabaseConfigured) {
      if (fallbackMessages[ministryId]) {
        fallbackMessages[ministryId] = fallbackMessages[ministryId].filter((m) => m.id !== messageId);
      }
      return true;
    }

    try {
      const { error } = await supabase
        .from('ministry_messages')
        .delete()
        .eq('id', messageId);

      if (error) throw error;
      return true;
    } catch (err) {
      console.warn('Supabase deleteMinistryMessage fallback:', err);
      return false;
    }
  },

  // 9. ACTIVITY LOGS
  async getActivityLogs(ministryId: string, limit = 20): Promise<MinistryActivityLog[]> {
    if (!isSupabaseConfigured) return fallbackActivityLogs[ministryId] || [];

    try {
      const { data, error } = await supabase
        .from('ministry_activity_logs')
        .select('*')
        .eq('ministry_id', ministryId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error || !data || data.length === 0) {
        return fallbackActivityLogs[ministryId] || [];
      }

      return data.map((row: any) => ({
        id: row.id,
        ministryId: row.ministry_id,
        userId: row.user_id || undefined,
        userName: row.user_name || undefined,
        actionType: row.action_type,
        title: row.title,
        description: row.description || undefined,
        createdAt: row.created_at,
      }));
    } catch (err) {
      console.warn('Supabase getActivityLogs fallback:', err);
      return fallbackActivityLogs[ministryId] || [];
    }
  },

  async createActivityLog(
    ministryId: string,
    log: {
      userId?: string;
      userName?: string;
      actionType: 'message_posted' | 'reaction_added' | 'member_joined' | 'member_left' | 'video_started' | 'video_joined' | 'budget_updated' | 'todo_completed';
      title: string;
      description?: string;
    }
  ): Promise<MinistryActivityLog> {
    const newLog: MinistryActivityLog = {
      id: `act-${Date.now()}`,
      ministryId,
      userId: log.userId,
      userName: log.userName,
      actionType: log.actionType,
      title: log.title,
      description: log.description,
      createdAt: new Date().toISOString(),
    };

    if (!isSupabaseConfigured) {
      if (!fallbackActivityLogs[ministryId]) fallbackActivityLogs[ministryId] = [];
      fallbackActivityLogs[ministryId].unshift(newLog);
      return newLog;
    }

    try {
      const { data, error } = await supabase
        .from('ministry_activity_logs')
        .insert([
          {
            ministry_id: ministryId,
            user_id: log.userId || null,
            user_name: log.userName || null,
            action_type: log.actionType,
            title: log.title,
            description: log.description || null,
          },
        ])
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        ministryId: data.ministry_id,
        userId: data.user_id,
        userName: data.user_name,
        actionType: data.action_type,
        title: data.title,
        description: data.description,
        createdAt: data.created_at,
      };
    } catch (err) {
      console.warn('Supabase createActivityLog fallback:', err);
      if (!fallbackActivityLogs[ministryId]) fallbackActivityLogs[ministryId] = [];
      fallbackActivityLogs[ministryId].unshift(newLog);
      return newLog;
    }
  },

  // 10. REALTIME SUPABASE SUBSCRIPTION FOR MINISTRY CHAT
  subscribeToMinistryMessages(
    ministryId: string,
    callbacks: {
      onNewMessage?: (msg: MinistryChatMessage) => void;
      onReactionUpdated?: (messageId: string, reactions: { emoji: string; count: number; users: string[] }[]) => void;
      onMessageDeleted?: (messageId: string) => void;
      onTyping?: (userName: string, isTyping: boolean) => void;
    }
  ) {
    if (!isSupabaseConfigured) {
      return {
        unsubscribe: () => {},
        broadcastTyping: () => {},
      };
    }

    const channelName = `ministry_chat_${ministryId}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase.channel(channelName, {
      config: {
        broadcast: { self: false },
        presence: { key: ministryId },
      },
    });

    // 1. Listen for new messages in PostgreSQL
    channel.on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'ministry_messages',
        filter: `ministry_id=eq.${ministryId}`,
      },
      (payload) => {
        const row = payload.new;
        if (row && callbacks.onNewMessage) {
          callbacks.onNewMessage({
            id: row.id,
            tenantId: 'tenant-grace-main',
            ministryId: row.ministry_id,
            ministryName: 'Ministry Fellowship',
            senderId: row.sender_id || 'usr-anon',
            senderName: row.sender_name || 'Member',
            senderEmail: row.sender_email || '',
            senderRole: row.sender_role || 'Member',
            senderAvatar: row.sender_avatar || undefined,
            text: row.text,
            scriptureRef: row.scripture_ref || undefined,
            attachmentUrl: row.attachment_url || undefined,
            attachmentName: row.attachment_name || undefined,
            timestamp: row.created_at,
            reactions: [],
          });
        }
      }
    );

    // 2. Listen for deleted messages
    channel.on(
      'postgres_changes',
      {
        event: 'DELETE',
        schema: 'public',
        table: 'ministry_messages',
      },
      (payload) => {
        if (payload.old?.id && callbacks.onMessageDeleted) {
          callbacks.onMessageDeleted(payload.old.id);
        }
      }
    );

    // 3. Listen for reaction changes
    channel.on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'ministry_message_reactions',
      },
      async (payload) => {
        const msgId = (payload.new as any)?.message_id || (payload.old as any)?.message_id;
        if (msgId && callbacks.onReactionUpdated) {
          const { data } = await supabase
            .from('ministry_message_reactions')
            .select('*')
            .eq('message_id', msgId);

          const reactions: { emoji: string; count: number; users: string[] }[] = [];
          (data || []).forEach((r: any) => {
            const item = reactions.find((x) => x.emoji === r.emoji);
            if (item) {
              item.count += 1;
              if (r.user_id && !item.users.includes(r.user_id)) item.users.push(r.user_id);
            } else {
              reactions.push({
                emoji: r.emoji,
                count: 1,
                users: r.user_id ? [r.user_id] : [],
              });
            }
          });

          callbacks.onReactionUpdated(msgId, reactions);
        }
      }
    );

    // 4. Realtime Broadcast for typing indicators
    channel.on('broadcast', { event: 'typing' }, (eventPayload) => {
      if (callbacks.onTyping && eventPayload.payload) {
        callbacks.onTyping(eventPayload.payload.userName, eventPayload.payload.isTyping);
      }
    });

    channel.subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log(`[Supabase Realtime] Connected to ministry channel: ${channelName}`);
      }
    });

    return {
      unsubscribe: () => {
        supabase.removeChannel(channel);
      },
      broadcastTyping: (userName: string, isTyping: boolean) => {
        channel.send({
          type: 'broadcast',
          event: 'typing',
          payload: { userName, isTyping },
        });
      },
    };
  },

  // 11. REALTIME SUBSCRIPTION FOR MINISTRY ACTIVITY STREAM
  subscribeToMinistryActivity(
    ministryId: string,
    onActivity: (activity: MinistryActivityLog) => void
  ) {
    if (!isSupabaseConfigured) {
      return { unsubscribe: () => {} };
    }

    const channelName = `ministry_activity_${ministryId}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase.channel(channelName);

    channel.on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'ministry_activity_logs',
        filter: `ministry_id=eq.${ministryId}`,
      },
      (payload) => {
        const row = payload.new;
        if (row && onActivity) {
          onActivity({
            id: row.id,
            ministryId: row.ministry_id,
            userId: row.user_id || undefined,
            userName: row.user_name || undefined,
            actionType: row.action_type,
            title: row.title,
            description: row.description || undefined,
            createdAt: row.created_at,
          });
        }
      }
    );

    channel.subscribe();

    return {
      unsubscribe: () => {
        supabase.removeChannel(channel);
      },
    };
  },

  /**
   * Start a Live Video Conference in Supabase Postgres
   */
  async startVideoConference(params: {
    tenantId?: string;
    ministryId: string;
    leaderProfileId: string;
    title?: string;
    roomUrl?: string;
  }): Promise<{ data: any; error: any }> {
    const roomName = `CMMS-Group-${params.ministryId.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`;
    const roomUrl = params.roomUrl || `https://meet.jit.si/${roomName}#config.prejoinPageEnabled=false&config.startWithAudioMuted=false`;

    if (!isSupabaseConfigured) {
      const fallbackConf = {
        id: `conf-${params.ministryId}-${Date.now()}`,
        tenant_id: params.tenantId || 'tenant-grace-main',
        ministry_id: params.ministryId,
        leader_profile_id: params.leaderProfileId,
        title: params.title || 'Live Group Video Conference',
        room_url: roomUrl,
        status: 'active',
        created_at: new Date().toISOString(),
      };
      return { data: fallbackConf, error: null };
    }

    try {
      // First mark any existing active calls as ended
      await supabase
        .from('video_conferences')
        .update({ status: 'ended' })
        .eq('ministry_id', params.ministryId)
        .eq('status', 'active');

      const { data, error } = await supabase
        .from('video_conferences')
        .insert([
          {
            tenant_id: params.tenantId || 'tenant-grace-main',
            ministry_id: params.ministryId,
            leader_profile_id: params.leaderProfileId,
            title: params.title || 'Live Group Video Conference',
            room_url: roomUrl,
            status: 'active',
          },
        ])
        .select()
        .single();

      if (error) {
        console.warn('Supabase startVideoConference error, returning fallback:', error.message);
      }
      return { data: data || { room_url: roomUrl, title: params.title || 'Live Video Call' }, error };
    } catch (err: any) {
      console.warn('Supabase startVideoConference exception:', err);
      return { data: { room_url: roomUrl, title: params.title || 'Live Video Call' }, error: err };
    }
  },

  /**
   * Fetch currently active video call for a ministry group
   */
  async getActiveVideoConference(ministryId: string) {
    if (!isSupabaseConfigured) {
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('video_conferences')
        .select('*')
        .eq('ministry_id', ministryId)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .maybeSingle();

      if (error) {
        console.warn('Error fetching active video conference from Supabase:', error.message);
        return null;
      }
      return data;
    } catch (err) {
      console.warn('Exception fetching active video conference:', err);
      return null;
    }
  },

  /**
   * End an active video conference in Supabase
   */
  async endVideoConference(conferenceId: string) {
    if (!isSupabaseConfigured) return { success: true };

    try {
      const { data, error } = await supabase
        .from('video_conferences')
        .update({ status: 'ended' })
        .eq('id', conferenceId);

      return { success: !error, error };
    } catch (err) {
      return { success: false, error: err };
    }
  },

  /**
   * Start a Live Group Chat session in Supabase
   */
  async startGroupChatSession(params: {
    tenantId?: string;
    ministryId: string;
    leaderProfileId: string;
  }) {
    if (!isSupabaseConfigured) {
      return {
        id: `chat-${params.ministryId}-${Date.now()}`,
        ministry_id: params.ministryId,
        leader_profile_id: params.leaderProfileId,
        is_active: true,
        created_at: new Date().toISOString(),
      };
    }

    try {
      const { data, error } = await supabase
        .from('group_chats')
        .insert([
          {
            tenant_id: params.tenantId || 'tenant-grace-main',
            ministry_id: params.ministryId,
            leader_profile_id: params.leaderProfileId,
            is_active: true,
          },
        ])
        .select()
        .single();

      if (error) {
        console.warn('Error starting group chat in Supabase:', error.message);
      }
      return data;
    } catch (err) {
      console.warn('Exception starting group chat session:', err);
      return null;
    }
  },

  /**
   * Subscribe to Supabase Realtime video_conferences changes
   */
  subscribeToVideoConferences(
    ministryId: string,
    callbacks: {
      onStarted?: (conference: any) => void;
      onEnded?: (conferenceId: string) => void;
    }
  ) {
    if (!isSupabaseConfigured) {
      return { unsubscribe: () => {} };
    }

    const channelName = `video_conf_${ministryId}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'video_conferences',
          filter: `ministry_id=eq.${ministryId}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT' && payload.new && (payload.new as any).status === 'active') {
            callbacks.onStarted?.(payload.new);
          } else if (payload.eventType === 'UPDATE' && payload.new && (payload.new as any).status === 'ended') {
            callbacks.onEnded?.((payload.new as any).id);
          }
        }
      )
      .subscribe();

    return {
      unsubscribe: () => {
        supabase.removeChannel(channel);
      },
    };
  },

  /**
   * Subscribe to Supabase Realtime group_chats changes
   */
  subscribeToGroupChats(
    ministryId: string,
    callbacks: {
      onStarted?: (session: any) => void;
      onEnded?: (sessionId: string) => void;
    }
  ) {
    if (!isSupabaseConfigured) {
      return { unsubscribe: () => {} };
    }

    const channelName = `group_chat_${ministryId}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'group_chats',
          filter: `ministry_id=eq.${ministryId}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT' && payload.new && (payload.new as any).is_active) {
            callbacks.onStarted?.(payload.new);
          } else if (payload.eventType === 'UPDATE' && payload.new && !(payload.new as any).is_active) {
            callbacks.onEnded?.((payload.new as any).id);
          }
        }
      )
      .subscribe();

    return {
      unsubscribe: () => {
        supabase.removeChannel(channel);
      },
    };
  },
};

