import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { VolunteerShift } from '../types';

export const supabaseVolunteerService = {
  async getVolunteerShifts(ministryId?: string): Promise<VolunteerShift[]> {
    if (!isSupabaseConfigured) return [];

    let query = supabase
      .from('volunteer_shifts')
      .select('*')
      .order('shift_date', { ascending: true });

    if (ministryId && ministryId !== 'all') {
      query = query.eq('ministry_id', ministryId);
    }

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getVolunteerShifts notice:', error.message);
      return [];
    }

    return (data || []).map(row => ({
      id: row.id,
      volunteerMemberId: row.volunteer_member_id || 'mem-vol',
      volunteerName: row.volunteer_name || 'Church Volunteer',
      ministryId: row.ministry_id || 'min-1',
      ministryName: row.ministry_name || 'Hospitality Ministry',
      roleTitle: row.role_title || 'Lead Usher',
      shiftDate: row.shift_date || new Date().toISOString().substring(0, 10),
      startTime: row.start_time || '08:30 AM',
      endTime: row.end_time || '12:30 PM',
      status: (row.status || 'Scheduled') as any,
      hoursLogged: Number(row.hours_logged || 4),
    } as VolunteerShift));
  },

  async createVolunteerShift(shift: Partial<VolunteerShift>, tenantId?: string): Promise<VolunteerShift> {
    if (!isSupabaseConfigured) throw new Error('Supabase not configured');

    const payload = {
      tenant_id: tenantId || 'tenant-grace-main',
      volunteer_member_id: shift.volunteerMemberId || null,
      volunteer_name: shift.volunteerName || 'Volunteer',
      ministry_id: shift.ministryId || 'min-1',
      ministry_name: shift.ministryName || 'Ministry',
      role_title: shift.roleTitle || 'Server',
      shift_date: shift.shiftDate || new Date().toISOString().substring(0, 10),
      start_time: shift.startTime || '08:30 AM',
      end_time: shift.endTime || '12:30 PM',
      status: shift.status || 'Scheduled',
      hours_logged: shift.hoursLogged || 4,
    };

    const { data, error } = await supabase
      .from('volunteer_shifts')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      volunteerMemberId: data.volunteer_member_id || 'mem-vol',
      volunteerName: data.volunteer_name,
      ministryId: data.ministry_id,
      ministryName: data.ministry_name,
      roleTitle: data.role_title,
      shiftDate: data.shift_date,
      startTime: data.start_time,
      endTime: data.end_time,
      status: data.status as any,
      hoursLogged: Number(data.hours_logged),
    };
  },
};
