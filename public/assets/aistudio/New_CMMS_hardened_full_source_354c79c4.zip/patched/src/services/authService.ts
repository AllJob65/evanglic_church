import { adminSupabase } from '../lib/supabase';
import { UserRole } from '../types';
import { db } from '../../server/db';

export class AuthService {
  /**
   * Authoritative Supabase Auth Login.
   * Supabase Auth is the single source of truth for credentials and sessions.
   * Role and permissions are authoritative from public.profiles table.
   */
  public async login(email: string, password?: string) {
    if (!email) {
      throw new Error('Email address is required');
    }

    if (!password) {
      throw new Error('Password is required');
    }

    // 1. Authoritative login via Supabase Auth
    const { data, error } = await adminSupabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    if (error || !data.user) {
      throw new Error(error?.message || 'Invalid email or password');
    }

    const authUser = data.user;
    const session = data.session;

    // 2. Query authoritative profile from public.profiles
    let role: UserRole = 'REGULAR_MEMBER';
    let branchName = 'Headquarters Campus';
    let branchIds = ['br-1'];
    let name = authUser.user_metadata?.full_name || authUser.user_metadata?.name || email.split('@')[0];

    try {
      const { data: profile } = await adminSupabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();

      if (profile) {
        role = (profile.role as UserRole) || 'REGULAR_MEMBER';
        branchIds = profile.branch_id ? [profile.branch_id] : branchIds;
        name = profile.full_name || profile.display_name || name;
      }
    } catch {
      if (authUser.app_metadata?.role) {
        role = authUser.app_metadata.role;
      }
    }

    db.addAuditLog(
      'User Authenticated',
      'Authentication',
      `User ${email} successfully authenticated via Supabase Auth as ${role}`,
      email
    );

    return {
      user: {
        id: authUser.id,
        name,
        email: authUser.email || email,
        role,
        branchName,
        branchIds,
        isMfaEnabled: false,
      },
      tokens: {
        accessToken: session?.access_token || '',
        refreshToken: session?.refresh_token || '',
        expiresIn: session?.expires_in || 3600,
      },
    };
  }

  public async refreshToken(refreshToken: string) {
    if (!refreshToken) {
      throw new Error('Refresh token is required');
    }

    const { data, error } = await adminSupabase.auth.refreshSession({
      refresh_token: refreshToken,
    });

    if (error || !data.session) {
      throw new Error(error?.message || 'Invalid refresh token');
    }

    return {
      accessToken: data.session.access_token,
      refreshToken: data.session.refresh_token,
      expiresIn: data.session.expires_in,
    };
  }

  public async logout(userId: string, email: string) {
    await adminSupabase.auth.signOut();

    db.addAuditLog(
      'User Logged Out',
      'Authentication',
      `Session terminated for ${email}`,
      email
    );

    return { success: true };
  }
}

export const authService = new AuthService();
