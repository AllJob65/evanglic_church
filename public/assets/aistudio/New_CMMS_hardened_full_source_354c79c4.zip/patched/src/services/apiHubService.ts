import { ApiKeyRecord, WebhookSubscription, SupabaseConnectionStatus, SmsGatewayConfig } from '../types';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export const apiHubService = {
  // 1. Supabase Live Diagnostics & Connection Checker
  async checkSupabaseConnection(): Promise<SupabaseConnectionStatus> {
    const startTime = Date.now();
    const envUrl = (import.meta.env?.VITE_SUPABASE_URL || '').trim();
    const envAnon = (import.meta.env?.VITE_SUPABASE_ANON_KEY || '').trim();

    try {
      // First query backend status
      const serverRes = await fetch('/api/v1/external/supabase/status');
      const serverData = await serverRes.json();

      // If client environment variables are available, run a live Supabase client ping
      if (isSupabaseConfigured) {
        try {
          const clientStart = Date.now();
          const { error } = await supabase.from('members').select('id', { count: 'exact', head: true });
          const clientLatency = Date.now() - clientStart;

          if (!error) {
            return {
              isConfigured: true,
              url: envUrl,
              anonKeyConfigured: true,
              isConnected: true,
              latencyMs: clientLatency,
              tablesFound: ['members', 'branches', 'attendance_records', 'families', 'ministries'],
              lastChecked: new Date().toISOString(),
              rowCountEstimates: serverData.rowCountEstimates,
            };
          }
        } catch (clientErr) {
          console.warn('[Supabase Client Ping Error]:', clientErr);
        }
      }

      return {
        isConfigured: serverData.isConfigured || isSupabaseConfigured,
        url: serverData.url || envUrl || 'Not Configured',
        anonKeyConfigured: serverData.anonKeyConfigured || Boolean(envAnon),
        isConnected: serverData.isConnected,
        latencyMs: serverData.latencyMs,
        tablesFound: serverData.tablesFound,
        lastChecked: new Date().toISOString(),
        error: serverData.error,
        rowCountEstimates: serverData.rowCountEstimates,
      };
    } catch (err: any) {
      return {
        isConfigured: isSupabaseConfigured,
        url: envUrl || 'Offline / Local',
        anonKeyConfigured: Boolean(envAnon),
        isConnected: false,
        latencyMs: Date.now() - startTime,
        lastChecked: new Date().toISOString(),
        error: err.message || 'Failed to ping Supabase status endpoint',
      };
    }
  },

  // 2. API Keys Management
  async getApiKeys(): Promise<ApiKeyRecord[]> {
    const res = await fetch('/api/v1/external/keys');
    const json = await res.json();
    return json.data || [];
  },

  async createApiKey(payload: {
    name: string;
    scopes: string[];
    rateLimitPerMin: number;
    description?: string;
  }): Promise<{ success: boolean; data: ApiKeyRecord; message: string }> {
    const res = await fetch('/api/v1/external/keys', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async deleteApiKey(id: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/v1/external/keys/${id}`, {
      method: 'DELETE',
    });
    return res.json();
  },

  // 3. Webhook Subscriptions Management
  async getWebhooks(): Promise<WebhookSubscription[]> {
    const res = await fetch('/api/v1/external/webhooks');
    const json = await res.json();
    return json.data || [];
  },

  async createWebhook(payload: {
    name: string;
    targetUrl: string;
    events: string[];
  }): Promise<{ success: boolean; data: WebhookSubscription; message: string }> {
    const res = await fetch('/api/v1/external/webhooks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async deleteWebhook(id: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/v1/external/webhooks/${id}`, {
      method: 'DELETE',
    });
    return res.json();
  },

  async testWebhook(webhookId: string, event: string): Promise<any> {
    const res = await fetch('/api/v1/external/webhooks/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ webhookId, event }),
    });
    return res.json();
  },

  // 4. SMS Gateway Config & Testing
  async getSmsConfig(): Promise<SmsGatewayConfig> {
    const res = await fetch('/api/v1/external/sms/config');
    const json = await res.json();
    return json.data;
  },

  async updateSmsConfig(config: Partial<SmsGatewayConfig>): Promise<SmsGatewayConfig> {
    const res = await fetch('/api/v1/external/sms/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    const json = await res.json();
    return json.data;
  },

  async sendTestSms(payload: {
    recipients: string[];
    message: string;
    senderId?: string;
    gateway?: string;
  }): Promise<any> {
    const res = await fetch('/api/integrations/sms/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // 5. Live Endpoint Simulator
  async executeApiTest(
    endpoint: string,
    method: 'GET' | 'POST' = 'GET',
    apiKey: string,
    body?: any
  ): Promise<{ status: number; durationMs: number; data: any; headers: Record<string, string> }> {
    const startTime = Date.now();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-API-Key': apiKey,
    };

    const res = await fetch(endpoint, {
      method,
      headers,
      body: body && method === 'POST' ? JSON.stringify(body) : undefined,
    });

    const durationMs = Date.now() - startTime;
    let data;
    try {
      data = await res.json();
    } catch {
      data = { text: await res.text() };
    }

    return {
      status: res.status,
      durationMs,
      data,
      headers: {
        'content-type': res.headers.get('content-type') || 'application/json',
      },
    };
  },
};
