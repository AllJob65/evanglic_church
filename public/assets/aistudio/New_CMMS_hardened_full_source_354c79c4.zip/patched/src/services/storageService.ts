import { supabase, isSupabaseConfigured, getStoredAuthToken } from '../lib/supabase';

export type StorageBucketName =
  | 'member-photos'
  | 'church-branding'
  | 'documents-vault'
  | 'chat-attachments';

export interface StorageUploadResult {
  success: boolean;
  bucket: StorageBucketName;
  path: string;
  publicUrl: string;
  provider: 'supabase-storage';
}

/**
 * Authoritative Supabase Storage Service
 * Consolidates all file uploads (member avatars, church logos/favicons, document vault files, chat attachments)
 * through the Express backend (/api/system/storage/upload) -> Supabase Storage buckets, with direct
 * Supabase Storage SDK support when configured.
 */
export const storageService = {
  async uploadFile(
    file: File,
    bucket: StorageBucketName = 'documents-vault',
    folder: string = 'uploads'
  ): Promise<StorageUploadResult> {
    const token = getStoredAuthToken();
    const tenantId =
      typeof window !== 'undefined'
        ? localStorage.getItem('cmms_tenant_id') || 'tenant-grace-main'
        : 'tenant-grace-main';

    // 1. Primary path: Upload via authoritative Express backend (/api/system/storage/upload)
    // which uses the server-side Supabase Storage client & enforces RBAC + Audit Logging
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('bucket', bucket);
      formData.append('folder', folder);

      const res = await fetch('/api/system/storage/upload', {
        method: 'POST',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          'X-Tenant-ID': tenantId,
        },
        body: formData,
      });

      const data = await res.json().catch(() => null);
      if (res.ok && data?.publicUrl) {
        return {
          success: true,
          bucket,
          path: data.path || `${folder}/${file.name}`,
          publicUrl: data.publicUrl,
          provider: 'supabase-storage',
        };
      }
      throw new Error(data?.error || `Upload failed (HTTP ${res.status}).`);
    } catch (err) {
      console.warn('[StorageService] Upload failed:', err);
      throw err instanceof Error ? err : new Error('Upload failed.');
    }

    // The browser must NOT upload straight to Supabase Storage: that path skips server-side RBAC,
    // type sniffing, bucket allowlisting and audit logging (and used `upsert: true` with a
    // client-chosen path). Any failure above is surfaced to the caller instead.
    throw new Error('Failed to upload file to Supabase Storage.');
  },
};
