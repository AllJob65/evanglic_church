import {
  Member,
  Family,
  Branch,
  Ministry,
  AttendanceRecord,
  AttendanceSession,
  EventItem,
  CommunicationMessage,
  CommunicationLog,
  CommunicationLogsSummary,
  CommunicationSystemStatus,
  PrayerRequest,
  CounselingSession,
  VisitationRecord,
  VolunteerShift,
  Asset,
  DocumentItem,
  LmsCourse,
  WorkflowRequest,
  AuditLog,
  SystemUser,
  UserRole,
  Conversation,
  ConversationMessage,
  MinistryAnnualPlan,
  MinistryQuarterlyReport,
  MinistryAnnualReport,
  ProfileChangeRequest,
  RegistrationInvitationRecord,
  RegistrationExpirationPreset,
} from '../types';
import {
  supabase,
  isSupabaseConfigured,
  getStoredAuthToken,
  getStoredRefreshToken,
  storeAuthToken,
  storeRefreshToken,
  storeAuthUser,
  isRememberMeActive,
} from '../lib/supabase';
import { storageService, StorageBucketName } from './storageService';

const API_BASE = '/api';

// In-Flight Request Deduplication Map: avoids concurrent duplicate network calls
const inFlightRequests = new Map<string, Promise<any>>();
let inFlightTokenRefresh: Promise<string | null> | null = null;

async function attemptSilentTokenRefresh(): Promise<string | null> {
  if (inFlightTokenRefresh) {
    return inFlightTokenRefresh;
  }

  inFlightTokenRefresh = (async () => {
    try {
      const refreshToken = getStoredRefreshToken();
      const accessToken = getStoredAuthToken();
      const res = await fetch(`${API_BASE}/auth/refresh`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        },
        body: JSON.stringify(refreshToken ? { refreshToken } : {}),
      });

      if (res.ok) {
        const data = await res.json().catch(() => null);
        const nextToken = data?.token || data?.tokens?.accessToken || data?.session?.access_token;
        const nextRefresh = data?.refreshToken || data?.tokens?.refreshToken || data?.session?.refresh_token;
        const remember = isRememberMeActive();
        if (nextToken) {
          storeAuthToken(nextToken, remember);
        }
        if (nextRefresh) {
          storeRefreshToken(nextRefresh, remember);
        }
        if (data?.user) {
          storeAuthUser(data.user, remember);
        }
        return nextToken || accessToken || null;
      }
    } catch {
      // ignore network error during background refresh
    } finally {
      inFlightTokenRefresh = null;
    }
    return null;
  })();

  return inFlightTokenRefresh;
}

// Safe Client-Side In-Memory Cache with TTL
interface CacheEntry {
  data: any;
  expiresAt: number;
}
const clientCache = new Map<string, CacheEntry>();

// Cache TTL configuration for suitable endpoints (in milliseconds)
const CACHE_TTL_MAP: Record<string, number> = {
  '/system/branding': 60_000, // 60s
  '/branches': 30_000,         // 30s
  '/system/health': 15_000,    // 15s
  '/volunteers/documents/categories/all': 30_000, // 30s
};

/**
 * Clear client-side cache entries that match a given pattern or all entries
 */
export function invalidateApiCache(pattern?: string) {
  if (!pattern) {
    clientCache.clear();
    return;
  }
  for (const key of clientCache.keys()) {
    if (key.includes(pattern)) {
      clientCache.delete(key);
    }
  }
}

async function getValidAuthToken(): Promise<string | null> {
  const stored = getStoredAuthToken();
  if (stored) return stored;
  if (isSupabaseConfigured) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) return session.access_token;
    } catch {
      // ignore
    }
  }
  return null;
}

interface RequestOptions extends RequestInit {
  cacheTtlMs?: number;
  skipCache?: boolean;
}

async function request<T>(endpoint: string, options?: RequestOptions): Promise<T> {
  const method = (options?.method || 'GET').toUpperCase();
  const isGet = method === 'GET';
  const token = await getValidAuthToken();
  // Scope in-flight deduplication to the authenticated session. Tenant authority
  // is derived by the server from the verified profile, never from local storage.
  const authCacheScope = token ? token.slice(-24) : 'anonymous';
  const cacheKey = `${method}:${authCacheScope}:${endpoint}`;

  // 1. Check Safe Client-Side Cache for GET requests
  if (isGet && !options?.skipCache) {
    const cached = clientCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.data as T;
    }
  }

  // 2. In-Flight Request Deduplication for GET requests
  if (isGet) {
    const existing = inFlightRequests.get(cacheKey);
    if (existing) {
      return existing as Promise<T>;
    }
  }

  const executeRequest = async (): Promise<T> => {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      };

      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      let res = await fetch(`${API_BASE}${endpoint}`, {
        credentials: 'include',
        headers: {
          ...headers,
          ...options?.headers,
        },
        ...options,
      });

      // Automatically attempt token refresh once if a non-auth API endpoint returns 401
      if (res.status === 401 && !endpoint.startsWith('/auth/')) {
        const refreshedToken = await attemptSilentTokenRefresh();
        if (refreshedToken) {
          headers['Authorization'] = `Bearer ${refreshedToken}`;
          res = await fetch(`${API_BASE}${endpoint}`, {
            credentials: 'include',
            headers: {
              ...headers,
              ...options?.headers,
            },
            ...options,
          });
        }
      }

      const rawText = await res.text();
      const trimmed = rawText.trim();
      const lower = trimmed.toLowerCase();
      const isHtmlFallback =
        lower.startsWith('<!doctype html') ||
        lower.startsWith('<html') ||
        lower.includes('<div id="root"') ||
        lower.includes('<head>');

      if (isHtmlFallback) {
        const htmlErr: any = new Error(`Backend endpoint ${endpoint} returned an HTML fallback (HTTP ${res.status}).`);
        htmlErr.isHtmlFallback = true;
        htmlErr.status = res.status;
        throw htmlErr;
      }

      if (!res.ok) {
        let errJson: any;
        try {
          errJson = rawText ? JSON.parse(rawText) : {};
        } catch {
          // not json
        }
        throw new Error(errJson?.message || errJson?.error || `Request failed with status ${res.status}`);
      }

      const data = rawText ? JSON.parse(rawText) : {};

      // Invalidate relevant cache on mutations
      if (!isGet) {
        // Strip query params to get resource path
        const resource = endpoint.split('?')[0].split('/')[1] || '';
        if (resource) {
          invalidateApiCache(resource);
        }
        invalidateApiCache('/system/state');
      } else {
        // Cache response if safe TTL is specified or recognized
        const ttl = options?.cacheTtlMs ?? CACHE_TTL_MAP[endpoint];
        if (ttl && ttl > 0) {
          clientCache.set(cacheKey, {
            data,
            expiresAt: Date.now() + ttl,
          });
        }
      }

      return data;
    } finally {
      if (isGet) {
        inFlightRequests.delete(cacheKey);
      }
    }
  };

  const requestPromise = executeRequest();
  if (isGet) {
    inFlightRequests.set(cacheKey, requestPromise);
  }

  return requestPromise;
}

export const apiService = {
  // System State & Health & Branding
  fetchSystemState: () => request<any>('/system/state'),
  fetchAllData: () => request<any>('/system/all-data'),
  cleanupDemoData: () => request<{ success: boolean; message: string; removedCount: number }>('/system/cleanup-demo', { method: 'POST' }),
  fetchHealth: () => request<any>('/system/health'),
  getBranding: () => request<any>('/system/branding'),
  updateBranding: (branding: any) =>
    request<any>('/system/branding', { method: 'PUT', body: JSON.stringify(branding) }),
  getPostgresSQL: () => request<any>('/system/schema-sql'),
  restoreSystem: (data: any) => request<{ success: boolean; message: string }>('/system/restore', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  resetSystem: () => request<{ success: boolean; state: any }>('/system/reset', { method: 'POST' }),

  // Auth & Session
  login: (email: string, password?: string) =>
    request<{ success: boolean; user: SystemUser; token: string; tokens?: { accessToken: string; refreshToken: string } }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  refreshToken: async () => {
    const refreshToken = getStoredRefreshToken();
    try {
      const res = await request<{
        success: boolean;
        token?: string;
        refreshToken?: string;
        tokens?: { accessToken: string; refreshToken: string };
        user: SystemUser;
      }>('/auth/refresh', {
        method: 'POST',
        body: JSON.stringify(refreshToken ? { refreshToken } : {}),
      });
      if (res && res.success) {
        const accessToken = res.token || res.tokens?.accessToken || '';
        const nextRefresh = res.refreshToken || res.tokens?.refreshToken || refreshToken || '';
        const remember = isRememberMeActive();
        if (accessToken) storeAuthToken(accessToken, remember);
        if (nextRefresh) storeRefreshToken(nextRefresh, remember);
        if (res.user) storeAuthUser(res.user, remember);
        return {
          success: true,
          tokens: { accessToken, refreshToken: nextRefresh },
          user: res.user,
        };
      }
    } catch (err) {
      if (isSupabaseConfigured) {
        const { data, error } = await supabase.auth.refreshSession(
          refreshToken ? { refresh_token: refreshToken } : undefined
        );
        if (error) throw error;
        return {
          success: true,
          tokens: {
            accessToken: data.session?.access_token || '',
            refreshToken: data.session?.refresh_token || '',
          },
          user: data.user as any,
        };
      }
      throw err;
    }
    throw new Error('Failed to refresh session.');
  },
  getCurrentUser: () => request<{ success: boolean; user: SystemUser }>('/auth/me'),
  getPublicRegistrationOptions: () => request<{ success: boolean; branches: { id: string; name: string }[] }>('/auth/registration-options', { skipCache: true }),
  getMembershipApprovals: () => request<{ success: boolean; workflows: WorkflowRequest[]; totalPending: number }>('/auth/approvals', { skipCache: true }),
  decideMembershipApplication: async (id: string, decision: 'Approve' | 'Reject', rejectionReason?: string, adminNotes?: string) => {
    const result = await request<any>(`/auth/approvals/${encodeURIComponent(id)}/decision`, {
      method: 'POST', body: JSON.stringify({ decision, rejectionReason, adminNotes }),
    });
    // The decision endpoint is under /auth, but an approval also creates a
    // member row. Invalidate member and system-state caches explicitly.
    invalidateApiCache('members');
    invalidateApiCache('/members');
    invalidateApiCache('/system/state');
    return result;
  },
  registerPublic: (data: any) => request<{ success: boolean; status: string; requiresApproval?: boolean; applicationReference: string; memberIdNumber: string; member?: Member; workflow?: WorkflowRequest; message: string }>('/auth/register-public', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  // Registration Invitations & Public Link Management (/api/registration-links)
  getRegistrationLinks: (params?: { branchId?: string; origin?: string }) => {
    const query = new URLSearchParams();
    if (params?.branchId) query.set('branchId', params.branchId);
    if (params?.origin) query.set('origin', params.origin);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<{
      success: boolean;
      origin: string;
      activeInvitation: RegistrationInvitationRecord & { registrationUrl: string };
      invitations: (RegistrationInvitationRecord & { registrationUrl: string })[];
    }>(`/registration-links${qs}`, { skipCache: true });
  },
  createRegistrationLink: (payload: {
    title?: string;
    description?: string;
    branchId?: string;
    ministryId?: string;
    defaultRole?: UserRole;
    requiresApproval?: boolean;
    singleUse?: boolean;
    maxUses?: number | null;
    expirationPreset?: RegistrationExpirationPreset;
    customExpiresAt?: string;
    revokePreviousActive?: boolean;
    clientOrigin?: string;
  }) =>
    request<{
      success: boolean;
      message: string;
      invitation: RegistrationInvitationRecord & { registrationUrl: string };
    }>('/registration-links', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  revokeRegistrationLink: (id: string, reason?: string) =>
    request<{
      success: boolean;
      message: string;
      invitation: RegistrationInvitationRecord;
    }>(`/registration-links/${encodeURIComponent(id)}/revoke`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }),
  validateRegistrationToken: async (token: string) => {
    const res = await fetch(`/api/registration-links/validate/${encodeURIComponent(token)}`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    });
    const data = await res.json().catch(() => ({}));
    return {
      ok: res.ok,
      httpStatus: res.status,
      ...data,
    };
  },
  dispatchRegistrationLink: (
    id: string,
    payload: {
      channel: 'EMAIL' | 'SMS';
      recipient: string;
      recipientName?: string;
      customMessage?: string;
      clientOrigin?: string;
    }
  ) =>
    request<{
      success: boolean;
      status: string;
      provider: string;
      message: string;
      log?: CommunicationLog;
      registrationUrl: string;
    }>(`/registration-links/${encodeURIComponent(id)}/share-dispatch`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  checkApplicationStatus: (ref: string) => request<any>(`/auth/application-status/${encodeURIComponent(ref)}`),
  getUsers: () => request<SystemUser[]>('/auth/users', { skipCache: true }),
  createUser: (user: Partial<SystemUser>) =>
    request<SystemUser>('/auth/users', { method: 'POST', body: JSON.stringify(user) }),
  updateUser: (id: string, user: Partial<SystemUser>) =>
    request<{ success: boolean; message: string; user: SystemUser }>(`/auth/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(user),
    }),
  updateUserRole: (id: string, role: string, additionalRoles?: string[]) =>
    request<SystemUser>(`/auth/users/${id}/role`, {
      method: 'PUT',
      body: JSON.stringify({ role, additionalRoles }),
    }),
  setUserPrimaryRole: (id: string, role: string, keepPreviousPrimaryAsAdditional: boolean = false) =>
    request<{
      success: boolean;
      message: string;
      user: SystemUser;
      primaryRole: UserRole;
      additionalRoles: UserRole[];
      effectivePermissions: string[];
    }>(`/auth/users/${id}/primary-role`, {
      method: 'PUT',
      body: JSON.stringify({ role, keepPreviousPrimaryAsAdditional }),
    }),
  addUserRole: (id: string, role: string) =>
    request<{
      success: boolean;
      message: string;
      user: SystemUser;
      primaryRole: UserRole;
      additionalRoles: UserRole[];
      roles: UserRole[];
      effectivePermissions: string[];
    }>(`/auth/users/${id}/roles`, {
      method: 'POST',
      body: JSON.stringify({ role }),
    }),
  removeUserRole: (id: string, role: string) =>
    request<{
      success: boolean;
      message: string;
      user: SystemUser;
      primaryRole: UserRole;
      additionalRoles: UserRole[];
      roles: UserRole[];
      effectivePermissions: string[];
    }>(`/auth/users/${id}/roles/${encodeURIComponent(role)}`, {
      method: 'DELETE',
    }),
  getUserEffectivePermissions: (id: string) =>
    request<{
      success: boolean;
      userId: string;
      email: string;
      name: string;
      primaryRole: UserRole;
      additionalRoles: UserRole[];
      roles: UserRole[];
      userRoles: { role: UserRole; isPrimary: boolean }[];
      effectivePermissions: string[];
      deniedPermissions: string[];
      roleBreakdown: { role: UserRole; isPrimary: boolean; grantedPermissions: string[] }[];
      roleDetails?: { role: UserRole; label: string; isPrimary: boolean; permissions: string[]; explicitDenyRules: string[] }[];
      assignedCampuses: string[];
      primaryCampus: string;
      branchId?: string;
      branchName?: string;
      branchIds?: string[];
    }>(`/auth/users/${id}/effective-permissions`, { skipCache: true }),
  updateUserCampuses: (id: string, payload: { branchId?: string; branchName?: string; assignedCampuses: string[]; branchIds?: string[] }) =>
    request<{ success: boolean; message: string; user: SystemUser }>(`/auth/users/${id}/campuses`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  addUserCampus: (
    id: string,
    campusOrPayload: string | { campusName: string; branchId?: string; setAsPrimary?: boolean },
    setAsPrimary: boolean = false
  ) =>
    request<{
      success: boolean;
      message: string;
      user: SystemUser;
      assignedCampuses: string[];
      primaryCampus: string;
    }>(`/auth/users/${id}/campuses`, {
      method: 'POST',
      body: JSON.stringify(
        typeof campusOrPayload === 'string'
          ? { campus: campusOrPayload, campusName: campusOrPayload, setAsPrimary }
          : {
              campus: campusOrPayload.campusName,
              campusName: campusOrPayload.campusName,
              branchId: campusOrPayload.branchId,
              setAsPrimary: campusOrPayload.setAsPrimary ?? setAsPrimary,
            }
      ),
    }),
  removeUserCampus: (id: string, campus: string) =>
    request<{
      success: boolean;
      message: string;
      user: SystemUser;
      assignedCampuses: string[];
      primaryCampus: string;
    }>(`/auth/users/${id}/campuses/${encodeURIComponent(campus)}`, {
      method: 'DELETE',
    }),
  updateUserStatus: (id: string, status: 'Active' | 'Inactive' | 'Suspended' | 'Pending', reason?: string) =>
    request<{ success: boolean; message: string; user: SystemUser }>(`/auth/users/${id}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, reason }),
    }),
  forceUserPasswordChange: (id: string, mustChangePassword: boolean = true) =>
    request<{ success: boolean; mustChangePassword: boolean; message: string; user: SystemUser }>(
      `/auth/users/${id}/force-password-change`,
      { method: 'POST', body: JSON.stringify({ mustChangePassword }) }
    ),
  revokeUserSessions: (id: string) =>
    request<{ success: boolean; sessionRevokedAt: string; message: string; user: SystemUser }>(
      `/auth/users/${id}/revoke-sessions`,
      { method: 'POST' }
    ),
  getUserSecurityEvents: (id: string) =>
    request<{ success: boolean; userId: string; email: string; events: AuditLog[] }>(
      `/auth/users/${id}/security-events`,
      { skipCache: true }
    ),
  toggleMfa: (id: string, enabled: boolean) =>
    request<SystemUser>(`/auth/users/${id}/toggle-mfa`, { method: 'POST', body: JSON.stringify({ enabled }) }),
  adminEnable2Fa: (id: string, code?: string) =>
    request<{
      success: boolean;
      message: string;
      enrollment?: {
        factorId: string;
        challengeId: string;
        secret: string;
        uri: string;
        issuer: string;
        accountName: string;
        verified: boolean;
      };
      user: SystemUser;
    }>(`/auth/admin/users/${id}/2fa/enable`, {
      method: 'POST',
      body: JSON.stringify(code ? { code } : {}),
    }),
  adminVerify2Fa: (id: string, payload: { code: string; challengeId?: string; secret?: string }) =>
    request<{ success: boolean; verified: boolean; message: string; user: SystemUser }>(
      `/auth/admin/users/${id}/2fa/verify`,
      { method: 'POST', body: JSON.stringify(payload) }
    ),
  adminDisable2Fa: (id: string) =>
    request<{ success: boolean; message: string; user: SystemUser }>(
      `/auth/admin/users/${id}/2fa/disable`,
      { method: 'POST' }
    ),
  deleteUser: (id: string) => request<{ success: boolean }>(`/auth/users/${id}`, { method: 'DELETE' }),
  adminResetPassword: (id: string, temporaryPassword?: string, email?: string) =>
    request<{
      success: boolean;
      temporaryPassword: string;
      mustChangePassword: boolean;
      message: string;
      temp_password_expires_at?: string;
      user?: Partial<SystemUser>;
    }>(`/auth/admin/users/${id}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ temporaryPassword, email }),
    }),

  // YouVersion Platform Data Exchange Integration
  getYouVersionExchangeToken: () => request<{ success: boolean; exchangeToken: string; permission: string; expiresIn: number; appKeyConfigured: boolean; message: string }>('/bible/youversion/exchange-token', {
    method: 'POST',
  }),
  syncYouVersionHighlights: (exchangeToken: string, highlights?: any[]) => request<{ success: boolean; message: string; permission: string; count: number; highlights: any[] }>('/bible/youversion/highlights/sync', {
    method: 'POST',
    body: JSON.stringify({ exchangeToken, highlights }),
  }),

  // Members & Families
  getMembers: async (params?: { branchId?: string; search?: string }): Promise<Member[]> => {
    const query = new URLSearchParams();
    if (params?.branchId) query.set('branchId', params.branchId);
    if (params?.search) query.set('search', params.search);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<Member[]>(`/members${qs}`);
  },
  createMember: async (member: Member): Promise<Member> => {
    return request<Member>('/members', { method: 'POST', body: JSON.stringify(member) });
  },
  updateMember: async (member: Member): Promise<Member> => {
    return request<Member>(`/members/${member.id}`, { method: 'PUT', body: JSON.stringify(member) });
  },
  deleteMember: async (id: string): Promise<{ success: boolean; deletedId: string }> => {
    return request<{ success: boolean; deletedId: string }>(`/members/${id}`, { method: 'DELETE' });
  },
  bulkImportMembers: (members: Member[]) =>
    request<{ count: number; members: Member[] }>('/members/bulk', {
      method: 'POST',
      body: JSON.stringify({ members }),
    }),
  transferBranch: (memberId: string, newBranchId: string) =>
    request<Member>(`/members/${memberId}/transfer-branch`, {
      method: 'POST',
      body: JSON.stringify({ newBranchId }),
    }),

  // Families
  getFamilies: async (): Promise<Family[]> => {
    return request<Family[]>('/members/families/all');
  },
  createFamily: async (family: Family): Promise<Family> => {
    return request<Family>('/members/families', { method: 'POST', body: JSON.stringify(family) });
  },
  updateFamily: async (family: Family): Promise<Family> => {
    return request<Family>(`/members/families/${family.id}`, { method: 'PUT', body: JSON.stringify(family) });
  },
  deleteFamily: async (id: string): Promise<{ success: boolean; deletedId: string }> => {
    return request<{ success: boolean; deletedId: string }>(`/members/families/${id}`, { method: 'DELETE' });
  },

  // Branches & Ministries
  getBranches: () => request<Branch[]>('/branches'),
  createBranch: (branch: Branch) =>
    request<Branch>('/branches', { method: 'POST', body: JSON.stringify(branch) }),
  updateBranch: (branch: Branch) =>
    request<Branch>(`/branches/${branch.id}`, { method: 'PUT', body: JSON.stringify(branch) }),
  deleteBranch: (id: string) =>
    request<{ success: boolean; deletedId: string }>(`/branches/${id}`, { method: 'DELETE' }),

  getMinistries: async (): Promise<Ministry[]> => {
    return request<Ministry[]>('/branches/ministries/all');
  },
  createMinistry: async (ministry: Ministry): Promise<Ministry> => {
    return request<Ministry>('/branches/ministries', { method: 'POST', body: JSON.stringify(ministry) });
  },
  updateMinistry: (ministry: Ministry) =>
    request<Ministry>(`/branches/ministries/${ministry.id}`, { method: 'PUT', body: JSON.stringify(ministry) }),
  deleteMinistry: (id: string) =>
    request<{ success: boolean; deletedId: string }>(`/branches/ministries/${id}`, { method: 'DELETE' }),
  deleteSubMinistry: (ministryId: string, subId: string) =>
    request<Ministry>(`/branches/ministries/${ministryId}/sub/${subId}`, { method: 'DELETE' }),

  // Attendance
  getAttendance: async (params?: { branchId?: string; date?: string }): Promise<AttendanceRecord[]> => {
    const query = new URLSearchParams();
    if (params?.branchId) query.set('branchId', params.branchId);
    if (params?.date) query.set('date', params.date);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<AttendanceRecord[]>(`/attendance${qs}`);
  },
  getAttendanceSessions: (params?: { status?: string; groupId?: string; branchId?: string }) => {
    const query = new URLSearchParams();
    if (params?.status) query.set('status', params.status);
    if (params?.groupId) query.set('groupId', params.groupId);
    if (params?.branchId) query.set('branchId', params.branchId);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<AttendanceSession[]>(`/attendance/sessions${qs}`);
  },
  createAttendanceSession: (session: Partial<AttendanceSession>) =>
    request<AttendanceSession>('/attendance/sessions', {
      method: 'POST',
      body: JSON.stringify(session),
    }),
  rotateAttendanceSessionToken: (sessionId: string) =>
    request<{ success: boolean; sessionId: string; qrPayloadToken: string }>(
      `/attendance/sessions/${sessionId}/rotate`,
      { method: 'POST' }
    ),
  closeAttendanceSession: (sessionId: string) =>
    request<{ success: boolean; session: AttendanceSession }>(
      `/attendance/sessions/${sessionId}/close`,
      { method: 'POST' }
    ),
  sessionCheckIn: (
    sessionId: string,
    data: { memberId?: string; memberName?: string; checkInType?: string; token?: string }
  ) =>
    request<{
      success: boolean;
      alreadyCheckedIn?: boolean;
      message: string;
      record: AttendanceRecord;
      attendeeCount?: number;
    }>(`/attendance/sessions/${sessionId}/checkin`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  recordAttendance: async (record: AttendanceRecord): Promise<AttendanceRecord> => {
    return request<AttendanceRecord>('/attendance', { method: 'POST', body: JSON.stringify(record) });
  },
  qrCheckIn: (data: { qrPayload: string; branchId?: string; serviceName?: string }) =>
    request<any>('/attendance/check-in/qr', { method: 'POST', body: JSON.stringify(data) }),
  bulkImportAttendance: (records: AttendanceRecord[]) =>
    request<{ count: number; records: AttendanceRecord[] }>('/attendance/bulk', {
      method: 'POST',
      body: JSON.stringify({ records }),
    }),

  // Events
  getEvents: async (branchId?: string): Promise<EventItem[]> => {
    const qs = branchId && branchId !== 'all' ? `?branchId=${encodeURIComponent(branchId)}` : '';
    return request<EventItem[]>(`/attendance/events/all${qs}`);
  },
  createEvent: async (event: EventItem): Promise<EventItem> => {
    return request<EventItem>('/attendance/events', { method: 'POST', body: JSON.stringify(event) });
  },
  updateEvent: async (event: EventItem): Promise<EventItem> => {
    return request<EventItem>(`/attendance/events/${event.id}`, { method: 'PUT', body: JSON.stringify(event) });
  },
  deleteEvent: async (id: string): Promise<{ success: boolean }> => {
    return request<{ success: boolean }>(`/attendance/events/${id}`, { method: 'DELETE' });
  },

  // Pastoral Care
  getPrayerRequests: async (): Promise<PrayerRequest[]> => {
    return request<PrayerRequest[]>('/pastoral/prayer');
  },
  createPrayerRequest: async (req: PrayerRequest): Promise<PrayerRequest> => {
    return request<PrayerRequest>('/pastoral/prayer', { method: 'POST', body: JSON.stringify(req) });
  },
  updatePrayerStatus: (id: string, status: string, notes?: string) =>
    request<PrayerRequest>(`/pastoral/prayer/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status, notes }),
    }),

  getCounselingSessions: async (): Promise<CounselingSession[]> => {
    return request<CounselingSession[]>('/pastoral/counseling');
  },
  createCounselingSession: async (session: CounselingSession): Promise<CounselingSession> => {
    return request<CounselingSession>('/pastoral/counseling', { method: 'POST', body: JSON.stringify(session) });
  },

  getVisitations: () => request<VisitationRecord[]>('/pastoral/visitations'),
  createVisitation: (vis: VisitationRecord) =>
    request<VisitationRecord>('/pastoral/visitations', { method: 'POST', body: JSON.stringify(vis) }),

  getCommunications: () => request<CommunicationMessage[]>('/pastoral/communications'),
  sendCommunication: (comm: CommunicationMessage) =>
    request<CommunicationMessage>('/pastoral/communications/send', {
      method: 'POST',
      body: JSON.stringify(comm),
    }),

  // Production Email + SMS Communication System (/api/communications)
  getCommunicationStatus: () =>
    request<{ success: boolean } & CommunicationSystemStatus>('/communications/status', {
      skipCache: true,
    }),
  getCommunicationLogs: (params?: {
    channel?: string;
    status?: string;
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }) => {
    const query = new URLSearchParams();
    if (params?.channel) query.set('channel', params.channel);
    if (params?.status) query.set('status', params.status);
    if (params?.memberId) query.set('memberId', params.memberId);
    if (params?.familyId) query.set('familyId', params.familyId);
    if (params?.ministryId) query.set('ministryId', params.ministryId);
    if (params?.search) query.set('search', params.search);
    if (params?.limit) query.set('limit', String(params.limit));
    if (params?.offset) query.set('offset', String(params.offset));
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<{
      success: boolean;
      total: number;
      logs: CommunicationLog[];
      summary: CommunicationLogsSummary;
    }>(`/communications/logs${qs}`, { skipCache: true });
  },
  sendSms: (payload: {
    recipient?: string;
    recipients?: (string | { phone?: string; memberId?: string; familyId?: string; name?: string })[];
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    subject?: string;
    message: string;
    triggerType?: string;
    senderId?: string;
  }) =>
    request<{
      success: boolean;
      message: string;
      sentCount: number;
      failedCount: number;
      log: CommunicationLog;
      logs: CommunicationLog[];
      communication?: CommunicationMessage;
    }>('/communications/sms', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  sendEmail: (payload: {
    recipient?: string;
    recipients?: (string | { email?: string; memberId?: string; familyId?: string; name?: string })[];
    memberId?: string;
    familyId?: string;
    ministryId?: string;
    subject: string;
    message: string;
    html?: string;
    replyTo?: string;
    triggerType?: string;
  }) =>
    request<{
      success: boolean;
      message: string;
      sentCount: number;
      failedCount: number;
      log: CommunicationLog;
      logs: CommunicationLog[];
      communication?: CommunicationMessage;
    }>('/communications/email', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  sendBroadcast: (payload: {
    channel: 'SMS' | 'EMAIL' | 'BOTH' | 'Multi-Channel';
    targetType: 'all_active' | 'branch' | 'ministry' | 'family' | 'custom_members';
    branchId?: string;
    ministryId?: string;
    familyId?: string;
    memberIds?: string[];
    subject?: string;
    message: string;
    triggerType?: string;
  }) =>
    request<{
      success: boolean;
      message: string;
      targetAudience: string;
      totalTargetedMembers: number;
      sentCount: number;
      failedCount: number;
      skippedCount: number;
      deliveryRatePercentage: number;
      communication: CommunicationMessage;
      logs: CommunicationLog[];
    }>('/communications/broadcast', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  retryCommunicationLog: (id: string) =>
    request<{
      success: boolean;
      log: CommunicationLog;
      error?: string | null;
    }>(`/communications/retry/${encodeURIComponent(id)}`, {
      method: 'POST',
    }),

  // Volunteers & Assets & Documents & Storage
  getVolunteerShifts: async (ministryId?: string): Promise<VolunteerShift[]> => {
    const qs = ministryId ? `?ministryId=${encodeURIComponent(ministryId)}` : '';
    return request<VolunteerShift[]>(`/volunteers/shifts${qs}`);
  },
  createVolunteerShift: async (shift: VolunteerShift): Promise<VolunteerShift> => {
    return request<VolunteerShift>('/volunteers/shifts', { method: 'POST', body: JSON.stringify(shift) });
  },

  getAssets: async (branchId?: string): Promise<Asset[]> => {
    const qs = branchId && branchId !== 'all' ? `?branchId=${encodeURIComponent(branchId)}` : '';
    return request<Asset[]>(`/volunteers/assets${qs}`);
  },
  createAsset: async (asset: Asset): Promise<Asset> => {
    return request<Asset>('/volunteers/assets', { method: 'POST', body: JSON.stringify(asset) });
  },

  getDocuments: async (category?: string): Promise<DocumentItem[]> => {
    const qs = category && category !== 'All' ? `?category=${encodeURIComponent(category)}` : '';
    return request<DocumentItem[]>(`/volunteers/documents${qs}`);
  },
  createDocument: async (doc: DocumentItem): Promise<DocumentItem> => {
    return request<DocumentItem>('/volunteers/documents', { method: 'POST', body: JSON.stringify(doc) });
  },
  deleteDocument: async (id: string): Promise<{ success: boolean }> => {
    return request<{ success: boolean }>(`/volunteers/documents/${id}`, { method: 'DELETE' });
  },
  uploadFileToStorage: (file: File, bucket: StorageBucketName = 'documents-vault', folder: string = 'uploads') =>
    storageService.uploadFile(file, bucket, folder),
  getDocumentCategories: () => request<string[]>('/volunteers/documents/categories/all'),
  addDocumentCategory: (categoryName: string) =>
    request<string[]>('/volunteers/documents/categories', {
      method: 'POST',
      body: JSON.stringify({ categoryName }),
    }),
  deleteDocumentCategory: (name: string) =>
    request<string[]>(`/volunteers/documents/categories/${encodeURIComponent(name)}`, {
      method: 'DELETE',
    }),

  // LMS
  getCourses: async (): Promise<LmsCourse[]> => {
    return request<LmsCourse[]>('/lms/courses');
  },
  createCourse: async (course: LmsCourse): Promise<LmsCourse> => {
    return request<LmsCourse>('/lms/courses', { method: 'POST', body: JSON.stringify(course) });
  },
  updateCourse: async (course: LmsCourse): Promise<LmsCourse> => {
    return request<LmsCourse>(`/lms/courses/${course.id}`, { method: 'PUT', body: JSON.stringify(course) });
  },
  deleteCourse: async (id: string): Promise<{ success: boolean }> => {
    return request<{ success: boolean }>(`/lms/courses/${id}`, { method: 'DELETE' });
  },

  // Workflows & Approvals Queue
  getProfileChangeRequests: async (): Promise<ProfileChangeRequest[]> => {
    return request<ProfileChangeRequest[]>('/workflows/profile-changes', { skipCache: true });
  },
  submitProfileChangeRequest: async (payload: Partial<ProfileChangeRequest> & {
    memberId: string;
    changes?: Partial<Member>;
    previousSnapshot?: Partial<Member>;
  }): Promise<{ success: boolean; request: ProfileChangeRequest }> => {
    return request<{ success: boolean; request: ProfileChangeRequest }>('/workflows/profile-changes', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateProfileChangeRequestStatus: async (
    id: string,
    status: 'Approved' | 'Rejected',
    notesOrReason?: string,
    reviewedBy?: string
  ): Promise<{ success: boolean; request: ProfileChangeRequest; member?: Member }> => {
    return request<{ success: boolean; request: ProfileChangeRequest; member?: Member }>(
      `/workflows/profile-changes/${encodeURIComponent(id)}/status`,
      {
        method: 'PUT',
        body: JSON.stringify({
          status,
          adminNotes: status === 'Approved' ? notesOrReason : undefined,
          rejectionReason: status === 'Rejected' ? notesOrReason : undefined,
          reviewedBy,
        }),
      }
    );
  },
  getWorkflows: async (params?: { status?: string; branchId?: string }): Promise<WorkflowRequest[]> => {
    const query = new URLSearchParams();
    if (params?.status) query.set('status', params.status);
    if (params?.branchId) query.set('branchId', params.branchId);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<WorkflowRequest[]>(`/workflows${qs}`);
  },
  submitWorkflowRequest: async (data: Partial<WorkflowRequest>): Promise<WorkflowRequest> => {
    const res = await request<{ success: boolean; workflow: WorkflowRequest }>('/workflows', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return (res as any)?.workflow || (res as any);
  },
  approveWorkflow: async (id: string, comment?: string): Promise<WorkflowRequest> => {
    return apiService.updateWorkflowStatus(id, 'Approved', comment, 'Authorized Pastor');
  },
  rejectWorkflow: async (id: string, reason: string): Promise<WorkflowRequest> => {
    return apiService.updateWorkflowStatus(id, 'Rejected', reason, 'Authorized Pastor');
  },
  updateWorkflowStatus: async (id: string, status: string, comment?: string, approverName?: string): Promise<WorkflowRequest> => {
    return request<WorkflowRequest>(`/workflows/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({
        status,
        comments: comment,
        comment,
        approverName,
        approvedBy: approverName,
      }),
    });
  },

  // Live Attendance & Queue
  getLiveAttendanceCounts: (branchId?: string, date?: string) => {
    const query = new URLSearchParams();
    if (branchId) query.set('branchId', branchId);
    if (date) query.set('date', date);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<any>(`/attendance/live-counts${qs}`);
  },
  getQueueStats: () => request<any>('/system/queue/stats'),
  enqueueBackgroundTask: (name: string, data: any) =>
    request<any>('/system/queue/jobs', { method: 'POST', body: JSON.stringify({ name, data }) }),

  // Audit Logs
  getAuditLogs: async (): Promise<AuditLog[]> => {
    return request<AuditLog[]>('/audit/logs');
  },
  addAuditLog: async (action: string, moduleName: string, details: string, user?: string): Promise<{ success: boolean }> => {
    return request<{ success: boolean }>('/audit/logs', {
      method: 'POST',
      body: JSON.stringify({ action, moduleName, details, user }),
    });
  },

  // AI Assistance
  generateDevotion: (topic: string, language?: string) =>
    request<any>('/ai/devotion', { method: 'POST', body: JSON.stringify({ topic, language }) }),
  generateSermonOutline: (title: string, passage?: string) =>
    request<any>('/ai/sermon-outline', { method: 'POST', body: JSON.stringify({ title, passage }) }),

  // Ministry Collaboration: Live Chat & Video Conferencing
  getMinistryMessages: (ministryId: string) =>
    request<{ success: boolean; messages: any[]; count: number }>(`/ministry-collab/messages/${ministryId}`),
  sendMinistryMessage: (ministryId: string, data: { text: string; scriptureRef?: string; attachmentUrl?: string; attachmentName?: string; senderName?: string; senderEmail?: string; senderRole?: string; senderAvatar?: string }) =>
    request<{ success: boolean; message: any }>(`/ministry-collab/messages/${ministryId}`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  reactToMinistryMessage: (ministryId: string, messageId: string, emoji: string) =>
    request<{ success: boolean; reactions: any[] }>(`/ministry-collab/messages/${ministryId}/${messageId}/react`, {
      method: 'POST',
      body: JSON.stringify({ emoji }),
    }),
  getMinistryVideoRoom: (ministryId: string) =>
    request<{ success: boolean; room: any }>(`/ministry-collab/video-room/${ministryId}`),
  joinMinistryVideoRoom: (ministryId: string, data: { name: string; role: string; avatar?: string }) =>
    request<{ success: boolean; room: any; participant: any }>(`/ministry-collab/video-room/${ministryId}/join`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  leaveMinistryVideoRoom: (ministryId: string, userId: string) =>
    request<{ success: boolean; message: string }>(`/ministry-collab/video-room/${ministryId}/leave`, {
      method: 'POST',
      body: JSON.stringify({ userId }),
    }),

  // 1:1 Direct Video & Conversations (Phase 21 & 22)
  getConversations: () =>
    request<{ success: boolean; conversations: Conversation[] }>('/conversations'),
  getLedMinistryMembers: () =>
    request<{ success: boolean; userId: string; role: string; memberIds: string[] }>('/conversations/led-ministry-members'),
  getConversationById: (conversationId: string) =>
    request<{ success: boolean; conversation: Conversation }>(`/conversations/${conversationId}`),
  createConversation: (data: { type: 'direct' | 'ad_hoc_group' | 'video'; participantIds: string[]; title?: string }) =>
    request<{ success: boolean; conversation: Conversation }>('/conversations', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  getConversationMessages: (conversationId: string) =>
    request<{ success: boolean; messages: ConversationMessage[] }>(`/conversations/${conversationId}/messages`),
  sendConversationMessage: (conversationId: string, body: string) =>
    request<{ success: boolean; message: ConversationMessage }>(`/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ body }),
    }),
  startDirectVideoCall: (conversationId: string) =>
    request<{ success: boolean; conversationId: string; roomUrl: string; activeVideoCall: any }>(
      `/conversations/${conversationId}/start-video`,
      { method: 'POST' }
    ),
  endDirectVideoCall: (conversationId: string) =>
    request<{ success: boolean; message: string; conversationId: string }>(
      `/conversations/${conversationId}/end-video`,
      { method: 'POST' }
    ),

  // Phase 25: Real Server-Side Backup, Restore, Reset & Scheduling
  triggerServerBackup: (type: 'Full System' | 'Incremental' | 'Differential' = 'Full System') =>
    request<any>('/system/backup', {
      method: 'POST',
      body: JSON.stringify({ type }),
    }),
  restoreServerBackup: (content: any, confirm: boolean = false) =>
    request<any>(`/system/restore?confirm=${confirm ? 'true' : 'false'}`, {
      method: 'POST',
      body: JSON.stringify({ content, confirm }),
    }),
  restoreServerBackupFile: async (file: File, confirm: boolean = false) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('confirm', confirm ? 'true' : 'false');
    const token = await getValidAuthToken();
    const tenantId = typeof window !== 'undefined' ? localStorage.getItem('cmms_tenant_id') || 'tenant-grace-main' : 'tenant-grace-main';
    const res = await fetch(`/api/system/restore?confirm=${confirm ? 'true' : 'false'}`, {
      method: 'POST',
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        'X-Tenant-ID': tenantId,
      },
      body: formData,
    });
    return res.json();
  },
  resetServerDatabase: (confirm: boolean = false) =>
    request<any>(`/system/reset?confirm=${confirm ? 'true' : 'false'}`, {
      method: 'POST',
      body: JSON.stringify({ confirm }),
    }),
  getBackupHistory: () =>
    request<{ success: boolean; history: any[] }>('/system/backup/history'),
  getBackupSchedule: () =>
    request<{ success: boolean; schedule: any }>('/system/backup/schedule'),
  updateBackupSchedule: (schedule: { enabled?: boolean; frequency?: string; time?: string; destination?: string }) =>
    request<{ success: boolean; schedule: any }>('/system/backup/schedule', {
      method: 'PUT',
      body: JSON.stringify(schedule),
    }),
  getDatabaseHealth: () =>
    request<{
      configured: boolean;
      engine: string;
      ok: boolean;
      status: string;
      message: string;
      latencyMs?: number;
      database?: string;
      timestamp: string;
    }>('/system/db-health'),
  getSecurityGovernance: () =>
    request<{
      success: boolean;
      settings: {
        jwtLifespanHours: number;
        lockoutMaxAttempts: number;
        lockoutDurationMinutes: number;
        mfaEnforcementMode: 'enforced' | 'optional';
      };
    }>('/system/security-governance'),
  updateSecurityGovernance: (settings: {
    jwtLifespanHours?: number;
    lockoutMaxAttempts?: number;
    lockoutDurationMinutes?: number;
    mfaEnforcementMode?: 'enforced' | 'optional';
  }) =>
    request<{
      success: boolean;
      message: string;
      settings: {
        jwtLifespanHours: number;
        lockoutMaxAttempts: number;
        lockoutDurationMinutes: number;
        mfaEnforcementMode: 'enforced' | 'optional';
      };
    }>('/system/security-governance', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),

  // Ministry Annual Planning & Reporting System
  getMinistryAnnualPlans: (params?: { ministryId?: string; year?: number; status?: string }) => {
    const query = new URLSearchParams();
    if (params?.ministryId) query.set('ministryId', params.ministryId);
    if (params?.year) query.set('year', String(params.year));
    if (params?.status) query.set('status', params.status);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return request<{ success: boolean; count: number; plans: MinistryAnnualPlan[] }>(`/ministry-plans${qs}`, {
      skipCache: true,
    });
  },
  getMinistryAnnualPlanById: (id: string) =>
    request<{ success: boolean; plan: MinistryAnnualPlan }>(`/ministry-plans/${encodeURIComponent(id)}`, {
      skipCache: true,
    }),
  createMinistryAnnualPlan: (payload: Partial<MinistryAnnualPlan> & { submitNow?: boolean }) =>
    request<{ success: boolean; message: string; plan: MinistryAnnualPlan }>('/ministry-plans', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateMinistryAnnualPlan: (id: string, payload: Partial<MinistryAnnualPlan>) =>
    request<{ success: boolean; message: string; plan: MinistryAnnualPlan }>(
      `/ministry-plans/${encodeURIComponent(id)}`,
      {
        method: 'PUT',
        body: JSON.stringify(payload),
      }
    ),
  submitMinistryAnnualPlan: (id: string, comment?: string) =>
    request<{ success: boolean; message: string; plan: MinistryAnnualPlan }>(
      `/ministry-plans/${encodeURIComponent(id)}/submit`,
      {
        method: 'POST',
        body: JSON.stringify({ comment }),
      }
    ),
  reviseMinistryAnnualPlan: (
    id: string,
    payload: Partial<MinistryAnnualPlan> & { comment?: string; submitNow?: boolean }
  ) =>
    request<{ success: boolean; message: string; plan: MinistryAnnualPlan }>(
      `/ministry-plans/${encodeURIComponent(id)}/revise`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    ),
  reviewMinistryAnnualPlan: (
    id: string,
    action: 'start_review' | 'comment' | 'return' | 'approve' | 'reject' | 'activate' | 'complete',
    comment?: string
  ) =>
    request<{ success: boolean; message: string; plan: MinistryAnnualPlan }>(
      `/ministry-plans/${encodeURIComponent(id)}/review`,
      {
        method: 'POST',
        body: JSON.stringify({ action, comment }),
      }
    ),
  submitMinistryQuarterlyReport: (id: string, report: Partial<MinistryQuarterlyReport>) =>
    request<{
      success: boolean;
      message: string;
      quarterlyReport: MinistryQuarterlyReport;
      annualReport: MinistryAnnualReport;
      plan: MinistryAnnualPlan;
    }>(`/ministry-plans/${encodeURIComponent(id)}/quarterly-reports`, {
      method: 'POST',
      body: JSON.stringify(report),
    }),
  submitMinistryAnnualReport: (
    id: string,
    report: {
      executiveSummary?: string;
      keyAchievements?: string[];
      majorChallenges?: string[];
      lessonsLearned?: string[];
      strategicRecommendationsNextYear?: string[];
      status?: 'Draft' | 'Submitted' | 'Approved';
      markPlanCompleted?: boolean;
    }
  ) =>
    request<{
      success: boolean;
      message: string;
      annualReport: MinistryAnnualReport;
      plan: MinistryAnnualPlan;
    }>(`/ministry-plans/${encodeURIComponent(id)}/annual-report`, {
      method: 'POST',
      body: JSON.stringify(report),
    }),
  downloadMinistryPlanReportFile: async (
    id: string,
    format: 'pdf' | 'xlsx',
    scope: 'full' | 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'annual' = 'full'
  ): Promise<Blob> => {
    const token = await getValidAuthToken();
    const tenantId =
      typeof window !== 'undefined'
        ? localStorage.getItem('cmms_tenant_id') || 'tenant-grace-main'
        : 'tenant-grace-main';
    const res = await fetch(
      `/api/ministry-plans/${encodeURIComponent(id)}/export/${format}?scope=${encodeURIComponent(scope)}`,
      {
        method: 'GET',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          'X-Tenant-ID': tenantId,
        },
      }
    );
    if (!res.ok) {
      throw new Error(`Failed to generate ${format.toUpperCase()} report (HTTP ${res.status})`);
    }
    return res.blob();
  },
};
