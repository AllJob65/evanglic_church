import { Response } from 'express';
import { memberService } from '../services/memberService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';
import { verifyResourceAccess } from '../security/authorization';

export class MemberController {
  public async getMembers(req: AuthenticatedRequest, res: Response) {
    try {
      const user = req.user!;
      const branchId = (req.query.branchId as string) || req.branchId;
      const search = req.query.search as string;
      const status = req.query.status as string;

      let members = await memberService.getMembers({
        branchId: branchId === 'all' ? undefined : branchId,
        search,
        membershipStatus: status,
      });

      // Tenant isolation
      members = members.filter((m: any) => !m.tenantId || m.tenantId === user.tenantId);

      // Branch isolation for non-global admins
      if (!user.branchIds.includes('*')) {
        members = members.filter((m: any) => user.branchIds.includes(m.branchId));
      }

      res.json(members);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch members' });
    }
  }

  public async getMemberById(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      const member = await memberService.getMemberById(id);

      if (!member) {
        return res.status(404).json({ error: 'Member not found' });
      }

      // IDOR & Resource Ownership check
      const access = verifyResourceAccess(member, user);
      if (!access.authorized) {
        return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
      }

      res.json(member);
    } catch (err: any) {
      res.status(404).json({ error: err.message || 'Member not found' });
    }
  }

  public async createMember(req: AuthenticatedRequest, res: Response) {
    try {
      const user = req.user!;
      const data = req.body;

      // Restrict target branch assignment
      const targetBranch = data.branchId || user.branchId;
      if (!user.branchIds.includes('*') && !user.branchIds.includes(targetBranch)) {
        return res.status(403).json({
          error: 'Cannot create a member in a branch you do not administer.',
          code: 'BRANCH_ACCESS_DENIED',
        });
      }

      const memberPayload = {
        ...data,
        tenantId: user.tenantId,
        branchId: targetBranch,
      };

      const operatorEmail = user.email || 'admin@gracecathedral.org';
      const created = await memberService.createMember(memberPayload, operatorEmail);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create member' });
    }
  }

  public async updateMember(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      const data = req.body;

      const current = await memberService.getMemberById(id);
      if (!current) {
        return res.status(404).json({ error: 'Member not found' });
      }

      const access = verifyResourceAccess(current, user);
      if (!access.authorized) {
        return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
      }

      // Prevent altering tenantId
      delete (data as any).tenantId;

      const operatorEmail = user.email || 'admin@gracecathedral.org';
      const updated = await memberService.updateMember(id, data, operatorEmail);
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update member' });
    }
  }

  public async deleteMember(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;

      const current = await memberService.getMemberById(id);
      if (!current) {
        return res.status(404).json({ error: 'Member not found' });
      }

      const access = verifyResourceAccess(current, user);
      if (!access.authorized) {
        return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
      }

      const operatorEmail = user.email || 'admin@gracecathedral.org';
      const deleted = await memberService.deleteMember(id, operatorEmail);
      res.json({ success: true, deletedId: deleted.id });
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to delete member' });
    }
  }

  public async uploadPhoto(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      const { photoUrl, photoBase64 } = req.body;
      const imageUri = photoUrl || photoBase64;
      if (!imageUri) {
        return res.status(400).json({ error: 'Photo URL or Base64 string required' });
      }

      const current = await memberService.getMemberById(id);
      if (!current) {
        return res.status(404).json({ error: 'Member not found' });
      }

      const access = verifyResourceAccess(current, user);
      if (!access.authorized) {
        return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
      }

      const result = await memberService.updateProfilePhoto(id, imageUri);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to upload member photo' });
    }
  }

  public async bulkImport(req: AuthenticatedRequest, res: Response) {
    try {
      const user = req.user!;
      const { members } = req.body;
      if (!Array.isArray(members) || members.length === 0) {
        return res.status(400).json({ error: 'Valid array of members required' });
      }

      // Enforce tenant on each member
      const sanitizedMembers = members.map((m: any) => ({
        ...m,
        tenantId: user.tenantId,
        branchId: (!user.branchIds.includes('*') && !user.branchIds.includes(m.branchId)) ? user.branchId : (m.branchId || user.branchId),
      }));

      const operatorEmail = user.email || 'admin@gracecathedral.org';
      const result = await memberService.bulkImport(sanitizedMembers, operatorEmail);
      res.status(201).json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Bulk import failed' });
    }
  }

  // Families
  public async getFamilies(req: AuthenticatedRequest, res: Response) {
    try {
      const user = req.user!;
      const branchId = (req.query.branchId as string) || req.branchId;
      let families = await memberService.getFamilies(branchId === 'all' ? undefined : branchId);

      families = families.filter((f: any) => !f.tenantId || f.tenantId === user.tenantId);
      if (!user.branchIds.includes('*')) {
        families = families.filter((f: any) => !f.branchId || user.branchIds.includes(f.branchId));
      }

      res.json(families);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch families' });
    }
  }

  public async createFamily(req: AuthenticatedRequest, res: Response) {
    try {
      const user = req.user!;
      const created = await memberService.createFamily({
        ...req.body,
        tenantId: user.tenantId,
        branchId: req.body.branchId || user.branchId,
      });
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create family' });
    }
  }

  public async updateFamily(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      const updated = await memberService.updateFamily(id, req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update family' });
    }
  }
}

export const memberController = new MemberController();
