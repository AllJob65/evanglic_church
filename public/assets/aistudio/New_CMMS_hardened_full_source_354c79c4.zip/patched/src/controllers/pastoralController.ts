import { Response } from 'express';
import { pastoralService } from '../services/pastoralService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';
import { PastoralRecordSchema } from '../validators';

export class PastoralController {
  public async getNotes(req: AuthenticatedRequest, res: Response) {
    try {
      const branchId = (req.query.branchId as string) || req.branchId;
      const memberId = req.query.memberId as string;
      const userRole = req.user?.role || 'REGULAR_MEMBER';
      const userId = req.user?.id;

      const notes = await pastoralService.getNotes(
        {
          branchId: branchId === 'all' ? undefined : branchId,
          memberId,
        },
        userRole,
        userId
      );
      res.json(notes);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch pastoral notes' });
    }
  }

  public async createNote(req: AuthenticatedRequest, res: Response) {
    try {
      const validated = PastoralRecordSchema.parse(req.body);
      const pastorEmail = req.user?.email || 'pastor@gracecathedral.org';
      const created = await pastoralService.createNote(validated, pastorEmail);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create pastoral note' });
    }
  }

  // Prayer Requests
  public async getPrayers(req: AuthenticatedRequest, res: Response) {
    try {
      const branchId = (req.query.branchId as string) || req.branchId;
      const isPublicOnly = req.user?.role === 'REGULAR_MEMBER';
      const prayers = await pastoralService.getPrayerRequests(branchId, isPublicOnly);
      res.json(prayers);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch prayer requests' });
    }
  }

  public async createPrayer(req: AuthenticatedRequest, res: Response) {
    try {
      const prayer = await pastoralService.createPrayerRequest(req.body);
      res.status(201).json(prayer);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create prayer request' });
    }
  }

  public async updatePrayerStatus(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { status, notes } = req.body;
      const updated = await pastoralService.updatePrayerStatus(id, status, notes);
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update prayer status' });
    }
  }

  // Counseling Sessions
  public async getCounseling(req: AuthenticatedRequest, res: Response) {
    try {
      const branchId = (req.query.branchId as string) || req.branchId;
      const userRole = req.user?.role || 'REGULAR_MEMBER';
      const userId = req.user?.id;

      const sessions = await pastoralService.getCounselingSessions(branchId, userRole, userId);
      res.json(sessions);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch counseling sessions' });
    }
  }

  public async createCounseling(req: AuthenticatedRequest, res: Response) {
    try {
      const operatorEmail = req.user?.email || 'pastor@gracecathedral.org';
      const session = await pastoralService.createCounselingSession(req.body, operatorEmail);
      res.status(201).json(session);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create counseling session' });
    }
  }

  public async updateCounselingStatus(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { status, notes } = req.body;
      const operatorEmail = req.user?.email || 'pastor@gracecathedral.org';
      const updated = await pastoralService.updateCounselingStatus(id, status, notes, operatorEmail);
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update counseling session' });
    }
  }

  // Visitations
  public async getVisitations(req: AuthenticatedRequest, res: Response) {
    try {
      const branchId = (req.query.branchId as string) || req.branchId;
      const visitations = await pastoralService.getVisitations(branchId);
      res.json(visitations);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch visitations' });
    }
  }

  public async createVisitation(req: AuthenticatedRequest, res: Response) {
    try {
      const operatorEmail = req.user?.email || 'pastor@gracecathedral.org';
      const visitation = await pastoralService.createVisitation(req.body, operatorEmail);
      res.status(201).json(visitation);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create visitation record' });
    }
  }
}

export const pastoralController = new PastoralController();
