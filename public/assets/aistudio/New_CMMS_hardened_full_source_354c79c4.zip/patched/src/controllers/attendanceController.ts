import { Response } from 'express';
import { attendanceService } from '../services/attendanceService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';

export class AttendanceController {
  public async getAttendance(req: AuthenticatedRequest, res: Response) {
    try {
      const branchId = (req.query.branchId as string) || req.branchId;
      const date = req.query.date as string;
      const memberId = req.query.memberId as string;

      const records = await attendanceService.getAttendance({
        branchId: branchId === 'all' ? undefined : branchId,
        date,
        memberId,
      });

      res.json(records);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch attendance records' });
    }
  }

  public async checkIn(req: AuthenticatedRequest, res: Response) {
    try {
      const record = req.body;
      const saved = await attendanceService.recordCheckIn(record);
      res.status(201).json(saved);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Check-in failed' });
    }
  }

  public async bulkAttendance(req: AuthenticatedRequest, res: Response) {
    try {
      const { records } = req.body;
      if (!Array.isArray(records) || records.length === 0) {
        return res.status(400).json({ error: 'Valid array of attendance records required' });
      }
      const operatorEmail = req.user?.email || 'admin@gracecathedral.org';
      const result = await attendanceService.bulkRecordAttendance(records, operatorEmail);
      res.status(201).json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Bulk attendance recording failed' });
    }
  }

  public async getLiveCounts(req: AuthenticatedRequest, res: Response) {
    try {
      const branchId = (req.query.branchId as string) || req.branchId;
      const date = req.query.date as string;
      const stats = await attendanceService.getLiveCounts(branchId, date);
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch live counts' });
    }
  }

  public async getEvents(req: AuthenticatedRequest, res: Response) {
    try {
      const events = await attendanceService.getEvents();
      res.json(events);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch events' });
    }
  }

  public async createEvent(req: AuthenticatedRequest, res: Response) {
    try {
      const event = await attendanceService.createEvent(req.body);
      res.status(201).json(event);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create event' });
    }
  }
}

export const attendanceController = new AttendanceController();
