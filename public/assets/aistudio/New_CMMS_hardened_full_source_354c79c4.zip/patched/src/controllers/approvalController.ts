import { Response } from 'express';
import { approvalService } from '../services/approvalService';
import { AuthenticatedRequest } from '../middleware/authMiddleware';

export class ApprovalController {
  public async getQueue(req: AuthenticatedRequest, res: Response) {
    try {
      const status = req.query.status as string;
      const branchId = (req.query.branchId as string) || req.branchId;
      const queue = await approvalService.getQueue(status, branchId === 'all' ? undefined : branchId);
      res.json(queue);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch approvals queue' });
    }
  }

  public async submit(req: AuthenticatedRequest, res: Response) {
    try {
      const requestData = req.body;
      const created = await approvalService.submitRequest(requestData);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to submit workflow request' });
    }
  }

  public async approve(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { comment } = req.body;
      const approverEmail = req.user?.email || 'admin@gracecathedral.org';
      const approved = await approvalService.approveRequest(id, approverEmail, comment);
      res.json(approved);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to approve request' });
    }
  }

  public async reject(req: AuthenticatedRequest, res: Response) {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      if (!reason) {
        return res.status(400).json({ error: 'Rejection reason is required' });
      }
      const approverEmail = req.user?.email || 'admin@gracecathedral.org';
      const rejected = await approvalService.rejectRequest(id, approverEmail, reason);
      res.json(rejected);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to reject request' });
    }
  }
}

export const approvalController = new ApprovalController();
