/**
 * Shared JWT configuration.
 *
 * Production requires a high-entropy signing secret. SUPABASE_JWT_SECRET is
 * retained as a migration compatibility fallback for deployments that already
 * use it to verify application-issued tokens.
 */
const configuredSecret =
  process.env.JWT_SECRET || process.env.SUPABASE_JWT_SECRET;

if (process.env.NODE_ENV === 'production') {
  if (!configuredSecret || configuredSecret.length < 32) {
    throw new Error(
      'A JWT_SECRET (or legacy SUPABASE_JWT_SECRET during migration) of at least 32 characters is required in production.'
    );
  }
  if (configuredSecret === 'cmms-dev-jwt-signing-secret-change-in-prod') {
    throw new Error('The development JWT secret is not permitted in production.');
  }
}

export const JWT_SECRET =
  configuredSecret ||
  (process.env.NODE_ENV === 'production'
    ? (() => { throw new Error('A strong JWT signing secret is required in production.'); })()
    : 'cmms-dev-jwt-signing-secret-change-in-prod');
