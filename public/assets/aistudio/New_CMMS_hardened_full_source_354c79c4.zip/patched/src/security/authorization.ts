import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { UserRole } from '../types';
import { getAdminClient, isSupabaseConfigured } from '../lib/supabase';
import { normalizeUserRole } from '../utils/rbac';
export { normalizeUserRole };
import { JWT_SECRET } from './jwtConfig';
import {
  classifyTokenOrigin,
  requireStoredAccount,
  mayUseLocalVerification,
  SovereignTokenError,
  verifySovereignToken,
} from './sovereignJwt';
import { db } from '../../server/db';
import { securityAuditService } from '../../server/services/securityAuditService';
import {
  extractAccessTokenFromRequest,
  verifyCsrfForCookieAuth,
} from '../../server/utils/cookieSecurity';

// ==============================================================================
// 1. UNIFIED PERMISSIONS MODEL (RESOURCE.ACTION)
// ==============================================================================
export type Permission =
  // Members
  | 'members.read'
  | 'members.create'
  | 'members.update'
  | 'members.delete'
  | 'members.export'
  // Families
  | 'families.read'
  | 'families.create'
  | 'families.update'
  | 'families.delete'
  // Attendance & Check-in
  | 'attendance.read'
  | 'attendance.create'
  | 'attendance.update'
  | 'attendance.delete'
  // Events
  | 'events.read'
  | 'events.create'
  | 'events.update'
  | 'events.delete'
  | 'events.manage'
  // Finance, Donations & Ledgers
  | 'finance.read'
  | 'finance.create'
  | 'finance.approve'
  | 'finance.export'
  // Pastoral Care & Counseling
  | 'pastoral.read'
  | 'pastoral.create'
  | 'pastoral.update'
  | 'pastoral.confidential'
  | 'prayer.read'
  | 'prayer.create'
  | 'prayer.update'
  | 'prayer.delete'
  | 'counseling.read'
  | 'counseling.create'
  | 'counseling.update'
  | 'counseling.confidential'
  | 'visitations.read'
  | 'visitations.create'
  | 'visitations.update'
  | 'visitations.manage'
  // Ministries & Collaboration
  | 'ministries.read'
  | 'ministries.manage'
  | 'groups.read'
  | 'groups.manage'
  // Volunteers
  | 'volunteers.read'
  | 'volunteers.manage'
  // Assets & Inventory
  | 'assets.read'
  | 'assets.manage'
  // Documents
  | 'documents.read'
  | 'documents.manage'
  // Communications (SMS / Email broadcasts)
  | 'communications.read'
  | 'communications.manage'
  // Workflows & Approvals
  | 'workflows.read'
  | 'workflows.create'
  | 'workflows.manage'
  // Branches / Campuses
  | 'branches.read'
  | 'branches.manage'
  // Users & RBAC
  | 'users.read'
  | 'users.manage'
  // Reports & Analytics
  | 'reports.read'
  | 'reports.export'
  // System & Infrastructure
  | 'system.manage'
  | 'backup.manage'
  | 'audit.read'
  // Devotions & Bible
  | 'devotions.read'
  | 'devotions.manage'
  | 'devotions.engage'
  | 'bible.read'
  | 'bible.personal';

// ==============================================================================
// 2. AUTHORITATIVE ROLE TO PERMISSION MAPPING MATRIX
// ==============================================================================
export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  SYSTEM_ADMIN: [
    // System Administrator possesses all operational and infrastructural permissions
    'members.read',
    'members.create',
    'members.update',
    'members.delete',
    'members.export',
    'families.read',
    'families.create',
    'families.update',
    'families.delete',
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'attendance.delete',
    'events.read',
    'events.create',
    'events.update',
    'events.delete',
    'events.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'pastoral.read',
    'pastoral.create',
    'pastoral.update',
    'pastoral.confidential',
    'prayer.read',
    'prayer.create',
    'prayer.update',
    'prayer.delete',
    'counseling.read',
    'counseling.create',
    'counseling.update',
    'counseling.confidential',
    'visitations.read',
    'visitations.create',
    'visitations.update',
    'visitations.manage',
    'ministries.read',
    'ministries.manage',
    'groups.read',
    'groups.manage',
    'volunteers.read',
    'volunteers.manage',
    'assets.read',
    'assets.manage',
    'documents.read',
    'documents.manage',
    'communications.read',
    'communications.manage',
    'workflows.read',
    'workflows.create',
    'workflows.manage',
    'branches.read',
    'branches.manage',
    'users.read',
    'users.manage',
    'reports.read',
    'reports.export',
    'system.manage',
    'backup.manage',
    'audit.read',
    'devotions.read',
    'devotions.manage',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],

  MANAGER: [
    // Operations Manager / Church Admin: Full operational control across all church modules.
    // EXCEPTION: Strictly DENIED system settings, database backup/restore, audit logs, and member deletion
    'members.read',
    'members.create',
    'members.update',
    'members.export',
    'families.read',
    'families.create',
    'families.update',
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'events.read',
    'events.create',
    'events.update',
    'events.delete',
    'events.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'pastoral.read',
    'pastoral.create',
    'pastoral.update',
    'prayer.read',
    'prayer.create',
    'prayer.update',
    'counseling.read',
    'visitations.read',
    'visitations.create',
    'visitations.update',
    'visitations.manage',
    'ministries.read',
    'ministries.manage',
    'groups.read',
    'groups.manage',
    'volunteers.read',
    'volunteers.manage',
    'assets.read',
    'assets.manage',
    'documents.read',
    'documents.manage',
    'communications.read',
    'communications.manage',
    'workflows.read',
    'workflows.create',
    'workflows.manage',
    'branches.read',
    'reports.read',
    'reports.export',
    'devotions.read',
    'devotions.manage',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],

  PASTOR: [
    // Pastoral leadership: Spiritual oversight, counseling, visitations, member directory, preaching
    'members.read',
    'members.create',
    'members.update',
    'families.read',
    'families.create',
    'families.update',
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'events.read',
    'events.create',
    'events.update',
    'events.manage',
    'pastoral.read',
    'pastoral.create',
    'pastoral.update',
    'pastoral.confidential',
    'counseling.read',
    'counseling.create',
    'counseling.update',
    'counseling.confidential',
    'prayer.read',
    'prayer.create',
    'prayer.update',
    'visitations.read',
    'visitations.create',
    'visitations.update',
    'visitations.manage',
    'ministries.read',
    'ministries.manage',
    'groups.read',
    'groups.manage',
    'documents.read',
    'communications.read',
    'communications.manage',
    'branches.read',
    'workflows.read',
    'workflows.create',
    'workflows.manage',
    'reports.read',
    'devotions.read',
    'devotions.manage',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],

  MINISTRY_LEADER: [
    // Ministry & Department Leader: Attendance rosters, department communications, volunteer coordination
    'attendance.read',
    'attendance.create',
    'attendance.update',
    'events.read',
    'events.create',
    'events.update',
    'events.manage',
    'ministries.read',
    'ministries.manage',
    'groups.read',
    'groups.manage',
    'volunteers.read',
    'documents.read',
    'communications.read',
    'communications.manage',
    'branches.read',
    'workflows.read',
    'workflows.create',
    'reports.read',
    'devotions.read',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],

  REGULAR_MEMBER: [
    // Church Member: Self-service profile, personal giving receipts, attendance QR check-in, devotionals, Bible
    'attendance.create', // Self check-in via QR
    'events.read',
    'finance.read', // Restricted to personal records in verifyResourceAccess
    'prayer.read', // Restricted to own prayer requests
    'prayer.create',
    'counseling.read', // Restricted to own sessions
    'ministries.read',
    'groups.read',
    'documents.read', // Public non-confidential documents only
    'branches.read',
    'workflows.create',
    'devotions.read',
    'devotions.engage',
    'bible.read',
    'bible.personal',
  ],
};

// ==============================================================================
// 2B. EXPLICIT DENY RULES & ROLE DEFINITIONS (users -> user_roles -> roles -> role_permissions -> effective permissions)
// ==============================================================================
export const SYSTEM_ONLY_PERMISSIONS: Permission[] = [
  'system.manage',
  'backup.manage',
  'audit.read',
  'branches.manage',
  'users.manage',
  'members.delete',
  'families.delete',
  'attendance.delete',
  'prayer.delete',
];

/**
 * Explicit deny rules per role when a user is NOT SYSTEM_ADMIN.
 * Even when multiple roles are combined (e.g., PASTOR + MINISTRY_LEADER, or MANAGER + PASTOR),
 * non-SYSTEM_ADMIN roles must NEVER gain system/infrastructure permissions (`system.manage`, `backup.manage`, etc.)
 * unless `SYSTEM_ADMIN` is explicitly assigned in their `user_roles`.
 */
export const ROLE_EXPLICIT_DENY_PERMISSIONS: Record<UserRole, Permission[]> = {
  SYSTEM_ADMIN: [],
  MANAGER: [
    'system.manage',
    'backup.manage',
    'members.delete',
    'families.delete',
    'attendance.delete',
    'prayer.delete',
  ],
  PASTOR: [
    'system.manage',
    'backup.manage',
    'audit.read',
    'users.read',
    'users.manage',
    'branches.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'members.delete',
    'families.delete',
  ],
  MINISTRY_LEADER: [
    'system.manage',
    'backup.manage',
    'audit.read',
    'users.read',
    'users.manage',
    'branches.manage',
    'finance.read',
    'finance.create',
    'finance.approve',
    'finance.export',
    'pastoral.confidential',
    'counseling.confidential',
    'members.delete',
    'families.delete',
  ],
  REGULAR_MEMBER: [
    'system.manage',
    'backup.manage',
    'audit.read',
    'users.read',
    'users.manage',
    'branches.manage',
    'members.create',
    'members.update',
    'members.delete',
    'members.export',
    'pastoral.confidential',
    'counseling.confidential',
  ],
};

export interface RoleDefinitionRecord {
  id: UserRole;
  code: UserRole;
  name: string;
  description: string;
  isSystemRole: boolean;
  permissions: Permission[];
  explicitDeniedPermissions: Permission[];
}

export const ROLES_CATALOG: Record<UserRole, RoleDefinitionRecord> = {
  SYSTEM_ADMIN: {
    id: 'SYSTEM_ADMIN',
    code: 'SYSTEM_ADMIN',
    name: 'System Administrator',
    description: 'Full infrastructure, security, multi-campus, backup/restore, and RBAC governance.',
    isSystemRole: true,
    permissions: ROLE_PERMISSIONS.SYSTEM_ADMIN,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.SYSTEM_ADMIN,
  },
  MANAGER: {
    id: 'MANAGER',
    code: 'MANAGER',
    name: 'Operations Manager',
    description: 'Operational management across members, events, finance, ministries, and approvals. Denied system settings and backup/restore.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.MANAGER,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.MANAGER,
  },
  PASTOR: {
    id: 'PASTOR',
    code: 'PASTOR',
    name: 'Pastor & Spiritual Counselor',
    description: 'Spiritual oversight, member directory, confidential pastoral counseling, visitations, prayer requests, and devotionals.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.PASTOR,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.PASTOR,
  },
  MINISTRY_LEADER: {
    id: 'MINISTRY_LEADER',
    code: 'MINISTRY_LEADER',
    name: 'Ministry Leader',
    description: 'Ministry roster management, department attendance, volunteer coordination, and ministry events.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.MINISTRY_LEADER,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.MINISTRY_LEADER,
  },
  REGULAR_MEMBER: {
    id: 'REGULAR_MEMBER',
    code: 'REGULAR_MEMBER',
    name: 'Regular Member',
    description: 'Personal profile self-service, attendance QR check-in, devotionals, Bible study, and personal prayer requests.',
    isSystemRole: false,
    permissions: ROLE_PERMISSIONS.REGULAR_MEMBER,
    explicitDeniedPermissions: ROLE_EXPLICIT_DENY_PERMISSIONS.REGULAR_MEMBER,
  },
};

/**
 * Resolves the ordered list of user roles (`user_roles`) from primaryRole + additionalRoles,
 * ensuring the primary role is never overwritten when adding additional roles.
 */
export function resolveUserRolesList(
  primaryRoleInput?: UserRole | string | null,
  additionalRolesInput?: (UserRole | string)[] | null
): {
  primaryRole: UserRole;
  additionalRoles: UserRole[];
  allRoles: UserRole[];
  userRoles: { role: UserRole; isPrimary: boolean }[];
} {
  const primaryRole = normalizeUserRole(primaryRoleInput || 'REGULAR_MEMBER');
  const rawExtras = Array.isArray(additionalRolesInput) ? additionalRolesInput : [];
  const additionalRoles: UserRole[] = [];
  for (const r of rawExtras) {
    if (!r) continue;
    const norm = normalizeUserRole(String(r));
    if (norm !== primaryRole && !additionalRoles.includes(norm)) {
      additionalRoles.push(norm);
    }
  }
  const allRoles: UserRole[] = [primaryRole, ...additionalRoles];
  const userRoles = allRoles.map((r, idx) => ({
    role: r,
    isPrimary: idx === 0,
  }));
  return { primaryRole, additionalRoles, allRoles, userRoles };
}

/**
 * Computes effective permissions following:
 * users -> user_roles -> roles -> role_permissions -> effective permissions
 *
 * Effective permissions = Union of `role_permissions` for all assigned `user_roles`,
 * minus any explicit user-level `deniedPermissions` and subject to system-level boundary guards
 * (a non-SYSTEM_ADMIN user never gains `system.manage` or `backup.manage` from combining non-admin roles).
 */
export function computeEffectivePermissions(
  primaryRoleInput: UserRole | string,
  additionalRolesInput?: (UserRole | string)[] | null,
  explicitUserDeniedPermissions?: (Permission | string)[] | null
): {
  primaryRole: UserRole;
  additionalRoles: UserRole[];
  allRoles: UserRole[];
  userRoles: { role: UserRole; isPrimary: boolean }[];
  effectivePermissions: Permission[];
  deniedPermissions: Permission[];
  roleBreakdown: { role: UserRole; isPrimary: boolean; grantedPermissions: Permission[] }[];
} {
  const { primaryRole, additionalRoles, allRoles, userRoles } = resolveUserRolesList(
    primaryRoleInput,
    additionalRolesInput
  );

  const unionSet = new Set<Permission>();
  const roleBreakdown: { role: UserRole; isPrimary: boolean; grantedPermissions: Permission[] }[] = [];

  for (const assignment of userRoles) {
    const perms = ROLE_PERMISSIONS[assignment.role] || [];
    for (const p of perms) {
      unionSet.add(p);
    }
    roleBreakdown.push({
      role: assignment.role,
      isPrimary: assignment.isPrimary,
      grantedPermissions: [...perms],
    });
  }

  const hasSystemAdmin = allRoles.includes('SYSTEM_ADMIN');
  const deniedSet = new Set<Permission>();

  // If user does NOT hold SYSTEM_ADMIN, enforce infrastructure boundary deny rules:
  // Combining PASTOR + MINISTRY_LEADER or MANAGER + PASTOR must never grant system.manage or backup.manage
  if (!hasSystemAdmin) {
    deniedSet.add('system.manage');
    deniedSet.add('backup.manage');
    deniedSet.add('branches.manage');
    deniedSet.add('members.delete');
    deniedSet.add('families.delete');
    deniedSet.add('attendance.delete');
    deniedSet.add('prayer.delete');

    // If every assigned role explicitly denies a permission (intersection of role deny rules),
    // ensure it stays in deniedSet for transparency.
    const candidateDenies = new Set<Permission>();
    for (const r of allRoles) {
      for (const d of ROLE_EXPLICIT_DENY_PERMISSIONS[r] || []) {
        candidateDenies.add(d);
      }
    }
    for (const d of candidateDenies) {
      const grantedByAnyAssignedRole = allRoles.some((r) => (ROLE_PERMISSIONS[r] || []).includes(d));
      if (!grantedByAnyAssignedRole) {
        deniedSet.add(d);
      }
    }
  }

  // Apply explicit user-level deny rules if provided
  if (Array.isArray(explicitUserDeniedPermissions)) {
    for (const rawDeny of explicitUserDeniedPermissions) {
      if (rawDeny && typeof rawDeny === 'string') {
        deniedSet.add(rawDeny as Permission);
      }
    }
  }

  for (const deniedPerm of deniedSet) {
    unionSet.delete(deniedPerm);
  }

  return {
    primaryRole,
    additionalRoles,
    allRoles,
    userRoles,
    effectivePermissions: Array.from(unionSet),
    deniedPermissions: Array.from(deniedSet),
    roleBreakdown,
  };
}

/**
 * Backend privilege-escalation guard for role mutations.
 * Rules enforced:
 * 1. A user must NOT modify their own SYSTEM_ADMIN role or permissions (cannot demote/remove own SYSTEM_ADMIN or alter own roles).
 * 2. A non-SYSTEM_ADMIN operator must NEVER assign or remove SYSTEM_ADMIN (primary or additional) to any user.
 * 3. A non-SYSTEM_ADMIN operator must NEVER modify an existing SYSTEM_ADMIN account.
 */
export function validateRoleMutationSecurity(params: {
  operator: { id: string; email?: string; role: UserRole; roles?: UserRole[]; additionalRoles?: UserRole[] };
  targetUser: { id: string; email?: string; role: UserRole; roles?: UserRole[]; additionalRoles?: UserRole[] };
  nextPrimaryRole: UserRole;
  nextAdditionalRoles: UserRole[];
}): { valid: boolean; code?: string; message?: string; statusCode?: number } {
  const { operator, targetUser, nextPrimaryRole, nextAdditionalRoles } = params;
  const operatorRoles = resolveUserRolesList(operator.role, operator.additionalRoles || operator.roles).allRoles;
  const targetCurrentRoles = resolveUserRolesList(
    targetUser.role,
    targetUser.additionalRoles || targetUser.roles
  ).allRoles;
  const nextAllRoles = resolveUserRolesList(nextPrimaryRole, nextAdditionalRoles).allRoles;

  const isOperatorSystemAdmin = operatorRoles.includes('SYSTEM_ADMIN');
  const isTargetCurrentlySystemAdmin = targetCurrentRoles.includes('SYSTEM_ADMIN');
  const isNextAssigningSystemAdmin = nextAllRoles.includes('SYSTEM_ADMIN');
  const isSelf =
    operator.id === targetUser.id ||
    (Boolean(operator.email) &&
      Boolean(targetUser.email) &&
      operator.email!.toLowerCase() === targetUser.email!.toLowerCase());

  // Rule 1: Non-admin must NEVER assign SYSTEM_ADMIN or modify a SYSTEM_ADMIN user
  if (!isOperatorSystemAdmin) {
    if (isNextAssigningSystemAdmin) {
      return {
        valid: false,
        code: 'PRIVILEGE_ESCALATION_FORBIDDEN',
        message: 'Privilege escalation blocked: Only a SYSTEM_ADMIN can assign the SYSTEM_ADMIN role.',
        statusCode: 403,
      };
    }
    if (isTargetCurrentlySystemAdmin) {
      return {
        valid: false,
        code: 'PRIVILEGE_ESCALATION_FORBIDDEN',
        message: 'Forbidden: Non-administrators cannot modify roles of a SYSTEM_ADMIN account.',
        statusCode: 403,
      };
    }
  }

  // Rule 2: A user must NOT modify their own SYSTEM_ADMIN role/permissions
  if (isSelf && isTargetCurrentlySystemAdmin) {
    const rolesChanged =
      nextPrimaryRole !== normalizeUserRole(targetUser.role) ||
      nextAllRoles.length !== targetCurrentRoles.length ||
      !nextAllRoles.every((r) => targetCurrentRoles.includes(r));

    if (!nextAllRoles.includes('SYSTEM_ADMIN') || nextPrimaryRole !== 'SYSTEM_ADMIN' || rolesChanged) {
      return {
        valid: false,
        code: 'SELF_ADMIN_MODIFICATION_FORBIDDEN',
        message: 'Security policy violation: You cannot modify or remove your own SYSTEM_ADMIN role or permissions.',
        statusCode: 403,
      };
    }
  }

  // Rule 3: Prevent self-privilege escalation for any non-admin user
  if (isSelf && !isOperatorSystemAdmin) {
    return {
      valid: false,
      code: 'SELF_ROLE_ESCALATION_FORBIDDEN',
      message: 'Security policy violation: Users cannot modify their own assigned roles.',
      statusCode: 403,
    };
  }

  return { valid: true };
}

// ==============================================================================
// 3. AUTHENTICATED USER CONTEXT INTERFACES & STRUCTURED AUTH ERRORS
// ==============================================================================
export type AccountStatus = 'Active' | 'Inactive' | 'Suspended' | 'Pending' | 'Locked';

export interface AuthenticatedUserPayload {
  id: string;
  email: string;
  name: string;
  full_name: string;
  phone?: string | null;
  role: UserRole;
  primaryRole?: UserRole;
  additionalRoles?: UserRole[];
  roles?: UserRole[];
  userRoles?: { role: UserRole; isPrimary: boolean }[];
  deniedPermissions?: Permission[];
  effectivePermissions?: Permission[];
  tenantId: string;
  tenant_id: string;
  tenantName?: string;
  branchId: string;
  branch_id: string;
  branchIds: string[]; // List of authorized branch IDs or ['*'] for all
  assignedCampuses?: string[];
  branchName?: string;
  status: AccountStatus;
  must_change_password: boolean;
  mustChangePassword: boolean;
  memberId?: string;
  permissions: Permission[];
  aal: 'aal1' | 'aal2';
  mfa_enabled: boolean;
  mfaEnabled: boolean;
  isMfaEnabled: boolean;
  mfa_enrolled: boolean;
  mfaEnrolled: boolean;
  last_max_auth_at?: string | null;
  temp_password_expires_at?: string | null;
  session_revoked_at?: string | null;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUserPayload;
  tenantId?: string;
  branchId?: string;
}

export class AuthError extends Error {
  public readonly code: string;
  public readonly statusCode: number;

  constructor(code: string, message: string, statusCode: number = 401) {
    super(message);
    this.name = 'AuthError';
    this.code = code;
    this.statusCode = statusCode;
  }
}

export function sendAuthError(res: Response, statusCode: number, code: string, message: string, extra?: Record<string, any>) {
  return res.status(statusCode).json({
    success: false,
    error: code,
    code,
    message,
    ...(extra || {}),
  });
}

// ==============================================================================
// 4. TOKEN REVOCATION & CAMPUS / TENANT NORMALIZATION HELPERS
// ==============================================================================
const revokedTokenHashes = new Map<string, number>(); // sha256(token) -> expiresAtMs
const userSessionRevokedAtMap = new Map<string, number>(); // userId -> timestampMs when all sessions were revoked

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function revokeSessionToken(token?: string | null, ttlMs: number = 24 * 60 * 60 * 1000): void {
  if (!token) return;
  const now = Date.now();
  for (const [k, exp] of revokedTokenHashes.entries()) {
    if (exp < now) revokedTokenHashes.delete(k);
  }
  revokedTokenHashes.set(hashToken(token.trim()), now + ttlMs);
  securityAuditService.markSessionRevoked(token.trim(), 'SYSTEM', 'Explicit token revocation');
}

export function revokeAllUserSessions(userId: string, timestampMs: number = Date.now()): void {
  if (!userId) return;
  userSessionRevokedAtMap.set(userId.trim(), timestampMs);
  securityAuditService.revokeAllSessionsForUser(userId.trim(), 'SYSTEM', 'Global user session revocation');
}

export function getUserSessionRevokedAt(userId: string): number | undefined {
  if (!userId) return undefined;
  const clean = userId.trim();
  return userSessionRevokedAtMap.get(clean) || securityAuditService.getUserRevokedAtMs(clean);
}

export function isSessionTokenRevoked(token?: string | null): boolean {
  if (!token) return false;
  if (securityAuditService.isSessionIdRevoked(token.trim())) {
    return true;
  }
  const h = hashToken(token.trim());
  const exp = revokedTokenHashes.get(h);
  if (!exp) return false;
  if (exp < Date.now()) {
    revokedTokenHashes.delete(h);
    return false;
  }
  return true;
}

export const DEFAULT_TENANT_UUID = '773627bc-212b-4336-be98-dd44b141d84e';
export const DEFAULT_HQ_BRANCH_UUID = '65204c56-5288-4473-82d5-ae62150dfdb7';

export function canonicalizeCampusGroup(branchId?: string | null): string {
  if (!branchId) return 'hq';
  const b = branchId.trim().toLowerCase();
  if (
    b === DEFAULT_HQ_BRANCH_UUID ||
    b === 'br-1' ||
    b === 'br-001' ||
    b === 'b-001' ||
    b === 'br-hq-01' ||
    b === 'hq-main' ||
    b === 'headquarters' ||
    b === 'headquarters campus'
  ) {
    return 'hq';
  }
  if (b === 'br-2' || b === 'br-002' || b === 'b-002' || b === 'sat-city') {
    return 'br-002';
  }
  if (b === 'br-3' || b === 'br-003' || b === 'b-003' || b === 'out-bethel') {
    return 'br-003';
  }
  return b;
}

export function isSameCampus(branchA?: string | null, branchB?: string | null): boolean {
  if (!branchA || !branchB) return false;
  if (branchA === '*' || branchB === '*') return true;
  return canonicalizeCampusGroup(branchA) === canonicalizeCampusGroup(branchB);
}

export function isSameTenant(tenantA?: string | null, tenantB?: string | null): boolean {
  if (!tenantA || !tenantB) return true;
  const norm = (t: string) => {
    const low = t.trim().toLowerCase();
    if (low === DEFAULT_TENANT_UUID || low === 'tenant-grace-main' || low === 'grace-main') {
      return DEFAULT_TENANT_UUID;
    }
    return low;
  };
  return norm(tenantA) === norm(tenantB);
}

export function normalizeAccountStatus(rawStatus?: string | null): AccountStatus {
  const s = (rawStatus || 'Active').trim().toLowerCase();
  if (s === 'inactive' || s === 'disabled' || s === 'deactivated') return 'Inactive';
  if (s === 'suspended' || s === 'rejected' || s === 'banned') return 'Suspended';
  if (s === 'pending' || s === 'pending approval' || s === 'pending_approval') return 'Pending';
  if (s === 'locked') return 'Locked';
  return 'Active';
}

export function assertAccountStatusActive(status: AccountStatus): void {
  if (status === 'Inactive') {
    throw new AuthError('ACCOUNT_INACTIVE', 'Your account is inactive. Please contact church administration.', 403);
  }
  if (status === 'Suspended') {
    throw new AuthError('ACCOUNT_SUSPENDED', 'Your account has been suspended. Access denied.', 403);
  }
  if (status === 'Pending') {
    throw new AuthError('ACCOUNT_PENDING', 'Your account is pending administrative approval.', 403);
  }
  if (status === 'Locked') {
    throw new AuthError('ACCOUNT_LOCKED', 'Your account is locked. Please contact a System Administrator.', 423);
  }
}

// Short-lived cache for tenant and branch metadata from Supabase
let cachedTenants: Map<string, { id: string; name: string; code: string }> = new Map();
let cachedBranches: Map<string, { id: string; name: string; code: string; tenant_id: string }> = new Map();
let metadataCacheExpiresAt = 0;

async function ensureTenantAndBranchMetadata(): Promise<void> {
  if (Date.now() < metadataCacheExpiresAt && cachedTenants.size > 0) return;
  try {
    const admin = getAdminClient();
    const [{ data: tenants }, { data: branches }] = await Promise.all([
      admin.from('tenants').select('id, name, code'),
      admin.from('branches').select('id, name, code, tenant_id'),
    ]);
    if (Array.isArray(tenants)) {
      const tMap = new Map<string, { id: string; name: string; code: string }>();
      for (const t of tenants) {
        if (t?.id) tMap.set(t.id, t);
      }
      cachedTenants = tMap;
    }
    if (Array.isArray(branches)) {
      const bMap = new Map<string, { id: string; name: string; code: string; tenant_id: string }>();
      for (const b of branches) {
        if (b?.id) bMap.set(b.id, b);
      }
      cachedBranches = bMap;
    }
    metadataCacheExpiresAt = Date.now() + 60_000;
  } catch {
    // Non-fatal metadata lookup
  }
}

// ==============================================================================
// 5. PERMISSION VERIFICATION HELPER (SUPPORTS SINGLE ROLE OR MULTI-ROLE USER)
// ==============================================================================
export function hasPermission(
  roleOrRoles: UserRole | UserRole[] | { role: UserRole; additionalRoles?: UserRole[]; roles?: UserRole[]; permissions?: Permission[]; deniedPermissions?: Permission[] },
  permission: Permission
): boolean {
  if (!roleOrRoles) return false;

  if (typeof roleOrRoles === 'string') {
    const { effectivePermissions } = computeEffectivePermissions(roleOrRoles, []);
    return effectivePermissions.includes(permission);
  }

  if (Array.isArray(roleOrRoles)) {
    if (roleOrRoles.length === 0) return false;
    const [primary, ...extra] = roleOrRoles;
    const { effectivePermissions } = computeEffectivePermissions(primary, extra);
    return effectivePermissions.includes(permission);
  }

  // Object payload (e.g. AuthenticatedUserPayload or SystemUser)
  const { effectivePermissions } = computeEffectivePermissions(
    roleOrRoles.role,
    roleOrRoles.additionalRoles || roleOrRoles.roles || [],
    roleOrRoles.deniedPermissions || []
  );
  return effectivePermissions.includes(permission);
}

// ==============================================================================
// 6. AUTHORITATIVE USER CONTEXT RESOLUTION & AUTHENTICATION MIDDLEWARE
// ==============================================================================

/**
 * Authoritatively resolves an authenticated Supabase `auth.users` record into a
 * complete, verified application session strictly following:
 * Supabase Auth -> auth.users -> profiles -> authoritative role -> tenant -> branch -> permissions -> application session
 */
export async function buildAuthoritativeSessionFromAuthUser(
  authUser: {
    id: string;
    email?: string;
    phone?: string;
    user_metadata?: Record<string, any>;
    app_metadata?: Record<string, any>;
    factors?: any[];
    last_sign_in_at?: string;
  },
  options?: {
    decodedJwt?: any;
    enforceActiveStatus?: boolean;
  }
): Promise<AuthenticatedUserPayload> {
  if (!authUser || !authUser.id) {
    throw new AuthError('INVALID_TOKEN', 'Invalid authentication user record.', 401);
  }

  const admin = getAdminClient();
  const userId = String(authUser.id).trim();
  const userEmail = String(authUser.email || '').trim().toLowerCase();

  // Always declare profile before any lookup so "profile is not defined" is impossible
  let profile: any = null;

  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(userId);
  if (isUuid) {
    const { data: profById, error: profByIdErr } = await admin
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    if (!profByIdErr && profById) {
      profile = profById;
    }
  }

  if (!profile && userEmail) {
    const { data: profByEmail, error: profByEmailErr } = await admin
      .from('profiles')
      .select('*')
      .ilike('email', userEmail)
      .maybeSingle();
    if (!profByEmailErr && profByEmail) {
      profile = profByEmail;
    }
  }

  if (!profile) {
    // If an authenticated Supabase Auth user exists in auth.users without a public.profiles row yet,
    // provision their authoritative profile row in public.profiles so session resolution never fails with undefined profile.
    const fallbackRole = normalizeUserRole(
      authUser.app_metadata?.role || 'REGULAR_MEMBER'
    );
    const fallbackName =
      authUser.user_metadata?.full_name ||
      authUser.user_metadata?.name ||
      (userEmail ? userEmail.split('@')[0] : 'Staff User');
    const fallbackStatus = authUser.app_metadata?.status || 'Active';

    await ensureTenantAndBranchMetadata();

    if (isUuid && userEmail) {
      try {
        const { data: provisionedProf } = await admin
          .from('profiles')
          .upsert({
            id: userId,
            tenant_id: DEFAULT_TENANT_UUID,
            branch_id: DEFAULT_HQ_BRANCH_UUID,
            full_name: fallbackName,
            email: userEmail,
            role: fallbackRole,
            phone: authUser.phone || null,
            status: fallbackStatus,
          })
          .select('*')
          .maybeSingle();
        if (provisionedProf) {
          profile = provisionedProf;
        }
      } catch {
        // Fallback to synthesized profile below if DB write is temporarily unavailable
      }
    }

    if (!profile) {
      profile = {
        id: userId,
        tenant_id: DEFAULT_TENANT_UUID,
        branch_id: DEFAULT_HQ_BRANCH_UUID,
        full_name: fallbackName,
        email: userEmail,
        role: fallbackRole,
        phone: authUser.phone || null,
        status: fallbackStatus,
      };
    }
  }

  await ensureTenantAndBranchMetadata();

  // 1. Authoritative Role strictly from profiles.role (never from frontend or hardcoded emails)
  if (!profile.role) {
    throw new AuthError('INVALID_ROLE', 'User profile does not have an assigned role.', 403);
  }
  const appMeta = authUser.app_metadata || {};
  const userMeta = authUser.user_metadata || {};

  // Normalized PostgreSQL assignment tables are authoritative when installed.
  // Metadata is retained only as a pre-migration compatibility fallback.
  let roleAssignmentRows: { role: string; is_primary: boolean }[] = [];
  let branchAssignmentRows: { branch_id: string; is_default: boolean }[] = [];
  try {
    const [roleResult, branchResult] = await Promise.all([
      admin.from('profile_role_assignments').select('role,is_primary')
        .eq('user_id', userId).eq('tenant_id', profile.tenant_id),
      admin.from('profile_branch_assignments').select('branch_id,is_default')
        .eq('user_id', userId).eq('tenant_id', profile.tenant_id),
    ]);
    if (!roleResult.error && Array.isArray(roleResult.data)) roleAssignmentRows = roleResult.data;
    if (!branchResult.error && Array.isArray(branchResult.data)) branchAssignmentRows = branchResult.data;
  } catch {
    // Older deployments continue using the profile/app_metadata compatibility path.
  }

  // public.profiles.role is the canonical primary role. A stale or incorrect
  // is_primary assignment must never silently downgrade SYSTEM_ADMIN to PASTOR
  // (or change any other user's primary role) during login/session restoration.
  const role: UserRole = normalizeUserRole(profile.role);
  const primaryAssignedRole = roleAssignmentRows.find((r) => r.is_primary)?.role;
  if (primaryAssignedRole && normalizeUserRole(primaryAssignedRole) !== role) {
    console.warn(
      '[AUTH][RBAC] Primary role assignment mismatch; preserving profiles.role.',
      {
        userId,
        profileRole: role,
        assignedPrimaryRole: normalizeUserRole(primaryAssignedRole),
        tenantId: profile.tenant_id,
      }
    );
  }

  // PostgreSQL role assignments supply secondary roles only. The profile role
  // remains primary even if the assignment table contains a stale primary row.
  const rawAdditionalRoles: string[] = roleAssignmentRows.length > 0
    ? roleAssignmentRows
        .filter((r) => !r.is_primary)
        .map((r) => r.role)
        .filter((r) => normalizeUserRole(r) !== role)
    : Array.isArray(appMeta.additional_roles)
      ? appMeta.additional_roles
      : Array.isArray(profile.additional_roles)
        ? profile.additional_roles
        : [];
  const additionalRoles: UserRole[] = Array.from(
    new Set(
      rawAdditionalRoles
        .map((r) => normalizeUserRole(r))
        .filter((r) => r !== role)
    )
  );
  const allRoles: UserRole[] = [role, ...additionalRoles];

  // 2. Authoritative Account Status from profiles.status (or app_metadata override if set by admin)
  const rawStatus = profile.status || appMeta.status || 'Active';
  const status: AccountStatus = normalizeAccountStatus(rawStatus);

  if (options?.enforceActiveStatus !== false) {
    assertAccountStatusActive(status);
  }

  // 3. Authoritative Tenant from profiles.tenant_id
  const tenantId: string = profile.tenant_id || DEFAULT_TENANT_UUID;
  const tenantObj = cachedTenants.get(tenantId);
  const tenantName: string = tenantObj?.name || 'Grace Cathedral Ministries';

  // 4. Authoritative Branch & Branch IDs from profiles.branch_id
  const branchId: string = profile.branch_id || DEFAULT_HQ_BRANCH_UUID;
  const branchObj = cachedBranches.get(branchId);
  const branchName: string =
    appMeta.branch_name ||
    branchObj?.name ||
    profile.branch_name ||
    'Headquarters Campus';

  const extraAssignedBranches: string[] = branchAssignmentRows.length > 0
    ? branchAssignmentRows.map((r) => r.branch_id)
    : Array.isArray(appMeta.branch_ids)
      ? appMeta.branch_ids
      : Array.isArray(profile.branch_ids)
        ? profile.branch_ids
        : [];

  const assignedCampuses: string[] = Array.isArray(appMeta.assigned_campuses)
    ? appMeta.assigned_campuses
    : Array.isArray(profile.assigned_campuses)
      ? profile.assigned_campuses
      : [branchName];

  let branchIds: string[] = [];
  if (allRoles.includes('SYSTEM_ADMIN') || allRoles.includes('MANAGER') || allRoles.includes('PASTOR')) {
    branchIds = Array.from(new Set(['*', branchId, 'br-001', 'br-1', ...extraAssignedBranches, ...assignedCampuses]));
  } else {
    const aliases = canonicalizeCampusGroup(branchId) === 'hq' ? ['br-001', 'br-1'] : [];
    branchIds = Array.from(new Set([branchId, ...aliases, ...extraAssignedBranches, ...assignedCampuses]));
  }

  // 5. Authoritative Permissions merged across primary role and any additional assigned roles (with explicit deny rules)
  const rawDeniedPerms: string[] = Array.isArray(appMeta.denied_permissions)
    ? appMeta.denied_permissions
    : Array.isArray(profile.denied_permissions)
      ? profile.denied_permissions
      : [];
  const computedRbac = computeEffectivePermissions(role, additionalRoles, rawDeniedPerms);
  const permissions: Permission[] = computedRbac.effectivePermissions;
  const deniedPermissions: Permission[] = computedRbac.deniedPermissions;
  const userRoles = computedRbac.userRoles;

  // 6. Authoritative must_change_password & temporary password expiry
  const mustChangePassword = Boolean(
    profile.must_change_password ??
    appMeta.must_change_password ??
    userMeta.must_change_password ??
    false
  );
  const tempPasswordExpiresAt: string | null =
    profile.temp_password_expires_at ??
    appMeta.temp_password_expires_at ??
    userMeta.temp_password_expires_at ??
    null;

  // Check if session was issued before an administrative password reset or explicit session revocation
  const resetTimeIso = profile.password_reset_at || appMeta.password_reset_at;
  const sessionRevokedIso = appMeta.session_revoked_at || profile.session_revoked_at || null;
  const inMemoryRevokedMs = getUserSessionRevokedAt(profile.id || userId);
  const decodedJwt = options?.decodedJwt;

  if (decodedJwt?.iat) {
    if (resetTimeIso) {
      const resetTimeSec = Math.floor(new Date(resetTimeIso).getTime() / 1000);
      if (decodedJwt.iat + 2 < resetTimeSec && !mustChangePassword) {
        throw new AuthError(
          'SESSION_EXPIRED',
          'Password was reset by an administrator. Please sign in again with your new credentials.',
          401
        );
      }
    }
    if (sessionRevokedIso) {
      const revokedSec = Math.floor(new Date(sessionRevokedIso).getTime() / 1000);
      if (decodedJwt.iat < revokedSec) {
        throw new AuthError(
          'SESSION_REVOKED',
          'Your active sessions were revoked by an administrator. Please sign in again.',
          401
        );
      }
    }
    if (inMemoryRevokedMs) {
      const revokedSec = Math.floor(inMemoryRevokedMs / 1000);
      if (decodedJwt.iat < revokedSec) {
        throw new AuthError(
          'SESSION_REVOKED',
          'Your active sessions were revoked by an administrator. Please sign in again.',
          401
        );
      }
    }
  }

  // 7. Authoritative MFA state (mfa_enabled, mfa_enrolled, aal)
  const verifiedTotpFactor = Array.isArray(authUser.factors)
    ? authUser.factors.find((f: any) => f.factor_type === 'totp' && f.status === 'verified')
    : null;
  const totpSecret = profile.totp_secret || appMeta.totp_secret || null;
  const mfaEnrolled = Boolean(verifiedTotpFactor || totpSecret);
  const mfaEnabled =
    profile.mfa_enabled !== undefined
      ? Boolean(profile.mfa_enabled)
      : appMeta.mfa_enabled !== undefined
        ? Boolean(appMeta.mfa_enabled)
        : userMeta.mfa_enabled !== undefined
          ? Boolean(userMeta.mfa_enabled)
          : Boolean(verifiedTotpFactor);

  let aal: 'aal1' | 'aal2' = 'aal1';
  if (
    decodedJwt?.aal === 'aal2' ||
    appMeta.aal === 'aal2' ||
    decodedJwt?.amr?.some((m: any) => m.method === 'totp' || m.method === 'mfa')
  ) {
    aal = 'aal2';
  } else if (!mfaEnabled) {
    aal = 'aal1';
  }

  const lastMaxAuthAt: string | null =
    profile.last_max_auth_at ||
    appMeta.last_max_auth_at ||
    authUser.last_sign_in_at ||
    null;

  const fullName =
    profile.full_name ||
    profile.name ||
    userMeta.full_name ||
    userMeta.name ||
    (userEmail ? userEmail.split('@')[0] : 'User');

  return {
    id: profile.id || userId,
    email: (profile.email || userEmail).toLowerCase(),
    name: fullName,
    full_name: fullName,
    phone: profile.phone ?? authUser.phone ?? null,
    role,
    primaryRole: role,
    additionalRoles,
    roles: allRoles,
    userRoles,
    deniedPermissions,
    effectivePermissions: permissions,
    tenantId,
    tenant_id: tenantId,
    tenantName,
    branchId,
    branch_id: branchId,
    branchIds,
    assignedCampuses,
    branchName,
    status,
    must_change_password: mustChangePassword,
    mustChangePassword,
    memberId: profile.member_id || undefined,
    permissions,
    aal,
    mfa_enabled: mfaEnabled,
    mfaEnabled,
    isMfaEnabled: mfaEnabled,
    mfa_enrolled: mfaEnrolled,
    mfaEnrolled,
    last_max_auth_at: lastMaxAuthAt,
    temp_password_expires_at: tempPasswordExpiresAt,
    session_revoked_at: sessionRevokedIso,
  };
}

/**
 * Authoritatively resolves a Bearer session token into a verified user context:
 * Supabase Auth -> auth.users -> profiles -> authoritative role -> tenant -> branch -> permissions -> application session
 */
export async function resolveTrustedUserSession(token: string): Promise<AuthenticatedUserPayload> {
  if (!token || !token.trim()) {
    throw new AuthError('NO_TOKEN', 'Authentication token is required.', 401);
  }

  const cleanToken = token.trim();

  // 1. Check if token was explicitly revoked via logout
  if (isSessionTokenRevoked(cleanToken)) {
    throw new AuthError('SESSION_EXPIRED', 'Session has been logged out or revoked. Please sign in again.', 401);
  }

  // 2. Decode JWT payload to check for intermediate MFA challenge tokens or expired timestamps
  let decodedToken: any = null;
  try {
    decodedToken = jwt.decode(cleanToken);
  } catch {
    // Will be rejected by Supabase verification below
  }

  if (decodedToken && typeof decodedToken === 'object') {
    if (decodedToken.purpose === 'mfa_challenge') {
      throw new AuthError(
        'MFA_REQUIRED',
        'Multi-factor authentication verification is required to complete sign-in.',
        401
      );
    }
    if (typeof decodedToken.exp === 'number' && decodedToken.exp * 1000 < Date.now()) {
      throw new AuthError('TOKEN_EXPIRED', 'Your session has expired. Please sign in again.', 401);
    }
  }

  // 3. Authoritative verification via Supabase Auth
  let authData: any = null;
  let authError: any = null;

  if (isSupabaseConfigured) {
    try {
      const admin = getAdminClient();
      const res = await admin.auth.getUser(cleanToken);
      authData = res.data;
      authError = res.error;
    } catch (err: any) {
      authError = err;
    }
  }

  if (authData?.user) {
    // 4. Load authoritative profile, role, status, tenant, branch, permissions, must_change_password, and MFA state
    return buildAuthoritativeSessionFromAuthUser(authData.user, {
      decodedJwt: decodedToken,
      enforceActiveStatus: true,
    });
  }

  // 5. Local verification: ONLY for application-issued tokens. A Supabase-issued token that
  //    Supabase just rejected (revoked / signed out / banned) must never be re-accepted here.
  if (!mayUseLocalVerification(classifyTokenOrigin(decodedToken))) {
    const supabaseSaid = String(authError?.message || '').toLowerCase();
    if (supabaseSaid.includes('expired')) {
      throw new AuthError('TOKEN_EXPIRED', 'Your session has expired. Please sign in again.', 401);
    }
    throw new AuthError('INVALID_TOKEN', 'Invalid or expired authentication session. Please sign in again.', 401);
  }

  let verifiedPayload: any = null;
  try {
    verifiedPayload = verifySovereignToken(cleanToken, {
      secret: JWT_SECRET,
      issuer: process.env.CMMS_JWT_ISSUER || undefined,
    });
  } catch (localJwtErr: any) {
    if (localJwtErr instanceof SovereignTokenError && localJwtErr.code === 'TOKEN_EXPIRED') {
      throw new AuthError('TOKEN_EXPIRED', localJwtErr.message, 401);
    }
    const errMsg = (authError?.message || localJwtErr?.message || '').toLowerCase();
    if (errMsg.includes('expired')) {
      throw new AuthError('TOKEN_EXPIRED', 'Your session has expired. Please sign in again.', 401);
    }
    throw new AuthError('INVALID_TOKEN', 'Invalid or expired authentication session. Please sign in again.', 401);
  }

  if (!verifiedPayload || (!verifiedPayload.sub && !verifiedPayload.userId && !verifiedPayload.email && !verifiedPayload.id)) {
    throw new AuthError('INVALID_TOKEN', 'Invalid session payload.', 401);
  }

  const uId = String(verifiedPayload.sub || verifiedPayload.userId || verifiedPayload.id || '').trim();
  const uEmail = String(verifiedPayload.email || '').trim().toLowerCase();

  // Look up authoritative record in db.getState().systemUsers or members
  const state = db.getState();
  const sysUser = (state.systemUsers || []).find(
    (u) => (uId && u.id === uId) || (uEmail && u.email && u.email.toLowerCase() === uEmail)
  );

  if (!sysUser && requireStoredAccount()) {
    // Opt-in (CMMS_REQUIRE_STORED_ACCOUNT=true): identity, role, tenant and branch come from the stored account, never from token claims.
    throw new AuthError('INVALID_TOKEN', 'Invalid or expired authentication session. Please sign in again.', 401);
  }

  const role: UserRole = normalizeUserRole(
    sysUser?.role || verifiedPayload.role || verifiedPayload.primaryRole || 'REGULAR_MEMBER'
  );

  const rawAdditionalRoles =
    sysUser?.additionalRoles || verifiedPayload.additionalRoles || verifiedPayload.additional_roles || [];
  const additionalRoles: UserRole[] = Array.isArray(rawAdditionalRoles)
    ? rawAdditionalRoles.map((r: string) => normalizeUserRole(r)).filter((r: UserRole) => r !== role)
    : [];
  const allRoles: UserRole[] = [role, ...additionalRoles];

  const tenantId: string =
    sysUser?.tenantId || verifiedPayload.tenantId || verifiedPayload.tenant_id || DEFAULT_TENANT_UUID;
  const branchId: string =
    sysUser?.branchId || verifiedPayload.branchId || verifiedPayload.branch_id || 'br-001';

  let branchIds: string[] = [];
  if (allRoles.includes('SYSTEM_ADMIN') || allRoles.includes('MANAGER') || allRoles.includes('PASTOR')) {
    branchIds = Array.from(new Set(['*', branchId, 'br-001', 'br-1']));
  } else {
    branchIds = Array.from(new Set([branchId, ...(sysUser?.branchIds || verifiedPayload.branchIds || [])]));
  }

  const { effectivePermissions } = computeEffectivePermissions(role, additionalRoles);
  const fullName =
    sysUser?.name ||
    verifiedPayload.name ||
    verifiedPayload.full_name ||
    (uEmail ? uEmail.split('@')[0] : 'Authorized User');

  const status: AccountStatus = normalizeAccountStatus(sysUser?.status || verifiedPayload.status || 'Active');
  assertAccountStatusActive(status);

  return {
    id: sysUser?.id || uId || `usr-${Date.now()}`,
    email: sysUser?.email || uEmail,
    name: fullName,
    full_name: fullName,
    phone: sysUser?.phone || verifiedPayload.phone || null,
    role,
    primaryRole: role,
    additionalRoles,
    roles: allRoles,
    userRoles: allRoles.map((r, idx) => ({ role: r, isPrimary: idx === 0 })),
    deniedPermissions: [],
    effectivePermissions,
    tenantId,
    tenant_id: tenantId,
    tenantName: 'Grace Cathedral Ministries',
    branchId,
    branch_id: branchId,
    branchIds,
    assignedCampuses: [branchId],
    branchName: sysUser?.branchName || verifiedPayload.branchName || 'Headquarters Campus',
    status,
    must_change_password: Boolean(sysUser?.must_change_password ?? verifiedPayload.must_change_password ?? false),
    mustChangePassword: Boolean(sysUser?.must_change_password ?? verifiedPayload.must_change_password ?? false),
    memberId: (sysUser as any)?.memberId || verifiedPayload.memberId,
    permissions: effectivePermissions,
    aal: verifiedPayload.aal || 'aal1',
    mfa_enabled: Boolean(sysUser?.mfaEnabled || sysUser?.isMfaEnabled || verifiedPayload.mfa_enabled),
    mfaEnabled: Boolean(sysUser?.mfaEnabled || sysUser?.isMfaEnabled || verifiedPayload.mfa_enabled),
    isMfaEnabled: Boolean(sysUser?.mfaEnabled || sysUser?.isMfaEnabled || verifiedPayload.mfa_enabled),
    mfa_enrolled: Boolean(sysUser?.totpSecret || verifiedPayload.mfa_enrolled),
    mfaEnrolled: Boolean(sysUser?.totpSecret || verifiedPayload.mfa_enrolled),
    last_max_auth_at: new Date().toISOString(),
  };
}

export async function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const extracted = extractAccessTokenFromRequest(req);

    if (!extracted.token) {
      if (req.headers.authorization) {
        securityAuditService.recordEvent({
          req,
          eventType: 'TOKEN_INVALID_OR_EXPIRED',
          action: 'Malformed Authorization Header Rejected',
          module: 'Authentication & Session Security',
          details: `Rejected request to ${req.method} ${req.originalUrl}: malformed Authorization header format.`,
          outcome: 'BLOCKED',
          severity: 'MEDIUM',
        });
        return sendAuthError(
          res,
          401,
          'INVALID_TOKEN',
          'Invalid Authorization header format. Format must be "Bearer <token>".'
        );
      }
      return sendAuthError(res, 401, 'NO_TOKEN', 'Authentication required. Missing Authorization header or session cookie.');
    }

    // If authenticated solely via HttpOnly cookie on a state-changing request, enforce CSRF protection
    if (extracted.source === 'cookie') {
      const csrfCheck = verifyCsrfForCookieAuth(req);
      if (!csrfCheck.valid) {
        securityAuditService.recordEvent({
          req,
          eventType: 'CSRF_VIOLATION',
          action: 'CSRF Token Validation Failed',
          module: 'Authentication & Session Security',
          details: `Blocked cookie-authenticated ${req.method} ${req.originalUrl}: ${csrfCheck.reason}`,
          outcome: 'BLOCKED',
          severity: 'HIGH',
        });
        return sendAuthError(res, 403, 'CSRF_INVALID', csrfCheck.reason || 'CSRF validation failed.');
      }
    }

    const token = extracted.token;
    const user = await resolveTrustedUserSession(token);

    // Server-enforced must_change_password gate
    // Use strict path matching instead of loose substring checks to prevent routes like /members or /messages from bypassing gates
    const reqPath = (req.path || '').split('?')[0].replace(/\/+$/, '');
    const origUrl = (req.originalUrl || '').split('?')[0].replace(/\/+$/, '');

    const isAuthMe = reqPath === '/me' || origUrl === '/api/auth/me' || origUrl === '/auth/me' || origUrl === '/api/me';
    const isChangePassword =
      reqPath === '/change-password' ||
      reqPath === '/reset-password' ||
      origUrl === '/api/auth/change-password' ||
      origUrl === '/api/auth/reset-password' ||
      origUrl === '/auth/change-password' ||
      origUrl === '/auth/reset-password';
    const isLogout = reqPath === '/logout' || origUrl === '/api/auth/logout' || origUrl === '/auth/logout';
    const isMfaVerify =
      reqPath.startsWith('/staff/mfa') ||
      reqPath.startsWith('/staff/reauth') ||
      origUrl.startsWith('/api/auth/staff/mfa') ||
      origUrl.startsWith('/api/auth/staff/reauth') ||
      origUrl.startsWith('/auth/staff/mfa') ||
      origUrl.startsWith('/auth/staff/reauth');

    const isPasswordExempt = isChangePassword || isLogout || isAuthMe;

    if (user.must_change_password && !isPasswordExempt) {
      return sendAuthError(
        res,
        403,
        'PASSWORD_CHANGE_REQUIRED',
        'You must change your temporary password before accessing the CMMS.',
        {
          must_change_password: true,
          mustChangePassword: true,
        }
      );
    }

    // Server-enforced Staff MFA check when MFA is enabled on the user's authoritative profile
    const userAllRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];
    const isStaffRole = userAllRoles.some(
      (r) => r === 'SYSTEM_ADMIN' || r === 'MANAGER' || r === 'PASTOR' || r === 'MINISTRY_LEADER'
    );

    if (isStaffRole && user.mfa_enabled) {
      const isMfaExempt = isMfaVerify || isChangePassword || isLogout || isAuthMe;

      if (!isMfaExempt && user.aal !== 'aal2') {
        return sendAuthError(
          res,
          401,
          'MFA_REQUIRED',
          'Multi-factor authentication verification is required. Staff session must reach AAL2.'
        );
      }
    }

    req.user = user;
    req.tenantId = user.tenantId;
    req.branchId = user.branchId;

    // Update active session registry lastActivity
    securityAuditService.touchSessionByToken(
      token,
      {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        tenantId: user.tenantId,
        branchId: user.branchId,
        aal: user.aal,
        mfa_enabled: user.mfa_enabled,
      },
      req
    );

    next();
  } catch (err: any) {
    if (err instanceof AuthError) {
      securityAuditService.recordEvent({
        req,
        eventType: err.code === 'SESSION_REVOKED' ? 'SESSION_REVOKED' : 'TOKEN_INVALID_OR_EXPIRED',
        action: `Authentication Rejected (${err.code})`,
        module: 'Authentication & Session Security',
        details: `Rejected ${req.method} ${req.originalUrl}: ${err.message}`,
        outcome: 'BLOCKED',
        severity: err.code === 'SESSION_REVOKED' ? 'HIGH' : 'MEDIUM',
      });
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    const message = err?.message || 'Token verification failed';
    securityAuditService.recordEvent({
      req,
      eventType: 'TOKEN_INVALID_OR_EXPIRED',
      action: 'Authentication Token Verification Failed',
      module: 'Authentication & Session Security',
      details: `Token verification failed on ${req.method} ${req.originalUrl}: ${message}`,
      outcome: 'FAILURE',
      severity: 'MEDIUM',
    });
    return sendAuthError(res, 401, 'UNAUTHORIZED', message);
  }
}

// ==============================================================================
// 6. STEP 7: PERMISSION CHECK MIDDLEWARE (MULTI-ROLE EFFECTIVE PERMISSIONS)
// ==============================================================================
export function requirePermission(permission: Permission) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const user = req.user;
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'UNAUTHORIZED',
        code: 'UNAUTHORIZED',
        message: 'Authentication required before verifying permissions.',
      });
    }

    const userAllRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];
    if (userAllRoles.includes('SYSTEM_ADMIN') && !(user.deniedPermissions || []).includes(permission)) {
      return next();
    }

    const effectivePerms = Array.isArray(user.permissions) && user.permissions.length > 0
      ? user.permissions
      : computeEffectivePermissions(user.role, user.additionalRoles || [], user.deniedPermissions || []).effectivePermissions;

    if (!effectivePerms.includes(permission)) {
      const rolesDisplay = userAllRoles.join(' + ');
      securityAuditService.recordEvent({
        req,
        eventType: 'UNAUTHORIZED_API_ACCESS',
        action: `Forbidden API Access (${permission})`,
        module: 'RBAC & Access Control',
        details: `Blocked ${user.email} (${rolesDisplay}) from ${req.method} ${req.originalUrl} — missing required permission '${permission}'.`,
        actorId: user.id,
        actorEmail: user.email,
        actorName: user.name,
        actorRole: user.role,
        outcome: 'BLOCKED',
        severity: SYSTEM_ONLY_PERMISSIONS.includes(permission) ? 'HIGH' : 'MEDIUM',
        metadata: {
          requiredPermission: permission,
          assignedRoles: userAllRoles,
          path: req.originalUrl,
          method: req.method,
        },
      });
      return res.status(403).json({
        success: false,
        error: `Forbidden: Assigned roles (${rolesDisplay}) lack required permission '${permission}'.`,
        message: `Forbidden: Assigned roles (${rolesDisplay}) lack required permission '${permission}'.`,
        code: 'FORBIDDEN',
        requiredPermission: permission,
      });
    }

    next();
  };
}

export function requireAnyPermission(...permissions: Permission[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const user = req.user;
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'UNAUTHORIZED',
        code: 'UNAUTHORIZED',
        message: 'Authentication required before verifying permissions.',
      });
    }

    const userAllRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];
    const effectivePerms = Array.isArray(user.permissions) && user.permissions.length > 0
      ? user.permissions
      : computeEffectivePermissions(user.role, user.additionalRoles || [], user.deniedPermissions || []).effectivePermissions;

    const hasAny = permissions.some(
      (p) => (userAllRoles.includes('SYSTEM_ADMIN') && !(user.deniedPermissions || []).includes(p)) || effectivePerms.includes(p)
    );
    if (!hasAny) {
      const rolesDisplay = userAllRoles.join(' + ');
      securityAuditService.recordEvent({
        req,
        eventType: 'UNAUTHORIZED_API_ACCESS',
        action: 'Forbidden API Access (Missing Permissions)',
        module: 'RBAC & Access Control',
        details: `Blocked ${user.email} (${rolesDisplay}) from ${req.method} ${req.originalUrl} — requires one of [${permissions.join(', ')}].`,
        actorId: user.id,
        actorEmail: user.email,
        actorName: user.name,
        actorRole: user.role,
        outcome: 'BLOCKED',
        severity: 'MEDIUM',
        metadata: {
          requiredPermissions: permissions,
          assignedRoles: userAllRoles,
          path: req.originalUrl,
          method: req.method,
        },
      });
      return res.status(403).json({
        success: false,
        error: `Forbidden: Assigned roles (${rolesDisplay}) do not hold any of the required permissions.`,
        message: `Forbidden: Assigned roles (${rolesDisplay}) do not hold any of the required permissions.`,
        code: 'FORBIDDEN',
        requiredPermissions: permissions,
      });
    }

    next();
  };
}

// ==============================================================================
// 7. STEP 8: IDOR & RESOURCE OWNERSHIP VERIFICATION HELPER
// ==============================================================================
export interface ResourceAccessOptions {
  checkBranch?: boolean;
  checkOwnership?: boolean;
  confidentialityField?: string;
  counselorIdField?: string;
}

export function verifyResourceAccess(
  resource: any,
  user: AuthenticatedUserPayload,
  options: ResourceAccessOptions = {}
): { authorized: boolean; reason?: string; status: 403 | 404 } {
  if (!resource) {
    return { authorized: false, reason: 'Resource not found', status: 404 };
  }

  const userAllRoles = user.roles && user.roles.length > 0 ? user.roles : [user.role];

  // SYSTEM_ADMIN has full access to all resources within system
  if (userAllRoles.includes('SYSTEM_ADMIN')) {
    return { authorized: true, status: 403 };
  }

  // 1. Cross-Tenant Isolation: Resource tenant must match user tenant
  const resourceTenantId = resource.tenantId || resource.tenant_id;
  const isDefaultTenant = (t?: string) => !t || t === 'tenant-grace-main' || (typeof t === 'string' && t.startsWith('773627bc'));
  if (resourceTenantId && user.tenantId && resourceTenantId !== user.tenantId && (!isDefaultTenant(resourceTenantId) || !isDefaultTenant(user.tenantId))) {
    return {
      authorized: false,
      reason: 'Cross-tenant resource access is strictly forbidden (IDOR protection)',
      status: 403,
    };
  }

  // 2. Branch Access Isolation
  const checkBranch = options.checkBranch !== false;
  const resourceBranchId = resource.branchId || resource.branch_id;
  if (checkBranch && resourceBranchId) {
    // Normalization helper for branch codes (e.g. b-001 vs br-001)
    const normB = (b?: string) => (b || '').trim().toLowerCase().replace(/^b-(\d+)/, 'br-$1');
    const normResourceBranch = normB(resourceBranchId);

    // Membership Application Review: Pastoral & administrative leadership have church-wide authority to vet/admit applicants
    const isMembershipReview =
      resource.requestType === 'Membership Application' &&
      (userAllRoles.includes('MANAGER') || userAllRoles.includes('PASTOR'));

    const hasBranchAccess =
      isMembershipReview ||
      user.branchIds.includes('*') ||
      user.branchIds.some((b) => normB(b) === normResourceBranch) ||
      normB(user.branchId) === normResourceBranch;

    if (!hasBranchAccess) {
      return {
        authorized: false,
        reason: `Resource belongs to branch '${resourceBranchId}'. Access is restricted to user's assigned branch.`,
        status: 403,
      };
    }
  }

  // 3. Confidentiality for Pastoral Care & Counseling
  const confidentiality = resource.confidentialityLevel || resource.confidentiality || resource[options.confidentialityField || ''];
  if (confidentiality) {
    const counselorId = resource.counselorId || resource.pastorId || resource[options.counselorIdField || ''];
    const isOrdainedPastor = userAllRoles.includes('PASTOR');

    if (confidentiality === 'SEALED') {
      if (counselorId !== user.id && counselorId !== user.email) {
        return {
          authorized: false,
          reason: 'Sealed pastoral counseling records can only be viewed by the assigned counselor.',
          status: 403,
        };
      }
    } else if (confidentiality === 'CONFIDENTIAL' || confidentiality === 'STRICTLY_CONFIDENTIAL') {
      if (!isOrdainedPastor && counselorId !== user.id && counselorId !== user.email) {
        return {
          authorized: false,
          reason: 'Confidential pastoral notes are restricted to ordained pastoral counselors.',
          status: 403,
        };
      }
    }
  }

  // 4. Resource Ownership Verification (Members accessing personal resources when they hold ONLY REGULAR_MEMBER)
  const isOnlyRegularMember = userAllRoles.length === 1 && userAllRoles[0] === 'REGULAR_MEMBER';
  if (isOnlyRegularMember || options.checkOwnership) {
    const isOwner =
      (resource.id && (resource.id === user.id || resource.id === user.memberId)) ||
      (resource.memberId && (resource.memberId === user.id || resource.memberId === user.memberId)) ||
      (resource.userId && resource.userId === user.id) ||
      (resource.createdById && resource.createdById === user.id) ||
      (resource.submittedById && resource.submittedById === user.id) ||
      (resource.email && resource.email.toLowerCase() === user.email.toLowerCase());

    if (!isOwner && isOnlyRegularMember) {
      return {
        authorized: false,
        reason: 'Forbidden: Regular members may only view or manage their own records.',
        status: 403,
      };
    }
  }

  return { authorized: true, status: 403 };
}

// ==============================================================================
// 8. COLLECTION FILTERING HELPER (APPLIES TENANT & BRANCH ISOLATION AUTOMATICALLY)
// ==============================================================================
export function filterCollectionByAccess<T extends Record<string, any>>(
  collection: T[],
  user: AuthenticatedUserPayload,
  options: { filterOwnershipForMembers?: boolean } = {}
): T[] {
  return collection.filter((item) => {
    // 1. Tenant match
    const tenantId = item.tenantId || item.tenant_id;
    if (tenantId && !isSameTenant(tenantId, user.tenantId)) {
      return false;
    }

    // 2. Branch match
    if (!user.branchIds.includes('*')) {
      const branchId = item.branchId || item.branch_id;
      if (
        branchId &&
        !user.branchIds.some((b) => isSameCampus(b, branchId)) &&
        !isSameCampus(user.branchId, branchId)
      ) {
        return false;
      }
    }

    // 3. Member personal ownership filter
    if (options.filterOwnershipForMembers && user.role === 'REGULAR_MEMBER') {
      const isOwner =
        (item.id && (item.id === user.id || item.id === user.memberId)) ||
        (item.memberId && (item.memberId === user.id || item.memberId === user.memberId)) ||
        (item.userId && item.userId === user.id) ||
        (item.createdById && item.createdById === user.id) ||
        (item.submittedById && item.submittedById === user.id) ||
        (item.email && item.email.toLowerCase() === user.email.toLowerCase());

      if (!isOwner) return false;
    }

    return true;
  });
}
