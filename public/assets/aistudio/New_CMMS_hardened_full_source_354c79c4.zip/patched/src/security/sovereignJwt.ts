/**
 * Verification of application-issued ("sovereign") JWTs, plus the rule that decides when
 * the local-secret path may be used instead of Supabase Auth.
 *
 * Problem in authenticateToken() (src/security/authorization.ts, ~L1320-1400):
 *   1. If `supabase.auth.getUser()` returns ANY error, the code falls through to
 *      `jwt.verify(token, JWT_SECRET)`. When JWT_SECRET is the documented
 *      SUPABASE_JWT_SECRET fallback, a Supabase session that Supabase has just rejected
 *      (signed out / revoked / user banned) still has a valid signature and is accepted.
 *   2. `jwt.verify` is called without a pinned algorithm list, `exp` is not required,
 *      and the token's own `role` / `tenantId` claims are trusted when no matching
 *      systemUsers record exists.
 *
 * Fix: route by (unverified) issuer, so a Supabase-issued token can only be accepted by
 * Supabase; require exp; pin HS256; and let callers refuse claim-derived roles.
 */
import jwt, { type JwtPayload } from 'jsonwebtoken';

export type TokenOrigin = 'supabase' | 'sovereign';

export class SovereignTokenError extends Error {
  constructor(
    public readonly code: 'TOKEN_EXPIRED' | 'INVALID_TOKEN',
    message: string
  ) {
    super(message);
    this.name = 'SovereignTokenError';
  }
}

/**
 * Classifies a token WITHOUT trusting it. Safe because the classification only chooses
 * which verifier runs; both verifiers check the signature, and a forged `iss` can only
 * route the token to the stricter (Supabase) verifier.
 */
export function classifyTokenOrigin(decoded: JwtPayload | string | null): TokenOrigin {
  if (decoded && typeof decoded === 'object') {
    const iss = typeof decoded.iss === 'string' ? decoded.iss : '';
    if (iss.includes('/auth/v1') || iss === 'supabase') return 'supabase';
  }
  return 'sovereign';
}

/** Local verification is allowed for sovereign tokens only. */
export function mayUseLocalVerification(origin: TokenOrigin): boolean {
  return origin === 'sovereign';
}

export interface SovereignVerifyOptions {
  secret: string;
  /** Enforced when set (e.g. CMMS_JWT_ISSUER). Add `issuer` to jwt.sign() calls to use it. */
  issuer?: string;
  audience?: string;
  /** Upper bound on token age regardless of `exp` (defaults to 8h = securityConfig.jwtLifespanHours). */
  maxAgeSeconds?: number;
}

export function verifySovereignToken(token: string, opts: SovereignVerifyOptions): JwtPayload {
  let payload: JwtPayload | string;
  try {
    payload = jwt.verify(token, opts.secret, {
      algorithms: ['HS256'],
      issuer: opts.issuer,
      audience: opts.audience,
      clockTolerance: 5,
      maxAge: opts.maxAgeSeconds ?? 8 * 60 * 60,
    });
  } catch (err) {
    if (err instanceof jwt.TokenExpiredError) {
      throw new SovereignTokenError('TOKEN_EXPIRED', 'Your session has expired. Please sign in again.');
    }
    throw new SovereignTokenError('INVALID_TOKEN', 'Invalid or expired authentication session.');
  }

  if (typeof payload !== 'object' || payload === null) {
    throw new SovereignTokenError('INVALID_TOKEN', 'Invalid session payload.');
  }
  if (typeof payload.exp !== 'number') {
    // Tokens that never expire are never acceptable.
    throw new SovereignTokenError('INVALID_TOKEN', 'Session token has no expiry.');
  }
  const subject = String(payload.sub ?? payload.userId ?? payload.id ?? '').trim();
  if (!subject) {
    throw new SovereignTokenError('INVALID_TOKEN', 'Session token has no subject.');
  }
  return payload;
}

/**
 * OPT-IN (CMMS_REQUIRE_STORED_ACCOUNT=true): a verified sovereign token must map to a stored
 * account, and role / tenant / branch are never taken from token claims.
 *
 * Off by default on purpose: `systemUsers` is currently held in a per-instance JSON file that
 * lives in /tmp on serverless hosts (server/db.ts:175-177), so on Vercel a user who logged in on
 * one instance may be absent on another. Turn this on once account lookup is backed by Postgres
 * (see AUDIT_REPORT.md, "Architecture").
 */
export function requireStoredAccount(env: NodeJS.ProcessEnv = process.env): boolean {
  return env.CMMS_REQUIRE_STORED_ACCOUNT === 'true';
}
