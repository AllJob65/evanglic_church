-- Authoritative reference copy of supabase/schema.sql
-- Run this script in the Supabase SQL Editor or migration tool to apply all hardened RLS policies.
\i supabase/schema.sql
