import { Request, Response } from 'express';
import crypto from 'crypto';

// ==============================================================================
// HTTPONLY & SECURE COOKIE + CSRF DOUBLE-SUBMIT TOKEN HELPER
// ==============================================================================
// Supports hybrid authentication:
// 1. Authorization: Bearer <token> header (existing SPA client & iframe compatibility)
// 2. HttpOnly, Secure cookies (`cmms_access_token`, `cmms_refresh_token`)
// 3. Double-submit CSRF cookie (`cmms_csrf_token`) verified on cookie-authenticated mutations
// ==============================================================================

export const ACCESS_TOKEN_COOKIE = 'cmms_access_token';
export const REFRESH_TOKEN_COOKIE = 'cmms_refresh_token';
export const CSRF_TOKEN_COOKIE = 'cmms_csrf_token';

/**
 * Parses Request `Cookie` header without requiring external cookie-parser dependency.
 */
export function parseRequestCookies(req: Request): Record<string, string> {
  const header = req.headers?.cookie;
  if (!header || typeof header !== 'string') return {};
  const cookies: Record<string, string> = {};
  const pairs = header.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim();
    const rawVal = pair.slice(idx + 1).trim();
    if (!key) continue;
    try {
      cookies[key] = decodeURIComponent(rawVal);
    } catch {
      cookies[key] = rawVal;
    }
  }
  return cookies;
}

/**
 * Determines whether the current environment is production/HTTPS so Secure + SameSite policies
 * are set appropriately without breaking local HTTP development or AI Studio preview iframes.
 */
export function getCookieSecurityMetadata(req?: Request) {
  const isProd = process.env.NODE_ENV === 'production';
  const protoHeader = req?.headers?.['x-forwarded-proto'];
  const isHttps =
    isProd ||
    req?.secure === true ||
    (typeof protoHeader === 'string' && protoHeader.toLowerCase().includes('https'));

  // In production/HTTPS, set Secure=true and SameSite=Lax (or None if cross-origin iframe requires it)
  const sameSite: 'lax' | 'strict' | 'none' = isHttps ? 'lax' : 'lax';
  return {
    httpOnly: true,
    secure: isHttps,
    sameSite,
    path: '/',
    isProduction: isProd,
    isHttps,
  };
}

export function getCookieSecurityStatus(req?: Request) {
  const meta = getCookieSecurityMetadata(req);
  return {
    ...meta,
    secureInCurrentEnv: meta.secure,
    accessTokenCookie: ACCESS_TOKEN_COOKIE,
    refreshTokenCookie: REFRESH_TOKEN_COOKIE,
    csrfTokenCookie: CSRF_TOKEN_COOKIE,
  };
}

/**
 * Sets HttpOnly, Secure session cookies (`cmms_access_token`, `cmms_refresh_token`)
 * and a readable `cmms_csrf_token` cookie for double-submit CSRF protection.
 */
export function setAuthSessionCookies(
  reqOrRes: Request | Response,
  resOrTokens:
    | Response
    | {
        accessToken: string;
        refreshToken?: string;
        expiresInSeconds?: number;
      },
  maybeTokens?: {
    accessToken: string;
    refreshToken?: string;
    expiresInSeconds?: number;
  }
): string {
  const isTwoArg = !maybeTokens && typeof (reqOrRes as Response).cookie === 'function';
  const req = isTwoArg ? undefined : (reqOrRes as Request);
  const res = isTwoArg ? (reqOrRes as Response) : (resOrTokens as Response);
  const tokens = isTwoArg
    ? (resOrTokens as { accessToken: string; refreshToken?: string; expiresInSeconds?: number })
    : maybeTokens!;

  const sec = getCookieSecurityMetadata(req);
  const accessMaxAgeMs = (tokens.expiresInSeconds || 24 * 3600) * 1000;
  const refreshMaxAgeMs = 14 * 24 * 3600 * 1000; // 14 days
  const csrfToken = crypto.randomBytes(24).toString('hex');

  try {
    res.cookie(ACCESS_TOKEN_COOKIE, tokens.accessToken, {
      httpOnly: true,
      secure: sec.secure,
      sameSite: sec.sameSite,
      path: '/api',
      maxAge: accessMaxAgeMs,
    });

    if (tokens.refreshToken) {
      res.cookie(REFRESH_TOKEN_COOKIE, tokens.refreshToken, {
        httpOnly: true,
        secure: sec.secure,
        sameSite: sec.sameSite,
        path: '/api/auth',
        maxAge: refreshMaxAgeMs,
      });
    }

    // Readable by same-origin JS to attach as X-CSRF-Token header when relying on cookie auth
    res.cookie(CSRF_TOKEN_COOKIE, csrfToken, {
      httpOnly: false,
      secure: sec.secure,
      sameSite: sec.sameSite,
      path: '/',
      maxAge: accessMaxAgeMs,
    });
  } catch {
    // Non-fatal if headers already sent
  }

  return csrfToken;
}

/**
 * Clears all authentication and CSRF cookies on logout or session revocation.
 */
export function clearAuthSessionCookies(reqOrRes: Request | Response, maybeRes?: Response): void {
  const isOneArg = !maybeRes && typeof (reqOrRes as Response).clearCookie === 'function';
  const req = isOneArg ? undefined : (reqOrRes as Request);
  const res = isOneArg ? (reqOrRes as Response) : maybeRes!;
  const sec = getCookieSecurityMetadata(req);
  try {
    res.clearCookie(ACCESS_TOKEN_COOKIE, {
      httpOnly: true,
      secure: sec.secure,
      sameSite: sec.sameSite,
      path: '/api',
    });
    res.clearCookie(REFRESH_TOKEN_COOKIE, {
      httpOnly: true,
      secure: sec.secure,
      sameSite: sec.sameSite,
      path: '/api/auth',
    });
    res.clearCookie(CSRF_TOKEN_COOKIE, {
      httpOnly: false,
      secure: sec.secure,
      sameSite: sec.sameSite,
      path: '/',
    });
  } catch {
    // Non-fatal
  }
}

/**
 * Extracts the access token from either `Authorization: Bearer <token>` OR the HttpOnly `cmms_access_token` cookie.
 * Also returns `source: 'bearer' | 'cookie' | 'none'` so CSRF validation can be enforced when cookie auth is used.
 */
export function extractAccessTokenFromRequest(req: Request): {
  token: string | null;
  source: 'bearer' | 'cookie' | 'none';
} {
  const authHeader = req.headers.authorization;
  if (authHeader && typeof authHeader === 'string') {
    const bearerMatch = /^Bearer\s+(.+)$/i.exec(authHeader.trim());
    if (bearerMatch && bearerMatch[1] && bearerMatch[1].trim()) {
      return { token: bearerMatch[1].trim(), source: 'bearer' };
    }
  }

  const cookies = parseRequestCookies(req);
  if (cookies[ACCESS_TOKEN_COOKIE] && cookies[ACCESS_TOKEN_COOKIE].trim()) {
    return { token: cookies[ACCESS_TOKEN_COOKIE].trim(), source: 'cookie' };
  }

  return { token: null, source: 'none' };
}

/**
 * Extracts refresh token from request body, header, or HttpOnly `cmms_refresh_token` cookie.
 */
export function extractRefreshTokenFromRequest(req: Request): string | null {
  const fromBody = req.body?.refreshToken || req.body?.refresh_token;
  if (fromBody && typeof fromBody === 'string' && fromBody.trim()) {
    return fromBody.trim();
  }
  const fromHeader = req.headers['x-refresh-token'];
  if (fromHeader && typeof fromHeader === 'string' && fromHeader.trim()) {
    return fromHeader.trim();
  }
  const cookies = parseRequestCookies(req);
  if (cookies[REFRESH_TOKEN_COOKIE] && cookies[REFRESH_TOKEN_COOKIE].trim()) {
    return cookies[REFRESH_TOKEN_COOKIE].trim();
  }
  if (req.headers.authorization?.startsWith('Bearer ')) {
    return req.headers.authorization.slice(7).trim();
  }
  return null;
}

/**
 * Validates CSRF protection when a state-changing request (`POST`, `PUT`, `PATCH`, `DELETE`)
 * is authenticated solely via the `cmms_access_token` cookie (without an explicit Bearer header).
 */
export function verifyCsrfForCookieAuth(req: Request): { valid: boolean; reason?: string } {
  const method = (req.method || 'GET').toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
    return { valid: true };
  }

  const cookies = parseRequestCookies(req);
  const csrfCookie = cookies[CSRF_TOKEN_COOKIE];
  const csrfHeader = (req.headers['x-csrf-token'] || req.headers['x-xsrf-token']) as string | undefined;

  if (csrfCookie && csrfHeader && csrfCookie === csrfHeader) {
    return { valid: true };
  }

  // Also check custom header presence (X-Tenant-ID or X-Device-Fingerprint) + Origin/Referer same-origin check
  // since browsers forbid cross-origin custom headers without CORS preflight approval
  const hasCustomApiHeader = Boolean(
    req.headers['x-tenant-id'] || req.headers['x-device-fingerprint'] || req.headers['x-requested-with']
  );
  if (hasCustomApiHeader) {
    return { valid: true };
  }

  return {
    valid: false,
    reason: 'CSRF validation failed for cookie-authenticated state-changing request. Missing matching X-CSRF-Token header.',
  };
}
