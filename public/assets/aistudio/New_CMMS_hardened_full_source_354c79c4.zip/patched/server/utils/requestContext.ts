import { Request } from 'express';
import { db } from '../db';
import { UserRole, AuditLog } from '../../src/types';

/**
 * Extracts the real client IP address.
 * Correctly inspects X-Forwarded-For (first IP in chain if behind proxy/Nginx),
 * X-Real-IP, and falls back to req.socket.remoteAddress or req.ip.
 * Strips IPv6-mapped IPv4 prefix (e.g. ::ffff:192.168.1.1 -> 192.168.1.1).
 */
export function getClientIp(req: Request): string {
  const xForwardedFor = req.headers['x-forwarded-for'];
  if (typeof xForwardedFor === 'string' && xForwardedFor.trim()) {
    // First IP in comma-delimited chain is the original client IP
    const firstIp = xForwardedFor.split(',')[0].trim();
    if (firstIp) {
      return normalizeIp(firstIp);
    }
  }

  const xRealIp = req.headers['x-real-ip'];
  if (typeof xRealIp === 'string' && xRealIp.trim()) {
    return normalizeIp(xRealIp.trim());
  }

  const socketIp = req.socket?.remoteAddress || req.ip || '127.0.0.1';
  return normalizeIp(socketIp);
}

function normalizeIp(ip: string): string {
  if (ip.startsWith('::ffff:')) {
    return ip.replace('::ffff:', '');
  }
  if (ip === '::1') {
    return '127.0.0.1';
  }
  return ip;
}

/**
 * Parses user agent string into a readable device/browser summary
 */
export function parseUserAgent(ua: string): string {
  if (!ua || ua === 'Unknown') return 'Unknown Device';

  let os = 'Unknown OS';
  if (/Windows NT 10.0/i.test(ua)) os = 'Windows 10/11';
  else if (/Windows/i.test(ua)) os = 'Windows';
  else if (/iPhone/i.test(ua)) os = 'iPhone (iOS)';
  else if (/iPad/i.test(ua)) os = 'iPad (iPadOS)';
  else if (/Macintosh|Mac OS X/i.test(ua)) os = 'macOS';
  else if (/Android/i.test(ua)) os = 'Android';
  else if (/Linux/i.test(ua)) os = 'Linux';

  let browser = 'Browser';
  if (/Edg\//i.test(ua)) browser = 'Edge';
  else if (/Chrome\//i.test(ua) && !/Chromium|Edg/i.test(ua)) browser = 'Chrome';
  else if (/Firefox\//i.test(ua)) browser = 'Firefox';
  else if (/Safari\//i.test(ua) && !/Chrome|Chromium|Edg/i.test(ua)) browser = 'Safari';
  else if (/PostmanRuntime/i.test(ua)) browser = 'Postman';
  else if (/curl/i.test(ua)) browser = 'cURL';

  return `${browser} on ${os}`;
}

export interface RequestContext {
  ipAddress: string;
  userAgent: string;
  deviceFingerprint: string;
  sessionId?: string;
  userId?: string;
  userEmail?: string;
  userName?: string;
  userRole?: UserRole;
  device: string;
}

/**
 * Extracts complete request context including real IP, user agent,
 * client device fingerprint header, and authenticated session attributes.
 */
export function getRequestContext(req: Request): RequestContext {
  const ipAddress = getClientIp(req);
  const userAgent = (req.headers['user-agent'] as string) || 'Unknown User Agent';
  
  // Client-generated stable device fingerprint (set via X-Device-Fingerprint or X-Fingerprint header)
  const deviceFingerprint =
    ((req.headers['x-device-fingerprint'] || req.headers['x-fingerprint']) as string) ||
    'untracked';

  const user = (req as any).user;
  const sessionId =
    user?.sessionId ||
    user?.sub ||
    user?.user_id ||
    (req.headers['x-session-id'] as string) ||
    undefined;

  return {
    ipAddress,
    userAgent,
    deviceFingerprint,
    sessionId,
    userId: user?.user_id || user?.id || user?.sub,
    userEmail: user?.email,
    userName: user?.name || user?.full_name,
    userRole: user?.role,
    device: parseUserAgent(userAgent),
  };
}

export interface AuditLogOptions {
  action: string;
  module: string;
  details: string;
  userId?: string;
  userEmail?: string;
  userName?: string;
  userRole?: UserRole | string;
  commitData?: string;
  location?: string;
}

/**
 * Universal security audit logger helper.
 * ALWAYS pulls ipAddress, userAgent, deviceFingerprint and device from the real request.
 * Callers CANNOT override the IP address or device strings.
 */
export function auditLog(req: Request, options: AuditLogOptions): AuditLog {
  const ctx = getRequestContext(req);

  const finalUserEmail = options.userEmail || ctx.userEmail || 'system@gracecathedral.org';
  const finalUserName = options.userName || ctx.userName || 'System / Unauthenticated';
  const finalUserRole = (options.userRole || ctx.userRole || 'REGULAR_MEMBER') as UserRole;
  const finalUserId = options.userId || ctx.userId;

  const logEntry: AuditLog = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString(),
    userEmail: finalUserEmail,
    userName: finalUserName,
    user: finalUserName,
    userRole: finalUserRole,
    action: options.action,
    module: options.module,
    details: options.details,
    ipAddress: ctx.ipAddress, // Strictly from request socket/header chain
    userAgent: ctx.userAgent, // Strictly from request headers
    deviceFingerprint: ctx.deviceFingerprint, // From client header
    sessionId: ctx.sessionId || finalUserId,
    device: ctx.device, // Parsed from real user agent
    location: options.location,
    commitData: options.commitData,
  };

  // Add to authoritative in-memory & file store
  db.addAuditLog(logEntry);

  return logEntry;
}
