import { Pool, PoolClient, QueryResult, QueryResultRow } from 'pg';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const connectionString = process.env.DATABASE_URL;

export function isPgConfigured(): boolean {
  return Boolean(process.env.DATABASE_URL);
}

export const isPostgresReady = isPgConfigured;

// Parse SSL requirements based on connection string or environment
const isProduction = process.env.NODE_ENV === 'production';
const requiresSsl = connectionString && (
  connectionString.includes('sslmode=require') ||
  connectionString.includes('supabase.co') ||
  connectionString.includes('neon.tech') ||
  (isProduction && !connectionString.includes('localhost') && !connectionString.includes('127.0.0.1'))
);

export const pool = new Pool({
  ...(connectionString ? { connectionString } : {}),
  ssl: requiresSsl ? { rejectUnauthorized: true } : false,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  allowExitOnIdle: true,
});

// Avoid unhandled pool errors from killing the process
pool.on('error', (err: Error) => {
  console.warn('[Postgres Pool Warning] Unexpected idle client error:', err.message);
});

/**
 * Execute a query with parameterized values
 */
export async function query<T extends QueryResultRow = any>(
  text: string,
  params?: any[]
): Promise<QueryResult<T>> {
  if (!isPgConfigured()) {
    throw new Error('DATABASE_URL is required before executing PostgreSQL queries.');
  }
  const start = Date.now();
  try {
    const res = await pool.query<T>(text, params);
    const duration = Date.now() - start;
    if (process.env.DEBUG_SQL === 'true') {
      console.log('[Postgres Query]', { text, duration, rows: res.rowCount });
    }
    return res;
  } catch (error: any) {
    console.error('[Postgres Query Error]', { text, error: error.message });
    throw error;
  }
}

export const pgQuery = query;

/**
 * Acquire a dedicated client from the pool (for transactions)
 */
export async function getClient(): Promise<PoolClient> {
  if (!isPgConfigured()) {
    throw new Error('DATABASE_URL is required before acquiring a PostgreSQL client.');
  }
  return pool.connect();
}

/**
 * Run a unit of work in one PostgreSQL transaction. The callback must use
 * the supplied client for every query so all statements share one connection.
 */
export async function withTransaction<T>(
  work: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (rollbackError) {
      console.error('[PostgreSQL] Transaction rollback failed:', rollbackError);
    }
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Check connection health and latency
 */
export async function testConnection(): Promise<{
  ok: boolean;
  message: string;
  latencyMs?: number;
  database?: string;
}> {
  if (!process.env.DATABASE_URL) {
    return {
      ok: false,
      message: 'DATABASE_URL is not configured in environment variables.',
    };
  }

  const start = Date.now();
  try {
    const result = await pool.query('SELECT current_database() as db_name, now() as current_time');
    const latencyMs = Date.now() - start;
    return {
      ok: true,
      message: 'PostgreSQL database connected successfully.',
      latencyMs,
      database: result.rows[0]?.db_name,
    };
  } catch (error: any) {
    return {
      ok: false,
      message: `Failed to connect to PostgreSQL: ${error.message}`,
    };
  }
}

/**
 * Run all pending migrations in server/migrations/ in numerical order
 */
export async function runMigrations(): Promise<{
  success: boolean;
  applied: string[];
  skipped: string[];
  error?: string;
}> {
  const applied: string[] = [];
  const skipped: string[] = [];

  // Validate migration assets before connecting or creating migration metadata.
  const migrationsDir = path.join(process.cwd(), 'server', 'migrations');
  if (!fs.existsSync(migrationsDir)) {
    return {
      success: false,
      applied,
      skipped,
      error: 'Migration directory server/migrations is missing. No database changes were made.',
    };
  }
  const discoveredFiles = fs
    .readdirSync(migrationsDir)
    .filter((file) => file.endsWith('.sql'))
    .sort((a, b) => a.localeCompare(b));
  let files = discoveredFiles;
  if (files.length === 0) {
    return {
      success: false,
      applied,
      skipped,
      error: 'No SQL migration files were found in server/migrations. No database changes were made.',
    };
  }

  const connStatus = await testConnection();
  if (!connStatus.ok) {
    return {
      success: false,
      applied,
      skipped,
      error: `Cannot run migrations: ${connStatus.message}`,
    };
  }

  const client = await getClient();
  try {
    // Serialize migration runners so concurrent deployments cannot apply the
    // same DDL simultaneously.
    await client.query("SELECT pg_advisory_lock(hashtext('cmms_schema_migrations'))");

    // SAFETY: never bootstrap this repository's legacy migration chain over an
    // already-provisioned application database whose migration history is absent.
    // The deployed Supabase schema may have been created independently, and the
    // legacy SQL files are not yet proven to match it. Running them blindly can
    // fail halfway through or alter production structures unexpectedly.
    const trackingTableRes = await client.query<{ exists: boolean }>(
      "SELECT to_regclass('public.schema_migrations') IS NOT NULL AS exists"
    );
    const trackingTableExists = Boolean(trackingTableRes.rows[0]?.exists);
    const migrationHistoryRes = trackingTableExists
      ? await client.query<{ count: string }>(
          'SELECT COUNT(*)::text AS count FROM public.schema_migrations'
        )
      : { rows: [{ count: '0' }] as { count: string }[] };
    const hasRecordedMigrations = Number(migrationHistoryRes.rows[0]?.count || 0) > 0;
    const existingApplicationSchemaRes = await client.query<{ exists: boolean }>(`
      SELECT EXISTS (
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = 'public'
          AND table_name IN ('tenants', 'branches', 'profiles', 'members')
      ) AS exists
    `);
    const hasExistingApplicationSchema = Boolean(existingApplicationSchemaRes.rows[0]?.exists);

    // Existing/provisioned schemas must use an explicit per-environment allowlist.
    // This remains required on every run so a later deployment cannot suddenly
    // execute the unreviewed legacy migration chain after a baseline is recorded.
    const allowlistValue = process.env.CMMS_MIGRATION_ALLOWLIST || '';
    const allowlist = allowlistValue.split(',').map((name) => name.trim()).filter(Boolean);
    if (hasExistingApplicationSchema && allowlist.length === 0) {
      return {
        success: false,
        applied,
        skipped,
        error: hasRecordedMigrations
          ? 'Migration safety stop: an existing CMMS schema requires CMMS_MIGRATION_ALLOWLIST on every run so unreviewed legacy migrations are never picked up. No schema changes were made.'
          : 'Migration safety stop: an existing CMMS schema with no recorded migration history requires CMMS_MIGRATION_ALLOWLIST with exact reviewed SQL filenames. No schema changes were made.',
      };
    }
    if (allowlist.length > 0) {
      const unknownFiles = allowlist.filter((name) => !discoveredFiles.includes(name));
      if (unknownFiles.length > 0) {
        return {
          success: false,
          applied,
          skipped,
          error: `Migration safety stop: allowlist contains unknown migration files: ${unknownFiles.join(', ')}. No schema changes were made.`,
        };
      }
      files = discoveredFiles.filter((name) => allowlist.includes(name));
    }

    // Create migration tracking table if not exists (schema_migrations)
    await client.query(`
      CREATE TABLE IF NOT EXISTS public.schema_migrations (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL UNIQUE,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
    `);
    await client.query('ALTER TABLE public.schema_migrations ADD COLUMN IF NOT EXISTS checksum TEXT;');

    // Get list of already applied migrations
    const existingRes = await client.query<{ name: string }>(
      'SELECT name FROM public.schema_migrations ORDER BY id ASC'
    );
    const existingSet = new Set(existingRes.rows.map((r) => r.name));

    for (const file of files) {
      const filePath = path.join(migrationsDir, file);
      const sql = fs.readFileSync(filePath, 'utf-8');
      const checksum = crypto.createHash('sha256').update(sql).digest('hex');
      if (existingSet.has(file)) {
        const appliedRow = await client.query<{ checksum: string | null }>(
          'SELECT checksum FROM public.schema_migrations WHERE name = $1',
          [file]
        );
        const recordedChecksum = appliedRow.rows[0]?.checksum;
        if (recordedChecksum && recordedChecksum !== checksum) {
          return {
            success: false,
            applied,
            skipped,
            error: `Applied migration ${file} has changed since it was recorded. Create a new migration instead of editing an applied migration.`,
          };
        }
        skipped.push(file);
        continue;
      }

      console.log(`[Migrations] Applying ${file}...`);
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query(
          'INSERT INTO public.schema_migrations (name, checksum) VALUES ($1, $2)',
          [file, checksum]
        );
        await client.query('COMMIT');
        applied.push(file);
        console.log(`[Migrations] Applied ${file} successfully.`);
      } catch (err: any) {
        await client.query('ROLLBACK');
        console.error(`[Migrations] Error applying ${file}:`, err.message);
        return {
          success: false,
          applied,
          skipped,
          error: `Error in migration ${file}: ${err.message}`,
        };
      }
    }

    return { success: true, applied, skipped };
  } finally {
    try {
      await client.query("SELECT pg_advisory_unlock(hashtext('cmms_schema_migrations'))");
    } catch (unlockError) {
      console.error('[Migrations] Failed to release migration advisory lock:', unlockError);
    }
    client.release();
  }
}

/**
 * Graceful shutdown helper
 */
export async function closePool(): Promise<void> {
  await pool.end();
}
