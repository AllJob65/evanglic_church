import { db } from '../db';
import { isPgConfigured, query } from '../pg';
import {
  CommunicationLog,
  CommunicationChannel,
  CommunicationStatus,
  CommunicationLogsSummary,
  Member,
  Family,
  Ministry,
  Branch,
} from '../../src/types';

export interface CreateCommunicationLogParams {
  tenantId?: string;
  branchId?: string;
  channel: CommunicationChannel;
  recipient: string;
  recipientName?: string | null;
  memberId?: string | null;
  familyId?: string | null;
  ministryId?: string | null;
  subject?: string | null;
  message: string;
  status: CommunicationStatus;
  provider: string;
  providerMessageId?: string | null;
  errorMessage?: string | null;
  triggerType?: string | null;
  sentAt?: string | null;
  deliveredAt?: string | null;
  createdBy?: string | null;
  createdByName?: string | null;
}

/**
 * Interpolates template placeholders such as {{firstName}}, {{lastName}}, {{fullName}},
 * {{title}}, {{memberIdNumber}}, {{phone}}, {{email}}, {{churchName}}, {{familyName}}, {{ministryName}}
 */
export function interpolateMessageTemplate(
  template: string,
  context: {
    member?: Partial<Member> | null;
    family?: Partial<Family> | null;
    ministry?: Partial<Ministry> | null;
    branch?: Partial<Branch> | null;
    churchName?: string;
  }
): string {
  if (!template) return '';
  const m = context.member;
  const fullName = m
    ? [m.title, m.firstName, m.middleName, m.lastName].filter(Boolean).join(' ').trim()
    : '';

  const replacements: Record<string, string> = {
    firstName: m?.firstName || 'Member',
    lastName: m?.lastName || '',
    fullName: fullName || 'Member',
    title: m?.title || '',
    memberIdNumber: m?.memberIdNumber || '',
    phone: m?.primaryPhone || '',
    email: m?.email || '',
    familyName: context.family?.householdName || (m?.lastName ? `${m.lastName} Household` : 'Household'),
    ministryName: context.ministry?.name || '',
    branchName: context.branch?.name || '',
    churchName: context.churchName || db.getBranding().churchName || 'Grace Cathedral International',
  };

  return template.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_match, key) => {
    return replacements[key] !== undefined ? replacements[key] : _match;
  });
}

class CommunicationLogService {
  /**
   * Creates and persists a communication log entry in the database (and PostgreSQL if configured)
   */
  public async recordLog(params: CreateCommunicationLogParams): Promise<CommunicationLog> {
    const nowIso = new Date().toISOString();
    const id = `clog-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;

    const logEntry: CommunicationLog = {
      id,
      tenant_id: params.tenantId || 'default',
      branch_id: params.branchId || undefined,
      channel: params.channel,
      recipient: params.recipient,
      recipient_name: params.recipientName || null,
      member_id: params.memberId || null,
      family_id: params.familyId || null,
      ministry_id: params.ministryId || null,
      subject: params.subject || null,
      message: params.message,
      status: params.status,
      provider: params.provider,
      provider_message_id: params.providerMessageId || null,
      error_message: params.errorMessage || null,
      trigger_type: params.triggerType || 'Direct',
      sent_at: params.sentAt || (params.status === 'SENT' || params.status === 'DELIVERED' ? nowIso : null),
      delivered_at: params.deliveredAt || (params.status === 'DELIVERED' ? nowIso : null),
      created_at: nowIso,
      created_by: params.createdBy || null,
      created_by_name: params.createdByName || null,
    };

    if (isPgConfigured()) {
      try {
        const result = await query<CommunicationLog>(
          `INSERT INTO communication_logs (
            id, tenant_id, branch_id, channel, recipient, recipient_name,
            member_id, family_id, ministry_id, subject, message, status,
            provider, provider_message_id, error_message, trigger_type,
            sent_at, delivered_at, created_at, created_by, created_by_name
          ) VALUES (
            $1, $2, $3, $4, $5, $6,
            $7, $8, $9, $10, $11, $12,
            $13, $14, $15, $16,
            $17, $18, $19, $20, $21
          ) RETURNING *`,
          [
            logEntry.id, logEntry.tenant_id, logEntry.branch_id || null,
            logEntry.channel, logEntry.recipient, logEntry.recipient_name,
            logEntry.member_id, logEntry.family_id, logEntry.ministry_id,
            logEntry.subject, logEntry.message, logEntry.status,
            logEntry.provider, logEntry.provider_message_id, logEntry.error_message,
            logEntry.trigger_type, logEntry.sent_at, logEntry.delivered_at,
            logEntry.created_at, logEntry.created_by, logEntry.created_by_name,
          ]
        );
        if (!result.rows[0]) {
          throw new Error('Communication log insert returned no persisted row.');
        }
        return result.rows[0];
      } catch (pgErr) {
        console.error('[CommunicationLogService] PostgreSQL insert failed:', pgErr);
        throw new Error('COMMUNICATION_LOG_PERSISTENCE_FAILED: PostgreSQL insert failed.');
      }
    }

    // Legacy JSON persistence is used only when PostgreSQL is not configured.
    const state = db.getState();
    if (!Array.isArray(state.communicationLogs)) state.communicationLogs = [];
    state.communicationLogs.unshift(logEntry);
    db.persist();

    return logEntry;
  }

  /**
   * Atomically claims a failed log for one retry attempt.
   * QUEUED is used as the in-flight state because the existing schema has no PROCESSING status.
   */
  public async claimRetry(id: string, tenantId: string): Promise<CommunicationLog | null> {
    if (isPgConfigured()) {
      try {
        const result = await query<CommunicationLog>(
          `UPDATE communication_logs
           SET status = 'QUEUED', error_message = NULL
           WHERE id = $1 AND tenant_id = $2 AND status = 'FAILED'
           RETURNING *`,
          [id, tenantId]
        );
        return result.rows[0] || null;
      } catch (pgErr) {
        console.error('[CommunicationLogService] PostgreSQL retry claim failed:', pgErr);
        throw new Error('COMMUNICATION_RETRY_CLAIM_FAILED: PostgreSQL claim failed.');
      }
    }
    const state = db.getState();
    if (!Array.isArray(state.communicationLogs)) return null;
    const index = state.communicationLogs.findIndex(
      (log) => log.id === id && (!log.tenant_id || log.tenant_id === tenantId) && log.status === 'FAILED'
    );
    if (index < 0) return null;
    const updated = { ...state.communicationLogs[index], status: 'QUEUED' as CommunicationStatus, error_message: null };
    state.communicationLogs[index] = updated;
    db.persist();
    return updated;
  }

  /**
   * Records an ambiguous provider outcome without making the log retryable.
   * QUEUED is retained deliberately until provider reconciliation determines delivery.
   */
  public async markRetryOutcomeUnknown(id: string, tenantId: string, reason: string): Promise<void> {
    const message = `RETRY_OUTCOME_UNKNOWN: ${reason.slice(0, 500)}`;
    if (isPgConfigured()) {
      try {
        await query(
          `UPDATE communication_logs
           SET status = 'QUEUED', error_message = $1
           WHERE id = $2 AND tenant_id = $3 AND status = 'QUEUED'`,
          [message, id, tenantId]
        );
        return;
      } catch (pgErr) {
        console.error('[CommunicationLogService] Could not record ambiguous retry outcome:', pgErr);
        throw new Error('COMMUNICATION_RETRY_RECONCILIATION_FAILED');
      }
    }
    const state = db.getState();
    const index = (state.communicationLogs || []).findIndex(
      (log) => log.id === id && (!log.tenant_id || log.tenant_id === tenantId) && log.status === 'QUEUED'
    );
    if (index < 0) return;
    state.communicationLogs[index] = { ...state.communicationLogs[index], status: 'QUEUED', error_message: message };
    db.persist();
  }

  /**
   * Updates an existing communication log entry (e.g. after retry)
   */
  public async updateLog(
    id: string,
    tenantId: string,
    updates: Partial<Pick<CommunicationLog, 'status' | 'provider' | 'provider_message_id' | 'error_message' | 'sent_at' | 'delivered_at'>>
  ): Promise<CommunicationLog | null> {
    if (isPgConfigured()) {
      try {
        const result = await query<CommunicationLog>(
          `UPDATE communication_logs
           SET status = $1, provider = $2, provider_message_id = $3,
               error_message = $4, sent_at = $5, delivered_at = $6
           WHERE id = $7 AND tenant_id = $8
           RETURNING *`,
          [updates.status, updates.provider, updates.provider_message_id,
           updates.error_message, updates.sent_at, updates.delivered_at, id, tenantId]
        );
        return result.rows[0] || null;
      } catch (pgErr) {
        console.error('[CommunicationLogService] PostgreSQL update failed:', pgErr);
        throw new Error('COMMUNICATION_LOG_UPDATE_FAILED: PostgreSQL update failed.');
      }
    }
    const state = db.getState();
    if (!Array.isArray(state.communicationLogs)) state.communicationLogs = [];
    const index = state.communicationLogs.findIndex(
      (log) => log.id === id && (!log.tenant_id || log.tenant_id === tenantId)
    );
    if (index === -1) return null;
    const updated: CommunicationLog = { ...state.communicationLogs[index], ...updates };
    state.communicationLogs[index] = updated;
    db.persist();
    return updated;
  }

  /**
   * Computes real summary statistics strictly from actual communication_logs
   */
  public computeSummary(logs: CommunicationLog[]): CommunicationLogsSummary {
    const total = logs.length;
    if (total === 0) {
      return {
        total: 0,
        smsCount: 0,
        emailCount: 0,
        sentCount: 0,
        deliveredCount: 0,
        failedCount: 0,
        queuedCount: 0,
        deliverySuccessRate: 0,
      };
    }

    let smsCount = 0;
    let emailCount = 0;
    let sentCount = 0;
    let deliveredCount = 0;
    let failedCount = 0;
    let queuedCount = 0;

    for (const log of logs) {
      if (log.channel === 'SMS') smsCount++;
      if (log.channel === 'EMAIL') emailCount++;
      if (log.status === 'SENT') sentCount++;
      else if (log.status === 'DELIVERED') deliveredCount++;
      else if (log.status === 'FAILED') failedCount++;
      else if (log.status === 'QUEUED') queuedCount++;
    }

    const successfulCount = sentCount + deliveredCount;
    const deliverySuccessRate = total > 0 ? Math.round((successfulCount / total) * 100) : 0;

    return {
      total,
      smsCount,
      emailCount,
      sentCount,
      deliveredCount,
      failedCount,
      queuedCount,
      deliverySuccessRate,
    };
  }
}

export const communicationLogService = new CommunicationLogService();
