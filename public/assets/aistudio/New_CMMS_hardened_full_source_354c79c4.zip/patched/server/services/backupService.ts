import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import cron, { ScheduledTask } from 'node-cron';
import { db, DatabaseSchema, BackupLogEntry, BackupScheduleConfig } from '../db';
import { securityAuditService } from './securityAuditService';

const IS_SERVERLESS = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
const BACKUP_DIR = IS_SERVERLESS ? path.join('/tmp', 'backups') : path.join(process.cwd(), 'backups');
const DB_FILE = IS_SERVERLESS ? path.join('/tmp', 'cmms_db.json') : path.join(process.cwd(), 'cmms_db.json');

// Ensure backups directory exists outside public web root
try {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
} catch (err) {
  console.warn('[BackupService] Could not create backup directory on read-only filesystem:', err);
}

let activeCronTask: ScheduledTask | null = null;

/**
 * Format bytes to readable string (e.g. "2.4 MB")
 */
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

/**
 * Validate a candidate backup object against the full DatabaseSchema shape.
 * Ensures every single collection is present and structurally sound.
 */
export function validateDatabaseSchema(raw: any): {
  valid: boolean;
  errors: string[];
  stats: Record<string, number>;
  validatedData?: DatabaseSchema;
} {
  const errors: string[] = [];
  const stats: Record<string, number> = {};

  if (!raw || typeof raw !== 'object') {
    return { valid: false, errors: ['Backup payload is empty or not a valid JSON object'], stats };
  }

  // Handle wrapped payloads { system, version, data: {...} } or direct {...}
  const data: DatabaseSchema = raw.data && typeof raw.data === 'object' ? raw.data : raw;

  // 1. Branding (object)
  if (!data.branding || typeof data.branding !== 'object') {
    errors.push('Missing or invalid "branding" configuration object');
  } else {
    stats.branding = 1;
  }

  // 2. SmsConfig (object)
  if (!data.smsConfig || typeof data.smsConfig !== 'object') {
    errors.push('Missing or invalid "smsConfig" configuration object');
  } else {
    stats.smsConfig = 1;
  }

  // 3. Core Array Collections
  const arrayCollections: (keyof DatabaseSchema)[] = [
    'branches',
    'members',
    'families',
    'ministries',
    'attendanceRecords',
    'attendanceSessions',
    'events',
    'communications',
    'prayerRequests',
    'counselingSessions',
    'visitations',
    'volunteerShifts',
    'assets',
    'documents',
    'documentCategories',
    'courses',
    'workflows',
    'auditLogs',
    'systemUsers',
    'apiKeys',
    'webhooks',
    'devotions',
    'devotionReactions',
    'devotionComments',
    'bibleNotes',
    'bibleHighlights',
    'bibleBookmarks',
    'bibleReadingHistory',
    'bibleReadingPlans',
    'bibleMessages',
    'bibleMessageRecipients',
  ];

  for (const coll of arrayCollections) {
    if (!Array.isArray(data[coll])) {
      errors.push(`Missing or invalid collection "${coll}" (must be an array)`);
    } else {
      stats[coll] = (data[coll] as any[]).length;
    }
  }

  // Optional collections tracking
  if (Array.isArray(data.ministryMembers)) stats.ministryMembers = data.ministryMembers.length;
  if (Array.isArray(data.conversations)) stats.conversations = data.conversations.length;
  if (Array.isArray(data.conversationParticipants)) stats.conversationParticipants = data.conversationParticipants.length;
  if (Array.isArray(data.conversationMessages)) stats.conversationMessages = data.conversationMessages.length;
  if (Array.isArray(data.permissionDeniedLogs)) stats.permissionDeniedLogs = data.permissionDeniedLogs.length;

  if (errors.length > 0) {
    return { valid: false, errors, stats };
  }

  return { valid: true, errors: [], stats, validatedData: data };
}

/**
 * Perform an atomic file write by writing to a temporary file first,
 * then atomically replacing the target destination.
 */
function atomicWriteFile(targetPath: string, content: string): void {
  const tempPath = `${targetPath}.${Date.now()}.${Math.random().toString(36).substring(2, 7)}.tmp`;
  fs.writeFileSync(tempPath, content, 'utf-8');
  fs.renameSync(tempPath, targetPath);
}

/**
 * Create a server-side JSON backup snapshot.
 * Writes a timestamped copy to `backups/` using atomic file writes.
 */
export function createServerBackup(options: {
  type?: 'Full System' | 'Incremental' | 'Differential' | 'Pre-Restore Auto Snapshot' | 'Pre-Reset Auto Snapshot' | 'Scheduled';
  triggeredBy: string;
}): {
  filename: string;
  filePath: string;
  size: string;
  bytes: number;
  checksum: string;
  timestamp: string;
  log: BackupLogEntry;
  payload: any;
} {
  if (IS_SERVERLESS) {
    throw Object.assign(
      new Error('Durable backup storage is not configured. Local /tmp storage is ephemeral and cannot be treated as a recoverable backup.'),
      { code: 'BACKUP_STORAGE_UNAVAILABLE' }
    );
  }

  const type = options.type || 'Full System';
  const timestamp = new Date().toISOString();
  const dateStr = timestamp.replace(/[:.]/g, '-');
  const filename = `cmms_backup_${type.toLowerCase().replace(/[\s-]+/g, '_')}_${dateStr}.json`;
  const targetPath = path.join(BACKUP_DIR, filename);

  // Authoritative current state
  const currentState = db.getState();

  const backupPayload = {
    metadata: {
      system: currentState.branding?.systemName || 'Grace Cathedral CMMS',
      version: '5.0.0-SOVEREIGN-PROD',
      exportedAt: timestamp,
      type,
      storageDestination: 'Local Storage',
      triggeredBy: options.triggeredBy,
    },
    data: currentState,
  };

  const jsonContent = JSON.stringify(backupPayload, null, 2);
  const bytes = Buffer.byteLength(jsonContent, 'utf-8');
  const checksum = crypto.createHash('sha256').update(jsonContent).digest('hex');

  // Atomic write to prevent half-written backups
  atomicWriteFile(targetPath, jsonContent);

  // Log in backup execution history
  const log = db.addBackupLog({
    filename,
    date: new Date().toLocaleString(),
    size: formatBytes(bytes),
    bytes,
    type,
    destination: 'Local Storage',
    status: 'Verified',
    triggeredBy: options.triggeredBy,
    checksum,
  });

  // Audit log
  db.addAuditLog(
    'Create Database Backup',
    'Backup & Disaster Recovery',
    `Created ${type} database backup (${filename}, ${formatBytes(bytes)}, SHA256: ${checksum.substring(0, 12)}...)`,
    options.triggeredBy
  );

  return {
    filename,
    filePath: targetPath,
    size: formatBytes(bytes),
    bytes,
    checksum,
    timestamp,
    log,
    payload: backupPayload,
  };
}

/**
 * Restore database state from a validated backup JSON payload.
 * Enforces mandatory confirmation and creates an automatic pre-restore snapshot.
 */
export function restoreServerBackup(options: {
  content: string | object;
  confirmed: boolean;
  triggeredBy: string;
}): {
  success: boolean;
  requiresConfirmation?: boolean;
  message: string;
  stats?: Record<string, number>;
  preRestoreSnapshot?: string;
  errors?: string[];
} {
  let parsedContent: any = options.content;
  if (typeof options.content === 'string') {
    try {
      parsedContent = JSON.parse(options.content);
    } catch (err: any) {
      return {
        success: false,
        message: `Failed to parse backup file: Invalid JSON syntax (${err.message})`,
        errors: [err.message],
      };
    }
  }

  // 1. Validate full shape
  const validation = validateDatabaseSchema(parsedContent);
  if (!validation.valid || !validation.validatedData) {
    return {
      success: false,
      message: `Backup schema validation failed (${validation.errors.length} errors found). Restore rejected.`,
      errors: validation.errors,
      stats: validation.stats,
    };
  }

  // 2. If confirmation is not yet granted, return validation preview
  if (!options.confirmed) {
    return {
      success: true,
      requiresConfirmation: true,
      message: 'Backup payload successfully verified against full DatabaseSchema. Confirming will overwrite active database. An automatic pre-restore snapshot will be created before applying.',
      stats: validation.stats,
    };
  }

  // 3. Mandatory Safety Net: Automatic Pre-Restore Snapshot
  const preRestore = createServerBackup({
    type: 'Pre-Restore Auto Snapshot',
    triggeredBy: `System Pre-Restore Guard (${options.triggeredBy})`,
  });

  try {
    const validatedData = validation.validatedData;
    // Keep the backupConfig and backupLogs from current system if missing in restore
    if (!validatedData.backupConfig) {
      validatedData.backupConfig = db.getBackupConfig();
    }
    if (!validatedData.backupLogs || validatedData.backupLogs.length === 0) {
      validatedData.backupLogs = db.getBackupLogs();
    }

    // Write atomically to cmms_db.json
    const existingLogs = db.getState().auditLogs || [];
    const incomingLogs = Array.isArray(validatedData.auditLogs) ? validatedData.auditLogs : [];
    const mergedLogMap = new Map<string, any>();
    for (const l of [...incomingLogs, ...existingLogs]) {
      if (l && l.id) mergedLogMap.set(l.id, l);
    }
    validatedData.auditLogs = Array.from(mergedLogMap.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    const serialized = JSON.stringify(validatedData, null, 2);
    atomicWriteFile(DB_FILE, serialized);

    // Reload in-memory store so it is immediately authoritative
    db.reloadFromDisk();
    securityAuditService.hydrateFromDurableStore();

    // Log the restore in history
    db.addBackupLog({
      filename: `Restored: ${preRestore.filename}`,
      date: new Date().toLocaleString(),
      size: formatBytes(Buffer.byteLength(serialized, 'utf-8')),
      bytes: Buffer.byteLength(serialized, 'utf-8'),
      type: 'Full System',
      destination: 'Local Storage',
      status: 'Completed',
      triggeredBy: options.triggeredBy,
    });

    db.addAuditLog(
      'System Database Restored',
      'Backup & Disaster Recovery',
      `Restored system database from external backup file. Pre-restore safeguard snapshot created: ${preRestore.filename}`,
      options.triggeredBy
    );

    return {
      success: true,
      message: 'System database restored successfully and verified.',
      stats: validation.stats,
      preRestoreSnapshot: preRestore.filename,
    };
  } catch (err: any) {
    // Attempt to roll back from the pre-restore snapshot
    try {
      if (fs.existsSync(preRestore.filePath)) {
        fs.copyFileSync(preRestore.filePath, DB_FILE);
        db.reloadFromDisk();
      }
    } catch (rbErr) {
      console.error('[BackupService] Rollback error:', rbErr);
    }

    return {
      success: false,
      message: `Restore failed: ${err.message}. Automatically rolled back to pre-restore state.`,
      errors: [err.message],
    };
  }
}

/**
 * Reset server database back to factory seed defaults.
 * Requires explicit confirm=true and creates an automatic pre-reset snapshot.
 */
export function resetServerDatabase(options: {
  confirmed: boolean;
  triggeredBy: string;
}): {
  success: boolean;
  requiresConfirmation?: boolean;
  message: string;
  preResetSnapshot?: string;
} {
  if (!options.confirmed) {
    return {
      success: true,
      requiresConfirmation: true,
      message: 'Confirming will reset all members, attendance, financials, and configurations to factory baseline defaults. An automatic pre-reset snapshot will be taken.',
    };
  }

  // Mandatory Safety Net: Automatic Pre-Reset Snapshot
  const preReset = createServerBackup({
    type: 'Pre-Reset Auto Snapshot',
    triggeredBy: `System Pre-Reset Guard (${options.triggeredBy})`,
  });

  // Execute database reset to default datasets
  db.resetToDefaults();

  db.addAuditLog(
    'Factory Database Reset',
    'Backup & Disaster Recovery',
    `Database was reset to factory default data. Pre-reset safeguard snapshot created: ${preReset.filename}`,
    options.triggeredBy
  );

  return {
    success: true,
    message: 'System data reset to factory defaults successfully.',
    preResetSnapshot: preReset.filename,
  };
}

/**
 * Resolve safe path for a backup file inside BACKUP_DIR
 */
export function getSafeBackupFilePath(filename: string): string | null {
  const sanitized = path.basename(filename);
  const resolved = path.join(BACKUP_DIR, sanitized);
  if (!resolved.startsWith(BACKUP_DIR)) return null;
  if (!fs.existsSync(resolved)) return null;
  return resolved;
}

/**
 * Initialize or reschedule automated cron backups based on persistent config
 */
export function initBackupScheduler(): void {
  if (activeCronTask) {
    activeCronTask.stop();
    activeCronTask = null;
  }

  const config = db.getBackupConfig();
  if (!config.enabled) {
    console.log('[BackupScheduler] Scheduled backups are currently disabled.');
    return;
  }

  // Parse execution time "HH:MM"
  const [hourStr, minStr] = (config.time || '02:00').split(':');
  const hour = parseInt(hourStr || '2', 10);
  const min = parseInt(minStr || '0', 10);

  // Generate cron expression
  let cronExp = `${min} ${hour} * * *`; // Daily
  if (config.frequency === 'Weekly') {
    cronExp = `${min} ${hour} * * 0`; // Sunday
  } else if (config.frequency === 'Monthly') {
    cronExp = `${min} ${hour} 1 * *`; // 1st of month
  }

  console.log(`[BackupScheduler] Initializing automated backup job: ${cronExp} (${config.frequency} at ${config.time})`);

  activeCronTask = cron.schedule(cronExp, () => {
    console.log('[BackupScheduler] Running scheduled database backup...');
    try {
      const result = createServerBackup({
        type: 'Scheduled',
        triggeredBy: 'Automated System Scheduler',
      });
      db.updateBackupConfig({ lastRunAt: new Date().toISOString() });
      console.log(`[BackupScheduler] Scheduled backup completed: ${result.filename} (${result.size})`);
    } catch (err: any) {
      console.error('[BackupScheduler] Scheduled backup failed:', err.message);
    }
  });
}
