import nodemailer from 'nodemailer';

export interface EmailDispatchInput {
  recipient: string;
  subject: string;
  message: string;
  html?: string;
  replyTo?: string;
  fromName?: string;
}

export interface EmailDispatchResult {
  success: boolean;
  status: 'QUEUED' | 'SENT' | 'DELIVERED' | 'FAILED';
  recipient: string;
  provider: string;
  providerMessageId: string | null;
  errorMessage: string | null;
  sentAt: string | null;
  deliveredAt: string | null;
}

export interface EmailProviderStatus {
  provider: string;
  fromAddress: string;
  configured: boolean;
  smtpConfigured: boolean;
  apiConfigured: boolean;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/**
 * Backend-Only Email Service
 * Supports SMTP (via Nodemailer), Resend API, and SendGrid API.
 * Validates email addresses, subjects, and plain-text/HTML bodies.
 * Provider credentials remain strictly on the backend.
 */
class EmailService {
  private getProviderName(): string {
    if (process.env.EMAIL_PROVIDER) return process.env.EMAIL_PROVIDER.trim();
    if (process.env.RESEND_API_KEY) return 'Resend';
    if (process.env.SENDGRID_API_KEY) return 'SendGrid';
    if (process.env.SMTP_HOST) return 'SMTP';
    return 'SMTP';
  }

  private getFromAddress(): string {
    return (
      process.env.EMAIL_FROM ||
      process.env.SMTP_FROM ||
      'Grace Cathedral CMMS <noreply@gracecathedral.org>'
    ).trim();
  }

  private getReplyTo(): string | undefined {
    const replyTo = (process.env.EMAIL_REPLY_TO || '').trim();
    return replyTo || undefined;
  }

  public getStatus(): EmailProviderStatus {
    const provider = this.getProviderName();
    const fromAddress = this.getFromAddress();
    const smtpConfigured = Boolean(
      process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS
    );
    const apiConfigured = Boolean(
      process.env.EMAIL_API_KEY || process.env.RESEND_API_KEY || process.env.SENDGRID_API_KEY
    );

    return {
      provider,
      fromAddress,
      configured: smtpConfigured || apiConfigured,
      smtpConfigured,
      apiConfigured,
    };
  }

  public validateEmail(rawEmail: string): {
    valid: boolean;
    normalized: string;
    error?: string;
  } {
    if (!rawEmail || typeof rawEmail !== 'string' || !rawEmail.trim()) {
      return {
        valid: false,
        normalized: '',
        error: 'Recipient email address is required.',
      };
    }

    const normalized = rawEmail.trim().toLowerCase();
    if (!EMAIL_REGEX.test(normalized)) {
      return {
        valid: false,
        normalized,
        error: `Invalid email address format: "${rawEmail.trim()}"`,
      };
    }

    return {
      valid: true,
      normalized,
    };
  }

  private buildHtmlFromText(subject: string, text: string): string {
    const escapedSubject = subject
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    const escapedBody = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br/>');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>${escapedSubject}</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #0f172a; line-height: 1.6; margin: 0; padding: 24px; background-color: #f8fafc;">
  <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden;">
    <div style="background: #1e3a8a; color: #ffffff; padding: 20px 24px;">
      <h2 style="margin: 0; font-size: 18px; font-weight: 700;">New Church</h2>
      <p style="margin: 4px 0 0; font-size: 12px; color: #bfdbfe;">Official Church Communication</p>
    </div>
    <div style="padding: 24px;">
      <h3 style="margin: 0 0 16px; font-size: 16px; color: #0f172a;">${escapedSubject}</h3>
      <div style="font-size: 14px; color: #334155;">${escapedBody}</div>
    </div>
    <div style="background: #f1f5f9; padding: 14px 24px; font-size: 11px; color: #64748b; text-align: center;">
      Sent via New Church Management System (CMMS)
    </div>
  </div>
</body>
</html>`;
  }

  public async sendEmail(input: EmailDispatchInput): Promise<EmailDispatchResult> {
    const provider = this.getProviderName();
    const rawRecipient = (input.recipient || '').trim();
    const subject = (input.subject || '').trim();
    const message = (input.message || '').trim();

    // 1. Validate recipient email
    const emailCheck = this.validateEmail(rawRecipient);
    if (!emailCheck.valid) {
      return {
        success: false,
        status: 'FAILED',
        recipient: rawRecipient,
        provider,
        providerMessageId: null,
        errorMessage: emailCheck.error || 'Invalid email address.',
        sentAt: null,
        deliveredAt: null,
      };
    }

    // 2. Validate subject & message
    if (!subject) {
      return {
        success: false,
        status: 'FAILED',
        recipient: emailCheck.normalized,
        provider,
        providerMessageId: null,
        errorMessage: 'Email subject is required.',
        sentAt: null,
        deliveredAt: null,
      };
    }

    if (!message && !input.html) {
      return {
        success: false,
        status: 'FAILED',
        recipient: emailCheck.normalized,
        provider,
        providerMessageId: null,
        errorMessage: 'Email message body cannot be empty.',
        sentAt: null,
        deliveredAt: null,
      };
    }

    const normalizedEmail = emailCheck.normalized;
    const fromAddress = this.getFromAddress();
    const replyTo = input.replyTo || this.getReplyTo();
    const htmlContent = input.html || this.buildHtmlFromText(subject, message);
    const nowIso = new Date().toISOString();

    try {
      // 3A. Resend HTTP API
      const resendKey = (
        process.env.RESEND_API_KEY ||
        (provider.toLowerCase() === 'resend' ? process.env.EMAIL_API_KEY : '') ||
        ''
      ).trim();

      if (resendKey) {
        const response = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${resendKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from: fromAddress,
            to: [normalizedEmail],
            subject,
            text: message,
            html: htmlContent,
            ...(replyTo ? { reply_to: replyTo } : {}),
          }),
        });

        const data: any = await response.json().catch(() => ({}));
        if (!response.ok) {
          return {
            success: false,
            status: 'FAILED',
            recipient: normalizedEmail,
            provider: 'Resend',
            providerMessageId: null,
            errorMessage: data?.message || data?.error || `Resend API HTTP ${response.status}`,
            sentAt: null,
            deliveredAt: null,
          };
        }

        return {
          success: true,
          status: 'SENT',
          recipient: normalizedEmail,
          provider: 'Resend',
          providerMessageId: data?.id || `resend-${Date.now()}`,
          errorMessage: null,
          sentAt: nowIso,
          deliveredAt: null,
        };
      }

      // 3B. SendGrid HTTP API
      const sendgridKey = (
        process.env.SENDGRID_API_KEY ||
        (provider.toLowerCase() === 'sendgrid' ? process.env.EMAIL_API_KEY : '') ||
        ''
      ).trim();

      if (sendgridKey) {
        const fromMatch = fromAddress.match(/^(?:([^<]+)\s*<([^>]+)>|([^\s]+))$/);
        const fromEmail = fromMatch ? (fromMatch[2] || fromMatch[3] || fromAddress).trim() : fromAddress;
        const fromName = fromMatch && fromMatch[1] ? fromMatch[1].trim().replace(/^"|"$/g, '') : 'New Church CMMS';

        const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${sendgridKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            personalizations: [{ to: [{ email: normalizedEmail }] }],
            from: { email: fromEmail, name: fromName },
            subject,
            content: [
              { type: 'text/plain', value: message },
              { type: 'text/html', value: htmlContent },
            ],
          }),
        });

        if (!response.ok) {
          const errData: any = await response.json().catch(() => ({}));
          return {
            success: false,
            status: 'FAILED',
            recipient: normalizedEmail,
            provider: 'SendGrid',
            providerMessageId: null,
            errorMessage:
              errData?.errors?.[0]?.message || `SendGrid API HTTP ${response.status}`,
            sentAt: null,
            deliveredAt: null,
          };
        }

        const sgMsgId = response.headers.get('x-message-id') || `sg-${Date.now()}`;
        return {
          success: true,
          status: 'SENT',
          recipient: normalizedEmail,
          provider: 'SendGrid',
          providerMessageId: sgMsgId,
          errorMessage: null,
          sentAt: nowIso,
          deliveredAt: null,
        };
      }

      // 3C. Live SMTP via Nodemailer when SMTP_HOST is configured
      const smtpHost = (process.env.SMTP_HOST || '').trim();
      const smtpPort = Number(process.env.SMTP_PORT || 587);
      const smtpUser = (process.env.SMTP_USER || '').trim();
      const smtpPass = (process.env.SMTP_PASS || '').trim();
      const smtpSecure =
        process.env.SMTP_SECURE === 'true' || smtpPort === 465;

      if (smtpHost && smtpUser && smtpPass) {
        const transporter = nodemailer.createTransport({
          host: smtpHost,
          port: smtpPort,
          secure: smtpSecure,
          auth: {
            user: smtpUser,
            pass: smtpPass,
          },
        });

        const info = await transporter.sendMail({
          from: fromAddress,
          to: normalizedEmail,
          subject,
          text: message,
          html: htmlContent,
          ...(replyTo ? { replyTo } : {}),
        });

        return {
          success: true,
          status: 'SENT',
          recipient: normalizedEmail,
          provider: 'SMTP',
          providerMessageId: info.messageId || `smtp-${Date.now()}`,
          errorMessage: null,
          sentAt: nowIso,
          deliveredAt: null,
        };
      }

      // Never report a locally constructed message as sent. If no real
      // provider is configured, fail explicitly so callers can surface the
      // delivery failure and operators can configure SMTP/API credentials.
      return {
        success: false,
        status: 'FAILED',
        recipient: normalizedEmail,
        provider,
        providerMessageId: null,
        errorMessage:
          'Email delivery is unavailable because no SMTP or email API provider is configured on the server.',
        sentAt: null,
        deliveredAt: null,
      };
    } catch (err: any) {
      return {
        success: false,
        status: 'FAILED',
        recipient: normalizedEmail,
        provider,
        providerMessageId: null,
        errorMessage: err?.message || 'Unexpected error communicating with email provider.',
        sentAt: null,
        deliveredAt: null,
      };
    }
  }
}

export const emailService = new EmailService();
