import { db } from '../db';
import { supabase, isSupabaseConfigured } from '../../src/utils/supabase';
import {
  Conversation,
  ConversationParticipant,
  ConversationMessage,
  ConversationType,
  UserRole,
} from '../../src/types';
import { normalizeUserRole } from '../../src/utils/rbac';
import { resolveMemberId } from './membershipService';

export const STAFF_ROLES: UserRole[] = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'];

export function isStaffRole(role: string): boolean {
  const norm = normalizeUserRole(role);
  return STAFF_ROLES.includes(norm);
}

/**
 * Direct conversation role gating:
 * - Allowed: one participant is SYSTEM_ADMIN, MANAGER, PASTOR or MINISTRY_LEADER, and the other is REGULAR_MEMBER.
 * - Allowed: two staff-tier participants (e.g. PASTOR <-> MANAGER) messaging each other.
 * - NEVER allowed: two REGULAR_MEMBER participants in a direct conversation with each other.
 */
export function isDirectChatAllowed(roleA: string, roleB: string): boolean {
  const normA = normalizeUserRole(roleA);
  const normB = normalizeUserRole(roleB);

  // If both resolve to REGULAR_MEMBER, it is NEVER allowed
  if (normA === 'REGULAR_MEMBER' && normB === 'REGULAR_MEMBER') {
    return false;
  }

  // Allowed if at least one is staff-tier (staff-to-member or staff-to-staff)
  return isStaffRole(normA) || isStaffRole(normB);
}

/**
 * Resolves all member IDs that belong to any ministry led by the given leader.
 * 
 * 1. Resolves the leader's memberId from systemUsers or members.
 * 2. Finds all ministries where `leaderMemberId` matches this leader's resolved memberId or user id
 *    (or in leaderMemberIds array if present).
 * 3. Returns the union of all `memberIds` across all ministries led by this leader.
 *
 * NOTE on subMinistries: Sub-ministries are currently an embedded array of lightweight objects
 * with only { id, name, leaderName, memberCount } without leaderMemberId or memberIds arrays.
 * Sub-ministry members are therefore encompassed by the parent Ministry's memberIds.
 */
export function getLedMinistryMemberIds(leaderUserId: string): string[] {
  if (!leaderUserId) return [];

  const state = db.getState();
  const leaderMemberId = resolveMemberId(leaderUserId, undefined, state);
  const ministries = state.ministries || [];

  const ledMemberIds = new Set<string>();

  for (const min of ministries) {
    const matchesLeader =
      (leaderMemberId && min.leaderMemberId === leaderMemberId) ||
      min.leaderMemberId === leaderUserId ||
      (Array.isArray((min as any).leaderMemberIds) && (
        (leaderMemberId && (min as any).leaderMemberIds.includes(leaderMemberId)) ||
        (min as any).leaderMemberIds.includes(leaderUserId)
      ));

    if (matchesLeader && Array.isArray(min.memberIds)) {
      for (const mId of min.memberIds) {
        if (mId) {
          ledMemberIds.add(mId);
        }
      }
    }
  }

  return Array.from(ledMemberIds);
}

/**
 * Checks whether a target member or user ID belongs to any ministry led by this leader.
 */
export function isMemberInLedMinistries(leaderUserId: string, targetUserId: string): boolean {
  if (!leaderUserId || !targetUserId) return false;

  const ledMemberIds = getLedMinistryMemberIds(leaderUserId);
  if (ledMemberIds.length === 0) return false;

  const state = db.getState();
  const targetMemberId = resolveMemberId(targetUserId, undefined, state);

  return (
    ledMemberIds.includes(targetUserId) ||
    (Boolean(targetMemberId) && ledMemberIds.includes(targetMemberId!))
  );
}

export interface DirectTierScopeValidationResult {
  allowed: boolean;
  code?: 'MEMBER_TO_MEMBER_BLOCKED' | 'OUTSIDE_LED_MINISTRY';
  error?: string;
  leaderId?: string;
  targetMemberId?: string;
  details?: string;
}

/**
 * Authoritatively validates the Phase 21 & Phase 21b tier and ministry-scope rules:
 *
 * 1. REGULAR_MEMBER <-> REGULAR_MEMBER:
 *    Always blocked with 403 MEMBER_TO_MEMBER_BLOCKED.
 * 2. Staff <-> Staff (SYSTEM_ADMIN, MANAGER, PASTOR, MINISTRY_LEADER):
 *    Always allowed.
 * 3. Executive Staff <-> REGULAR_MEMBER (SYSTEM_ADMIN, MANAGER, PASTOR):
 *    Allowed church-wide.
 * 4. MINISTRY_LEADER <-> REGULAR_MEMBER:
 *    Allowed ONLY IF the REGULAR_MEMBER is in getLedMinistryMemberIds(leader).
 *    Otherwise rejected with 403 OUTSIDE_LED_MINISTRY.
 */
export function validateDirectConversationTierAndScope(
  userAId: string,
  roleA: string,
  userBId: string,
  roleB: string
): DirectTierScopeValidationResult {
  const normA = normalizeUserRole(roleA);
  const normB = normalizeUserRole(roleB);

  // 1. Both regular members -> always blocked
  if (normA === 'REGULAR_MEMBER' && normB === 'REGULAR_MEMBER') {
    return {
      allowed: false,
      code: 'MEMBER_TO_MEMBER_BLOCKED',
      error: 'Direct conversations between regular members are restricted. One participant must be a staff member or ministry leader.',
      details: `Blocked direct communication between regular members ${userAId} and ${userBId}`,
    };
  }

  // 2. Both staff roles -> open communication (staff-to-staff stays open per Phase 21)
  if (isStaffRole(normA) && isStaffRole(normB)) {
    return { allowed: true };
  }

  // 3. MINISTRY_LEADER <-> REGULAR_MEMBER
  if (normA === 'MINISTRY_LEADER' && normB === 'REGULAR_MEMBER') {
    const isWithinLed = isMemberInLedMinistries(userAId, userBId);
    if (!isWithinLed) {
      return {
        allowed: false,
        code: 'OUTSIDE_LED_MINISTRY',
        error: 'Ministry leaders may only direct-message or call members of ministries they lead.',
        leaderId: userAId,
        targetMemberId: userBId,
        details: `Ministry leader ${userAId} attempted direct communication with member ${userBId} who is outside their led ministries.`,
      };
    }
    return { allowed: true };
  }

  if (normB === 'MINISTRY_LEADER' && normA === 'REGULAR_MEMBER') {
    const isWithinLed = isMemberInLedMinistries(userBId, userAId);
    if (!isWithinLed) {
      return {
        allowed: false,
        code: 'OUTSIDE_LED_MINISTRY',
        error: 'Ministry leaders may only direct-message or call members of ministries they lead.',
        leaderId: userBId,
        targetMemberId: userAId,
        details: `Regular member ${userAId} attempted direct communication with ministry leader ${userBId} without belonging to their led ministries.`,
      };
    }
    return { allowed: true };
  }

  // 4. Executive Staff (SYSTEM_ADMIN, MANAGER, PASTOR) <-> REGULAR_MEMBER
  if (
    (isStaffRole(normA) && normB === 'REGULAR_MEMBER') ||
    (isStaffRole(normB) && normA === 'REGULAR_MEMBER')
  ) {
    return { allowed: true };
  }

  return { allowed: true };
}

/**
 * Authoritatively resolves a user's role server-side from database, test tokens, or profiles.
 */
export async function resolveUserRole(userId: string): Promise<UserRole> {
  if (!userId) return 'REGULAR_MEMBER';

  const state = db.getState();

  // 1. Check systemUsers in database by ID or Email
  const sysUser = (state.systemUsers || []).find(
    (u) => u.id === userId || (u.email && u.email.toLowerCase() === userId.toLowerCase())
  );
  if (sysUser?.role) {
    return normalizeUserRole(sysUser.role);
  }

  // 2. Deterministic test tokens / ID resolution in non-production environments
  const lower = userId.toLowerCase();
  if (lower.startsWith('usr-') || lower.includes('test-user') || lower.startsWith('test-token-')) {
    if (lower.includes('system_admin') || lower.includes('admin')) return 'SYSTEM_ADMIN';
    if (lower.includes('manager')) return 'MANAGER';
    if (lower.includes('pastor')) return 'PASTOR';
    if (lower.includes('ministry_leader') || lower.includes('leader')) return 'MINISTRY_LEADER';
    if (lower.includes('regular_member') || lower.includes('member')) return 'REGULAR_MEMBER';
  }

  // 3. Supabase profiles table if configured
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', userId)
        .maybeSingle();

      if (!error && data?.role) {
        return normalizeUserRole(data.role);
      }
    } catch (err) {
      console.warn('[conversationService] Supabase profile role lookup failed:', err);
    }
  }

  // 4. Church members directory (regular members without elevated system accounts)
  const member = (state.members || []).find((m) => m.id === userId);
  if (member) {
    return 'REGULAR_MEMBER';
  }

  return 'REGULAR_MEMBER';
}

/**
 * Checks whether a given role is allowed to initiate the requested conversation type.
 * - 'direct': Authenticated tenant members (subject to staff<->member or staff<->staff role check).
 * - 'ad_hoc_group' & 'video': Only MINISTRY_LEADER, PASTOR, MANAGER, SYSTEM_ADMIN.
 */
export function canCreateConversationType(role: string, type: ConversationType): boolean {
  const normRole = (role || '').toUpperCase() as UserRole;
  if (type === 'direct') {
    return true; // Any authenticated tenant member
  }
  if (type === 'ad_hoc_group' || type === 'video') {
    return ['MINISTRY_LEADER', 'PASTOR', 'MANAGER', 'SYSTEM_ADMIN'].includes(normRole);
  }
  return false;
}

/**
 * Validates participant counts:
 * - 'direct': exactly 2 total (creator + 1 other)
 * - 'ad_hoc_group' & 'video': between 2 and 50 total
 */
export function validateParticipantLimits(
  type: ConversationType,
  totalParticipantsCount: number
): { valid: boolean; error?: string } {
  if (type === 'direct') {
    if (totalParticipantsCount !== 2) {
      return {
        valid: false,
        error: 'A direct conversation must have exactly two participants (you and one other member).',
      };
    }
    return { valid: true };
  }

  // ad_hoc_group and video
  if (totalParticipantsCount < 2) {
    return {
      valid: false,
      error: 'A conversation requires at least 2 participants.',
    };
  }
  if (totalParticipantsCount > 50) {
    return {
      valid: false,
      error: 'Conversations are capped at a maximum of 50 participants.',
    };
  }

  return { valid: true };
}

/**
 * Checks if a user belongs to the specified tenant.
 */
export async function verifyUserInTenant(userId: string, tenantId: string): Promise<boolean> {
  if (!userId || !tenantId) return false;

  const state = db.getState();

  // 1. Check systemUsers
  const sysUser = state.systemUsers?.find((u) => u.id === userId);
  if (sysUser) {
    const userTenant = (sysUser as any).tenantId || (sysUser as any).tenant_id || 'tenant-grace-main';
    return userTenant === tenantId;
  }

  // 2. Check members
  const member = state.members?.find((m) => m.id === userId);
  if (member) {
    const memberTenant = (member as any).tenantId || (member as any).tenant_id || 'tenant-grace-main';
    return memberTenant === tenantId;
  }

  // 3. Fallback to Supabase if configured
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('tenant_id')
        .eq('id', userId)
        .maybeSingle();

      if (!error && data) {
        return (data as any).tenant_id === tenantId;
      }
    } catch (err) {
      console.warn('[conversationService] Supabase profile check failed:', err);
    }
  }

  // If user matches our standard dev/test users or format, allow within default tenant
  if (tenantId === 'tenant-grace-main') {
    return true;
  }

  return false;
}

/**
 * Authoritatively verifies that the caller is currently an ACTIVE participant (left_at is null)
 * in the requested conversation, and that the conversation belongs to the caller's tenant.
 *
 * ZERO TRUST: Never trusts client-supplied headers or body fields alone.
 */
export async function isActiveParticipant(
  conversationId: string,
  userId: string,
  tenantId: string
): Promise<boolean> {
  if (!conversationId || !userId || !tenantId) return false;

  const state = db.getState();

  // 1. Verify conversation exists and belongs to the caller's tenant
  const conv = state.conversations?.find((c) => c.id === conversationId);
  if (!conv || conv.tenantId !== tenantId) {
    return false;
  }

  // 2. Check participant record in local database
  const participants = state.conversationParticipants || [];
  const participant = participants.find(
    (p) => p.conversationId === conversationId && p.userId === userId
  );

  if (participant && !participant.leftAt) {
    return true;
  }

  // 3. Check Supabase if configured
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase
        .from('conversation_participants')
        .select('left_at')
        .eq('conversation_id', conversationId)
        .eq('user_id', userId)
        .is('left_at', null)
        .maybeSingle();

      if (!error && data) {
        return true;
      }
    } catch (err) {
      console.warn('[conversationService] Supabase participant check failed:', err);
    }
  }

  return false;
}

/**
 * Retrieves active participants for a conversation, optionally enriched with user display names/roles.
 */
export function getActiveParticipants(conversationId: string): ConversationParticipant[] {
  const state = db.getState();
  const allParticipants = state.conversationParticipants || [];
  const active = allParticipants.filter((p) => p.conversationId === conversationId && !p.leftAt);

  // Enrich with user name & role if available
  return active.map((p) => {
    const sysUser = state.systemUsers?.find((u) => u.id === p.userId);
    const member = state.members?.find((m) => m.id === p.userId);

    return {
      ...p,
      userName: sysUser?.name || (member ? `${member.firstName} ${member.lastName}` : p.userName || p.userId),
      userEmail: sysUser?.email || member?.email || p.userEmail,
      userRole: sysUser?.role || (member ? 'REGULAR_MEMBER' : p.userRole || 'REGULAR_MEMBER'),
    };
  });
}
