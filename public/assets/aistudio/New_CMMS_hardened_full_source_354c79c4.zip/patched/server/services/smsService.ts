import { validateEthiopianPhone, normalizeEthiopianPhone } from '../../src/utils/phoneValidation';

export interface SmsDispatchInput {
  recipient: string;
  message: string;
  senderId?: string;
}

export interface SmsDispatchResult {
  success: boolean;
  status: 'QUEUED' | 'SENT' | 'DELIVERED' | 'FAILED';
  recipient: string;
  normalizedRecipient: string;
  provider: string;
  providerMessageId: string | null;
  errorMessage: string | null;
  sentAt: string | null;
  deliveredAt: string | null;
}

export interface SmsProviderStatus {
  provider: string;
  senderId: string;
  configured: boolean;
  endpointConfigured: boolean;
}

/**
 * Backend-Only SMS Service
 * Validates & normalizes Ethiopian phone numbers and dispatches SMS via the configured provider.
 * Credentials are read strictly from server process.env and are NEVER exposed to the frontend.
 */
class SmsService {
  private getProviderName(): string {
    return (
      process.env.SMS_PROVIDER ||
      (process.env.AFROMESSAGE_API_KEY ? 'AfroMessage' : '') ||
      (process.env.TWILIO_ACCOUNT_SID ? 'Twilio' : '') ||
      'EthioTelecom'
    ).trim();
  }

  private getSenderId(overrideSenderId?: string): string {
    return (
      overrideSenderId ||
      process.env.SMS_SENDER_ID ||
      process.env.ETHIO_TELECOM_SENDER_ID ||
      'GRACECATH'
    ).trim();
  }

  private getApiUrl(): string {
    return (
      process.env.SMS_API_URL ||
      process.env.ETHIO_TELECOM_SMS_URL ||
      ''
    ).trim();
  }

  private getApiKey(): string {
    return (
      process.env.SMS_API_KEY ||
      process.env.ETHIO_TELECOM_APP_ID ||
      process.env.AFROMESSAGE_API_KEY ||
      process.env.TWILIO_ACCOUNT_SID ||
      ''
    ).trim();
  }

  private getApiSecret(): string {
    return (
      process.env.SMS_API_SECRET ||
      process.env.ETHIO_TELECOM_APP_SECRET ||
      process.env.TWILIO_AUTH_TOKEN ||
      ''
    ).trim();
  }

  /**
   * Returns non-sensitive provider configuration status
   */
  public getStatus(): SmsProviderStatus {
    const provider = this.getProviderName();
    const senderId = this.getSenderId();
    const apiKey = this.getApiKey();
    const apiUrl = this.getApiUrl();

    const apiSecret = this.getApiSecret();
    const providerKey = provider.toLowerCase();
    const configured =
      providerKey === 'twilio'
        ? Boolean(apiKey && apiSecret)
        : providerKey === 'afromessage'
          ? Boolean(apiKey)
          : Boolean(apiUrl && apiKey);

    return {
      provider,
      senderId,
      configured,
      endpointConfigured: Boolean(apiUrl || providerKey === 'twilio' || providerKey === 'afromessage'),
    };
  }

  /**
   * Validates and normalizes an Ethiopian phone number according to project rules
   */
  public validateAndNormalizePhone(rawPhone: string): {
    valid: boolean;
    normalized: string;
    error?: string;
  } {
    if (!rawPhone || typeof rawPhone !== 'string' || !rawPhone.trim()) {
      return {
        valid: false,
        normalized: '',
        error: 'Recipient phone number is required.',
      };
    }

    const validation = validateEthiopianPhone(rawPhone);
    if (!validation.isValid) {
      return {
        valid: false,
        normalized: rawPhone.trim(),
        error: validation.error || 'Invalid Ethiopian phone number format.',
      };
    }

    const normalized = normalizeEthiopianPhone(rawPhone);
    return {
      valid: true,
      normalized,
    };
  }

  /**
   * Sends an SMS message to a single recipient
   */
  public async sendSms(input: SmsDispatchInput): Promise<SmsDispatchResult> {
    const provider = this.getProviderName();
    const senderId = this.getSenderId(input.senderId);
    const rawRecipient = (input.recipient || '').trim();
    const message = (input.message || '').trim();

    // 1. Validate message body
    if (!message) {
      return {
        success: false,
        status: 'FAILED',
        recipient: rawRecipient,
        normalizedRecipient: rawRecipient,
        provider,
        providerMessageId: null,
        errorMessage: 'SMS message body cannot be empty.',
        sentAt: null,
        deliveredAt: null,
      };
    }

    if (message.length > 1600) {
      return {
        success: false,
        status: 'FAILED',
        recipient: rawRecipient,
        normalizedRecipient: rawRecipient,
        provider,
        providerMessageId: null,
        errorMessage: 'SMS message exceeds maximum allowed length (1600 characters).',
        sentAt: null,
        deliveredAt: null,
      };
    }

    // 2. Validate & normalize Ethiopian phone number
    const phoneCheck = this.validateAndNormalizePhone(rawRecipient);
    if (!phoneCheck.valid) {
      return {
        success: false,
        status: 'FAILED',
        recipient: rawRecipient,
        normalizedRecipient: phoneCheck.normalized,
        provider,
        providerMessageId: null,
        errorMessage: phoneCheck.error || 'Invalid Ethiopian phone number.',
        sentAt: null,
        deliveredAt: null,
      };
    }

    const normalizedPhone = phoneCheck.normalized;
    const apiKey = this.getApiKey();
    const apiSecret = this.getApiSecret();
    const apiUrl = this.getApiUrl();
    const nowIso = new Date().toISOString();

    try {
      // 3A. Twilio Provider
      if (provider.toLowerCase() === 'twilio' && apiKey && apiSecret) {
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(apiKey)}/Messages.json`;
        const authHeader = Buffer.from(`${apiKey}:${apiSecret}`).toString('base64');
        const formData = new URLSearchParams();
        formData.append('To', normalizedPhone);
        formData.append('From', senderId);
        formData.append('Body', message);

        const response = await fetch(twilioUrl, {
          method: 'POST',
          headers: {
            Authorization: `Basic ${authHeader}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: formData.toString(),
        });

        const data: any = await response.json().catch(() => ({}));
        if (!response.ok) {
          return {
            success: false,
            status: 'FAILED',
            recipient: normalizedPhone,
            normalizedRecipient: normalizedPhone,
            provider: 'Twilio',
            providerMessageId: null,
            errorMessage: data?.message || `Twilio API error (${response.status})`,
            sentAt: null,
            deliveredAt: null,
          };
        }

        return {
          success: true,
          status: data?.status === 'delivered' ? 'DELIVERED' : 'SENT',
          recipient: normalizedPhone,
          normalizedRecipient: normalizedPhone,
          provider: 'Twilio',
          providerMessageId: data?.sid || `tw-${Date.now()}`,
          errorMessage: null,
          sentAt: nowIso,
          deliveredAt: data?.status === 'delivered' ? nowIso : null,
        };
      }

      // 3B. AfroMessage Provider
      if (provider.toLowerCase() === 'afromessage' && apiKey) {
        const afroUrl = apiUrl || 'https://api.afromessage.com/api/send';
        const response = await fetch(afroUrl, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
          body: JSON.stringify({
            sender: senderId,
            to: normalizedPhone,
            message,
          }),
        });

        const data: any = await response.json().catch(() => ({}));
        if (!response.ok || data?.acknowledge === 'error') {
          return {
            success: false,
            status: 'FAILED',
            recipient: normalizedPhone,
            normalizedRecipient: normalizedPhone,
            provider: 'AfroMessage',
            providerMessageId: null,
            errorMessage: data?.response?.errors?.[0] || data?.message || `AfroMessage HTTP ${response.status}`,
            sentAt: null,
            deliveredAt: null,
          };
        }

        return {
          success: true,
          status: 'SENT',
          recipient: normalizedPhone,
          normalizedRecipient: normalizedPhone,
          provider: 'AfroMessage',
          providerMessageId: data?.response?.message_id || `afro-${Date.now()}`,
          errorMessage: null,
          sentAt: nowIso,
          deliveredAt: null,
        };
      }

      // 3C. Ethio Telecom / Generic REST SMS Gateway when credentials are provided
      if (apiUrl && apiKey) {
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'X-App-Id': apiKey,
        };
        if (apiSecret) {
          headers['X-App-Secret'] = apiSecret;
          headers['Authorization'] = `Bearer ${apiSecret}`;
        } else {
          headers['Authorization'] = `Bearer ${apiKey}`;
        }

        const response = await fetch(apiUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            senderId,
            recipient: normalizedPhone,
            to: normalizedPhone,
            message,
            timestamp: nowIso,
          }),
        });

        const data: any = await response.json().catch(() => ({}));
        if (!response.ok) {
          return {
            success: false,
            status: 'FAILED',
            recipient: normalizedPhone,
            normalizedRecipient: normalizedPhone,
            provider,
            providerMessageId: null,
            errorMessage: data?.message || data?.error || `SMS Gateway HTTP ${response.status}`,
            sentAt: null,
            deliveredAt: null,
          };
        }

        return {
          success: true,
          status: data?.status === 'DELIVERED' ? 'DELIVERED' : 'SENT',
          recipient: normalizedPhone,
          normalizedRecipient: normalizedPhone,
          provider,
          providerMessageId: data?.messageId || data?.id || `et-sms-${Date.now()}`,
          errorMessage: null,
          sentAt: nowIso,
          deliveredAt: data?.status === 'DELIVERED' ? nowIso : null,
        };
      }

      // Never fabricate a message ID or report SENT without an actual
      // configured provider accepting the request.
      return {
        success: false,
        status: 'FAILED',
        recipient: normalizedPhone,
        normalizedRecipient: normalizedPhone,
        provider,
        providerMessageId: null,
        errorMessage:
          'SMS delivery is unavailable because no supported SMS provider is fully configured on the server.',
        sentAt: null,
        deliveredAt: null,
      };
    } catch (err: any) {
      return {
        success: false,
        status: 'FAILED',
        recipient: normalizedPhone,
        normalizedRecipient: normalizedPhone,
        provider,
        providerMessageId: null,
        errorMessage: err?.message || 'Unexpected error communicating with SMS provider.',
        sentAt: null,
        deliveredAt: null,
      };
    }
  }
}

export const smsService = new SmsService();
