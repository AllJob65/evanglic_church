import { Request } from 'express';
import crypto from 'crypto';
import { db } from '../db';
import { AuditLog, UserRole } from '../../src/types';
import { getRequestContext } from '../utils/requestContext';
import { getAdminClient, isSupabaseConfigured } from '../../src/lib/supabase';
import { isPgConfigured, query } from '../pg';

// ==============================================================================
// CENTRALIZED SECURITY AUDIT, DURABLE SESSION TRACKING, & ALERT DETECTION SERVICE
// ==============================================================================

export type SecurityEventType =
  | 'AUTH_LOGIN_SUCCESS'
  | 'AUTH_LOGIN_FAILURE'
  | 'AUTH_LOGOUT'
  | 'SESSION_EXPIRED'
  | 'SESSION_REVOKED'
  | 'PASSWORD_CHANGED'
  | 'PASSWORD_RESET_REQUESTED'
  | 'PASSWORD_RESET_COMPLETED'
  | 'ADMIN_PASSWORD_RESET'
  | 'MFA_ENROLLED'
  | 'MFA_ENABLED'
  | 'MFA_DISABLED'
  | 'MFA_CHALLENGE_ISSUED'
  | 'MFA_VERIFICATION_SUCCESS'
  | 'MFA_VERIFICATION_FAILURE'
  | 'TOKEN_INVALID_OR_EXPIRED'
  | 'REFRESH_TOKEN_REUSE_DETECTED'
  | 'UNAUTHORIZED_API_ACCESS'
  | 'ROLE_PERMISSION_CHANGED'
  | 'PRIVILEGED_ADMIN_ACTION'
  | 'RATE_LIMIT_VIOLATION'
  | 'CSRF_VIOLATION'
  | 'SECURITY_CONFIG_CHANGED'
  | 'AUDIT_INTEGRITY_VERIFIED';

export type SecuritySeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type SecurityOutcome = 'SUCCESS' | 'FAILURE' | 'BLOCKED' | 'WARNING';

export interface ActiveSessionRecord {
  sessionId: string; // Safe non-reversible SHA-256 fingerprint prefix (e.g. sess_a1b2c3d4e5f6)
  tokenHash: string; // Full SHA-256 hash of access token (never exposed in API responses)
  refreshTokenHash?: string; // Full SHA-256 hash of current valid refresh token
  userId: string;
  userEmail: string;
  userName: string;
  userRole: UserRole;
  tenantId: string;
  branchId: string;
  ipAddress: string;
  userAgent: string;
  device: string;
  deviceFingerprint: string;
  loginTime: string;
  lastActivity: string;
  expiresAt: string;
  aal: 'aal1' | 'aal2';
  mfaVerified: boolean;
  status: 'ACTIVE' | 'REVOKED' | 'EXPIRED';
  revokedAt?: string;
  revokedBy?: string;
  revocationReason?: string;
}

export interface SecurityAlertRecord {
  id: string;
  timestamp: string;
  alertType:
    | 'REPEATED_FAILED_LOGINS'
    | 'SUSPICIOUS_AUTH_FAILURES'
    | 'INVALID_TOKEN_SPIKE'
    | 'PRIVILEGED_ACCOUNT_CHANGE'
    | 'REFRESH_TOKEN_REUSE'
    | 'RATE_LIMIT_BREACH'
    | 'UNAUTHORIZED_ACCESS_PATTERN';
  severity: SecuritySeverity;
  title: string;
  description: string;
  actorId?: string;
  actorEmail?: string;
  ipAddress?: string;
  correlationId: string;
  status: 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED';
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  metadata?: Record<string, any>;
}

const SENSITIVE_KEYS_PATTERN =
  /password|passwd|secret|token|authorization|cookie|totp|otp|mfa_code|access_token|refresh_token|service_role|api_key|private_key/i;

/**
 * Redacts any sensitive credentials, raw tokens, cookies, or secret headers from metadata objects or strings.
 */
export function redactSensitiveMetadata(input: any): any {
  if (input === null || input === undefined) return input;
  if (typeof input === 'string') {
    // Redact Bearer tokens or JWT-like strings (eyJ...)
    return input
      .replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, 'Bearer [REDACTED_TOKEN]')
      .replace(/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, '[REDACTED_JWT]');
  }
  if (Array.isArray(input)) {
    return input.map((item) => redactSensitiveMetadata(item));
  }
  if (typeof input === 'object') {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(input)) {
      if (SENSITIVE_KEYS_PATTERN.test(k)) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = redactSensitiveMetadata(v);
      }
    }
    return out;
  }
  return input;
}

/**
 * Computes a safe, non-reversible session identifier from a raw token or session ID.
 * Never stores or returns the raw token.
 */
export function toSafeSessionId(rawTokenOrId?: string | null): string {
  if (!rawTokenOrId || !rawTokenOrId.trim()) return 'sess_unauthenticated';
  const clean = rawTokenOrId.trim();
  if (clean.startsWith('sess_') && clean.length <= 24) return clean;
  const hash = crypto.createHash('sha256').update(clean).digest('hex');
  return `sess_${hash.slice(0, 12)}`;
}

export function hashRawToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken.trim()).digest('hex');
}

// ==============================================================================
// DURABLE-BACKED STORES (Hydrated from db.getState() on startup & persisted on every mutation)
// ==============================================================================
const activeSessionsById = new Map<string, ActiveSessionRecord>();
const sessionIdByTokenHash = new Map<string, string>();
const consumedRefreshTokens = new Map<
  string,
  { sessionId: string; userId: string; userEmail: string; consumedAt: number }
>();
const securityAlertsStore: SecurityAlertRecord[] = [];
const userRevokedAtByUser = new Map<string, number>();

// Rolling window counters for real-time anomaly & alert detection
const recentFailedLoginsByActor = new Map<string, { count: number; firstAt: number; ips: Set<string> }>();
const recentInvalidTokensByIp = new Map<string, { count: number; firstAt: number }>();

/**
 * Computes tamper-evident SHA-256 hash chain for an audit log entry.
 */
export function computeAuditChainHash(prevHash: string, entry: Partial<AuditLog>): string {
  const canonical = [
    prevHash,
    entry.id || '',
    entry.timestamp || '',
    entry.eventType || entry.action || '',
    entry.actorId || entry.userEmail || '',
    entry.outcome || 'SUCCESS',
    entry.severity || 'LOW',
    entry.module || '',
    entry.details || '',
    entry.ipAddress || '',
  ].join('|');
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

class SecurityAuditService {
  constructor() {
    this.hydrateFromDurableStore();
  }

  /**
   * Hydrates active sessions, consumed refresh tokens, security alerts, and user revocation
   * timestamps from the durable database snapshot (`db.getState()`) on server startup.
   */
  public hydrateFromDurableStore(): void {
    try {
      const state = db.getState();

      // 1. Hydrate sessions
      activeSessionsById.clear();
      sessionIdByTokenHash.clear();
      if (Array.isArray(state.securitySessions)) {
        for (const s of state.securitySessions) {
          if (s && s.sessionId) {
            activeSessionsById.set(s.sessionId, s);
            if (s.tokenHash) {
              sessionIdByTokenHash.set(s.tokenHash, s.sessionId);
            }
          }
        }
      }

      // 2. Hydrate consumed refresh tokens
      consumedRefreshTokens.clear();
      if (Array.isArray(state.consumedRefreshTokens)) {
        for (const rt of state.consumedRefreshTokens) {
          if (rt && rt.tokenHash) {
            consumedRefreshTokens.set(rt.tokenHash, {
              sessionId: rt.sessionId,
              userId: rt.userId,
              userEmail: rt.userEmail,
              consumedAt: rt.consumedAt,
            });
          }
        }
      }

      // 3. Hydrate security alerts
      securityAlertsStore.length = 0;
      if (Array.isArray(state.securityAlerts)) {
        securityAlertsStore.push(...state.securityAlerts);
      }

      // 4. Hydrate user revocations
      userRevokedAtByUser.clear();
      if (state.userRevocations && typeof state.userRevocations === 'object') {
        for (const [k, v] of Object.entries(state.userRevocations)) {
          if (typeof v === 'number') {
            userRevokedAtByUser.set(k.toLowerCase(), v);
          }
        }
      }

      // 5. Startup is strictly read-only: NEVER rewrite existing audit hashes.
      // Initialize the independent HMAC checkpoint anchor ONLY if none exists on disk yet.
      const existingCheckpoint = db.readAuditCheckpoint();
      if (!existingCheckpoint.exists) {
        db.writeAuditCheckpoint(state.auditLogs);
      }
    } catch (err) {
      console.warn('[SecurityAuditService] Warning hydrating security state:', err);
    }
  }

  /**
   * Synchronizes in-memory maps into durable `db.getState()` and triggers `db.persist()`.
   * Propagates persistence errors when `throwOnError` is true.
   */
  private syncToDurableStore(options?: { throwOnError?: boolean }): void {
    const state = db.getState();
    state.securitySessions = Array.from(activeSessionsById.values());
    state.consumedRefreshTokens = Array.from(consumedRefreshTokens.entries()).map(
      ([tokenHash, val]) => ({
        tokenHash,
        sessionId: val.sessionId,
        userId: val.userId,
        userEmail: val.userEmail,
        consumedAt: val.consumedAt,
      })
    );
    state.securityAlerts = [...securityAlertsStore];
    const revMap: Record<string, number> = {};
    for (const [k, v] of userRevokedAtByUser.entries()) {
      revMap[k] = v;
    }
    state.userRevocations = revMap;
    db.persist(undefined, { throwOnError: options?.throwOnError ?? true });
  }

  /**
   * Asynchronously Dual-Writes an audit event to PostgreSQL (`DATABASE_URL`) or Supabase (`public.audit_logs`)
   * when configured, while keeping the durable local store authoritative.
   */
  private async persistAuditEventToDatabase(logEntry: AuditLog, tenantId?: string): Promise<void> {
    const resolvedTenantId = tenantId || '773627bc-212b-4336-be98-dd44b141d84e';

    if (isPgConfigured()) {
      try {
        await query(
          `INSERT INTO public.audit_logs (
            id, tenant_id, timestamp, user_id, actor_id, user_email, user_name, user_role,
            event_type, outcome, severity, correlation_id, action, module,
            target_user_id, target_user_email, ip_address, user_agent, device_fingerprint,
            session_id, details, commit_data, device, prev_hash, integrity_hash, schema_version
          ) VALUES (
            $1, $2::uuid, $3::timestamptz, $4, $5, $6, $7, $8,
            $9, $10, $11, $12, $13, $14,
            $15, $16, $17, $18, $19,
            $20, $21, $22, $23, $24, $25, $26
          ) ON CONFLICT (id) DO NOTHING`,
          [
            logEntry.id,
            resolvedTenantId,
            logEntry.timestamp,
            logEntry.actorId || logEntry.userEmail,
            logEntry.actorId || logEntry.userEmail,
            logEntry.userEmail,
            logEntry.userName || logEntry.user || logEntry.userEmail,
            logEntry.userRole,
            logEntry.eventType || logEntry.action,
            logEntry.outcome || 'SUCCESS',
            logEntry.severity || 'LOW',
            logEntry.correlationId || null,
            logEntry.action,
            logEntry.module,
            logEntry.targetUserId || null,
            logEntry.targetUserEmail || null,
            logEntry.ipAddress,
            logEntry.userAgent || null,
            logEntry.deviceFingerprint || null,
            logEntry.sessionId || null,
            logEntry.details,
            logEntry.commitData || null,
            logEntry.device || null,
            logEntry.prevHash || null,
            logEntry.integrityHash || null,
            logEntry.schemaVersion || '2.0',
          ]
        );
        return;
      } catch {
        // Fallback to Supabase REST or local store if direct PG table migration 024 is not yet applied
      }
    }

    if (isSupabaseConfigured) {
      try {
        const admin = getAdminClient();
        await admin.from('audit_logs').upsert({
          id: logEntry.id,
          tenant_id: resolvedTenantId,
          timestamp: logEntry.timestamp,
          user_id: logEntry.actorId || logEntry.userEmail,
          user_email: logEntry.userEmail,
          user_name: logEntry.userName || logEntry.userEmail,
          user_role: logEntry.userRole,
          action: logEntry.action,
          module: logEntry.module,
          ip_address: logEntry.ipAddress,
          user_agent: logEntry.userAgent || null,
          device_fingerprint: logEntry.deviceFingerprint || null,
          session_id: logEntry.sessionId || null,
          details: logEntry.details,
          commit_data: logEntry.commitData || null,
          device: logEntry.device || null,
        });
      } catch {
        // Non-fatal if remote Supabase table lacks optional columns
      }
    }
  }

  /**
   * Registers or updates an active authenticated session from real login/refresh/verify flows.
   */
  public registerSession(params: {
    rawAccessToken: string;
    rawRefreshToken?: string;
    userId: string;
    userEmail: string;
    userName: string;
    userRole: UserRole;
    tenantId?: string;
    branchId?: string;
    req?: Request;
    expiresInSeconds?: number;
    aal?: 'aal1' | 'aal2';
    mfaVerified?: boolean;
  }): ActiveSessionRecord {
    const tokenHash = hashRawToken(params.rawAccessToken);
    const sessionId = toSafeSessionId(params.rawAccessToken);
    const refreshTokenHash = params.rawRefreshToken ? hashRawToken(params.rawRefreshToken) : undefined;
    const ctx = params.req ? getRequestContext(params.req) : null;
    const nowIso = new Date().toISOString();
    const secConfig = db.getSecurityConfig();
    const lifespanSeconds =
      params.expiresInSeconds || (secConfig.jwtLifespanHours || 8) * 3600;
    const expiresAtIso = new Date(Date.now() + lifespanSeconds * 1000).toISOString();

    const record: ActiveSessionRecord = {
      sessionId,
      tokenHash,
      refreshTokenHash,
      userId: params.userId,
      userEmail: params.userEmail.toLowerCase(),
      userName: params.userName,
      userRole: params.userRole,
      tenantId: params.tenantId || '773627bc-212b-4336-be98-dd44b141d84e',
      branchId: params.branchId || '65204c56-5288-4473-82d5-ae62150dfdb7',
      ipAddress: ctx?.ipAddress || '127.0.0.1',
      userAgent: ctx?.userAgent || 'Browser Session',
      device: ctx?.device || 'Web Client',
      deviceFingerprint: ctx?.deviceFingerprint || 'untracked',
      loginTime: nowIso,
      lastActivity: nowIso,
      expiresAt: expiresAtIso,
      aal: params.aal || 'aal1',
      mfaVerified: Boolean(params.mfaVerified),
      status: 'ACTIVE',
    };

    activeSessionsById.set(sessionId, record);
    sessionIdByTokenHash.set(tokenHash, sessionId);
    this.syncToDurableStore();
    return record;
  }

  /**
   * Updates lastActivity timestamp for an active session when a request is authenticated.
   */
  public touchSessionByToken(
    rawAccessToken: string,
    userContext?: {
      id: string;
      email: string;
      name: string;
      role: UserRole;
      tenantId: string;
      branchId: string;
      aal?: 'aal1' | 'aal2';
      mfa_enabled?: boolean;
    },
    req?: Request
  ): ActiveSessionRecord | undefined {
    if (!rawAccessToken) return undefined;
    const tokenHash = hashRawToken(rawAccessToken);
    const sessionId = sessionIdByTokenHash.get(tokenHash) || toSafeSessionId(rawAccessToken);
    const existing = activeSessionsById.get(sessionId);

    const nowIso = new Date().toISOString();
    if (existing) {
      if (existing.status === 'ACTIVE') {
        const prevMs = new Date(existing.lastActivity).getTime();
        existing.lastActivity = nowIso;
        if (req) {
          const ctx = getRequestContext(req);
          existing.ipAddress = ctx.ipAddress;
          existing.device = ctx.device;
        }
        // Throttle disk sync on touch to once every 30s per session
        if (isNaN(prevMs) || Date.now() - prevMs > 30_000) {
          this.syncToDurableStore();
        }
      }
      return existing;
    }

    // If session was created before server restart, register it from verified token
    if (userContext) {
      return this.registerSession({
        rawAccessToken,
        userId: userContext.id,
        userEmail: userContext.email,
        userName: userContext.name,
        userRole: userContext.role,
        tenantId: userContext.tenantId,
        branchId: userContext.branchId,
        req,
        aal: userContext.aal || 'aal1',
        mfaVerified: userContext.aal === 'aal2' || Boolean(userContext.mfa_enabled),
      });
    }
    return undefined;
  }

  /**
   * Tracks refresh token rotation and detects refresh-token reuse attacks.
   * Returns { reuseDetected: true } if an already-consumed refresh token is presented again.
   */
  public verifyAndRotateRefreshToken(params: {
    oldRefreshToken: string;
    newAccessToken?: string;
    newRefreshToken?: string;
    userId?: string;
    userEmail?: string;
    req?: Request;
  }): { reuseDetected: boolean; compromisedUserId?: string; compromisedEmail?: string } {
    const oldHash = hashRawToken(params.oldRefreshToken);
    const previouslyConsumed = consumedRefreshTokens.get(oldHash);

    if (previouslyConsumed) {
      const elapsedMs = Date.now() - previouslyConsumed.consumedAt;
      // Allow a 15-second grace period for concurrent page reloads, React StrictMode, or multi-tab refresh calls
      if (elapsedMs >= 0 && elapsedMs < 15_000) {
        return { reuseDetected: false };
      }

      // Refresh token reuse detected outside grace window! Automatically revoke all sessions for that user and raise CRITICAL alert
      this.revokeAllSessionsForUser(
        previouslyConsumed.userId,
        'SYSTEM_SECURITY_GUARD',
        'Automatic revocation due to refresh token reuse detection'
      );

      this.createAlert({
        alertType: 'REFRESH_TOKEN_REUSE',
        severity: 'CRITICAL',
        title: 'Refresh Token Reuse Detected',
        description: `A previously rotated refresh token for ${previouslyConsumed.userEmail} was replayed. All active sessions for this user have been immediately revoked.`,
        actorId: previouslyConsumed.userId,
        actorEmail: previouslyConsumed.userEmail,
        ipAddress: params.req ? getRequestContext(params.req).ipAddress : undefined,
        metadata: {
          sessionId: previouslyConsumed.sessionId,
          originallyConsumedAt: new Date(previouslyConsumed.consumedAt).toISOString(),
        },
      });

      this.recordEvent({
        req: params.req,
        eventType: 'REFRESH_TOKEN_REUSE_DETECTED',
        action: 'Refresh Token Reuse Blocked',
        module: 'Authentication & Session Security',
        details: `Detected replay of consumed refresh token for ${previouslyConsumed.userEmail} (session ${previouslyConsumed.sessionId}). Revoked all user sessions.`,
        actorId: previouslyConsumed.userId,
        actorEmail: previouslyConsumed.userEmail,
        outcome: 'BLOCKED',
        severity: 'CRITICAL',
        sessionId: previouslyConsumed.sessionId,
      });

      return {
        reuseDetected: true,
        compromisedUserId: previouslyConsumed.userId,
        compromisedEmail: previouslyConsumed.userEmail,
      };
    }

    // Mark old refresh token as consumed and persist durably
    if (params.userId && params.userEmail) {
      const sessionId = params.newAccessToken
        ? toSafeSessionId(params.newAccessToken)
        : `sess_${oldHash.slice(0, 12)}`;
      consumedRefreshTokens.set(oldHash, {
        sessionId,
        userId: params.userId,
        userEmail: params.userEmail,
        consumedAt: Date.now(),
      });
      this.syncToDurableStore();
    }

    return { reuseDetected: false };
  }

  /**
   * Marks a specific session as REVOKED by sessionId or raw token and persists durably.
   */
  public markSessionRevoked(
    sessionIdOrRawToken: string,
    revokedBy: string,
    reason: string = 'Explicit session revocation'
  ): ActiveSessionRecord | null {
    const safeId = toSafeSessionId(sessionIdOrRawToken);
    const session = activeSessionsById.get(safeId) || activeSessionsById.get(sessionIdOrRawToken);
    const nowIso = new Date().toISOString();

    if (!session) {
      // Even if the session was not previously registered in the table, record a synthetic revoked entry
      // so the safe sessionId / tokenHash is durably blacklisted across restarts.
      const tokenHash = sessionIdOrRawToken.startsWith('sess_')
        ? sessionIdOrRawToken
        : hashRawToken(sessionIdOrRawToken);
      const synthetic: ActiveSessionRecord = {
        sessionId: safeId,
        tokenHash,
        userId: 'unknown',
        userEmail: 'unknown',
        userName: 'Revoked Token',
        userRole: 'REGULAR_MEMBER',
        tenantId: '773627bc-212b-4336-be98-dd44b141d84e',
        branchId: '65204c56-5288-4473-82d5-ae62150dfdb7',
        ipAddress: '127.0.0.1',
        userAgent: 'Revoked Session',
        device: 'Revoked Token',
        deviceFingerprint: 'revoked',
        loginTime: nowIso,
        lastActivity: nowIso,
        expiresAt: nowIso,
        aal: 'aal1',
        mfaVerified: false,
        status: 'REVOKED',
        revokedAt: nowIso,
        revokedBy,
        revocationReason: reason,
      };
      activeSessionsById.set(safeId, synthetic);
      sessionIdByTokenHash.set(tokenHash, safeId);
      this.syncToDurableStore();
      return synthetic;
    }

    session.status = 'REVOKED';
    session.revokedAt = nowIso;
    session.revokedBy = revokedBy;
    session.revocationReason = reason;
    this.syncToDurableStore();
    return session;
  }

  /**
   * Marks all sessions belonging to a userId (or email) as REVOKED and records a durable user-level
   * revocation timestamp so any JWT issued prior to this timestamp is rejected across restarts.
   */
  public revokeAllSessionsForUser(
    userIdOrEmail: string,
    revokedBy: string,
    reason: string = 'Administrative global session revocation'
  ): number {
    const clean = userIdOrEmail.trim().toLowerCase();
    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();
    userRevokedAtByUser.set(clean, nowMs);

    let count = 0;
    for (const sess of activeSessionsById.values()) {
      if (
        (sess.userId.toLowerCase() === clean || sess.userEmail.toLowerCase() === clean) &&
        sess.status === 'ACTIVE'
      ) {
        sess.status = 'REVOKED';
        sess.revokedAt = nowIso;
        sess.revokedBy = revokedBy;
        sess.revocationReason = reason;
        count++;
      }
    }
    this.syncToDurableStore();
    return count;
  }

  /**
   * Returns the durable user-level revocation timestamp (ms) if all sessions for the user were revoked.
   */
  public getUserRevokedAtMs(userIdOrEmail?: string | null): number | undefined {
    if (!userIdOrEmail) return undefined;
    return userRevokedAtByUser.get(userIdOrEmail.trim().toLowerCase());
  }

  /**
   * Checks whether a safe sessionId or raw token has been explicitly revoked in the durable session registry.
   */
  public isSessionIdRevoked(rawTokenOrSessionId: string): boolean {
    const safeId = toSafeSessionId(rawTokenOrSessionId);
    const sess = activeSessionsById.get(safeId) || activeSessionsById.get(rawTokenOrSessionId);
    return sess?.status === 'REVOKED';
  }

  /**
   * Returns all tracked sessions (sanitized: never exposes tokenHash or refreshTokenHash).
   */
  public listSessions(filters?: { status?: string; userId?: string; search?: string }): Omit<
    ActiveSessionRecord,
    'tokenHash' | 'refreshTokenHash'
  >[] {
    const nowMs = Date.now();
    const list: Omit<ActiveSessionRecord, 'tokenHash' | 'refreshTokenHash'>[] = [];

    for (const sess of activeSessionsById.values()) {
      if (sess.userId === 'unknown' && sess.userName === 'Revoked Token') {
        continue; // Skip synthetic raw-token blacklist entries from UI display
      }
      if (sess.status === 'ACTIVE' && new Date(sess.expiresAt).getTime() < nowMs) {
        sess.status = 'EXPIRED';
      }
      if (filters?.status && filters.status !== 'ALL' && sess.status !== filters.status) {
        continue;
      }
      if (filters?.userId && sess.userId !== filters.userId && sess.userEmail !== filters.userId.toLowerCase()) {
        continue;
      }
      if (filters?.search) {
        const q = filters.search.trim().toLowerCase();
        const matches =
          sess.userEmail.toLowerCase().includes(q) ||
          sess.userName.toLowerCase().includes(q) ||
          sess.ipAddress.toLowerCase().includes(q) ||
          sess.device.toLowerCase().includes(q) ||
          sess.sessionId.toLowerCase().includes(q);
        if (!matches) continue;
      }

      const { tokenHash: _th, refreshTokenHash: _rth, ...safeSession } = sess;
      list.push(safeSession);
    }

    return list.sort((a, b) => new Date(b.lastActivity).getTime() - new Date(a.lastActivity).getTime());
  }

  /**
   * Creates a structured security alert, deduplicates noisy alerts within a 5-minute window,
   * and persists durably.
   */
  public createAlert(params: {
    alertType: SecurityAlertRecord['alertType'];
    severity: SecuritySeverity;
    title: string;
    description: string;
    actorId?: string;
    actorEmail?: string;
    ipAddress?: string;
    correlationId?: string;
    metadata?: Record<string, any>;
  }): SecurityAlertRecord {
    const now = Date.now();
    const recentMatch = securityAlertsStore.find(
      (a) =>
        a.status === 'OPEN' &&
        a.alertType === params.alertType &&
        a.actorEmail === params.actorEmail &&
        a.ipAddress === params.ipAddress &&
        now - new Date(a.timestamp).getTime() < 5 * 60 * 1000
    );
    if (recentMatch) {
      recentMatch.timestamp = new Date().toISOString();
      recentMatch.description = redactSensitiveMetadata(params.description);
      this.syncToDurableStore();
      return recentMatch;
    }

    const alert: SecurityAlertRecord = {
      id: `sec-alert-${now}-${crypto.randomBytes(3).toString('hex')}`,
      timestamp: new Date(now).toISOString(),
      alertType: params.alertType,
      severity: params.severity,
      title: params.title,
      description: redactSensitiveMetadata(params.description),
      actorId: params.actorId,
      actorEmail: params.actorEmail,
      ipAddress: params.ipAddress,
      correlationId: params.correlationId || `corr_${crypto.randomBytes(6).toString('hex')}`,
      status: 'OPEN',
      metadata: redactSensitiveMetadata(params.metadata || {}),
    };

    securityAlertsStore.unshift(alert);
    if (securityAlertsStore.length > 500) {
      securityAlertsStore.pop();
    }
    this.syncToDurableStore();
    return alert;
  }

  public getAlerts(statusFilter?: string): SecurityAlertRecord[] {
    if (!statusFilter || statusFilter === 'ALL') {
      return [...securityAlertsStore];
    }
    return securityAlertsStore.filter((a) => a.status === statusFilter.toUpperCase());
  }

  public updateAlertStatus(
    alertId: string,
    status: 'ACKNOWLEDGED' | 'RESOLVED',
    actorEmail: string
  ): SecurityAlertRecord | null {
    const found = securityAlertsStore.find((a) => a.id === alertId);
    if (!found) return null;
    found.status = status;
    found.acknowledgedBy = actorEmail;
    found.acknowledgedAt = new Date().toISOString();
    this.syncToDurableStore();
    return found;
  }

  /**
   * Central method to record any security-relevant event with tamper-evident hash chaining,
   * automatic credential redaction, durable persistence, and real-time anomaly alert evaluation.
   */
  public recordEvent(options: {
    req?: Request;
    eventType: SecurityEventType;
    action: string;
    module: string;
    details: string;
    actorId?: string;
    actorEmail?: string;
    actorName?: string;
    actorRole?: UserRole | string;
    targetUserId?: string;
    targetUserEmail?: string;
    outcome?: SecurityOutcome;
    severity?: SecuritySeverity;
    correlationId?: string;
    sessionId?: string;
    metadata?: Record<string, any>;
  }): AuditLog {
    const ctx = options.req ? getRequestContext(options.req) : null;
    const ipAddress = ctx?.ipAddress || '127.0.0.1';
    const userAgent = ctx?.userAgent || 'Server Internal';
    const device = ctx?.device || 'System Process';
    const deviceFingerprint = ctx?.deviceFingerprint || 'untracked';

    const actorEmail = (
      options.actorEmail ||
      ctx?.userEmail ||
      'unauthenticated@gracecathedral.org'
    ).toLowerCase();
    const actorName = options.actorName || ctx?.userName || actorEmail;
    const actorRole = (options.actorRole || ctx?.userRole || 'REGULAR_MEMBER') as UserRole;
    const actorId = options.actorId || ctx?.userId || actorEmail;

    const rawAuthHeader = options.req?.headers?.authorization;
    const extractedToken =
      rawAuthHeader && rawAuthHeader.startsWith('Bearer ')
        ? rawAuthHeader.slice(7).trim()
        : undefined;

    const safeSessionId =
      options.sessionId
        ? toSafeSessionId(options.sessionId)
        : extractedToken
          ? toSafeSessionId(extractedToken)
          : ctx?.sessionId
            ? toSafeSessionId(ctx.sessionId)
            : 'sess_anonymous';

    const correlationId =
      options.correlationId ||
      (options.req?.headers?.['x-correlation-id'] as string) ||
      `corr_${crypto.randomBytes(6).toString('hex')}`;

    const outcome: SecurityOutcome = options.outcome || 'SUCCESS';
    const severity: SecuritySeverity = options.severity || 'LOW';
    const sanitizedDetails = redactSensitiveMetadata(options.details);
    const sanitizedMetadata = redactSensitiveMetadata({
      ...(options.metadata || {}),
      targetUserId: options.targetUserId,
      targetUserEmail: options.targetUserEmail,
      correlationId,
      safeSessionId,
    });

    const timestamp = new Date().toISOString();
    const id = `audit-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;

    const logEntry = db.addAuditLog({
      id,
      timestamp,
      userEmail: actorEmail,
      userName: actorName,
      user: actorName,
      userRole: actorRole,
      actorId,
      eventType: options.eventType,
      outcome,
      severity,
      correlationId,
      action: options.action,
      module: options.module,
      targetUserId: options.targetUserId,
      targetUserEmail: options.targetUserEmail,
      details: sanitizedDetails,
      ipAddress,
      userAgent,
      deviceFingerprint,
      sessionId: safeSessionId,
      device,
      commitData: JSON.stringify(sanitizedMetadata),
      schemaVersion: '2.0',
    });

    // Asynchronously dual-write to PostgreSQL / Supabase when configured
    void this.persistAuditEventToDatabase(logEntry);

    // Evaluate real-time security alert rules
    this.evaluateRealTimeAlerts({
      eventType: options.eventType,
      outcome,
      severity,
      actorId,
      actorEmail,
      ipAddress,
      correlationId,
      details: sanitizedDetails,
      metadata: sanitizedMetadata,
    });

    return logEntry;
  }

  /**
   * Evaluates real-time security anomaly rules and generates alerts from actual backend events.
   */
  private evaluateRealTimeAlerts(event: {
    eventType: SecurityEventType;
    outcome: SecurityOutcome;
    severity: SecuritySeverity;
    actorId: string;
    actorEmail: string;
    ipAddress: string;
    correlationId: string;
    details: string;
    metadata: Record<string, any>;
  }) {
    const now = Date.now();
    const windowMs = 15 * 60 * 1000; // 15 minutes

    // 1. Repeated failed logins & distributed credential stuffing
    if (event.eventType === 'AUTH_LOGIN_FAILURE' || event.eventType === 'MFA_VERIFICATION_FAILURE') {
      const key = event.actorEmail || event.ipAddress;
      const tracker = recentFailedLoginsByActor.get(key);
      if (!tracker || now - tracker.firstAt > windowMs) {
        recentFailedLoginsByActor.set(key, {
          count: 1,
          firstAt: now,
          ips: new Set([event.ipAddress]),
        });
      } else {
        tracker.count += 1;
        tracker.ips.add(event.ipAddress);

        if (tracker.count >= 3) {
          this.createAlert({
            alertType: 'REPEATED_FAILED_LOGINS',
            severity: tracker.count >= 5 ? 'HIGH' : 'MEDIUM',
            title: `Repeated Authentication Failures (${tracker.count} attempts)`,
            description: `Account ${event.actorEmail} experienced ${tracker.count} failed authentication or MFA attempts within 15 minutes from IP ${event.ipAddress}.`,
            actorId: event.actorId,
            actorEmail: event.actorEmail,
            ipAddress: event.ipAddress,
            correlationId: event.correlationId,
            metadata: { failedCount: tracker.count, distinctIps: Array.from(tracker.ips) },
          });
        }

        if (tracker.ips.size >= 2) {
          this.createAlert({
            alertType: 'SUSPICIOUS_AUTH_FAILURES',
            severity: 'HIGH',
            title: 'Multi-IP Authentication Failure Pattern',
            description: `Failed login attempts for ${event.actorEmail} originated from ${tracker.ips.size} distinct IP addresses within 15 minutes.`,
            actorId: event.actorId,
            actorEmail: event.actorEmail,
            ipAddress: event.ipAddress,
            correlationId: event.correlationId,
            metadata: { distinctIps: Array.from(tracker.ips) },
          });
        }
      }
    }

    // 2. Invalid or expired token patterns
    if (event.eventType === 'TOKEN_INVALID_OR_EXPIRED') {
      const tracker = recentInvalidTokensByIp.get(event.ipAddress);
      if (!tracker || now - tracker.firstAt > windowMs) {
        recentInvalidTokensByIp.set(event.ipAddress, { count: 1, firstAt: now });
      } else {
        tracker.count += 1;
        if (tracker.count >= 5) {
          this.createAlert({
            alertType: 'INVALID_TOKEN_SPIKE',
            severity: 'MEDIUM',
            title: `Repeated Invalid/Expired Token Attempts (${tracker.count})`,
            description: `IP ${event.ipAddress} presented ${tracker.count} invalid, forged, or revoked bearer tokens within 15 minutes.`,
            actorEmail: event.actorEmail,
            ipAddress: event.ipAddress,
            correlationId: event.correlationId,
            metadata: { count: tracker.count },
          });
        }
      }
    }

    // 3. Privileged account / RBAC changes
    if (
      event.eventType === 'ROLE_PERMISSION_CHANGED' ||
      event.eventType === 'ADMIN_PASSWORD_RESET' ||
      event.eventType === 'MFA_DISABLED'
    ) {
      this.createAlert({
        alertType: 'PRIVILEGED_ACCOUNT_CHANGE',
        severity: event.severity === 'CRITICAL' ? 'CRITICAL' : 'HIGH',
        title: `Privileged Account Change: ${event.eventType.replace(/_/g, ' ')}`,
        description: event.details,
        actorId: event.actorId,
        actorEmail: event.actorEmail,
        ipAddress: event.ipAddress,
        correlationId: event.correlationId,
        metadata: event.metadata,
      });
    }

    // 4. Rate-limit violations
    if (event.eventType === 'RATE_LIMIT_VIOLATION') {
      this.createAlert({
        alertType: 'RATE_LIMIT_BREACH',
        severity: 'MEDIUM',
        title: 'API Rate-Limit Threshold Exceeded',
        description: event.details,
        actorEmail: event.actorEmail,
        ipAddress: event.ipAddress,
        correlationId: event.correlationId,
        metadata: event.metadata,
      });
    }

    // 5. Unauthorized API access attempts
    if (event.eventType === 'UNAUTHORIZED_API_ACCESS' && event.severity === 'HIGH') {
      this.createAlert({
        alertType: 'UNAUTHORIZED_ACCESS_PATTERN',
        severity: 'HIGH',
        title: 'Blocked Privilege Escalation or Unauthorized API Access',
        description: event.details,
        actorId: event.actorId,
        actorEmail: event.actorEmail,
        ipAddress: event.ipAddress,
        correlationId: event.correlationId,
        metadata: event.metadata,
      });
    }
  }

  /**
   * Verifies the cryptographic SHA-256 hash chain across all audit records from oldest to newest
   * in a strictly READ-ONLY manner.
   * - Pre-existing legacy records (created before v2.0 hash chaining) that lack prevHash/integrityHash
   *   at the start of history are explicitly flagged in `legacyUnchainedRecords` and `legacyRecordIds`
   *   without rewriting their hashes.
   * - Once the v2.0 hash chain begins, any missing hash, modified field, reordered record, removed record,
   *   or mismatch against the independent HMAC-signed checkpoint anchor fails verification immediately.
   */
  public verifyAuditTrailIntegrity(): {
    verified: boolean;
    totalRecords: number;
    chainedRecords: number;
    unchainedRecords: number;
    legacyUnchainedRecords: number;
    legacyRecordIds: string[];
    checkpointVerified: boolean;
    brokenAtRecordId?: string;
    failureReason?: string;
    headHash: string;
    checkedAt: string;
  } {
    const rawLogs = db.getState().auditLogs || [];
    const logs = [...rawLogs].reverse(); // chronological order (oldest -> newest)
    let chainedCount = 0;
    let legacyUnchainedCount = 0;
    const legacyRecordIds: string[] = [];
    let chainStarted = false;
    let expectedPrevHash = 'GENESIS_CMMS_AUDIT_CHAIN_0000000000000000';
    let lastChainedRecordId = 'GENESIS';

    for (const log of logs) {
      const hasHashes = Boolean(log.integrityHash && log.prevHash);

      if (!hasHashes) {
        if (!chainStarted) {
          // Pre-existing legacy record before hash chain began: explicitly flag without mutating
          legacyUnchainedCount++;
          legacyRecordIds.push(log.id);
          continue;
        } else {
          // Unchained record injected AFTER the cryptographic hash chain already started -> TAMPER / INJECTION
          return {
            verified: false,
            totalRecords: logs.length,
            chainedRecords: chainedCount,
            unchainedRecords: legacyUnchainedCount + 1,
            legacyUnchainedRecords: legacyUnchainedCount,
            legacyRecordIds,
            checkpointVerified: false,
            brokenAtRecordId: log.id,
            failureReason: `Unchained record ${log.id} detected after hash chain started (missing prevHash or integrityHash).`,
            headHash: expectedPrevHash,
            checkedAt: new Date().toISOString(),
          };
        }
      }

      chainStarted = true;
      chainedCount++;

      if (log.prevHash !== expectedPrevHash) {
        return {
          verified: false,
          totalRecords: logs.length,
          chainedRecords: chainedCount,
          unchainedRecords: legacyUnchainedCount,
          legacyUnchainedRecords: legacyUnchainedCount,
          legacyRecordIds,
          checkpointVerified: false,
          brokenAtRecordId: log.id,
          failureReason: `Broken hash link (record removed, reordered, or prevHash altered) at record ${log.id}: expected prevHash ${expectedPrevHash.slice(0, 12)}..., found ${log.prevHash!.slice(0, 12)}...`,
          headHash: expectedPrevHash,
          checkedAt: new Date().toISOString(),
        };
      }

      const recomputed = computeAuditChainHash(log.prevHash!, log);
      if (recomputed !== log.integrityHash) {
        return {
          verified: false,
          totalRecords: logs.length,
          chainedRecords: chainedCount,
          unchainedRecords: legacyUnchainedCount,
          legacyUnchainedRecords: legacyUnchainedCount,
          legacyRecordIds,
          checkpointVerified: false,
          brokenAtRecordId: log.id,
          failureReason: `Tamper detected at record ${log.id}: recomputed SHA-256 hash does not match stored integrityHash.`,
          headHash: expectedPrevHash,
          checkedAt: new Date().toISOString(),
        };
      }

      expectedPrevHash = log.integrityHash!;
      lastChainedRecordId = log.id;
    }

    // Verify against the independent HMAC-signed trusted chain head checkpoint (.cmms_audit_checkpoint.json)
    const cpResult = db.readAuditCheckpoint();
    if (cpResult.exists) {
      if (!cpResult.validHmac) {
        return {
          verified: false,
          totalRecords: logs.length,
          chainedRecords: chainedCount,
          unchainedRecords: legacyUnchainedCount,
          legacyUnchainedRecords: legacyUnchainedCount,
          legacyRecordIds,
          checkpointVerified: false,
          brokenAtRecordId: lastChainedRecordId,
          failureReason: cpResult.error || 'Independent audit checkpoint HMAC signature verification failed.',
          headHash: expectedPrevHash,
          checkedAt: new Date().toISOString(),
        };
      }

      const cp = cpResult.checkpoint!;
      if (cp.chainedRecordsCount > chainedCount || cp.totalRecordsCount > logs.length) {
        return {
          verified: false,
          totalRecords: logs.length,
          chainedRecords: chainedCount,
          unchainedRecords: legacyUnchainedCount,
          legacyUnchainedRecords: legacyUnchainedCount,
          legacyRecordIds,
          checkpointVerified: false,
          brokenAtRecordId: cp.lastRecordId,
          failureReason: `Audit history truncation/deletion detected: checkpoint recorded ${cp.totalRecordsCount} total (${cp.chainedRecordsCount} chained) records ending at ${cp.lastRecordId}, but store currently has ${logs.length} total (${chainedCount} chained) records.`,
          headHash: expectedPrevHash,
          checkedAt: new Date().toISOString(),
        };
      }

      if (cp.chainedRecordsCount === chainedCount && cp.headHash !== expectedPrevHash) {
        return {
          verified: false,
          totalRecords: logs.length,
          chainedRecords: chainedCount,
          unchainedRecords: legacyUnchainedCount,
          legacyUnchainedRecords: legacyUnchainedCount,
          legacyRecordIds,
          checkpointVerified: false,
          brokenAtRecordId: lastChainedRecordId,
          failureReason: `Chain head mismatch against trusted checkpoint anchor: expected headHash ${cp.headHash.slice(0, 12)}..., found ${expectedPrevHash.slice(0, 12)}...`,
          headHash: expectedPrevHash,
          checkedAt: new Date().toISOString(),
        };
      }
    }

    return {
      verified: true,
      totalRecords: logs.length,
      chainedRecords: chainedCount,
      unchainedRecords: legacyUnchainedCount,
      legacyUnchainedRecords: legacyUnchainedCount,
      legacyRecordIds,
      checkpointVerified: true,
      headHash: expectedPrevHash,
      checkedAt: new Date().toISOString(),
    };
  }
}

export const securityAuditService = new SecurityAuditService();
