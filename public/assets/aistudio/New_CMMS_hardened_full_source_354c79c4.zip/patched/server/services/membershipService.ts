import { db, PermissionDeniedLog } from '../db';
import { supabase, isSupabaseConfigured } from '../../src/utils/supabase';

/**
 * Returns canonical variations of a ministry or group ID (e.g. min-1, min-01, min-001)
 */
export function getMinistryIdVariations(id: string): string[] {
  if (!id) return [];
  const clean = id.trim();
  const variations = new Set<string>([clean, clean.toLowerCase()]);

  const match = clean.match(/^min-(\d+)$/i);
  if (match) {
    const num = parseInt(match[1], 10);
    variations.add(`min-${num}`);
    variations.add(`min-${String(num).padStart(2, '0')}`);
    variations.add(`min-${String(num).padStart(3, '0')}`);
  }
  return Array.from(variations);
}

/**
 * Authoritatively resolves a user's member ID by checking member records and system users
 */
export function resolveMemberId(userId: string, email?: string, state?: any): string | null {
  const currentState = state || db.getState();
  if (userId && userId.startsWith('mem-')) {
    return userId;
  }

  // Check system user memberId link
  if (currentState.systemUsers) {
    const sysUser = currentState.systemUsers.find(
      (u: any) => u.id === userId || (email && u.email?.toLowerCase() === email.toLowerCase())
    );
    if (sysUser && (sysUser as any).memberId) {
      return (sysUser as any).memberId;
    }
  }

  // Check member records by id or email
  if (currentState.members) {
    const member = currentState.members.find(
      (m: any) => m.id === userId || (email && m.email?.toLowerCase() === email.toLowerCase())
    );
    if (member) {
      return member.id;
    }
  }

  return null;
}

/**
 * Checks if a user is an enrolled member or assigned leader of a ministry.
 * Checks the database (dedicated join table and relational lookups), not client claims.
 * SYSTEM_ADMIN, MANAGER, PASTOR retain tenant/branch oversight access.
 */
export async function isMemberOfMinistry(
  userId: string,
  ministryId: string,
  role?: string,
  email?: string
): Promise<boolean> {
  if (!userId || !ministryId) return false;

  // 1. Administrative oversight access
  const normRole = (role || '').toUpperCase();
  if (normRole === 'SYSTEM_ADMIN' || normRole === 'MANAGER' || normRole === 'PASTOR') {
    return true;
  }

  const variations = getMinistryIdVariations(ministryId);
  const state = db.getState();
  const memberId = resolveMemberId(userId, email, state);

  // 2. Check dedicated join table (db.getState().ministryMembers)
  const joinMembers = state.ministryMembers || [];
  const joinMatch = joinMembers.some((jm) => {
    if (jm.status !== 'Active') return false;
    const ministryMatch = variations.includes(jm.ministryId);
    if (!ministryMatch) return false;
    return (
      jm.userId === userId ||
      (memberId && jm.userId === memberId) ||
      (email && jm.userEmail?.toLowerCase() === email.toLowerCase())
    );
  });
  if (joinMatch) return true;

  // 3. Check Ministry leadership & memberIds array
  const ministry = state.ministries?.find((m) => variations.includes(m.id));
  if (ministry) {
    if (
      (memberId && ministry.directorMemberId === memberId) ||
      (memberId && ministry.coordinatorMemberId === memberId) ||
      (memberId && ministry.leaderMemberId === memberId) ||
      (memberId && ministry.memberIds?.includes(memberId)) ||
      ministry.memberIds?.includes(userId)
    ) {
      return true;
    }
  }

  // 4. Check Member record (ministriesJoinedNow)
  if (memberId) {
    const member = state.members?.find((m) => m.id === memberId);
    if (member && member.ministriesJoinedNow?.some((mid) => variations.includes(mid))) {
      return true;
    }
  }

  // 5. Check Supabase ministry_members table if configured
  if (isSupabaseConfigured) {
    try {
      for (const vId of variations) {
        const query = supabase
          .from('ministry_members')
          .select('id, status, role')
          .eq('ministry_id', vId)
          .eq('status', 'Active');

        if (memberId) {
          query.or(`user_id.eq.${userId},user_id.eq.${memberId}`);
        } else {
          query.eq('user_id', userId);
        }

        const { data, error } = await query.limit(1);
        if (!error && data && data.length > 0) {
          return true;
        }
      }
    } catch {
      // Supabase query error fallback
    }
  }

  return false;
}

/**
 * Checks if a user is the assigned leader of a ministry.
 */
export async function isLeaderOfMinistry(
  userId: string,
  ministryId: string,
  role?: string,
  email?: string
): Promise<boolean> {
  if (!userId || !ministryId) return false;

  const normRole = (role || '').toUpperCase();
  if (normRole === 'SYSTEM_ADMIN' || normRole === 'MANAGER' || normRole === 'PASTOR') {
    return true;
  }

  if (normRole !== 'MINISTRY_LEADER') {
    return false;
  }

  const variations = getMinistryIdVariations(ministryId);
  const state = db.getState();
  const memberId = resolveMemberId(userId, email, state);

  // 1. Check dedicated join table for Leader or CoLeader role
  const joinMembers = state.ministryMembers || [];
  const joinLeader = joinMembers.some((jm) => {
    if (jm.status !== 'Active') return false;
    if (jm.role !== 'Leader' && jm.role !== 'CoLeader') return false;
    const ministryMatch = variations.includes(jm.ministryId);
    if (!ministryMatch) return false;
    return (
      jm.userId === userId ||
      (memberId && jm.userId === memberId) ||
      (email && jm.userEmail?.toLowerCase() === email.toLowerCase())
    );
  });
  if (joinLeader) return true;

  // 2. Check Ministry leadership
  const ministry = state.ministries?.find((m) => variations.includes(m.id));
  if (ministry) {
    if (
      (memberId && ministry.directorMemberId === memberId) ||
      (memberId && ministry.coordinatorMemberId === memberId) ||
      (memberId && ministry.leaderMemberId === memberId)
    ) {
      return true;
    }
  }

  return false;
}

/**
 * Authoritatively verifies whether a user is an active member of a group.
 */
export async function isMemberOfGroup(
  userId: string,
  groupId: string,
  role?: string,
  email?: string
): Promise<boolean> {
  if (!userId || !groupId) return false;

  const normRole = (role || '').toUpperCase();
  if (normRole === 'SYSTEM_ADMIN' || normRole === 'MANAGER' || normRole === 'PASTOR') {
    return true;
  }

  // If group ID represents a ministry
  const isMin = groupId.toLowerCase().startsWith('min-') || getMinistryIdVariations(groupId).length > 1;
  if (isMin) {
    return isMemberOfMinistry(userId, groupId, role, email);
  }

  const state = db.getState();
  const memberId = resolveMemberId(userId, email, state);

  // Check bibleStudyGroupId on member
  if (memberId) {
    const member = state.members?.find((m) => m.id === memberId);
    if (member && member.bibleStudyGroupId === groupId) {
      return true;
    }
  }

  // Fallback to ministry check
  return isMemberOfMinistry(userId, groupId, role, email);
}

/**
 * Authoritatively verifies whether a user is the assigned leader of a group.
 */
export async function isLeaderOfGroup(
  userId: string,
  groupId: string,
  role?: string,
  email?: string
): Promise<boolean> {
  if (!userId || !groupId) return false;

  const normRole = (role || '').toUpperCase();
  if (normRole === 'SYSTEM_ADMIN' || normRole === 'MANAGER' || normRole === 'PASTOR') {
    return true;
  }

  if (normRole !== 'MINISTRY_LEADER') {
    return false;
  }

  return isLeaderOfMinistry(userId, groupId, role, email);
}

/**
 * Records a permission denied attempt to both security audit log and structured denial logs.
 */
export function logPermissionDenied(entry: Omit<PermissionDeniedLog, 'id' | 'timestamp'>): PermissionDeniedLog {
  return db.logPermissionDenied(entry);
}

/**
 * Extracts ministry or group ID from video room identifiers or explicit parameter.
 */
export function extractMinistryOrGroupIdFromVideoRoom(roomId: string, explicitMinistryId?: string): string | null {
  if (explicitMinistryId && explicitMinistryId.trim()) {
    return explicitMinistryId.trim();
  }
  if (!roomId) return null;

  // 1. room-{ministryId}-tenant...
  const roomTenantMatch = roomId.match(/^room-([a-zA-Z0-9_-]+)-tenant/i);
  if (roomTenantMatch) return roomTenantMatch[1];

  // 2. conf-{groupId}-{timestamp}
  const confMatch = roomId.match(/^conf-([a-zA-Z0-9_-]+)-\d+$/i);
  if (confMatch) return confMatch[1];

  // 3. room-{groupId} or video-room-{groupId}
  const genericMatch = roomId.match(/^(?:room|video-room)-([a-zA-Z0-9_-]+)$/i);
  if (genericMatch) return genericMatch[1];

  // 4. If roomId contains min-XXX
  const minMatch = roomId.match(/(min-\d+)/i);
  if (minMatch) return minMatch[1];

  return null;
}
