import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { db } from '../db';
import { query as pgQuery, isPgConfigured as isPostgresReady } from '../pg';
import {
  authenticateToken,
  AuthenticatedRequest,
  isSameTenant,
  isSameCampus,
} from '../../src/security/authorization';
import { normalizeUserRole } from '../../src/utils/rbac';
import {
  RegistrationInvitationRecord,
  RegistrationExpirationPreset,
  RegistrationInvitationStatus,
  UserRole,
} from '../../src/types';
import { smsService } from '../services/smsService';
import { emailService } from '../services/emailService';
import { communicationLogService } from '../services/communicationLogService';

const router = Router();

/**
 * Ensure PostgreSQL table `registration_invitations` exists when PostgreSQL is connected
 */
let pgTableEnsured = false;
async function ensurePgTable() {
  if (pgTableEnsured || !isPostgresReady()) return;
  try {
    await pgQuery(`
      CREATE TABLE IF NOT EXISTS registration_invitations (
        id TEXT PRIMARY KEY,
        token TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        tenant_id TEXT NOT NULL,
        church_name TEXT NOT NULL,
        branch_id TEXT NOT NULL,
        branch_name TEXT NOT NULL,
        ministry_id TEXT,
        ministry_name TEXT,
        default_role TEXT NOT NULL DEFAULT 'REGULAR_MEMBER',
        requires_approval BOOLEAN NOT NULL DEFAULT true,
        single_use BOOLEAN NOT NULL DEFAULT false,
        max_uses INTEGER,
        uses_count INTEGER NOT NULL DEFAULT 0,
        expiration_preset TEXT NOT NULL DEFAULT '30d',
        expires_at TIMESTAMPTZ,
        status TEXT NOT NULL DEFAULT 'active',
        created_by TEXT NOT NULL,
        created_by_name TEXT NOT NULL,
        created_by_email TEXT NOT NULL,
        created_by_role TEXT NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        revoked_at TIMESTAMPTZ,
        revoked_by TEXT,
        revoked_reason TEXT,
        last_used_at TIMESTAMPTZ,
        usage_history JSONB NOT NULL DEFAULT '[]'::jsonb
      );
      CREATE INDEX IF NOT EXISTS idx_reg_invitations_token ON registration_invitations(token);
      CREATE INDEX IF NOT EXISTS idx_reg_invitations_tenant ON registration_invitations(tenant_id);
    `);
    pgTableEnsured = true;
  } catch (err) {
    console.warn('[RegistrationLinks] Postgres table init notice:', err);
  }
}

/**
 * Generates a cryptographically secure, URL-safe unique registration token
 */
export function generateCryptographicRegistrationToken(): string {
  const randomBytes = crypto.randomBytes(24).toString('base64url');
  return `gci_${randomBytes}`;
}

/**
 * Computes effective status of an invitation based on current time & usage count
 */
export function evaluateInvitationStatus(inv: RegistrationInvitationRecord): RegistrationInvitationStatus {
  if (inv.status === 'revoked') return 'revoked';
  if (inv.singleUse && inv.usesCount >= 1) return 'used';
  if (inv.maxUses !== null && inv.maxUses !== undefined && inv.maxUses > 0 && inv.usesCount >= inv.maxUses) {
    return 'used';
  }
  if (inv.expiresAt) {
    const expTime = new Date(inv.expiresAt).getTime();
    if (!Number.isNaN(expTime) && Date.now() > expTime) {
      return 'expired';
    }
  }
  return inv.status === 'used' || inv.status === 'expired' ? inv.status : 'active';
}

/**
 * Resolves the authoritative public origin URL for generating real registration links
 */
export function resolvePublicOrigin(req: Request, clientOrigin?: string): string {
  // 1. Check explicit client origin if it's a valid http/https origin
  if (clientOrigin && typeof clientOrigin === 'string') {
    const clean = clientOrigin.trim().replace(/\/+$/, '');
    if (clean.startsWith('https://') || clean.startsWith('http://')) {
      return clean;
    }
  }
  // 2. Check environment variables (APP_URL, VITE_APP_URL, VERCEL_PROJECT_PRODUCTION_URL, VERCEL_URL)
  const envUrl = (
    process.env.APP_URL ||
    process.env.PUBLIC_APP_URL ||
    process.env.VITE_APP_URL ||
    (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : '') ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : '') ||
    ''
  ).trim().replace(/\/+$/, '');

  // 3. Derive from request headers (x-forwarded-proto + x-forwarded-host or host)
  const protoHeader = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
  const proto = protoHeader.split(',')[0].trim() || 'https';
  const hostHeader = (req.headers['x-forwarded-host'] as string) || req.headers.host || '';
  const host = hostHeader.split(',')[0].trim();

  if (host && !host.includes('localhost') && !host.startsWith('127.0.0.1')) {
    return `${proto}://${host}`;
  }

  if (envUrl && !envUrl.includes('localhost')) {
    return envUrl;
  }

  if (host) {
    return `${proto}://${host}`;
  }

  return envUrl || 'https://gracecathedral.org';
}

/**
 * Checks if authenticated user is authorized to manage registration links
 */
function canManageRegistrationLinks(user: NonNullable<AuthenticatedRequest['user']>): boolean {
  const role = normalizeUserRole(user.role);
  const allRoles = Array.isArray(user.roles) ? user.roles.map((r) => normalizeUserRole(r)) : [role];
  if (
    allRoles.includes('SYSTEM_ADMIN') ||
    allRoles.includes('MANAGER') ||
    allRoles.includes('PASTOR') ||
    allRoles.includes('MINISTRY_LEADER')
  ) {
    return true;
  }
  const perms = Array.isArray(user.permissions) ? user.permissions : [];
  return (
    perms.includes('members.create') ||
    perms.includes('workflows.manage') ||
    perms.includes('communications.manage')
  );
}

/**
 * Sync invitation record to PostgreSQL if available
 */
async function syncInvitationToPostgres(inv: RegistrationInvitationRecord): Promise<void> {
  if (!isPostgresReady()) return;
  try {
    await ensurePgTable();
    await pgQuery(
      `INSERT INTO registration_invitations (
        id, token, title, description, tenant_id, church_name, branch_id, branch_name,
        ministry_id, ministry_name, default_role, requires_approval, single_use, max_uses,
        uses_count, expiration_preset, expires_at, status, created_by, created_by_name,
        created_by_email, created_by_role, created_at, updated_at, revoked_at, revoked_by,
        revoked_reason, last_used_at, usage_history
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8,
        $9, $10, $11, $12, $13, $14,
        $15, $16, $17, $18, $19, $20,
        $21, $22, $23, $24, $25, $26,
        $27, $28, $29::jsonb
      )
      ON CONFLICT (token) DO UPDATE SET
        title = EXCLUDED.title,
        description = EXCLUDED.description,
        branch_id = EXCLUDED.branch_id,
        branch_name = EXCLUDED.branch_name,
        ministry_id = EXCLUDED.ministry_id,
        ministry_name = EXCLUDED.ministry_name,
        default_role = EXCLUDED.default_role,
        requires_approval = EXCLUDED.requires_approval,
        single_use = EXCLUDED.single_use,
        max_uses = EXCLUDED.max_uses,
        uses_count = EXCLUDED.uses_count,
        expiration_preset = EXCLUDED.expiration_preset,
        expires_at = EXCLUDED.expires_at,
        status = EXCLUDED.status,
        updated_at = EXCLUDED.updated_at,
        revoked_at = EXCLUDED.revoked_at,
        revoked_by = EXCLUDED.revoked_by,
        revoked_reason = EXCLUDED.revoked_reason,
        last_used_at = EXCLUDED.last_used_at,
        usage_history = EXCLUDED.usage_history`,
      [
        inv.id,
        inv.token,
        inv.title,
        inv.description || null,
        inv.tenantId,
        inv.churchName,
        inv.branchId,
        inv.branchName,
        inv.ministryId || null,
        inv.ministryName || null,
        inv.defaultRole,
        inv.requiresApproval,
        inv.singleUse,
        inv.maxUses,
        inv.usesCount,
        inv.expirationPreset,
        inv.expiresAt,
        inv.status,
        inv.createdBy,
        inv.createdByName,
        inv.createdByEmail,
        inv.createdByRole,
        inv.createdAt,
        inv.updatedAt,
        inv.revokedAt || null,
        inv.revokedBy || null,
        inv.revokedReason || null,
        inv.lastUsedAt || null,
        JSON.stringify(inv.usageHistory || []),
      ]
    );
  } catch (err) {
    console.warn('[RegistrationLinks] Postgres sync warning:', err);
  }
}

/**
 * Helper to ensure at least one active default registration invitation exists for the church/branch
 */
function ensureActiveDefaultInvitation(
  user: NonNullable<AuthenticatedRequest['user']>,
  requestedBranchId?: string
): RegistrationInvitationRecord {
  const state = db.getState();
  if (!Array.isArray(state.registrationInvitations)) {
    state.registrationInvitations = [];
  }

  // Refresh statuses
  let changed = false;
  for (const inv of state.registrationInvitations) {
    const computed = evaluateInvitationStatus(inv);
    if (inv.status !== computed) {
      inv.status = computed;
      inv.updatedAt = new Date().toISOString();
      changed = true;
    }
  }

  const targetBranchId = requestedBranchId || (user.branchIds.includes('*') ? 'all' : user.branchId || 'br-1');
  const existingActive = state.registrationInvitations.find(
    (inv) =>
      inv.status === 'active' &&
      isSameTenant(inv.tenantId, user.tenantId) &&
      (targetBranchId === 'all' || inv.branchId === targetBranchId || inv.branchId === 'all')
  );

  if (existingActive) {
    if (changed) db.persist();
    return existingActive;
  }

  const branchObj = (state.branches || []).find((b) => isSameCampus(b.id, targetBranchId));
  const branchName =
    targetBranchId === 'all'
      ? 'All Campuses (Applicant Selects Branch)'
      : branchObj?.name || user.branchName || 'Headquarters Campus';
  const churchName =
    state.branding?.systemName || state.branding?.churchName || 'Grace Cathedral International';

  const now = new Date();
  const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days default

  const newInv: RegistrationInvitationRecord = {
    id: `reg-inv-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    token: generateCryptographicRegistrationToken(),
    title:
      targetBranchId === 'all'
        ? 'Official Church Membership Registration Link'
        : `${branchName} – Membership Registration Link`,
    description:
      'Public digital membership & fellowship onboarding invitation for new members and families.',
    tenantId: user.tenantId || 'tenant-grace-main',
    churchName,
    branchId: targetBranchId,
    branchName,
    defaultRole: 'REGULAR_MEMBER',
    requiresApproval: true,
    singleUse: false,
    maxUses: null,
    usesCount: 0,
    expirationPreset: '30d',
    expiresAt,
    status: 'active',
    createdBy: user.id,
    createdByName: user.name || user.email,
    createdByEmail: user.email,
    createdByRole: normalizeUserRole(user.role),
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    usageHistory: [],
  };

  state.registrationInvitations.unshift(newInv);
  db.persist();
  syncInvitationToPostgres(newInv).catch(() => {});

  return newInv;
}

// ============================================================================
// PUBLIC ENDPOINT: Validate Registration Token (No Auth Required)
// GET /api/registration-links/validate/:token (and /verify/:token alias)
// ============================================================================
router.get(['/validate/:token', '/verify/:token'], async (req: Request, res: Response) => {
  try {
    const rawToken = String(req.params.token || '').trim();
    if (!rawToken) {
      return res.status(400).json({
        valid: false,
        status: 'invalid',
        reason: 'Registration token is missing.',
      });
    }

    const state = db.getState();
    if (!Array.isArray(state.registrationInvitations)) {
      state.registrationInvitations = [];
    }

    let invitation = state.registrationInvitations.find((inv) => inv.token === rawToken);

    // Also check PostgreSQL if not in memory
    if (!invitation && isPostgresReady()) {
      try {
        await ensurePgTable();
        const pgRes = await pgQuery('SELECT * FROM registration_invitations WHERE token = $1 LIMIT 1', [rawToken]);
        if (pgRes.rows.length > 0) {
          const r = pgRes.rows[0];
          invitation = {
            id: r.id,
            token: r.token,
            title: r.title,
            description: r.description || undefined,
            tenantId: r.tenant_id,
            churchName: r.church_name,
            branchId: r.branch_id,
            branchName: r.branch_name,
            ministryId: r.ministry_id || undefined,
            ministryName: r.ministry_name || undefined,
            defaultRole: (r.default_role as UserRole) || 'REGULAR_MEMBER',
            requiresApproval: Boolean(r.requires_approval),
            singleUse: Boolean(r.single_use),
            maxUses: r.max_uses !== null ? Number(r.max_uses) : null,
            usesCount: Number(r.uses_count || 0),
            expirationPreset: (r.expiration_preset as RegistrationExpirationPreset) || '30d',
            expiresAt: r.expires_at ? new Date(r.expires_at).toISOString() : null,
            status: (r.status as RegistrationInvitationStatus) || 'active',
            createdBy: r.created_by,
            createdByName: r.created_by_name,
            createdByEmail: r.created_by_email,
            createdByRole: (r.created_by_role as UserRole) || 'SYSTEM_ADMIN',
            createdAt: new Date(r.created_at).toISOString(),
            updatedAt: new Date(r.updated_at).toISOString(),
            revokedAt: r.revoked_at ? new Date(r.revoked_at).toISOString() : null,
            revokedBy: r.revoked_by || null,
            revokedReason: r.revoked_reason || null,
            lastUsedAt: r.last_used_at ? new Date(r.last_used_at).toISOString() : null,
            usageHistory: Array.isArray(r.usage_history) ? r.usage_history : [],
          };
          state.registrationInvitations.unshift(invitation);
          db.persist();
        }
      } catch (pgErr) {
        console.warn('[RegistrationLinks] Postgres token lookup warning:', pgErr);
      }
    }

    if (!invitation) {
      return res.status(404).json({
        valid: false,
        status: 'not_found',
        reason: 'This registration invitation link was not found or is invalid. Please request a fresh registration link from your church administrator.',
      });
    }

    const effectiveStatus = evaluateInvitationStatus(invitation);
    if (invitation.status !== effectiveStatus) {
      invitation.status = effectiveStatus;
      invitation.updatedAt = new Date().toISOString();
      db.persist();
      syncInvitationToPostgres(invitation).catch(() => {});
    }

    const branches = (state.branches || []).map((b) => ({
      id: b.id,
      name: b.name,
      city: b.city,
      address: b.address,
    }));

    const ministries = (state.ministries || []).map((m) => ({
      id: m.id,
      name: m.name,
      category: m.category,
      branchId: m.branchId,
    }));

    if (effectiveStatus === 'revoked') {
      return res.status(410).json({
        valid: false,
        status: 'revoked',
        reason:
          invitation.revokedReason ||
          'This registration invitation link has been revoked by a church administrator and is no longer accepting submissions.',
        churchName: invitation.churchName,
        branchName: invitation.branchName,
        revokedAt: invitation.revokedAt,
      });
    }

    if (effectiveStatus === 'expired') {
      return res.status(410).json({
        valid: false,
        status: 'expired',
        reason: `This registration invitation link expired on ${
          invitation.expiresAt ? new Date(invitation.expiresAt).toLocaleString() : 'its scheduled expiration date'
        }. Please contact your church office for an updated registration link.`,
        churchName: invitation.churchName,
        branchName: invitation.branchName,
        expiresAt: invitation.expiresAt,
      });
    }

    if (effectiveStatus === 'used') {
      return res.status(410).json({
        valid: false,
        status: 'used',
        reason: invitation.singleUse
          ? 'This single-use registration invitation link has already been used to submit a membership application.'
          : `This registration invitation link has reached its maximum limit of ${invitation.maxUses} registrations.`,
        churchName: invitation.churchName,
        branchName: invitation.branchName,
        usesCount: invitation.usesCount,
        maxUses: invitation.maxUses,
      });
    }

    return res.json({
      valid: true,
      status: 'active',
      invitation: {
        id: invitation.id,
        token: invitation.token,
        title: invitation.title,
        description: invitation.description,
        churchName: invitation.churchName,
        branchId: invitation.branchId,
        branchName: invitation.branchName,
        ministryId: invitation.ministryId,
        ministryName: invitation.ministryName,
        defaultRole: invitation.defaultRole,
        requiresApproval: invitation.requiresApproval,
        singleUse: invitation.singleUse,
        maxUses: invitation.maxUses,
        usesCount: invitation.usesCount,
        expiresAt: invitation.expiresAt,
        createdByName: invitation.createdByName,
        createdAt: invitation.createdAt,
      },
      branches,
      ministries,
      branding: {
        churchName: state.branding?.churchName || invitation.churchName,
        systemName: state.branding?.systemName || invitation.churchName,
        churchMotto: state.branding?.churchMotto || '',
        churchLogoUrl: state.branding?.churchLogoUrl || '',
        primaryColorHex: state.branding?.primaryColorHex || '#7c3aed',
      },
    });
  } catch (err: any) {
    console.error('[RegistrationLinks] Error validating token:', err);
    return res.status(500).json({
      valid: false,
      status: 'error',
      reason: 'An unexpected error occurred while validating the registration link.',
    });
  }
});

// ============================================================================
// AUTHENTICATED ENDPOINTS: Create, List, Regenerate, Revoke, Share Invitations
// ============================================================================
router.use(authenticateToken);

/**
 * GET /api/registration-links
 * Lists all registration invitations for the authenticated user's church/campus scope
 * and ensures at least one active invitation exists so the modal immediately has a real link.
 */
router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (!canManageRegistrationLinks(user)) {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to manage or share member registration links.',
      });
    }

    const requestedBranchId = req.query.branchId ? String(req.query.branchId) : undefined;
    const activeDefault = ensureActiveDefaultInvitation(user, requestedBranchId);

    const state = db.getState();
    let list = [...(state.registrationInvitations || [])].filter((inv) =>
      isSameTenant(inv.tenantId, user.tenantId)
    );

    if (!user.branchIds.includes('*')) {
      list = list.filter(
        (inv) =>
          inv.branchId === 'all' ||
          user.branchIds.some((b) => isSameCampus(b, inv.branchId)) ||
          isSameCampus(user.branchId, inv.branchId)
      );
    }

    const origin = resolvePublicOrigin(req, req.query.origin ? String(req.query.origin) : undefined);

    const enriched = list.map((inv) => {
      const effectiveStatus = evaluateInvitationStatus(inv);
      if (inv.status !== effectiveStatus) {
        inv.status = effectiveStatus;
      }
      return {
        ...inv,
        registrationUrl: `${origin}/register/${inv.token}`,
      };
    });

    return res.json({
      success: true,
      origin,
      activeInvitation: {
        ...activeDefault,
        registrationUrl: `${origin}/register/${activeDefault.token}`,
      },
      invitations: enriched,
    });
  } catch (err: any) {
    console.error('[RegistrationLinks] GET error:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to load registration invitations.',
    });
  }
});

/**
 * POST /api/registration-links
 * Generates and stores a new cryptographically secure registration invitation link in the database.
 */
router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (!canManageRegistrationLinks(user)) {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to generate member registration links.',
      });
    }

    const {
      title,
      description,
      branchId: rawBranchId,
      ministryId,
      defaultRole = 'REGULAR_MEMBER',
      requiresApproval = true,
      singleUse = false,
      maxUses = null,
      expirationPreset = '30d',
      customExpiresAt,
      revokePreviousActive = false,
      clientOrigin,
    } = req.body || {};

    const state = db.getState();
    if (!Array.isArray(state.registrationInvitations)) {
      state.registrationInvitations = [];
    }

    // Enforce campus scope for non-global users
    let targetBranchId = rawBranchId ? String(rawBranchId) : user.branchIds.includes('*') ? 'all' : user.branchId;
    if (!user.branchIds.includes('*') && targetBranchId !== 'all') {
      const allowed =
        user.branchIds.some((b) => isSameCampus(b, targetBranchId)) ||
        isSameCampus(user.branchId, targetBranchId);
      if (!allowed) {
        targetBranchId = user.branchId;
      }
    }

    const branchObj = (state.branches || []).find((b) => isSameCampus(b.id, targetBranchId));
    const branchName =
      targetBranchId === 'all'
        ? 'All Campuses (Applicant Selects Branch)'
        : branchObj?.name || user.branchName || 'Headquarters Campus';

    const ministryObj = ministryId
      ? (state.ministries || []).find((m) => m.id === String(ministryId))
      : undefined;

    const churchName =
      state.branding?.systemName || state.branding?.churchName || 'Grace Cathedral International';

    // Compute expiration timestamp
    const now = new Date();
    let expiresAt: string | null = null;
    const preset = (expirationPreset as RegistrationExpirationPreset) || '30d';

    if (preset === '24h') {
      expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();
    } else if (preset === '7d') {
      expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString();
    } else if (preset === '30d') {
      expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
    } else if (preset === 'custom' && customExpiresAt) {
      const parsedDate = new Date(customExpiresAt);
      if (Number.isNaN(parsedDate.getTime()) || parsedDate.getTime() <= now.getTime()) {
        return res.status(400).json({
          success: false,
          error: 'Custom expiration date must be a valid future date and time.',
        });
      }
      expiresAt = parsedDate.toISOString();
    } else if (preset === 'never') {
      expiresAt = null;
    } else {
      expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
    }

    // Optionally revoke previous active invitations for the same branch
    if (revokePreviousActive) {
      for (const existing of state.registrationInvitations) {
        if (
          existing.status === 'active' &&
          isSameTenant(existing.tenantId, user.tenantId) &&
          existing.branchId === targetBranchId
        ) {
          existing.status = 'revoked';
          existing.revokedAt = now.toISOString();
          existing.revokedBy = user.name || user.email;
          existing.revokedReason = 'Superseded by newly regenerated registration link';
          existing.updatedAt = now.toISOString();
          syncInvitationToPostgres(existing).catch(() => {});
        }
      }
    }

    // Restrict defaultRole to safe member roles unless SYSTEM_ADMIN
    const normalizedDefaultRole = normalizeUserRole(defaultRole);
    const safeRole: UserRole =
      normalizeUserRole(user.role) === 'SYSTEM_ADMIN'
        ? normalizedDefaultRole
        : 'REGULAR_MEMBER';

    const parsedMaxUses = singleUse
      ? 1
      : maxUses !== null && maxUses !== undefined && String(maxUses).trim() !== ''
      ? Math.max(1, parseInt(String(maxUses), 10) || 1)
      : null;

    const newInvitation: RegistrationInvitationRecord = {
      id: `reg-inv-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      token: generateCryptographicRegistrationToken(),
      title:
        (title && String(title).trim()) ||
        (targetBranchId === 'all'
          ? 'Official Church Membership Registration Link'
          : `${branchName} – Membership Registration Link`),
      description:
        description !== undefined
          ? String(description).trim()
          : 'Public digital membership & fellowship onboarding invitation for new members and families.',
      tenantId: user.tenantId || 'tenant-grace-main',
      churchName,
      branchId: targetBranchId,
      branchName,
      ministryId: ministryObj?.id || undefined,
      ministryName: ministryObj?.name || undefined,
      defaultRole: safeRole,
      requiresApproval: Boolean(requiresApproval),
      singleUse: Boolean(singleUse),
      maxUses: parsedMaxUses,
      usesCount: 0,
      expirationPreset: preset,
      expiresAt,
      status: 'active',
      createdBy: user.id,
      createdByName: user.name || user.email,
      createdByEmail: user.email,
      createdByRole: normalizeUserRole(user.role),
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
      usageHistory: [],
    };

    state.registrationInvitations.unshift(newInvitation);
    db.persist();
    await syncInvitationToPostgres(newInvitation);

    const origin = resolvePublicOrigin(req, clientOrigin);
    const registrationUrl = `${origin}/register/${newInvitation.token}`;

    db.addAuditLog(
      revokePreviousActive ? 'Regenerated Registration Link' : 'Created Registration Link',
      'Membership & Onboarding',
      `${user.name} (${user.role}) generated registration link "${newInvitation.title}" for ${branchName} [Token: ${newInvitation.token.slice(0, 12)}..., Single-Use: ${newInvitation.singleUse}, Expires: ${newInvitation.expiresAt ? new Date(newInvitation.expiresAt).toLocaleDateString() : 'Never'}]`,
      user.email
    );

    return res.status(201).json({
      success: true,
      message: revokePreviousActive
        ? 'Previous link revoked and new registration link generated.'
        : 'New registration invitation link generated and saved.',
      invitation: {
        ...newInvitation,
        registrationUrl,
      },
    });
  } catch (err: any) {
    console.error('[RegistrationLinks] POST error:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to generate registration link.',
    });
  }
});

/**
 * POST /api/registration-links/:id/revoke
 * Revokes an existing registration invitation link immediately so it can no longer be used.
 */
router.post('/:id/revoke', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (!canManageRegistrationLinks(user)) {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to revoke registration links.',
      });
    }

    const { id } = req.params;
    const { reason } = req.body || {};

    const state = db.getState();
    const list = state.registrationInvitations || [];
    const target = list.find((inv) => inv.id === id || inv.token === id);

    if (!target) {
      return res.status(404).json({
        success: false,
        error: 'Registration invitation link not found.',
      });
    }

    if (!isSameTenant(target.tenantId, user.tenantId)) {
      return res.status(403).json({
        success: false,
        error: 'Cross-tenant access denied.',
      });
    }

    const nowIso = new Date().toISOString();
    target.status = 'revoked';
    target.revokedAt = nowIso;
    target.revokedBy = user.name || user.email;
    target.revokedReason =
      (reason && String(reason).trim()) || `Revoked by ${user.name || user.email}`;
    target.updatedAt = nowIso;

    db.persist();
    await syncInvitationToPostgres(target);

    db.addAuditLog(
      'Revoked Registration Link',
      'Membership & Onboarding',
      `${user.name} (${user.role}) revoked registration link "${target.title}" (${target.token.slice(0, 12)}...). Reason: ${target.revokedReason}`,
      user.email
    );

    return res.json({
      success: true,
      message: 'Registration invitation link has been revoked.',
      invitation: target,
    });
  } catch (err: any) {
    console.error('[RegistrationLinks] Revoke error:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to revoke registration link.',
    });
  }
});

/**
 * POST /api/registration-links/:id/share-dispatch
 * Dispatches the real registration link via Email or SMS using the church's communication services
 * and logs the activity in both Audit Logs and Communication Logs.
 */
router.post('/:id/share-dispatch', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (!canManageRegistrationLinks(user)) {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to dispatch registration invitations.',
      });
    }

    const { id } = req.params;
    const {
      channel, // 'EMAIL' | 'SMS'
      recipient,
      recipientName,
      customMessage,
      clientOrigin,
    } = req.body || {};

    const state = db.getState();
    const invitation = (state.registrationInvitations || []).find(
      (inv) => inv.id === id || inv.token === id
    );

    if (!invitation) {
      return res.status(404).json({
        success: false,
        error: 'Registration invitation link not found.',
      });
    }

    const effectiveStatus = evaluateInvitationStatus(invitation);
    if (effectiveStatus !== 'active') {
      return res.status(400).json({
        success: false,
        error: `Cannot share a ${effectiveStatus} registration link. Please generate or select an active link.`,
      });
    }

    const origin = resolvePublicOrigin(req, clientOrigin);
    const registrationUrl = `${origin}/register/${invitation.token}`;
    const expiryText = invitation.expiresAt
      ? `This invitation link is valid until ${new Date(invitation.expiresAt).toLocaleDateString()}.`
      : 'This invitation link is currently active.';

    const defaultBody = `Greetings${recipientName ? ` ${recipientName}` : ''} from ${invitation.churchName}!\n\nYou are warmly invited to complete your official church membership registration for ${invitation.branchName}.\n\nComplete your registration online here:\n${registrationUrl}\n\n${expiryText}`;
    const bodyText = (customMessage && String(customMessage).trim())
      ? `${String(customMessage).trim()}\n\nRegistration Link: ${registrationUrl}`
      : defaultBody;

    const upperChannel = String(channel || '').toUpperCase();

    if (upperChannel === 'EMAIL') {
      const subject = `Official Membership Registration Invitation – ${invitation.churchName}`;
      const result = await emailService.sendEmail({
        recipient: String(recipient || '').trim(),
        subject,
        message: bodyText,
      });

      const logRecord = communicationLogService.recordLog({
        tenantId: user.tenantId,
        branchId: invitation.branchId === 'all' ? user.branchId : invitation.branchId,
        channel: 'EMAIL',
        recipient: result.recipient || String(recipient || '').trim(),
        recipientName: recipientName || null,
        subject,
        message: bodyText,
        status: result.status,
        provider: result.provider,
        providerMessageId: result.providerMessageId,
        errorMessage: result.errorMessage,
        triggerType: 'Registration Link Invitation',
        sentAt: result.sentAt,
        deliveredAt: result.deliveredAt,
        createdBy: user.id,
        createdByName: user.name,
      });

      db.addAuditLog(
        'Shared Registration Link via Email',
        'Membership & Onboarding',
        `Sent registration invitation link (${invitation.token.slice(0, 10)}...) to ${recipient} [${result.status}]`,
        user.email
      );

      return res.json({
        success: result.success,
        status: result.status,
        provider: result.provider,
        message: result.success
          ? `Registration invitation emailed to ${result.recipient}.`
          : result.errorMessage || 'Email dispatch failed (check SMTP/API configuration).',
        log: logRecord,
        registrationUrl,
      });
    } else if (upperChannel === 'SMS') {
      const smsResult = await smsService.sendSms({
        recipient: String(recipient || '').trim(),
        message: bodyText,
      });

      const logRecord = communicationLogService.recordLog({
        tenantId: user.tenantId,
        branchId: invitation.branchId === 'all' ? user.branchId : invitation.branchId,
        channel: 'SMS',
        recipient: smsResult.recipient || String(recipient || '').trim(),
        recipientName: recipientName || null,
        subject: 'Registration Link SMS',
        message: bodyText,
        status: smsResult.status,
        provider: smsResult.provider,
        providerMessageId: smsResult.providerMessageId,
        errorMessage: smsResult.errorMessage,
        triggerType: 'Registration Link Invitation',
        sentAt: smsResult.sentAt,
        deliveredAt: smsResult.deliveredAt,
        createdBy: user.id,
        createdByName: user.name,
      });

      db.addAuditLog(
        'Shared Registration Link via SMS',
        'Membership & Onboarding',
        `Sent registration invitation link (${invitation.token.slice(0, 10)}...) via SMS to ${recipient} [${smsResult.status}]`,
        user.email
      );

      return res.json({
        success: smsResult.success,
        status: smsResult.status,
        provider: smsResult.provider,
        message: smsResult.success
          ? `Registration invitation SMS sent to ${smsResult.recipient}.`
          : smsResult.errorMessage || 'SMS dispatch failed.',
        log: logRecord,
        registrationUrl,
      });
    } else {
      return res.status(400).json({
        success: false,
        error: 'Unsupported dispatch channel. Use EMAIL or SMS.',
      });
    }
  } catch (err: any) {
    console.error('[RegistrationLinks] Share dispatch error:', err);
    return res.status(500).json({
      success: false,
      error: err?.message || 'Failed to dispatch registration link.',
    });
  }
});

export default router;
