import { Router, Request, Response } from 'express';
import { db } from '../db';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
  verifyResourceAccess,
} from '../../src/security/authorization';
import {
  BibleNote,
  BibleHighlight,
  BibleBookmark,
  BibleReadingHistoryEntry,
  BibleReadingPlanProgress,
  BibleReaderSettings,
  DEFAULT_BIBLE_READER_SETTINGS,
  BibleMessage,
  BibleMessageRecipient,
  BibleRecipientType,
  BibleMessageStatus,
  BibleNotification,
  UserRole,
} from '../../src/types';
import { BIBLE_CANON, BibleBookInfo } from '../../src/data/bibleCanon';
import { BibleChapterData, BibleVerseItem, BIBLE_READING_PLANS } from '../../src/data/bibleData';

const router = Router();

// ============================================================================
// SERVER-SIDE YOUVERSION & BIBLE ENGINE PROXY
// The YouVersion API App Key is kept strictly server-side.
// Frontend components NEVER receive or send the secret key directly.
// ============================================================================

const envBaseUrl = (process.env.YOUVERSION_API_BASE_URL || '').trim();
const YOUVERSION_API_BASE_URL = envBaseUrl.startsWith('http://') || envBaseUrl.startsWith('https://')
  ? envBaseUrl.replace(/\/$/, '')
  : 'https://api.youversion.com/v1';

const YVP_APP_KEY = process.env.YOUVERSION_APP_KEY || process.env.YVP_APP_KEY || 'novf8BhKM5gCBDl057OUf4mEGfx7V6NqZLsRsBEptu28gil1';

const YVP_HEADERS = {
  'x-yvp-app-key': YVP_APP_KEY,
  'X-YouVersion-App-Key': YVP_APP_KEY,
  'Accept': 'application/json',
};

// ============================================================================
// IN-MEMORY STALE CACHE & HEALTH TELEMETRY
// ============================================================================
const memoryCache = {
  bibles: null as { data: any[]; timestamp: number } | null,
  allBibles: null as { data: any[]; timestamp: number } | null,
  bibleDetails: new Map<string, { data: any; timestamp: number }>(),
  books: new Map<string, { data: any[]; timestamp: number }>(),
  passages: new Map<string, { data: any; timestamp: number }>(),
};

let healthCache: {
  status: 'healthy' | 'degraded' | 'down';
  message: string;
  latencyMs: number;
  checkedAt: string;
  upstreamUrl: string;
  cached: boolean;
  staleCacheAvailable: boolean;
} | null = null;
let lastHealthCheckTime = 0;
const HEALTH_CACHE_TTL_MS = 30 * 1000;
const ALL_BIBLES_CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes cache for full paginated catalog

/**
 * Fetches the COMPLETE list of Bibles from YouVersion `/v1/bibles` handling all pagination via `next_page_token`.
 */
async function fetchAllYouVersionBiblesPaginated(languageRanges: string[] = ['*'], forceRefresh = false): Promise<any[]> {
  const isFullCatalog = languageRanges.includes('*');
  if (
    isFullCatalog &&
    !forceRefresh &&
    memoryCache.allBibles &&
    memoryCache.allBibles.data.length > 0 &&
    Date.now() - memoryCache.allBibles.timestamp < ALL_BIBLES_CACHE_TTL_MS
  ) {
    return memoryCache.allBibles.data;
  }

  const allBibles: any[] = [];
  const seenIds = new Set<number>();
  let nextPageToken: string | null = null;
  let pageSafetyCounter = 0;

  try {
    do {
      pageSafetyCounter++;
      const url = new URL(`${YOUVERSION_API_BASE_URL}/bibles`);
      for (const lang of languageRanges) {
        url.searchParams.append('language_ranges[]', lang);
      }
      if (nextPageToken) {
        url.searchParams.set('page_token', nextPageToken);
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(url.toString(), {
        headers: YVP_HEADERS,
        signal: controller.signal,
      }).finally(() => clearTimeout(timeout));

      if (!res.ok) {
        break;
      }

      const payload = (await res.json()) as { data?: any[]; next_page_token?: string | null };
      const pageItems = Array.isArray(payload.data) ? payload.data : [];
      for (const b of pageItems) {
        if (b && typeof b.id === 'number' && !seenIds.has(b.id)) {
          seenIds.add(b.id);
          allBibles.push(b);
        }
      }

      nextPageToken = payload.next_page_token || null;
    } while (nextPageToken && pageSafetyCounter < 25);
  } catch (err) {
    console.warn('[BibleRoute] Paginated /v1/bibles fetch interrupted:', err);
  }

  if (allBibles.length > 0) {
    if (isFullCatalog) {
      memoryCache.allBibles = { data: allBibles, timestamp: Date.now() };
    }
    memoryCache.bibles = { data: allBibles, timestamp: Date.now() };
    return allBibles;
  }

  if (isFullCatalog && memoryCache.allBibles && memoryCache.allBibles.data.length > 0) {
    return memoryCache.allBibles.data;
  }
  if (memoryCache.bibles && memoryCache.bibles.data.length > 0) {
    return memoryCache.bibles.data;
  }

  return DEFAULT_YOUVERSION_BIBLES;
}

/**
 * Excludes the 3 specific Amharic Bible versions requested by the user:
 *  1. አማ2000 — የአማርኛ መጽሐፍ ቅዱስ (ሰማንያ አሃዱ)
 *  2. አማ54 — መጽሐፍ ቅዱስ (የብሉይና የሃዲስ ኪዳን መጻሕፍት)
 *  3. መቅካእኤ — መጽሐፍ ቅዱስ-(ካቶሊካዊት እትም - ኤማሁስ)
 */
const EXCLUDED_AMHARIC_VERSIONS_PATTERNS = [
  'አማ2000',
  'የአማርኛ መጽሐፍ ቅዱስ (ሰማንያ አሃዱ)',
  'ሰማንያ አሃዱ',
  'አማ54',
  'መጽሐፍ ቅዱስ (የብሉይና የሃዲስ ኪዳን መጻሕፍት)',
  'የብሉይና የሃዲስ ኪዳን መጻሕፍት',
  'መቅካእኤ',
  'መጽሐፍ ቅዱስ-(ካቶሊካዊት እትም - ኤማሁስ)',
  'ካቶሊካዊት እትም - ኤማሁስ',
  'ካቶሊካዊት እትም',
  'ኤማሁስ',
];

function isAmharicBible(b: any): boolean {
  const lang = String(b?.language_tag || b?.language?.tag || '').toLowerCase().trim();
  return lang === 'am' || lang === 'amh' || lang.startsWith('am-');
}

function isOromifaBible(b: any): boolean {
  const lang = String(b?.language_tag || b?.language?.tag || '').toLowerCase().trim();
  if (['om', 'orm', 'gaz', 'hae', 'gax', 'orc'].includes(lang) || lang.startsWith('om-')) {
    return true;
  }
  const abbr = String(b?.abbreviation || '').toLowerCase().trim();
  const locAbbr = String(b?.localized_abbreviation || '').toLowerCase().trim();
  const title = String(b?.title || '').toLowerCase().trim();
  const locTitle = String(b?.localized_title || '').toLowerCase().trim();
  const combined = `${abbr} | ${locAbbr} | ${title} | ${locTitle}`;
  return (
    combined.includes('orom') ||
    combined.includes('afaan orom') ||
    combined.includes('kitaaba woyyicha') ||
    combined.includes('kitaaba qulqulluu') ||
    combined.includes('macaafa qulqulluu')
  );
}

function isExcludedAmharicBible(b: any): boolean {
  const abbr = String(b?.abbreviation || '').trim();
  const locAbbr = String(b?.localized_abbreviation || '').trim();
  const title = String(b?.title || '').trim();
  const locTitle = String(b?.localized_title || '').trim();
  const combined = `${abbr} | ${locAbbr} | ${title} | ${locTitle}`;

  return EXCLUDED_AMHARIC_VERSIONS_PATTERNS.some((pattern) => combined.includes(pattern));
}

/**
 * Matches the requested translations against the live YouVersion API metadata:
 * - Amharic: All Amharic language (`am`) Bibles returned by YouVersion `/v1/bibles`
 *   EXCEPT:
 *     1. አማ2000 የአማርኛ መጽሐፍ ቅዱስ (ሰማንያ አሃዱ)
 *     2. አማ54 መጽሐፍ ቅዱስ (የብሉይና የሃዲስ ኪዳን መጻሕፍት)
 *     3. መቅካእኤ መጽሐፍ ቅዱስ-(ካቶሊካዊት እትም - ኤማሁስ)
 * - English:
 *     1. English Standard Version (ESV)
 *     2. New International Version (NIV)
 *     3. Christian Standard Bible (CSB)
 *     4. New Living Translation (NLT)
 *
 * Strictly checks ID, abbreviation, localized_abbreviation, title, localized_title, and language_tag.
 * Never invents Bible IDs or mismatches non-English/non-Amharic versions.
 */
function matchRequestedTranslationsAgainstCatalog(catalog: any[]) {
  const findExactEnglishMatch = (slotKey: string) => {
    switch (slotKey) {
      case 'ESV':
        return catalog.find((b) => {
          const lang = String(b.language_tag || b.language?.tag || '').toLowerCase();
          if (!lang.startsWith('en')) return false;
          const abbr = String(b.abbreviation || '').toUpperCase();
          const locAbbr = String(b.localized_abbreviation || '').toUpperCase();
          const title = String(b.title || '').toLowerCase();
          const locTitle = String(b.localized_title || '').toLowerCase();
          return (
            abbr === 'ESV' ||
            locAbbr === 'ESV' ||
            title.includes('english standard version') ||
            locTitle.includes('english standard version')
          );
        });
      case 'NIV':
        return catalog.find((b) => {
          const lang = String(b.language_tag || b.language?.tag || '').toLowerCase();
          if (!lang.startsWith('en')) return false;
          const abbr = String(b.abbreviation || '').toUpperCase();
          const locAbbr = String(b.localized_abbreviation || '').toUpperCase();
          const title = String(b.title || '').toLowerCase();
          const locTitle = String(b.localized_title || '').toLowerCase();
          return (
            locAbbr === 'NIV' ||
            abbr === 'NIV' ||
            abbr === 'NIV11' ||
            title === 'new international version 2011' ||
            locTitle === 'new international version'
          );
        });
      case 'CSB':
        return catalog.find((b) => {
          const lang = String(b.language_tag || b.language?.tag || '').toLowerCase();
          if (!lang.startsWith('en')) return false;
          const abbr = String(b.abbreviation || '').toUpperCase();
          const locAbbr = String(b.localized_abbreviation || '').toUpperCase();
          const title = String(b.title || '').toLowerCase();
          const locTitle = String(b.localized_title || '').toLowerCase();
          return (
            abbr === 'CSB' ||
            locAbbr === 'CSB' ||
            abbr === 'CSB17' ||
            title.includes('christian standard bible') ||
            locTitle.includes('christian standard bible')
          );
        });
      case 'NLT':
        return catalog.find((b) => {
          const lang = String(b.language_tag || b.language?.tag || '').toLowerCase();
          if (!lang.startsWith('en')) return false;
          const abbr = String(b.abbreviation || '').toUpperCase();
          const locAbbr = String(b.localized_abbreviation || '').toUpperCase();
          const title = String(b.title || '').toLowerCase();
          const locTitle = String(b.localized_title || '').toLowerCase();
          return (
            abbr === 'NLT' ||
            locAbbr === 'NLT' ||
            title.includes('new living translation') ||
            locTitle.includes('new living translation')
          );
        });
      default:
        return undefined;
    }
  };

  // 1. Dynamically collect all allowed Amharic Bibles from the YouVersion catalog (excluding the 3 specified versions)
  const allowedAmharicBibles = catalog.filter(
    (b) => isAmharicBible(b) && !isExcludedAmharicBible(b)
  );
  const excludedAmharicBibles = catalog.filter(
    (b) => isAmharicBible(b) && isExcludedAmharicBible(b)
  );

  const amharicSlots =
    allowedAmharicBibles.length > 0
      ? allowedAmharicBibles.map((matched, idx) => {
          const abbr = matched.localized_abbreviation || matched.abbreviation || 'AM';
          const title = matched.localized_title || matched.title || 'Amharic Bible';
          const isNasv1260 = Number(matched.id) === 1260 || String(matched.abbreviation || '').toUpperCase() === 'NASV';
          return {
            slotKey: isNasv1260 ? 'AM05' : `AM_${matched.id}`,
            requestedAbbreviation: isNasv1260 ? 'አማ05 / NASV' : abbr,
            requestedTitle: isNasv1260 ? `${title} (${matched.title})` : title,
            youversionBibleId: Number(matched.id),
            matchedAbbreviation: matched.abbreviation || null,
            matchedLocalizedAbbreviation: matched.localized_abbreviation || null,
            matchedTitle: matched.title || null,
            matchedLocalizedTitle: matched.localized_title || null,
            languageTag: matched.language_tag || 'am',
            enabled: true,
            displayOrder: idx + 1,
            isDefault: false,
            isFeatured: idx === 0,
            availableInApi: true,
            matchStatus: 'matched' as const,
            matchNotes: `Verified Amharic Bible from YouVersion /v1/bibles (ID: ${matched.id}, abbr: "${matched.abbreviation}", localized_abbr: "${matched.localized_abbreviation}", title: "${matched.title}", localized_title: "${matched.localized_title}"). Excluded Amharic versions filtered out (${excludedAmharicBibles.length} excluded).`,
          };
        })
      : [
          {
            slotKey: 'AM05',
            requestedAbbreviation: 'አማ05 / NASV',
            requestedTitle: 'አዲሱ መደበኛ ትርጒም (New Amharic Standard Version)',
            youversionBibleId: null,
            matchedAbbreviation: null,
            matchedLocalizedAbbreviation: null,
            matchedTitle: null,
            matchedLocalizedTitle: null,
            languageTag: 'am',
            enabled: true,
            displayOrder: 1,
            isDefault: false,
            isFeatured: true,
            availableInApi: false,
            matchStatus: 'unmatched_license_restricted' as const,
            matchNotes: `No non-excluded Amharic Bibles returned in current YouVersion /v1/bibles catalog.`,
          },
        ];

  // 2. Match the 4 requested English versions: ESV, NIV, CSB, NLT
  const englishSpecs = [
    {
      slotKey: 'ESV',
      requestedAbbreviation: 'ESV',
      requestedTitle: 'English Standard Version (ESV)',
      expectedLanguage: 'en',
      displayOrder: amharicSlots.length + 1,
      isDefault: false,
      isFeatured: false,
    },
    {
      slotKey: 'NIV',
      requestedAbbreviation: 'NIV',
      requestedTitle: 'New International Version (NIV)',
      expectedLanguage: 'en',
      displayOrder: amharicSlots.length + 2,
      isDefault: true,
      isFeatured: true,
    },
    {
      slotKey: 'CSB',
      requestedAbbreviation: 'CSB',
      requestedTitle: 'Christian Standard Bible (CSB)',
      expectedLanguage: 'en',
      displayOrder: amharicSlots.length + 3,
      isDefault: false,
      isFeatured: false,
    },
    {
      slotKey: 'NLT',
      requestedAbbreviation: 'NLT',
      requestedTitle: 'New Living Translation (NLT)',
      expectedLanguage: 'en',
      displayOrder: amharicSlots.length + 4,
      isDefault: false,
      isFeatured: false,
    },
  ];

  const englishSlots = englishSpecs.map((spec) => {
    const matched = findExactEnglishMatch(spec.slotKey);
    return {
      slotKey: spec.slotKey,
      requestedAbbreviation: spec.requestedAbbreviation,
      requestedTitle: spec.requestedTitle,
      youversionBibleId: matched ? Number(matched.id) : null,
      matchedAbbreviation: matched ? (matched.abbreviation || null) : null,
      matchedLocalizedAbbreviation: matched ? (matched.localized_abbreviation || null) : null,
      matchedTitle: matched ? (matched.title || null) : null,
      matchedLocalizedTitle: matched ? (matched.localized_title || null) : null,
      languageTag: matched ? (matched.language_tag || spec.expectedLanguage) : spec.expectedLanguage,
      enabled: true,
      displayOrder: spec.displayOrder,
      isDefault: spec.isDefault,
      isFeatured: spec.isFeatured,
      availableInApi: Boolean(matched),
      matchStatus: matched ? ('matched' as const) : ('unmatched_license_restricted' as const),
      matchNotes: matched
        ? `Verified from YouVersion /v1/bibles (ID: ${matched.id}, abbr: "${matched.abbreviation}", localized_abbr: "${matched.localized_abbreviation}", title: "${matched.title}", localized_title: "${matched.localized_title}")`
        : `Not returned in current YouVersion API key /v1/bibles catalog (${catalog.length} Bibles checked).`,
    };
  });

  return [...amharicSlots, ...englishSlots].filter((s) => s.youversionBibleId !== null);
}

// Supported Bible translations metadata - Verified from live YouVersion Platform API
const SUPPORTED_VERSIONS = [
  {
    id: 'amharic-nasv',
    youversionBibleId: 1260,
    name: 'New Amharic Standard Version 2024',
    localizedTitle: 'አዲሱ መደበኛ ትርጒም',
    language: 'Amharic',
    languageCode: 'am',
    abbreviation: 'NASV',
    localizedAbbreviation: 'NASV',
    hasAudio: true,
    enabled: true,
    displayOrder: 1,
    isDefault: false,
    isFeatured: true,
  },
  {
    id: 'niv',
    youversionBibleId: 111,
    name: 'New International Version 2011',
    localizedTitle: 'New International Version',
    language: 'English',
    languageCode: 'en',
    abbreviation: 'NIV11',
    localizedAbbreviation: 'NIV',
    hasAudio: true,
    enabled: true,
    displayOrder: 2,
    isDefault: true,
    isFeatured: true,
  },
];

const DEFAULT_YOUVERSION_BIBLES = [
  {
    id: 1260,
    abbreviation: 'NASV',
    localized_abbreviation: 'NASV',
    title: 'New Amharic Standard Version 2024',
    localized_title: 'አዲሱ መደበኛ ትርጒም',
    language_tag: 'am',
    language: { tag: 'am', name: 'Amharic' },
    audio: true,
    cached: true,
  },
  {
    id: 111,
    abbreviation: 'NIV11',
    localized_abbreviation: 'NIV',
    title: 'New International Version 2011',
    localized_title: 'New International Version',
    language_tag: 'en',
    language: { tag: 'en', name: 'English' },
    audio: true,
    cached: true,
  },
];

function getOrInitBibleTranslationAdminConfig(catalog: any[]) {
  const state = db.getState();
  const matchedSlots = matchRequestedTranslationsAgainstCatalog(catalog);

  // Collect verified YouVersion IDs from the matched Amharic + English slots
  const verifiedIdsFromSlots = Array.from(
    new Set(
      matchedSlots
        .filter((s) => s.youversionBibleId !== null)
        .map((s) => Number(s.youversionBibleId))
    )
  );

  if (!state.bibleTranslationConfig) {
    state.bibleTranslationConfig = {
      enabledBibleIds: verifiedIdsFromSlots.length > 0 ? verifiedIdsFromSlots : [1260, 111],
      defaultBibleId: 111,
      featuredBibleId: 1260,
      displayOrderMap: {
        1260: 1,
        111: 2,
      },
      enabledSlotKeys: matchedSlots.map((s) => s.slotKey),
      excludedAmharicPatterns: EXCLUDED_AMHARIC_VERSIONS_PATTERNS,
      configuredSlots: matchedSlots,
      updatedAt: new Date().toISOString(),
      updatedBy: 'System',
    };
  } else {
    // Always refresh the API match metadata against the latest catalog without losing admin enable/disable state
    const prevSlots = state.bibleTranslationConfig.configuredSlots || [];
    state.bibleTranslationConfig.excludedAmharicPatterns = EXCLUDED_AMHARIC_VERSIONS_PATTERNS;
    state.bibleTranslationConfig.configuredSlots = matchedSlots.map((freshSlot) => {
      const existingSlot = prevSlots.find((p: any) => p.slotKey === freshSlot.slotKey);
      return existingSlot
        ? {
            ...freshSlot,
            enabled: existingSlot.enabled !== undefined ? existingSlot.enabled : freshSlot.enabled,
            displayOrder: existingSlot.displayOrder !== undefined ? existingSlot.displayOrder : freshSlot.displayOrder,
            isDefault: existingSlot.isDefault !== undefined ? existingSlot.isDefault : freshSlot.isDefault,
            isFeatured: existingSlot.isFeatured !== undefined ? existingSlot.isFeatured : freshSlot.isFeatured,
          }
        : freshSlot;
    });

    // Ensure any newly matched Amharic/English slot IDs are included in enabledBibleIds unless explicitly disabled
    const currentEnabled = new Set<number>((state.bibleTranslationConfig.enabledBibleIds || [1260, 111]).map(Number));
    for (const s of state.bibleTranslationConfig.configuredSlots) {
      if (s.enabled && s.youversionBibleId) {
        currentEnabled.add(Number(s.youversionBibleId));
      }
    }
    state.bibleTranslationConfig.enabledBibleIds = Array.from(currentEnabled);
  }

  return state.bibleTranslationConfig;
}

/**
 * Builds the normal CMMS user Bible selector list based on:
 * - All Amharic Bibles EXCEPT (አማ2000 የአማርኛ መጽሐፍ ቅዱስ (ሰማንያ አሃዱ)፣ አማ54 መጽሐፍ ቅዱስ (የብሉይና የሃዲስ ኪዳን መጻሕፍት)፣ መቅካእኤ መጽሐፍ ቅዱስ-(ካቶሊካዊት እትም - ኤማሁስ))
 * - English versions: ESV, NIV, CSB, NLT
 * - Plus any additional translations explicitly enabled by System Admin (unless in the excluded Amharic list).
 */
function buildUserVisibleBibles(catalog: any[], adminConfig: any): any[] {
  const slots: any[] = adminConfig.configuredSlots || [];
  const enabledBibleIds: number[] = Array.isArray(adminConfig.enabledBibleIds)
    ? adminConfig.enabledBibleIds.map(Number)
    : [1260, 111];
  const displayOrderMap: Record<string, number> = adminConfig.displayOrderMap || {};

  const result: any[] = [];
  const addedBibleIds = new Set<number>();

  // 1. Add enabled items from the configured Amharic & English slots that have a real verified YouVersion ID
  for (const slot of slots) {
    if (!slot.enabled || !slot.youversionBibleId) continue;
    if (!enabledBibleIds.includes(Number(slot.youversionBibleId))) continue;

    const rawBible = catalog.find((b) => Number(b.id) === Number(slot.youversionBibleId));
    if (!rawBible) continue;

    // Never display any of the 3 excluded Amharic versions
    if (isAmharicBible(rawBible) && isExcludedAmharicBible(rawBible)) continue;
    if (addedBibleIds.has(Number(rawBible.id))) continue;

    const isAmharic = isAmharicBible(rawBible);
    const displayAbbr = rawBible.localized_abbreviation || rawBible.abbreviation;
    const displayTitle = rawBible.localized_title || rawBible.title;

    const userDisplayLabel = isAmharic
      ? rawBible.localized_title && rawBible.title && rawBible.localized_title !== rawBible.title
        ? `${displayTitle} (${rawBible.title}) — ${displayAbbr}`
        : `${displayAbbr} — ${displayTitle}`
      : `${ rawBible.title?.includes('(') ? rawBible.title : `${displayTitle} (${displayAbbr})` }`;

    result.push({
      ...rawBible,
      id: Number(rawBible.id),
      slotKey: slot.slotKey,
      userDisplayLabel,
      enabled: true,
      displayOrder: slot.displayOrder ?? displayOrderMap[rawBible.id] ?? 10,
      isDefault: Number(adminConfig.defaultBibleId) === Number(rawBible.id),
      isFeatured: Number(adminConfig.featuredBibleId) === Number(rawBible.id),
    });
    addedBibleIds.add(Number(rawBible.id));
  }

  // 2. Also include any additional YouVersion translations explicitly enabled by System Admin (except excluded Amharic versions)
  for (const bibleId of enabledBibleIds) {
    if (addedBibleIds.has(Number(bibleId))) continue;

    const rawBible = catalog.find((b) => Number(b.id) === Number(bibleId));
    if (rawBible) {
      if (isAmharicBible(rawBible) && isExcludedAmharicBible(rawBible)) continue;

      const displayAbbr = rawBible.localized_abbreviation || rawBible.abbreviation;
      const displayTitle = rawBible.localized_title || rawBible.title;
      result.push({
        ...rawBible,
        id: Number(rawBible.id),
        slotKey: `CUSTOM_${rawBible.id}`,
        userDisplayLabel: `${displayAbbr} — ${displayTitle}`,
        enabled: true,
        displayOrder: displayOrderMap[rawBible.id] ?? 50,
        isDefault: Number(adminConfig.defaultBibleId) === Number(rawBible.id),
        isFeatured: Number(adminConfig.featuredBibleId) === Number(rawBible.id),
      });
      addedBibleIds.add(Number(rawBible.id));
    }
  }

  result.sort((a, b) => (a.displayOrder ?? 99) - (b.displayOrder ?? 99));
  return result;
}

const DEFAULT_YOUVERSION_BOOKS = BIBLE_CANON.map((b) => ({
  id: b.id,
  name: b.nameEnglish,
  name_long: `${b.nameEnglish} (${b.nameAmharic})`,
  testament: b.testament,
  category: b.category,
  category_amharic: b.categoryAmharic,
  chapters_count: b.chaptersCount,
  chapters: Array.from({ length: b.chaptersCount }, (_, i) => ({
    id: `${b.id}.${i + 1}`,
    number: String(i + 1),
    canonical: true,
  })),
}));

// Helper to extract authenticated user id strictly from verified token or request context
function getAuthenticatedUserId(req: Request): string {
  const user = (req as AuthenticatedRequest).user;
  const headerUserId = (req.headers['x-user-id'] as string) || '';
  return user?.id || (user as any)?.userId || (user as any)?.memberId || headerUserId || '';
}

// ----------------------------------------------------------------------------
// 1. PUBLIC YOUVERSION PLATFORM API PROXY ENDPOINTS & HEALTH
// ----------------------------------------------------------------------------

/**
 * GET /api/bible/health
 * Lightweight server-side health check for the YouVersion API (cached for 30s to avoid hammering)
 */
router.get('/health', async (req: Request, res: Response) => {
  const forceRefresh = req.query.fresh === 'true';
  const now = Date.now();

  if (!forceRefresh && healthCache && now - lastHealthCheckTime < HEALTH_CACHE_TTL_MS) {
    return res.json({ ...healthCache, cached: true });
  }

  const startTime = Date.now();
  let status: 'healthy' | 'degraded' | 'down' = 'healthy';
  let message = 'YouVersion Platform API is operational';
  let latencyMs = 0;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);

    const testUrl = `${YOUVERSION_API_BASE_URL}/bibles?language_ranges[]=en`;
    const checkRes = await fetch(testUrl, {
      headers: YVP_HEADERS,
      signal: controller.signal,
    }).finally(() => clearTimeout(timeout));

    latencyMs = Date.now() - startTime;

    if (checkRes.ok) {
      status = 'healthy';
      message = `YouVersion Platform API connected successfully (${latencyMs}ms)`;
    } else if (checkRes.status === 401 || checkRes.status === 403) {
      status = 'degraded';
      message = `YouVersion API authentication error HTTP ${checkRes.status} (stale fallback cache active)`;
    } else {
      status = 'degraded';
      message = `YouVersion API returned HTTP ${checkRes.status} (stale-while-error active)`;
    }
  } catch (err: any) {
    latencyMs = Date.now() - startTime;
    status = 'down';
    message = err.name === 'AbortError'
      ? `YouVersion API timed out after 3500ms (stale fallback cache active)`
      : `YouVersion API unreachable: ${err.message || 'Network failure'} (stale fallback cache active)`;
  }

  const result = {
    status,
    message,
    latencyMs,
    checkedAt: new Date().toISOString(),
    upstreamUrl: YOUVERSION_API_BASE_URL,
    cached: false,
    staleCacheAvailable: true,
  };

  healthCache = result;
  lastHealthCheckTime = now;

  return res.json(result);
});

/**
 * GET /api/bible/youversion/bibles
 * Retrieves available Bibles from the official YouVersion `/v1/bibles` endpoint handling all pagination (`next_page_token`).
 * By default (`scope=user`), returns only the enabled translations for normal CMMS users.
 * When `scope=all` or `scope=admin`, returns the complete paginated YouVersion translation catalog for System Admin.
 */
router.get('/youversion/bibles', async (req: Request, res: Response) => {
  try {
    const scope = String(req.query.scope || 'user').toLowerCase();
    const forceRefresh = req.query.fresh === 'true';
    const languagesParam = (req.query.languages as string) || '*';
    const langArray = languagesParam
      .split(',')
      .map((l) => l.trim())
      .filter(Boolean);

    // Retrieve the complete paginated list from YouVersion /v1/bibles using next_page_token
    const fullCatalog = await fetchAllYouVersionBiblesPaginated(
      scope === 'all' || scope === 'admin' || languagesParam === '*' ? ['*'] : langArray,
      forceRefresh
    );

    const adminConfig = getOrInitBibleTranslationAdminConfig(fullCatalog);

    if (scope === 'all' || scope === 'admin') {
      const enabledSet = new Set<number>((adminConfig.enabledBibleIds || []).map(Number));
      const enrichedCatalog = fullCatalog.map((b) => ({
        ...b,
        enabled: enabledSet.has(Number(b.id)),
        displayOrder: adminConfig.displayOrderMap?.[b.id] ?? 99,
        isDefault: Number(adminConfig.defaultBibleId) === Number(b.id),
        isFeatured: Number(adminConfig.featuredBibleId) === Number(b.id),
      }));

      return res.json({
        success: true,
        scope: 'admin',
        total: enrichedCatalog.length,
        bibles: enrichedCatalog,
        adminConfig,
      });
    }

    // Normal CMMS user selector: primary configured & enabled translations + "More Options" (Oromifa Bible versions only)
    const userBibles = buildUserVisibleBibles(fullCatalog, adminConfig);
    const primaryIds = new Set<number>(userBibles.map((b) => Number(b.id)));
    const otherBibles = fullCatalog
      .filter((b) => {
        if (primaryIds.has(Number(b.id))) return false;
        if (isAmharicBible(b) && isExcludedAmharicBible(b)) return false;
        return isOromifaBible(b);
      })
      .map((b) => {
        const displayAbbr = b.localized_abbreviation || b.abbreviation;
        const displayTitle = b.localized_title || b.title;
        return {
          ...b,
          id: Number(b.id),
          slotKey: `MORE_${b.id}`,
          userDisplayLabel: `${displayTitle}${b.title && b.localized_title && b.title !== b.localized_title ? ` (${b.title})` : ''} — ${displayAbbr} (Oromiffa)`,
          isMoreOption: true,
        };
      })
      .sort((a, b) =>
        String(a.userDisplayLabel || '').localeCompare(String(b.userDisplayLabel || ''))
      );

    return res.json({
      success: true,
      scope: 'user',
      total: userBibles.length,
      otherTotal: otherBibles.length,
      catalogTotal: fullCatalog.length,
      bibles: userBibles,
      otherBibles,
      configuredSlots: adminConfig.configuredSlots,
      defaultBibleId: adminConfig.defaultBibleId,
      featuredBibleId: adminConfig.featuredBibleId,
    });
  } catch (err: any) {
    console.error('[BibleRoute] Error fetching YouVersion bibles:', err);
    return res.json({
      success: true,
      stale: true,
      total: DEFAULT_YOUVERSION_BIBLES.length,
      bibles: DEFAULT_YOUVERSION_BIBLES,
    });
  }
});

/**
 * GET /api/bible/admin/translations
 * Returns the complete paginated YouVersion Bible catalog (429+ versions) along with
 * the 6 matched slots, enabled/disabled state, default Bible, display order, and featured translation for System Admin.
 */
router.get('/admin/translations', authenticateToken, requirePermission('system.manage'), async (req: Request, res: Response) => {
  try {
    const forceRefresh = req.query.fresh === 'true';
    const fullCatalog = await fetchAllYouVersionBiblesPaginated(['*'], forceRefresh);
    const adminConfig = getOrInitBibleTranslationAdminConfig(fullCatalog);
    const enabledSet = new Set<number>((adminConfig.enabledBibleIds || []).map(Number));

    const completeCatalog = fullCatalog.map((b) => ({
      ...b,
      enabled: enabledSet.has(Number(b.id)),
      displayOrder: adminConfig.displayOrderMap?.[b.id] ?? 99,
      isDefault: Number(adminConfig.defaultBibleId) === Number(b.id),
      isFeatured: Number(adminConfig.featuredBibleId) === Number(b.id),
    }));

    return res.json({
      success: true,
      totalCatalogCount: completeCatalog.length,
      userVisibleBibles: buildUserVisibleBibles(fullCatalog, adminConfig),
      configuredSlots: adminConfig.configuredSlots,
      adminConfig,
      allYouVersionBibles: completeCatalog,
    });
  } catch (err: any) {
    console.error('[BibleRoute] Error loading admin translations:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to retrieve YouVersion translation catalog',
    });
  }
});

/**
 * PUT /api/bible/admin/translations
 * Allows System Admin to enable/disable translations, set Default Bible, Display Order, or Featured Translation
 * without changing the API integration or deleting/modifying any Bible study data.
 */
router.put('/admin/translations', authenticateToken, requirePermission('system.manage'), async (req: Request, res: Response) => {
  try {
    const fullCatalog = await fetchAllYouVersionBiblesPaginated(['*'], false);
    const currentConfig = getOrInitBibleTranslationAdminConfig(fullCatalog);
    const {
      enabledBibleIds,
      defaultBibleId,
      featuredBibleId,
      displayOrderMap,
      slotUpdates,
      toggleBibleId,
      toggleEnabled,
      toggleSlotKey,
    } = req.body || {};

    let updatedEnabledIds: number[] = Array.isArray(enabledBibleIds)
      ? enabledBibleIds.map(Number)
      : [...(currentConfig.enabledBibleIds || [111, 1260]).map(Number)];

    if (typeof toggleBibleId === 'number' || (typeof toggleBibleId === 'string' && toggleBibleId.trim() !== '')) {
      const targetId = Number(toggleBibleId);
      if (!isNaN(targetId)) {
        const shouldEnable = toggleEnabled !== undefined ? Boolean(toggleEnabled) : !updatedEnabledIds.includes(targetId);
        if (shouldEnable && !updatedEnabledIds.includes(targetId)) {
          updatedEnabledIds.push(targetId);
        } else if (!shouldEnable) {
          updatedEnabledIds = updatedEnabledIds.filter((id) => id !== targetId);
        }
      }
    }

    let updatedSlots = [...(currentConfig.configuredSlots || [])];
    if (toggleSlotKey) {
      updatedSlots = updatedSlots.map((slot) =>
        slot.slotKey === toggleSlotKey
          ? { ...slot, enabled: toggleEnabled !== undefined ? Boolean(toggleEnabled) : !slot.enabled }
          : slot
      );
    }

    if (Array.isArray(slotUpdates)) {
      updatedSlots = updatedSlots.map((slot) => {
        const patch = slotUpdates.find((u: any) => u.slotKey === slot.slotKey);
        return patch ? { ...slot, ...patch } : slot;
      });
    }

    const nextConfig = {
      ...currentConfig,
      enabledBibleIds: updatedEnabledIds,
      defaultBibleId: defaultBibleId !== undefined ? Number(defaultBibleId) : currentConfig.defaultBibleId,
      featuredBibleId: featuredBibleId !== undefined ? Number(featuredBibleId) : currentConfig.featuredBibleId,
      displayOrderMap: displayOrderMap !== undefined ? { ...currentConfig.displayOrderMap, ...displayOrderMap } : currentConfig.displayOrderMap,
      configuredSlots: updatedSlots,
      updatedAt: new Date().toISOString(),
      updatedBy: getAuthenticatedUserId(req) || 'SYSTEM_ADMIN',
    };

    const state = db.getState();
    state.bibleTranslationConfig = nextConfig;
    db.persist();

    const enabledSet = new Set<number>(nextConfig.enabledBibleIds.map(Number));
    const completeCatalog = fullCatalog.map((b) => ({
      ...b,
      enabled: enabledSet.has(Number(b.id)),
      displayOrder: nextConfig.displayOrderMap?.[b.id] ?? 99,
      isDefault: Number(nextConfig.defaultBibleId) === Number(b.id),
      isFeatured: Number(nextConfig.featuredBibleId) === Number(b.id),
    }));

    return res.json({
      success: true,
      message: 'Bible translation configuration updated. All existing Bible data and study marks are preserved.',
      adminConfig: nextConfig,
      configuredSlots: nextConfig.configuredSlots,
      userVisibleBibles: buildUserVisibleBibles(fullCatalog, nextConfig),
      allYouVersionBibles: completeCatalog,
    });
  } catch (err: any) {
    console.error('[BibleRoute] Error updating admin translations:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to update Bible translation configuration',
    });
  }
});

/**
 * GET /api/bible/youversion/bibles/:id
 * Fetches specific Bible information by YouVersion ID with stale cache fallback
 */
router.get('/youversion/bibles/:id', async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    const url = `${YOUVERSION_API_BASE_URL}/bibles/${encodeURIComponent(id)}`;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);
      const yvpRes = await fetch(url, { headers: YVP_HEADERS, signal: controller.signal }).finally(() =>
        clearTimeout(timeout)
      );

      if (yvpRes.ok) {
        const data = await yvpRes.json();
        memoryCache.bibleDetails.set(id, { data, timestamp: Date.now() });
        return res.json({ success: true, bible: data });
      }
    } catch (fetchErr) {
      console.warn(`[BibleRoute] YouVersion bible ${id} live fetch failed, serving stale:`, fetchErr);
    }

    // Stale cache
    if (memoryCache.bibleDetails.has(id)) {
      return res.json({ success: true, stale: true, bible: memoryCache.bibleDetails.get(id)!.data });
    }

    // Match supported version fallback
    const matched = SUPPORTED_VERSIONS.find((v) => String(v.youversionBibleId) === String(id)) || SUPPORTED_VERSIONS[0];
    return res.json({
      success: true,
      stale: true,
      bible: {
        id: matched.youversionBibleId,
        abbreviation: matched.abbreviation,
        title: matched.name,
        language: { tag: matched.languageCode, name: matched.language },
      },
    });
  } catch (err: any) {
    return res.json({
      success: true,
      stale: true,
      bible: {
        id: id,
        abbreviation: 'BIBLE',
        title: 'Scripture Translation',
      },
    });
  }
});

/**
 * GET /api/bible/youversion/bibles/:id/books
 * Fetches canonical book list and chapter tree with robust cache-and-serve-stale
 */
router.get('/youversion/bibles/:id/books', async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    const url = `${YOUVERSION_API_BASE_URL}/bibles/${encodeURIComponent(id)}/books`;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);
      const yvpRes = await fetch(url, { headers: YVP_HEADERS, signal: controller.signal }).finally(() =>
        clearTimeout(timeout)
      );

      if (yvpRes.ok) {
        const data = (await yvpRes.json()) as { data?: any[] };
        const books = data.data || [];
        if (books.length > 0) {
          memoryCache.books.set(id, { data: books, timestamp: Date.now() });
        }
        return res.json({ success: true, total: books.length, books });
      }
    } catch (fetchErr) {
      console.warn(`[BibleRoute] YouVersion books live fetch failed for ${id}, using stale:`, fetchErr);
    }

    // Stale memory cache
    if (memoryCache.books.has(id)) {
      const cached = memoryCache.books.get(id)!.data;
      return res.json({ success: true, stale: true, total: cached.length, books: cached });
    }

    // Fallback: 66 Canonical Bible Books with chapter trees
    return res.json({
      success: true,
      stale: true,
      source: 'canonical-static-fallback',
      total: DEFAULT_YOUVERSION_BOOKS.length,
      books: DEFAULT_YOUVERSION_BOOKS,
    });
  } catch (err: any) {
    return res.json({
      success: true,
      stale: true,
      source: 'canonical-static-fallback',
      total: DEFAULT_YOUVERSION_BOOKS.length,
      books: DEFAULT_YOUVERSION_BOOKS,
    });
  }
});

/**
 * GET /api/bible/youversion/bibles/:id/passages/:passageId
 * Fetches live passage content with cache-and-serve-stale and canonical chapter fallback
 */
router.get('/youversion/bibles/:id/passages/:passageId', async (req: Request, res: Response) => {
  const { id, passageId } = req.params;
  const cacheKey = `${id}:${passageId}`;
  try {
    const url = `${YOUVERSION_API_BASE_URL}/bibles/${encodeURIComponent(id)}/passages/${encodeURIComponent(passageId)}`;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);
      const yvpRes = await fetch(url, { headers: YVP_HEADERS, signal: controller.signal }).finally(() =>
        clearTimeout(timeout)
      );

      if (yvpRes.ok) {
        const data = await yvpRes.json();
        memoryCache.passages.set(cacheKey, { data, timestamp: Date.now() });
        return res.json({ success: true, passage: data });
      }
    } catch (fetchErr) {
      console.warn(`[BibleRoute] YouVersion passage live fetch failed for ${cacheKey}, using stale:`, fetchErr);
    }

    // Check memory cache
    if (memoryCache.passages.has(cacheKey)) {
      return res.json({
        success: true,
        stale: true,
        passage: memoryCache.passages.get(cacheKey)!.data,
      });
    }

    // YouVersion content is strictly authoritative - do not substitute local or fake verses
    return res.status(503).json({
      success: false,
      error: 'Bible content temporarily unavailable — YouVersion service could not be reached',
      message: 'Scripture content from YouVersion is temporarily unavailable. Please retry shortly.',
      passageId,
      outage: true,
    });
  } catch (err: any) {
    return res.status(503).json({
      success: false,
      error: 'Bible content temporarily unavailable — YouVersion service could not be reached',
      message: 'Scripture content from YouVersion is temporarily unavailable. Please retry shortly.',
      detail: err.message,
      outage: true,
    });
  }
});

/**
 * GET /api/bible/youversion/verse-of-the-day
 * Fetches the official YouVersion Verse of the Day curriculum
 */
router.get('/youversion/verse-of-the-day', async (req: Request, res: Response) => {
  try {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    const targetDay = req.query.day ? parseInt(String(req.query.day), 10) : dayOfYear;

    const votdRes = await fetch(`${YOUVERSION_API_BASE_URL}/verse_of_the_days`, { headers: YVP_HEADERS });
    let passageId = 'JHN.3.16';

    if (votdRes.ok) {
      const votdJson = (await votdRes.json()) as { data?: { day: number; passage_id: string }[] };
      const match = votdJson.data?.find((d) => d.day === targetDay) || votdJson.data?.[0];
      if (match?.passage_id) {
        passageId = match.passage_id;
      }
    }

    const [amhRes, engRes] = await Promise.allSettled([
      fetch(`${YOUVERSION_API_BASE_URL}/bibles/1260/passages/${encodeURIComponent(passageId)}`, { headers: YVP_HEADERS }),
      fetch(`${YOUVERSION_API_BASE_URL}/bibles/111/passages/${encodeURIComponent(passageId)}`, { headers: YVP_HEADERS }),
    ]);

    let textAmharic = '';
    let textEnglish = '';

    if (amhRes.status === 'fulfilled' && amhRes.value.ok) {
      const j = (await amhRes.value.json()) as { content?: string };
      textAmharic = j.content || '';
    }
    if (engRes.status === 'fulfilled' && engRes.value.ok) {
      const j = (await engRes.value.json()) as { content?: string };
      textEnglish = j.content || '';
    }

    return res.json({
      success: true,
      source: 'youversion-platform-api',
      day: targetDay,
      passageId,
      textAmharic: textAmharic || 'እግዚአብሔር ዓለምን እንዲሁ ወዶአልና አንድያ ልጁን እስኪሰጥ ድረስ፤ በርሱ የሚያምን ሁሉ የዘላለም ሕይወት እንዲኖረው እንጂ እንዳይጠፋ።',
      textEnglish: textEnglish || 'For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.',
    });
  } catch (err: any) {
    return res.json({
      success: true,
      source: 'grace-cathedral-fallback',
      day: 1,
      passageId: 'JHN.3.16',
      textAmharic: 'እግዚአብሔር ዓለምን እንዲሁ ወዶአልና አንድያ ልጁን እስኪሰጥ ድረስ፤ በርሱ የሚያምን ሁሉ የዘላለም ሕይወት እንዲኖረው እንጂ እንዳይጠፋ።',
      textEnglish: 'For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.',
    });
  }
});

// ----------------------------------------------------------------------------
// 2. PUBLIC BIBLE METADATA ENDPOINTS
// ----------------------------------------------------------------------------

/**
 * GET /api/bible/versions
 * Returns the list of supported Bible versions/translations, merging local presets and live YouVersion Bibles
 */
router.get('/versions', async (req: Request, res: Response) => {
  try {
    const scope = String(req.query.scope || 'user').toLowerCase();
    const fullCatalog = await fetchAllYouVersionBiblesPaginated(['*'], false);
    const adminConfig = getOrInitBibleTranslationAdminConfig(fullCatalog);
    const userBibles = buildUserVisibleBibles(fullCatalog, adminConfig);

    return res.json({
      success: true,
      youversionProxyConfigured: Boolean(YVP_APP_KEY),
      versions: SUPPORTED_VERSIONS,
      youversionBibles: scope === 'all' || scope === 'admin' ? fullCatalog : userBibles,
      allYouVersionBiblesCount: fullCatalog.length,
      configuredSlots: adminConfig.configuredSlots,
      adminConfig,
    });
  } catch (err: any) {
    return res.json({
      success: true,
      youversionProxyConfigured: Boolean(YVP_APP_KEY),
      versions: SUPPORTED_VERSIONS,
      youversionBibles: DEFAULT_YOUVERSION_BIBLES,
    });
  }
});

/**
 * GET /api/bible/books
 * Returns the 66 canonical Bible books with Amharic & English names, category, and chapter counts
 */
router.get('/books', (req: Request, res: Response) => {
  const { testament, category } = req.query;
  let books = [...BIBLE_CANON];

  if (testament && testament !== 'All') {
    books = books.filter((b) => b.testament.toLowerCase() === String(testament).toLowerCase());
  }

  if (category && category !== 'All') {
    books = books.filter((b) => b.category.toLowerCase() === String(category).toLowerCase());
  }

  return res.json({
    success: true,
    total: books.length,
    books,
  });
});

/**
 * Parses YouVersion HTML passage content (<span class="yv-v" v="16"></span>...)
 * into a Map keyed by actual canonical verse number (number -> { text, isRedLetter }).
 */
function parseYouVersionHtmlToVerseMap(html: string): Map<number, { text: string; isRedLetter: boolean }> {
  const verseMap = new Map<number, { text: string; isRedLetter: boolean }>();
  if (!html || typeof html !== 'string') return verseMap;

  // Strip section headings, titles, verse number labels, and footnote markers
  const cleaned = html
    .replace(/<div class="(?:s\d*|sp|ms\d*|mr|r|d)"[^>]*>[\s\S]*?<\/div>/gi, ' ')
    .replace(/<span class="(?:yv-vlbl|vlbl)"[^>]*>[\s\S]*?<\/span>/gi, '')
    .replace(/<span class="yv-n[^"]*"[^>]*>[\s\S]*?<\/span>/gi, '');

  // Split by YouVersion canonical verse marker <span class="yv-v" v="NUMBER"></span>
  const parts = cleaned.split(/<span[^>]*class="[^"]*yv-v[^"]*"[^>]*v="(\d+)"[^>]*><\/span>/i);

  for (let i = 1; i < parts.length; i += 2) {
    const vNum = parseInt(parts[i], 10);
    const rawSegment = parts[i + 1] || '';
    if (!vNum || isNaN(vNum)) continue;

    const isRedLetter = /class="[^"]*\bwj\b[^"]*"/i.test(rawSegment);
    const text = rawSegment
      .replace(/<\/(?:div|p|li\d*|q\d*)>/gi, ' ')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();

    if (verseMap.has(vNum)) {
      const prev = verseMap.get(vNum)!;
      verseMap.set(vNum, {
        text: `${prev.text} ${text}`.trim(),
        isRedLetter: prev.isRedLetter || isRedLetter,
      });
    } else {
      verseMap.set(vNum, { text, isRedLetter });
    }
  }

  return verseMap;
}

/**
 * GET /api/bible/passage
 * Proxies scripture chapter request with live YouVersion API lookup and canonical verse matching
 */
router.get('/passage', async (req: Request, res: Response) => {
  try {
    const bookParam = String(req.query.book || 'JHN').trim();
    const chapterParam = parseInt(String(req.query.chapter || '1'), 10) || 1;
    const versionParam = String(req.query.version || 'Parallel').trim();

    // Match book in canon
    const book =
      BIBLE_CANON.find(
        (b) =>
          b.id.toUpperCase() === bookParam.toUpperCase() ||
          b.nameEnglish.toLowerCase() === bookParam.toLowerCase() ||
          b.nameAmharic === bookParam
      ) || BIBLE_CANON[0];

    // Determine requested translation Bible ID (default to NIV 111 when Parallel or English)
    const numericVersion = parseInt(versionParam, 10);
    const englishBibleId =
      !isNaN(numericVersion) && numericVersion > 0 && numericVersion !== 1260
        ? numericVersion
        : 111;

    const cacheKey = `${book.id}.${chapterParam}.${englishBibleId}`;

    // 1. Fetch live HTML text strictly from YouVersion Platform API with verse markers
    if (YVP_APP_KEY) {
      try {
        const passageKey = `${book.id}.${chapterParam}`;
        const [amhRes, engRes] = await Promise.allSettled([
          fetch(`${YOUVERSION_API_BASE_URL}/bibles/1260/passages/${encodeURIComponent(passageKey)}?format=html`, { headers: YVP_HEADERS }),
          fetch(`${YOUVERSION_API_BASE_URL}/bibles/${englishBibleId}/passages/${encodeURIComponent(passageKey)}?format=html`, { headers: YVP_HEADERS }),
        ]);

        let amhHtml = '';
        let engHtml = '';

        if (amhRes.status === 'fulfilled' && amhRes.value.ok) {
          const j = (await amhRes.value.json()) as { content?: string };
          amhHtml = j.content || '';
        }
        if (engRes.status === 'fulfilled' && engRes.value.ok) {
          const j = (await engRes.value.json()) as { content?: string };
          engHtml = j.content || '';
        }

        const amhVerseMap = parseYouVersionHtmlToVerseMap(amhHtml);
        const engVerseMap = parseYouVersionHtmlToVerseMap(engHtml);

        // Collect all canonical verse numbers present in either translation and sort ascending
        const verseNumbers = Array.from(
          new Set<number>([...engVerseMap.keys(), ...amhVerseMap.keys()])
        ).sort((a, b) => a - b);

        if (verseNumbers.length > 0) {
          const parsedVerses: BibleVerseItem[] = verseNumbers.map((vNum) => {
            const engEntry = engVerseMap.get(vNum);
            const amhEntry = amhVerseMap.get(vNum);
            const engText = engEntry?.text || '';
            const amhText = amhEntry?.text || '';
            return {
              verseKey: `${book.id}.${chapterParam}.${vNum}`,
              verseNumber: vNum,
              verse: vNum,
              textEnglish: engText,
              english: engText,
              textAmharic: amhText,
              amharic: amhText,
              isRedLetter: Boolean(engEntry?.isRedLetter || amhEntry?.isRedLetter),
              textKJV: `${book.nameEnglish} ${chapterParam}:${vNum}`,
            };
          });

          const chapterData: BibleChapterData = {
            bookId: book.id,
            bookEnglish: book.nameEnglish,
            bookAmharic: book.nameAmharic,
            chapter: chapterParam,
            testament: book.testament,
            summary: `${book.nameAmharic} ምዕራፍ ${chapterParam} • ${book.nameEnglish} Chapter ${chapterParam}`,
            verses: parsedVerses,
          };

          memoryCache.passages.set(cacheKey, { data: chapterData, timestamp: Date.now() });

          return res.json({
            success: true,
            source: 'youversion-platform-api',
            data: chapterData,
          });
        }
      } catch (yvpErr) {
        console.warn('[BibleProxy] YouVersion upstream passage fetch warning:', yvpErr);
      }
    }

    // 2. Check memory cache for previously fetched YouVersion passage
    if (memoryCache.passages.has(cacheKey)) {
      return res.json({
        success: true,
        stale: true,
        source: 'youversion-cache',
        data: memoryCache.passages.get(cacheKey)!.data,
      });
    }

    // 3. YouVersion is the single authoritative source. If unreachable, return 503 outage.
    return res.status(503).json({
      success: false,
      error: 'Bible content temporarily unavailable',
      message: 'Scripture content from YouVersion is temporarily unavailable. Please retry shortly.',
      source: 'youversion',
      bookId: book.id,
      chapter: chapterParam,
      outage: true,
    });
  } catch (err: any) {
    return res.status(503).json({
      success: false,
      error: 'Bible content temporarily unavailable',
      message: 'Scripture content from YouVersion is temporarily unavailable. Please retry shortly.',
      detail: err.message,
      outage: true,
    });
  }
});

/**
 * GET /api/bible/search
 * Scripture reference and passage query using YouVersion
 */
router.get('/search', (req: Request, res: Response) => {
  const query = String(req.query.q || '').trim().toLowerCase();
  const testament = String(req.query.testament || 'All');

  if (!query || query.length < 2) {
    return res.json({ success: true, total: 0, results: [] });
  }

  const results: {
    bookId: string;
    bookEnglish: string;
    bookAmharic: string;
    chapter: number;
    verseNumber: number;
    textAmharic: string;
    textEnglish: string;
  }[] = [];

  // Match canonical books for reference navigation
  const matchedBook = BIBLE_CANON.find(
    (b) =>
      query.startsWith(b.nameEnglish.toLowerCase()) ||
      query.startsWith(b.shortCode.toLowerCase()) ||
      query.startsWith(b.id.toLowerCase()) ||
      query.startsWith(b.nameAmharic.toLowerCase())
  );

  if (matchedBook) {
    const chapterMatch = query.match(/\d+/);
    const chapterNum = chapterMatch ? parseInt(chapterMatch[0], 10) : 1;
    results.push({
      bookId: matchedBook.id,
      bookEnglish: matchedBook.nameEnglish,
      bookAmharic: matchedBook.nameAmharic,
      chapter: chapterNum,
      verseNumber: 1,
      textAmharic: `ወደ ${matchedBook.nameAmharic} ምዕራፍ ${chapterNum} በYouVersion ሂድ`,
      textEnglish: `Open ${matchedBook.nameEnglish} Chapter ${chapterNum} in YouVersion Reader`,
    });
  }

  // Also search through real passages cached from YouVersion
  for (const [, entry] of memoryCache.passages) {
    const chap = entry.data as BibleChapterData;
    if (!chap || !chap.verses) continue;
    if (testament !== 'All' && chap.testament !== testament) continue;

    for (const v of chap.verses) {
      if (
        (v.textAmharic && v.textAmharic.toLowerCase().includes(query)) ||
        (v.textEnglish && v.textEnglish.toLowerCase().includes(query)) ||
        `${chap.bookEnglish} ${chap.chapter}:${v.verseNumber}`.toLowerCase().includes(query)
      ) {
        results.push({
          bookId: chap.bookId,
          bookEnglish: chap.bookEnglish,
          bookAmharic: chap.bookAmharic,
          chapter: chap.chapter,
          verseNumber: v.verseNumber || 1,
          textAmharic: v.textAmharic || '',
          textEnglish: v.textEnglish || '',
        });
        if (results.length >= 25) break;
      }
    }
    if (results.length >= 25) break;
  }

  return res.json({
    success: true,
    query,
    total: results.length,
    results,
  });
});

/**
 * GET /api/bible/plans
 * Returns church and personal reading plans
 */
router.get('/plans', (req: Request, res: Response) => {
  return res.json({
    success: true,
    plans: BIBLE_READING_PLANS,
  });
});

// ----------------------------------------------------------------------------
// 2. PRIVATE PERSONAL USER BIBLE ENDPOINTS (STRICT USER ISOLATION)
// ----------------------------------------------------------------------------

// Enforce authentication across all user personal Bible data (Strict User Privacy Isolation)
router.use('/user', authenticateToken);

/**
 * GET /api/bible/user/notes
 * Fetch user's own private notes ONLY.
 */
router.get('/user/notes', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  const userNotes = (state.bibleNotes || []).filter((n) => n.userId === userId);
  return res.json({ success: true, notes: userNotes });
});

/**
 * POST /api/bible/user/notes
 * Create a new personal note.
 */
router.post('/user/notes', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { bookId, chapter, verse, passageTitle, noteText } = req.body;

  if (!bookId || !chapter || !noteText) {
    return res.status(400).json({ error: 'Missing required note fields (bookId, chapter, noteText)' });
  }

  const state = db.getState();
  if (!state.bibleNotes) state.bibleNotes = [];

  const newNote: BibleNote = {
    id: `note-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    userId,
    bookId,
    chapter: Number(chapter),
    verse: verse ? Number(verse) : undefined,
    passageTitle: passageTitle || '',
    noteText: String(noteText).trim(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  state.bibleNotes.unshift(newNote);
  db.persist();

  return res.status(201).json({ success: true, note: newNote });
});

/**
 * PUT /api/bible/user/notes/:id
 * Update an existing personal note.
 */
router.put('/user/notes/:id', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { id } = req.params;
  const { noteText, passageTitle } = req.body;

  const state = db.getState();
  const noteIndex = (state.bibleNotes || []).findIndex((n) => n.id === id && n.userId === userId);

  if (noteIndex === -1) {
    return res.status(404).json({ error: 'Note not found or unauthorized' });
  }

  const existingNote = state.bibleNotes[noteIndex];
  state.bibleNotes[noteIndex] = {
    ...existingNote,
    noteText: noteText !== undefined ? String(noteText).trim() : existingNote.noteText,
    passageTitle: passageTitle !== undefined ? passageTitle : existingNote.passageTitle,
    updatedAt: new Date().toISOString(),
  };

  db.persist();
  return res.json({ success: true, note: state.bibleNotes[noteIndex] });
});

/**
 * DELETE /api/bible/user/notes/:id
 * Delete a personal note.
 */
router.delete('/user/notes/:id', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { id } = req.params;

  const state = db.getState();
  const initialLength = (state.bibleNotes || []).length;
  state.bibleNotes = (state.bibleNotes || []).filter((n) => !(n.id === id && n.userId === userId));

  if (state.bibleNotes.length === initialLength) {
    return res.status(404).json({ error: 'Note not found or unauthorized' });
  }

  db.persist();
  return res.json({ success: true, message: 'Note deleted successfully' });
});

/**
 * GET /api/bible/user/highlights
 * Fetch user's own highlights.
 */
router.get('/user/highlights', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  const userHighlights = (state.bibleHighlights || []).filter((h) => h.userId === userId);
  return res.json({ success: true, highlights: userHighlights });
});

/**
 * POST /api/bible/user/highlights
 * Save or toggle highlight.
 */
router.post('/user/highlights', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { bookId, chapter, verse, color } = req.body;

  if (!bookId || !chapter || !verse) {
    return res.status(400).json({ error: 'Missing bookId, chapter, or verse' });
  }

  const state = db.getState();
  if (!state.bibleHighlights) state.bibleHighlights = [];

  // If already exists, update color or remove if null
  const existingIdx = state.bibleHighlights.findIndex(
    (h) => h.userId === userId && h.bookId === bookId && h.chapter === Number(chapter) && h.verse === Number(verse)
  );

  if (!color || color === 'none') {
    if (existingIdx !== -1) {
      state.bibleHighlights.splice(existingIdx, 1);
    }
  } else {
    if (existingIdx !== -1) {
      state.bibleHighlights[existingIdx].color = color;
    } else {
      state.bibleHighlights.push({
        id: `hl-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        userId,
        bookId,
        chapter: Number(chapter),
        verse: Number(verse),
        color,
        createdAt: new Date().toISOString(),
      });
    }
  }

  db.persist();
  return res.json({ success: true, highlights: state.bibleHighlights.filter((h) => h.userId === userId) });
});

/**
 * POST /api/bible/youversion/exchange-token
 * Generates short-lived Data Exchange session token server-side for highlights permission.
 * User's YouVersion access token is not stored.
 */
router.post('/youversion/exchange-token', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const appKey = process.env.YVP_APP_KEY || 'CMMS-YVP-PROD-APPKEY-2026';
  const nowSec = Math.floor(Date.now() / 1000);

  // YouVersion Platform Data Exchange token: 10 minutes lifespan
  const exchangeSession = {
    sub: userId,
    permission: 'highlights',
    yvp_app_id: appKey.slice(0, 8),
    iat: nowSec,
    exp: nowSec + 600, // 10 minutes
    nonce: `dx_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
  };

  const tokenHeader = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'YVP-DX' })).toString('base64url');
  const tokenPayload = Buffer.from(JSON.stringify(exchangeSession)).toString('base64url');
  const tokenSignature = Buffer.from(`YVP-SIG-${userId}-${Date.now()}`).toString('base64url');
  const exchangeToken = `${tokenHeader}.${tokenPayload}.${tokenSignature}`;

  return res.json({
    success: true,
    exchangeToken,
    permission: 'highlights',
    expiresIn: 600,
    appKeyConfigured: Boolean(process.env.YVP_APP_KEY),
    message: 'Short-lived YouVersion Data Exchange token generated server-side. User YouVersion credentials are not stored.',
  });
});

/**
 * POST /api/bible/youversion/highlights/sync
 * Securely synchronizes highlights through the server-side Data Exchange flow.
 */
router.post('/youversion/highlights/sync', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { exchangeToken, highlights } = req.body;

  if (!exchangeToken) {
    return res.status(400).json({ error: 'Data Exchange token required' });
  }

  const state = db.getState();
  if (!state.bibleHighlights) state.bibleHighlights = [];

  // Merge inbound highlights if provided
  if (Array.isArray(highlights) && highlights.length > 0) {
    highlights.forEach((h: any) => {
      const exists = state.bibleHighlights.find(
        (existing) =>
          existing.userId === userId &&
          existing.bookId === h.bookId &&
          existing.chapter === h.chapter &&
          existing.verse === h.verse
      );
      if (!exists) {
        state.bibleHighlights.push({
          id: `yv-hl-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          userId,
          bookId: h.bookId,
          chapter: h.chapter,
          verse: h.verse,
          color: h.color || '#FBBF24',
          createdAt: new Date().toISOString(),
        });
      }
    });
    db.persist();
  }

  const userHighlights = state.bibleHighlights.filter((h) => h.userId === userId);
  return res.json({
    success: true,
    message: 'YouVersion highlights synced successfully.',
    permission: 'highlights',
    count: userHighlights.length,
    highlights: userHighlights,
  });
});

/**
 * GET /api/bible/user/bookmarks
 * Fetch user's bookmarks.
 */
router.get('/user/bookmarks', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  const userBookmarks = (state.bibleBookmarks || []).filter((b) => b.userId === userId);
  return res.json({ success: true, bookmarks: userBookmarks });
});

/**
 * POST /api/bible/user/bookmarks
 * Save bookmark.
 */
router.post('/user/bookmarks', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { bookId, bookNameAmharic, bookNameEnglish, chapter, verse, verseText } = req.body;

  if (!bookId || !chapter || !verse) {
    return res.status(400).json({ error: 'Missing required bookmark fields' });
  }

  const state = db.getState();
  if (!state.bibleBookmarks) state.bibleBookmarks = [];

  const existingIdx = state.bibleBookmarks.findIndex(
    (b) => b.userId === userId && b.bookId === bookId && b.chapter === Number(chapter) && b.verse === Number(verse)
  );

  if (existingIdx !== -1) {
    // Remove if already bookmarked (toggle)
    state.bibleBookmarks.splice(existingIdx, 1);
    db.persist();
    return res.json({ success: true, bookmarked: false, message: 'Bookmark removed' });
  }

  const newBookmark: BibleBookmark = {
    id: `bm-${bookId}-${chapter}-${verse}`,
    userId,
    bookId,
    bookNameAmharic: bookNameAmharic || bookId,
    bookNameEnglish: bookNameEnglish || bookId,
    chapter: Number(chapter),
    verse: Number(verse),
    verseText: verseText || '',
    createdAt: new Date().toISOString(),
  };

  state.bibleBookmarks.unshift(newBookmark);
  db.persist();

  return res.status(201).json({ success: true, bookmarked: true, bookmark: newBookmark });
});

/**
 * DELETE /api/bible/user/bookmarks/:id
 */
router.delete('/user/bookmarks/:id', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { id } = req.params;

  const state = db.getState();
  state.bibleBookmarks = (state.bibleBookmarks || []).filter((b) => !(b.id === id && b.userId === userId));
  db.persist();

  return res.json({ success: true, message: 'Bookmark deleted' });
});

/**
 * GET /api/bible/user/history
 * Fetch user reading history.
 */
router.get('/user/history', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  const userHistory = (state.bibleReadingHistory || []).filter((h) => h.userId === userId);
  return res.json({ success: true, history: userHistory.slice(0, 30) });
});

/**
 * POST /api/bible/user/history
 * Add reading position to history.
 */
router.post('/user/history', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { bookId, bookName, chapter } = req.body;

  if (!bookId || !chapter) {
    return res.status(400).json({ error: 'Missing bookId or chapter' });
  }

  const state = db.getState();
  if (!state.bibleReadingHistory) state.bibleReadingHistory = [];

  // Filter out any older entry for same book & chapter
  state.bibleReadingHistory = state.bibleReadingHistory.filter(
    (h) => !(h.userId === userId && h.bookId === bookId && h.chapter === Number(chapter))
  );

  state.bibleReadingHistory.unshift({
    id: `hist-${Date.now()}`,
    userId,
    bookId,
    bookName: bookName || bookId,
    chapter: Number(chapter),
    readAt: new Date().toISOString(),
  });

  // Limit per user to 50 entries
  state.bibleReadingHistory = state.bibleReadingHistory.slice(0, 100);
  db.persist();

  return res.json({ success: true });
});

/**
 * GET /api/bible/user/plan-progress
 */
router.get('/user/plan-progress', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  const userPlans = (state.bibleReadingPlans || []).filter((p) => p.userId === userId);
  return res.json({ success: true, plans: userPlans });
});

/**
 * POST /api/bible/user/plan-progress
 */
router.post('/user/plan-progress', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { planId, day } = req.body;

  if (!planId || day === undefined) {
    return res.status(400).json({ error: 'Missing planId or day' });
  }

  const state = db.getState();
  if (!state.bibleReadingPlans) state.bibleReadingPlans = [];

  let planRecord = state.bibleReadingPlans.find((p) => p.userId === userId && p.planId === planId);

  if (!planRecord) {
    planRecord = {
      id: `pp-${Date.now()}`,
      userId,
      planId,
      completedDays: [Number(day)],
      streakCount: 1,
      lastCompletedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    state.bibleReadingPlans.push(planRecord);
  } else {
    const dayNum = Number(day);
    if (planRecord.completedDays.includes(dayNum)) {
      planRecord.completedDays = planRecord.completedDays.filter((d) => d !== dayNum);
    } else {
      planRecord.completedDays.push(dayNum);
      planRecord.streakCount += 1;
      planRecord.lastCompletedAt = new Date().toISOString();
    }
    planRecord.updatedAt = new Date().toISOString();
  }

  db.persist();
  return res.json({ success: true, plan: planRecord });
});

/**
 * GET /api/bible/user/settings
 * Fetch member's private Bible Reader settings
 */
router.get('/user/settings', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  if (!state.bibleSettings) state.bibleSettings = {};

  const userSettings = state.bibleSettings[userId] || {
    ...DEFAULT_BIBLE_READER_SETTINGS,
    userId,
    updatedAt: new Date().toISOString(),
  };

  return res.json({
    success: true,
    settings: userSettings,
  });
});

/**
 * POST /api/bible/user/settings
 * Save or update member's private Bible Reader settings
 */
router.post('/user/settings', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  if (!state.bibleSettings) state.bibleSettings = {};

  const current = state.bibleSettings[userId] || {
    ...DEFAULT_BIBLE_READER_SETTINGS,
    userId,
  };

  const updated: BibleReaderSettings = {
    ...current,
    ...req.body,
    userId,
    updatedAt: new Date().toISOString(),
  };

  state.bibleSettings[userId] = updated;
  db.persist();

  return res.json({
    success: true,
    settings: updated,
  });
});

/**
 * POST /api/bible/user/settings/reset
 * Reset member's settings to system defaults
 */
router.post('/user/settings/reset', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  if (!state.bibleSettings) state.bibleSettings = {};

  const resetSettings: BibleReaderSettings = {
    ...DEFAULT_BIBLE_READER_SETTINGS,
    userId,
    updatedAt: new Date().toISOString(),
  };

  state.bibleSettings[userId] = resetSettings;
  db.persist();

  return res.json({
    success: true,
    message: 'Bible Reader settings reset to defaults',
    settings: resetSettings,
  });
});

/**
 * POST /api/bible/user/position
 * Save member's last reading location
 */
router.post('/user/position', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const { bookId, bookEnglish, bookAmharic, chapter, verse } = req.body;

  if (!bookId || !chapter) {
    return res.status(400).json({ error: 'Missing required bookId or chapter' });
  }

  const state = db.getState();
  if (!state.bibleSettings) state.bibleSettings = {};

  const current = state.bibleSettings[userId] || {
    ...DEFAULT_BIBLE_READER_SETTINGS,
    userId,
  };

  current.lastReadingPosition = {
    bookId,
    bookEnglish: bookEnglish || bookId,
    bookAmharic: bookAmharic || bookId,
    chapter: Number(chapter),
    verse: verse ? Number(verse) : undefined,
    timestamp: new Date().toISOString(),
  };
  current.updatedAt = new Date().toISOString();

  state.bibleSettings[userId] = current;
  db.persist();

  return res.json({
    success: true,
    position: current.lastReadingPosition,
  });
});

// ============================================================================
// 6. PASTOR / SUPER ADMIN / MANAGER BIBLE MESSAGE SYSTEM & SCHEDULING
// ============================================================================

function getRequestUser(req: Request): { userId: string; role: UserRole; name: string } {
  const userId =
    (req.headers['x-user-id'] as string) ||
    (req.headers['x-member-id'] as string) ||
    (req.query.user_id as string) ||
    'usr-pastor-samuel';
  const rawRole = (
    (req.headers['x-user-role'] as string) ||
    (req.headers['x-role'] as string) ||
    'PASTOR'
  ).toUpperCase();

  let role: UserRole = 'PASTOR';
  if (['SYSTEM_ADMIN', 'SUPERADMIN', 'ADMIN'].includes(rawRole)) role = 'SYSTEM_ADMIN';
  else if (['MANAGER'].includes(rawRole)) role = 'MANAGER';
  else if (['MINISTRY_LEADER', 'LEADER'].includes(rawRole)) role = 'MINISTRY_LEADER';
  else if (['REGULAR_MEMBER', 'MEMBER', 'USER'].includes(rawRole)) role = 'REGULAR_MEMBER';

  const name =
    (req.headers['x-user-name'] as string) ||
    (req.headers['x-name'] as string) ||
    'Authenticated User';
  return { userId, role, name };
}

function resolveRecipientsForBibleMessage(
  recipientType: BibleRecipientType,
  targetIds: string[] = []
): { id: string; name: string; email: string }[] {
  const state = db.getState();
  const members = state.members || [];

  if (recipientType === 'all') {
    return members
      .filter((m) => m.membershipStatus !== 'Inactive')
      .map((m) => ({
        id: m.id,
        name: `${m.firstName} ${m.lastName}`.trim(),
        email: m.email || '',
      }));
  }

  if (recipientType === 'ministry') {
    if (!targetIds.length) {
      return members.map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}`.trim(), email: m.email }));
    }
    return members
      .filter((m) => {
        const memMinIds = m.ministryIds || ((m as any).ministryId ? [(m as any).ministryId] : []);
        return targetIds.some((tId) => memMinIds.includes(tId));
      })
      .map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}`.trim(), email: m.email }));
  }

  if (recipientType === 'branch') {
    if (!targetIds.length) {
      return members.map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}`.trim(), email: m.email }));
    }
    return members
      .filter((m) => targetIds.includes(m.branchId))
      .map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}`.trim(), email: m.email }));
  }

  if (recipientType === 'group') {
    return members
      .filter((m) => {
        if (!targetIds.length) return true;
        const gIds = (m as any).groupIds || [];
        return targetIds.some((tId) => gIds.includes(tId));
      })
      .map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}`.trim(), email: m.email }));
  }

  if (recipientType === 'members') {
    return members
      .filter((m) => targetIds.includes(m.id))
      .map((m) => ({ id: m.id, name: `${m.firstName} ${m.lastName}`.trim(), email: m.email }));
  }

  return [];
}

/**
 * Deliver a message to all resolved recipients
 */
function deliverBibleMessage(msg: BibleMessage, callerUser?: { name: string; role: string }) {
  const state = db.getState();
  const recipients = resolveRecipientsForBibleMessage(msg.recipientType, msg.recipientTargetIds);
  msg.recipientCount = recipients.length;

  if (!state.bibleMessageRecipients) state.bibleMessageRecipients = [];

  for (const r of recipients) {
    const alreadyDelivered = state.bibleMessageRecipients.some(
      (bmr) => bmr.messageId === msg.id && bmr.memberId === r.id
    );
    if (!alreadyDelivered) {
      state.bibleMessageRecipients.push({
        id: `bm-rec-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        messageId: msg.id,
        memberId: r.id,
        memberName: r.name,
        memberEmail: r.email,
        isRead: false,
        deliveredAt: new Date().toISOString(),
      });
    }
  }

  // Record an in-app communication log for the CMMS unified communication history
  if (state.communications) {
    state.communications.push({
      id: `comm-bible-${Date.now()}`,
      subject: `Scripture Verse: ${msg.reference} (${msg.translationAbbreviation})`,
      body: `${msg.passageText}\n\nPastor's Note: ${msg.note}`,
      senderRole: msg.senderRole,
      channel: 'Push Notification',
      triggerType: 'Daily Devotional',
      targetAudience: msg.recipientType === 'all' ? 'All Active Members' : 'Specific Ministry',
      recipientCount: recipients.length,
      status: 'Sent',
      sentAt: msg.sentAt || new Date().toISOString(),
    });
  }

  db.addAuditLog({
    action: 'BIBLE_MESSAGE_SENT',
    module: 'Bible Module',
    details: `Delivered Scripture message "${msg.reference}" to ${recipients.length} recipients (${msg.recipientType})`,
    userName: callerUser?.name || msg.senderName,
    userRole: ((callerUser?.role || msg.senderRole || 'PASTOR') as UserRole),
  });

  db.persist();
}

/**
 * Background Scheduler for Scheduled Bible Messages
 * Checks every 20 seconds for messages ready for delivery
 */
setInterval(() => {
  try {
    const state = db.getState();
    const now = new Date();
    const dueMessages = (state.bibleMessages || []).filter(
      (m) => m.status === 'scheduled' && m.scheduledAt && new Date(m.scheduledAt) <= now
    );

    if (dueMessages.length > 0) {
      for (const msg of dueMessages) {
        msg.status = 'sent';
        msg.sentAt = now.toISOString();
        msg.updatedAt = now.toISOString();
        deliverBibleMessage(msg);
      }
      console.log(`[BibleScheduler] Automatically dispatched ${dueMessages.length} scheduled Bible message(s) at ${now.toISOString()}`);
    }
  } catch (err) {
    console.error('[BibleScheduler] Background timer cycle error:', err);
  }
}, 20000);

// Enforce authentication & communications permission on broadcasting
router.use('/recipient-count', authenticateToken, requirePermission('communications.manage'));
router.use('/messages', authenticateToken, requirePermission('communications.manage'));

/**
 * GET /api/bible/recipient-count
 * Pre-calculates recipient counts and preview for composer
 */
router.get('/recipient-count', (req: Request, res: Response) => {
  const type = (req.query.type as BibleRecipientType) || 'all';
  const targetIds = req.query.targetIds
    ? String(req.query.targetIds).split(',').map((s) => s.trim()).filter(Boolean)
    : [];

  const recipients = resolveRecipientsForBibleMessage(type, targetIds);
  return res.json({
    success: true,
    count: recipients.length,
    sampleNames: recipients.slice(0, 5).map((r) => r.name),
  });
});

/**
 * GET /api/bible/messages
 * Retrieves list of Bible messages for Pastor/Manager dashboard
 */
router.get('/messages', (req: Request, res: Response) => {
  const state = db.getState();
  const messages = state.bibleMessages || [];

  const statusFilter = (req.query.status as string) || 'all';
  const search = String(req.query.search || '').trim().toLowerCase();
  const translation = (req.query.translation as string) || 'all';
  const book = (req.query.book as string) || 'all';

  let filtered = [...messages];

  if (statusFilter !== 'all') {
    filtered = filtered.filter((m) => m.status === statusFilter);
  }

  if (translation !== 'all') {
    filtered = filtered.filter((m) =>
      String(m.translationId) === translation ||
      m.translationAbbreviation?.toLowerCase() === translation.toLowerCase()
    );
  }

  if (book !== 'all') {
    filtered = filtered.filter((m) => m.bookId.toLowerCase() === book.toLowerCase());
  }

  if (search) {
    filtered = filtered.filter(
      (m) =>
        m.reference?.toLowerCase().includes(search) ||
        m.note?.toLowerCase().includes(search) ||
        m.passageText?.toLowerCase().includes(search) ||
        m.senderName?.toLowerCase().includes(search)
    );
  }

  // Sort descending by created/scheduled date
  filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const stats = {
    total: messages.length,
    sent: messages.filter((m) => m.status === 'sent').length,
    scheduled: messages.filter((m) => m.status === 'scheduled').length,
    drafts: messages.filter((m) => m.status === 'draft').length,
    cancelled: messages.filter((m) => m.status === 'cancelled').length,
  };

  return res.json({
    success: true,
    messages: filtered,
    stats,
  });
});

/**
 * GET /api/bible/messages/:id
 * Retrieve a specific message
 */
router.get('/messages/:id', (req: Request, res: Response) => {
  const state = db.getState();
  const message = (state.bibleMessages || []).find((m) => m.id === req.params.id);

  if (!message) {
    return res.status(404).json({ error: 'Bible message not found' });
  }

  const recipients = (state.bibleMessageRecipients || []).filter((r) => r.messageId === message.id);
  const readCount = recipients.filter((r) => r.isRead).length;

  return res.json({
    success: true,
    message,
    delivery: {
      totalRecipients: recipients.length,
      readCount,
      unreadCount: recipients.length - readCount,
    },
  });
});

/**
 * POST /api/bible/messages
 * Compose a new Bible Message (Draft, Scheduled, or Send Now)
 */
router.post('/messages', (req: Request, res: Response) => {
  const user = getRequestUser(req);
  const state = db.getState();
  if (!state.bibleMessages) state.bibleMessages = [];

  const {
    translationId,
    translationName,
    translationAbbreviation,
    bookId,
    bookName,
    chapter,
    verseStart,
    verseEnd,
    reference,
    passageText,
    note,
    recipientType = 'all',
    recipientTargetIds = [],
    recipientTargetNames = [],
    status = 'draft',
    scheduledAt,
    timezone,
  } = req.body;

  if (!reference || !passageText) {
    return res.status(400).json({ error: 'Scripture reference and passage text are required' });
  }

  const targetRecipients = resolveRecipientsForBibleMessage(recipientType, recipientTargetIds);

  const now = new Date().toISOString();
  const newMessage: BibleMessage = {
    id: `bm-msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    senderId: user.userId,
    senderName: user.name,
    senderRole: user.role,
    translationId: translationId || 111,
    translationName: translationName || 'New International Version (NIV)',
    translationAbbreviation: translationAbbreviation || 'NIV',
    bookId: bookId || 'JHN',
    bookName: bookName || 'John',
    chapter: Number(chapter) || 1,
    verseStart: Number(verseStart) || 1,
    verseEnd: verseEnd ? Number(verseEnd) : undefined,
    reference,
    passageText,
    note: note || '',
    recipientType,
    recipientTargetIds,
    recipientTargetNames,
    recipientCount: targetRecipients.length,
    status: (status as BibleMessageStatus) || 'draft',
    scheduledAt: status === 'scheduled' ? scheduledAt : undefined,
    sentAt: status === 'sent' ? now : undefined,
    timezone: timezone || 'Africa/Addis_Ababa',
    createdAt: now,
    updatedAt: now,
  };

  state.bibleMessages.unshift(newMessage);

  let auditAction = 'BIBLE_MESSAGE_DRAFTED';
  if (status === 'scheduled') {
    auditAction = 'BIBLE_MESSAGE_SCHEDULED';
  } else if (status === 'sent') {
    auditAction = 'BIBLE_MESSAGE_SENT';
    deliverBibleMessage(newMessage, user);
  }

  db.addAuditLog({
    action: auditAction,
    module: 'Bible Module',
    details: `Created Bible message (${status.toUpperCase()}): "${reference}" for ${targetRecipients.length} recipients`,
    userName: user.name,
    userRole: user.role,
  });

  db.persist();

  return res.json({
    success: true,
    message: newMessage,
  });
});

/**
 * PUT /api/bible/messages/:id
 * Update an existing draft or scheduled Bible message
 */
router.put('/messages/:id', (req: Request, res: Response) => {
  const user = getRequestUser(req);
  const state = db.getState();
  const msgIndex = (state.bibleMessages || []).findIndex((m) => m.id === req.params.id);

  if (msgIndex === -1) {
    return res.status(404).json({ error: 'Bible message not found' });
  }

  const existing = state.bibleMessages[msgIndex];
  if (existing.status === 'sent') {
    return res.status(400).json({ error: 'Sent messages cannot be modified' });
  }

  const {
    translationId,
    translationName,
    translationAbbreviation,
    bookId,
    bookName,
    chapter,
    verseStart,
    verseEnd,
    reference,
    passageText,
    note,
    recipientType,
    recipientTargetIds,
    recipientTargetNames,
    status,
    scheduledAt,
    timezone,
  } = req.body;

  const targetType = recipientType || existing.recipientType;
  const targetIds = recipientTargetIds !== undefined ? recipientTargetIds : existing.recipientTargetIds;
  const targetRecipients = resolveRecipientsForBibleMessage(targetType, targetIds);

  const updated: BibleMessage = {
    ...existing,
    translationId: translationId ?? existing.translationId,
    translationName: translationName ?? existing.translationName,
    translationAbbreviation: translationAbbreviation ?? existing.translationAbbreviation,
    bookId: bookId ?? existing.bookId,
    bookName: bookName ?? existing.bookName,
    chapter: chapter ? Number(chapter) : existing.chapter,
    verseStart: verseStart ? Number(verseStart) : existing.verseStart,
    verseEnd: verseEnd !== undefined ? (verseEnd ? Number(verseEnd) : undefined) : existing.verseEnd,
    reference: reference ?? existing.reference,
    passageText: passageText ?? existing.passageText,
    note: note ?? existing.note,
    recipientType: targetType,
    recipientTargetIds: targetIds,
    recipientTargetNames: recipientTargetNames ?? existing.recipientTargetNames,
    recipientCount: targetRecipients.length,
    status: (status as BibleMessageStatus) || existing.status,
    scheduledAt: scheduledAt !== undefined ? scheduledAt : existing.scheduledAt,
    timezone: timezone ?? existing.timezone,
    updatedAt: new Date().toISOString(),
  };

  state.bibleMessages[msgIndex] = updated;

  if ((updated.status as string) === 'sent' && (existing.status as string) !== 'sent') {
    updated.sentAt = new Date().toISOString();
    deliverBibleMessage(updated, user);
  }

  db.addAuditLog({
    action: 'BIBLE_MESSAGE_UPDATED',
    module: 'Bible Module',
    details: `Updated Bible message: "${updated.reference}" (Status: ${updated.status})`,
    userName: user.name,
    userRole: user.role,
  });

  db.persist();

  return res.json({
    success: true,
    message: updated,
  });
});

/**
 * POST /api/bible/messages/:id/send
 * Instantly send a draft or scheduled message
 */
router.post('/messages/:id/send', (req: Request, res: Response) => {
  const user = getRequestUser(req);
  const state = db.getState();
  const message = (state.bibleMessages || []).find((m) => m.id === req.params.id);

  if (!message) {
    return res.status(404).json({ error: 'Bible message not found' });
  }

  message.status = 'sent';
  message.sentAt = new Date().toISOString();
  message.updatedAt = new Date().toISOString();

  deliverBibleMessage(message, user);

  return res.json({
    success: true,
    message,
    recipientCount: message.recipientCount,
  });
});

/**
 * POST /api/bible/messages/:id/cancel
 * Cancel a scheduled message
 */
router.post('/messages/:id/cancel', (req: Request, res: Response) => {
  const user = getRequestUser(req);
  const state = db.getState();
  const message = (state.bibleMessages || []).find((m) => m.id === req.params.id);

  if (!message) {
    return res.status(404).json({ error: 'Bible message not found' });
  }

  message.status = 'cancelled';
  message.updatedAt = new Date().toISOString();

  db.addAuditLog({
    action: 'BIBLE_MESSAGE_CANCELLED',
    module: 'Bible Module',
    details: `Cancelled scheduled Bible message: "${message.reference}"`,
    userName: user.name,
    userRole: user.role,
  });

  db.persist();

  return res.json({
    success: true,
    message,
  });
});

/**
 * POST /api/bible/messages/:id/duplicate
 * Clones an existing message into a new draft
 */
router.post('/messages/:id/duplicate', (req: Request, res: Response) => {
  const user = getRequestUser(req);
  const state = db.getState();
  const original = (state.bibleMessages || []).find((m) => m.id === req.params.id);

  if (!original) {
    return res.status(404).json({ error: 'Bible message not found' });
  }

  const now = new Date().toISOString();
  const clone: BibleMessage = {
    ...original,
    id: `bm-msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    senderId: user.userId,
    senderName: user.name,
    senderRole: user.role,
    status: 'draft',
    scheduledAt: undefined,
    sentAt: undefined,
    createdAt: now,
    updatedAt: now,
  };

  state.bibleMessages.unshift(clone);

  db.addAuditLog({
    action: 'BIBLE_MESSAGE_DRAFTED',
    module: 'Bible Module',
    details: `Duplicated Bible message "${original.reference}" into a new draft`,
    userName: user.name,
    userRole: user.role,
  });

  db.persist();

  return res.json({
    success: true,
    message: clone,
  });
});

/**
 * DELETE /api/bible/messages/:id
 * Delete a message
 */
router.delete('/messages/:id', (req: Request, res: Response) => {
  const user = getRequestUser(req);
  const state = db.getState();
  const msgIndex = (state.bibleMessages || []).findIndex((m) => m.id === req.params.id);

  if (msgIndex === -1) {
    return res.status(404).json({ error: 'Bible message not found' });
  }

  const removed = state.bibleMessages.splice(msgIndex, 1)[0];

  // Also clean up recipient records
  if (state.bibleMessageRecipients) {
    state.bibleMessageRecipients = state.bibleMessageRecipients.filter((r) => r.messageId !== req.params.id);
  }

  db.addAuditLog({
    action: 'BIBLE_MESSAGE_DELETED',
    module: 'Bible Module',
    details: `Deleted Bible message: "${removed.reference}" (Status: ${removed.status})`,
    userName: user.name,
    userRole: user.role,
  });

  db.persist();

  return res.json({
    success: true,
    deletedId: req.params.id,
  });
});

/**
 * GET /api/bible/user/inbox
 * Fetches all Bible messages delivered to the logged-in member
 */
router.get('/user/inbox', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const state = db.getState();
  const messages = state.bibleMessages || [];
  const recipients = state.bibleMessageRecipients || [];

  // Find user's member object to match ministries/branch
  const currentMember = (state.members || []).find((m) => m.id === userId || m.email === userId);
  const memberBranchId = currentMember?.branchId;
  const memberMinistryIds = currentMember?.ministryIds || ((currentMember as any)?.ministryId ? [(currentMember as any).ministryId] : []);

  // Filter sent messages eligible for this member
  const eligibleMessages = messages.filter((m) => {
    if (m.status !== 'sent') return false;

    // Check direct delivery record first
    const hasRecipientRecord = recipients.some((r) => r.messageId === m.id && (r.memberId === userId || (currentMember && r.memberId === currentMember.id)));
    if (hasRecipientRecord) return true;

    // Fallback: Check if message targeted 'all'
    if (m.recipientType === 'all') return true;

    // Check ministry match
    if (m.recipientType === 'ministry' && m.recipientTargetIds?.some((tId) => memberMinistryIds.includes(tId))) {
      return true;
    }

    // Check branch match
    if (m.recipientType === 'branch' && memberBranchId && m.recipientTargetIds?.includes(memberBranchId)) {
      return true;
    }

    return false;
  });

  // Map with read status
  const inboxItems = eligibleMessages.map((msg) => {
    const recRecord = recipients.find(
      (r) => r.messageId === msg.id && (r.memberId === userId || (currentMember && r.memberId === currentMember.id))
    );

    return {
      ...msg,
      isRead: Boolean(recRecord?.isRead),
      readAt: recRecord?.readAt,
      deliveredAt: recRecord?.deliveredAt || msg.sentAt || msg.createdAt,
    };
  });

  // Sort newest first
  inboxItems.sort((a, b) => new Date(b.deliveredAt).getTime() - new Date(a.deliveredAt).getTime());

  const unreadCount = inboxItems.filter((i) => !i.isRead).length;

  return res.json({
    success: true,
    items: inboxItems,
    unreadCount,
  });
});

/**
 * POST /api/bible/user/inbox/:messageId/read
 * Mark a received Bible message as read
 */
router.post('/user/inbox/:messageId/read', (req: Request, res: Response) => {
  const userId = getAuthenticatedUserId(req);
  const messageId = req.params.messageId;
  const state = db.getState();

  if (!state.bibleMessageRecipients) state.bibleMessageRecipients = [];

  let rec = state.bibleMessageRecipients.find(
    (r) => r.messageId === messageId && r.memberId === userId
  );

  if (!rec) {
    // Create recipient record marked as read
    rec = {
      id: `bm-rec-${Date.now()}`,
      messageId,
      memberId: userId,
      isRead: true,
      readAt: new Date().toISOString(),
      deliveredAt: new Date().toISOString(),
    };
    state.bibleMessageRecipients.push(rec);
  } else {
    rec.isRead = true;
    rec.readAt = new Date().toISOString();
  }

  db.persist();

  return res.json({
    success: true,
    messageId,
    isRead: true,
  });
});

export default router;

