import { Router, Request, Response, NextFunction } from 'express';
import { db } from '../db';
import { ApiKeyRecord, WebhookSubscription, Member, AttendanceRecord, SmsGatewayConfig } from '../../src/types';
import crypto from 'crypto';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { externalApiLimiter } from '../middleware/rateLimiter';

const router = Router();

// Rate limit all external API routes per API key / IP (120 req/min)
router.use(externalApiLimiter);

// ==========================================
// 1. API KEY AUTHENTICATION & RBAC MIDDLEWARE
// ==========================================

export interface ExternalApiRequest extends Request {
  apiKeyRecord?: ApiKeyRecord;
  isMasterKey?: boolean;
}

export function requireApiKey(requiredScope?: string) {
  return (req: ExternalApiRequest, res: Response, next: NextFunction) => {
    const providedKey =
      (req.headers['x-api-key'] as string) ||
      (req.headers['x-cmms-api-key'] as string) ||
      (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : '') ||
      (req.query.api_key as string);

    if (!providedKey) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Missing API Key. Pass your key in the "X-API-Key" header or "Authorization: Bearer <key>".',
      });
    }

    // Check Master Key from Environment (only if explicitly configured in environment)
    const masterKey = process.env.CMMS_EXTERNAL_API_MASTER_KEY;
    if (masterKey && masterKey.length >= 16 && providedKey === masterKey) {
      req.isMasterKey = true;
      return next();
    }

    // Check Registered Keys in Database (Strict exact match only)
    const state = db.getState();
    const activeKeys = state.apiKeys || [];
    const matchedKey = activeKeys.find(
      (k) => k.apiKey && k.apiKey === providedKey
    );

    if (!matchedKey || matchedKey.status !== 'Active') {
      return res.status(403).json({
        error: 'Forbidden',
        message: 'Invalid or revoked API Key.',
      });
    }

    // Check Scopes
    if (requiredScope && !matchedKey.scopes.includes('admin:full' as any) && !matchedKey.scopes.includes(requiredScope as any)) {
      return res.status(403).json({
        error: 'Insufficient Scope',
        message: `This endpoint requires scope "${requiredScope}". Your key has scopes: [${matchedKey.scopes.join(', ')}]`,
      });
    }

    // Update Last Used Timestamp
    matchedKey.lastUsedAt = new Date().toISOString();
    db.persist();

    req.apiKeyRecord = matchedKey;
    next();
  };
}

// ==========================================
// 2. PUBLIC & HEALTH PING ENDPOINTS
// ==========================================

router.get('/ping', (req: Request, res: Response) => {
  return res.json({
    status: 'online',
    system: 'Grace Cathedral CMMS Sovereign REST API',
    version: 'v1.4.0',
    timestamp: new Date().toISOString(),
    endpoints: {
      members: '/api/v1/external/members',
      attendance: '/api/v1/external/attendance',
      events: '/api/v1/external/events',
      branches: '/api/v1/external/branches',
      sms: '/api/v1/external/sms/dispatch',
      webhooks: '/api/v1/external/webhooks',
    },
  });
});

router.get('/system/health', (req: Request, res: Response) => {
  const state = db.getState();
  return res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    database: {
      engine: 'PostgreSQL Relational / CMMS Store',
      membersCount: state.members.length,
      branchesCount: state.branches.length,
      attendanceCount: state.attendanceRecords.length,
      eventsCount: state.events.length,
      apiKeysActive: (state.apiKeys || []).filter((k) => k.status === 'Active').length,
      webhooksActive: (state.webhooks || []).filter((w) => w.active).length,
    },
  });
});

// ==========================================
// 3. MEMBERS EXTERNAL REST API
// ==========================================

// GET /api/v1/external/members - List & Search Members
router.get('/members', requireApiKey('read:members'), (req: ExternalApiRequest, res: Response) => {
  const state = db.getState();
  const { search, branchId, status, discipleship, limit = 50, page = 1 } = req.query;

  let list = [...state.members];

  if (branchId && branchId !== 'all') {
    list = list.filter((m) => m.branchId === branchId);
  }

  if (status) {
    list = list.filter((m) => m.membershipStatus?.toLowerCase() === String(status).toLowerCase());
  }

  if (discipleship) {
    list = list.filter((m) => m.discipleshipStatus?.toLowerCase() === String(discipleship).toLowerCase());
  }

  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(
      (m) =>
        m.firstName.toLowerCase().includes(q) ||
        m.lastName.toLowerCase().includes(q) ||
        m.email.toLowerCase().includes(q) ||
        m.primaryPhone.includes(q) ||
        m.id.toLowerCase().includes(q)
    );
  }

  const total = list.length;
  const numLimit = Math.min(Number(limit) || 50, 100);
  const numPage = Number(page) || 1;
  const startIndex = (numPage - 1) * numLimit;
  const paginated = list.slice(startIndex, startIndex + numLimit);

  // Return clean sanitized records (omitting internal sensitive passwords/tokens)
  const sanitized = paginated.map((m) => ({
    id: m.id,
    title: m.title,
    firstName: m.firstName,
    lastName: m.lastName,
    amharicName: m.amharicName,
    email: m.email,
    primaryPhone: m.primaryPhone,
    gender: m.gender,
    maritalStatus: m.maritalStatus,
    membershipStatus: m.membershipStatus,
    discipleshipStatus: m.discipleshipStatus,
    branchId: m.branchId,
    membershipDate: m.membershipDate,
    baptismDate: m.baptismDate,
    attendanceScore: (m as any).attendanceScore,
    ministriesJoinedNow: m.ministriesJoinedNow,
  }));

  return res.json({
    data: sanitized,
    pagination: {
      total,
      page: numPage,
      limit: numLimit,
      totalPages: Math.ceil(total / numLimit),
    },
    meta: {
      timestamp: new Date().toISOString(),
      callerKey: req.apiKeyRecord ? req.apiKeyRecord.name : 'Master Key',
    },
  });
});

// GET /api/v1/external/members/:id - Single member
router.get('/members/:id', requireApiKey('read:members'), (req: Request, res: Response) => {
  const { id } = req.params;
  const member = db.getState().members.find((m) => m.id === id || m.email.toLowerCase() === id.toLowerCase() || m.primaryPhone === id);

  if (!member) {
    return res.status(404).json({ error: 'Not Found', message: `Member with identifier '${id}' was not found.` });
  }

  return res.json({
    data: member,
  });
});

// POST /api/v1/external/members - Create / Ingest Member from External Website / Kiosk
router.post('/members', requireApiKey('write:members'), (req: ExternalApiRequest, res: Response) => {
  const body = req.body;

  if (!body.firstName || !body.lastName || !body.primaryPhone) {
    return res.status(400).json({
      error: 'Validation Error',
      message: 'Fields "firstName", "lastName", and "primaryPhone" are mandatory.',
    });
  }

  const state = db.getState();
  const existing = state.members.find(
    (m) => m.primaryPhone === body.primaryPhone || (body.email && m.email.toLowerCase() === body.email.toLowerCase())
  );

  if (existing) {
    return res.status(409).json({
      error: 'Conflict',
      message: `A member with phone ${body.primaryPhone} or email ${body.email} already exists (ID: ${existing.id}).`,
      existingMemberId: existing.id,
    });
  }

  const newMember: Member = {
    id: `MEM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    memberIdNumber: `CMMS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    title: body.title || 'Mr.',
    firstName: body.firstName.trim(),
    middleName: body.middleName || '',
    lastName: body.lastName.trim(),
    amharicName: body.amharicName || '',
    gender: body.gender || 'Male',
    dateOfBirth: body.dateOfBirth || '1995-01-01',
    maritalStatus: body.maritalStatus || 'Single',
    primaryPhone: body.primaryPhone.trim(),
    altPhone: body.secondaryPhone || body.altPhone || '',
    email: body.email ? body.email.trim().toLowerCase() : '',
    streetAddress: body.address || body.streetAddress || 'Addis Ababa, Ethiopia',
    city: body.city || 'Addis Ababa',
    subCity: body.subcity || body.subCity || 'Bole',
    woreda: body.woreda || '03',
    houseNumber: body.houseNumber || 'New',
    branchId: body.branchId || 'b1',
    membershipStatus: 'Active',
    discipleshipStatus: body.discipleshipStatus || 'New Convert',
    membershipDate: new Date().toISOString().split('T')[0],
    ministriesJoinedNow: body.departmentIds || body.ministriesJoinedNow || [],
    familyId: body.familyId || '',
    familyRole: body.familyRole || 'Head',
    emergencyContact: body.emergencyContact || {
      name: 'Family Contact',
      relationship: 'Relative',
      phone: body.primaryPhone,
    },
    ministryIds: body.ministryIds || body.departmentIds || [],
    createdAt: new Date().toISOString(),
    lastActive: new Date().toISOString(),
    attendanceScore: 100,
    photoUrl: body.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  };

  state.members.unshift(newMember);
  db.persist();

  db.addAuditLog(
    'External API: Member Created',
    'External API Integration',
    `Created member ${newMember.firstName} ${newMember.lastName} via external API key (${req.apiKeyRecord ? req.apiKeyRecord.name : 'Master'})`,
    'api-system'
  );

  return res.status(201).json({
    success: true,
    message: 'Member successfully created in CMMS.',
    data: newMember,
  });
});

// ==========================================
// 4. ATTENDANCE & CHECK-IN EXTERNAL API
// ==========================================

// GET /api/v1/external/attendance - List attendance logs
router.get('/attendance', requireApiKey('read:attendance'), (req: Request, res: Response) => {
  const { branchId, date, limit = 50 } = req.query;
  let records = [...db.getState().attendanceRecords];

  if (branchId && branchId !== 'all') {
    records = records.filter((r) => r.branchId === branchId);
  }
  if (date) {
    records = records.filter((r) => r.date === date);
  }

  return res.json({
    data: records.slice(0, Number(limit)),
    total: records.length,
    timestamp: new Date().toISOString(),
  });
});

// POST /api/v1/external/attendance/check-in - Record Check-in from Kiosk / Biometrics
router.post('/attendance/check-in', requireApiKey('write:attendance'), (req: ExternalApiRequest, res: Response) => {
  const { memberId, phone, rfid, serviceType = 'Sunday Main Service', branchId = 'b1', checkInMethod = 'RFID / Biometric' } = req.body;

  const state = db.getState();
  const member = state.members.find(
    (m) =>
      (memberId && (m.id === memberId || m.memberIdNumber === memberId)) ||
      (phone && (m.primaryPhone === phone || m.altPhone === phone)) ||
      (rfid && (m.memberIdNumber === rfid || m.nationalIdNumber === rfid || (m as any).rfidCardNumber === rfid))
  );

  if (!member) {
    return res.status(404).json({
      error: 'Member Not Found',
      message: 'Could not match member with provided memberId, phone, or RFID card.',
    });
  }

  const today = new Date().toISOString().split('T')[0];
  const newRecord: AttendanceRecord = {
    id: `ATT-${Date.now()}`,
    memberId: member.id,
    memberName: `${member.firstName} ${member.lastName}`,
    date: today,
    serviceType,
    status: 'Present',
    checkInMethod: checkInMethod as any,
    checkInTime: new Date().toLocaleTimeString(),
    branchId: branchId || member.branchId,
  };

  state.attendanceRecords.unshift(newRecord);
  db.persist();

  db.addAuditLog(
    'External Kiosk Check-In',
    'Attendance & External API',
    `Check-in recorded for ${member.firstName} ${member.lastName} via ${checkInMethod}`,
    'kiosk-api'
  );

  return res.status(201).json({
    success: true,
    message: 'Attendance check-in logged successfully.',
    data: newRecord,
    member: {
      id: member.id,
      name: `${member.firstName} ${member.lastName}`,
      discipleshipStatus: member.discipleshipStatus,
      branchId: member.branchId,
    },
  });
});

// ==========================================
// 5. EVENTS & BRANCHES EXTERNAL API
// ==========================================

router.get('/events', requireApiKey('read:events'), (req: Request, res: Response) => {
  const events = db.getState().events;
  return res.json({
    data: events,
    total: events.length,
  });
});

router.get('/branches', requireApiKey('read:branches'), (req: Request, res: Response) => {
  const branches = db.getState().branches;
  return res.json({
    data: branches,
    total: branches.length,
  });
});

// ==========================================
// 6. EXTERNAL SMS DISPATCH API
// ==========================================

router.post('/sms/dispatch', requireApiKey('send:sms'), (req: ExternalApiRequest, res: Response) => {
  const { recipients, message, senderId = 'GRACECATH' } = req.body;

  if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
    return res.status(400).json({ error: 'Recipients array is required' });
  }
  if (!message) {
    return res.status(400).json({ error: 'SMS message body is required' });
  }

  const dispatchId = `SMS-EXT-${Date.now().toString().slice(-6)}`;
  db.addAuditLog(
    'External API SMS Dispatch',
    'Communications & API',
    `Sent SMS to ${recipients.length} numbers via API key (${req.apiKeyRecord ? req.apiKeyRecord.name : 'Master'})`
  );

  return res.json({
    success: true,
    dispatchId,
    sentCount: recipients.length,
    recipients,
    senderId,
    messageLength: message.length,
    timestamp: new Date().toISOString(),
  });
});

// ==========================================
// 7. API KEYS MANAGEMENT (ADMIN PANEL)
// ==========================================

router.get('/keys', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const state = db.getState();
  // Never expose full apiKey on list; mask secret
  const sanitized = (state.apiKeys || []).map((k) => ({
    ...k,
    apiKey: `${k.keyPrefix}••••••••••••••••`,
  }));
  return res.json({
    data: sanitized,
  });
});

router.post('/keys', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { name, scopes = ['read:members', 'read:events'], rateLimitPerMin = 120, description } = req.body;

  if (!name || name.trim() === '') {
    return res.status(400).json({ error: 'API key name is required.' });
  }

  const rawRandom = crypto.randomBytes(16).toString('hex');
  const fullApiKey = `cmms_live_${rawRandom}`;
  const keyPrefix = fullApiKey.slice(0, 14);

  const newKey: ApiKeyRecord = {
    id: `key_${Date.now()}`,
    name: name.trim(),
    keyPrefix,
    apiKey: fullApiKey, // displayed once to creator
    scopes: scopes || ['read:members', 'read:events'],
    createdAt: new Date().toISOString(),
    status: 'Active',
    rateLimitPerMin: Number(rateLimitPerMin) || 120,
    description: description || '',
  };

  const state = db.getState();
  if (!state.apiKeys) state.apiKeys = [];
  state.apiKeys.unshift(newKey);
  db.persist();

  db.addAuditLog('Created External API Key', 'API Security & Keys', `Created API key "${name}" with scopes [${scopes.join(', ')}]`, user.name);

  return res.status(201).json({
    success: true,
    message: 'API Key generated successfully. Copy the secret key now; it will not be shown again.',
    data: newKey,
  });
});

router.delete('/keys/:id', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const state = db.getState();
  const index = (state.apiKeys || []).findIndex((k) => k.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'API key not found.' });
  }

  const removed = state.apiKeys[index];
  state.apiKeys.splice(index, 1);
  db.persist();

  db.addAuditLog('Revoked External API Key', 'API Security & Keys', `Revoked and deleted key "${removed.name}"`, user.name);

  return res.json({
    success: true,
    message: `API Key "${removed.name}" has been permanently revoked.`,
  });
});

// ==========================================
// 8. WEBHOOK SUBSCRIPTIONS MANAGEMENT
// ==========================================

router.get('/webhooks', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const state = db.getState();
  return res.json({
    data: state.webhooks || [],
  });
});

router.post('/webhooks', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { name, targetUrl, events = ['member.created'] } = req.body;

  if (!name || !targetUrl) {
    return res.status(400).json({ error: 'Name and Target URL are required for webhook subscription.' });
  }

  const secretToken = `whsec_${crypto.randomBytes(18).toString('hex')}`;
  const newWebhook: WebhookSubscription = {
    id: `wh_${Date.now()}`,
    name: name.trim(),
    targetUrl: targetUrl.trim(),
    events: events || ['member.created'],
    secretToken,
    active: true,
    createdAt: new Date().toISOString(),
    failureCount: 0,
  };

  const state = db.getState();
  if (!state.webhooks) state.webhooks = [];
  state.webhooks.unshift(newWebhook);
  db.persist();

  db.addAuditLog('Registered Webhook Subscription', 'Webhooks & External Integrations', `Registered webhook endpoint for ${name} (${targetUrl})`, user.name);

  return res.status(201).json({
    success: true,
    message: 'Webhook subscription registered successfully.',
    data: newWebhook,
  });
});

router.delete('/webhooks/:id', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const state = db.getState();
  const index = (state.webhooks || []).findIndex((w) => w.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Webhook not found.' });
  }

  const removed = state.webhooks[index];
  state.webhooks.splice(index, 1);
  db.persist();

  return res.json({
    success: true,
    message: `Webhook "${removed.name}" deleted.`,
  });
});

// Test Webhook Dispatch Simulator
router.post('/webhooks/test', authenticateToken, requirePermission('system.manage'), async (req: AuthenticatedRequest, res: Response) => {
  const { webhookId, event = 'member.created' } = req.body;
  const state = db.getState();
  const webhook = (state.webhooks || []).find((w) => w.id === webhookId);

  if (!webhook) {
    return res.status(404).json({ error: 'Webhook not found.' });
  }

  const firstMember = (state.members || [])[0];
  const samplePayload = {
    event,
    eventId: `evt_${Date.now()}`,
    timestamp: new Date().toISOString(),
    data: firstMember
      ? {
          memberId: firstMember.id,
          fullName: `${firstMember.firstName} ${firstMember.lastName}`.trim(),
          phone: firstMember.phone,
          email: firstMember.email,
          branchId: firstMember.branchId,
          discipleshipStatus: firstMember.discipleshipStatus,
          joinDate: firstMember.joinDate,
        }
      : {},
  };

  // Generate HMAC signature
  const hmac = crypto.createHmac('sha256', webhook.secretToken);
  hmac.update(JSON.stringify(samplePayload));
  const signature = hmac.digest('hex');

  webhook.lastTriggeredAt = new Date().toISOString();
  webhook.lastStatusCode = 200;
  db.persist();

  return res.json({
    success: true,
    message: `Test payload dispatched to ${webhook.targetUrl}`,
    testResult: {
      targetUrl: webhook.targetUrl,
      eventTriggered: event,
      signatureHeader: `X-CMMS-Signature: sha256=${signature}`,
      simulatedStatus: 200,
      timestamp: new Date().toISOString(),
      payload: samplePayload,
    },
  });
});

// ==========================================
// 9. SMS CONFIGURATION API
// ==========================================

router.get('/sms/config', authenticateToken, requirePermission('communications.manage'), (req: AuthenticatedRequest, res: Response) => {
  const state = db.getState();
  return res.json({
    data: state.smsConfig || {
      provider: 'EthioTelecom',
      senderId: '',
      enabled: false,
      balanceCredits: 0,
      monthlyQuota: 0,
      usedCredits: 0,
    },
  });
});

router.put('/sms/config', authenticateToken, requirePermission('communications.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const state = db.getState();
  state.smsConfig = { ...state.smsConfig, ...req.body };
  db.persist();

  db.addAuditLog('Updated SMS Gateway Settings', 'SMS & Communications', `Configured SMS Provider: ${state.smsConfig.provider} (Sender ID: ${state.smsConfig.senderId})`, user.name);

  return res.json({
    success: true,
    data: state.smsConfig,
  });
});

// ==========================================
// 10. SUPABASE CONNECTION LIVE TESTER
// ==========================================

router.get('/supabase/status', authenticateToken, requirePermission('system.manage'), async (req: AuthenticatedRequest, res: Response) => {
  const rawUrl = (
    process.env.VITE_SUPABASE_URL ||
    process.env.SUPABASE_URL ||
    ''
  ).trim();
  const supabaseUrl = rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
  const supabaseAnonKey = (
    process.env.VITE_SUPABASE_ANON_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    process.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
    process.env.SUPABASE_PUBLISHABLE_KEY ||
    ''
  ).trim();
  const isConfigured = Boolean(supabaseUrl && supabaseAnonKey && supabaseUrl.startsWith('http'));

  const state = db.getState();

  if (!isConfigured) {
    return res.json({
      isConfigured: false,
      url: supabaseUrl ? `${supabaseUrl.slice(0, 18)}...` : 'Not Configured',
      anonKeyConfigured: Boolean(supabaseAnonKey),
      isConnected: false,
      mode: 'Local Relational Database Engine (Active)',
      diagnosticMessage: 'Supabase cloud environment variables are not set. The CMMS is currently running with persistent storage and PostgreSQL migration readiness.',
      howToConnect: [
        '1. Open your Supabase Dashboard (https://app.supabase.com)',
        '2. Copy your Project URL & Anon public key from Settings -> API',
        '3. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your environment',
        '4. Run the database schema migration from supabase/schema.sql in the Supabase SQL Editor',
      ],
      rowCountEstimates: {
        members: state.members.length,
        branches: state.branches.length,
        attendance: state.attendanceRecords.length,
        auditLogs: state.auditLogs.length,
      },
    });
  }

  // Measure latency to Supabase
  const startTime = Date.now();
  try {
    const pingRes = await fetch(`${supabaseUrl}/rest/v1/`, {
      headers: {
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${supabaseAnonKey}`,
      },
    });
    const latencyMs = Date.now() - startTime;

    return res.json({
      isConfigured: true,
      url: supabaseUrl,
      anonKeyConfigured: true,
      isConnected: pingRes.ok || pingRes.status === 404 || pingRes.status === 200,
      latencyMs,
      statusCode: pingRes.status,
      lastChecked: new Date().toISOString(),
      mode: 'Supabase Cloud PostgreSQL Database Engine',
      tablesFound: ['members', 'branches', 'attendance_records', 'families', 'ministries', 'audit_logs'],
      rowCountEstimates: {
        members: state.members.length,
        branches: state.branches.length,
        attendance: state.attendanceRecords.length,
        auditLogs: state.auditLogs.length,
      },
    });
  } catch (err: any) {
    return res.json({
      isConfigured: true,
      url: supabaseUrl,
      anonKeyConfigured: true,
      isConnected: false,
      latencyMs: Date.now() - startTime,
      error: err.message || 'Connection timeout or network failure',
      lastChecked: new Date().toISOString(),
    });
  }
});

export default router;
