/**
 * Hardened replacement for `POST /api/system/storage/upload` in server/routes/system.ts.
 *
 * Fixes (all verified in the original handler):
 *  - any authenticated user could upload            -> requires `documents.manage`
 *  - client chose the bucket (any bucket, incl. private/system ones)  -> server allowlist
 *  - client chose `folder` (path traversal, cross-prefix writes)      -> sanitised segments
 *  - `upsert: true` + predictable name (overwrite others' files)      -> random name, no upsert
 *  - client-supplied MIME type stored and served (stored XSS via SVG/HTML) -> magic-byte sniffing + allowlist
 *  - "success" with a data: URL of up to 50 MB when Storage is unavailable -> 503 (small dev-only fallback)
 *  - public URL returned for private buckets                          -> signed URL unless bucket is public
 *  - audit trail by display name only                                 -> user id + tenant id + object path
 *
 * Mount (permission is checked per bucket by `deps.authorize`, so no route-level permission):
 *   router.post('/storage/upload', authenticateToken, sensitiveAdminLimiter, ...storageUploadHandlers(deps));
 */
import crypto from 'node:crypto';
import type { Request, Response, NextFunction, RequestHandler } from 'express';
import multer from 'multer';

export const DEFAULT_BUCKETS: readonly string[] = ['documents-vault', 'member-photos', 'church-branding', 'chat-attachments'];
export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024; // 10 MB per file
const DEV_DATA_URL_MAX_BYTES = 1 * 1024 * 1024;

/** Structural subset of the project's AuthenticatedUserPayload. */
export interface UploadUser {
  id: string;
  tenantId: string;
  name?: string;
  email?: string;
}

export interface StorageClientLike {
  storage: {
    from(bucket: string): {
      upload(
        path: string,
        body: Buffer,
        opts: { contentType: string; upsert: boolean }
      ): Promise<{ error: { message: string } | null }>;
      getPublicUrl(path: string): { data: { publicUrl: string } };
      createSignedUrl(
        path: string,
        expiresInSeconds: number
      ): Promise<{ data: { signedUrl: string } | null; error: { message: string } | null }>;
    };
  };
}

export interface StorageUploadDeps {
  /** Service-role client; pass `null` when Supabase is not configured. */
  adminSupabase: StorageClientLike | null;
  /** Audit sink. Must not throw. */
  audit(entry: {
    action: string;
    module: string;
    details: string;
    userId: string;
    tenantId: string;
  }): void;
  /** Buckets clients may target. Default: the four buckets the app uses. */
  allowedBuckets?: readonly string[];
  /** Per-bucket permission check, e.g. documents-vault -> documents.manage. Default: any authenticated user. */
  authorize?: (user: UploadUser, bucket: string) => boolean;
  /** Buckets whose objects are intentionally world-readable. Default: none. */
  publicBuckets?: readonly string[];
  isProduction?: boolean;
}

interface DetectedType {
  mime: string;
  exts: readonly string[];
}

/** Returns the real type from file content; `null` when not on the allowlist. */
export function sniffAllowedType(buf: Buffer): DetectedType | null {
  const startsWith = (...bytes: number[]) =>
    buf.length >= bytes.length && bytes.every((b, i) => buf[i] === b);

  if (startsWith(0x25, 0x50, 0x44, 0x46, 0x2d)) return { mime: 'application/pdf', exts: ['pdf'] };
  if (startsWith(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)) return { mime: 'image/png', exts: ['png'] };
  if (startsWith(0xff, 0xd8, 0xff)) return { mime: 'image/jpeg', exts: ['jpg', 'jpeg'] };
  if (startsWith(0x47, 0x49, 0x46, 0x38)) return { mime: 'image/gif', exts: ['gif'] };
  if (
    startsWith(0x52, 0x49, 0x46, 0x46) &&
    buf.length >= 12 &&
    buf.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return { mime: 'image/webp', exts: ['webp'] };
  }
  // OOXML (docx/xlsx/pptx) are ZIP containers; the extension disambiguates.
  if (startsWith(0x50, 0x4b, 0x03, 0x04)) {
    return { mime: 'application/zip', exts: ['docx', 'xlsx', 'pptx'] };
  }
  // Plain text / CSV: reject anything with NUL bytes or invalid UTF-8.
  if (buf.length > 0 && !buf.includes(0)) {
    const text = buf.toString('utf8');
    if (!text.includes('\uFFFD')) {
      const head = text.slice(0, 512).trimStart().toLowerCase();
      // Active-content text formats are never allowed.
      if (head.startsWith('<') || head.startsWith('<?xml') || head.startsWith('<!doctype')) return null;
      return { mime: 'text/plain', exts: ['txt', 'csv'] };
    }
  }
  return null;
}

const OOXML_MIME: Record<string, string> = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
};

const SEGMENT_RE = /^[a-z0-9][a-z0-9_-]{0,47}$/;

/** `a/b/c` -> validated segments; throws on traversal, empty or oversized paths. */
export function sanitizeFolder(raw: unknown): string {
  const value = typeof raw === 'string' && raw.trim() ? raw.trim().toLowerCase() : 'uploads';
  const segments = value.split('/').filter((s) => s.length > 0);
  if (segments.length === 0 || segments.length > 3) {
    throw new UploadError(400, 'INVALID_FOLDER', 'Folder must have 1 to 3 segments.');
  }
  for (const segment of segments) {
    if (!SEGMENT_RE.test(segment)) {
      throw new UploadError(400, 'INVALID_FOLDER', 'Folder segments may contain a-z, 0-9, "_" and "-" only.');
    }
  }
  return segments.join('/');
}

export function sanitizeBaseName(originalName: string): string {
  const base = originalName.replace(/\.[^.]*$/, '');
  const cleaned = base
    .normalize('NFKD')
    .replace(/\p{M}+/gu, '') // drop combining accents: "é" -> "e", not "e_"
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return cleaned.slice(0, 60) || 'file';
}

export class UploadError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string
  ) {
    super(message);
    this.name = 'UploadError';
  }
}

function extensionOf(name: string): string {
  const match = /\.([a-zA-Z0-9]{1,8})$/.exec(name);
  return match ? match[1].toLowerCase() : '';
}

const multerInstance = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_BYTES, files: 1, fields: 8, fieldSize: 1024 },
});

type UploadRequest = Request & { user?: UploadUser; file?: Express.Multer.File };

export function storageUploadHandlers(deps: StorageUploadDeps): RequestHandler[] {
  const allowedBuckets = deps.allowedBuckets ?? DEFAULT_BUCKETS;
  const publicBuckets = new Set(deps.publicBuckets ?? []);
  const isProduction = deps.isProduction ?? process.env.NODE_ENV === 'production';

  const parse: RequestHandler = (req, res, next) => {
    multerInstance.single('file')(req, res, (err: unknown) => {
      if (!err) return next();
      if (err instanceof multer.MulterError) {
        const tooLarge = err.code === 'LIMIT_FILE_SIZE';
        return res.status(tooLarge ? 413 : 400).json({
          success: false,
          code: tooLarge ? 'FILE_TOO_LARGE' : 'INVALID_UPLOAD',
          error: tooLarge
            ? `File exceeds the ${MAX_UPLOAD_BYTES / (1024 * 1024)} MB limit.`
            : 'Invalid multipart upload.',
        });
      }
      return next(err);
    });
  };

  const handle = async (req: UploadRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = req.user;
      if (!user?.id || !user.tenantId) {
        throw new UploadError(401, 'UNAUTHENTICATED', 'Authentication required.');
      }
      const file = req.file;
      if (!file || file.size === 0) throw new UploadError(400, 'NO_FILE', 'No file provided for upload.');

      const bucket = typeof req.body?.bucket === 'string' && req.body.bucket ? req.body.bucket : allowedBuckets[0];
      if (!allowedBuckets.includes(bucket)) {
        throw new UploadError(403, 'BUCKET_NOT_ALLOWED', 'Uploads to this bucket are not permitted.');
      }
      if (deps.authorize && !deps.authorize(user, bucket)) {
        throw new UploadError(403, 'FORBIDDEN', 'You do not have permission to upload to this bucket.');
      }
      const folder = sanitizeFolder(req.body?.folder);

      const detected = sniffAllowedType(file.buffer);
      if (!detected) throw new UploadError(415, 'UNSUPPORTED_TYPE', 'This file type is not permitted.');
      const ext = extensionOf(file.originalname);
      if (!detected.exts.includes(ext)) {
        throw new UploadError(415, 'EXTENSION_MISMATCH', 'File extension does not match its content.');
      }
      const contentType = detected.mime === 'application/zip' ? OOXML_MIME[ext] : detected.mime;

      // Tenant prefix first: storage policies can enforce `(storage.foldername(name))[1] = tenant_id`.
      const objectPath = `${user.tenantId}/${folder}/${crypto.randomUUID()}-${sanitizeBaseName(file.originalname)}.${ext}`;

      if (!deps.adminSupabase) {
        if (isProduction || file.size > DEV_DATA_URL_MAX_BYTES) {
          throw new UploadError(503, 'STORAGE_UNAVAILABLE', 'File storage is not configured. Nothing was saved.');
        }
        deps.audit({
          action: 'Storage Upload (dev data-URL fallback)',
          module: 'Storage & Assets',
          details: `bucket=${bucket} path=${objectPath} bytes=${file.size}`,
          userId: user.id,
          tenantId: user.tenantId,
        });
        res.status(201).json({
          success: true,
          bucket,
          path: objectPath,
          publicUrl: `data:${contentType};base64,${file.buffer.toString('base64')}`,
          provider: 'supabase-storage', // keeps the existing client contract
        });
        return;
      }

      const bucketApi = deps.adminSupabase.storage.from(bucket);
      const { error } = await bucketApi.upload(objectPath, file.buffer, { contentType, upsert: false });
      if (error) {
        console.error('[Storage] upload failed:', error.message);
        throw new UploadError(502, 'STORAGE_UPLOAD_FAILED', 'The file could not be stored. Please retry.');
      }

      let url: string | null;
      if (publicBuckets.has(bucket)) {
        url = bucketApi.getPublicUrl(objectPath).data.publicUrl;
      } else {
        const signed = await bucketApi.createSignedUrl(objectPath, 3600);
        url = signed.data?.signedUrl ?? null;
      }

      deps.audit({
        action: 'Storage Upload',
        module: 'Storage & Assets',
        details: `bucket=${bucket} path=${objectPath} bytes=${file.size} type=${contentType}`,
        userId: user.id,
        tenantId: user.tenantId,
      });

      res.status(201).json({
        success: true,
        bucket,
        path: objectPath,
        url,
        publicUrl: url, // backwards-compatible alias: src/services/storageService.ts reads this
        urlExpiresInSeconds: publicBuckets.has(bucket) ? null : 3600,
        provider: 'supabase-storage',
      });
    } catch (err) {
      if (err instanceof UploadError) {
        res.status(err.status).json({ success: false, code: err.code, error: err.message });
        return;
      }
      next(err);
    }
  };

  return [parse, handle as RequestHandler];
}
