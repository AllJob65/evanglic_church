import { Router, Response } from 'express';
import { db } from '../db';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
  isSameTenant,
  isSameCampus,
} from '../../src/security/authorization';
import { smsService } from '../services/smsService';
import { emailService } from '../services/emailService';
import {
  communicationLogService,
  interpolateMessageTemplate,
} from '../services/communicationLogService';
import { CommunicationLog, CommunicationMessage, Member } from '../../src/types';
import { isPgConfigured, query } from '../pg';
import { isDatabaseUuid, listMembers } from '../repositories/memberRepository';

const router = Router();

// All communication endpoints require a verified user token
router.use(authenticateToken);

/**
 * Helper to resolve member record by ID or phone or email from the authoritative database
 */
async function persistCommunicationSummary(
  summary: CommunicationMessage,
  user: AuthenticatedRequest['user'],
  fallbackState?: ReturnType<typeof db.getState>
): Promise<void> {
  if (isPgConfigured()) {
    try {
      await query(
        `INSERT INTO communications (
          id, tenant_id, branch_id, subject, body, sender_role, channel,
          trigger_type, target_audience, recipient_count, sent_at, status,
          delivery_rate_percentage, delivery_stats
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
        [
          summary.id, user?.tenantId, summary.branchId || null, summary.subject,
          summary.body, summary.senderRole, summary.channel, summary.triggerType,
          summary.targetAudience, summary.recipientCount, summary.sentAt,
          summary.status, summary.deliveryRatePercentage, JSON.stringify(summary.deliveryStats),
        ]
      );
      return;
    } catch (error) {
      console.error('[Communications] PostgreSQL campaign summary insert failed:', error);
      throw new Error('COMMUNICATION_SUMMARY_PERSISTENCE_FAILED');
    }
  }
  const state = fallbackState || db.getState();
  if (!Array.isArray(state.communications)) state.communications = [];
  state.communications.unshift(summary);
  db.persist();
}

async function findFamilyInDb(id: string, user: AuthenticatedRequest['user']): Promise<any | undefined> {
  if (isPgConfigured()) {
    const branchIds = [...new Set([...(user?.branchIds || []), user?.branchId].filter(
      (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
    ))];
    const result = user?.branchIds?.includes('*')
      ? await query<any>('SELECT * FROM families WHERE id = $1 AND tenant_id = $2 LIMIT 1', [id, user.tenantId])
      : await query<any>(
          'SELECT * FROM families WHERE id = $1 AND tenant_id = $2 AND (branch_id IS NULL OR branch_id = ANY($3::uuid[])) LIMIT 1',
          [id, user?.tenantId, branchIds]
        );
    return result.rows[0];
  }
  return (db.getState().families || []).find((family) => family.id === id);
}

async function findBranchInDb(id: string, user: AuthenticatedRequest['user']): Promise<any | undefined> {
  if (isPgConfigured()) {
    if (!isDatabaseUuid(id)) return undefined;
    const branchIds = [...new Set([...(user?.branchIds || []), user?.branchId].filter(
      (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
    ))];
    const result = user?.branchIds?.includes('*')
      ? await query<any>(
          'SELECT id, tenant_id AS "tenantId", code, name, type, city, region, address, phone, email FROM branches WHERE id = $1 AND tenant_id = $2 LIMIT 1',
          [id, user.tenantId]
        )
      : await query<any>(
          'SELECT id, tenant_id AS "tenantId", code, name, type, city, region, address, phone, email FROM branches WHERE id = $1 AND tenant_id = $2 AND id = ANY($3::uuid[]) LIMIT 1',
          [id, user?.tenantId, branchIds]
        );
    return result.rows[0];
  }
  return (db.getState().branches || []).find((branch) => branch.id === id);
}

async function findMinistryInDb(id: string, user: AuthenticatedRequest['user']): Promise<any | undefined> {
  if (isPgConfigured()) {
    const branchIds = [...new Set([...(user?.branchIds || []), user?.branchId].filter(
      (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
    ))];
    const result = user?.branchIds?.includes('*')
      ? await query<any>('SELECT * FROM ministries WHERE id = $1 AND tenant_id = $2 LIMIT 1', [id, user.tenantId])
      : await query<any>(
          'SELECT * FROM ministries WHERE id = $1 AND tenant_id = $2 AND (branch_id IS NULL OR branch_id = ANY($3::uuid[])) LIMIT 1',
          [id, user?.tenantId, branchIds]
        );
    return result.rows[0];
  }
  return (db.getState().ministries || []).find((ministry) => ministry.id === id);
}

async function listCommunicationMembers(
  user: AuthenticatedRequest['user'],
  branchId?: string
): Promise<Member[]> {
  const branchIds = [...new Set([...(user?.branchIds || []), user?.branchId].filter(
    (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
  ))];
  const allBranches = Boolean(user?.branchIds?.includes('*'));
  if (branchId && !isDatabaseUuid(branchId)) {
    throw new Error('BROADCAST_BRANCH_ID_INVALID');
  }
  const scope = {
    tenantId: user?.tenantId || '',
    branchIds,
    branchId: branchId || (user?.branchId && isDatabaseUuid(user.branchId) ? user.branchId : undefined),
    allBranches,
  };
  const result = await listMembers(scope);
  return result.members;
}

async function findMemberInDb(
  identifier: string | null | undefined,
  user: AuthenticatedRequest['user']
): Promise<Member | undefined> {
  if (!identifier?.trim()) return undefined;
  const clean = identifier.trim().toLowerCase();
  if (isPgConfigured()) {
    const branchIds = [...new Set([...(user?.branchIds || []), user?.branchId].filter(
      (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
    ))];
    const allBranches = Boolean(user?.branchIds?.includes('*'));
    const scope = {
      tenantId: user?.tenantId || '',
      branchIds,
      branchId: user?.branchId && isDatabaseUuid(user.branchId) ? user.branchId : undefined,
      allBranches,
    };
    const { members } = await listMembers(scope, { search: identifier.trim(), limit: 50 });
    const phoneKey = identifier.replace(/[\s-]/g, '');
    return members.find((member) =>
      member.id.toLowerCase() === clean ||
      member.memberIdNumber?.toLowerCase() === clean ||
      member.email?.toLowerCase() === clean ||
      member.primaryPhone?.replace(/[\s-]/g, '') === phoneKey
    );
  }
  return (db.getState().members || []).find(
    (member) =>
      member.id.toLowerCase() === clean ||
      (member.memberIdNumber && member.memberIdNumber.toLowerCase() === clean) ||
      (member.email && member.email.toLowerCase() === clean) ||
      (member.primaryPhone && member.primaryPhone.replace(/[\s-]/g, '') === identifier.replace(/[\s-]/g, ''))
  );
}

/**
 * GET /api/communications/status
 * Returns non-sensitive provider configuration status (never exposes secrets)
 */
router.get(
  '/status',
  requirePermission('communications.read'),
  (_req: AuthenticatedRequest, res: Response) => {
    return res.json({
      success: true,
      sms: smsService.getStatus(),
      email: emailService.getStatus(),
    });
  }
);

/**
 * GET /api/communications/logs
 * Lists real communication_logs from the database with optional filtering
 */
router.get(
  '/logs',
  requirePermission('communications.read'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
    const user = req.user!;
    const {
      channel,
      status,
      memberId,
      familyId,
      ministryId,
      search,
      limit = '200',
      offset = '0',
    } = req.query;

    let logs: CommunicationLog[] = [];
    let summary: ReturnType<typeof communicationLogService.computeSummary>;
    let totalFiltered = 0;
    const parsedOffset = Math.max(0, parseInt(String(offset), 10) || 0);
    const parsedLimit = Math.min(1000, Math.max(1, parseInt(String(limit), 10) || 200));

    if (isPgConfigured()) {
      const params: unknown[] = [user.tenantId];
      const where = ['tenant_id = $1'];
      let branchParams: unknown[] = [];
      if (!user.branchIds.includes('*')) {
        branchParams = [...new Set([...(user.branchIds || []), user.branchId].filter(
          (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
        ))];
        params.push(branchParams);
        where.push(`(branch_id IS NULL OR branch_id = ANY($${params.length}::uuid[]))`);
      }
      const addFilter = (column: string, value: unknown) => {
        if (value !== undefined && value !== null && String(value).trim() && String(value).toUpperCase() !== 'ALL') {
          params.push(String(value).trim());
          where.push(`${column} = $${params.length}`);
        }
      };
      addFilter('channel', channel ? String(channel).toUpperCase() : undefined);
      addFilter('status', status ? String(status).toUpperCase() : undefined);
      addFilter('member_id', memberId);
      addFilter('family_id', familyId);
      addFilter('ministry_id', ministryId);
      if (search && String(search).trim()) {
        params.push(`%${String(search).trim()}%`);
        const p = `$${params.length}`;
        where.push(`(recipient ILIKE ${p} OR recipient_name ILIKE ${p} OR subject ILIKE ${p} OR message ILIKE ${p} OR provider ILIKE ${p} OR trigger_type ILIKE ${p})`);
      }
      const whereSql = where.join(' AND ');
      const countResult = await query<{ total: string }>(
        `SELECT COUNT(*)::text AS total FROM communication_logs WHERE ${whereSql}`, params
      );
      const aggregateResult = await query<{ total: string; smsCount: string; emailCount: string; sentCount: string; deliveredCount: string; failedCount: string; queuedCount: string }>(
        `SELECT COUNT(*)::text AS total,
          COUNT(*) FILTER (WHERE channel = 'SMS')::text AS "smsCount",
          COUNT(*) FILTER (WHERE channel = 'EMAIL')::text AS "emailCount",
          COUNT(*) FILTER (WHERE status = 'SENT')::text AS "sentCount",
          COUNT(*) FILTER (WHERE status = 'DELIVERED')::text AS "deliveredCount",
          COUNT(*) FILTER (WHERE status = 'FAILED')::text AS "failedCount",
          COUNT(*) FILTER (WHERE status = 'QUEUED')::text AS "queuedCount"
         FROM communication_logs WHERE tenant_id = $1 ${user.branchIds.includes('*') ? '' : 'AND (branch_id IS NULL OR branch_id = ANY($2::uuid[]))'}`,
        user.branchIds.includes('*') ? [user.tenantId] : [user.tenantId, branchParams]
      );
      const pageParams = [...params, parsedLimit, parsedOffset];
      const logsResult = await query<CommunicationLog>(
        `SELECT * FROM communication_logs WHERE ${whereSql} ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
        pageParams
      );
      totalFiltered = Number(countResult.rows[0]?.total || 0);
      const agg = aggregateResult.rows[0];
      const total = Number(agg?.total || 0);
      const sentCount = Number(agg?.sentCount || 0);
      const deliveredCount = Number(agg?.deliveredCount || 0);
      summary = {
        total, smsCount: Number(agg?.smsCount || 0), emailCount: Number(agg?.emailCount || 0),
        sentCount, deliveredCount, failedCount: Number(agg?.failedCount || 0),
        queuedCount: Number(agg?.queuedCount || 0),
        deliverySuccessRate: total ? Math.round(((sentCount + deliveredCount) / total) * 100) : 0,
      };
      logs = logsResult.rows;
      return res.json({ success: true, total: totalFiltered, logs, summary });
    } else {
      const state = db.getState();
      logs = Array.isArray(state.communicationLogs) ? [...state.communicationLogs] : [];
      logs = logs.filter((l) => !l.tenant_id || isSameTenant(l.tenant_id, user.tenantId));
      if (!user.branchIds.includes('*')) {
        logs = logs.filter((l) => !l.branch_id || user.branchIds.some((b) => isSameCampus(b, l.branch_id)) || isSameCampus(user.branchId, l.branch_id));
      }
    }

    // Compute overall summary for this user's tenant/branch scope before query filters
    summary = communicationLogService.computeSummary(logs);

    // Apply filters
    if (channel && String(channel).toUpperCase() !== 'ALL') {
      const ch = String(channel).toUpperCase();
      logs = logs.filter((l) => l.channel === ch);
    }

    if (status && String(status).toUpperCase() !== 'ALL') {
      const st = String(status).toUpperCase();
      logs = logs.filter((l) => l.status === st);
    }

    if (memberId) {
      logs = logs.filter((l) => l.member_id === String(memberId));
    }

    if (familyId) {
      logs = logs.filter((l) => l.family_id === String(familyId));
    }

    if (ministryId) {
      logs = logs.filter((l) => l.ministry_id === String(ministryId));
    }

    if (search && String(search).trim()) {
      const q = String(search).trim().toLowerCase();
      logs = logs.filter(
        (l) =>
          (l.recipient && l.recipient.toLowerCase().includes(q)) ||
          (l.recipient_name && l.recipient_name.toLowerCase().includes(q)) ||
          (l.subject && l.subject.toLowerCase().includes(q)) ||
          (l.message && l.message.toLowerCase().includes(q)) ||
          (l.provider && l.provider.toLowerCase().includes(q)) ||
          (l.trigger_type && l.trigger_type.toLowerCase().includes(q))
      );
    }

    totalFiltered = logs.length;
    const paginatedLogs = logs.slice(parsedOffset, parsedOffset + parsedLimit);

    return res.json({
      success: true,
      total: totalFiltered,
      logs: paginatedLogs,
      summary,
    });
    } catch (err: any) {
      console.error('[GET /api/communications/logs] Failed to read communication logs:', err);
      return res.status(503).json({
        success: false,
        error: 'COMMUNICATION_LOG_READ_UNAVAILABLE',
        message: 'Communication logs are temporarily unavailable.',
      });
    }
  }
);

/**
 * GET /api/communications/logs/:id
 * Retrieves a single communication log record by ID
 */
router.get(
  '/logs/:id',
  requirePermission('communications.read'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = req.user!;
      const { id } = req.params;
      let log: CommunicationLog | undefined;
      if (isPgConfigured()) {
        const detailBranchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(
          (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
        ))];
        const result = user.branchIds?.includes('*')
          ? await query<CommunicationLog>(
              'SELECT * FROM communication_logs WHERE id = $1 AND tenant_id = $2 LIMIT 1',
              [id, user.tenantId]
            )
          : await query<CommunicationLog>(
              'SELECT * FROM communication_logs WHERE id = $1 AND tenant_id = $2 AND (branch_id IS NULL OR branch_id = ANY($3::uuid[])) LIMIT 1',
              [id, user.tenantId, detailBranchIds]
            );
        log = result.rows[0];
      } else {
        log = (db.getState().communicationLogs || []).find((l) => l.id === id && (!l.tenant_id || isSameTenant(l.tenant_id, user.tenantId)));
      }

      if (!log) {
        return res.status(404).json({
          success: false,
          error: 'Communication log record not found.',
        });
      }

      if (log.tenant_id && !isSameTenant(log.tenant_id, user.tenantId)) {
        return res.status(403).json({
          success: false,
          error: 'Access denied: cross-tenant communication log.',
        });
      }
      if (
        log.branch_id &&
        !user.branchIds.includes('*') &&
        !user.branchIds.some((b) => isSameCampus(b, log!.branch_id)) &&
        !isSameCampus(user.branchId, log.branch_id)
      ) {
        return res.status(403).json({
          success: false,
          error: 'Access denied: communication log belongs to another branch.',
        });
      }

      return res.json({ success: true, log });
    } catch (err: any) {
      console.error('[GET /api/communications/logs/:id] Failed to read communication log:', err);
      return res.status(503).json({
        success: false,
        error: 'COMMUNICATION_LOG_READ_UNAVAILABLE',
        message: 'Communication logs are temporarily unavailable.',
      });
    }
  }
);

/**
 * POST /api/communications/sms
 * Flow:
 * React UI -> POST /api/communications/sms -> Auth + RBAC -> Validate recipient ->
 * Validate message -> SMS Provider Service -> Save communication result -> Return result
 */
router.post(
  '/sms',
  requirePermission('communications.manage'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = req.user!;
      const {
        recipient,
        recipients,
        memberId,
        familyId,
        ministryId,
        subject,
        message,
        triggerType = 'Direct SMS',
        senderId,
      } = req.body || {};

      const rawMessage = typeof message === 'string' ? message.trim() : '';
      if (!rawMessage) {
        return res.status(400).json({
          success: false,
          error: 'SMS message content is required.',
        });
      }

      const state = db.getState();

      // Build list of target SMS items
      interface TargetSmsItem {
        phone: string;
        member?: Member;
        familyId?: string | null;
        recipientName?: string | null;
      }
      const targets: TargetSmsItem[] = [];

      if (memberId) {
        const mem = await findMemberInDb(memberId, req.user);
        if (!mem) {
          return res.status(404).json({
            success: false,
            error: `Member with ID "${memberId}" was not found in the database.`,
          });
        }
        const targetPhone = (recipient || mem.primaryPhone || mem.altPhone || '').trim();
        if (!targetPhone) {
          return res.status(400).json({
            success: false,
            error: `Member ${mem.firstName} ${mem.lastName} does not have a phone number on file.`,
          });
        }
        targets.push({
          phone: targetPhone,
          member: mem,
          familyId: familyId || mem.familyId || null,
          recipientName: `${mem.title || ''} ${mem.firstName} ${mem.lastName}`.trim(),
        });
      } else if (familyId && !recipient && !Array.isArray(recipients)) {
        const fam = await findFamilyInDb(familyId, req.user);
        if (!fam) {
          return res.status(404).json({
            success: false,
            error: `Family with ID "${familyId}" was not found in the database.`,
          });
        }
        const headMem = await findMemberInDb(fam.headOfHouseholdMemberId, req.user);
        const famPhone = (fam.primaryHouseholdPhone || headMem?.primaryPhone || '').trim();
        if (!famPhone) {
          return res.status(400).json({
            success: false,
            error: `Household "${fam.householdName}" does not have a primary phone number on file.`,
          });
        }
        targets.push({
          phone: famPhone,
          member: headMem,
          familyId: fam.id,
          recipientName: fam.householdName,
        });
      } else if (Array.isArray(recipients) && recipients.length > 0) {
        for (const r of recipients) {
          const phoneStr = typeof r === 'string' ? r.trim() : String(r?.phone || r?.recipient || '').trim();
          const matchedMem = await findMemberInDb(typeof r === 'object' && r?.memberId ? r.memberId : phoneStr, req.user);
          if (phoneStr) {
            targets.push({
              phone: phoneStr,
              member: matchedMem,
              familyId: (typeof r === 'object' ? r?.familyId : undefined) || matchedMem?.familyId || familyId || null,
              recipientName:
                (typeof r === 'object' ? r?.name : undefined) ||
                (matchedMem ? `${matchedMem.title || ''} ${matchedMem.firstName} ${matchedMem.lastName}`.trim() : null),
            });
          }
        }
      } else if (recipient && typeof recipient === 'string' && recipient.trim()) {
        const matchedMem = await findMemberInDb(recipient.trim(), req.user);
        targets.push({
          phone: recipient.trim(),
          member: matchedMem,
          familyId: familyId || matchedMem?.familyId || null,
          recipientName: matchedMem
            ? `${matchedMem.title || ''} ${matchedMem.firstName} ${matchedMem.lastName}`.trim()
            : null,
        });
      }

      if (targets.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'At least one valid recipient phone number or memberId is required.',
        });
      }

      const createdLogs: CommunicationLog[] = [];
      let sentCount = 0;
      let failedCount = 0;

      for (const target of targets) {
        const famObj = target.familyId
          ? await findFamilyInDb(target.familyId, req.user)
          : null;
        const minObj = ministryId
          ? await findMinistryInDb(ministryId, req.user)
          : null;
        const branchObj = target.member?.branchId
          ? await findBranchInDb(target.member.branchId, req.user)
          : null;

        const personalizedMessage = interpolateMessageTemplate(rawMessage, {
          member: target.member,
          family: famObj,
          ministry: minObj,
          branch: branchObj,
        });

        const dispatchResult = await smsService.sendSms({
          recipient: target.phone,
          message: personalizedMessage,
          senderId,
        });

        if (dispatchResult.success) {
          sentCount++;
        } else {
          failedCount++;
        }

        const logRecord = await communicationLogService.recordLog({
          tenantId: user.tenantId,
          branchId: target.member?.branchId || user.branchId,
          channel: 'SMS',
          recipient: dispatchResult.normalizedRecipient || target.phone,
          recipientName: target.recipientName || null,
          memberId: target.member?.id || null,
          familyId: target.familyId || null,
          ministryId: ministryId || null,
          subject: subject || null,
          message: personalizedMessage,
          status: dispatchResult.status,
          provider: dispatchResult.provider,
          providerMessageId: dispatchResult.providerMessageId,
          errorMessage: dispatchResult.errorMessage,
          triggerType,
          sentAt: dispatchResult.sentAt,
          deliveredAt: dispatchResult.deliveredAt,
          createdBy: user.id,
          createdByName: user.name,
        });

        createdLogs.push(logRecord);
      }

      // Record campaign summary in state.communications for unified history
      const primaryLog = createdLogs[0];
      const commSummary: CommunicationMessage = {
        id: `comm-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        tenantId: user.tenantId,
        branchId: user.branchId,
        subject: subject || `SMS to ${primaryLog.recipient_name || primaryLog.recipient}`,
        body: primaryLog.message,
        senderRole: user.role,
        channel: 'SMS',
        triggerType,
        targetAudience:
          targets.length === 1
            ? `${primaryLog.recipient_name ? `${primaryLog.recipient_name} (${primaryLog.recipient})` : primaryLog.recipient}`
            : `${targets.length} SMS Recipients`,
        recipientCount: targets.length,
        sentAt: new Date().toISOString(),
        status: sentCount > 0 ? 'Sent' : 'Failed',
        // Provider acceptance is not a delivery receipt or an open event.
        // Until provider callbacks are integrated, report only confirmed sends.
        deliveryRatePercentage: 0,
        deliveryStats: {
          sent: sentCount,
          delivered: 0,
          opened: 0,
          failed: failedCount,
        },
      };
      await persistCommunicationSummary(commSummary, user, state);

      db.addAuditLog(
        'SMS Communication Dispatched',
        'Communications & SMS',
        `Dispatched SMS (${sentCount} sent, ${failedCount} failed) to ${commSummary.targetAudience} via ${primaryLog.provider}`,
        user.name
      );

      // If single recipient and it failed validation/provider, return 400 or 502 with the created log
      if (targets.length === 1 && !createdLogs[0] || (targets.length === 1 && failedCount === 1)) {
        return res.status(400).json({
          success: false,
          error: primaryLog.error_message || 'Failed to send SMS.',
          log: primaryLog,
          logs: createdLogs,
        });
      }

      return res.status(201).json({
        success: sentCount > 0,
        message:
          targets.length === 1
            ? `SMS sent to ${primaryLog.recipient} via ${primaryLog.provider}.`
            : `SMS batch processed: ${sentCount} sent, ${failedCount} failed.`,
        sentCount,
        failedCount,
        log: primaryLog,
        logs: createdLogs,
        communication: commSummary,
      });
    } catch (err: any) {
      console.error('[POST /api/communications/sms] Error:', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Internal server error while dispatching SMS.',
      });
    }
  }
);

/**
 * POST /api/communications/email
 * Flow:
 * React UI -> POST /api/communications/email -> Auth + RBAC -> Validate recipient ->
 * Validate email/message -> Email Provider Service -> Save communication result -> Return result
 */
router.post(
  '/email',
  requirePermission('communications.manage'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = req.user!;
      const {
        recipient,
        recipients,
        memberId,
        familyId,
        ministryId,
        subject,
        message,
        html,
        replyTo,
        triggerType = 'Direct Email',
      } = req.body || {};

      const rawSubject = typeof subject === 'string' ? subject.trim() : '';
      const rawMessage = typeof message === 'string' ? message.trim() : '';

      if (!rawSubject) {
        return res.status(400).json({
          success: false,
          error: 'Email subject is required.',
        });
      }

      if (!rawMessage && !html) {
        return res.status(400).json({
          success: false,
          error: 'Email message body is required.',
        });
      }

      const state = db.getState();

      interface TargetEmailItem {
        email: string;
        member?: Member;
        familyId?: string | null;
        recipientName?: string | null;
      }
      const targets: TargetEmailItem[] = [];

      if (memberId) {
        const mem = await findMemberInDb(memberId, req.user);
        if (!mem) {
          return res.status(404).json({
            success: false,
            error: `Member with ID "${memberId}" was not found in the database.`,
          });
        }
        const targetEmail = (recipient || mem.email || '').trim();
        if (!targetEmail) {
          return res.status(400).json({
            success: false,
            error: `Member ${mem.firstName} ${mem.lastName} does not have an email address on file.`,
          });
        }
        targets.push({
          email: targetEmail,
          member: mem,
          familyId: familyId || mem.familyId || null,
          recipientName: `${mem.title || ''} ${mem.firstName} ${mem.lastName}`.trim(),
        });
      } else if (familyId && !recipient && !Array.isArray(recipients)) {
        const fam = await findFamilyInDb(familyId, req.user);
        if (!fam) {
          return res.status(404).json({
            success: false,
            error: `Family with ID "${familyId}" was not found in the database.`,
          });
        }
        const headMem = await findMemberInDb(fam.headOfHouseholdMemberId, req.user);
        const famEmail = (headMem?.email || '').trim();
        if (!famEmail) {
          return res.status(400).json({
            success: false,
            error: `Head of Household for "${fam.householdName}" does not have an email address on file.`,
          });
        }
        targets.push({
          email: famEmail,
          member: headMem,
          familyId: fam.id,
          recipientName: fam.householdName,
        });
      } else if (Array.isArray(recipients) && recipients.length > 0) {
        for (const r of recipients) {
          const emailStr = typeof r === 'string' ? r.trim() : String(r?.email || r?.recipient || '').trim();
          const matchedMem = await findMemberInDb(typeof r === 'object' && r?.memberId ? r.memberId : emailStr, req.user);
          if (emailStr) {
            targets.push({
              email: emailStr,
              member: matchedMem,
              familyId: (typeof r === 'object' ? r?.familyId : undefined) || matchedMem?.familyId || familyId || null,
              recipientName:
                (typeof r === 'object' ? r?.name : undefined) ||
                (matchedMem ? `${matchedMem.title || ''} ${matchedMem.firstName} ${matchedMem.lastName}`.trim() : null),
            });
          }
        }
      } else if (recipient && typeof recipient === 'string' && recipient.trim()) {
        const matchedMem = await findMemberInDb(recipient.trim(), req.user);
        targets.push({
          email: recipient.trim(),
          member: matchedMem,
          familyId: familyId || matchedMem?.familyId || null,
          recipientName: matchedMem
            ? `${matchedMem.title || ''} ${matchedMem.firstName} ${matchedMem.lastName}`.trim()
            : null,
        });
      }

      if (targets.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'At least one valid recipient email address or memberId is required.',
        });
      }

      const createdLogs: CommunicationLog[] = [];
      let sentCount = 0;
      let failedCount = 0;

      for (const target of targets) {
        const famObj = target.familyId
          ? (state.families || []).find((f) => f.id === target.familyId)
          : null;
        const minObj = ministryId
          ? await findMinistryInDb(ministryId, req.user)
          : null;
        const branchObj = target.member?.branchId
          ? await findBranchInDb(target.member.branchId, req.user)
          : null;

        const personalizedSubject = interpolateMessageTemplate(rawSubject, {
          member: target.member,
          family: famObj,
          ministry: minObj,
          branch: branchObj,
        });
        const personalizedMessage = interpolateMessageTemplate(rawMessage, {
          member: target.member,
          family: famObj,
          ministry: minObj,
          branch: branchObj,
        });

        const dispatchResult = await emailService.sendEmail({
          recipient: target.email,
          subject: personalizedSubject,
          message: personalizedMessage,
          html,
          replyTo,
        });

        if (dispatchResult.success) {
          sentCount++;
        } else {
          failedCount++;
        }

        const logRecord = await communicationLogService.recordLog({
          tenantId: user.tenantId,
          branchId: target.member?.branchId || user.branchId,
          channel: 'EMAIL',
          recipient: dispatchResult.recipient || target.email,
          recipientName: target.recipientName || null,
          memberId: target.member?.id || null,
          familyId: target.familyId || null,
          ministryId: ministryId || null,
          subject: personalizedSubject,
          message: personalizedMessage,
          status: dispatchResult.status,
          provider: dispatchResult.provider,
          providerMessageId: dispatchResult.providerMessageId,
          errorMessage: dispatchResult.errorMessage,
          triggerType,
          sentAt: dispatchResult.sentAt,
          deliveredAt: dispatchResult.deliveredAt,
          createdBy: user.id,
          createdByName: user.name,
        });

        createdLogs.push(logRecord);
      }

      const primaryLog = createdLogs[0];
      const commSummary: CommunicationMessage = {
        id: `comm-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        tenantId: user.tenantId,
        branchId: user.branchId,
        subject: primaryLog.subject || rawSubject,
        body: primaryLog.message,
        senderRole: user.role,
        channel: 'Email',
        triggerType,
        targetAudience:
          targets.length === 1
            ? `${primaryLog.recipient_name ? `${primaryLog.recipient_name} (${primaryLog.recipient})` : primaryLog.recipient}`
            : `${targets.length} Email Recipients`,
        recipientCount: targets.length,
        sentAt: new Date().toISOString(),
        status: sentCount > 0 ? 'Sent' : 'Failed',
        // Provider acceptance is not a delivery receipt or an open event.
        // Until provider callbacks are integrated, report no confirmed deliveries.
        deliveryRatePercentage: 0,
        deliveryStats: {
          sent: sentCount,
          delivered: 0,
          opened: 0,
          failed: failedCount,
        },
      };
      await persistCommunicationSummary(commSummary, user, state);

      db.addAuditLog(
        'Email Communication Dispatched',
        'Communications & Email',
        `Dispatched Email "${rawSubject}" (${sentCount} sent, ${failedCount} failed) to ${commSummary.targetAudience} via ${primaryLog.provider}`,
        user.name
      );

      if (targets.length === 1 && failedCount === 1) {
        return res.status(400).json({
          success: false,
          error: primaryLog.error_message || 'Failed to send Email.',
          log: primaryLog,
          logs: createdLogs,
        });
      }

      return res.status(201).json({
        success: sentCount > 0,
        message:
          targets.length === 1
            ? `Email sent to ${primaryLog.recipient} via ${primaryLog.provider}.`
            : `Email batch processed: ${sentCount} sent, ${failedCount} failed.`,
        sentCount,
        failedCount,
        log: primaryLog,
        logs: createdLogs,
        communication: commSummary,
      });
    } catch (err: any) {
      console.error('[POST /api/communications/email] Error:', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Internal server error while dispatching Email.',
      });
    }
  }
);

/**
 * POST /api/communications/broadcast
 * Sends targeted bulk SMS, Email, or Multi-Channel (SMS + Email) broadcasts using real database members/families/ministries/branches
 */
router.post(
  '/broadcast',
  requirePermission('communications.manage'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = req.user!;
      const {
        channel = 'SMS', // 'SMS' | 'EMAIL' | 'BOTH' | 'Multi-Channel'
        targetType = 'all_active', // 'all_active' | 'branch' | 'ministry' | 'family' | 'custom_members'
        branchId,
        ministryId,
        familyId,
        memberIds,
        subject = '',
        message = '',
        triggerType = 'Broadcast Campaign',
      } = req.body || {};

      const cleanMessage = String(message || '').trim();
      const cleanSubject = String(subject || '').trim() || 'Grace Cathedral Official Announcement';

      if (!cleanMessage) {
        return res.status(400).json({
          success: false,
          error: 'Broadcast message content cannot be empty.',
        });
      }

      const normChannel = String(channel).toUpperCase();
      const sendSmsChannel =
        normChannel === 'SMS' || normChannel === 'BOTH' || normChannel === 'MULTI-CHANNEL';
      const sendEmailChannel =
        normChannel === 'EMAIL' || normChannel === 'BOTH' || normChannel === 'MULTI-CHANNEL';

      if (!sendSmsChannel && !sendEmailChannel) {
        return res.status(400).json({
          success: false,
          error: 'Invalid communication channel. Specify SMS, EMAIL, or BOTH.',
        });
      }

      const state = db.getState();
      const allMembers: Member[] = isPgConfigured()
        ? await listCommunicationMembers(user, targetType === 'branch' ? branchId : undefined)
        : (state.members || []).filter(
            (m) => !m.tenantId || isSameTenant(m.tenantId, user.tenantId)
          );

      let targetMembers: Member[] = [];
      let audienceLabel = 'All Active Members';

      if (targetType === 'custom_members' && Array.isArray(memberIds) && memberIds.length > 0) {
        const idSet = new Set(memberIds.map(String));
        targetMembers = allMembers.filter((m) => idSet.has(m.id));
        audienceLabel = `Selected Members (${targetMembers.length})`;
      } else if (targetType === 'family' && familyId) {
        const fam = await findFamilyInDb(familyId, req.user);
        if (!fam) {
          return res.status(404).json({
            success: false,
            error: 'Selected family/household was not found in the database.',
          });
        }
        const famMemberIds = new Set(fam.memberIds || [fam.headOfHouseholdMemberId]);
        targetMembers = allMembers.filter(
          (m) => m.familyId === fam.id || famMemberIds.has(m.id)
        );
        audienceLabel = `Household: ${fam.householdName}`;
      } else if (targetType === 'ministry' && ministryId) {
        const min = await findMinistryInDb(ministryId, req.user);
        if (!min) {
          return res.status(404).json({
            success: false,
            error: 'Selected ministry was not found in the database.',
          });
        }
        const minMemberIds = new Set(min.memberIds || []);
        targetMembers = allMembers.filter(
          (m) =>
            (m.ministryIds || []).includes(min.id) ||
            minMemberIds.has(m.id) ||
            (m.ministriesJoinedNow || []).some(
              (name) => name.toLowerCase() === min.name.toLowerCase()
            )
        );
        audienceLabel = `Ministry: ${min.name}`;
      } else if (targetType === 'branch' && branchId) {
        const br = await findBranchInDb(branchId, req.user);
        targetMembers = allMembers.filter((m) => m.branchId === branchId);
        audienceLabel = `Campus: ${br?.name || branchId}`;
      } else {
        // Default: all_active
        targetMembers = allMembers.filter(
          (m) =>
            m.membershipStatus === 'Active' &&
            !m.departureReason
        );
        if (!user.branchIds.includes('*')) {
          targetMembers = targetMembers.filter((m) =>
            user.branchIds.some((b) => isSameCampus(b, m.branchId))
          );
        }
        audienceLabel = 'All Active Members';
      }

      if (targetMembers.length === 0) {
        return res.status(400).json({
          success: false,
          error: `No members found in the database matching target audience "${audienceLabel}".`,
        });
      }

      const createdLogs: CommunicationLog[] = [];
      let sentCount = 0;
      let failedCount = 0;
      let skippedCount = 0;

      // Deduplicate phones & emails within a single broadcast run so shared household phones aren't spammed
      const seenSmsRecipients = new Set<string>();
      const seenEmailRecipients = new Set<string>();

      for (const mem of targetMembers) {
        const famObj = mem.familyId
          ? await findFamilyInDb(mem.familyId, req.user)
          : null;
        const minObj = ministryId
          ? await findMinistryInDb(ministryId, req.user)
          : null;
        const branchObj = mem.branchId
          ? await findBranchInDb(mem.branchId, req.user)
          : null;

        const personalizedSubject = interpolateMessageTemplate(cleanSubject, {
          member: mem,
          family: famObj,
          ministry: minObj,
          branch: branchObj,
        });
        const personalizedMessage = interpolateMessageTemplate(cleanMessage, {
          member: mem,
          family: famObj,
          ministry: minObj,
          branch: branchObj,
        });
        const fullName = `${mem.title || ''} ${mem.firstName} ${mem.lastName}`.trim();

        if (sendSmsChannel) {
          const rawPhone = (mem.primaryPhone || mem.altPhone || '').trim();
          if (!rawPhone) {
            skippedCount++;
          } else {
            const phoneCheck = smsService.validateAndNormalizePhone(rawPhone);
            const dedupKey = phoneCheck.normalized || rawPhone;
            if (!seenSmsRecipients.has(dedupKey)) {
              seenSmsRecipients.add(dedupKey);
              const smsRes = await smsService.sendSms({
                recipient: rawPhone,
                message: personalizedMessage,
              });
              if (smsRes.success) sentCount++;
              else failedCount++;

              const smsLog = await communicationLogService.recordLog({
                tenantId: user.tenantId,
                branchId: mem.branchId || user.branchId,
                channel: 'SMS',
                recipient: smsRes.normalizedRecipient || rawPhone,
                recipientName: fullName,
                memberId: mem.id,
                familyId: mem.familyId || familyId || null,
                ministryId: ministryId || null,
                subject: personalizedSubject,
                message: personalizedMessage,
                status: smsRes.status,
                provider: smsRes.provider,
                providerMessageId: smsRes.providerMessageId,
                errorMessage: smsRes.errorMessage,
                triggerType,
                sentAt: smsRes.sentAt,
                deliveredAt: smsRes.deliveredAt,
                createdBy: user.id,
                createdByName: user.name,
              });
              createdLogs.push(smsLog);
            }
          }
        }

        if (sendEmailChannel) {
          const rawEmail = (mem.email || '').trim().toLowerCase();
          if (!rawEmail) {
            skippedCount++;
          } else if (!seenEmailRecipients.has(rawEmail)) {
            seenEmailRecipients.add(rawEmail);
            const emailRes = await emailService.sendEmail({
              recipient: rawEmail,
              subject: personalizedSubject,
              message: personalizedMessage,
            });
            if (emailRes.success) sentCount++;
            else failedCount++;

            const emailLog = await communicationLogService.recordLog({
              tenantId: user.tenantId,
              branchId: mem.branchId || user.branchId,
              channel: 'EMAIL',
              recipient: emailRes.recipient || rawEmail,
              recipientName: fullName,
              memberId: mem.id,
              familyId: mem.familyId || familyId || null,
              ministryId: ministryId || null,
              subject: personalizedSubject,
              message: personalizedMessage,
              status: emailRes.status,
              provider: emailRes.provider,
              providerMessageId: emailRes.providerMessageId,
              errorMessage: emailRes.errorMessage,
              triggerType,
              sentAt: emailRes.sentAt,
              deliveredAt: emailRes.deliveredAt,
              createdBy: user.id,
              createdByName: user.name,
            });
            createdLogs.push(emailLog);
          }
        }
      }

      const totalDispatched = sentCount + failedCount;
      const deliveryRate =
        totalDispatched > 0 ? Math.round((sentCount / totalDispatched) * 100) : 0;

      const commRecord: CommunicationMessage = {
        id: `comm-bcast-${Date.now()}`,
        tenantId: user.tenantId,
        branchId: branchId || user.branchId,
        subject: cleanSubject,
        body: cleanMessage,
        senderRole: user.role,
        channel:
          sendSmsChannel && sendEmailChannel
            ? 'Multi-Channel'
            : sendEmailChannel
            ? 'Email'
            : 'SMS',
        triggerType,
        targetAudience: audienceLabel,
        recipientCount: totalDispatched,
        sentAt: new Date().toISOString(),
        status: sentCount > 0 ? 'Sent' : 'Failed',
        // Provider acceptance is not a delivery receipt or an open event.
        // Until provider callbacks are integrated, report only confirmed sends.
        deliveryRatePercentage: 0,
        deliveryStats: {
          sent: sentCount,
          delivered: 0,
          opened: 0,
          failed: failedCount,
        },
      };

      await persistCommunicationSummary(commRecord, user, state);

      db.addAuditLog(
        'Broadcast Communication Sent',
        'Communications',
        `Broadcast "${cleanSubject}" to ${audienceLabel} (${sentCount} sent, ${failedCount} failed, ${skippedCount} skipped missing contact)`,
        user.name
      );

      return res.status(201).json({
        success: sentCount > 0,
        message: `Broadcast completed: ${sentCount} sent, ${failedCount} failed, ${skippedCount} skipped.`,
        targetAudience: audienceLabel,
        totalTargetedMembers: targetMembers.length,
        sentCount,
        failedCount,
        skippedCount,
        deliveryRatePercentage: deliveryRate,
        communication: commRecord,
        logs: createdLogs,
      });
    } catch (err: any) {
      console.error('[POST /api/communications/broadcast] Error:', err);
      return res.status(500).json({
        success: false,
        error: err?.message || 'Internal server error during broadcast dispatch.',
      });
    }
  }
);

/**
 * POST /api/communications/retry/:id
 * Retries a previously FAILED communication log record
 */
router.post(
  '/retry/:id',
  requirePermission('communications.manage'),
  async (req: AuthenticatedRequest, res: Response) => {
    let retryClaimed = false;
    try {
      const user = req.user!;
      const { id } = req.params;
      let existing: CommunicationLog | undefined;
      if (isPgConfigured()) {
        const retryBranchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(
          (value): value is string => typeof value === 'string' && isDatabaseUuid(value)
        ))];
        const result = user.branchIds?.includes('*')
          ? await query<CommunicationLog>(
              'SELECT * FROM communication_logs WHERE id = $1 AND tenant_id = $2 LIMIT 1',
              [id, user.tenantId]
            )
          : await query<CommunicationLog>(
              'SELECT * FROM communication_logs WHERE id = $1 AND tenant_id = $2 AND (branch_id IS NULL OR branch_id = ANY($3::uuid[])) LIMIT 1',
              [id, user.tenantId, retryBranchIds]
            );
        existing = result.rows[0];
      } else {
        existing = (db.getState().communicationLogs || []).find((l) => l.id === id && (!l.tenant_id || isSameTenant(l.tenant_id, user.tenantId)));
      }

      if (!existing) {
        return res.status(404).json({
          success: false,
          error: 'Communication log record not found.',
        });
      }

      if (
        existing.branch_id &&
        !user.branchIds.includes('*') &&
        !user.branchIds.some((b) => isSameCampus(b, existing!.branch_id)) &&
        !isSameCampus(user.branchId, existing.branch_id)
      ) {
        return res.status(403).json({
          success: false,
          error: 'Access denied: communication log belongs to another branch.',
        });
      }

      if (existing.status !== 'FAILED') {
        return res.status(409).json({
          success: false,
          error: 'Only failed communications can be retried. This record may already be queued, sent, or delivered.',
          code: 'COMMUNICATION_NOT_RETRYABLE',
        });
      }

      // Claim before contacting the provider so repeated requests cannot resend a completed log.
      const claimed = await communicationLogService.claimRetry(id, user.tenantId);
      if (!claimed) {
        return res.status(409).json({
          success: false,
          error: 'This communication is no longer eligible for retry.',
          code: 'COMMUNICATION_RETRY_ALREADY_CLAIMED',
        });
      }
      existing = claimed;
      retryClaimed = true;

      if (existing.channel === 'SMS') {
        const smsRes = await smsService.sendSms({
          recipient: existing.recipient,
          message: existing.message,
        });

        const updated = await communicationLogService.updateLog(id, user.tenantId, {
          status: smsRes.status,
          provider: smsRes.provider,
          provider_message_id: smsRes.providerMessageId,
          error_message: smsRes.errorMessage,
          sent_at: smsRes.sentAt,
          delivered_at: smsRes.deliveredAt,
        });

        db.addAuditLog(
          'Retried SMS Communication',
          'Communications & SMS',
          `Retried SMS log #${id} to ${existing.recipient} -> ${smsRes.status}`,
          user.name
        );

        return res.json({
          success: smsRes.success,
          log: updated,
          error: smsRes.errorMessage,
        });
      } else {
        const emailRes = await emailService.sendEmail({
          recipient: existing.recipient,
          subject: existing.subject || 'Grace Cathedral Notification',
          message: existing.message,
        });

        const updated = await communicationLogService.updateLog(id, user.tenantId, {
          status: emailRes.status,
          provider: emailRes.provider,
          provider_message_id: emailRes.providerMessageId,
          error_message: emailRes.errorMessage,
          sent_at: emailRes.sentAt,
          delivered_at: emailRes.deliveredAt,
        });

        db.addAuditLog(
          'Retried Email Communication',
          'Communications & Email',
          `Retried Email log #${id} to ${existing.recipient} -> ${emailRes.status}`,
          user.name
        );

        return res.json({
          success: emailRes.success,
          log: updated,
          error: emailRes.errorMessage,
        });
      }
    } catch (err: any) {
      if (retryClaimed && req.user?.tenantId) {
        try {
          await communicationLogService.markRetryOutcomeUnknown(
            req.params.id,
            req.user.tenantId,
            err?.message || 'Provider dispatch or result persistence failed.'
          );
        } catch (reconciliationError: any) {
          console.error('[Communications] Retry outcome could not be recorded:', reconciliationError);
          return res.status(503).json({
            success: false,
            code: 'COMMUNICATION_RETRY_RECONCILIATION_FAILED',
            error: 'The provider outcome is uncertain and could not be recorded. Do not retry this message until an administrator reconciles provider delivery.',
          });
        }
        return res.status(502).json({
          success: false,
          code: 'COMMUNICATION_RETRY_OUTCOME_UNKNOWN',
          error: 'The provider outcome is uncertain. The message remains queued and must be reconciled before another retry; do not resend automatically.',
        });
      }
      return res.status(500).json({
        success: false,
        error: err?.message || 'Failed to retry communication.',
      });
    }
  }
);

export default router;
