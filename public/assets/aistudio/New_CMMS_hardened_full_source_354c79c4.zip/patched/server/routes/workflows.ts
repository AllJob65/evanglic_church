import { Router, Response } from 'express';
import { db } from '../db';
import { WorkflowRequest, Member, ProfileChangeRequest } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  verifyResourceAccess,
  AuthenticatedRequest,
} from '../../src/security/authorization';

const router = Router();

// Apply authentication to all workflow routes
router.use(authenticateToken);

const PROFILE_FIELD_LABELS: Record<string, string> = {
  title: 'Title',
  firstName: 'First Name',
  middleName: 'Middle Name',
  lastName: 'Last Name',
  gender: 'Gender',
  dateOfBirth: 'Date of Birth',
  nationality: 'Nationality',
  nationalIdNumber: 'National ID Number',
  passportNumber: 'Passport Number',
  photoUrl: 'Member Photo & Profile Avatar',
  maritalStatus: 'Marital Status',
  marriageDate: 'Marriage Date (Wedding Date)',
  divorceDate: 'Divorce Date',
  spouseName: 'Spouse Full Name',
  spousePhone: 'Spouse Phone Number',
  spouseMemberId: 'Spouse Member ID',
  maleChildrenCount: 'Male Children',
  femaleChildrenCount: 'Female Children',
  adoptedChildrenCount: 'Adopted Children',
  primaryPhone: 'Primary Phone Number',
  altPhone: 'Alternative Phone',
  email: 'Email Address',
  preferredCommChannel: 'Preferred Communication',
  woreda: 'Woreda (Worda)',
  kebele: 'Kebele',
  houseNumber: 'House Number',
  streetAddress: 'Street Address',
  city: 'Sub-City / City',
  subCity: 'Sub-City',
  region: 'Region / State',
  postalCode: 'Postal Code',
  branchId: 'Assigned Campus Branch',
  membershipDate: 'Membership Date',
  membershipLocation: 'Membership Received Location / Church',
  salvationDate: 'Salvation Date',
  salvationLocation: 'Where Saved (Church / City / Location)',
  isWaterBaptized: 'Is Water Baptized?',
  waterBaptismDate: 'Baptism Date',
  waterBaptismLocation: 'Where Baptized (Church / Lake / Location)',
  isHolySpiritBaptized: 'Holy Spirit Baptized',
  foundationCourseCompleted: 'Foundation Class Completed',
  membershipStatus: 'Membership Status',
  departureReason: 'Reason for Departure / Status Change',
  departureDate: 'Status / Departure Date',
  departureEndDate: 'Excommunication End Date',
  excommunicationDescription: 'Excommunication Description & Official Decree',
  excommunicationPaperName: 'Paper of Excommunication',
  educationLevel: 'Education Level',
  fieldOfStudy: 'Field of Study',
  occupation: 'Occupation / Profession',
  employerName: 'Employer / Organization',
  employerType: 'Employer Type',
  employerTypeOther: 'Specify Other Employer Type',
  emergencyContact: 'Emergency Contact Info',
  bloodType: 'Blood Type',
  ministryIds: 'Ministries Enrolled',
  ministriesJoinedNow: 'Ministries Joined Now',
  ministriesServedBefore: 'Past Ministries Served',
};

// GET all profile change requests
router.get('/profile-changes', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const state = db.getState();
  const list = state.profileChangeRequests || [];

  if (user.role === 'REGULAR_MEMBER') {
    const own = list.filter(
      (r) =>
        r.memberId === user.id ||
        r.memberId === user.memberId ||
        (r.memberEmail && user.email && r.memberEmail.toLowerCase() === user.email.toLowerCase())
    );
    return res.json(own);
  }

  return res.json(list);
});

// POST submit a new profile change request
router.post('/profile-changes', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const body = req.body || {};
  const memberId = body.memberId || user.memberId || user.id;
  const changes: Partial<Member> = body.changes || body.newSnapshot || body.requestedChanges || {};

  const state = db.getState();
  if (!Array.isArray(state.profileChangeRequests)) {
    state.profileChangeRequests = [];
  }

  const existingMember =
    state.members.find((m) => m.id === memberId) ||
    (user.email ? state.members.find((m) => m.email?.toLowerCase() === user.email.toLowerCase()) : undefined);

  const changedFields: ProfileChangeRequest['changedFields'] =
    Array.isArray(body.changedFields) && body.changedFields.length > 0 ? body.changedFields : [];

  if (changedFields.length === 0) {
    Object.entries(changes).forEach(([key, val]) => {
      if (val !== undefined) {
        const oldVal = existingMember
          ? (existingMember as any)[key]
          : body.previousSnapshot
          ? body.previousSnapshot[key]
          : '';
        const formatVal = (v: any) => {
          if (v === null || v === undefined) return '';
          if (typeof v === 'object') return JSON.stringify(v);
          return String(v);
        };
        const oldStr = formatVal(oldVal);
        const newStr = formatVal(val);
        if (oldStr !== newStr) {
          changedFields.push({
            fieldKey: key,
            fieldLabel: PROFILE_FIELD_LABELS[key] || key,
            oldValue: oldVal ?? '',
            newValue: val,
          });
        }
      }
    });
  }

  const newRequest: ProfileChangeRequest = {
    id: body.id || `pcr-${Date.now().toString().slice(-6)}`,
    memberId: existingMember?.id || memberId,
    memberIdNumber: existingMember?.memberIdNumber || body.memberIdNumber || 'CMMS-MEMBER',
    memberName:
      body.memberName ||
      (existingMember ? `${existingMember.firstName} ${existingMember.lastName}`.trim() : user.name || 'Member'),
    memberEmail: existingMember?.email || body.memberEmail || user.email || '',
    submittedAt: body.submittedAt || new Date().toISOString().replace('T', ' ').substring(0, 19),
    status: 'Pending',
    changedFields,
    newSnapshot: changes,
    requestedChanges: changes,
  };

  state.profileChangeRequests.unshift(newRequest);
  db.persist();

  db.addAuditLog(
    'Submitted Profile Change Request',
    'Member Portal & Approvals',
    `Member ${newRequest.memberName} (${newRequest.memberIdNumber}) requested ${changedFields.length} field updates. Pending Administrator Authorization.`,
    user.email
  );

  return res.status(201).json({
    success: true,
    request: newRequest,
  });
});

// PUT approve or reject a profile change request
router.put('/profile-changes/:id/status', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  if (user.role === 'REGULAR_MEMBER') {
    return res.status(403).json({ error: 'Forbidden: Administrative authorization required.' });
  }

  const id = req.params.id;
  const { status, adminNotes, rejectionReason, reviewedBy } = req.body || {};

  if (status !== 'Approved' && status !== 'Rejected') {
    return res.status(400).json({ error: 'Invalid status. Must be Approved or Rejected.' });
  }

  const state = db.getState();
  if (!Array.isArray(state.profileChangeRequests)) {
    state.profileChangeRequests = [];
  }

  const reqIndex = state.profileChangeRequests.findIndex((r) => r.id === id);
  if (reqIndex === -1) {
    return res.status(404).json({ error: 'Profile change request not found.' });
  }

  const targetReq = state.profileChangeRequests[reqIndex];

  // A profile-change approval must never become member registration.
  // Resolve the existing member before mutating the request so a missing or
  // stale member reference leaves the request pending and unchanged.
  const approvedMember = status === 'Approved'
    ? state.members.find(
        (m) =>
          m.id === targetReq.memberId ||
          (targetReq.memberEmail && m.email?.toLowerCase() === targetReq.memberEmail.toLowerCase())
      )
    : undefined;
  if (status === 'Approved' && !approvedMember) {
    return res.status(409).json({
      error: 'The member linked to this profile-change request no longer exists. The request was not approved.',
      code: 'PROFILE_CHANGE_MEMBER_NOT_FOUND',
    });
  }

  const reviewer = user.name || user.email || 'System Administrator';
  const reviewedAt = new Date().toISOString().replace('T', ' ').substring(0, 19);

  targetReq.status = status;
  targetReq.reviewedBy = reviewer;
  targetReq.reviewedAt = reviewedAt;
  if (status === 'Rejected') {
    targetReq.rejectionReason = rejectionReason || adminNotes || 'Declined by administrator';
  }

  let updatedMember: Member | undefined;

  if (status === 'Approved') {
    const snapshot = targetReq.newSnapshot || targetReq.requestedChanges || {};
    if (!approvedMember) {
      // Defensive guard: approval was prevalidated above before request mutation.
      return res.status(409).json({
        error: 'The member linked to this profile-change request no longer exists. The request was not approved.',
        code: 'PROFILE_CHANGE_MEMBER_NOT_FOUND',
      });
    }
    const memIdx = state.members.findIndex((m) => m.id === approvedMember.id);
    state.members[memIdx] = {
      ...approvedMember,
      ...snapshot,
      // Prevent request payloads from changing identity and tenancy keys.
      id: approvedMember.id,
      tenantId: approvedMember.tenantId,
      branchId: approvedMember.branchId,
      lastActive: new Date().toISOString().split('T')[0],
    };
    updatedMember = state.members[memIdx];

    const sysUserIdx = (state.systemUsers || []).findIndex(
      (u) =>
        u.id === targetReq.memberId ||
        (targetReq.memberEmail && u.email?.toLowerCase() === targetReq.memberEmail.toLowerCase())
    );
    if (sysUserIdx !== -1) {
      const u = state.systemUsers[sysUserIdx];
      if (snapshot.firstName || snapshot.lastName) {
        u.name = [snapshot.firstName || u.name.split(' ')[0], snapshot.middleName, snapshot.lastName || u.name.split(' ').slice(1).join(' ')]
          .filter(Boolean)
          .join(' ')
          .trim();
      }
      if (snapshot.primaryPhone) u.phone = snapshot.primaryPhone;
      if (snapshot.photoUrl) u.photoUrl = snapshot.photoUrl;
      if (snapshot.branchId) u.branchId = snapshot.branchId;
    }
  }

  db.persist();
  db.addAuditLog(
    status === 'Approved' ? 'Authorized Member Profile Update' : 'Rejected Member Profile Update',
    'Administration & Approvals',
    status === 'Approved'
      ? `Approved and committed profile changes for ${targetReq.memberName} (${targetReq.memberIdNumber}). ${targetReq.changedFields.length} fields updated in database.`
      : `Declined profile change request for ${targetReq.memberName} (${targetReq.memberIdNumber}). Reason: ${targetReq.rejectionReason}`,
    user.email
  );

  return res.json({
    success: true,
    request: targetReq,
    member: updatedMember,
  });
});

// GET all workflows - Enforce workflows.read
router.get('/', requirePermission('workflows.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { type, status, branchId } = req.query;
  let list = db.getState().workflows || [];

  // Tenant Isolation
  list = list.filter((w) => !w.tenantId || w.tenantId === user.tenantId);

  // If Regular Member, only view own submitted workflows
  if (user.role === 'REGULAR_MEMBER') {
    list = list.filter(
      (w) =>
        w.requesterId === user.id ||
        (user.memberId && w.requesterId === user.memberId) ||
        (w.requesterEmail && w.requesterEmail.toLowerCase() === user.email.toLowerCase())
    );
  } else {
    // Branch Isolation for pastoral staff
    if (!user.branchIds.includes('*')) {
      list = list.filter((w) => !w.branchId || user.branchIds.includes(w.branchId));
    } else if (branchId && branchId !== 'all') {
      list = list.filter((w) => w.branchId === branchId);
    }
  }

  if (type && type !== 'all') {
    list = list.filter((w) => w.requestType === type);
  }

  if (status && status !== 'all') {
    list = list.filter((w) => w.status === status);
  }

  return res.json(list);
});

// GET workflow by ID - IDOR Protected
router.get('/:id', requirePermission('workflows.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const wf = (db.getState().workflows || []).find((w) => w.id === id);

  if (!wf) {
    return res.status(404).json({ error: 'Workflow request not found' });
  }

  const access = verifyResourceAccess(wf, user, { checkOwnership: user.role === 'REGULAR_MEMBER' });
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  return res.json(wf);
});

// POST create workflow request (workflows.create)
router.post('/', requirePermission('workflows.create'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const data: WorkflowRequest = req.body;

  const newWf: WorkflowRequest = {
    ...data,
    id: data.id || `wf-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: data.branchId || user.branchId,
    requesterId: user.role === 'REGULAR_MEMBER' ? user.id : (data.requesterId || user.id),
    requesterName: user.role === 'REGULAR_MEMBER' ? user.name : (data.requesterName || user.name),
    requesterEmail: user.role === 'REGULAR_MEMBER' ? user.email : (data.requesterEmail || user.email),
    requestCode: data.requestCode || `REQ-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    submittedDate: data.submittedDate || new Date().toISOString().slice(0, 10),
    status: 'Pending',
  };

  const currentWfs = db.getState().workflows || [];
  db.getState().workflows = [newWf, ...currentWfs];
  db.persist();

  db.addAuditLog(
    'Created Workflow',
    'Governance & Approvals',
    `Initiated workflow ${newWf.requestCode} (${newWf.requestType}) for ${newWf.requesterName}`,
    user.name
  );

  return res.status(201).json({ success: true, workflow: newWf });
});

// PUT /api/workflows/:id/status (Approve / Reject / Escalate) - Requires workflows.manage
router.put('/:id/status', requirePermission('workflows.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { status, comments, reason } = req.body;

  const workflows = db.getState().workflows || [];
  const targetIndex = workflows.findIndex((w) => w.id === id);

  if (targetIndex === -1) {
    return res.status(404).json({ error: 'Workflow request not found' });
  }

  const targetWf = workflows[targetIndex];

  // IDOR & branch access check
  const access = verifyResourceAccess(targetWf, user);
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  targetWf.status = status;
  const decisionComments = comments || reason || targetWf.comments || '';
  targetWf.comments = decisionComments;

  if (status === 'Approved') {
    // Verified approver derived directly from authenticated identity
    targetWf.approvedBy = `${user.name} (${user.role})`;
    targetWf.approvedAt = new Date().toISOString();

    // If approving a Membership Application, activate or promote pending member in the database
    if (targetWf.requestType === 'Membership Application' && targetWf.pendingMemberData) {
      const pData = targetWf.pendingMemberData as any;
      const state = db.getState();
      const members = state.members || [];
      const existingMemberIndex = members.findIndex(
        (m) =>
          m.id === pData.id ||
          m.memberIdNumber === pData.memberIdNumber ||
          (pData.email && m.email?.toLowerCase() === pData.email.toLowerCase())
      );

      if (existingMemberIndex >= 0) {
        members[existingMemberIndex].membershipStatus = 'Active';
      } else {
        const newMember: Member = {
          id: pData.id || `mem-${Date.now()}`,
          tenantId: user.tenantId,
          memberIdNumber: pData.memberIdNumber || `GC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          title: pData.title || 'Brother',
          firstName: pData.firstName || 'Member',
          middleName: pData.middleName || '',
          lastName: pData.lastName || '',
          gender: pData.gender || 'Male',
          dateOfBirth: pData.dateOfBirth || '2000-01-01',
          streetAddress: pData.streetAddress || 'Main Church Ave',
          city: pData.city || 'Addis Ababa',
          emergencyContact: pData.emergencyContact || {
            name: 'Church Admin',
            relationship: 'Office',
            phone: pData.primaryPhone || targetWf.requesterPhone || '+251911000000',
          },
          ministryIds: pData.ministryIds || [],
          primaryPhone: pData.primaryPhone || targetWf.requesterPhone || '',
          email: pData.email || targetWf.requesterEmail || '',
          branchId: pData.branchId || targetWf.branchId || user.branchId,
          membershipStatus: 'Active',
          membershipType: pData.membershipType || 'Full Member',
          membershipDate: new Date().toISOString().slice(0, 10),
          waterBaptized: pData.waterBaptized ?? true,
          attendanceScore: 100,
          createdAt: new Date().toISOString(),
          lastActive: new Date().toISOString(),
        };
        members.unshift(newMember);
      }

      // Activate user account
      const systemUsers = state.systemUsers || [];
      const email = (targetWf.requesterEmail || pData.email || '').toLowerCase();
      let existingUser = systemUsers.find((u) => u.email?.toLowerCase() === email);
      if (existingUser) {
        existingUser.status = 'Active';
      }
    }
  } else if (status === 'Rejected') {
    targetWf.rejectedReason = reason || decisionComments || 'Rejected by administration';
  }

  db.persist();

  db.addAuditLog(
    `Workflow ${status}`,
    'Governance & Approvals',
    `Workflow request #${targetWf.requestCode} updated to ${status} by ${user.name}`,
    user.name
  );

  return res.json({
    success: true,
    workflow: targetWf,
  });
});

export default router;
