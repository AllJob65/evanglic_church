import { Router, Response } from 'express';
import { Member, Family } from '../../src/types';
import { isDatabaseUuid, listMembers, getMemberById, createMemberRecord, updateMemberRecord, deleteMemberRecord } from '../repositories/memberRepository';
import type { MemberScope } from '../repositories/memberRepository';
import { query } from '../pg';
import {
  authenticateToken,
  requirePermission,
  verifyResourceAccess,
  AuthenticatedRequest,
} from '../../src/security/authorization';

const router = Router();

// Apply authentication to all member routes
router.use(authenticateToken);

// PostgreSQL is the authoritative source for member records on this route.

const asyncRoute = (handler: (req: AuthenticatedRequest, res: Response) => Promise<unknown>) =>
  (req: AuthenticatedRequest, res: Response, next: (error?: unknown) => void) =>
    Promise.resolve(handler(req, res)).catch(next);

function resolveMemberScope(user: NonNullable<AuthenticatedRequest['user']>, requestedBranch?: unknown): MemberScope {
  if (!isDatabaseUuid(user.tenantId)) throw new Error('Your account is not assigned to a valid database tenant. Contact a system administrator.');
  const allBranches = user.branchIds.includes('*');
  const branchIds = [...new Set([...user.branchIds.filter(isDatabaseUuid), ...(isDatabaseUuid(user.branchId) ? [user.branchId] : [])])];
  const branchId = typeof requestedBranch === 'string' && requestedBranch !== 'all'
    ? requestedBranch
    : undefined;
  if (branchId && !isDatabaseUuid(branchId)) throw new Error('The selected branch is not linked to a valid database branch.');
  if (!allBranches && branchId && !branchIds.includes(branchId) && branchId !== user.branchId) {
    throw new Error('Branch access denied.');
  }
  return { tenantId: user.tenantId, branchIds, branchId, allBranches };
}

function csvCell(value: unknown): string {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}

async function recordMemberAudit(req: AuthenticatedRequest, action: string, details: string): Promise<void> {
  const actor = req.user!;
  if (!isDatabaseUuid(actor.id) || !isDatabaseUuid(actor.tenantId)) return;
  try {
    await query(
      `INSERT INTO public.audit_logs
        (tenant_id,user_id,user_email,user_name,user_role,action,module,details,ip_address)
       VALUES ($1::uuid,$2::uuid,$3,$4,$5,$6,'Membership',$7,$8)`,
      [actor.tenantId,actor.id,actor.email||null,actor.name||null,actor.role,action,details,req.ip||null]
    );
  } catch (error) {
    // The member write must not be reported as failed after it has committed.
    console.error('[Member Audit] Failed to append audit event:', error instanceof Error ? error.message : error);
  }
}

// GET all members (keeps the existing array response and optional paginated envelope).
router.get('/', requirePermission('members.read'), asyncRoute(async (req, res) => {
  const user = req.user!;
  const scope = resolveMemberScope(user, req.query.branchId);
  const pageNum = req.query.page ? Number.parseInt(String(req.query.page), 10) : undefined;
  const limitValue = req.query.limit || req.query.pageSize;
  const limitNum = limitValue ? Number.parseInt(String(limitValue), 10) : undefined;
  if ((pageNum !== undefined && (!Number.isInteger(pageNum) || pageNum < 1)) ||
      (limitNum !== undefined && (!Number.isInteger(limitNum) || limitNum < 1))) {
    return res.status(400).json({ error: 'Invalid pagination parameters.' });
  }
  const page = pageNum || 1;
  const limit = limitNum ? Math.min(200, limitNum) : undefined;
  const result = await listMembers(scope, {
    search: typeof req.query.search === 'string' ? req.query.search : undefined,
    status: typeof req.query.status === 'string' ? req.query.status : undefined,
    limit,
    offset: limit ? (page - 1) * limit : 0,
  });
  res.setHeader('X-Total-Count', String(result.total));
  if (limit) {
    const totalPages = Math.ceil(result.total / limit);
    res.setHeader('X-Page', String(page));
    res.setHeader('X-Per-Page', String(limit));
    res.setHeader('X-Total-Pages', String(totalPages));
    if (req.query.paginated === 'true') {
      return res.json({ data: result.members, pagination: { total: result.total, page, limit, totalPages, hasMore: page < totalPages } });
    }
  }
  return res.json(result.members);
}));

// CSV export is generated from the same PostgreSQL query and access scope.
router.get('/export/csv', requirePermission('members.export'), asyncRoute(async (req, res) => {
  const scope = resolveMemberScope(req.user!, req.query.branchId);
  const { members } = await listMembers(scope);
  await recordMemberAudit(req,'EXPORT',`Exported ${members.length} member records to CSV`);
  const headers = ['Member ID','Title','First Name','Last Name','Gender','Phone','Email','Status','Branch','Marital Status','Membership Date'];
  const rows = members.map(m => [m.memberIdNumber || m.id,m.title,m.firstName,m.lastName,m.gender,m.primaryPhone,m.email,m.membershipStatus,m.branchId,m.maritalStatus,m.membershipDate].map(csvCell).join(','));
  res.setHeader('Content-Type','text/csv; charset=utf-8');
  res.setHeader('Content-Disposition',`attachment; filename="members_export_${Date.now()}.csv"`);
  return res.send([headers.join(','),...rows].join('\r\n'));
}));

router.get('/:id', requirePermission('members.read'), asyncRoute(async (req,res) => {
  const member=await getMemberById(req.params.id,resolveMemberScope(req.user!));
  if(!member) return res.status(404).json({error:'Member record not found'});
  return res.json(member);
}));

router.post('/', requirePermission('members.create'), asyncRoute(async (req,res) => {
  const input=req.body as Member;
  if(!input || typeof input.firstName!=='string' || !input.firstName.trim() || typeof input.lastName!=='string' || !input.lastName.trim()) {
    return res.status(400).json({error:'First name and last name are required'});
  }
  const scope=resolveMemberScope(req.user!,input.branchId);
  const targetBranch=input.branchId||req.user!.branchId;
  if(!isDatabaseUuid(targetBranch)) return res.status(400).json({error:'A valid database branch UUID is required.'});
  const saved=await createMemberRecord({...input,tenantId:scope.tenantId,branchId:targetBranch},scope);
  await recordMemberAudit(req,'CREATE',`Created member ${saved.memberIdNumber} (${saved.id})`);
  return res.status(201).json(saved);
}));

router.put('/:id', requirePermission('members.update'), asyncRoute(async (req,res) => {
  const input={...(req.body||{})} as Partial<Member>;
  delete (input as any).id;
  delete (input as any).tenantId;
  const saved=await updateMemberRecord(req.params.id,input,resolveMemberScope(req.user!));
  if(!saved) return res.status(404).json({error:'Member record not found'});
  await recordMemberAudit(req,'UPDATE',`Updated member ${saved.memberIdNumber} (${saved.id})`);
  return res.json(saved);
}));

router.post('/:id/depart', requirePermission('members.update'), asyncRoute(async (req,res) => {
  const {status,reason,notes,date}=req.body||{};
  const allowedStatuses=['Transferred','Deceased','Left Church','Excommunicated','Inactive','On Leave'];
  const nextStatus=allowedStatuses.includes(status)?status:'Transferred';
  const saved=await updateMemberRecord(req.params.id,{
    membershipStatus:nextStatus,
    departureReason:reason,
    departureNotes:notes,
    departureDate:date||new Date().toISOString().slice(0,10),
  } as Partial<Member>,resolveMemberScope(req.user!));
  if(!saved) return res.status(404).json({error:'Member record not found'});
  await recordMemberAudit(req,'STATUS_CHANGE',`Changed member ${saved.memberIdNumber} status to ${saved.membershipStatus}`);
  return res.json(saved);
}));

router.delete('/:id', requirePermission('members.delete'), asyncRoute(async (req,res) => {
  const deleted=await deleteMemberRecord(req.params.id,resolveMemberScope(req.user!));
  if(!deleted) return res.status(404).json({error:'Member record not found'});
  await recordMemberAudit(req,'DELETE',`Deleted member record ${req.params.id}`);
  return res.json({success:true,deletedId:req.params.id});
}));

router.post('/bulk', requirePermission('members.create'), asyncRoute(async (req,res) => {
  const rows=req.body?.members;
  if(!Array.isArray(rows)) return res.status(400).json({error:'Invalid members list'});
  if(rows.length>500) return res.status(413).json({error:'Bulk import is limited to 500 records per request.'});
  const created:Member[]=[];
  for(const item of rows) {
    if(!item || typeof item.firstName!=='string' || typeof item.lastName!=='string') continue;
    const targetBranch=item.branchId||req.user!.branchId;
    if(!isDatabaseUuid(targetBranch)) return res.status(400).json({error:'A valid database branch UUID is required for every imported member.',createdCount:created.length,created});
    const scope=resolveMemberScope(req.user!,targetBranch);
    try { created.push(await createMemberRecord({...item,branchId:targetBranch,tenantId:req.user!.tenantId} as Member,scope)); }
    catch(error) { return res.status(400).json({error:error instanceof Error?error.message:'Bulk import failed',createdCount:created.length,created}); }
  }
  await recordMemberAudit(req,'BULK_IMPORT',`Imported ${created.length} member records`);
  return res.status(201).json({count:created.length,members:created});
}));

router.post('/:id/transfer-branch', requirePermission('members.update'), asyncRoute(async (req,res) => {
  const newBranchId=req.body?.newBranchId;
  if(!isDatabaseUuid(newBranchId)) return res.status(400).json({error:'A valid destination branch UUID is required.'});
  const scope=resolveMemberScope(req.user!);
  const saved=await updateMemberRecord(req.params.id,{branchId:newBranchId},scope);
  if(!saved) return res.status(404).json({error:'Member record not found'});
  await recordMemberAudit(req,'BRANCH_TRANSFER',`Transferred member ${saved.memberIdNumber} to branch ${newBranchId}`);
  return res.json(saved);
}));

// ==============================================================================
// FAMILIES ROUTES - PostgreSQL is authoritative for household records.
type FamilyDbRow = {
  id:string;tenant_id:string;branch_id:string|null;family_code:string;household_name:string;
  head_member_id:string;primary_phone:string|null;family_type:Family['familyType'];family_photo_url:string|null;
  primary_language:string;address:string;woreda:string|null;kebele:string|null;house_number:string|null;
  city:string;region:string;member_ids:unknown;relationships:unknown;registration_date:string|null;status:Family['status'];
};
function mapFamilyRow(row:FamilyDbRow):Family {
  return {
    id:row.id,tenantId:row.tenant_id,branchId:row.branch_id||undefined,familyCode:row.family_code,
    householdName:row.household_name,headOfHouseholdMemberId:row.head_member_id,
    primaryHouseholdPhone:row.primary_phone||undefined,familyType:row.family_type,
    familyPhotoUrl:row.family_photo_url||undefined,primaryLanguage:row.primary_language,
    address:row.address,woreda:row.woreda||undefined,kebele:row.kebele||undefined,
    houseNumber:row.house_number||undefined,city:row.city,region:row.region,
    memberIds:Array.isArray(row.member_ids)?row.member_ids as string[]:[],
    relationships:Array.isArray(row.relationships)?row.relationships as Family['relationships']:[],
    registrationDate:row.registration_date||new Date().toISOString().slice(0,10),status:row.status,
  };
}
async function validateFamilyReferences(input:Partial<Family>,tenantId:string,branchId:string):Promise<void>{
  const branch=await query('SELECT id FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid',[branchId,tenantId]);
  if(!branch.rowCount)throw new Error('Selected branch does not belong to the authenticated tenant.');
  const head=input.headOfHouseholdMemberId;
  if(!isDatabaseUuid(head))throw new Error('A valid head-of-household member UUID is required.');
  const ids=Array.from(new Set([head,...(Array.isArray(input.memberIds)?input.memberIds:[])].filter(isDatabaseUuid)));
  if(ids.length!==(new Set([head,...(Array.isArray(input.memberIds)?input.memberIds:[])])).size)throw new Error('Family members must use valid member UUIDs.');
  const found=await query('SELECT id FROM public.members WHERE tenant_id=$1::uuid AND id=ANY($2::uuid[])',[tenantId,ids]);
  if(found.rowCount!==ids.length)throw new Error('One or more selected family members do not belong to this tenant.');
}
const familySelect=`SELECT id,tenant_id,branch_id,family_code,household_name,head_member_id,primary_phone,
 family_type,family_photo_url,primary_language,address,woreda,kebele,house_number,city,region,
 member_ids,relationships,registration_date,status FROM public.families`;

router.get('/families/all', requirePermission('families.read'), asyncRoute(async (req,res)=>{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  const allBranches=user.branchIds.includes('*');
  const branchIds=[...new Set([...user.branchIds.filter(isDatabaseUuid),...(isDatabaseUuid(user.branchId)?[user.branchId]:[])])];
  const result=allBranches
    ? await query<FamilyDbRow>(`${familySelect} WHERE tenant_id=$1::uuid ORDER BY household_name`,[user.tenantId])
    : await query<FamilyDbRow>(`${familySelect} WHERE tenant_id=$1::uuid AND (branch_id=ANY($2::uuid[]) OR branch_id IS NULL) ORDER BY household_name`,[user.tenantId,branchIds]);
  return res.json(result.rows.map(mapFamilyRow));
}));

router.get('/families/:id', requirePermission('families.read'), asyncRoute(async (req,res)=>{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and family UUIDs are required.'});
  const result=await query<FamilyDbRow>(`${familySelect} WHERE id=$1::uuid AND tenant_id=$2::uuid`,[req.params.id,user.tenantId]);
  if(!result.rows[0])return res.status(404).json({error:'Family record not found'});
  const family=mapFamilyRow(result.rows[0]);
  if(family.branchId&&!user.branchIds.includes('*')&&!user.branchIds.includes(family.branchId)&&family.branchId!==user.branchId)return res.status(403).json({error:'Branch access denied.'});
  return res.json(family);
}));

router.post('/families', requirePermission('families.create'), asyncRoute(async (req,res)=>{
  const user=req.user!;
  const input=req.body as Partial<Family>;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  const branchId=isDatabaseUuid(input.branchId)?input.branchId:user.branchId;
  if(!isDatabaseUuid(branchId))return res.status(400).json({error:'A valid branch UUID is required.'});
  if(!input.householdName||!input.familyCode||!input.address||!input.city||!input.region||!input.primaryLanguage||!input.familyType||!input.status)
    return res.status(400).json({error:'Required family registration fields are missing.'});
  await validateFamilyReferences(input,user.tenantId,branchId);
  const result=await query<FamilyDbRow>(
    `INSERT INTO public.families
      (tenant_id,branch_id,family_code,household_name,head_member_id,primary_phone,family_type,family_photo_url,
       primary_language,address,woreda,kebele,house_number,city,region,member_ids,relationships,registration_date,status)
     VALUES($1::uuid,$2::uuid,$3,$4,$5::uuid,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16::jsonb,$17::jsonb,$18::date,$19)
     RETURNING id,tenant_id,branch_id,family_code,household_name,head_member_id,primary_phone,family_type,family_photo_url,
       primary_language,address,woreda,kebele,house_number,city,region,member_ids,relationships,registration_date,status`,
    [user.tenantId,branchId,input.familyCode,input.householdName,input.headOfHouseholdMemberId,input.primaryHouseholdPhone||null,
     input.familyType,input.familyPhotoUrl||null,input.primaryLanguage,input.address,input.woreda||null,input.kebele||null,
     input.houseNumber||null,input.city,input.region,JSON.stringify(input.memberIds||[]),JSON.stringify(input.relationships||[]),
     input.registrationDate||new Date().toISOString().slice(0,10),input.status]);
  const saved=mapFamilyRow(result.rows[0]);
  await recordMemberAudit(req,'FAMILY_CREATE',`Created household ${saved.familyCode} (${saved.id})`);
  return res.status(201).json(saved);
}));

router.put('/families/:id', requirePermission('families.update'), asyncRoute(async (req,res)=>{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and family UUIDs are required.'});
  const current=await query<FamilyDbRow>(`${familySelect} WHERE id=$1::uuid AND tenant_id=$2::uuid`,[req.params.id,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Family record not found'});
  const existing=mapFamilyRow(current.rows[0]);
  if(existing.branchId&&!user.branchIds.includes('*')&&!user.branchIds.includes(existing.branchId)&&existing.branchId!==user.branchId)return res.status(403).json({error:'Branch access denied.'});
  const input={...existing,...req.body,id:existing.id,tenantId:user.tenantId} as Family;
  const branchId=isDatabaseUuid(input.branchId)?input.branchId:existing.branchId;
  if(!isDatabaseUuid(branchId))return res.status(400).json({error:'A valid branch UUID is required.'});
  await validateFamilyReferences(input,user.tenantId,branchId);
  const result=await query<FamilyDbRow>(
    `UPDATE public.families SET branch_id=$3::uuid,family_code=$4,household_name=$5,head_member_id=$6::uuid,
      primary_phone=$7,family_type=$8,family_photo_url=$9,primary_language=$10,address=$11,woreda=$12,kebele=$13,
      house_number=$14,city=$15,region=$16,member_ids=$17::jsonb,relationships=$18::jsonb,
      registration_date=$19::date,status=$20,updated_at=now()
     WHERE id=$1::uuid AND tenant_id=$2::uuid
     RETURNING id,tenant_id,branch_id,family_code,household_name,head_member_id,primary_phone,family_type,family_photo_url,
       primary_language,address,woreda,kebele,house_number,city,region,member_ids,relationships,registration_date,status`,
    [req.params.id,user.tenantId,branchId,input.familyCode,input.householdName,input.headOfHouseholdMemberId,
     input.primaryHouseholdPhone||null,input.familyType,input.familyPhotoUrl||null,input.primaryLanguage,input.address,
     input.woreda||null,input.kebele||null,input.houseNumber||null,input.city,input.region,JSON.stringify(input.memberIds||[]),
     JSON.stringify(input.relationships||[]),input.registrationDate,input.status]);
  const saved=mapFamilyRow(result.rows[0]);
  await recordMemberAudit(req,'FAMILY_UPDATE',`Updated household ${saved.familyCode} (${saved.id})`);
  return res.json(saved);
}));

router.delete('/families/:id', requirePermission('families.delete'), asyncRoute(async (req,res)=>{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and family UUIDs are required.'});
  const current=await query<FamilyDbRow>(`${familySelect} WHERE id=$1::uuid AND tenant_id=$2::uuid`,[req.params.id,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Family record not found'});
  const family=mapFamilyRow(current.rows[0]);
  if(family.branchId&&!user.branchIds.includes('*')&&!user.branchIds.includes(family.branchId)&&family.branchId!==user.branchId)return res.status(403).json({error:'Branch access denied.'});
  await query('DELETE FROM public.families WHERE id=$1::uuid AND tenant_id=$2::uuid',[req.params.id,user.tenantId]);
  await recordMemberAudit(req,'FAMILY_DELETE',`Deleted household ${family.familyCode} (${family.id})`);
  return res.json({success:true,deletedId:req.params.id});
}));

// Restricted member health and emergency-contact data. Never included in list/state payloads.
router.get('/:id/private-details',requirePermission('pastoral.confidential'),asyncRoute(async(req,res)=>{
  const user=req.user!;
  if(!isDatabaseUuid(req.params.id)||!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'Valid member and tenant UUIDs are required.'});
  const scope=resolveMemberScope(user);
  const member=await getMemberById(req.params.id,scope);
  if(!member)return res.status(404).json({error:'Member record not found'});
  const result=await query<{emergency_contact:Record<string,unknown>;health_information:Record<string,unknown>;access_note:string|null}>(
    `SELECT emergency_contact,health_information,access_note FROM public.member_private_details
     WHERE member_id=$1::uuid AND tenant_id=$2::uuid`,
    [req.params.id,user.tenantId]
  );
  const row=result.rows[0];
  return res.json({
    emergencyContact:row?.emergency_contact||{name:'',relationship:'',phone:''},
    ...(row?.health_information||{}),
    notes:row?.access_note||'',
  });
}));

router.put('/:id/private-details',requirePermission('pastoral.confidential'),asyncRoute(async(req,res)=>{
  const user=req.user!;
  if(!isDatabaseUuid(req.params.id)||!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'Valid member and tenant UUIDs are required.'});
  const scope=resolveMemberScope(user);
  const member=await getMemberById(req.params.id,scope);
  if(!member)return res.status(404).json({error:'Member record not found'});
  const body=req.body||{};
  const health=Object.fromEntries(['bloodType','knownAllergies','medicalConditions','specialNeeds'].filter(k=>body[k]!==undefined).map(k=>[k,body[k]]));
  const emergencyContact=body.emergencyContact&&typeof body.emergencyContact==='object'?body.emergencyContact:{};
  const branchId=member.branchId;
  await query(
    `INSERT INTO public.member_private_details(member_id,tenant_id,branch_id,emergency_contact,health_information,access_note,updated_at)
     VALUES($1::uuid,$2::uuid,$3::uuid,$4::jsonb,$5::jsonb,$6,now())
     ON CONFLICT(member_id) DO UPDATE SET tenant_id=EXCLUDED.tenant_id,branch_id=EXCLUDED.branch_id,
       emergency_contact=EXCLUDED.emergency_contact,health_information=EXCLUDED.health_information,
       access_note=EXCLUDED.access_note,updated_at=now()`,
    [member.id,user.tenantId,branchId,JSON.stringify(emergencyContact),JSON.stringify(health),typeof body.notes==='string'?body.notes:null]
  );
  await recordMemberAudit(req,'PRIVATE_DETAILS_UPDATE',`Updated restricted pastoral details for member ${member.memberIdNumber}`);
  return res.json({success:true,message:'Restricted member details updated.'});
}));

export default router;
