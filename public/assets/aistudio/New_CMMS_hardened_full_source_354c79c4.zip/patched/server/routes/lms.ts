import { Router, Request, Response } from 'express';
import { db } from '../db';
import { LmsCourse, WorkflowRequest } from '../../src/types';

const router = Router();

// LMS COURSES
router.get('/courses', (req: Request, res: Response) => {
  return res.json(db.getState().courses);
});

router.post('/courses', (req: Request, res: Response) => {
  const courseData: LmsCourse = req.body;
  const course: LmsCourse = {
    ...courseData,
    id: courseData.id || `crs-${Date.now()}`,
    courseCode: courseData.courseCode || `CRS-${Date.now().toString().slice(-4)}`,
    enrolledStudentsCount: courseData.enrolledStudentsCount || 0,
    totalModules: courseData.totalModules || 1,
    durationWeeks: courseData.durationWeeks || 4,
    passPercentage: courseData.passPercentage || 80,
  };

  db.getState().courses.unshift(course);
  db.persist();
  db.addAuditLog('Create LMS Course', 'LMS & Academy', `Created new academy course: ${course.title}`);
  return res.status(201).json(course);
});

router.put('/courses/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const state = db.getState();
  const index = state.courses.findIndex((c) => c.id === id);
  if (index === -1) return res.status(404).json({ error: 'Course not found' });

  state.courses[index] = { ...state.courses[index], ...req.body, id };
  db.persist();
  db.addAuditLog('Update LMS Course', 'LMS & Academy', `Updated course: ${state.courses[index].title}`);
  return res.json(state.courses[index]);
});

router.delete('/courses/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const state = db.getState();
  const index = state.courses.findIndex((c) => c.id === id);
  if (index === -1) return res.status(404).json({ error: 'Course not found' });

  const deleted = state.courses.splice(index, 1)[0];
  db.persist();
  db.addAuditLog('Delete LMS Course', 'LMS & Academy', `Deleted academy course: ${deleted.title}`);
  return res.json({ success: true, deletedId: id });
});

// WORKFLOWS & APPROVALS
router.get('/workflows', (req: Request, res: Response) => {
  return res.json(db.getState().workflows);
});

router.put('/workflows/:id/status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, comment } = req.body;
  const state = db.getState();
  const wf = state.workflows.find((w) => w.id === id);
  if (!wf) return res.status(404).json({ error: 'Workflow not found' });

  wf.status = status;
  if (comment) wf.comments = comment;
  db.persist();
  db.addAuditLog('Workflow Action', 'Workflows & Approvals', `Workflow #${id} (${wf.requestType}) transitioned to ${status}`);
  return res.json(wf);
});

export default router;
