import { Router, Response } from 'express';
import { db } from '../db';
import { socketService } from '../../src/services/socketService';
import {
  authenticateToken,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import {
  Conversation,
  ConversationParticipant,
  ConversationMessage,
  ConversationType,
  UserRole,
} from '../../src/types';
import {
  canCreateConversationType,
  validateParticipantLimits,
  verifyUserInTenant,
  isActiveParticipant,
  getActiveParticipants,
  resolveUserRole,
  isDirectChatAllowed,
  getLedMinistryMemberIds,
  isMemberInLedMinistries,
  validateDirectConversationTierAndScope,
} from '../services/conversationService';
import { logPermissionDenied } from '../services/membershipService';

const router = Router();

// Enforce authentication across all conversation endpoints
router.use(authenticateToken);

/**
 * POST /api/conversations
 * Creates a new conversation (direct, ad_hoc_group, or video).
 * Validates role-based initiation boundaries and tenant participant isolation.
 */
router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { type, title, participantIds, roomUrl } = req.body;

  // 1. Validate conversation type
  const validTypes: ConversationType[] = ['direct', 'ad_hoc_group', 'video'];
  if (!type || !validTypes.includes(type)) {
    return res.status(400).json({
      error: 'Invalid conversation type. Must be direct, ad_hoc_group, or video.',
      code: 'INVALID_CONVERSATION_TYPE',
    });
  }

  // 2. Role permission rule:
  // - 'direct': Any authenticated tenant member
  // - 'ad_hoc_group' / 'video': Only MINISTRY_LEADER, PASTOR, MANAGER, SYSTEM_ADMIN
  if (!canCreateConversationType(user.role, type)) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'create_conversation',
      targetType: 'conversation',
      targetId: type,
      reason: `Role ${user.role} is not authorized to create ${type} conversations. Only leaders, pastors, and admins can create ad-hoc group and video conversations.`,
      ipAddress: req.ip,
    });

    return res.status(403).json({
      error: 'Forbidden: Only ministry leaders, pastors, and administrators can initiate ad-hoc group or video conversations.',
      code: 'FORBIDDEN_CONVERSATION_CREATION',
    });
  }

  // 3. Title validation for ad_hoc_group and video
  const cleanTitle = typeof title === 'string' ? title.trim() : '';
  if ((type === 'ad_hoc_group' || type === 'video') && !cleanTitle) {
    return res.status(400).json({
      error: 'Title is required for ad-hoc group and video conversations.',
      code: 'TITLE_REQUIRED',
    });
  }

  // 4. Validate and deduplicate explicit participant user IDs
  if (!Array.isArray(participantIds)) {
    return res.status(400).json({
      error: 'participantIds must be an array of explicit user IDs.',
      code: 'INVALID_PARTICIPANTS',
    });
  }

  // Deduplicate and ensure creator is part of the final participant list
  const distinctOtherIds = Array.from(
    new Set(participantIds.map((id) => String(id).trim()).filter((id) => id && id !== user.id))
  );
  const allParticipantIds = [user.id, ...distinctOtherIds];

  // 5. Participant limits and Direct conversation role validation
  const limitsCheck = validateParticipantLimits(type, allParticipantIds.length);
  if (!limitsCheck.valid) {
    return res.status(400).json({
      error: limitsCheck.error,
      code: 'PARTICIPANT_LIMIT_VIOLATION',
    });
  }

  // Enforce role rule for type 'direct':
  // - Allowed: staff <-> member
  // - Allowed: staff <-> staff
  // - NEVER allowed: member <-> member (reject 403 MEMBER_TO_MEMBER_BLOCKED)
  if (type === 'direct') {
    if (distinctOtherIds.length !== 1 || allParticipantIds.length !== 2) {
      return res.status(400).json({
        error: 'A direct conversation must have exactly two participants (you and one other member).',
        code: 'PARTICIPANT_LIMIT_VIOLATION',
      });
    }

    const otherUserId = distinctOtherIds[0];
    const creatorRole = await resolveUserRole(user.id);
    const otherRole = await resolveUserRole(otherUserId);

    const tierCheck = validateDirectConversationTierAndScope(
      user.id,
      creatorRole,
      otherUserId,
      otherRole
    );

    if (!tierCheck.allowed) {
      logPermissionDenied({
        userId: user.id,
        userEmail: user.email,
        userRole: user.role,
        action: 'create_direct_conversation',
        targetType: 'conversation',
        targetId: otherUserId,
        reason: tierCheck.error || 'Direct conversation blocked by tier or ministry-scope rule.',
        ipAddress: req.ip,
      });

      db.addAuditLog(
        'Unauthorized Access Attempt Blocked',
        'Conversations & Messaging',
        tierCheck.details ||
          `Blocked direct conversation between ${user.email} (${creatorRole}) and ${otherUserId} (${otherRole}): ${tierCheck.code}`,
        user.email,
        req.ip
      );

      return res.status(403).json({
        error: tierCheck.error,
        code: tierCheck.code,
      });
    }
  }

  // 6. Tenant isolation validation: Reject any participant outside creator's tenant
  const tenantId = user.tenantId || 'tenant-grace-main';
  for (const pid of distinctOtherIds) {
    const isSameTenant = await verifyUserInTenant(pid, tenantId);
    if (!isSameTenant) {
      logPermissionDenied({
        userId: user.id,
        userEmail: user.email,
        userRole: user.role,
        action: 'add_cross_tenant_participant',
        targetType: 'conversation',
        targetId: pid,
        reason: `Attempted to add participant ${pid} outside tenant ${tenantId}.`,
        ipAddress: req.ip,
      });

      return res.status(400).json({
        error: `Cannot add participant "${pid}": Member does not belong to your church organization tenant.`,
        code: 'CROSS_TENANT_PARTICIPANT_BLOCKED',
      });
    }
  }

  // 7. Check if an active direct conversation already exists between these 2 users
  const state = db.getState();
  if (type === 'direct') {
    const targetUserId = distinctOtherIds[0];
    const existingDirect = (state.conversations || []).find((c) => {
      if (c.type !== 'direct' || c.tenantId !== tenantId || c.status !== 'active') return false;
      const participants = (state.conversationParticipants || []).filter(
        (p) => p.conversationId === c.id && !p.leftAt
      );
      const userIds = participants.map((p) => p.userId);
      return userIds.includes(user.id) && userIds.includes(targetUserId);
    });

    if (existingDirect) {
      // Re-verify tier and ministry-scope check on access attempt
      const creatorRole = await resolveUserRole(user.id);
      const otherRole = await resolveUserRole(targetUserId);
      const checkExisting = validateDirectConversationTierAndScope(
        user.id,
        creatorRole,
        targetUserId,
        otherRole
      );

      if (!checkExisting.allowed) {
        logPermissionDenied({
          userId: user.id,
          userEmail: user.email,
          userRole: user.role,
          action: 'access_direct_conversation',
          targetType: 'conversation',
          targetId: existingDirect.id,
          reason: checkExisting.error || 'Access denied by tier or ministry scope rule.',
          ipAddress: req.ip,
        });

        db.addAuditLog(
          'Unauthorized Access Attempt Blocked',
          'Conversations & Messaging',
          checkExisting.details ||
            `Blocked access to existing direct conversation ${existingDirect.id}: ${checkExisting.code}`,
          user.email,
          req.ip
        );

        return res.status(403).json({
          error: checkExisting.error,
          code: checkExisting.code,
        });
      }

      const activeParticipants = getActiveParticipants(existingDirect.id);
      return res.status(200).json({
        success: true,
        conversation: {
          ...existingDirect,
          participants: activeParticipants,
        },
      });
    }
  }

  // 8. Construct new Conversation record
  const conversationId = `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  // For video type, reuse WebRTC / Jitsi room-URL approach
  const generatedRoomUrl =
    type === 'video'
      ? roomUrl || `https://meet.jit.si/CMMS-Conv-${tenantId}-${conversationId}`
      : null;

  const newConversation: Conversation = {
    id: conversationId,
    type,
    title: cleanTitle || (type === 'direct' ? null : 'Ad-hoc Conversation'),
    createdBy: user.id,
    tenantId,
    branchId: user.branchId || null,
    status: 'active',
    createdAt: now,
    endedAt: null,
    roomUrl: generatedRoomUrl,
  };

  // 9. Construct Participant records
  const newParticipants: ConversationParticipant[] = allParticipantIds.map((pid) => ({
    id: `cp-${conversationId}-${pid}`,
    conversationId,
    userId: pid,
    addedBy: user.id,
    addedAt: now,
    leftAt: null,
  }));

  // 10. Persist to server database
  if (!state.conversations) state.conversations = [];
  if (!state.conversationParticipants) state.conversationParticipants = [];

  state.conversations.unshift(newConversation);
  state.conversationParticipants.push(...newParticipants);
  db.save();

  // 11. Security Audit Log
  db.addAuditLog(
    'Create Conversation',
    'Conversations & Messaging',
    `User ${user.name} (${user.role}) created ${type} conversation "${newConversation.title || conversationId}" with ${allParticipantIds.length} participants`,
    user.email,
    req.ip
  );

  // 12. Socket notification to invited participants
  const io = socketService.getIO();
  if (io) {
    const activeParticipants = getActiveParticipants(conversationId);
    allParticipantIds.forEach((pid) => {
      io.to(`user:${pid}`).emit('conversation:created', {
        conversation: {
          ...newConversation,
          participants: activeParticipants,
        },
      });
    });
  }

  const enrichedParticipants = getActiveParticipants(conversationId);

  return res.status(201).json({
    success: true,
    conversation: {
      ...newConversation,
      participants: enrichedParticipants,
    },
  });
});

/**
 * GET /api/conversations
 * List conversations the caller currently actively participates in.
 * STRICT ZERO TRUST: Never trusts client parameters; relies exclusively on authenticated req.user.
 */
router.get('/', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const state = db.getState();

  const allParticipants = state.conversationParticipants || [];
  const allConversations = state.conversations || [];
  const allMessages = state.conversationMessages || [];

  // Find conversation IDs where caller is an active participant (leftAt is null)
  const myActiveConvIds = new Set(
    allParticipants
      .filter((p) => p.userId === user.id && !p.leftAt)
      .map((p) => p.conversationId)
  );

  // Filter conversations belonging to the caller's tenant and active participancy
  const myConversations = allConversations
    .filter((c) => myActiveConvIds.has(c.id) && c.tenantId === tenantId)
    .map((c) => {
      const activeParticipants = getActiveParticipants(c.id);

      // Find last active message
      const convMessages = allMessages
        .filter((m) => m.conversationId === c.id && !m.deletedAt)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      const lastMessage = convMessages[0] || null;

      return {
        ...c,
        participants: activeParticipants,
        lastMessage,
      };
    })
    .sort((a, b) => {
      const timeA = a.lastMessage?.createdAt || a.createdAt;
      const timeB = b.lastMessage?.createdAt || b.createdAt;
      return new Date(timeB).getTime() - new Date(timeA).getTime();
    });

  return res.json({
    success: true,
    conversations: myConversations,
  });
});

/**
 * GET /api/conversations/led-ministry-members
 * Returns the array of member IDs within any ministry led by the authenticated user.
 */
router.get('/led-ministry-members', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const memberIds = getLedMinistryMemberIds(user.id);
  return res.json({
    success: true,
    userId: user.id,
    role: user.role,
    memberIds,
  });
});

/**
 * GET /api/conversations/:id/messages
 * Retrieves paginated messages for a conversation.
 * STRICT ZERO TRUST: Requires caller to be an active participant (left_at is null).
 * Returns uniform 404 if not authorized or not found to prevent leaking existence.
 */
router.get('/:id/messages', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;

  // Zero-trust check: Caller must be an active participant
  const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
  if (!isParticipant) {
    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  const state = db.getState();
  const allMessages = state.conversationMessages || [];

  // Filter messages for this conversation excluding deleted
  const messages = allMessages
    .filter((m) => m.conversationId === conversationId && !m.deletedAt)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  // Pagination support
  const page = Math.max(1, parseInt(req.query.page as string, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit as string, 10) || 50));
  const startIndex = (page - 1) * limit;
  const paginatedMessages = messages.slice(startIndex, startIndex + limit);

  return res.json({
    success: true,
    conversationId,
    messages: paginatedMessages,
    total: messages.length,
    page,
    limit,
  });
});

/**
 * POST /api/conversations/:id/messages
 * Posts a message to a conversation.
 * STRICT ZERO TRUST: Caller must be an active participant.
 */
router.post('/:id/messages', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;
  const { body } = req.body;

  // 1. Verify caller is an active participant
  const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
  if (!isParticipant) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'post_conversation_message',
      targetType: 'conversation',
      targetId: conversationId,
      reason: 'User is not an active participant in this conversation.',
      ipAddress: req.ip,
    });

    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  // 2. Validate message body
  const cleanBody = typeof body === 'string' ? body.trim() : '';
  if (!cleanBody) {
    return res.status(400).json({
      error: 'Message body cannot be empty.',
      code: 'EMPTY_MESSAGE',
    });
  }
  if (cleanBody.length > 4000) {
    return res.status(400).json({
      error: 'Message exceeds maximum length of 4000 characters.',
      code: 'MESSAGE_TOO_LONG',
    });
  }

  // 3. Check conversation status
  const state = db.getState();
  const conv = (state.conversations || []).find((c) => c.id === conversationId);
  if (!conv || conv.status === 'ended') {
    return res.status(400).json({
      error: 'Cannot post messages to an ended conversation.',
      code: 'CONVERSATION_ENDED',
    });
  }

  // 3b. Re-scope direct conversation tier and ministry-scope rules on every message attempt
  if (conv.type === 'direct') {
    const activeParts = (state.conversationParticipants || []).filter(
      (p) => p.conversationId === conversationId && !p.leftAt
    );
    const otherPart = activeParts.find((p) => p.userId !== user.id);
    if (otherPart) {
      const senderRole = await resolveUserRole(user.id);
      const recipientRole = await resolveUserRole(otherPart.userId);
      const tierCheck = validateDirectConversationTierAndScope(
        user.id,
        senderRole,
        otherPart.userId,
        recipientRole
      );

      if (!tierCheck.allowed) {
        logPermissionDenied({
          userId: user.id,
          userEmail: user.email,
          userRole: senderRole,
          action: 'post_direct_message',
          targetType: 'conversation',
          targetId: conversationId,
          reason: tierCheck.error || 'Access denied by tier or ministry scope rule.',
          ipAddress: req.ip,
        });

        db.addAuditLog(
          'Unauthorized Access Attempt Blocked',
          'Conversations & Messaging',
          tierCheck.details || `Blocked direct message in ${conversationId}: ${tierCheck.code}`,
          user.email,
          req.ip
        );

        return res.status(403).json({
          error: tierCheck.error,
          code: tierCheck.code,
        });
      }
    }
  }

  // 4. Create and persist message
  const now = new Date().toISOString();
  const newMessage: ConversationMessage = {
    id: `cmsg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    conversationId,
    senderId: user.id,
    body: cleanBody,
    createdAt: now,
    editedAt: null,
    deletedAt: null,
    senderName: user.name,
    senderRole: user.role,
  };

  if (!state.conversationMessages) {
    state.conversationMessages = [];
  }
  state.conversationMessages.push(newMessage);
  db.save();

  // 5. Broadcast in real-time to the conversation socket room
  const io = socketService.getIO();
  if (io) {
    const roomKey = `conversation:${tenantId}:${conversationId}`;
    io.to(roomKey).emit('conversation:message_received', {
      conversationId,
      message: newMessage,
    });
  }

  return res.status(201).json({
    success: true,
    message: newMessage,
  });
});

/**
 * POST /api/conversations/:id/participants
 * Add an explicit user ID to an active conversation.
 * Only the creator OR privileged administrators (SYSTEM_ADMIN, PASTOR, MANAGER).
 */
router.post('/:id/participants', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;
  const { userId } = req.body;

  if (!userId || typeof userId !== 'string') {
    return res.status(400).json({
      error: 'userId is required.',
      code: 'USER_ID_REQUIRED',
    });
  }

  const cleanUserId = userId.trim();
  const state = db.getState();
  const conv = (state.conversations || []).find((c) => c.id === conversationId);

  // Zero-trust check: Conversation must exist and belong to caller's tenant
  if (!conv || conv.tenantId !== tenantId) {
    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  // Only creator or privileged roles may add participants
  const privilegedRoles: UserRole[] = ['SYSTEM_ADMIN', 'PASTOR', 'MANAGER'];
  const isCreator = conv.createdBy === user.id;
  const isPrivileged = privilegedRoles.includes(user.role);

  if (!isCreator && !isPrivileged) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'add_conversation_participant',
      targetType: 'conversation',
      targetId: conversationId,
      reason: 'User is neither the creator nor a privileged administrator for this conversation.',
      ipAddress: req.ip,
    });

    return res.status(403).json({
      error: 'Forbidden: Only the conversation creator or administrative leaders may add participants.',
      code: 'FORBIDDEN_ADD_PARTICIPANT',
    });
  }

  // Direct conversations role and participant pair validation
  if (conv.type === 'direct') {
    const currentActive = (state.conversationParticipants || []).filter(
      (p) => p.conversationId === conversationId && !p.leftAt
    );
    const isAlreadyActive = currentActive.some((p) => p.userId === cleanUserId);

    if (!isAlreadyActive && currentActive.length >= 2) {
      return res.status(400).json({
        error: 'Cannot add more than 2 participants to a direct 1:1 conversation. Start an ad-hoc group conversation instead.',
        code: 'DIRECT_CONVERSATION_IMMUTABLE',
      });
    }

    // Re-check role rule against the resulting pair
    const resultingUserIds = Array.from(
      new Set([...currentActive.map((p) => p.userId), cleanUserId])
    );

    if (resultingUserIds.length === 2) {
      const roleA = await resolveUserRole(resultingUserIds[0]);
      const roleB = await resolveUserRole(resultingUserIds[1]);

      const tierCheck = validateDirectConversationTierAndScope(
        resultingUserIds[0],
        roleA,
        resultingUserIds[1],
        roleB
      );

      if (!tierCheck.allowed) {
        logPermissionDenied({
          userId: user.id,
          userEmail: user.email,
          userRole: user.role,
          action: 'add_direct_conversation_participant',
          targetType: 'conversation',
          targetId: cleanUserId,
          reason: tierCheck.error || 'Direct conversation blocked by tier or ministry-scope rule.',
          ipAddress: req.ip,
        });

        db.addAuditLog(
          'Unauthorized Access Attempt Blocked',
          'Conversations & Messaging',
          tierCheck.details ||
            `Blocked adding participant ${cleanUserId} (${roleB}) to direct conversation ${conversationId}: ${tierCheck.code}`,
          user.email,
          req.ip
        );

        return res.status(403).json({
          error: tierCheck.error,
          code: tierCheck.code,
        });
      }
    }
  }

  // Active participant cap check (max 50)
  const currentParticipants = (state.conversationParticipants || []).filter(
    (p) => p.conversationId === conversationId && !p.leftAt
  );
  if (currentParticipants.length >= 50) {
    return res.status(400).json({
      error: 'Participant limit reached (maximum 50 participants allowed).',
      code: 'PARTICIPANT_CAP_REACHED',
    });
  }

  // Verify target user belongs to the same tenant
  const isSameTenant = await verifyUserInTenant(cleanUserId, tenantId);
  if (!isSameTenant) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'add_cross_tenant_participant',
      targetType: 'conversation',
      targetId: cleanUserId,
      reason: `Attempted to add participant ${cleanUserId} from another tenant.`,
      ipAddress: req.ip,
    });

    return res.status(400).json({
      error: 'Cannot add participant: Member belongs to a different church tenant.',
      code: 'CROSS_TENANT_PARTICIPANT_BLOCKED',
    });
  }

  // Check if participant already active or previously left
  if (!state.conversationParticipants) {
    state.conversationParticipants = [];
  }

  const existing = state.conversationParticipants.find(
    (p) => p.conversationId === conversationId && p.userId === cleanUserId
  );

  const now = new Date().toISOString();
  let participantRecord: ConversationParticipant;

  if (existing) {
    if (!existing.leftAt) {
      return res.status(200).json({
        success: true,
        message: 'User is already an active participant in this conversation.',
        participant: existing,
      });
    }
    // Re-activate previously departed participant
    existing.leftAt = null;
    existing.addedBy = user.id;
    existing.addedAt = now;
    participantRecord = existing;
  } else {
    participantRecord = {
      id: `cp-${conversationId}-${cleanUserId}`,
      conversationId,
      userId: cleanUserId,
      addedBy: user.id,
      addedAt: now,
      leftAt: null,
    };
    state.conversationParticipants.push(participantRecord);
  }

  db.save();

  // Audit log
  db.addAuditLog(
    'Add Conversation Participant',
    'Conversations & Messaging',
    `User ${user.name} added participant ${cleanUserId} to conversation "${conv.title || conversationId}"`,
    user.email,
    req.ip
  );

  // Socket notification
  const io = socketService.getIO();
  if (io) {
    const roomKey = `conversation:${tenantId}:${conversationId}`;
    io.to(roomKey).emit('conversation:participant_added', {
      conversationId,
      participant: participantRecord,
    });
    io.to(`user:${cleanUserId}`).emit('conversation:added', {
      conversationId,
      conversation: conv,
    });
  }

  return res.status(200).json({
    success: true,
    participant: participantRecord,
  });
});

/**
 * POST /api/conversations/:id/leave
 * Sets left_at for the caller and revokes socket room participancy.
 */
router.post('/:id/leave', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;

  const state = db.getState();
  const conv = (state.conversations || []).find((c) => c.id === conversationId);

  if (!conv || conv.tenantId !== tenantId) {
    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  const participants = state.conversationParticipants || [];
  const participant = participants.find(
    (p) => p.conversationId === conversationId && p.userId === user.id && !p.leftAt
  );

  if (!participant) {
    return res.status(400).json({
      error: 'You are not currently an active participant in this conversation.',
      code: 'NOT_ACTIVE_PARTICIPANT',
    });
  }

  // Mark left_at
  const now = new Date().toISOString();
  participant.leftAt = now;
  db.save();

  // Audit log
  db.addAuditLog(
    'Leave Conversation',
    'Conversations & Messaging',
    `User ${user.name} left conversation "${conv.title || conversationId}"`,
    user.email,
    req.ip
  );

  // Notify socket room that participant has left
  const io = socketService.getIO();
  if (io) {
    const roomKey = `conversation:${tenantId}:${conversationId}`;
    io.to(roomKey).emit('conversation:participant_left', {
      conversationId,
      userId: user.id,
      userName: user.name,
      leftAt: now,
    });
  }

  return res.json({
    success: true,
    message: 'Successfully left conversation.',
    leftAt: now,
  });
});

/**
 * POST /api/conversations/:id/end
 * Creator or privileged role only (SYSTEM_ADMIN, PASTOR, MANAGER).
 * Sets status to 'ended' and ended_at.
 */
router.post('/:id/end', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;

  const state = db.getState();
  const conv = (state.conversations || []).find((c) => c.id === conversationId);

  if (!conv || conv.tenantId !== tenantId) {
    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  // Check creator or privileged role
  const privilegedRoles: UserRole[] = ['SYSTEM_ADMIN', 'PASTOR', 'MANAGER'];
  const isCreator = conv.createdBy === user.id;
  const isPrivileged = privilegedRoles.includes(user.role);

  if (!isCreator && !isPrivileged) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'end_conversation',
      targetType: 'conversation',
      targetId: conversationId,
      reason: 'Only creator or privileged administrative roles can end a conversation.',
      ipAddress: req.ip,
    });

    return res.status(403).json({
      error: 'Forbidden: Only the creator or an administrator can end this conversation.',
      code: 'FORBIDDEN_END_CONVERSATION',
    });
  }

  const now = new Date().toISOString();
  conv.status = 'ended';
  conv.endedAt = now;
  db.save();

  // Audit log
  db.addAuditLog(
    'End Conversation',
    'Conversations & Messaging',
    `User ${user.name} ended ${conv.type} conversation "${conv.title || conversationId}"`,
    user.email,
    req.ip
  );

  // Notify socket room
  const io = socketService.getIO();
  if (io) {
    const roomKey = `conversation:${tenantId}:${conversationId}`;
    io.to(roomKey).emit('conversation:ended', {
      conversationId,
      endedBy: user.id,
      endedAt: now,
    });
  }

  return res.json({
    success: true,
    conversation: conv,
  });
});

/**
 * POST /api/conversations/:id/start-video
 * Initiates a 1:1 direct video call on a direct conversation.
 * Enforces:
 * 1. Conversation must be type 'direct', active, same tenant.
 * 2. Caller must be an active participant (zero-trust check).
 * 3. Pair tier rule: staff-tier <-> regular member or staff <-> staff.
 *    Rejects member <-> member with 403 code 'MEMBER_TO_MEMBER_BLOCKED'.
 * 4. Generates Jitsi-style room URL.
 * 5. Notifies other participant strictly via user:{id} socket room (no group blast).
 */
router.post('/:id/start-video', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;

  const state = db.getState();
  const conv = (state.conversations || []).find((c) => c.id === conversationId);

  if (!conv || conv.tenantId !== tenantId) {
    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  // Direct conversations only
  if (conv.type !== 'direct') {
    return res.status(400).json({
      error: 'This endpoint is strictly for 1:1 direct video calls. Group conversations use group video conferencing.',
      code: 'DIRECT_CONVERSATION_REQUIRED',
    });
  }

  if (conv.status !== 'active') {
    return res.status(400).json({
      error: 'Cannot start video call in an inactive or ended conversation.',
      code: 'CONVERSATION_INACTIVE',
    });
  }

  // Active participant check (Zero-trust)
  const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
  if (!isParticipant) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'start_direct_video',
      targetType: 'conversation',
      targetId: conversationId,
      reason: 'User is not an active participant of this direct conversation.',
      ipAddress: req.ip,
    });
    return res.status(403).json({
      error: 'Forbidden: You are not an active participant in this conversation.',
      code: 'FORBIDDEN_CONVERSATION',
    });
  }

  // Active participants list
  const activeParticipants = getActiveParticipants(conversationId);
  const otherParticipant = activeParticipants.find((p) => p.userId !== user.id);
  if (!otherParticipant) {
    return res.status(400).json({
      error: 'No other active participant found in this conversation to call.',
      code: 'NO_RECIPIENT_FOUND',
    });
  }

  // Tier rule and ministry-scope check
  const callerRole = await resolveUserRole(user.id);
  const recipientRole = await resolveUserRole(otherParticipant.userId);

  const tierCheck = validateDirectConversationTierAndScope(
    user.id,
    callerRole,
    otherParticipant.userId,
    recipientRole
  );

  if (!tierCheck.allowed) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: callerRole,
      action: 'start_direct_video',
      targetType: 'conversation',
      targetId: conversationId,
      reason: tierCheck.error || 'Direct 1:1 video call blocked by tier or ministry-scope rule.',
      ipAddress: req.ip,
    });

    db.addAuditLog(
      'Unauthorized Access Attempt Blocked',
      'Conversations & Messaging',
      tierCheck.details ||
        `Blocked 1:1 video call attempt between ${user.email} (${callerRole}) and ${otherParticipant.userId} (${recipientRole}) in conversation ${conversationId}: ${tierCheck.code}`,
      user.email,
      req.ip
    );

    return res.status(403).json({
      error: tierCheck.error,
      code: tierCheck.code,
    });
  }

  // Generate Jitsi-style room URL reusing group video conference mechanism
  const roomUrl = `https://meet.jit.si/CMMS-Direct-${tenantId}-${conversationId}-${Date.now().toString(36)}`;
  const now = new Date().toISOString();

  conv.roomUrl = roomUrl;
  conv.activeVideoCall = {
    roomUrl,
    startedAt: now,
    startedBy: user.id,
    callerName: user.name,
    callerRole,
    recipientId: otherParticipant.userId,
    recipientName: otherParticipant.userName || 'Member',
    status: 'calling',
  };
  db.save();

  db.addAuditLog(
    'Start 1:1 Video Call',
    'Conversations & Messaging',
    `User ${user.name} (${callerRole}) started 1:1 video call with ${otherParticipant.userName || otherParticipant.userId} (${recipientRole}) in conversation ${conversationId}`,
    user.email,
    req.ip
  );

  // Notify other participant strictly via user:{id} socket room (no group blast)
  const io = socketService.getIO();
  if (io) {
    io.to(`user:${otherParticipant.userId}`).emit('direct_video:incoming_call', {
      conversationId: conv.id,
      callerId: user.id,
      callerName: user.name,
      callerRole,
      roomUrl,
      startedAt: now,
    });
  }

  return res.status(200).json({
    success: true,
    conversationId: conv.id,
    roomUrl,
    activeVideoCall: conv.activeVideoCall,
  });
});

/**
 * POST /api/conversations/:id/end-video
 * Ends the active 1:1 direct video call on this conversation.
 */
router.post('/:id/end-video', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const tenantId = user.tenantId || 'tenant-grace-main';
  const conversationId = req.params.id;

  const state = db.getState();
  const conv = (state.conversations || []).find((c) => c.id === conversationId);

  if (!conv || conv.tenantId !== tenantId) {
    return res.status(404).json({
      error: 'Conversation not found or access denied.',
      code: 'CONVERSATION_NOT_FOUND',
    });
  }

  const isParticipant = await isActiveParticipant(conversationId, user.id, tenantId);
  if (!isParticipant) {
    return res.status(403).json({
      error: 'Forbidden: You are not an active participant in this conversation.',
      code: 'FORBIDDEN_CONVERSATION',
    });
  }

  conv.roomUrl = null;
  conv.activeVideoCall = null;
  db.save();

  db.addAuditLog(
    'End 1:1 Video Call',
    'Conversations & Messaging',
    `User ${user.name} ended 1:1 video call in conversation ${conversationId}`,
    user.email,
    req.ip
  );

  const activeParticipants = getActiveParticipants(conversationId);
  const io = socketService.getIO();
  if (io) {
    for (const p of activeParticipants) {
      io.to(`user:${p.userId}`).emit('direct_video:call_ended', {
        conversationId,
        endedBy: user.id,
        endedByName: user.name,
      });
    }
  }

  return res.status(200).json({
    success: true,
    message: '1:1 video call ended.',
    conversationId,
  });
});

export default router;
