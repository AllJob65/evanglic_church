import { Router, Request, Response } from 'express';
import { db } from '../db';
import { Member } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
  verifyResourceAccess,
} from '../../src/security/authorization';
import { smsService } from '../services/smsService';
import { communicationLogService } from '../services/communicationLogService';

const router = Router();

// Bible Database (Multilingual: English KJV/NIV, Amharic, Afaan Oromoo, Tigrigna)
const BIBLE_VERSES = [
  {
    reference: 'Philippians 4:19',
    book: 'Philippians',
    chapter: 4,
    verse: 19,
    text_en: 'And my God will meet all your needs according to the riches of his glory in Christ Jesus.',
    text_am: 'አምላኬም እንደ ባለ ጠግነቱ መጠን በክብር በክርስቶስ ኢየሱስ የሚያስፈልጋችሁን ሁሉ ይሞላባችኋል።',
    text_om: 'Waaqayyo koo immoo akka badhaadhummaa isaatti ulfinaan karaa Kiristoos Yesuus waan isin barbaachisu hundumaa isiniif in kenna.',
    text_ti: 'ኣምላኸይ ከኣ ከምቲ መጠን ሃብቱ ብኽብሪ ብክርስቶስ የሱስ ንዅሉ እተድልዩኹም ኪመልኣልኩም እዩ።',
    theme: 'Provision & Trust',
  },
  {
    reference: 'Jeremiah 29:11',
    book: 'Jeremiah',
    chapter: 29,
    verse: 11,
    text_en: 'For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future.',
    text_am: 'ለእናንተ የማስባትን አሳብ እኔ አውቃለሁ፤ ፍጻሜና ተስፋ እሰጣችሁ ዘንድ የሰላም አሳብ ነው እንጂ የክፉ ነገር አይደለም።',
    text_om: 'Ani yaada isiniif yaadu nan beeka, jedha Waaqayyo; innis yaada nagaati malee yaada hamaa miti, abdii fi egeree isiniif kennuuf.',
    text_ti: 'ኣነ ዝሓስበልኩም ዘሎኹ ሓሳብ ኣነ እፈልጦ እየ፡ መፈጸምታን ተስፋን ክህበኩምሲ፡ ናይ ሰላም ሓሳብ እዩ እምበር፡ ናይ ክፉእ ኣይኰነን፡ ይብል እግዚኣብሄር።',
    theme: 'Hope & Destiny',
  },
  {
    reference: 'Psalm 23:1',
    book: 'Psalms',
    chapter: 23,
    verse: 1,
    text_en: 'The Lord is my shepherd, I lack nothing.',
    text_am: 'እግዚአብሔር እረኛዬ ነው፥ የሚያሳጣኝም የለም።',
    text_om: 'Waaqayyo tiksee kooti, ani homaa hin dhabu.',
    text_ti: 'እግዚኣብሄር ጓሳይየይ እዩ፡ ዚጐድለኒ የብለይን።',
    theme: 'Guidance & Peace',
  },
  {
    reference: 'Isaiah 40:31',
    book: 'Isaiah',
    chapter: 40,
    verse: 31,
    text_en: 'But those who hope in the Lord will renew their strength. They will soar on wings like eagles; they will run and not grow weary, they will walk and not be faint.',
    text_am: 'እግዚአብሔርን በመተማመን የሚጠባበቁ ግን ኃይላቸውን ያድሳሉ፤ እንደ ንስር በክንፍ ይወጣሉ፤ ይሮጣሉ፥ አይታክቱም፤ ይሄዳሉ፥ አይደክሙም።',
    text_om: 'Warri Waaqayyoon abdatan garuu humna haaraa argatu; akkuma risaa koolaan ol in balali\'u; in fiigu, hin dhabanis; in deemu, hin dadhabanis.',
    text_ti: 'እቶም ንእግዚኣብሄር ዚጽበዩ ግና ሓይሎም ይሕደስ፡ ከም ንስሪ በኽናፍ ይድይቡ፡ ይጐይዩ እሞ ኣይደኽሙን፡ ይኸዱ እሞ ኣይሕለሉን።',
    theme: 'Strength & Renewal',
  },
  {
    reference: 'Romans 8:28',
    book: 'Romans',
    chapter: 8,
    verse: 28,
    text_en: 'And we know that in all things God works for the good of those who love him, who have been called according to his purpose.',
    text_am: 'እግዚአብሔርንም ለሚወዱት እንደ አሳቡም ለተጠሩት ነገር ሁሉ ለበጎ እንዲደረግ እናውቃለን።',
    text_om: 'Waaqayyo warra isa jaallataniif, warra akka yaada isaatti waamamaniif, waan hundumaan gaariif akka hojjetu beekna.',
    text_ti: 'ነቶም ንኣምላኽ ዜፍቅሩ፡ ከም ምኽሩውን እተጸውዑ፡ ኵሉ ንሰናዮም ሓቢሩ ከም ዚዓዪ፡ ንፈልጥ ኢና።',
    theme: 'Faith & Victory',
  },
  {
    reference: 'Proverbs 3:5-6',
    book: 'Proverbs',
    chapter: 3,
    verse: 5,
    text_en: 'Trust in the Lord with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.',
    text_am: 'በሙሉ ልብህ በእግዚአብሔር ታመን፥ በራስህም ማስተዋል አትደገፍ፤ በመንገድህ ሁሉ እርሱን እወቅ፥ እርሱም ጎዳናህን ያቀናልሃል።',
    text_om: 'Garaa kee guutuudhaan Waaqayyoon amanadhu, hubannaa ofii keetiitti hin hirkatin; karaa kee hundumaatti isa beeki, innis daandii kee siif qajeelcha.',
    text_ti: 'ብምሉእ ልብኻ ብእግዚኣብሄር ተኣመን፡ ኣብ ልቦናኻ ኣይትጸጋዕ። ኣብ ኵሉ መገድኻ ንእኡ ሕሰብ፡ ንሱ ኸኣ ኣኻይዳኻ ኬቕንዓልካ እዩ።',
    theme: 'Wisdom & Trust',
  },
  {
    reference: 'Numbers 6:24-26',
    book: 'Numbers',
    chapter: 6,
    verse: 24,
    text_en: 'The Lord bless you and keep you; the Lord make his face shine on you and be gracious to you; the Lord turn his face toward you and give you peace.',
    text_am: 'እግዚአብሔር ይባርክህ ይጠብቅህም፤ እግዚአብሔር ፊቱን ያብራልህ ይማርህም፤ እግዚአብሔር ፊቱን ወደ አንተ ያንሣ ሰላምንም ይስጥህ።',
    text_om: 'Waaqayyo si haa eebbisu, si haa eegus; Waaqayyo fuula isaa siif haa ibsu, araara siif haa godhu; Waaqayyo fuula isaa gara keetti haa deebisu, nagaas siif haa kennu.',
    text_ti: 'እግዚኣብሄር ይባርኽካን ይሐልውካን፡ እግዚኣብሄር ገጹ የብርሃልካ ብጸጋውን ይደግፍካ፡ እግዚኣብሄር ገጹ ናባኻ ገጹ የልዕል ሰላምውን ይሃብካ።',
    theme: 'Blessing & Peace',
  },
];

// 1. SMS Gateway API (Communications permission required)
router.post('/sms/send', authenticateToken, requirePermission('communications.manage'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { recipients, message, senderId } = req.body;

  if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
    return res.status(400).json({ error: 'Recipients array is required' });
  }

  if (!message || String(message).trim() === '') {
    return res.status(400).json({ error: 'SMS message body is required' });
  }

  const successfulNumbers: string[] = [];
  const failedNumbers: string[] = [];
  const logsCreated = [];

  for (const rawPhone of recipients) {
    const dispatchRes = await smsService.sendSms({
      recipient: String(rawPhone || ''),
      message: String(message).trim(),
      senderId,
    });

    const logEntry = await communicationLogService.recordLog({
      tenantId: user.tenantId,
      branchId: user.branchId,
      channel: 'SMS',
      recipient: dispatchRes.normalizedRecipient || String(rawPhone || ''),
      message: String(message).trim(),
      status: dispatchRes.status,
      provider: dispatchRes.provider,
      providerMessageId: dispatchRes.providerMessageId,
      errorMessage: dispatchRes.errorMessage,
      triggerType: 'Gateway API Dispatch',
      sentAt: dispatchRes.sentAt,
      deliveredAt: dispatchRes.deliveredAt,
      createdBy: user.id,
      createdByName: user.name,
    });
    logsCreated.push(logEntry);

    if (dispatchRes.success) {
      successfulNumbers.push(dispatchRes.normalizedRecipient);
    } else {
      failedNumbers.push(String(rawPhone));
    }
  }

  const dispatchId = logsCreated[0]?.provider_message_id || `SMS-${Date.now().toString().slice(-6)}`;
  db.addAuditLog(
    'SMS Gateway Dispatch',
    'Communications',
    `Dispatched SMS batch to ${successfulNumbers.length} recipients (${failedNumbers.length} failed)`,
    user.name
  );

  return res.json({
    success: successfulNumbers.length > 0,
    dispatchId,
    gatewayUsed: smsService.getStatus().provider,
    senderId: smsService.getStatus().senderId,
    totalRecipients: recipients.length,
    sentCount: successfulNumbers.length,
    failedCount: failedNumbers.length,
    successfulNumbers,
    failedNumbers,
    characterCount: String(message).length,
    smsSegments: Math.ceil(String(message).length / 160),
    logs: logsCreated,
    timestamp: new Date().toISOString(),
  });
});

// SMS Status (Computed strictly from real configuration and communication_logs)
router.get('/sms/status', authenticateToken, requirePermission('communications.manage'), (req: AuthenticatedRequest, res: Response) => {
  const smsConfig = smsService.getStatus();
  const allLogs = (db.getState().communicationLogs || []).filter((l) => l.channel === 'SMS');
  const summary = communicationLogService.computeSummary(allLogs);

  return res.json({
    status: 'Online',
    primaryGateway: smsConfig.provider,
    activeSenderHeader: smsConfig.senderId,
    configured: smsConfig.configured,
    totalSmsLogs: summary.total,
    sentCount: summary.sentCount + summary.deliveredCount,
    failedCount: summary.failedCount,
    deliveryRatePercent: summary.deliverySuccessRate,
  });
});

// 2. Bible API Endpoints
router.get('/bible/search', (req: Request, res: Response) => {
  const query = String(req.query.q || '').toLowerCase();
  const lang = String(req.query.lang || 'en');

  let results = BIBLE_VERSES;
  if (query) {
    results = BIBLE_VERSES.filter((v) =>
      v.reference.toLowerCase().includes(query) ||
      v.text_en.toLowerCase().includes(query) ||
      v.text_am.includes(query) ||
      v.text_om.toLowerCase().includes(query) ||
      v.theme.toLowerCase().includes(query)
    );
  }

  return res.json({
    query,
    count: results.length,
    verses: results.map((v) => ({
      reference: v.reference,
      book: v.book,
      chapter: v.chapter,
      verse: v.verse,
      theme: v.theme,
      text: lang === 'am' ? v.text_am : lang === 'om' ? v.text_om : lang === 'ti' ? v.text_ti : v.text_en,
      translations: {
        en: v.text_en,
        am: v.text_am,
        om: v.text_om,
        ti: v.text_ti,
      },
    })),
  });
});

router.get('/bible/verse-of-the-day', (req: Request, res: Response) => {
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 1000 / 60 / 60 / 24);
  const verse = BIBLE_VERSES[dayOfYear % BIBLE_VERSES.length];

  return res.json({
    date: today.toISOString().split('T')[0],
    ...verse,
  });
});

// 3. Automated Event Messaging API (Birthdays, Wedding Anniversaries, Milestones)
router.get('/events/upcoming', authenticateToken, requirePermission('events.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let members = db.getState().members;

  // Tenant Isolation
  members = members.filter((m) => !m.tenantId || m.tenantId === user.tenantId);

  // Branch Isolation
  if (!user.branchIds.includes('*')) {
    members = members.filter((m) => user.branchIds.includes(m.branchId));
  }

  const today = new Date();
  const currentMonth = today.getMonth() + 1;
  const currentDay = today.getDate();

  // Find Birthday Events (upcoming within 30 days)
  const birthdays = members.map((m) => {
    if (!m.dateOfBirth) return null;
    const dob = new Date(m.dateOfBirth);
    const dobMonth = dob.getMonth() + 1;
    const dobDay = dob.getDate();
    const isToday = dobMonth === currentMonth && dobDay === currentDay;

    return {
      memberId: m.id,
      fullName: `${m.title} ${m.firstName} ${m.lastName}`,
      phone: m.primaryPhone,
      email: m.email,
      dateOfBirth: m.dateOfBirth,
      ageTurning: today.getFullYear() - dob.getFullYear(),
      isToday,
      birthMonth: dobMonth,
      birthDay: dobDay,
    };
  }).filter(Boolean);

  // Find Wedding Anniversaries (only married members with marriageDate)
  const anniversaries = members.filter((m) => m.maritalStatus === 'Married' && m.marriageDate).map((m) => {
    const md = new Date(m.marriageDate!);
    const mdMonth = md.getMonth() + 1;
    const mdDay = md.getDate();
    const isToday = mdMonth === currentMonth && mdDay === currentDay;
    const yearsMarried = today.getFullYear() - md.getFullYear();

    return {
      memberId: m.id,
      fullName: `${m.title} ${m.firstName} ${m.lastName}`,
      phone: m.primaryPhone,
      spouseName: m.spouseName || 'Spouse',
      spousePhone: m.spousePhone || '',
      marriageDate: m.marriageDate,
      yearsMarried: yearsMarried > 0 ? yearsMarried : 1,
      isToday,
      anniversaryMonth: mdMonth,
      anniversaryDay: mdDay,
    };
  });

  return res.json({
    todayDate: today.toISOString().split('T')[0],
    birthdaysTodayCount: birthdays.filter((b: any) => b.isToday).length,
    anniversariesTodayCount: anniversaries.filter((a: any) => a.isToday).length,
    birthdays,
    anniversaries,
  });
});

// Trigger Birthday or Anniversary Message Dispatch
router.post('/events/send-wishes', authenticateToken, requirePermission('communications.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { eventType, memberId, channel = 'SMS', customMessage } = req.body;
  const member = db.getState().members.find((m) => m.id === memberId);

  if (!member) {
    return res.status(404).json({ error: 'Member not found' });
  }

  const access = verifyResourceAccess(member, user);
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  let defaultMsg = '';
  if (eventType === 'birthday') {
    defaultMsg = `Happy Birthday ${member.title} ${member.firstName}! Grace Cathedral celebrates God's faithfulness in your life. "The Lord bless you and keep you" (Numbers 6:24). Enjoy your special day in God's grace!`;
  } else if (eventType === 'anniversary') {
    defaultMsg = `Happy Wedding Anniversary to ${member.firstName} and ${member.spouseName || 'your beloved spouse'}! May the Lord continue to bless your marriage with enduring joy and divine love. Warm blessings from your Church Family!`;
  }

  const finalMessage = customMessage || defaultMsg;
  const dispatchId = `EVENT-MSG-${Date.now().toString().slice(-6)}`;

  db.addAuditLog(
    `Sent ${eventType === 'birthday' ? 'Birthday Blessing' : 'Wedding Anniversary Wish'}`,
    'Communications',
    `Dispatched ${channel} greeting to ${member.firstName} ${member.lastName} (${member.primaryPhone})`
  );

  return res.json({
    success: true,
    dispatchId,
    recipient: `${member.firstName} ${member.lastName}`,
    phone: member.primaryPhone,
    spousePhone: member.spousePhone,
    channel,
    message: finalMessage,
    timestamp: new Date().toISOString(),
  });
});

export default router;
