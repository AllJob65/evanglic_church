import { Router, Response } from 'express';
import { db } from '../db';
import { MinistryChatMessage, MinistryVideoRoom, VideoParticipant } from '../../src/types';
import { socketService } from '../../src/services/socketService';
import {
  authenticateToken,
  AuthenticatedRequest,
} from '../../src/security/authorization';

const router = Router();

// In-memory persistent stores for real-time collaboration
const ministryMessagesStore: Map<string, MinistryChatMessage[]> = new Map();
const activeVideoRoomsStore: Map<string, MinistryVideoRoom> = new Map();

// Apply authentication across all ministry collaboration routes
router.use(authenticateToken);

// Helper to check user access to a specific ministry
function canAccessMinistry(req: AuthenticatedRequest, ministryId: string): boolean {
  const user = req.user!;
  if (['SYSTEM_ADMIN', 'PASTOR', 'BRANCHADMIN'].includes(user.role)) {
    return true;
  }
  const state = db.getState();
  const ministry = (state.ministries || []).find((m) => m.id === ministryId);
  if (!ministry) return false;
  // Ensure same tenant
  if (ministry.tenantId && ministry.tenantId !== user.tenantId) {
    return false;
  }
  // Check if leader or member
  if (ministry.leaderMemberId === user.id) return true;
  const member = (state.members || []).find((m) => m.id === user.id || m.email === user.email);
  if (member && member.ministryIds?.includes(ministryId)) return true;
  // Default allow general church collaboration for members in the same tenant
  return true;
}

// 1. GET MESSAGES FOR A MINISTRY (Scoped by Tenant and Ministry)
router.get('/messages/:ministryId', (req: AuthenticatedRequest, res: Response) => {
  const { ministryId } = req.params;
  const user = req.user!;

  if (!canAccessMinistry(req, ministryId)) {
    return res.status(403).json({ error: 'Access denied: You are not authorized to access this ministry channel.' });
  }

  const messages = ministryMessagesStore.get(ministryId) || [];
  const scopedMessages = messages.filter((m) => !m.tenantId || m.tenantId === user.tenantId);

  return res.json({
    success: true,
    tenantId: user.tenantId,
    ministryId,
    count: scopedMessages.length,
    messages: scopedMessages,
  });
});

// 2. SEND MESSAGE TO MINISTRY CHANNEL (Scoped by Tenant & User)
router.post('/messages/:ministryId', (req: AuthenticatedRequest, res: Response) => {
  const { ministryId } = req.params;
  const { text, scriptureRef, attachmentUrl, attachmentName } = req.body;
  const user = req.user!;

  if (!canAccessMinistry(req, ministryId)) {
    return res.status(403).json({ error: 'Access denied: You are not authorized to post in this ministry channel.' });
  }

  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Message text is required' });
  }

  const ministries = db.getState().ministries || [];
  const ministry = ministries.find((m) => m.id === ministryId);
  const ministryName = ministry?.name || 'Church Ministry Fellowship';

  const newMessage: MinistryChatMessage = {
    id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    tenantId: user.tenantId,
    ministryId,
    ministryName,
    senderId: user.id,
    senderName: user.name || 'Church Member',
    senderEmail: user.email || 'member@gracecathedral.org',
    senderRole: user.role || 'Member',
    senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    text: text.trim(),
    scriptureRef: scriptureRef || undefined,
    attachmentUrl: attachmentUrl || undefined,
    attachmentName: attachmentName || undefined,
    timestamp: new Date().toISOString(),
    reactions: [],
  };

  const currentList = ministryMessagesStore.get(ministryId) || [];
  currentList.push(newMessage);
  ministryMessagesStore.set(ministryId, currentList);

  // Broadcast in real-time via Socket.io to ministry channel
  const io = socketService.getIO();
  if (io) {
    const roomKey = `ministry:${user.tenantId}:${ministryId}`;
    io.to(roomKey).emit('chat:new_message', {
      message: newMessage,
      ministryId,
      tenantId: user.tenantId,
    });
  }

  return res.status(201).json({
    success: true,
    message: newMessage,
  });
});

// 3. REACT TO MESSAGE (Emoji)
router.post('/messages/:ministryId/:messageId/react', (req: AuthenticatedRequest, res: Response) => {
  const { ministryId, messageId } = req.params;
  const { emoji } = req.body;
  const user = req.user!;

  if (!canAccessMinistry(req, ministryId)) {
    return res.status(403).json({ error: 'Access denied: You are not authorized for this ministry.' });
  }

  const list = ministryMessagesStore.get(ministryId) || [];
  const target = list.find((m) => m.id === messageId);
  if (!target) {
    return res.status(404).json({ error: 'Message not found' });
  }

  if (!target.reactions) target.reactions = [];
  const existingReaction = target.reactions.find((r) => r.emoji === emoji);
  if (existingReaction) {
    if (!existingReaction.users.includes(user.id)) {
      existingReaction.users.push(user.id);
      existingReaction.count += 1;
    }
  } else {
    target.reactions.push({ emoji, count: 1, users: [user.id] });
  }

  const io = socketService.getIO();
  if (io) {
    io.to(`ministry:${user.tenantId}:${ministryId}`).emit('chat:reaction_updated', {
      messageId,
      reactions: target.reactions,
    });
  }

  return res.json({ success: true, reactions: target.reactions });
});

// 4. GET / INITIALIZE VIDEO CONFERENCE ROOM FOR MINISTRY
router.get('/video-room/:ministryId', (req: AuthenticatedRequest, res: Response) => {
  const { ministryId } = req.params;
  const user = req.user!;

  if (!canAccessMinistry(req, ministryId)) {
    return res.status(403).json({ error: 'Access denied: You are not authorized for this ministry.' });
  }

  const ministries = db.getState().ministries || [];
  const ministry = ministries.find((m) => m.id === ministryId);
  const ministryName = ministry?.name || 'Ministry Video Room';

  let room = activeVideoRoomsStore.get(ministryId);
  if (!room || !room.isActive) {
    room = {
      roomId: `room-${ministryId}-${user.tenantId}`,
      tenantId: user.tenantId,
      ministryId,
      ministryName,
      title: `${ministryName} — Live Fellowship & Prayer`,
      hostId: ministry?.leaderMemberId || user.id,
      hostName: ministry?.leaderMemberName || ministry?.leaderName || user.name || 'Ministry Director',
      participants: [
        {
          id: `part-${Date.now()}-leader`,
          userId: ministry?.leaderMemberId || user.id,
          name: ministry?.leaderMemberName || ministry?.leaderName || user.name || 'Leader (Host)',
          role: 'Leader',
          isMuted: false,
          isVideoOff: false,
          isScreenSharing: false,
          isSpeaking: true,
          joinedAt: new Date().toISOString(),
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
        },
      ],
      isActive: true,
      startedAt: new Date().toISOString(),
    };
    activeVideoRoomsStore.set(ministryId, room);
  }

  return res.json({
    success: true,
    room,
  });
});

// 5. JOIN / LEAVE VIDEO ROOM ACTIONS
router.post('/video-room/:ministryId/join', (req: AuthenticatedRequest, res: Response) => {
  const { ministryId } = req.params;
  const { avatar } = req.body;
  const user = req.user!;

  if (!canAccessMinistry(req, ministryId)) {
    return res.status(403).json({ error: 'Access denied.' });
  }

  let room = activeVideoRoomsStore.get(ministryId);
  if (!room) {
    const ministries = db.getState().ministries || [];
    const min = ministries.find((m) => m.id === ministryId);
    room = {
      roomId: `room-${ministryId}-${user.tenantId}`,
      tenantId: user.tenantId,
      ministryId,
      ministryName: min?.name || 'Ministry Video Room',
      title: `${min?.name || 'Ministry'} — Video Room`,
      hostId: user.id,
      hostName: user.name || 'Leader',
      participants: [],
      isActive: true,
      startedAt: new Date().toISOString(),
    };
    activeVideoRoomsStore.set(ministryId, room);
  }

  const existingIdx = room.participants.findIndex((p) => p.userId === user.id);
  const newParticipant: VideoParticipant = {
    id: `part-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    userId: user.id,
    name: user.name || 'Church Member',
    role: user.role || 'Member',
    avatar: avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    isMuted: false,
    isVideoOff: false,
    isScreenSharing: false,
    joinedAt: new Date().toISOString(),
  };

  if (existingIdx >= 0) {
    room.participants[existingIdx] = newParticipant;
  } else {
    room.participants.push(newParticipant);
  }

  const io = socketService.getIO();
  if (io) {
    io.to(`video:${room.roomId}`).emit('video:participant_joined', {
      room,
      participant: newParticipant,
    });
  }

  return res.json({ success: true, room, participant: newParticipant });
});

router.post('/video-room/:ministryId/leave', (req: AuthenticatedRequest, res: Response) => {
  const { ministryId } = req.params;
  const user = req.user!;

  const room = activeVideoRoomsStore.get(ministryId);
  if (room) {
    room.participants = room.participants.filter((p) => p.userId !== user.id);
    const io = socketService.getIO();
    if (io) {
      io.to(`video:${room.roomId}`).emit('video:participant_left', {
        userId: user.id,
        roomId: room.roomId,
      });
    }
  }

  return res.json({ success: true, message: 'Left video room' });
});

export default router;
