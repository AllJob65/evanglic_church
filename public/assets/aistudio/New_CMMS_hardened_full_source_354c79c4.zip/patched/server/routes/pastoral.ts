import { Router, Response } from 'express';
import { db } from '../db';
import { PrayerRequest, CounselingSession, VisitationRecord, CommunicationMessage } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  verifyResourceAccess,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { publicFormsLimiter } from '../middleware/rateLimiter';

const router = Router();

// Every staff-created pastoral record must belong to a branch the caller is
// explicitly assigned to. A wildcard assignment is the only tenant-wide bypass.
function canWritePastoralBranch(user: NonNullable<AuthenticatedRequest['user']>, branchId: string | undefined): boolean {
  return Boolean(branchId) && (user.branchIds.includes('*') || user.branchIds.includes(branchId!));
}

// Public Prayer Request endpoint protected by publicFormsLimiter
router.post('/prayer/public', publicFormsLimiter, (req: any, res: Response) => {
  const tenantId = process.env.CMMS_PUBLIC_PRAYER_TENANT_ID?.trim();
  const branchId = process.env.CMMS_PUBLIC_PRAYER_BRANCH_ID?.trim();
  if (!tenantId || !branchId) {
    return res.status(503).json({
      error: 'Public prayer submissions are not configured for this church.',
      code: 'PUBLIC_PRAYER_SCOPE_NOT_CONFIGURED',
    });
  }

  const { name, phone, email, title, details, category, isConfidential } = req.body;
  if (!title && !details) {
    return res.status(400).json({ error: 'Title or prayer details are required.' });
  }

  const prayer: PrayerRequest = {
    id: `pr-${Date.now()}`,
    tenantId,
    branchId,
    memberId: 'public-visitor',
    memberName: name || 'Anonymous Visitor',
    phone: phone || '',
    email: email || '',
    requestNumber: `PR-${Date.now().toString().slice(-4)}`,
    title: title || 'Pastoral Prayer Request',
    description: details || title || 'Pastoral Prayer Request',
    details: details || '',
    category: category || 'General Intercession',
    urgency: 'Medium',
    urgencyLevel: 'Medium',
    submittedDate: new Date().toISOString().split('T')[0],
    isConfidential: Boolean(isConfidential),
    status: 'Pending',
  };

  db.getState().prayerRequests.unshift(prayer);
  db.persist();
  db.addAuditLog('Public Prayer Request', 'Pastoral Care', `Public prayer request submitted by ${prayer.memberName}: "${prayer.title}"`, 'Public Gateway');
  return res.status(201).json({ success: true, message: 'Your prayer request has been received by our pastoral care team.', id: prayer.id });
});

// Apply authentication to all internal pastoral care & communication endpoints
router.use(authenticateToken);

// ==============================================================================
// PRAYER REQUESTS - Enforce prayer.read, prayer.create, prayer.update
// ==============================================================================
router.get('/prayer', requirePermission('prayer.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let list = db.getState().prayerRequests;

  // Tenant Isolation
  list = list.filter((p) => Boolean(p.tenantId) && p.tenantId === user.tenantId);

  // If Regular Member, only return own prayer requests
  if (user.role === 'REGULAR_MEMBER') {
    list = list.filter(
      (p) =>
        p.memberId === user.id ||
        (user.memberId && p.memberId === user.memberId) ||
        (p as any).submittedById === user.id
    );
  } else {
    // Branch Isolation for pastoral staff
    if (!user.branchIds.includes('*')) {
      list = list.filter((p) => Boolean(p.branchId) && user.branchIds.includes(p.branchId));
    }
  }

  return res.json(list);
});

router.post('/prayer', requirePermission('prayer.create'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const reqData: PrayerRequest = req.body;
  const targetBranchId = reqData.branchId || user.branchId;
  if (!canWritePastoralBranch(user, targetBranchId)) {
    return res.status(403).json({ error: 'You are not assigned to the requested branch.', code: 'BRANCH_SCOPE_DENIED' });
  }

  const prayer: PrayerRequest = {
    ...reqData,
    id: reqData.id || `pr-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: targetBranchId,
    memberId: user.role === 'REGULAR_MEMBER' ? (user.memberId || user.id) : (reqData.memberId || user.id),
    memberName: user.role === 'REGULAR_MEMBER' ? user.name : (reqData.memberName || user.name),
    requestNumber: reqData.requestNumber || `PR-${Date.now().toString().slice(-4)}`,
    submittedDate: reqData.submittedDate || new Date().toISOString().split('T')[0],
    status: reqData.status || 'Pending',
  };

  db.getState().prayerRequests.unshift(prayer);
  db.persist();
  db.addAuditLog('Add Prayer Request', 'Pastoral Care', `Logged prayer request for ${prayer.memberName}: "${prayer.title}"`, user.name);
  return res.status(201).json(prayer);
});

router.put('/prayer/:id/status', requirePermission('prayer.update'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { status, notes } = req.body;
  const reqItem = db.getState().prayerRequests.find((p) => p.id === id);
  if (!reqItem) return res.status(404).json({ error: 'Prayer request not found' });

  const access = verifyResourceAccess(reqItem, user);
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  reqItem.status = status;
  if (notes) reqItem.testimonyNotes = notes;
  db.persist();
  db.addAuditLog('Update Prayer Status', 'Pastoral Care', `Updated prayer request #${id} status to ${status}`, user.name);
  return res.json(reqItem);
});

// ==============================================================================
// COUNSELING SESSIONS - Enforce counseling.read, counseling.create, confidentiality
// ==============================================================================
router.get('/counseling', requirePermission('counseling.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let list = db.getState().counselingSessions;

  // Tenant Isolation
  list = list.filter((c) => Boolean(c.tenantId) && c.tenantId === user.tenantId);

  // Member Ownership Isolation
  if (user.role === 'REGULAR_MEMBER') {
    list = list.filter((c) => c.memberId === user.id || (user.memberId && c.memberId === user.memberId));
  } else {
    // Pastoral staff: Filter branch and confidentiality
    if (!user.branchIds.includes('*')) {
      list = list.filter((c) => Boolean(c.branchId) && user.branchIds.includes(c.branchId));
    }

    // Sealed notes: only counselor can view
    list = list.filter((c) => {
      if ((c as any).confidentialityLevel === 'SEALED') {
        return c.counselorId === user.id;
      }
      return true;
    });
  }

  return res.json(list);
});

router.post('/counseling', requirePermission('counseling.create'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const sessionData: CounselingSession = req.body;
  const targetBranchId = sessionData.branchId || user.branchId;
  if (!canWritePastoralBranch(user, targetBranchId)) {
    return res.status(403).json({ error: 'You are not assigned to the requested branch.', code: 'BRANCH_SCOPE_DENIED' });
  }

  const session: CounselingSession = {
    ...sessionData,
    id: sessionData.id || `coun-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: targetBranchId,
    counselorId: sessionData.counselorId || user.id,
    counselorName: sessionData.counselorName || user.name,
    sessionCode: sessionData.sessionCode || `CS-${Date.now().toString().slice(-4)}`,
    sessionDate: sessionData.sessionDate || new Date().toISOString().split('T')[0],
    sessionTime: sessionData.sessionTime || '14:00',
  };

  db.getState().counselingSessions.unshift(session);
  db.persist();
  db.addAuditLog('Add Counseling Session', 'Pastoral Care', `Recorded confidential counseling session with ${session.counselorName}`, user.name);
  return res.status(201).json(session);
});

// GET single counseling session - IDOR & Confidentiality Protected
router.get('/counseling/:id', requirePermission('counseling.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const session = db.getState().counselingSessions.find((c) => c.id === id);
  if (!session) {
    return res.status(404).json({ error: 'Counseling session record not found' });
  }

  const access = verifyResourceAccess(session, user, { checkOwnership: user.role === 'REGULAR_MEMBER' });
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  // Sealed notes confidentiality
  if ((session as any).confidentialityLevel === 'SEALED') {
    const isCounselor = session.counselorId === user.id;
    const isOwner = session.memberId === user.id || (user.memberId && session.memberId === user.memberId);
    if (!isCounselor && !isOwner) {
      return res.status(403).json({ error: 'Access denied: confidential counseling session notes are sealed.', code: 'SEALED_CONFIDENTIAL' });
    }
  }

  return res.json(session);
});

// GET pastoral record by ID - IDOR Protected
router.get('/:id', requirePermission('pastoral.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const state = db.getState();
  const session = state.counselingSessions.find((c) => c.id === id);
  if (session) {
    const access = verifyResourceAccess(session, user, { checkOwnership: user.role === 'REGULAR_MEMBER' });
    if (!access.authorized) return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });

    // Keep SEALED access explicit on this generic ID lookup too. The shared
    // authorization helper intentionally has a SYSTEM_ADMIN bypass for general
    // resources, but sealed counseling notes remain counselor/owner restricted.
    if ((session as any).confidentialityLevel === 'SEALED') {
      const isCounselor = session.counselorId === user.id;
      const isOwner = session.memberId === user.id || (user.memberId && session.memberId === user.memberId);
      if (!isCounselor && !isOwner) {
        return res.status(403).json({ error: 'Access denied: confidential counseling session notes are sealed.', code: 'SEALED_CONFIDENTIAL' });
      }
    }
    return res.json(session);
  }

  const visit = state.visitations.find((v) => v.id === id);
  if (visit) {
    const access = verifyResourceAccess(visit, user);
    if (!access.authorized) return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
    return res.json(visit);
  }

  const prayer = state.prayerRequests.find((p) => p.id === id);
  if (prayer) {
    const access = verifyResourceAccess(prayer, user, { checkOwnership: user.role === 'REGULAR_MEMBER' });
    if (!access.authorized) return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
    return res.json(prayer);
  }

  return res.status(404).json({ error: 'Pastoral record not found' });
});

// ==============================================================================
// VISITATIONS - Enforce visitations.read, visitations.manage
// ==============================================================================
router.get('/visitations', requirePermission('visitations.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let list = db.getState().visitations;

  // Tenant Isolation
  list = list.filter((v) => Boolean(v.tenantId) && v.tenantId === user.tenantId);

  // Branch Isolation
  if (!user.branchIds.includes('*')) {
    list = list.filter((v) => Boolean(v.branchId) && user.branchIds.includes(v.branchId));
  }

  return res.json(list);
});

router.post('/visitations', requirePermission('visitations.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const visData: VisitationRecord = req.body;
  const targetBranchId = visData.branchId || user.branchId;
  if (!canWritePastoralBranch(user, targetBranchId)) {
    return res.status(403).json({ error: 'You are not assigned to the requested branch.', code: 'BRANCH_SCOPE_DENIED' });
  }
  const record: VisitationRecord = {
    ...visData,
    id: visData.id || `vis-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: targetBranchId,
    visitationCode: visData.visitationCode || `VIS-${Date.now().toString().slice(-4)}`,
    visitDate: visData.visitDate || new Date().toISOString().split('T')[0],
  };

  db.getState().visitations.unshift(record);
  db.persist();
  db.addAuditLog('Record Visitation', 'Pastoral Care', `Completed pastoral home visitation to ${record.memberName}`, user.name);
  return res.status(201).json(record);
});

// ==============================================================================
// COMMUNICATIONS (SMS / Email) - Enforce communications.read, communications.manage
// ==============================================================================
router.get('/communications', requirePermission('communications.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let list = db.getState().communications;

  // Tenant Isolation
  list = list.filter((c) => Boolean(c.tenantId) && c.tenantId === user.tenantId);

  // Branch Isolation
  if (!user.branchIds.includes('*')) {
    list = list.filter((c) => Boolean(c.branchId) && user.branchIds.includes(c.branchId));
  }

  return res.json(list);
});

router.post('/communications/send', requirePermission('communications.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const commData: CommunicationMessage = req.body;
  const targetBranchId = commData.branchId || user.branchId;
  if (!canWritePastoralBranch(user, targetBranchId)) {
    return res.status(403).json({ error: 'You are not assigned to the requested branch.', code: 'BRANCH_SCOPE_DENIED' });
  }
  const message: CommunicationMessage = {
    ...commData,
    id: commData.id || `comm-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: targetBranchId,
    sentAt: new Date().toISOString(),
    status: 'Sent',
    deliveryRatePercentage: 100,
  };

  db.getState().communications.unshift(message);
  db.persist();
  db.addAuditLog('Broadcast Communication', 'Communications', `Sent ${message.channel} broadcast: "${message.subject}" to ${message.targetAudience}`, user.name);
  return res.status(201).json(message);
});

export default router;
