import { Router, Response } from 'express';
import { socketService } from '../../src/services/socketService';
import { GroupChatSession, UserRole } from '../../src/types';
import {
  authenticateToken,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { db } from '../db';
import {
  isLeaderOfGroup,
  logPermissionDenied,
} from '../services/membershipService';

const router = Router();

// Enforce authentication across all group chat endpoints
router.use(authenticateToken);

// Helper to get or initialize persistent chat sessions from db
function getChatSessions(): GroupChatSession[] {
  const state = db.getState();
  if (!state.groupChatSessions || state.groupChatSessions.length === 0) {
    const initialSession: GroupChatSession = {
      id: 'chat-session-min-1-seed',
      groupId: 'min-1',
      leaderId: 'usr-leader-worship',
      isActive: true,
      startedAt: new Date().toISOString(),
    };
    state.groupChatSessions = [initialSession];
    db.save();
  }
  return state.groupChatSessions;
}

/**
 * POST /api/group-chats/start
 * Leader triggers a live group chat session
 */
router.post('/start', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { groupId } = req.body;

  if (!groupId) {
    return res.status(400).json({ error: 'groupId is required' });
  }

  // 1. Role verification matching socket handler
  const allowedRoles: UserRole[] = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'];
  if (!allowedRoles.includes(user.role)) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'rest_start_chat',
      targetType: 'group',
      targetId: groupId,
      reason: 'Role is not authorized to start group chats.',
      ipAddress: req.ip,
    });
    return res.status(403).json({
      error: 'Forbidden: Only ministry leaders and pastors can initiate chat sessions.',
      code: 'FORBIDDEN_ROLE',
    });
  }

  // 2. Specific leadership verification for THIS group
  const isLeader = await isLeaderOfGroup(user.id, groupId, user.role, user.email);
  if (!isLeader) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'rest_start_chat',
      targetType: 'group',
      targetId: groupId,
      reason: 'User is not the assigned leader or administrator of this group.',
      ipAddress: req.ip,
    });
    return res.status(403).json({
      error: 'Forbidden: You are not the assigned leader for this group.',
      code: 'FORBIDDEN_LEADER',
    });
  }

  const sessionId = `chat-session-${groupId}-${Date.now()}`;
  const newSession: GroupChatSession = {
    id: sessionId,
    groupId,
    leaderId: user.id,
    isActive: true,
    startedAt: new Date().toISOString(),
  };

  const sessions = getChatSessions();
  sessions.push(newSession);
  db.save();

  db.addAuditLog(
    'Start Realtime Chat Session',
    'Ministry Collaboration',
    `Leader ${user.name} initiated live chat session for group "${groupId}" via REST API`,
    user.email
  );

  // Broadcast to all active members in the group across tenant and legacy room formats
  const io = socketService.getIO();
  if (io) {
    io.to(`group:${user.tenantId}:${groupId}`).emit('chat_session_started', {
      sessionId: newSession.id,
      groupId,
      leaderId: newSession.leaderId,
      leaderName: user.name,
      isActive: true,
      startedAt: newSession.startedAt,
    });
    io.to(`group_${groupId}`).emit('chat_session_started', {
      sessionId: newSession.id,
      groupId,
      leaderId: newSession.leaderId,
      leaderName: user.name,
      isActive: true,
      startedAt: newSession.startedAt,
    });
  }

  return res.status(201).json({
    success: true,
    session: newSession,
  });
});

/**
 * GET /api/group-chats/active
 * Query active chat session for a group
 */
router.get('/active', (req: AuthenticatedRequest, res: Response) => {
  const { groupId } = req.query;
  const sessions = getChatSessions();

  const allActive = sessions.filter(
    (s) => s.isActive && (!groupId || s.groupId === groupId)
  );

  const activeSession = allActive.length > 0 ? allActive[allActive.length - 1] : null;

  return res.json({
    success: true,
    activeSession,
  });
});

/**
 * POST /api/group-chats/:id/end
 * End an active chat session
 */
router.post('/:id/end', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const sessions = getChatSessions();
  const session = sessions.find((s) => s.id === id);

  if (!session) {
    return res.status(404).json({ error: 'Chat session not found' });
  }

  const isPrivileged = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'BRANCHADMIN'].includes(user.role);
  let isAuthorized = isPrivileged;

  if (!isAuthorized) {
    if (session.leaderId === user.id) {
      // Must also verify user is actually an assigned leader of THIS group
      const isGroupLeader = await isLeaderOfGroup(user.id, session.groupId, user.role, user.email);
      if (isGroupLeader) {
        isAuthorized = true;
      }
    }
  }

  if (!isAuthorized) {
    logPermissionDenied({
      userId: user.id,
      userEmail: user.email,
      userRole: user.role,
      action: 'rest_end_chat',
      targetType: 'group',
      targetId: session.groupId,
      reason: 'User attempted to end a chat session for a group they do not lead or oversee.',
      ipAddress: req.ip,
    });
    return res.status(403).json({
      error: 'Unauthorized to end this chat session',
      code: 'FORBIDDEN_LEADER',
    });
  }

  session.isActive = false;
  session.endedAt = new Date().toISOString();
  db.save();

  db.addAuditLog(
    'End Realtime Chat Session',
    'Ministry Collaboration',
    `User ${user.name} ended live chat session for group "${session.groupId}"`,
    user.email
  );

  const io = socketService.getIO();
  if (io) {
    io.to(`group:${user.tenantId}:${session.groupId}`).emit('chat_session_ended', {
      sessionId: session.id,
      groupId: session.groupId,
    });
    io.to(`group_${session.groupId}`).emit('chat_session_ended', {
      sessionId: session.id,
      groupId: session.groupId,
    });
  }

  return res.json({
    success: true,
    message: 'Chat session ended',
    session,
  });
});

export default router;
