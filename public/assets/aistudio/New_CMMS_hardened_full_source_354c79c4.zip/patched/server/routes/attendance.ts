import { timingSafeEqual } from 'node:crypto';
import { Router, Response } from 'express';
import { db } from '../db';
import { AttendanceRecord, AttendanceSession, EventItem } from '../../src/types';
import { socketService } from '../../src/services/socketService';
import {
  authenticateToken,
  requirePermission,
  verifyResourceAccess,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { query, withTransaction } from '../pg';
import { isDatabaseUuid } from '../repositories/memberRepository';
import {
  closeAttendanceSession,
  createAttendanceSession,
  getAttendanceSession,
  listAttendanceSessions,
  rotateAttendanceSessionQrToken,
  type AttendanceSessionRecord,
} from '../repositories/attendanceSessionRepository';
import { createSessionCheckIn } from '../repositories/attendanceCheckInRepository';

const router = Router();

// Apply authentication to all attendance endpoints
router.use(authenticateToken);

// ==========================================
// ATTENDANCE SESSIONS (Leader Live Activation)
// ==========================================

function attendanceScope(user: NonNullable<AuthenticatedRequest['user']>) {
  return { tenantId: user.tenantId, branchId: user.branchId, branchIds: user.branchIds || [] };
}

function toAttendanceSession(row: AttendanceSessionRecord): AttendanceSession {
  return {
    id: row.id,
    sessionId: row.sessionCode,
    tenantId: row.tenantId,
    groupId: row.groupId || '',
    groupName: row.groupName || '',
    branchId: row.branchId,
    leaderId: row.leaderUserId || '',
    leaderName: row.leaderName || '',
    type: row.sessionType === 'scheduled' ? 'scheduled' : 'instant',
    title: row.title,
    serviceType: row.serviceType,
    status: row.status,
    startTime: row.startTime,
    endTime: row.endTime,
    qrPayloadToken: row.qrPayloadToken,
    location: row.location || '',
    attendeeCount: row.attendeeCount,
  };
}

function sendAttendanceRepositoryError(res: Response, error: unknown) {
  const message = error instanceof Error ? error.message : 'Attendance operation failed.';
  if (/outside the authenticated user scope/i.test(message)) {
    return res.status(403).json({ error: message, code: 'BRANCH_ACCESS_DENIED' });
  }
  if (/not found/i.test(message)) return res.status(404).json({ error: message });
  if (/valid .* UUID|required|belongs to this tenant/i.test(message)) {
    return res.status(400).json({ error: message });
  }
  console.error('[Attendance PostgreSQL]', message);
  return res.status(500).json({ error: 'Attendance operation failed.' });
}

// GET all or active sessions — PostgreSQL is authoritative.
router.get('/sessions', requirePermission('attendance.read'), async (req: AuthenticatedRequest, res: Response, next) => {
  try {
    const user = req.user!;
    const status = req.query.status === 'active' || req.query.status === 'closed'
      ? req.query.status : undefined;
    const groupId = typeof req.query.groupId === 'string' ? req.query.groupId : undefined;
    const branchId = typeof req.query.branchId === 'string' ? req.query.branchId : undefined;
    const rows = await listAttendanceSessions(attendanceScope(user), { status, groupId, branchId });
    return res.json(rows.map(toAttendanceSession));
  } catch (error) {
    if (error instanceof Error && /scope|UUID|branch/i.test(error.message)) return sendAttendanceRepositoryError(res, error);
    return next(error);
  }
});

// GET single session — tenant and branch scope enforced in repository.
router.get('/sessions/:sessionId', requirePermission('attendance.read'), async (req: AuthenticatedRequest, res: Response, next) => {
  try {
    const row = await getAttendanceSession(attendanceScope(req.user!), req.params.sessionId);
    if (!row) return res.status(404).json({ error: 'Session not found' });
    return res.json(toAttendanceSession(row));
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// CREATE / ACTIVATE new session.
router.post('/sessions', requirePermission('attendance.create'), async (req: AuthenticatedRequest, res: Response, next) => {
  try {
    const user = req.user!;
    const { groupId, groupName, branchId, type = 'instant', title, serviceType = 'Ministry Attendance', location = 'Church Campus' } = req.body || {};
    if (typeof title !== 'string' || !title.trim()) return res.status(400).json({ error: 'Session title is required' });
    const targetBranch = branchId || user.branchId;
    const row = await createAttendanceSession(attendanceScope(user), {
      branchId: targetBranch,
      leaderUserId: user.id,
      leaderName: user.name,
      groupId: isDatabaseUuid(groupId) ? groupId : null,
      groupName: groupName || null,
      sessionType: type === 'scheduled' ? 'scheduled' : 'instant',
      title,
      serviceType,
      location,
    });
    const session = toAttendanceSession(row);
    db.addAuditLog('Activated Attendance Session', 'Attendance Management',
      `Leader ${user.name} started ${session.type} session "${session.title}" (${session.sessionId})`, user.name);
    try { socketService.emitToAll('attendance:session_started', session); }
    catch (err) { console.warn('[Socket] Session broadcast note:', err); }
    return res.status(201).json(session);
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// ROTATE SESSION QR TOKEN.
router.post('/sessions/:sessionId/rotate', requirePermission('attendance.update'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const row = await rotateAttendanceSessionQrToken(attendanceScope(req.user!), req.params.sessionId);
    if (!row) return res.status(404).json({ error: 'Session not found' });
    const session = toAttendanceSession(row);
    try { socketService.emitToAll('attendance:token_rotated', { sessionId: session.sessionId, qrPayloadToken: session.qrPayloadToken }); } catch {}
    return res.json({ success: true, sessionId: session.sessionId, qrPayloadToken: session.qrPayloadToken });
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// CLOSE ATTENDANCE SESSION.
router.post('/sessions/:sessionId/close', requirePermission('attendance.update'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const row = await closeAttendanceSession(attendanceScope(req.user!), req.params.sessionId);
    if (!row) return res.status(404).json({ error: 'Session not found' });
    const session = toAttendanceSession(row);
    db.addAuditLog('Closed Attendance Session', 'Attendance Management',
      `Session ID ${session.sessionId} marked as closed.`, req.user!.name);
    try { socketService.emitToAll('attendance:session_closed', { sessionId: session.sessionId, endTime: session.endTime }); } catch {}
    return res.json({ success: true, session });
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// MEMBER CHECK-IN TO SESSION — token-verified transactional PostgreSQL check-in.
router.post('/sessions/:sessionId/checkin', requirePermission('attendance.create'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const session = await getAttendanceSession(attendanceScope(user), req.params.sessionId);
    if (!session) return res.status(404).json({ error: 'Attendance session not found' });
    if (session.status !== 'active') {
      return res.status(400).json({ error: 'This attendance session has ended and is no longer accepting check-ins.' });
    }

    const isQr = req.body?.checkInType === 'qr' || req.body?.checkInType === 'QR Code Scanning';
    if (isQr) {
      const suppliedToken = req.body?.qrPayloadToken;
      if (typeof suppliedToken !== 'string' || suppliedToken.length < 32 ||
          suppliedToken.length !== session.qrPayloadToken.length ||
          !timingSafeEqual(Buffer.from(suppliedToken), Buffer.from(session.qrPayloadToken))) {
        return res.status(401).json({ error: 'Invalid or expired attendance QR token.', code: 'INVALID_QR_TOKEN' });
      }
    }

    const requestedId = user.role === 'REGULAR_MEMBER' ? (user.memberId || user.id) : req.body?.memberId;
    if (typeof requestedId !== 'string' || !requestedId.trim()) {
      return res.status(400).json({ error: 'A member ID is required for check-in.' });
    }
    const memberResult = await query<{ id: string; first_name: string; last_name: string }>(
      `SELECT id, first_name, last_name FROM public.members
        WHERE tenant_id = $1::uuid AND branch_id = $2::uuid
          AND (id::text = $3 OR member_number = $3)
        LIMIT 1`,
      [user.tenantId, session.branchId, requestedId.trim()],
    );
    const member = memberResult.rows[0];
    if (!member) return res.status(404).json({ error: 'Member does not exist in this tenant and session branch.' });

    const result = await createSessionCheckIn(
      { tenantId: user.tenantId, branchId: session.branchId, branchIds: user.branchIds || [] },
      {
        sessionCode: session.sessionCode,
        memberId: member.id,
        checkInMethod: isQr ? 'QR Code Scanning' : 'Manual Web Click',
        checkedInAt: new Date(),
        notes: `Verified check-in to session ${session.sessionCode}`,
      },
    );
    const record: AttendanceRecord = {
      id: result.record.id,
      tenantId: result.record.tenantId,
      sessionId: session.sessionCode,
      serviceName: result.record.eventName,
      eventName: result.record.eventName,
      serviceType: result.record.serviceType,
      branchId: result.record.branchId,
      date: result.record.checkInTime.slice(0, 10),
      time: new Date(result.record.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      memberId: result.record.memberId,
      memberName: result.record.memberName,
      checkInTime: new Date(result.record.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      checkedInTime: result.record.checkInTime,
      checkInType: isQr ? 'qr' : 'manual',
      checkInMethod: result.record.checkInMethod,
      status: 'Present',
      notes: `Verified check-in to session ${session.sessionCode}`,
    };
    if (!result.alreadyCheckedIn) {
      db.addAuditLog('Member Session Check-In', 'Attendance & Security',
        `${result.record.memberName} checked in to "${result.record.eventName}" (${session.sessionCode}) via ${result.record.checkInMethod}`, user.name);
      try {
        socketService.emitToAll('attendance:member_checked_in', {
          sessionId: session.sessionCode, record, attendeeCount: result.attendeeCount,
        });
      } catch {}
    }
    return res.status(result.alreadyCheckedIn ? 200 : 201).json({
      success: true,
      alreadyCheckedIn: result.alreadyCheckedIn,
      message: result.alreadyCheckedIn
        ? `Already checked into ${result.record.eventName}.`
        : `Attendance recorded successfully for ${result.record.eventName}!`,
      record,
      attendeeCount: result.attendeeCount,
    });
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// ==========================================
// STANDARD ATTENDANCE RECORDS ENDPOINTS
// ==========================================

// Attendance records are read and written from PostgreSQL only.
type AttendanceDbRow = {
  id: string; tenant_id: string; branch_id: string; event_name: string; service_type: string;
  member_id: string | null; visitor_name: string | null; visitor_phone: string | null;
  checkin_method: string | null; checkin_time: Date | string; session_id: string | null;
  record_code: string | null; member_name: string | null; status: string;
  absence_reason: string | null; notes: string | null; service_session: string | null; event_id: string | null;
};
const attendanceSelect = `SELECT id,tenant_id,branch_id,event_name,service_type,member_id,visitor_name,visitor_phone,
 checkin_method,checkin_time,session_id,record_code,member_name,status,absence_reason,notes,service_session,event_id
 FROM public.attendance_records`;

function mapAttendanceRow(row: AttendanceDbRow): AttendanceRecord {
  const checkedAt = new Date(row.checkin_time);
  return {
    id: row.id, tenantId: row.tenant_id, branchId: row.branch_id,
    sessionId: row.session_id || undefined,
    serviceName: row.event_name, eventName: row.event_name, serviceType: row.service_type,
    eventId: row.event_id || undefined, date: checkedAt.toISOString().slice(0, 10),
    time: checkedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    memberId: row.member_id || '', memberName: row.member_name || row.visitor_name || undefined,
    checkInTime: checkedAt.toISOString(),
    checkedInTime: checkedAt.toISOString(),
    checkInType: /qr/i.test(row.checkin_method || '') ? 'qr' : 'manual',
    checkInMethod: row.checkin_method || undefined,
    status: row.status, absenceReason: row.absence_reason || undefined, notes: row.notes || undefined,
    serviceSession: row.service_session || undefined,
  };
}

function attendanceBranchFilter(user: NonNullable<AuthenticatedRequest['user']>, requested?: unknown) {
  const allBranches = user.branchIds.includes('*');
  if (requested && requested !== 'all') {
    if (typeof requested !== 'string' || !isDatabaseUuid(requested)) throw new Error('A valid branch UUID is required.');
    if (!allBranches && !user.branchIds.includes(requested)) throw new Error('Attendance branch is outside the authenticated user scope.');
    return { sql: 'branch_id = $BRANCH::uuid', value: requested };
  }
  if (allBranches) return null;
  const ids = [...new Set([...(user.branchIds || []), user.branchId].filter(isDatabaseUuid))];
  if (!ids.length) throw new Error('Authenticated user has no authorized attendance branches.');
  return { sql: 'branch_id = ANY($BRANCH::uuid[])', value: ids };
}

// GET attendance records.
router.get('/', requirePermission('attendance.read'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const values: unknown[] = [user.tenantId];
    const where = ['tenant_id = $1::uuid'];
    const branch = attendanceBranchFilter(user, req.query.branchId);
    if (branch) {
      values.push(branch.value);
      where.push(branch.sql.replace('$BRANCH', String(values.length)));
    }
    if (typeof req.query.memberId === 'string' && req.query.memberId) {
      values.push(req.query.memberId);
      where.push(`member_id::text = $\${values.length}`);
    }
    if (typeof req.query.date === 'string' && req.query.date) {
      values.push(req.query.date);
      where.push(`checkin_time::date = $\${values.length}::date`);
    }
    const result = await query<AttendanceDbRow>(
      `\${attendanceSelect} WHERE \${where.join(' AND ')} ORDER BY checkin_time DESC LIMIT 5000`, values,
    );
    return res.json(result.rows.map(mapAttendanceRow));
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// Manual attendance entry.
router.post('/', requirePermission('attendance.create'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const input = req.body as Partial<AttendanceRecord>;
    const branchId = input.branchId || user.branchId;
    const branch = attendanceBranchFilter(user, branchId);
    if (!branch) throw new Error('A valid branch UUID is required.');
    if (typeof input.memberId !== 'string' || !isDatabaseUuid(input.memberId)) {
      return res.status(400).json({ error: 'A valid member UUID is required.' });
    }
    const memberResult = await query<{ id: string; first_name: string; last_name: string }>(
      `SELECT id,first_name,last_name FROM public.members
       WHERE id=$1::uuid AND tenant_id=$2::uuid AND branch_id=$3::uuid`,
      [input.memberId, user.tenantId, branchId],
    );
    const member = memberResult.rows[0];
    if (!member) return res.status(404).json({ error: 'Member not found in the selected tenant and branch.' });
    const checkedAt = input.checkInTime && !Number.isNaN(Date.parse(input.checkInTime))
      ? new Date(input.checkInTime) : new Date();
    const result = await query<AttendanceDbRow>(
      `INSERT INTO public.attendance_records
       (tenant_id,branch_id,event_name,service_type,member_id,checkin_method,checkin_time,
        member_name,status,absence_reason,notes,service_session,event_id)
       VALUES($1::uuid,$2::uuid,$3,$4,$5::uuid,$6,$7,$8,$9,$10,$11,$12,$13::uuid)
       RETURNING id,tenant_id,branch_id,event_name,service_type,member_id,visitor_name,visitor_phone,
        checkin_method,checkin_time,session_id,record_code,member_name,status,absence_reason,notes,service_session,event_id`,
      [user.tenantId, branchId, input.serviceName || input.eventName || 'Manual Attendance',
       input.serviceType || 'Ministry Attendance', member.id,
       input.checkInMethod || 'Manual Web Click', checkedAt.toISOString(),
       input.memberName || [member.first_name, member.last_name].filter(Boolean).join(' '),
       input.status || 'Present', input.absenceReason || null, input.notes || null,
       input.serviceSession || null, input.eventId || null],
    );
    const record = mapAttendanceRow(result.rows[0]);
    db.addAuditLog('Record Attendance', 'Attendance', `Recorded check-in for member \${member.id} at \${record.serviceName}`, user.name);
    return res.status(201).json(record);
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// QR code check-in. The member and branch are resolved within authenticated scope.
router.post('/check-in/qr', requirePermission('attendance.create'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const { qrPayload, branchId: requestedBranch, serviceName = 'Sunday Morning Service' } = req.body || {};
    if (typeof qrPayload !== 'string' || !qrPayload.trim()) {
      return res.status(400).json({ error: 'QR Code payload is required' });
    }
    let memberKey = qrPayload.trim();
    if (memberKey.startsWith('GC-MEMBER:')) memberKey = memberKey.slice('GC-MEMBER:'.length).trim();
    const branch = attendanceBranchFilter(user, requestedBranch || user.branchId);
    if (!branch) throw new Error('A valid branch UUID is required.');
    const branchParam = branch.value;
    const memberResult = await query<{ id: string; member_number: string; first_name: string; last_name: string; branch_id: string }>(
      `SELECT id,member_number,first_name,last_name,branch_id FROM public.members
       WHERE tenant_id=$1::uuid AND \${branch.sql.replace('$BRANCH', '$2')}
         AND (id::text=$3 OR member_number=$3 OR phone=$3) LIMIT 1`,
      [user.tenantId, branchParam, memberKey],
    );
    const member = memberResult.rows[0];
    if (!member) return res.status(404).json({ error: 'Member record matching QR code was not found.' });
    const checkedAt = new Date();
    const result = await query<AttendanceDbRow>(
      `INSERT INTO public.attendance_records
       (tenant_id,branch_id,event_name,service_type,member_id,checkin_method,checkin_time,member_name,status)
       VALUES($1::uuid,$2::uuid,$3,'Sunday Main Service',$4::uuid,'QR Code Scanning',$5,$6,'Present')
       RETURNING id,tenant_id,branch_id,event_name,service_type,member_id,visitor_name,visitor_phone,
        checkin_method,checkin_time,session_id,record_code,member_name,status,absence_reason,notes,service_session,event_id`,
      [user.tenantId, member.branch_id, serviceName, member.id, checkedAt.toISOString(), `\${member.first_name} \${member.last_name}`],
    );
    const record = mapAttendanceRow(result.rows[0]);
    db.addAuditLog('QR Check-In', 'Attendance & Security', `Fast QR Check-in for member \${member.member_number}`, user.name);
    return res.json({
      success: true, message: `Welcome, \${member.first_name} \${member.last_name}! Check-in verified.`,
      member: { id: member.id, name: `\${member.first_name} \${member.last_name}`, code: member.member_number },
      record,
    });
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// Bulk attendance import. Validate all members and write the batch atomically.
router.post('/bulk', requirePermission('attendance.create'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const records = req.body?.records;
    if (!Array.isArray(records)) return res.status(400).json({ error: 'Invalid records array' });
    if (records.length > 1000) return res.status(400).json({ error: 'A maximum of 1000 attendance records can be imported per request.' });
    const created = await withTransaction(async (client) => {
      const output: AttendanceRecord[] = [];
      for (const item of records as Partial<AttendanceRecord>[]) {
        const branchId = item.branchId || user.branchId;
        const branch = attendanceBranchFilter(user, branchId);
        if (!branch || typeof item.memberId !== 'string' || !isDatabaseUuid(item.memberId)) {
          throw new Error('Each attendance row requires an authorized branch and valid member UUID.');
        }
        const memberResult = await client.query<{ id: string; first_name: string; last_name: string }>(
          `SELECT id,first_name,last_name FROM public.members
           WHERE id=$1::uuid AND tenant_id=$2::uuid AND branch_id=$3::uuid`,
          [item.memberId, user.tenantId, branchId],
        );
        const member = memberResult.rows[0];
        if (!member) throw new Error('An imported member does not belong to the selected tenant and branch.');
        const checkedAt = item.checkInTime && !Number.isNaN(Date.parse(item.checkInTime))
          ? new Date(item.checkInTime) : new Date();
        const inserted = await client.query<AttendanceDbRow>(
          `INSERT INTO public.attendance_records
           (tenant_id,branch_id,event_name,service_type,member_id,checkin_method,checkin_time,
            member_name,status,absence_reason,notes,service_session,event_id)
           VALUES($1::uuid,$2::uuid,$3,$4,$5::uuid,$6,$7,$8,$9,$10,$11,$12,$13::uuid)
           RETURNING id,tenant_id,branch_id,event_name,service_type,member_id,visitor_name,visitor_phone,
            checkin_method,checkin_time,session_id,record_code,member_name,status,absence_reason,notes,service_session,event_id`,
          [user.tenantId, branchId, item.serviceName || item.eventName || 'Imported Attendance',
           item.serviceType || 'Ministry Attendance', member.id, item.checkInMethod || 'Excel Import',
           checkedAt.toISOString(), item.memberName || [member.first_name, member.last_name].join(' '),
           item.status || 'Present', item.absenceReason || null, item.notes || null,
           item.serviceSession || null, item.eventId || null],
        );
        output.push(mapAttendanceRow(inserted.rows[0]));
      }
      return output;
    });
    db.addAuditLog('Bulk Attendance Import', 'Attendance', `Bulk imported \${created.length} attendance records`, user.name);
    return res.status(201).json({ count: created.length, records: created });
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// Live counts are derived from the same PostgreSQL source as attendance records.
router.get('/live-counts', requirePermission('attendance.read'), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const targetDate = typeof req.query.date === 'string' ? req.query.date : new Date().toISOString().slice(0, 10);
    const values: unknown[] = [user.tenantId, targetDate];
    let branchSql = '';
    const branch = attendanceBranchFilter(user, req.query.branchId);
    if (branch) {
      values.push(branch.value);
      branchSql = ` AND \${branch.sql.replace('$BRANCH', String(values.length))}`;
    }
    const counts = await query<{ status: string; total: string }>(
      `SELECT status,COUNT(*)::text AS total FROM public.attendance_records
       WHERE tenant_id=$1::uuid AND checkin_time::date=$2::date\${branchSql} GROUP BY status`, values,
    );
    const sessionsValues: unknown[] = [user.tenantId];
    let sessionsBranchSql = '';
    const sessionsBranch = attendanceBranchFilter(user);
    if (sessionsBranch) {
      sessionsValues.push(sessionsBranch.value);
      sessionsBranchSql = ` AND \${sessionsBranch.sql.replace('$BRANCH', String(sessionsValues.length))}`;
    }
    const sessions = await query<{ total: string }>(
      `SELECT COUNT(*)::text AS total FROM public.attendance_sessions
       WHERE tenant_id=$1::uuid AND status='active'\${sessionsBranchSql}`, sessionsValues,
    );
    const byStatus = new Map(counts.rows.map(row => [row.status.toLowerCase(), Number(row.total)]));
    return res.json({
      date: targetDate,
      totalPresent: byStatus.get('present') || 0,
      totalAbsent: (byStatus.get('absent') || 0) + (byStatus.get('absent excused') || 0) + (byStatus.get('absent unexcused') || 0),
      totalRecords: counts.rows.reduce((sum, row) => sum + Number(row.total), 0),
      activeSessionsCount: Number(sessions.rows[0]?.total || 0),
    });
  } catch (error) {
    return sendAttendanceRepositoryError(res, error);
  }
});

// ==========================================
// EVENTS API - Enforce events.read and events.manage
// ==========================================
type EventDbRow={id:string;tenant_id:string;branch_id:string|null;title:string;event_type:string;start_date:string;end_date:string;location:string;description:string|null;speakers:string[]|null;capacity:number;registered_count:number;is_paid:boolean;ticket_price:string|number;status:string;event_data:Record<string,any>};
function mapEventRow(r:EventDbRow):EventItem {
 const d=r.event_data||{};
 return {...d,id:r.id,tenantId:r.tenant_id,branchId:r.branch_id||'',title:r.title,type:r.event_type as EventItem['type'],
  startDate:r.start_date,endDate:r.end_date,date:r.start_date,time:d.time||new Date(r.start_date).toISOString().slice(11,16),
  location:r.location,description:r.description||'',speakerNames:r.speakers||[],capacity:r.capacity,
  registeredCount:r.registered_count,isPaid:r.is_paid,ticketPrice:Number(r.ticket_price||0),status:r.status as EventItem['status']} as EventItem;
}
const eventSelect=`SELECT id,tenant_id,branch_id,title,event_type,start_date,end_date,location,description,speakers,capacity,
 registered_count,is_paid,ticket_price,status,event_data FROM public.events`;
router.get('/events/all',requirePermission('events.read'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  const all=user.branchIds.includes('*');
  const ids=[...new Set([...user.branchIds.filter(isDatabaseUuid),...(isDatabaseUuid(user.branchId)?[user.branchId]:[])])];
  const result=all
   ?await query<EventDbRow>(`${eventSelect} WHERE tenant_id=$1::uuid ORDER BY start_date DESC`,[user.tenantId])
   :await query<EventDbRow>(`${eventSelect} WHERE tenant_id=$1::uuid AND (branch_id IS NULL OR branch_id=ANY($2::uuid[])) ORDER BY start_date DESC`,[user.tenantId,ids]);
  return res.json(result.rows.map(mapEventRow));
 }catch(error){next(error);}
});
router.post('/events',requirePermission('events.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!,input=req.body as Partial<EventItem>;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  if(!input.title?.trim()||!input.startDate||!input.endDate||!input.location)return res.status(400).json({error:'Title, start date, end date and location are required.'});
  const branchId=isDatabaseUuid(input.branchId)?input.branchId:user.branchId;
  if(!isDatabaseUuid(branchId))return res.status(400).json({error:'A valid branch UUID is required.'});
  const branch=await query('SELECT id FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid',[branchId,user.tenantId]);
  if(!branch.rowCount)return res.status(400).json({error:'Selected branch does not belong to this tenant.'});
  const {id:_id,tenantId:_tenant,branchId:_branch,title:_title,type:_type,startDate:_start,endDate:_end,location:_location,description:_description,speakerNames:_speakers,capacity:_capacity,registeredCount:_count,isPaid:_paid,ticketPrice:_price,status:_status,...extra}=input as any;
  const result=await query<EventDbRow>(
   `INSERT INTO public.events(tenant_id,branch_id,title,event_type,start_date,end_date,location,description,speakers,capacity,registered_count,is_paid,ticket_price,status,event_data)
    VALUES($1::uuid,$2::uuid,$3,$4,$5::timestamptz,$6::timestamptz,$7,$8,$9,$10,$11,$12,$13,$14,$15::jsonb)
    RETURNING id,tenant_id,branch_id,title,event_type,start_date,end_date,location,description,speakers,capacity,registered_count,is_paid,ticket_price,status,event_data`,
   [user.tenantId,branchId,input.title.trim(),input.type||'Conference',input.startDate,input.endDate,input.location,input.description||null,input.speakerNames||[],input.capacity||0,input.registeredCount||0,Boolean(input.isPaid),input.ticketPrice||0,input.status||'Upcoming',JSON.stringify(extra)]);
  return res.status(201).json(mapEventRow(result.rows[0]));
 }catch(error){next(error);}
});
router.put('/events/:id',requirePermission('events.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and event UUIDs are required.'});
  const current=await query<EventDbRow>(`${eventSelect} WHERE id=$1::uuid AND tenant_id=$2::uuid`,[req.params.id,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Event not found'});
  const merged={...mapEventRow(current.rows[0]),...req.body,id:req.params.id,tenantId:user.tenantId} as EventItem;
  const branchId=isDatabaseUuid(merged.branchId)?merged.branchId:current.rows[0].branch_id;
  if(!isDatabaseUuid(branchId))return res.status(400).json({error:'A valid branch UUID is required.'});
  const branch=await query('SELECT id FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid',[branchId,user.tenantId]);
  if(!branch.rowCount)return res.status(400).json({error:'Selected branch does not belong to this tenant.'});
  const {id:_id,tenantId:_tenant,branchId:_branch,title:_title,type:_type,startDate:_start,endDate:_end,location:_location,description:_description,speakerNames:_speakers,capacity:_capacity,registeredCount:_count,isPaid:_paid,ticketPrice:_price,status:_status,...extra}=merged as any;
  const result=await query<EventDbRow>(
   `UPDATE public.events SET branch_id=$3::uuid,title=$4,event_type=$5,start_date=$6::timestamptz,end_date=$7::timestamptz,
    location=$8,description=$9,speakers=$10,capacity=$11,registered_count=$12,is_paid=$13,ticket_price=$14,status=$15,event_data=$16::jsonb
    WHERE id=$1::uuid AND tenant_id=$2::uuid
    RETURNING id,tenant_id,branch_id,title,event_type,start_date,end_date,location,description,speakers,capacity,registered_count,is_paid,ticket_price,status,event_data`,
   [req.params.id,user.tenantId,branchId,merged.title,merged.type,merged.startDate,merged.endDate,merged.location,merged.description||null,merged.speakerNames||[],merged.capacity||0,merged.registeredCount||0,Boolean(merged.isPaid),merged.ticketPrice||0,merged.status,JSON.stringify(extra)]);
  return res.json(mapEventRow(result.rows[0]));
 }catch(error){next(error);}
});
router.delete('/events/:id',requirePermission('events.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and event UUIDs are required.'});
  const result=await query(`UPDATE public.events SET status='Cancelled' WHERE id=$1::uuid AND tenant_id=$2::uuid RETURNING id`,[req.params.id,user.tenantId]);
  if(!result.rowCount)return res.status(404).json({error:'Event not found'});
  return res.json({success:true,deletedId:req.params.id,cancelled:true});
 }catch(error){next(error);}
});

export default router;
