import { Router, Request, Response } from 'express';
import multer from 'multer';
import { storageUploadHandlers } from './storageUpload';
import { db } from '../db';
import { SystemBrandingConfig } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  hasPermission,
  type Permission,
  AuthenticatedRequest,
  isSameTenant,
  isSameCampus,
} from '../../src/security/authorization';
import { sensitiveAdminLimiter } from '../middleware/rateLimiter';
import {
  createServerBackup,
  restoreServerBackup,
  resetServerDatabase,
  getSafeBackupFilePath,
  initBackupScheduler,
} from '../services/backupService';
import { query, testConnection } from '../pg';
import { listMembers, getMemberById, isDatabaseUuid } from '../repositories/memberRepository';
import { adminSupabase, isSupabaseConfigured } from '../../src/lib/supabase';
import { queueService } from '../../src/services/queueService';
import { securityAuditService } from '../services/securityAuditService';

const router = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
});

// Public branding read endpoint for app initialization (favicon, logo, church name)
router.get('/branding', (req: Request, res: Response) => {
  return res.json(db.getBranding());
});

// Detailed Database Health & Storage Stats (public health check)
router.get('/health', async (req: Request, res: Response) => {
  const state = db.getState();
  let counts = {
    membersCount: state.members.length,
    branchesCount: state.branches.length,
    familiesCount: state.families.length,
    ministriesCount: state.ministries.length,
    eventsCount: state.events.length,
    attendanceRecordsCount: state.attendanceRecords.length,
    auditLogsCount: state.auditLogs.length,
    documentsCount: state.documents.length,
    systemUsersCount: state.systemUsers.length,
  };
  let engine = 'Legacy JSON compatibility store';
  let databaseStatus = 'degraded';
  if (process.env.DATABASE_URL) {
    try {
      const result = await query<{members:number;branches:number;families:number;ministries:number;events:number;attendance:number;audit:number;documents:number;profiles:number}>(`
        SELECT
          (SELECT COUNT(*)::int FROM public.members) AS members,
          (SELECT COUNT(*)::int FROM public.branches) AS branches,
          (SELECT COUNT(*)::int FROM public.families) AS families,
          (SELECT COUNT(*)::int FROM public.ministries) AS ministries,
          (SELECT COUNT(*)::int FROM public.events) AS events,
          (SELECT COUNT(*)::int FROM public.attendance_records) AS attendance,
          (SELECT COUNT(*)::int FROM public.audit_logs) AS audit,
          (SELECT COUNT(*)::int FROM public.documents) AS documents,
          (SELECT COUNT(*)::int FROM public.profiles) AS profiles
      `);
      const row=result.rows[0];
      counts={
        membersCount:row.members,branchesCount:row.branches,familiesCount:row.families,
        ministriesCount:row.ministries,eventsCount:row.events,attendanceRecordsCount:row.attendance,
        auditLogsCount:row.audit,documentsCount:row.documents,systemUsersCount:row.profiles,
      };
      engine='PostgreSQL';
      databaseStatus='healthy';
    } catch (error) {
      databaseStatus='degraded';
      engine='PostgreSQL (connection/query failure)';
      console.error('[Health] PostgreSQL count query failed:',error instanceof Error?error.message:error);
    }
  } else {
    databaseStatus = 'degraded';
  }
  return res.json({
    status: databaseStatus,
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    database: { engine, ...counts },
    branding: db.getBranding(),
  });
});

// Live Database Health Check - honestly queries Postgres if configured, otherwise reports flat-file store
router.get('/db-health', async (req: Request, res: Response) => {
  if (!process.env.DATABASE_URL) {
    return res.json({
      configured: false,
      engine: 'Flat-file JSON Storage',
      ok: false,
      status: 'not applicable — flat-file store',
      message: 'not applicable — flat-file store (DATABASE_URL not configured in environment)',
      timestamp: new Date().toISOString(),
    });
  }

  try {
    const conn = await testConnection();
    if (conn.ok) {
      return res.json({
        configured: true,
        engine: 'PostgreSQL',
        ok: true,
        status: 'connected',
        latencyMs: conn.latencyMs,
        database: conn.database,
        message: conn.message,
        timestamp: new Date().toISOString(),
      });
    } else {
      return res.json({
        configured: true,
        engine: 'PostgreSQL',
        ok: false,
        status: 'connection_failed',
        message: conn.message,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (err: any) {
    return res.json({
      configured: true,
      engine: 'PostgreSQL',
      ok: false,
      status: 'error',
      message: err.message,
      timestamp: new Date().toISOString(),
    });
  }
});

// Retrieve all database data directly from the system database (Strictly SYSTEM_ADMIN)
router.get(
  '/all-data',
  authenticateToken,
  requirePermission('system.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'FORBIDDEN_ROLE',
        code: 'FORBIDDEN_ROLE',
        message: 'Forbidden: SYSTEM_ADMIN role is required to export full database records.',
      });
    }
    const rawState = db.getState();
    return res.json({
      success: true,
      branches: rawState.branches || [],
      members: rawState.members || [],
      families: rawState.families || [],
      ministries: rawState.ministries || [],
      attendanceRecords: rawState.attendanceRecords || [],
      attendanceSessions: rawState.attendanceSessions || [],
      events: rawState.events || [],
      communications: rawState.communications || [],
      communicationLogs: rawState.communicationLogs || [],
      prayerRequests: rawState.prayerRequests || [],
      counselingSessions: rawState.counselingSessions || [],
      visitations: rawState.visitations || [],
      volunteerShifts: rawState.volunteerShifts || [],
      assets: rawState.assets || [],
      documents: rawState.documents || [],
      documentCategories: rawState.documentCategories || [],
      courses: rawState.courses || [],
      workflows: rawState.workflows || [],
      profileChangeRequests: rawState.profileChangeRequests || [],
      auditLogs: rawState.auditLogs || [],
      systemUsers: (rawState.systemUsers || []).map(({ password, passwordHash, mfaSecret, totpSecret, ...u }: any) => u),
      branding: db.getBranding(),
    });
  }
);

// Remove any demo or autofill artifacts from the database (Strictly SYSTEM_ADMIN)
router.post(
  '/cleanup-demo',
  authenticateToken,
  requirePermission('system.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({
        success: false,
        error: 'FORBIDDEN_ROLE',
        code: 'FORBIDDEN_ROLE',
        message: 'Forbidden: SYSTEM_ADMIN role is required to purge demo records.',
      });
    }
    const state = db.getState();
    let removedCount = 0;

    // Filter out demo users
    const prevUsersCount = (state.systemUsers || []).length;
    state.systemUsers = (state.systemUsers || []).filter(
      (u: any) => !u.id?.includes('demo') && !u.email?.includes('demo') && !u.name?.toLowerCase().includes('demo')
    );
    removedCount += prevUsersCount - state.systemUsers.length;

    // Filter out demo workflows
    const prevWfCount = (state.workflows || []).length;
    state.workflows = (state.workflows || []).filter(
      (w: any) => !w.id?.includes('demo') && !w.requesterEmail?.includes('demo') && !w.requesterName?.toLowerCase().includes('demo')
    );
    removedCount += prevWfCount - state.workflows.length;

    // NOTE: Audit logs are append-only and never purged or modified by ordinary API operations.

    db.persist();
    db.addAuditLog(
      'Database Demo Cleanup',
      'System Database',
      `Purged ${removedCount} demo and autofill artifacts from database (audit trail preserved)`,
      req.user?.email || req.user?.name
    );

    return res.json({
      success: true,
      message: `Database cleaned: ${removedCount} demo records purged`,
      removedCount,
    });
  }
);

// ==============================================================================
// PROTECTED SYSTEM & INFRASTRUCTURE ROUTES (Requires Authentication & Permissions)
// ==============================================================================

// Redesigned state snapshot - Returns strictly partitioned data based on authenticated role and permissions
router.get('/state', authenticateToken, async (req: AuthenticatedRequest, res: Response, next) => {
  const user = req.user!;
  try {
  const rawState = db.getState();
  const permissions = user.permissions || [];
  const hasPerm = (p: string) => permissions.includes(p as any);

  const tenantId = user.tenantId;
  const isAllBranches = user.branchIds.includes('*');
  const isTenantAllowed = (t?: string) => !t || isSameTenant(t, tenantId);
  const isBranchAllowed = (branchId?: string) => {
    if (!branchId || isAllBranches) return true;
    return user.branchIds.some((b) => isSameCampus(b, branchId)) || isSameCampus(user.branchId, branchId);
  };
  if (!isDatabaseUuid(user.tenantId)) throw new Error('Authenticated profile has no valid tenant UUID.');

  // 1. Branches are read from PostgreSQL.
  const branchIds = [...new Set([...(user.branchIds || []).filter(isDatabaseUuid), ...(isDatabaseUuid(user.branchId) ? [user.branchId] : [])])];
  const branchRows = isAllBranches
    ? await query(`SELECT id,tenant_id,code,name,city,phone,status,branch_data FROM public.branches WHERE tenant_id=$1::uuid ORDER BY name`,[user.tenantId])
    : await query(`SELECT id,tenant_id,code,name,city,phone,status,branch_data FROM public.branches WHERE tenant_id=$1::uuid AND id=ANY($2::uuid[]) ORDER BY name`,[user.tenantId,branchIds]);
  const branches = branchRows.rows.map((b:any)=>({...((b.branch_data||{}) as object),id:b.id,tenantId:b.tenant_id,code:b.code,name:b.name,city:b.city||'',phone:b.phone||'',status:b.status}));

  // 2. Members are loaded from PostgreSQL, not the legacy JSON state.
  let members: any[] = [];
  if (hasPerm('members.read')) {
    if (!isDatabaseUuid(user.tenantId)) throw new Error('Authenticated profile has no valid tenant UUID.');
    const requestedBranch = typeof req.query.branchId === 'string' && req.query.branchId !== 'all' ? req.query.branchId : undefined;
    const scope = {
      tenantId: user.tenantId,
      branchIds: [...new Set([...(user.branchIds || []).filter(isDatabaseUuid), ...(isDatabaseUuid(user.branchId) ? [user.branchId] : [])])],
      branchId: requestedBranch,
      allBranches: user.branchIds.includes('*'),
    };
    members = (await listMembers(scope)).members;
  } else if (isDatabaseUuid(user.memberId)) {
    const own = await getMemberById(user.memberId, {
      tenantId: user.tenantId,
      branchIds: (user.branchIds || []).filter(isDatabaseUuid),
      branchId: isDatabaseUuid(user.branchId) ? user.branchId : undefined,
      allBranches: true,
    });
    if (own) members = [own];
  }

  // 3. Families are read from PostgreSQL.
  let families: any[] = [];
  if (!isDatabaseUuid(user.tenantId)) throw new Error('Authenticated profile has no valid tenant UUID.');
  if (user.role === 'REGULAR_MEMBER') {
    const userMember = members[0];
    if (userMember?.familyId && isDatabaseUuid(userMember.familyId)) {
      const f=await query(`SELECT id,tenant_id,branch_id,family_code,household_name,head_member_id,primary_phone,family_type,family_photo_url,primary_language,address,woreda,kebele,house_number,city,region,member_ids,relationships,registration_date,status FROM public.families WHERE id=$1::uuid AND tenant_id=$2::uuid`,[userMember.familyId,user.tenantId]);
      families=f.rows.map((r:any)=>({...r,id:r.id,tenantId:r.tenant_id,branchId:r.branch_id,familyCode:r.family_code,householdName:r.household_name,headOfHouseholdMemberId:r.head_member_id,primaryHouseholdPhone:r.primary_phone,familyType:r.family_type,familyPhotoUrl:r.family_photo_url,primaryLanguage:r.primary_language,registrationDate:r.registration_date,memberIds:r.member_ids||[],relationships:r.relationships||[]}));
    }
  } else if (hasPerm('families.read') || hasPerm('members.read')) {
    const f=await query(`SELECT id,tenant_id,branch_id,family_code,household_name,head_member_id,primary_phone,family_type,family_photo_url,primary_language,address,woreda,kebele,house_number,city,region,member_ids,relationships,registration_date,status FROM public.families WHERE tenant_id=$1::uuid AND (branch_id IS NULL OR $2::boolean OR branch_id=ANY($3::uuid[])) ORDER BY household_name`,[user.tenantId,isAllBranches,branchIds]);
    families=f.rows.map((r:any)=>({...r,id:r.id,tenantId:r.tenant_id,branchId:r.branch_id,familyCode:r.family_code,householdName:r.household_name,headOfHouseholdMemberId:r.head_member_id,primaryHouseholdPhone:r.primary_phone,familyType:r.family_type,familyPhotoUrl:r.family_photo_url,primaryLanguage:r.primary_language,registrationDate:r.registration_date,memberIds:r.member_ids||[],relationships:r.relationships||[]}));
  }

  // 4. Attendance Records
  let attendanceRecords: any[] = [];
  if (user.role === 'REGULAR_MEMBER') {
    attendanceRecords = (rawState.attendanceRecords || []).filter(
      (a) =>
        isTenantAllowed(a.tenantId) &&
        (a.memberId === user.id || a.memberId === user.memberId)
    );
  } else if (hasPerm('attendance.read')) {
    attendanceRecords = (rawState.attendanceRecords || []).filter(
      (a) => isTenantAllowed(a.tenantId) && isBranchAllowed(a.branchId)
    );
  }

  // 6. Pastoral Care (Highly confidential - counseling & visitations)
  let counselingSessions: any[] = [];
  let visitations: any[] = [];
  let prayerRequests: any[] = [];
  if (hasPerm('pastoral.read')) {
    counselingSessions = (rawState.counselingSessions || []).filter(
      (c) => isTenantAllowed(c.tenantId) && isBranchAllowed(c.branchId)
    );
    visitations = (rawState.visitations || []).filter(
      (v) => isTenantAllowed(v.tenantId) && isBranchAllowed(v.branchId)
    );
    prayerRequests = (rawState.prayerRequests || []).filter(
      (p) => isTenantAllowed(p.tenantId) && isBranchAllowed(p.branchId)
    );
  } else {
    // Non-pastoral callers only receive their own or publicly shared prayer requests
    prayerRequests = (rawState.prayerRequests || []).filter(
      (p) =>
        isTenantAllowed(p.tenantId) &&
        (!p.isConfidential || p.memberId === user.id || p.memberId === user.memberId)
    );
  }

  // 7. System Users (Strict user management boundary)
  let systemUsers: any[] = [];
  if (hasPerm('users.manage') || hasPerm('system.manage')) {
    systemUsers = (rawState.systemUsers || [])
      .filter((u: any) => isTenantAllowed(u.tenantId))
      .map((u: any) => {
        const { password, passwordHash, mfaSecret, totpSecret, ...safeUser } = u;
        return safeUser;
      });
  }

  // 8. Audit Logs (Compliance & governance boundary)
  let auditLogs: any[] = [];
  if (hasPerm('audit.read') || hasPerm('system.manage')) {
    auditLogs = rawState.auditLogs || [];
  }

  // 9. Workflows & Profile Change Requests
  let workflows: any[] = [];
  let profileChangeRequests: any[] = [];
  if (user.role === 'REGULAR_MEMBER') {
    workflows = (rawState.workflows || []).filter(
      (w) =>
        isTenantAllowed(w.tenantId) &&
        (w.requesterId === user.id || w.requesterId === user.memberId || w.requesterEmail?.toLowerCase() === user.email?.toLowerCase())
    );
    profileChangeRequests = (rawState.profileChangeRequests || []).filter(
      (r) =>
        r.memberId === user.id ||
        r.memberId === user.memberId ||
        (r.memberEmail && user.email && r.memberEmail.toLowerCase() === user.email.toLowerCase())
    );
  } else if (hasPerm('workflows.read') || hasPerm('members.read')) {
    const legacyWorkflows = (rawState.workflows || []).filter(
      (w) => w.requestType !== 'Membership Application' && isTenantAllowed(w.tenantId) && isBranchAllowed(w.branchId)
    );
    const workflowBranchIds = branchIds;
    const membershipRows = isAllBranches
      ? await query(`SELECT id,tenant_id,branch_id,request_code,request_type,requester_name,requester_phone,requester_email,branch_name,details,current_step,assigned_role,status,comments,approved_by,approved_at,rejected_reason,decision_notes,pending_member_data,created_at
          FROM public.workflow_requests WHERE tenant_id=$1::uuid AND request_type='Membership Application' ORDER BY created_at DESC`,[user.tenantId])
      : await query(`SELECT id,tenant_id,branch_id,request_code,request_type,requester_name,requester_phone,requester_email,branch_name,details,current_step,assigned_role,status,comments,approved_by,approved_at,rejected_reason,decision_notes,pending_member_data,created_at
          FROM public.workflow_requests WHERE tenant_id=$1::uuid AND request_type='Membership Application' AND (branch_id IS NULL OR branch_id=ANY($2::uuid[])) ORDER BY created_at DESC`,[user.tenantId,workflowBranchIds]);
    const membershipWorkflows = membershipRows.rows.map((w:any)=>({
      id:w.id,tenantId:w.tenant_id,branchId:w.branch_id,requestCode:w.request_code,requestType:'Membership Application',
      requesterName:w.requester_name,requesterPhone:w.requester_phone,requesterEmail:w.requester_email,
      branchName:w.branch_name||'',details:w.details,currentStep:w.current_step||'Submitted for Review',
      assignedApproverRole:w.assigned_role||'PASTOR',submittedDate:w.created_at?.toISOString?.().slice(0,10)||String(w.created_at||'').slice(0,10),
      status:w.status||'Pending',comments:w.comments,approvedBy:w.approved_by,approvedAt:w.approved_at,
      rejectedReason:w.rejected_reason,decisionNotes:w.decision_notes,
      pendingMemberData:(() => {
        const pending = w.pending_member_data || {};
        if (user.permissions?.includes('pastoral.read')) return pending;
        const { emergencyContact, bloodType, knownAllergies, medicalConditions, specialNeeds, notes, ...safePending } = pending;
        return safePending;
      })(),
    }));
    workflows = [...membershipWorkflows,...legacyWorkflows];
    profileChangeRequests = rawState.profileChangeRequests || [];
  }

  // 10. General Tenant-Scoped Resources
  const ministryRows=await query(`SELECT m.id,m.tenant_id,m.branch_id,m.name,m.category,m.leader_name,m.meeting_day,m.status,m.ministry_data,
    COALESCE(array_agg(mm.member_id) FILTER(WHERE mm.member_id IS NOT NULL),ARRAY[]::uuid[])::text[] AS member_ids,
    COUNT(mm.member_id)::int AS member_count
    FROM public.ministries m LEFT JOIN public.ministry_members mm ON mm.ministry_id=m.id
    WHERE m.tenant_id=$1::uuid AND ($2::boolean OR m.branch_id IS NULL OR m.branch_id=ANY($3::uuid[]))
    GROUP BY m.id ORDER BY m.name`,[user.tenantId,isAllBranches,branchIds]);
  const ministries=ministryRows.rows.map((m:any)=>({...((m.ministry_data||{}) as object),id:m.id,tenantId:m.tenant_id,branchId:m.branch_id,name:m.name,category:m.category,leaderName:m.leader_name,meetingSchedule:m.meeting_day,status:m.status,memberIds:m.member_ids||[],memberCount:Number(m.member_count||0)}));
  const eventRows=await query(`SELECT id,tenant_id,branch_id,title,event_type,start_date,end_date,location,description,speakers,capacity,registered_count,is_paid,ticket_price,status,event_data
    FROM public.events WHERE tenant_id=$1::uuid AND ($2::boolean OR branch_id IS NULL OR branch_id=ANY($3::uuid[])) ORDER BY start_date DESC`,[user.tenantId,isAllBranches,branchIds]);
  const events=eventRows.rows.map((e:any)=>({...((e.event_data||{}) as object),id:e.id,tenantId:e.tenant_id,branchId:e.branch_id,title:e.title,type:e.event_type,startDate:e.start_date,endDate:e.end_date,date:e.start_date,location:e.location,description:e.description||'',speakerNames:e.speakers||[],capacity:e.capacity,registeredCount:e.registered_count,isPaid:e.is_paid,ticketPrice:Number(e.ticket_price||0),status:e.status}));
  const volunteerShifts = (rawState.volunteerShifts || []).filter(
    (v) => isTenantAllowed(v.tenantId) && isBranchAllowed(v.branchId)
  );
  const assets = hasPerm('assets.read')
    ? (rawState.assets || []).filter((a) => isTenantAllowed(a.tenantId) && isBranchAllowed(a.branchId))
    : [];
  const documents = (rawState.documents || []).filter(
    (d) => isTenantAllowed(d.tenantId) && isBranchAllowed(d.branchId)
  );
  const courses = rawState.courses || [];
  const communications = hasPerm('communications.read')
    ? (rawState.communications || []).filter((c) => isTenantAllowed(c.tenantId))
    : [];
  const communicationLogs = hasPerm('communications.read')
    ? (rawState.communicationLogs || []).filter((l) => isTenantAllowed(l.tenant_id))
    : [];

  return res.json({
    tenantId,
    branding: rawState.branding,
    branches,
    members,
    families,
    ministries,
    attendanceRecords,
    attendanceSessions: rawState.attendanceSessions || [],
    events,
    communications,
    communicationLogs,
    prayerRequests,
    counselingSessions,
    visitations,
    volunteerShifts,
    assets,
    documents,
    courses,
    workflows,
    profileChangeRequests,
    auditLogs,
    systemUsers,
  });
  } catch (error) {
    next(error);
  }
});

// Update Branding & System Config - Strictly reserved for SYSTEM_ADMIN (system.manage)
router.put('/branding', authenticateToken, requirePermission('system.manage'), sensitiveAdminLimiter, (req: AuthenticatedRequest, res: Response) => {
  const updates: Partial<SystemBrandingConfig> = req.body;
  if (!updates || Object.keys(updates).length === 0) {
    return res.status(400).json({ error: 'No branding parameters provided' });
  }

  const updatedBranding = db.updateBranding(updates);
  db.addAuditLog('Update Branding', 'System Settings', 'Updated system branding and appearance settings', req.user?.name);
  return res.json({
    success: true,
    message: 'System branding and favicon settings updated successfully',
    branding: updatedBranding,
  });
});

// PostgreSQL Schema DDL Generator - Strictly reserved for SYSTEM_ADMIN (system.manage)
router.get('/schema-sql', authenticateToken, requirePermission('system.manage'), (req: AuthenticatedRequest, res: Response) => {
  const ddl = db.generatePostgresDDL();
  const download = req.query.download === 'true';

  if (download) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=cmms_postgresql_schema_${Date.now()}.sql`);
    return res.send(ddl);
  }

  return res.json({
    engine: 'PostgreSQL 15 / 16 (Compatible with Supabase, Neon, AWS RDS, Azure)',
    generatedAt: new Date().toISOString(),
    sql: ddl,
    tables: [
      { name: 'branches', records: db.getState().branches.length, description: 'Multi-campus branches & regional chapels' },
      { name: 'families', records: db.getState().families.length, description: 'Households and family mapping' },
      { name: 'members', records: db.getState().members.length, description: 'Member directory with spiritual milestones' },
      { name: 'ministries', records: db.getState().ministries.length, description: 'Departments, fellowships & volunteer groups' },
      { name: 'attendance_records', records: db.getState().attendanceRecords.length, description: 'QR & manual check-in sessions' },
      { name: 'system_users', records: db.getState().systemUsers.length, description: 'RBAC users, credentials & MFA' },
      { name: 'audit_logs', records: db.getState().auditLogs.length, description: 'Immutable system audit trails' },
    ],
  });
});

// Security Governance Settings (JWT lifespan, lockout policy, MFA enforcement) - Restricted to SYSTEM_ADMIN
router.get(
  '/security-governance',
  authenticateToken,
  requirePermission('system.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    return res.json({
      success: true,
      settings: db.getSecurityConfig(),
    });
  }
);

router.put(
  '/security-governance',
  authenticateToken,
  requirePermission('system.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({ error: 'Forbidden: SYSTEM_ADMIN role required.' });
    }

    const { jwtLifespanHours, lockoutMaxAttempts, lockoutDurationMinutes, mfaEnforcementMode } = req.body;

    const updates: any = {};
    if (typeof jwtLifespanHours === 'number' && jwtLifespanHours > 0) {
      updates.jwtLifespanHours = Math.min(720, Math.max(1, jwtLifespanHours));
    }
    if (typeof lockoutMaxAttempts === 'number' && lockoutMaxAttempts > 0) {
      updates.lockoutMaxAttempts = Math.min(50, Math.max(1, lockoutMaxAttempts));
    }
    if (typeof lockoutDurationMinutes === 'number' && lockoutDurationMinutes > 0) {
      updates.lockoutDurationMinutes = Math.min(1440, Math.max(1, lockoutDurationMinutes));
    }
    if (mfaEnforcementMode === 'enforced' || mfaEnforcementMode === 'optional') {
      updates.mfaEnforcementMode = mfaEnforcementMode;
    }

    const updated = db.updateSecurityConfig(updates);

    securityAuditService.recordEvent({
      req,
      eventType: 'SECURITY_CONFIG_CHANGED',
      action: 'Updated Security Governance Policy',
      module: 'Security Configuration',
      actorId: req.user?.id,
      actorEmail: req.user?.email,
      actorName: req.user?.name,
      actorRole: req.user?.role,
      outcome: 'SUCCESS',
      severity: 'HIGH',
      details: `Administrator ${req.user?.name} (${req.user?.email}) updated security governance configuration: JWT Lifespan=${updated.jwtLifespanHours}h, Max Lockout Attempts=${updated.lockoutMaxAttempts}, Lockout Duration=${updated.lockoutDurationMinutes}m, MFA Mode=${updated.mfaEnforcementMode}`,
      metadata: updates,
    });

    return res.json({
      success: true,
      message: 'Security governance policy updated successfully.',
      settings: updated,
    });
  }
);

// ==============================================================================
// SERVER-SIDE BACKUP, RESTORE, RESET & SCHEDULER (SYSTEM_ADMIN ONLY)
// ==============================================================================

// 1. Create Server-Side Backup (POST /api/system/backup)
router.post(
  '/backup',
  authenticateToken,
  requirePermission('backup.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({
        error: 'Forbidden: SYSTEM_ADMIN role is required to perform database backups.',
        code: 'FORBIDDEN_ROLE',
      });
    }

    const backupType = req.body?.type || 'Full System';
    const triggeredBy = req.user.email || req.user.name || 'System Admin';

    try {
      const backupResult = createServerBackup({
        type: backupType,
        triggeredBy,
      });

      // Stream file as download attachment
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${backupResult.filename}"`);
      return res.json(backupResult.payload);
    } catch (err: any) {
      console.error('[System Route] Backup creation error:', err);
      if (err?.code === 'BACKUP_STORAGE_UNAVAILABLE') {
        return res.status(503).json({ error: err.message, code: 'BACKUP_STORAGE_UNAVAILABLE' });
      }
      return res.status(500).json({ error: `Backup failed: ${err.message}` });
    }
  }
);

// Compatibility GET for browser navigation
router.get(
  '/backup',
  authenticateToken,
  requirePermission('backup.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({
        error: 'Forbidden: SYSTEM_ADMIN role is required to perform database backups.',
        code: 'FORBIDDEN_ROLE',
      });
    }

    try {
      const backupResult = createServerBackup({
        type: 'Full System',
        triggeredBy: req.user.email || req.user.name || 'System Admin',
      });
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${backupResult.filename}"`);
      return res.json(backupResult.payload);
    } catch (err: any) {
      if (err?.code === 'BACKUP_STORAGE_UNAVAILABLE') {
        return res.status(503).json({ error: err.message, code: 'BACKUP_STORAGE_UNAVAILABLE' });
      }
      return res.status(500).json({ error: 'Backup creation failed.', code: 'BACKUP_FAILED' });
    }
  }
);

// 2. Restore Database from Backup (POST /api/system/restore)
router.post(
  '/restore',
  authenticateToken,
  requirePermission('backup.manage'),
  sensitiveAdminLimiter,
  upload.single('file'),
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({
        error: 'Forbidden: SYSTEM_ADMIN role is required to perform database restores.',
        code: 'FORBIDDEN_ROLE',
      });
    }

    // Extract payload either from multipart upload or JSON body
    let rawContent: any;
    if (req.file) {
      try {
        rawContent = req.file.buffer.toString('utf-8');
      } catch (e: any) {
        return res.status(400).json({ error: 'Failed to read uploaded backup file.' });
      }
    } else if (req.body?.content) {
      rawContent = req.body.content;
    } else if (req.body?.data) {
      rawContent = req.body.data;
    } else {
      rawContent = req.body;
    }

    const isConfirmed =
      req.query.confirm === 'true' ||
      req.body?.confirm === true ||
      req.body?.confirm === 'true';

    const triggeredBy = req.user.email || req.user.name || 'System Admin';

    const result = restoreServerBackup({
      content: rawContent,
      confirmed: isConfirmed,
      triggeredBy,
    });

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.json(result);
  }
);

// 3. Factory Reset Database (POST /api/system/reset)
router.post(
  '/reset',
  authenticateToken,
  requirePermission('system.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({
        error: 'Forbidden: SYSTEM_ADMIN role is required to reset system data.',
        code: 'FORBIDDEN_ROLE',
      });
    }

    const isConfirmed =
      req.query.confirm === 'true' ||
      req.body?.confirm === true ||
      req.body?.confirm === 'true';

    const triggeredBy = req.user.email || req.user.name || 'System Admin';

    const result = resetServerDatabase({
      confirmed: isConfirmed,
      triggeredBy,
    });

    if (result.requiresConfirmation) {
      return res.status(200).json(result);
    }

    return res.json(result);
  }
);

// 4. Retrieve Backup History Logs (GET /api/system/backup/history)
router.get(
  '/backup/history',
  authenticateToken,
  requirePermission('backup.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({ error: 'Forbidden: SYSTEM_ADMIN role required.' });
    }
    return res.json({
      success: true,
      history: db.getBackupLogs(),
    });
  }
);

// 5. Retrieve Automated Backup Schedule (GET /api/system/backup/schedule)
router.get(
  '/backup/schedule',
  authenticateToken,
  requirePermission('backup.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({ error: 'Forbidden: SYSTEM_ADMIN role required.' });
    }
    return res.json({
      success: true,
      schedule: db.getBackupConfig(),
    });
  }
);

// 6. Update Automated Backup Schedule (PUT /api/system/backup/schedule)
router.put(
  '/backup/schedule',
  authenticateToken,
  requirePermission('backup.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({ error: 'Forbidden: SYSTEM_ADMIN role required.' });
    }

    const { enabled, frequency, time, destination } = req.body;

    // Validate that only implemented destination ('Local Storage') is accepted
    if (destination && destination !== 'Local Storage') {
      return res.status(400).json({
        error: `Storage destination "${destination}" is not supported. Only "Local Storage" (Server Local Disk) is currently available.`,
      });
    }

    const updated = db.updateBackupConfig({
      ...(typeof enabled === 'boolean' ? { enabled } : {}),
      ...(frequency ? { frequency } : {}),
      ...(time ? { time } : {}),
      destination: 'Local Storage',
    });

    // Re-initialize scheduled cron job
    initBackupScheduler();

    db.addAuditLog(
      'Update Backup Schedule',
      'Backup & Disaster Recovery',
      `Updated automated backup policy: ${updated.enabled ? 'Enabled' : 'Disabled'}, ${updated.frequency} at ${updated.time}`,
      req.user.email || req.user.name
    );

    return res.json({
      success: true,
      message: 'Automated backup schedule configuration updated successfully.',
      schedule: updated,
    });
  }
);

// 7. Download Archived Backup Snapshot (GET /api/system/backup/download/:filename)
router.get(
  '/backup/download/:filename',
  authenticateToken,
  requirePermission('backup.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    if (req.user?.role !== 'SYSTEM_ADMIN') {
      return res.status(403).json({ error: 'Forbidden: SYSTEM_ADMIN role required.' });
    }

    const filePath = getSafeBackupFilePath(req.params.filename);
    if (!filePath) {
      return res.status(404).json({ error: 'Backup file not found or invalid filename.' });
    }

    return res.download(filePath);
  }
);

// ==============================================================================
// SUPABASE STORAGE UPLOAD ENDPOINT (hardened: permission, bucket allowlist, content sniffing)
// ==============================================================================
router.post(
  '/storage/upload',
  authenticateToken,
  sensitiveAdminLimiter,
  ...storageUploadHandlers({
    adminSupabase: isSupabaseConfigured ? (adminSupabase as any) : null,
    publicBuckets: (process.env.CMMS_PUBLIC_STORAGE_BUCKETS || '').split(',').map((b) => b.trim()).filter(Boolean),
    // Permission per bucket; chat attachments are open to any authenticated user.
    authorize: (user, bucket) => {
      const required: Record<string, Permission | null> = {
        'documents-vault': 'documents.manage',
        'member-photos': 'members.update',
        'church-branding': 'system.manage',
        'chat-attachments': null,
      };
      const permission = required[bucket];
      return permission === null ? true : permission !== undefined && hasPermission(user as any, permission);
    },
    audit: ({ action, module, details, userId, tenantId }) =>
      db.addAuditLog(action, module, `${details} tenant=${tenantId}`, userId),
  })
);

// ==============================================================================
// BACKGROUND TASK QUEUE ENDPOINTS
// ==============================================================================
router.get('/queue/stats', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  if (req.user?.role !== 'SYSTEM_ADMIN') {
    return res.status(403).json({ error: 'SYSTEM_ADMIN role required.', code: 'FORBIDDEN_ROLE' });
  }
  return res.json(queueService.getStats());
});

router.post('/queue/jobs', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  if (req.user?.role !== 'SYSTEM_ADMIN') {
    return res.status(403).json({ error: 'SYSTEM_ADMIN role required.', code: 'FORBIDDEN_ROLE' });
  }

  const { name, data } = req.body || {};
  const allowedJobNames = ['bulk_sms', 'bulk_email', 'nightly_rollup', 'pastoral_followup', 'data_backup'] as const;
  if (typeof name !== 'string' || !allowedJobNames.includes(name as typeof allowedJobNames[number])) {
    return res.status(400).json({ error: 'Unsupported background task name.', code: 'INVALID_JOB_NAME' });
  }
  if (data !== undefined && (data === null || typeof data !== 'object' || Array.isArray(data))) {
    return res.status(400).json({ error: 'Job data must be a JSON object.', code: 'INVALID_JOB_DATA' });
  }
  if (data !== undefined && Buffer.byteLength(JSON.stringify(data), 'utf8') > 16 * 1024) {
    return res.status(413).json({ error: 'Job data exceeds the 16 KB limit.', code: 'JOB_DATA_TOO_LARGE' });
  }

  try {
    const job = await queueService.addJob(name as typeof allowedJobNames[number], data);
    return res.status(202).json({
      success: true,
      message: `Background task '${name}' enqueued successfully`,
      job,
    });
  } catch (error) {
    if ((error as any)?.code === 'QUEUE_BACKEND_UNAVAILABLE') {
      return res.status(503).json({
        error: 'Durable background processing is not configured. No task was accepted.',
        code: 'QUEUE_BACKEND_UNAVAILABLE',
      });
    }
    return res.status(500).json({ error: 'Unable to enqueue background task.', code: 'QUEUE_ENQUEUE_FAILED' });
  }
});

export default router;
