import { Router, Response } from 'express';
import { socketService } from '../../src/services/socketService';
import { VideoConference } from '../../src/types';
import {
  authenticateToken,
  AuthenticatedRequest,
} from '../../src/security/authorization';

const router = Router();

// Enforce authentication across all video conference endpoints
router.use(authenticateToken);

// In-memory collection for video conferences (backed by server runtime)
const videoConferences: Map<string, VideoConference> = new Map();

// Seed initial active conference for demonstration
const initialConference: VideoConference = {
  id: 'conf-worship-lead-001',
  groupId: 'min-1',
  leaderId: 'usr-leader-worship',
  title: 'Worship Team Vocal & Rehearsal Prep',
  roomUrl: `https://meet.jit.si/CMMS-Group-min-1-WorshipTeam`,
  status: 'active',
  createdAt: new Date().toISOString(),
};
videoConferences.set(initialConference.id, initialConference);

/**
 * POST /api/video-conferences
 * Group Leader creates a dynamic WebRTC video conference link
 */
router.post('/', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { groupId, title, roomUrl } = req.body;

  if (!groupId) {
    return res.status(400).json({ error: 'groupId is required' });
  }

  const generatedUrl = roomUrl || `https://meet.jit.si/CMMS-Group-${groupId}-${Date.now()}`;
  const conferenceId = `conf-${groupId}-${Date.now()}`;

  // End existing active calls for this group first to ensure clean state
  for (const [id, call] of videoConferences.entries()) {
    if (call.groupId === groupId && call.status === 'active') {
      call.status = 'ended';
      videoConferences.set(id, call);
    }
  }

  const newConference: VideoConference = {
    id: conferenceId,
    groupId,
    leaderId: user.id,
    title: title || 'Group Live Video Conference',
    roomUrl: generatedUrl,
    status: 'active',
    createdAt: new Date().toISOString(),
  };

  videoConferences.set(newConference.id, newConference);

  // Broadcast WebRTC video room alert to all members of this group in real-time
  const io = socketService.getIO();
  if (io) {
    io.to(`group_${groupId}`).emit('video_conference_started', newConference);
  }

  return res.status(201).json({
    success: true,
    conference: newConference,
  });
});

/**
 * GET /api/video-conferences/active
 * Member portal queries or polls for active video conference in their assigned group
 */
router.get('/active', (req: AuthenticatedRequest, res: Response) => {
  const { groupId } = req.query;

  const allActive = Array.from(videoConferences.values()).filter(
    (conf) => conf.status === 'active' && (!groupId || conf.groupId === groupId)
  );

  const activeCall = allActive.length > 0 ? allActive[allActive.length - 1] : null;

  return res.json({
    success: true,
    activeCall,
    activeCalls: allActive,
  });
});

/**
 * GET /api/video-conferences
 * List all video conferences
 */
router.get('/', (req: AuthenticatedRequest, res: Response) => {
  const { groupId } = req.query;
  let list = Array.from(videoConferences.values());
  if (groupId) {
    list = list.filter((c) => c.groupId === groupId);
  }
  return res.json({
    success: true,
    conferences: list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
  });
});

/**
 * POST /api/video-conferences/:id/end
 * End an active video conference
 */
router.post('/:id/end', (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const conf = videoConferences.get(id);

  if (!conf) {
    return res.status(404).json({ error: 'Video conference not found' });
  }

  const isLeader = conf.leaderId === user.id;
  const isPrivileged = ['SYSTEM_ADMIN', 'PASTOR', 'BRANCHADMIN'].includes(user.role);
  if (!isLeader && !isPrivileged) {
    return res.status(403).json({ error: 'Unauthorized to end this video conference' });
  }

  conf.status = 'ended';
  videoConferences.set(id, conf);

  const io = socketService.getIO();
  if (io) {
    io.to(`group_${conf.groupId}`).emit('video_conference_ended', {
      id: conf.id,
      groupId: conf.groupId,
    });
  }

  return res.json({
    success: true,
    message: 'Video conference ended',
    conference: conf,
  });
});

export default router;
