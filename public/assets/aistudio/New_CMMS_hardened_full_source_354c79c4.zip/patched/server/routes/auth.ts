import { Router, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { db } from '../db';
import { SystemUser, UserRole } from '../../src/types';
import { createClient } from '@supabase/supabase-js';
import {
  supabase,
  getAdminClient,
  createIsolatedAuthClient,
  isSupabaseConfigured,
  supabaseUrl,
  supabaseAnonKey,
  rawKey,
} from '../../src/lib/supabase';
import { JWT_SECRET } from '../../src/security/jwtConfig';
import { normalizeUserRole } from '../../src/utils/rbac';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
  verifyResourceAccess,
  resolveTrustedUserSession,
  buildAuthoritativeSessionFromAuthUser,
  AuthError,
  sendAuthError,
  revokeSessionToken,
  revokeAllUserSessions,
  normalizeAccountStatus,
  isSameCampus,
  DEFAULT_TENANT_UUID,
  DEFAULT_HQ_BRANCH_UUID,
  computeEffectivePermissions,
  validateRoleMutationSecurity,
  ROLES_CATALOG,
  ROLE_PERMISSIONS,
  resolveUserRolesList,
} from '../../src/security/authorization';
import {
  loginLimiter,
  passwordResetRequestLimiter,
  passwordResetVerifyLimiter,
  mfaVerifyLimiter,
  publicRegistrationLimiter,
  sensitiveAdminLimiter,
} from '../middleware/rateLimiter';
import {
  setAuthSessionCookies,
  clearAuthSessionCookies,
  extractAccessTokenFromRequest,
  extractRefreshTokenFromRequest,
} from '../utils/cookieSecurity';
import { securityAuditService } from '../services/securityAuditService';
import { query } from '../pg';
import { createMemberRecord, updateMemberRecord, isDatabaseUuid } from '../repositories/memberRepository';
import {
  createMembershipApplication,
  listMembershipApplications,
  getMembershipApplication,
  approveMembershipApplication,
  findMembershipApplication,
  saveMembershipDecision,
} from '../repositories/membershipWorkflowRepository';

function sanitizeMembershipWorkflowForUser<T extends { pendingMemberData?: any }>(workflow: T, user: AuthenticatedRequest['user']): T {
  if (user?.permissions?.includes('pastoral.read')) return workflow;
  const pending = workflow.pendingMemberData;
  if (!pending) return workflow;
  const {
    emergencyContact, bloodType, knownAllergies, medicalConditions, specialNeeds, notes,
    ...safePendingMemberData
  } = pending;
  return { ...workflow, pendingMemberData: safePendingMemberData };
}

const router = Router();

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isValidUUID(value?: string | null): boolean {
  return Boolean(value && UUID_REGEX.test(value.trim()));
}

function getDefaultRouteForRole(role?: UserRole | string): string {
  if (!role) return 'devotions';
  const norm = normalizeUserRole(role);
  switch (norm) {
    case 'SYSTEM_ADMIN':
    case 'MANAGER':
      return 'dashboard';
    case 'PASTOR':
      return 'prayer-counseling';
    case 'MINISTRY_LEADER':
      return 'attendance';
    case 'REGULAR_MEMBER':
    default:
      return 'devotions';
  }
}

// In-memory store for pending MFA login challenges (holds the real Supabase session while awaiting TOTP)
interface PendingStaffMfaLoginChallenge {
  challengeId: string;
  userId: string;
  email: string;
  supabaseAccessToken: string;
  supabaseRefreshToken: string;
  supabaseSession: any;
  factorId?: string;
  enrollmentSecret?: string;
  enrollmentUri?: string;
  expiresAt: number;
}
const pendingStaffMfaChallenges = new Map<string, PendingStaffMfaLoginChallenge>();

// In-memory store for pending staff MFA enrollment attempts (tied strictly to session/challenge)
interface PendingStaffMfaEnrollment {
  userId: string;
  email: string;
  secret: string;
  uri: string;
  factorId?: string;
  challengeId: string;
  expiresAt: number;
}
const pendingStaffMfaEnrollments = new Map<string, PendingStaffMfaEnrollment>();

// Helper to sanitize phone for matching
function cleanPhone(num?: string): string {
  if (!num) return '';
  return num.replace(/[^0-9]/g, '');
}

// ==============================================================================
// 0A. REFRESH ACCESS TOKEN (Authoritative Supabase Auth session refresh + reuse detection)
// ==============================================================================
router.post('/refresh', async (req: Request, res: Response) => {
  const refreshToken = extractRefreshTokenFromRequest(req);
  const extractedAccess = extractAccessTokenFromRequest(req);

  if ((!refreshToken || !String(refreshToken).trim()) && !extractedAccess.token) {
    return sendAuthError(res, 400, 'NO_REFRESH_TOKEN', 'Refresh token is required to renew your session.');
  }

  const cleanRefreshToken = refreshToken ? String(refreshToken).trim() : '';

  if (cleanRefreshToken) {
    // Check if this refresh token was already rotated/consumed (Refresh-Token Reuse Detection)
    const reuseCheck = securityAuditService.verifyAndRotateRefreshToken({
      oldRefreshToken: cleanRefreshToken,
      req,
    });
    if (reuseCheck.reuseDetected) {
      if (reuseCheck.compromisedUserId) {
        revokeAllUserSessions(reuseCheck.compromisedUserId);
      }
      clearAuthSessionCookies(res);
      return sendAuthError(
        res,
        401,
        'REFRESH_TOKEN_REUSE_DETECTED',
        'Security alert: Refresh token reuse detected. All sessions for this account have been revoked.'
      );
    }
  }

  try {
    if (cleanRefreshToken) {
      const authClient = createIsolatedAuthClient();
      const { data, error } = await authClient.auth.refreshSession({
        refresh_token: cleanRefreshToken,
      });

      if (!error && data?.session && data?.user) {
        let decodedJwt: any = null;
        try {
          decodedJwt = jwt.decode(data.session.access_token);
        } catch {}

        const authoritativeUser = await buildAuthoritativeSessionFromAuthUser(data.user, {
          decodedJwt,
          enforceActiveStatus: true,
        });

        // Record consumed old refresh token and register new active session
        securityAuditService.verifyAndRotateRefreshToken({
          oldRefreshToken: cleanRefreshToken,
          newAccessToken: data.session.access_token,
          newRefreshToken: data.session.refresh_token,
          userId: authoritativeUser.id,
          userEmail: authoritativeUser.email,
          req,
        });

        securityAuditService.registerSession({
          rawAccessToken: data.session.access_token,
          rawRefreshToken: data.session.refresh_token,
          userId: authoritativeUser.id,
          userEmail: authoritativeUser.email,
          userName: authoritativeUser.name,
          userRole: authoritativeUser.role,
          tenantId: authoritativeUser.tenantId,
          branchId: authoritativeUser.branchId,
          req,
          expiresInSeconds: data.session.expires_in,
          aal: authoritativeUser.aal,
          mfaVerified: authoritativeUser.aal === 'aal2',
        });

        setAuthSessionCookies(res, {
          accessToken: data.session.access_token,
          refreshToken: data.session.refresh_token,
          expiresInSeconds: data.session.expires_in,
        });

        return res.status(200).json({
          success: true,
          token: data.session.access_token,
          refreshToken: data.session.refresh_token,
          session: {
            access_token: data.session.access_token,
            refresh_token: data.session.refresh_token,
            expires_in: data.session.expires_in,
            expires_at: data.session.expires_at,
            token_type: 'bearer',
          },
          user: authoritativeUser,
          profile: authoritativeUser,
        });
      }
    }

    // Fallback: If refresh token was not available or already rotated by a concurrent tab/request,
    // check if the request carries a valid access token (via Authorization header or HttpOnly cookie)
    if (extractedAccess.token) {
      const resolvedUser = await resolveTrustedUserSession(extractedAccess.token);
      return res.status(200).json({
        success: true,
        token: extractedAccess.token,
        refreshToken: cleanRefreshToken || undefined,
        user: resolvedUser,
        profile: resolvedUser,
      });
    }

    clearAuthSessionCookies(res);
    securityAuditService.recordEvent({
      req,
      eventType: 'TOKEN_INVALID_OR_EXPIRED',
      action: 'Refresh Token Rejected',
      module: 'Authentication & Session Security',
      details: 'Session refresh failed: Refresh token invalid or expired',
      outcome: 'FAILURE',
      severity: 'MEDIUM',
    });
    return sendAuthError(
      res,
      401,
      'REFRESH_TOKEN_EXPIRED',
      'Your session has expired. Please sign in again.'
    );
  } catch (err: any) {
    if (err instanceof AuthError) {
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    return sendAuthError(res, 401, 'REFRESH_ERROR', err?.message || 'Session refresh failed. Please sign in again.');
  }
});

// ==============================================================================
// 0B. CURRENT USER SESSION RESTORATION (GET /api/auth/me)
// Authoritative chain: Supabase Auth -> auth.users -> profiles -> role -> tenant -> branch -> permissions -> session
// ==============================================================================
router.get('/me', async (req: Request, res: Response) => {
  const extracted = extractAccessTokenFromRequest(req);
  if (!extracted.token) {
    if (req.headers.authorization) {
      return sendAuthError(
        res,
        401,
        'INVALID_TOKEN',
        'Invalid Authorization header format. Format must be "Bearer <token>".'
      );
    }
    return sendAuthError(res, 401, 'NO_TOKEN', 'Authorization token is required.');
  }

  const token = extracted.token;

  try {
    const resolvedUser = await resolveTrustedUserSession(token);

    securityAuditService.touchSessionByToken(
      token,
      {
        id: resolvedUser.id,
        email: resolvedUser.email,
        name: resolvedUser.name,
        role: resolvedUser.role,
        tenantId: resolvedUser.tenantId,
        branchId: resolvedUser.branchId,
        aal: resolvedUser.aal,
        mfa_enabled: resolvedUser.mfa_enabled,
      },
      req
    );

    return res.status(200).json({
      success: true,
      user: resolvedUser,
      profile: resolvedUser,
    });
  } catch (err: any) {
    if (err instanceof AuthError) {
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    return sendAuthError(res, 401, 'INVALID_TOKEN', err?.message || 'Session invalid or expired. Please sign in again.');
  }
});

// ==============================================================================
// 0C. LOGOUT ENDPOINT (POST /api/auth/logout & POST /api/auth/staff/logout)
// Immediately revokes Bearer session token, clears HttpOnly cookies, and invalidates Supabase session
// ==============================================================================
async function handleLogout(req: Request, res: Response) {
  const extracted = extractAccessTokenFromRequest(req);
  const bodyToken = req.body?.token || req.body?.accessToken;
  const rawToken =
    extracted.token ||
    (typeof bodyToken === 'string' ? bodyToken.trim() : '');

  if (rawToken) {
    revokeSessionToken(rawToken);
    securityAuditService.recordEvent({
      req,
      eventType: 'AUTH_LOGOUT',
      action: 'User Signed Out & Session Revoked',
      module: 'Authentication & Session Security',
      details: 'User explicitly signed out; access token hash added to server revocation registry and HttpOnly cookies cleared.',
      outcome: 'SUCCESS',
      severity: 'LOW',
      sessionId: rawToken,
    });
    try {
      const admin = getAdminClient();
      if (typeof (admin.auth.admin as any)?.signOut === 'function') {
        await (admin.auth.admin as any).signOut(rawToken, 'global').catch(() => {});
      }
    } catch {
      // Non-fatal if token already expired on Supabase
    }
  }

  clearAuthSessionCookies(res);

  return res.status(200).json({
    success: true,
    message: 'Successfully signed out and invalidated session.',
  });
}

router.post('/logout', handleLogout);
router.post('/staff/logout', handleLogout);


// ==============================================================================
// 1. STAFF PORTAL LOCKOUT MANAGEMENT & TOTP HELPERS
// ==============================================================================
export const STAFF_ROLES: UserRole[] = ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'];

export const isStaffRole = (role?: string | null): boolean => {
  if (!role) return false;
  const r = role.toUpperCase().replace(/\s+/g, '_');
  return STAFF_ROLES.includes(r as UserRole);
};

interface StaffLockoutRecord {
  failedAttempts: number;
  lockedUntil?: number;
}
const staffLockoutsByIdentifier = new Map<string, StaffLockoutRecord>();
const staffLockoutsByIp = new Map<string, StaffLockoutRecord>();

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || req.ip || '127.0.0.1';
}

function checkStaffLockout(email: string, ip: string): { locked: boolean; minutesRemaining?: number } {
  const now = Date.now();
  const emailRecord = staffLockoutsByIdentifier.get(email.toLowerCase());
  if (emailRecord?.lockedUntil && emailRecord.lockedUntil > now) {
    return { locked: true, minutesRemaining: Math.ceil((emailRecord.lockedUntil - now) / 60000) };
  }
  const ipRecord = staffLockoutsByIp.get(ip);
  if (ipRecord?.lockedUntil && ipRecord.lockedUntil > now) {
    return { locked: true, minutesRemaining: Math.ceil((ipRecord.lockedUntil - now) / 60000) };
  }
  return { locked: false };
}

function recordStaffFailure(email: string, ip: string, reason: string, req?: Request): { locked: boolean; attempts: number } {
  const normEmail = email.toLowerCase();
  const now = Date.now();
  const secConfig = db.getSecurityConfig();
  const maxAttempts = secConfig.lockoutMaxAttempts || 5;
  const lockoutDurationMinutes = secConfig.lockoutDurationMinutes || 15;
  const lockoutMs = lockoutDurationMinutes * 60 * 1000;

  const emailRecord = staffLockoutsByIdentifier.get(normEmail) || { failedAttempts: 0 };
  emailRecord.failedAttempts += 1;
  const ipRecord = staffLockoutsByIp.get(ip) || { failedAttempts: 0 };
  ipRecord.failedAttempts += 1;

  let locked = false;
  if (emailRecord.failedAttempts >= maxAttempts) {
    emailRecord.lockedUntil = now + lockoutMs;
    locked = true;
    securityAuditService.recordEvent({
      req,
      eventType: 'AUTH_LOGIN_FAILURE',
      action: 'Staff Account Locked',
      module: 'Authentication & Security',
      details: `Staff identifier ${normEmail} locked for ${lockoutDurationMinutes} minutes due to ${maxAttempts} consecutive failed login attempts`,
      actorEmail: normEmail,
      outcome: 'BLOCKED',
      severity: 'HIGH',
    });
  }
  if (ipRecord.failedAttempts >= maxAttempts) {
    ipRecord.lockedUntil = now + lockoutMs;
    locked = true;
  }

  staffLockoutsByIdentifier.set(normEmail, emailRecord);
  staffLockoutsByIp.set(ip, ipRecord);

  securityAuditService.recordEvent({
    req,
    eventType: 'AUTH_LOGIN_FAILURE',
    action: 'Staff Login Failed',
    module: 'Authentication & Security',
    details: `Failed staff login attempt for ${normEmail} from IP ${ip} (attempt ${emailRecord.failedAttempts}/${maxAttempts}): ${reason}`,
    actorEmail: normEmail,
    outcome: 'FAILURE',
    severity: locked ? 'HIGH' : 'MEDIUM',
  });

  return { locked, attempts: emailRecord.failedAttempts };
}

function clearStaffLockout(email: string, ip: string) {
  staffLockoutsByIdentifier.delete(email.toLowerCase());
  staffLockoutsByIp.delete(ip);
}

// RFC 6238 Base32 & TOTP Engine (zero external dependencies)
function base32Decode(str: string): Buffer {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0;
  let value = 0;
  const output: number[] = [];
  for (let i = 0; i < str.length; i++) {
    const idx = alphabet.indexOf(str[i].toUpperCase());
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(output);
}

function base32Encode(buffer: Buffer): string {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0;
  let value = 0;
  let output = '';
  for (let i = 0; i < buffer.length; i++) {
    value = (value << 8) | buffer[i];
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += alphabet[(value << (5 - bits)) & 31];
  }
  return output;
}

function verifyTOTPCode(secret: string, token: string, window = 1): boolean {
  if (!secret || !token) return false;
  try {
    const key = base32Decode(secret);
    const epoch = Math.floor(Date.now() / 1000);
    const currentStep = Math.floor(epoch / 30);
    for (let i = -window; i <= window; i++) {
      const step = currentStep + i;
      const buf = Buffer.alloc(8);
      buf.writeBigInt64BE(BigInt(step));
      const hmac = crypto.createHmac('sha1', key).update(buf).digest();
      const offset = hmac[hmac.length - 1] & 0xf;
      const code = ((hmac.readUInt32BE(offset) & 0x7fffffff) % 1000000).toString().padStart(6, '0');
      if (code === token.trim()) return true;
    }
  } catch (err) {
    return false;
  }
  return false;
}

// ==============================================================================
// 1. MEMBER LOGIN (Authoritative with 403 WRONG_PORTAL gate for staff roles)
// ==============================================================================
async function handleMemberLogin(req: Request, res: Response) {
  const { email, identifier, phone, password } = req.body || {};
  const input = (identifier || email || phone || '').trim();

  if (!input) {
    return sendAuthError(res, 400, 'EMAIL_REQUIRED', 'Email address or phone number is required.');
  }

  if (!password) {
    return sendAuthError(res, 400, 'PASSWORD_REQUIRED', 'Password is required to sign in.');
  }

  if (!supabaseUrl || !rawKey || supabaseUrl.includes('unconfigured.supabase.local')) {
    return sendAuthError(
      res,
      503,
      'AUTH_PROVIDER_UNAVAILABLE',
      'Authentication is temporarily unavailable. Please contact the system administrator.'
    );
  }

  try {
    const admin = getAdminClient();
    let emailToAuth = input.toLowerCase();
    if (!input.includes('@')) {
      try {
        const { data: foundProfile } = await admin
          .from('profiles')
          .select('email')
          .or(`phone.eq.${input},full_name.eq.${input}`)
          .maybeSingle();
        if (foundProfile?.email) {
          emailToAuth = foundProfile.email.toLowerCase();
        }
      } catch (lookupErr) {
        console.warn('Identifier lookup notice:', lookupErr);
      }
    }

    const authClient = createIsolatedAuthClient();
    const { data, error } = await authClient.auth.signInWithPassword({
      email: emailToAuth,
      password,
    });

    if (error || !data?.user || !data?.session) {
      securityAuditService.recordEvent({
        req,
        eventType: 'AUTH_LOGIN_FAILURE',
        action: 'Member Login Failed',
        module: 'Authentication & Security',
        details: `Failed member login attempt for ${emailToAuth}: Invalid credentials`,
        actorEmail: emailToAuth,
        outcome: 'FAILURE',
        severity: 'MEDIUM',
      });
      return sendAuthError(
        res,
        401,
        'INVALID_CREDENTIALS',
        'Invalid email/phone or password. Please verify your credentials.'
      );
    }

    const authUser = data.user;
    const rawSession = data.session;

    let decodedJwt: any = null;
    try {
      decodedJwt = jwt.decode(rawSession.access_token);
    } catch {}

    // Load authoritative profile without immediately throwing on Pending so we can return pending reference details
    const resolvedUser = await buildAuthoritativeSessionFromAuthUser(authUser, {
      decodedJwt,
      enforceActiveStatus: false,
    });

    // Role check: Staff roles are strictly forbidden from member portal
    if (isStaffRole(resolvedUser.role)) {
      if (rawSession?.access_token) {
        revokeSessionToken(rawSession.access_token);
        try {
          if (typeof (admin.auth.admin as any)?.signOut === 'function') {
            await (admin.auth.admin as any).signOut(rawSession.access_token, 'global').catch(() => {});
          }
        } catch {}
      }
      return sendAuthError(
        res,
        403,
        'WRONG_PORTAL',
        'Staff and leadership members must sign in via the Staff Portal (/staff/login).',
        { correctPortal: '/staff/login' }
      );
    }

    // Check account status
    if (resolvedUser.status === 'Suspended') {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(
        res,
        403,
        'ACCOUNT_SUSPENDED',
        'This account has been suspended. Please contact church administration.'
      );
    }

    if (resolvedUser.status === 'Inactive' || resolvedUser.status === 'Locked') {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(
        res,
        403,
        resolvedUser.status === 'Locked' ? 'ACCOUNT_LOCKED' : 'ACCOUNT_INACTIVE',
        `This account is currently ${resolvedUser.status.toLowerCase()}. Access denied.`
      );
    }

    // Check pending application status
    if (resolvedUser.status === 'Pending') {
      revokeSessionToken(rawSession.access_token);
      const state = db.getState();
      const pendingWf = state.workflows.find(
        (w) =>
          w.requestType === 'Membership Application' &&
          (w.requesterEmail?.toLowerCase() === resolvedUser.email.toLowerCase() ||
            w.details?.toLowerCase().includes(resolvedUser.email.toLowerCase()))
      );
      return res.status(403).json({
        success: false,
        status: 'PENDING',
        error: 'ACCOUNT_PENDING',
        code: 'ACCOUNT_PENDING',
        message: 'Your registration is currently under review by pastoral administration.',
        referenceCode: pendingWf?.requestCode,
        redirectUrl: `/application-status/${pendingWf?.requestCode || ''}`,
      });
    }

    // Check temporary password expiration
    if (resolvedUser.must_change_password && resolvedUser.temp_password_expires_at) {
      if (new Date(resolvedUser.temp_password_expires_at).getTime() < Date.now()) {
        revokeSessionToken(rawSession.access_token);
        return sendAuthError(
          res,
          403,
          'TEMP_PASSWORD_EXPIRED',
          'Your temporary password has expired. Please contact church administration.'
        );
      }
    }

    securityAuditService.registerSession({
      rawAccessToken: rawSession.access_token,
      rawRefreshToken: rawSession.refresh_token,
      userId: resolvedUser.id,
      userEmail: resolvedUser.email,
      userName: resolvedUser.name,
      userRole: resolvedUser.role,
      tenantId: resolvedUser.tenantId,
      branchId: resolvedUser.branchId,
      req,
      expiresInSeconds: rawSession.expires_in,
      aal: resolvedUser.aal || 'aal1',
      mfaVerified: false,
    });

    setAuthSessionCookies(res, {
      accessToken: rawSession.access_token,
      refreshToken: rawSession.refresh_token,
      expiresInSeconds: rawSession.expires_in,
    });

    securityAuditService.recordEvent({
      req,
      eventType: 'AUTH_LOGIN_SUCCESS',
      action: 'Member Login Authenticated',
      module: 'Authentication & Security',
      details: `Member ${resolvedUser.email} successfully logged in via Member Portal`,
      actorId: resolvedUser.id,
      actorEmail: resolvedUser.email,
      actorName: resolvedUser.name,
      actorRole: resolvedUser.role,
      outcome: 'SUCCESS',
      severity: 'LOW',
      sessionId: rawSession.access_token,
    });

    return res.status(200).json({
      success: true,
      user: resolvedUser,
      profile: resolvedUser,
      session: {
        access_token: rawSession.access_token,
        refresh_token: rawSession.refresh_token,
        expires_in: rawSession.expires_in,
        expires_at: rawSession.expires_at,
        token_type: 'bearer',
      },
      token: rawSession.access_token,
      refreshToken: rawSession.refresh_token,
      mustChangePassword: resolvedUser.must_change_password,
      must_change_password: resolvedUser.must_change_password,
    });
  } catch (err: any) {
    if (err instanceof AuthError) {
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    return sendAuthError(res, 401, 'INVALID_CREDENTIALS', err?.message || 'Invalid email or password.');
  }
}

// Wire Member Login routes (dedicated + alias)
router.post('/member/login', loginLimiter, handleMemberLogin);
router.post('/login', loginLimiter, handleMemberLogin);

// ==============================================================================
// 2. STAFF & LEADERSHIP LOGIN (POST /api/auth/staff/login)
// Production Architecture:
// Supabase Auth -> auth.users -> profiles -> authoritative role -> tenant -> branch -> permissions -> application session
// ==============================================================================
async function handleStaffLogin(req: Request, res: Response) {
  const { email, identifier, password, campusId, branchId: requestedBranchId } = req.body || {};
  const inputEmail = (email || identifier || '').trim().toLowerCase();
  const selectedCampus = (campusId || requestedBranchId || '').trim();
  const clientIp = getClientIp(req);

  if (!inputEmail || !inputEmail.includes('@')) {
    return sendAuthError(
      res,
      400,
      'EMAIL_REQUIRED',
      'Official church staff email is required (e.g. pastor@gracecathedral.org).'
    );
  }

  if (!password) {
    return sendAuthError(res, 400, 'PASSWORD_REQUIRED', 'Password is required to sign in.');
  }

  if (!supabaseUrl || !rawKey || supabaseUrl.includes('unconfigured.supabase.local')) {
    return sendAuthError(
      res,
      503,
      'AUTH_PROVIDER_UNAVAILABLE',
      'Authentication is temporarily unavailable. Please contact the system administrator.'
    );
  }

  try {
    const admin = getAdminClient();
    const authClient = createIsolatedAuthClient();
    const { data, error } = await authClient.auth.signInWithPassword({
      email: inputEmail,
      password,
    });

    if (error || !data?.user || !data?.session) {
      recordStaffFailure(inputEmail, clientIp, 'Invalid credentials', req);
      return sendAuthError(
        res,
        401,
        'INVALID_CREDENTIALS',
        'Invalid email or password'
      );
    }

    const authUser = data.user;
    const rawSession = data.session;

    let decodedJwt: any = null;
    try {
      decodedJwt = jwt.decode(rawSession.access_token);
    } catch {}

    // Resolve authoritative profile, role, status, tenant, branch, permissions, must_change_password, and MFA state
    // Set enforceActiveStatus: false so we can return specific structured errors and revoke the Supabase token cleanly
    let resolvedUser: any;
    try {
      resolvedUser = await buildAuthoritativeSessionFromAuthUser(authUser, {
        decodedJwt,
        enforceActiveStatus: false,
      });
    } catch (profErr: any) {
      revokeSessionToken(rawSession.access_token);
      if (profErr instanceof AuthError) {
        return sendAuthError(res, profErr.statusCode, profErr.code, profErr.message);
      }
      return sendAuthError(res, 403, 'PROFILE_NOT_FOUND', 'Authoritative staff profile not found.');
    }

    // 1. Account Status Verification (Active, Inactive, Suspended, Pending, Locked)
    if (resolvedUser.status === 'Suspended') {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(
        res,
        403,
        'ACCOUNT_SUSPENDED',
        'Staff account has been suspended. Access denied.'
      );
    }

    if (resolvedUser.status === 'Inactive') {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(
        res,
        403,
        'ACCOUNT_INACTIVE',
        'Staff account is inactive. Please contact a System Administrator.'
      );
    }

    if (resolvedUser.status === 'Pending') {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(
        res,
        403,
        'ACCOUNT_PENDING',
        'Staff account is pending administrative approval. Access denied.'
      );
    }

    if (resolvedUser.status === 'Locked') {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(
        res,
        423,
        'ACCOUNT_LOCKED',
        'Staff account is locked for security reasons. Please contact a System Administrator.'
      );
    }

    // 2. Authoritative Role Verification: Only staff and leadership allowed in Staff Portal
    if (!isStaffRole(resolvedUser.role)) {
      revokeSessionToken(rawSession.access_token);
      try {
        if (typeof (admin.auth.admin as any)?.signOut === 'function') {
          await (admin.auth.admin as any).signOut(rawSession.access_token, 'global').catch(() => {});
        }
      } catch {}
      return sendAuthError(
        res,
        403,
        'WRONG_PORTAL',
        'Regular members must sign in via the Member Portal (/login).',
        { correctPortal: '/login' }
      );
    }

    // 3. Authoritative Campus / Branch Validation
    // If a specific campus was selected at login, verify the user's authoritative profile permits that campus.
    // SYSTEM_ADMIN has global multi-campus authority ('*'), while campus-scoped staff must match their assigned branch.
    if (selectedCampus && resolvedUser.role !== 'SYSTEM_ADMIN') {
      const matchesAssignedBranch =
        isSameCampus(selectedCampus, resolvedUser.branchId) ||
        isSameCampus(selectedCampus, resolvedUser.branchName) ||
        (Array.isArray(resolvedUser.branchIds) &&
          resolvedUser.branchIds.some((b: string) => b !== '*' && isSameCampus(selectedCampus, b)));

      if (!matchesAssignedBranch) {
        revokeSessionToken(rawSession.access_token);
        return sendAuthError(
          res,
          403,
          'WRONG_CAMPUS',
          `Access denied for the selected campus. Your account is assigned to ${resolvedUser.branchName}.`,
          {
            assignedBranchId: resolvedUser.branchId,
            assignedBranchName: resolvedUser.branchName,
          }
        );
      }
    }

    // Clear failed login attempts upon valid credentials, status, role, and campus
    clearStaffLockout(inputEmail, clientIp);

    // Supabase Auth and profiles remain authoritative; login does not write a JSON user mirror.

    // 4. Mandatory Password Change Gate (must_change_password)
    if (resolvedUser.must_change_password) {
      if (
        resolvedUser.temp_password_expires_at &&
        new Date(resolvedUser.temp_password_expires_at).getTime() < Date.now()
      ) {
        revokeSessionToken(rawSession.access_token);
        db.addAuditLog(
          'TEMP_PASSWORD_EXPIRED',
          'Authentication & Security',
          `Temporary password login attempt rejected for ${resolvedUser.email} - credentials expired`,
          resolvedUser.email
        );
        return sendAuthError(
          res,
          403,
          'TEMP_PASSWORD_EXPIRED',
          'Your temporary password has expired. Please contact a System Administrator for a new password.'
        );
      }

      db.addAuditLog(
        'FIRST_LOGIN',
        'Authentication & Security',
        `Staff account ${resolvedUser.email} logged in with temporary password. Mandatory password change required.`,
        resolvedUser.email
      );
      db.addAuditLog(
        'PASSWORD_CHANGE_REQUIRED',
        'Authentication & Security',
        `Restricted staff account ${resolvedUser.email} to password-change flow until new credentials are confirmed.`,
        resolvedUser.email
      );

      // Return the real Supabase session token; authenticateToken middleware restricts it strictly to /change-password, /me, /logout
      return res.status(200).json({
        success: true,
        mustChangePassword: true,
        must_change_password: true,
        mfaRequired: false,
        user: resolvedUser,
        profile: resolvedUser,
        token: rawSession.access_token,
        refreshToken: rawSession.refresh_token,
        session: {
          access_token: rawSession.access_token,
          refresh_token: rawSession.refresh_token,
          expires_in: rawSession.expires_in,
          expires_at: rawSession.expires_at,
          token_type: 'bearer',
        },
        message: 'You must change your temporary password before accessing the CMMS.',
      });
    }

    // 5. Authoritative MFA State Check
    // Staff MFA is mandatory. Accounts without an enrolled factor must complete
    // enrollment; enrolled accounts must verify a TOTP challenge before session
    // cookies or a fully authenticated response are issued.
    // 6. MFA Enabled -> Issue TOTP Enrollment or Verification Challenge
    const branding = db.getBranding();
    const systemName = branding.systemName || 'Grace Cathedral CMMS';

    let factorId = `factor_${resolvedUser.id}`;
    let mfaEnrolled = Boolean(resolvedUser.mfa_enrolled);

    if (isValidUUID(resolvedUser.id)) {
      try {
        const { data: factorsData } = await admin.auth.admin.mfa.listFactors({
          userId: resolvedUser.id,
        });
        const totpFactor = factorsData?.factors?.find((f) => f.factor_type === 'totp' && f.status === 'verified');
        if (totpFactor) {
          mfaEnrolled = true;
          factorId = totpFactor.id;
        }
      } catch {}
    }

    // Clean up expired challenges
    const now = Date.now();
    for (const [key, record] of pendingStaffMfaEnrollments.entries()) {
      if (record.expiresAt < now) pendingStaffMfaEnrollments.delete(key);
    }
    for (const [key, record] of pendingStaffMfaChallenges.entries()) {
      if (record.expiresAt < now) pendingStaffMfaChallenges.delete(key);
    }

    if (!mfaEnrolled) {
      const challengeId = `mfa_enroll_${crypto.randomBytes(16).toString('hex')}`;
      let secret = '';
      let otpauthUri = '';

      if (rawSession?.access_token && isSupabaseConfigured) {
        try {
          const userClient = createClient(supabaseUrl, supabaseAnonKey || rawKey, {
            auth: { persistSession: false, autoRefreshToken: false },
            global: { headers: { Authorization: `Bearer ${rawSession.access_token}` } },
          });
          const enrollRes = await userClient.auth.mfa.enroll({
            factorType: 'totp',
            friendlyName: resolvedUser.email,
            issuer: systemName,
          });
          if (!enrollRes.error && enrollRes.data?.totp) {
            factorId = enrollRes.data.id;
            secret = enrollRes.data.totp.secret;
            otpauthUri = enrollRes.data.totp.uri;
          }
        } catch {}
      }

      if (!secret) {
        const rawSecret = crypto.randomBytes(20);
        secret = base32Encode(rawSecret);
        otpauthUri = `otpauth://totp/${encodeURIComponent(systemName)}:${encodeURIComponent(resolvedUser.email)}?secret=${secret}&issuer=${encodeURIComponent(systemName)}`;
      }

      pendingStaffMfaEnrollments.set(challengeId, {
        userId: resolvedUser.id,
        email: resolvedUser.email.toLowerCase(),
        secret,
        uri: otpauthUri,
        factorId,
        challengeId,
        expiresAt: now + 10 * 60 * 1000,
      });

      pendingStaffMfaChallenges.set(challengeId, {
        challengeId,
        userId: resolvedUser.id,
        email: resolvedUser.email.toLowerCase(),
        supabaseAccessToken: rawSession.access_token,
        supabaseRefreshToken: rawSession.refresh_token,
        supabaseSession: rawSession,
        factorId,
        enrollmentSecret: secret,
        enrollmentUri: otpauthUri,
        expiresAt: now + 10 * 60 * 1000,
      });

      const aal1ChallengeToken = jwt.sign(
        {
          sub: resolvedUser.id,
          userId: resolvedUser.id,
          email: resolvedUser.email,
          role: resolvedUser.role,
          branchId: resolvedUser.branchId,
          aal: 'aal1',
          purpose: 'mfa_challenge',
          challengeId,
          enrollmentId: challengeId,
        },
        JWT_SECRET,
        { expiresIn: '10m' }
      );

      db.addAuditLog(
        'Staff MFA Enrollment Initiated',
        'Authentication & Security',
        `Staff member ${resolvedUser.email} initiated mandatory TOTP 2FA enrollment`,
        resolvedUser.email
      );

      return res.status(200).json({
        success: true,
        mfaRequired: true,
        mfaEnrolled: false,
        user: resolvedUser,
        profile: resolvedUser,
        totp: {
          factorId,
          secret,
          uri: otpauthUri,
        },
        factorId,
        challengeId,
        sessionToken: aal1ChallengeToken,
        message: 'Two-factor authentication enrollment required. Please scan the QR code with your authenticator app.',
      });
    } else {
      const challengeId = `mfa_chal_${crypto.randomBytes(16).toString('hex')}`;

      pendingStaffMfaChallenges.set(challengeId, {
        challengeId,
        userId: resolvedUser.id,
        email: resolvedUser.email.toLowerCase(),
        supabaseAccessToken: rawSession.access_token,
        supabaseRefreshToken: rawSession.refresh_token,
        supabaseSession: rawSession,
        factorId,
        expiresAt: now + 10 * 60 * 1000,
      });

      const aal1ChallengeToken = jwt.sign(
        {
          sub: resolvedUser.id,
          userId: resolvedUser.id,
          email: resolvedUser.email,
          role: resolvedUser.role,
          branchId: resolvedUser.branchId,
          aal: 'aal1',
          purpose: 'mfa_challenge',
          challengeId,
        },
        JWT_SECRET,
        { expiresIn: '10m' }
      );

      db.addAuditLog(
        'Staff MFA Challenge Issued',
        'Authentication & Security',
        `Staff member ${resolvedUser.email} issued TOTP challenge`,
        resolvedUser.email
      );

      return res.status(200).json({
        success: true,
        mfaRequired: true,
        mfaEnrolled: true,
        user: resolvedUser,
        profile: resolvedUser,
        factorId,
        challengeId,
        sessionToken: aal1ChallengeToken,
        message: 'Please enter the 6-digit verification code from your authenticator app.',
      });
    }
  } catch (err: any) {
    if (err instanceof AuthError) {
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    return sendAuthError(res, 401, 'AUTH_FAILED', err?.message || 'Staff authentication failed.');
  }
}

// Wire Staff Login route
router.post('/staff/login', loginLimiter, handleStaffLogin);

// 1A-1. REQUEST PASSWORD RESET (Supports Email & Phone SMS OTP with strict rate limiting & generic responses)
// Password recovery is fail-closed until a provider-backed recovery flow
// can deliver, verify, and consume a challenge and update Supabase Auth.
router.post(['/forgot-password', '/staff/forgot-password'], passwordResetRequestLimiter, (_req: Request, res: Response) => {
  return sendAuthError(
    res,
    503,
    'PASSWORD_RECOVERY_UNAVAILABLE',
    'Password recovery is temporarily unavailable. Please contact an administrator.'
  );
});

// Verify endpoint remains disabled alongside request/reset until the full
// provider-backed recovery lifecycle is implemented.
router.post('/verify-reset-code', passwordResetVerifyLimiter, (_req: Request, res: Response) => {
  return sendAuthError(
    res,
    503,
    'PASSWORD_RECOVERY_UNAVAILABLE',
    'Password recovery is temporarily unavailable. Please contact an administrator.'
  );
});

router.post('/reset-password', passwordResetVerifyLimiter, (_req: Request, res: Response) => {
  return sendAuthError(
    res,
    503,
    'PASSWORD_RECOVERY_UNAVAILABLE',
    'Password recovery is temporarily unavailable. Please contact an administrator.'
  );
});

// 1A-4. AUTHORITATIVE PASSWORD CHANGE (Supabase Auth + Profile must_change_password update)
router.post('/change-password', async (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return sendAuthError(res, 401, 'NO_TOKEN', 'Authentication required.');
    }

    const bearerMatch = /^Bearer\s+(.+)$/i.exec(authHeader.trim());
    if (!bearerMatch || !bearerMatch[1] || !bearerMatch[1].trim()) {
      return sendAuthError(
        res,
        401,
        'INVALID_TOKEN',
        'Invalid Authorization header format. Format must be "Bearer <token>".'
      );
    }

    const token = bearerMatch[1].trim();
    const sessionUser = await resolveTrustedUserSession(token);

    const { currentPassword, newPassword, confirmPassword } = req.body || {};

    if (!currentPassword || typeof currentPassword !== 'string' || !currentPassword.trim()) {
      return sendAuthError(
        res,
        400,
        'CURRENT_PASSWORD_REQUIRED',
        'Current password is required to change your password.'
      );
    }

    if (newPassword === currentPassword || newPassword === 'Pass@12345') {
      return sendAuthError(
        res,
        400,
        'PASSWORD_SAME_AS_TEMPORARY',
        'New password cannot be the same as your temporary password. Please choose a new secure password.'
      );
    }

    if (confirmPassword && newPassword !== confirmPassword) {
      return sendAuthError(
        res,
        400,
        'PASSWORD_CONFIRMATION_MISMATCH',
        'New password and password confirmation do not match.'
      );
    }

    if (!newPassword || newPassword.length < 8) {
      return sendAuthError(res, 400, 'WEAK_PASSWORD', 'New password must be at least 8 characters long.');
    }

    const hasUpper = /[A-Z]/.test(newPassword);
    const hasLower = /[a-z]/.test(newPassword);
    const hasNumber = /[0-9]/.test(newPassword);
    const hasSymbol = /[^A-Za-z0-9]/.test(newPassword);

    if (!hasUpper || !hasLower || !hasNumber || !hasSymbol) {
      return sendAuthError(
        res,
        400,
        'WEAK_PASSWORD',
        'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.'
      );
    }

    const nowIso = new Date().toISOString();
    let updatedAuthData: any = null;
    let freshSignIn: any = null;
    let freshSession: any = null;
    let freshToken = token;
    let freshRefreshToken: string | undefined = undefined;

    if (isSupabaseConfigured) {
      // Verify current password via Supabase Auth
      const verifyClient = createIsolatedAuthClient();
      const { error: signInError } = await verifyClient.auth.signInWithPassword({
        email: sessionUser.email,
        password: currentPassword,
      });

      if (signInError) {
        return sendAuthError(
          res,
          400,
          'INVALID_CURRENT_PASSWORD',
          'Current password verification failed. Please check your credentials.'
        );
      }

      const admin = getAdminClient();

      // Update password and clear must_change_password in Supabase Auth user metadata
      const { data: uData, error: updateAuthErr } = await admin.auth.admin.updateUserById(
        sessionUser.id,
        {
          password: newPassword,
          app_metadata: {
            must_change_password: false,
            password_changed_at: nowIso,
            temp_password_expires_at: null,
          },
          user_metadata: {
            must_change_password: false,
          },
        }
      );

      if (updateAuthErr) {
        return sendAuthError(
          res,
          500,
          'PASSWORD_UPDATE_FAILED',
          updateAuthErr.message || 'Failed to update password in authentication service.'
        );
      }
      updatedAuthData = uData;

      // Also update profiles table if extra columns exist
      try {
        await admin
          .from('profiles')
          .update({
            updated_at: nowIso,
          })
          .eq('id', sessionUser.id);
      } catch {}

      // Sign in with the new password to issue a fresh Supabase session token
      const freshAuthClient = createIsolatedAuthClient();
      const { data: fSignIn } = await freshAuthClient.auth.signInWithPassword({
        email: sessionUser.email,
        password: newPassword,
      });
      freshSignIn = fSignIn;
      freshSession = freshSignIn?.session;
      if (freshSession?.access_token) {
        freshToken = freshSession.access_token;
        freshRefreshToken = freshSession.refresh_token;
        setAuthSessionCookies(res, {
          accessToken: freshSession.access_token,
          refreshToken: freshSession.refresh_token,
          expiresInSeconds: freshSession.expires_in,
        });
      }
    } else {
      // Without Supabase Auth, a signed session alone is not proof of the current password.
      // Require a locally stored bcrypt hash; never accept missing or plaintext credentials.
      const state = db.getState();
      const existingSysUser = (state.systemUsers || []).find(
        (u) => u.id === sessionUser.id || u.email?.toLowerCase() === sessionUser.email.toLowerCase()
      );
      const storedPass = (existingSysUser as any)?.passwordHash || (existingSysUser as any)?.password;

      if (!storedPass || typeof storedPass !== 'string' || !storedPass.startsWith('$2')) {
        return sendAuthError(
          res,
          503,
          'PASSWORD_CHANGE_VERIFICATION_UNAVAILABLE',
          'Current-password verification is unavailable for this account. Contact an administrator.'
        );
      }

      let passwordMatch = false;
      try {
        passwordMatch = bcrypt.compareSync(currentPassword, storedPass);
      } catch {
        passwordMatch = false;
      }

      if (!passwordMatch) {
        return sendAuthError(
          res,
          400,
          'INVALID_CURRENT_PASSWORD',
          'Current password verification failed. Please check your credentials.'
        );
      }

      // Generate a fresh JWT with mustChangePassword = false
      freshToken = jwt.sign(
        {
          sub: sessionUser.id,
          userId: sessionUser.id,
          email: sessionUser.email,
          role: sessionUser.role,
          tenantId: sessionUser.tenantId,
          mustChangePassword: false,
          must_change_password: false,
          aal: 'aal1',
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      );
    }

    // Supabase Auth is authoritative when configured. Do not write a second,
    // potentially stale password or must-change-password copy to the JSON store.
    if (!isSupabaseConfigured) {
      const state = db.getState();
      const existingSysUser = (state.systemUsers || []).find(
        (u) => u.id === sessionUser.id || u.email?.toLowerCase() === sessionUser.email.toLowerCase()
      );
      if (existingSysUser) {
        existingSysUser.must_change_password = false;
        existingSysUser.mustChangePassword = false;
        existingSysUser.password_changed_at = nowIso;
        (existingSysUser as any).temp_password_expires_at = undefined;
        (existingSysUser as any).temporaryPassword = undefined;
        (existingSysUser as any).password = bcrypt.hashSync(newPassword, 10);
        db.persist();
      }
    }

    securityAuditService.recordEvent({
      req,
      eventType: 'PASSWORD_CHANGED',
      action: 'PASSWORD_CHANGED',
      module: 'Security & Access',
      details: `Password successfully changed and verified for account ${sessionUser.email}.`,
      actorId: sessionUser.id,
      actorEmail: sessionUser.email,
      actorName: sessionUser.name,
      actorRole: sessionUser.role,
      outcome: 'SUCCESS',
      severity: 'LOW',
    });

    const updatedSessionUser: any = {
      ...sessionUser,
      must_change_password: false,
      mustChangePassword: false,
      password_changed_at: nowIso,
    };

    return res.status(200).json({
      success: true,
      message: 'Password successfully updated.',
      mustChangePassword: false,
      must_change_password: false,
      password_changed_at: nowIso,
      token: freshToken,
      refreshToken: freshRefreshToken,
      session: freshSession
        ? {
            access_token: freshSession.access_token,
            refresh_token: freshSession.refresh_token,
            expires_in: freshSession.expires_in,
            expires_at: freshSession.expires_at,
            token_type: 'bearer',
          }
        : undefined,
      user: updatedSessionUser,
      profile: updatedSessionUser,
    });
  } catch (err: any) {
    if (err instanceof AuthError) {
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    return sendAuthError(res, 500, 'PASSWORD_UPDATE_FAILED', err?.message || 'Failed to update password.');
  }
});

// 1B. GOOGLE OAUTH ONBOARDING CHECK (Strictly Member Onboarding / Authoritative Profile Lookup)
// States: NEW_USER (State A), PENDING (State B), APPROVED (State C), REJECTED (State D)
router.post('/google', async (req: Request, res: Response) => {
  const { email, name, googleId, picture } = req.body || {};
  if (!email) {
    return sendAuthError(res, 400, 'EMAIL_REQUIRED', 'Google email is required.');
  }

  const state = db.getState();
  const normalizedEmail = String(email).toLowerCase().trim();

  // 1. Check authoritative Supabase profile first
  const admin = getAdminClient();
  let sbProfile: any = null;
  try {
    const { data } = await admin
      .from('profiles')
      .select('*')
      .ilike('email', normalizedEmail)
      .maybeSingle();
    sbProfile = data;
  } catch {}

  const existingUser = state.systemUsers.find((u) => u.email.toLowerCase() === normalizedEmail);
  const authoritativeRole = sbProfile?.role
    ? normalizeUserRole(sbProfile.role)
    : existingUser?.role
      ? normalizeUserRole(existingUser.role)
      : null;

  // Staff and leadership members must sign in via the Staff Portal (/staff/login)
  if (authoritativeRole && isStaffRole(authoritativeRole)) {
    return sendAuthError(
      res,
      403,
      'WRONG_PORTAL',
      'Staff and leadership members must sign in via the Staff Portal (/staff/login) using email and password.',
      { correctPortal: '/staff/login', status: 'WRONG_PORTAL' }
    );
  }

  // 2. Check if a workflow application exists
  const existingWf = state.workflows.find(
    (w) =>
      w.requestType === 'Membership Application' &&
      (w.requesterEmail?.toLowerCase() === normalizedEmail || w.details?.toLowerCase().includes(normalizedEmail))
  );

  // If user is not in database at all -> STATE A: NEW_USER
  if (!sbProfile && !existingUser && !existingWf) {
    return res.status(200).json({
      success: true,
      status: 'NEW_USER',
      message: 'User not found in system database. Please complete registration form.',
      googleUser: {
        email: normalizedEmail,
        name: name || normalizedEmail.split('@')[0],
        googleId: googleId || `gid_${Date.now()}`,
        picture: picture || '',
      },
    });
  }

  const userStatus =
    sbProfile?.status ||
    existingUser?.status ||
    (existingWf
      ? existingWf.status === 'Approved'
        ? 'Active'
        : existingWf.status === 'Rejected'
          ? 'Suspended'
          : 'Pending'
      : 'Pending');

  // STATE B: PENDING
  if (userStatus === 'Pending') {
    const pendingUser: SystemUser = existingUser || {
      id: sbProfile?.id || existingWf?.id || `usr-pending-${Date.now()}`,
      name: sbProfile?.full_name || existingWf?.requesterName || name || normalizedEmail.split('@')[0],
      email: normalizedEmail,
      phone: sbProfile?.phone || existingWf?.requesterPhone || '+251 91 123 4567',
      role: 'REGULAR_MEMBER',
      branchName: existingWf?.branchName || 'Headquarters Campus',
      status: 'Pending',
      lastLogin: new Date().toISOString(),
    };

    const refCode = existingWf?.requestCode || '';
    return res.status(200).json({
      success: true,
      status: 'PENDING',
      message: 'Your registration is currently under review by pastoral administration. Please check your application status.',
      referenceCode: refCode,
      redirectUrl: `/application-status/${refCode}`,
      user: pendingUser,
      workflow: existingWf || null,
    });
  }

  // STATE D: REJECTED / SUSPENDED
  if (userStatus === 'Suspended' || existingWf?.status === 'Rejected') {
    const rejectedUser: SystemUser = existingUser || {
      id: sbProfile?.id || existingWf?.id || `usr-rej-${Date.now()}`,
      name: sbProfile?.full_name || existingWf?.requesterName || name || normalizedEmail.split('@')[0],
      email: normalizedEmail,
      role: 'REGULAR_MEMBER',
      branchName: 'Headquarters Campus',
      status: 'Suspended',
      lastLogin: new Date().toISOString(),
    };

    return res.status(200).json({
      success: true,
      status: 'REJECTED',
      message: 'Access Denied. Your onboarding application has been reviewed and declined.',
      reason: existingWf?.rejectedReason || existingWf?.comments || 'Application did not meet prerequisite criteria.',
      supportContact: {
        email: 'admin@gracecathedral.org',
        phone: '+251 11 662 8900',
        office: 'Office of Pastoral Governance, Addis Ababa',
      },
      user: rejectedUser,
    });
  }

  // STATE C: APPROVED REGULAR MEMBER
  const approvedUser: SystemUser = existingUser || {
    id: sbProfile?.id || `usr-${Date.now()}`,
    name: sbProfile?.full_name || name || normalizedEmail.split('@')[0],
    email: normalizedEmail,
    role: 'REGULAR_MEMBER',
    branchName: 'Headquarters Campus',
    branchIds: [sbProfile?.branch_id || DEFAULT_HQ_BRANCH_UUID],
    status: 'Active',
    lastLogin: new Date().toISOString(),
  };

  approvedUser.role = 'REGULAR_MEMBER';
  approvedUser.lastLogin = new Date().toISOString();
  db.persist();

  return res.status(200).json({
    success: true,
    status: 'APPROVED',
    message: 'Google Authentication verified. Please sign in with your member credentials.',
    user: approvedUser,
  });
});

// 1C. ONBOARDING + PUBLIC MEMBERSHIP REGISTRATION — PostgreSQL is authoritative.
router.post('/register-onboarding', publicRegistrationLimiter, async (req: Request, res: Response) => {
  const { name, email, phone, department, address, city, notes } = req.body || {};
  if (typeof name !== 'string' || !name.trim() || typeof email !== 'string' || !email.trim()) {
    return res.status(400).json({ error: 'Full Name and Email are required.' });
  }
  const normalizedEmail = email.trim().toLowerCase();
  const tenantId = DEFAULT_TENANT_UUID;
  const branchId = DEFAULT_HQ_BRANCH_UUID;
  try {
    const existing = await query(
      `SELECT id FROM public.workflow_requests
       WHERE tenant_id=$1::uuid AND request_type='Membership Application'
         AND lower(requester_email)=lower($2) AND status='Pending' LIMIT 1`,
      [tenantId, normalizedEmail]
    );
    if (existing.rowCount) return res.status(409).json({ error: 'A pending membership application already exists for this email.' });
    const workflow = await createMembershipApplication({
      tenantId, branchId, requestCode: `APP-${Date.now().toString().slice(-8)}`,
      requesterName: name.trim(), requesterPhone: phone || undefined, requesterEmail: normalizedEmail,
      branchName: 'Headquarters Campus',
      details: `Online onboarding. Department: ${department || 'General'}. Address: ${address || ''}. City: ${city || ''}. Notes: ${notes || ''}`,
      pendingMemberData: {
        firstName: name.trim().split(/\\s+/)[0], lastName: name.trim().split(/\\s+/).slice(1).join(' ') || 'Member',
        gender: 'Male', primaryPhone: phone || '', email: normalizedEmail, streetAddress: address || '',
        city: city || 'Addis Ababa', membershipStatus: 'Pending Approval',
      } as any,
    });
    return res.status(201).json({ success: true, status: 'PENDING', workflow, message: 'Your registration is awaiting church approval.' });
  } catch (error: any) {
    console.error('[Membership onboarding] PostgreSQL write failed:', error);
    return res.status(500).json({ error: 'Registration could not be saved. Please try again or contact the church office.' });
  }
});

// Public registration metadata: expose only active campus IDs and names.
router.get('/registration-options', async (_req: Request, res: Response) => {
  try {
    // Read active campus options from the Supabase database via PostgREST.
    // This avoids requiring the separate node-postgres DATABASE_URL just to
    // populate the public registration form.
    const admin = getAdminClient();
    const { data, error } = await admin
      .from('branches')
      .select('id,name')
      .eq('tenant_id', DEFAULT_TENANT_UUID)
      .eq('status', 'Active')
      .order('name', { ascending: true });

    if (error) {
      console.error('[Registration options] Supabase branch read failed:', error);
      return res.status(500).json({ error: 'Registration campuses are temporarily unavailable.' });
    }

    const branches = (data || [])
      .filter((row: any) => typeof row.id === 'string' && typeof row.name === 'string')
      .map((row: any) => ({ id: row.id, name: row.name }));

    return res.json({ success: true, branches });
  } catch (error) {
    console.error('[Registration options] Database read failed:', error);
    return res.status(500).json({ error: 'Registration campuses are temporarily unavailable.' });
  }
});

// Public member registration creates a PostgreSQL approval record. It does not
// create an active member until an authorized reviewer approves the application.
router.post('/register-public', publicRegistrationLimiter, async (req: Request, res: Response) => {
  const body = req.body || {};
  const firstName = String(body.firstName || '').trim();
  const lastName = String(body.lastName || '').trim();
  const cleanEmail = String(body.email || '').trim().toLowerCase();
  const phone = String(body.phone || '').trim();
  if (!firstName || !lastName) return res.status(400).json({ error: 'First name and last name are required.' });
  if (!cleanEmail && !cleanPhone(phone)) return res.status(400).json({ error: 'Either email address or mobile phone number is required.' });
  if (body.password && String(body.password).length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters long.' });

  const state = db.getState();
  let invitation: any = null;
  if (body.registrationToken) {
    invitation = (state.registrationInvitations || []).find((item: any) => item.token === String(body.registrationToken).trim());
    if (!invitation) return res.status(404).json({ error: 'Invalid registration invitation token.', code: 'INVALID_REGISTRATION_TOKEN' });
    if (invitation.status === 'revoked') return res.status(410).json({ error: invitation.revokedReason || 'This registration invitation has been revoked.', code: 'INVITATION_REVOKED' });
    if (invitation.expiresAt && Date.now() > new Date(invitation.expiresAt).getTime()) return res.status(410).json({ error: 'This registration invitation has expired.', code: 'INVITATION_EXPIRED' });
    if ((invitation.singleUse && invitation.usesCount >= 1) || (invitation.maxUses > 0 && invitation.usesCount >= invitation.maxUses)) {
      return res.status(410).json({ error: 'This registration invitation has reached its usage limit.', code: 'INVITATION_LIMIT_REACHED' });
    }
  }

  const tenantId = isValidUUID(invitation?.tenantId) ? invitation.tenantId : DEFAULT_TENANT_UUID;
  const requestedBranchId = isValidUUID(invitation?.branchId) ? invitation.branchId : (isValidUUID(body.branchId) ? body.branchId : DEFAULT_HQ_BRANCH_UUID);
  const branchResult = await query(
    `SELECT id,name FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid AND status='Active' LIMIT 1`,
    [requestedBranchId, tenantId]
  );
  if (!branchResult.rows[0]) return res.status(400).json({ error: 'The selected registration campus is unavailable. Please contact the church office.' });
  const branchId = branchResult.rows[0].id as string;
  const branchName = branchResult.rows[0].name as string;

  try {
    const duplicate = await query(
      `SELECT id,member_number FROM public.members
       WHERE tenant_id=$1::uuid AND
         (($2::text IS NOT NULL AND lower(email)=lower($2)) OR ($3::text IS NOT NULL AND regexp_replace(coalesce(phone,''),'[^0-9]','','g')=regexp_replace($3,'[^0-9]','','g')))
       LIMIT 1`,
      [tenantId, cleanEmail || null, phone || null]
    );
    if (duplicate.rowCount) return res.status(409).json({ error: 'A member with this email or phone number already exists.', code: 'MEMBER_ALREADY_EXISTS' });

    const pendingDuplicate = await query(
      `SELECT id FROM public.workflow_requests WHERE tenant_id=$1::uuid AND request_type='Membership Application'
       AND status='Pending' AND (($2::text IS NOT NULL AND lower(requester_email)=lower($2)) OR
       ($3::text IS NOT NULL AND regexp_replace(coalesce(requester_phone,''),'[^0-9]','','g')=regexp_replace($3,'[^0-9]','','g'))) LIMIT 1`,
      [tenantId, cleanEmail || null, phone || null]
    );
    if (pendingDuplicate.rowCount) return res.status(409).json({ error: 'A pending application already exists for this email or phone number.', code: 'APPLICATION_ALREADY_PENDING' });

    const now = new Date().toISOString();
    const applicationReference = `MEM-APP-${Math.floor(100000 + Math.random() * 900000)}`;
    const memberIdNumber = `GC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const resolvedDob = body.dob || body.dateOfBirth || null;
    const selectedMinistries = Array.isArray(body.ministriesJoinedNow) ? body.ministriesJoinedNow :
      Array.isArray(body.selectedMinistries) ? body.selectedMinistries : [];
    const ministryIds = [...new Set((Array.isArray(body.ministryIds) ? body.ministryIds : []).filter(isDatabaseUuid))];
    const emergencyContact = body.emergencyContact && typeof body.emergencyContact === 'object'
      ? body.emergencyContact
      : { name: body.emergencyName || '', relationship: body.emergencyRelationship || '', phone: body.emergencyPhone || phone };
    const pendingMemberData: any = {
      memberIdNumber, title: body.title || (body.gender === 'Female' ? 'Sister' : 'Brother'),
      firstName, middleName: String(body.middleName || '').trim(), lastName,
      gender: body.gender === 'Female' ? 'Female' : 'Male',
      maritalStatus: body.maritalStatus || 'Single', dateOfBirth: resolvedDob || '',
      primaryPhone: phone, altPhone: body.altPhone || '', email: cleanEmail || undefined,
      streetAddress: body.streetAddress || body.address || '', city: body.city || 'Addis Ababa',
      subCity: body.subCity || '', region: body.region || '', postalCode: body.postalCode || '',
      woreda: body.woreda || '', kebele: body.kebele || '', houseNumber: body.houseNumber || '',
      branchId, branchName, membershipStatus: 'Pending Approval', membershipType: 'Full Member',
      membershipDate: body.membershipDate || now.slice(0,10), membershipLocation: body.membershipLocation || branchName,
      nationality: body.nationality || 'Ethiopian', nationalIdNumber: body.nationalIdNumber || '',
      passportNumber: body.passportNumber || '', photoUrl: body.photoUrl || '',
      marriageDate: body.marriageDate || '', spouseName: body.spouseName || '', spousePhone: body.spousePhone || '',
      maleChildrenCount: Number(body.maleChildrenCount || 0), femaleChildrenCount: Number(body.femaleChildrenCount || 0),
      adoptedChildrenCount: Number(body.adoptedChildrenCount || 0),
      isWaterBaptized: Boolean(body.isWaterBaptized ?? body.waterBaptized),
      waterBaptized: Boolean(body.isWaterBaptized ?? body.waterBaptized),
      baptismDate: body.baptismDate || body.waterBaptismDate || '', waterBaptismDate: body.waterBaptismDate || body.baptismDate || '',
      waterBaptismLocation: body.waterBaptismLocation || '', isHolySpiritBaptized: Boolean(body.isHolySpiritBaptized),
      salvationDate: body.salvationDate || '', salvationLocation: body.salvationLocation || '',
      previousChurch: body.previousChurch || '', foundationCourseCompleted: Boolean(body.foundationCourseCompleted),
      discipleshipLevel: body.discipleshipLevel || '', ministryIds,
      ministriesJoinedNow: selectedMinistries, ministriesServedBefore: Array.isArray(body.ministriesServedBefore) ? body.ministriesServedBefore : [],
      educationLevel: body.educationLevel || '', fieldOfStudy: body.fieldOfStudy || '', occupation: body.occupation || '',
      employer: body.employer || body.employerName || '', employerName: body.employerName || body.employer || '',
      employerType: body.employerType || '', employerTypeOther: body.employerTypeOther || '',
      skillsAndTalents: Array.isArray(body.skillsAndTalents) ? body.skillsAndTalents : [],
      languagesSpoken: Array.isArray(body.languagesSpoken) ? body.languagesSpoken : [],
      bloodType: body.bloodType || '', knownAllergies: Array.isArray(body.knownAllergies) ? body.knownAllergies : [],
      emergencyContact, notes: body.notes || '', createdAt: now, lastActive: now,
    };
    const requiresApproval = invitation ? invitation.requiresApproval !== false : true;
    let member: any = pendingMemberData;
    if (!requiresApproval) {
      member = await createMemberRecord({ ...pendingMemberData, tenantId, branchId, membershipStatus: 'Active' } as any,
        { tenantId, branchIds: [branchId], branchId, allBranches: true });
    }
    const workflow = await createMembershipApplication({
      tenantId, branchId, requestCode: applicationReference, requesterName: `${firstName} ${lastName}`,
      requesterPhone: phone || undefined, requesterEmail: cleanEmail || undefined, branchName,
      details: `Public member registration. Selected ministries: ${selectedMinistries.join(', ') || 'None'}`,
      pendingMemberData,
      status: requiresApproval ? 'Pending' : 'Approved',
      approvedBy: requiresApproval ? undefined : (invitation?.createdByName || 'Invitation Auto-Approval'),
    });
    if (invitation) {
      invitation.usesCount = (invitation.usesCount || 0) + 1;
      invitation.lastUsedAt = now;
      invitation.updatedAt = now;
      if (!Array.isArray(invitation.usageHistory)) invitation.usageHistory = [];
      invitation.usageHistory.unshift({ id: `use-${Date.now()}`, applicantName: `${firstName} ${lastName}`, applicantEmail: cleanEmail || undefined, applicantPhone: phone || undefined, memberIdNumber, applicationReference, submittedAt: now, ipAddress: req.ip });
      if (invitation.singleUse || (invitation.maxUses > 0 && invitation.usesCount >= invitation.maxUses)) invitation.status = 'used';
      db.persist();
    }
    return res.status(201).json({
      success: true, status: requiresApproval ? 'PENDING_APPROVAL' : 'ACTIVE', requiresApproval,
      applicationReference, memberIdNumber, member, workflow,
      message: requiresApproval ? `Application submitted successfully. Reference: ${applicationReference}. It will appear in the approval queue.` : 'Membership created successfully.',
    });
  } catch (error: any) {
    console.error('[Public membership registration] PostgreSQL write failed:', error);
    return res.status(500).json({ error: 'Your registration could not be saved. Please try again or contact the church office.' });
  }
});

// Public application status lookup reads the same PostgreSQL workflow queue.
router.get('/application-status/:ref', async (req: Request, res: Response) => {
  const ref = String(req.params.ref || '').trim();
  if (!ref) return res.status(400).json({ error: 'Application reference code is required.' });
  try {
    const wf = await findMembershipApplication(ref);
    if (!wf) return res.status(404).json({ success: false, found: false, message: 'No matching membership application was found.' });
    return res.json({
      success: true, found: true, reference: wf.requestCode, status: wf.status,
      applicantName: wf.requesterName, applicantEmail: wf.requesterEmail, applicantPhone: wf.requesterPhone,
      branchName: wf.branchName, submittedDate: wf.submittedDate, currentStep: wf.currentStep,
      approvedAt: wf.approvedAt, approvedBy: wf.approvedBy, rejectedReason: wf.rejectedReason,
      comments: wf.decisionNotes || wf.comments, details: wf.details,
    });
  } catch (error) {
    console.error('[Application status] PostgreSQL read failed:', error);
    return res.status(500).json({ error: 'Application status is temporarily unavailable.' });
  }
});

// Approval queue and decisions use PostgreSQL workflow_requests, not the legacy JSON store.
router.get('/approvals', authenticateToken, requirePermission('workflows.read'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  if (!isValidUUID(user.tenantId)) return res.status(400).json({ error: 'A valid tenant assignment is required.' });
  try {
    const branchIds = [...new Set([...(user.branchIds || []).filter(isValidUUID), ...(isValidUUID(user.branchId) ? [user.branchId] : [])])];
    const workflows = await listMembershipApplications({ tenantId: user.tenantId, branchIds, allBranches: (user.branchIds || []).includes('*') });
    const safeWorkflows = workflows.map(workflow => sanitizeMembershipWorkflowForUser(workflow, user));
    return res.json({ success: true, workflows: safeWorkflows, pendingUsers: [], totalPending: safeWorkflows.filter(w => w.status === 'Pending').length });
  } catch (error) {
    console.error('[Membership approvals] PostgreSQL read failed:', error);
    return res.status(500).json({ error: 'The membership approval queue could not be loaded.' });
  }
});

router.post('/approvals/:id/decision', authenticateToken, requirePermission('workflows.manage'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const id = req.params.id;
  const { decision, rejectionReason, adminNotes } = req.body || {};
  if (decision !== 'Approve' && decision !== 'Reject') return res.status(400).json({ error: 'Decision must be "Approve" or "Reject".' });
  if (!isValidUUID(user.tenantId)) return res.status(400).json({ error: 'A valid tenant assignment is required.' });
  try {
    const branchIds = [...new Set([...(user.branchIds || []).filter(isValidUUID), ...(isValidUUID(user.branchId) ? [user.branchId] : [])])];
    const workflow = await getMembershipApplication(id, user.tenantId, branchIds, (user.branchIds || []).includes('*'));
    if (!workflow) return res.status(404).json({ error: 'Application workflow not found.' });
    if (workflow.status !== 'Pending') return res.status(409).json({ error: 'This application has already been decided.' });

    if (decision === 'Approve') {
      const result = await approveMembershipApplication({
        id,
        tenantId: user.tenantId,
        approvedBy: user.name || user.email || user.id,
        decisionNotes: adminNotes || 'Approved by church administration',
      });
      return res.json({
        success: true,
        status: 'APPROVED',
        workflow: result.workflow,
        memberId: result.memberId,
        message: 'Applicant approved and PostgreSQL member record created successfully.',
      });
    }

    const saved = await saveMembershipDecision({
      id,
      tenantId: user.tenantId,
      status: 'Rejected',
      approvedBy: user.name || user.email || user.id,
      rejectedReason: rejectionReason || 'Application declined by church administration',
      decisionNotes: adminNotes || 'Rejected during administrative review',
    });
    if (!saved) return res.status(409).json({ error: 'The application was changed by another reviewer. Refresh the approval queue.' });
    return res.json({ success: true, status: 'REJECTED', workflow: saved, message: 'Applicant rejected.' });
  } catch (error: any) {
    console.error('[Membership decision] PostgreSQL operation failed:', error);
    const message = error?.message || 'The membership decision could not be saved.';
    const status = /already been decided|not found|already exists/i.test(message) ? 409 : 500;
    return res.status(status).json({ error: message });
  }
});

// 1F. SEED DEMO USERS ENDPOINT (Disabled in production: returns current users without injecting fake data)
router.post('/seed-demo-users', authenticateToken, requirePermission('system.manage'), sensitiveAdminLimiter, (req: AuthenticatedRequest, res: Response) => {
  return res.json({
    success: true,
    message: 'Demo user seeding is disabled. Database is authoritative.',
  });
});

// 3. STAFF TWO-FACTOR AUTHENTICATION (Supabase Auth MFA & RFC 6238 TOTP Engine)
router.post('/staff/mfa/challenge', mfaVerifyLimiter, async (req: Request, res: Response) => {
  const { factorId } = req.body || {};
  const challengeId = `chal_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  return res.status(200).json({
    success: true,
    challengeId,
    factorId: factorId || 'totp',
    message: 'New two-factor authentication challenge generated.',
  });
});

router.post('/staff/mfa/verify', mfaVerifyLimiter, async (req: Request, res: Response) => {
  const { code, factorId, challengeId, email, sessionToken } = req.body || {};
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '').trim() || sessionToken;

  if (!code || String(code).trim().length !== 6) {
    return sendAuthError(res, 400, 'INVALID_MFA_CODE', 'Valid 6-digit TOTP verification code is required.');
  }

  let decodedToken: any = null;
  if (token) {
    try {
      decodedToken = jwt.verify(token, JWT_SECRET);
    } catch (jwtErr: any) {
      if (jwtErr?.name === 'TokenExpiredError') {
        return sendAuthError(
          res,
          401,
          'SESSION_EXPIRED',
          'Your login session has expired. Please return to the login screen and sign in again.'
        );
      }
      return sendAuthError(
        res,
        401,
        'SESSION_EXPIRED',
        'Invalid or expired session token. Please return to the login screen and sign in again.'
      );
    }
  }

  const effectiveChallengeId = challengeId || decodedToken?.challengeId || decodedToken?.enrollmentId;
  const pendingChallenge = effectiveChallengeId ? pendingStaffMfaChallenges.get(effectiveChallengeId) : null;
  const pendingEnrollment = effectiveChallengeId ? pendingStaffMfaEnrollments.get(effectiveChallengeId) : null;

  const targetUserId = pendingChallenge?.userId || pendingEnrollment?.userId || decodedToken?.userId || decodedToken?.sub;
  const targetEmail = (
    pendingChallenge?.email ||
    pendingEnrollment?.email ||
    decodedToken?.email ||
    email ||
    ''
  )
    .trim()
    .toLowerCase();

  if (!targetUserId && !targetEmail) {
    return sendAuthError(
      res,
      401,
      'SESSION_EXPIRED',
      'Your login session has expired. Please return to the login screen and sign in again.'
    );
  }

  const admin = getAdminClient();
  let authUser: any = null;
  try {
    if (targetUserId && isValidUUID(targetUserId)) {
      const { data: uData } = await admin.auth.admin.getUserById(targetUserId);
      authUser = uData?.user || null;
    }
    if (!authUser && targetEmail) {
      const { data: prof } = await admin.from('profiles').select('id').ilike('email', targetEmail).maybeSingle();
      if (prof?.id) {
        const { data: uData } = await admin.auth.admin.getUserById(prof.id);
        authUser = uData?.user || null;
      }
    }
  } catch {}

  if (!authUser) {
    return sendAuthError(
      res,
      401,
      'SESSION_EXPIRED',
      'Your login session has expired. Please return to the login screen and sign in again.'
    );
  }

  let verified = false;
  let isEnrollmentFlow = false;

  if (pendingEnrollment) {
    isEnrollmentFlow = true;

    if (pendingEnrollment.expiresAt < Date.now()) {
      pendingStaffMfaEnrollments.delete(effectiveChallengeId);
      pendingStaffMfaChallenges.delete(effectiveChallengeId);
      return sendAuthError(
        res,
        401,
        'SESSION_EXPIRED',
        'Enrollment session has expired. Please sign in again to restart two-factor enrollment.'
      );
    }

    if (pendingEnrollment.userId !== authUser.id && pendingEnrollment.email !== (authUser.email || '').toLowerCase()) {
      return sendAuthError(res, 403, 'FORBIDDEN', 'Security challenge mismatch. Please restart enrollment.');
    }

    if (isSupabaseConfigured) {
      if (!pendingEnrollment.factorId || !effectiveChallengeId) {
        return sendAuthError(res, 503, 'MFA_PROVIDER_STATE_UNAVAILABLE', 'A Supabase MFA factor challenge is required to complete enrollment. Restart enrollment or contact an administrator.');
      }
      try {
        const { data: verData, error: verErr } = await admin.auth.mfa.verify({
          factorId: pendingEnrollment.factorId,
          challengeId: effectiveChallengeId,
          code: String(code).trim(),
        });
        if (verErr || !verData) {
          return sendAuthError(res, 401, 'INVALID_MFA_CODE', 'The Supabase authenticator challenge was rejected.');
        }
        verified = true;
      } catch (error) {
        console.error('[Auth] Supabase MFA enrollment verification failed:', error);
        return sendAuthError(res, 502, 'MFA_VERIFICATION_UNAVAILABLE', 'Supabase MFA verification could not be completed. Retry enrollment.');
      }
    } else {
      verified = verifyTOTPCode(pendingEnrollment.secret, String(code).trim());
    }

    if (!verified) {
      securityAuditService.recordEvent({
        req,
        eventType: 'MFA_VERIFICATION_FAILURE',
        action: 'Staff MFA Verification Failed',
        module: 'Authentication & Security',
        details: `Incorrect TOTP code submitted during MFA enrollment for ${authUser.email}`,
        actorId: authUser.id,
        actorEmail: authUser.email,
        outcome: 'FAILURE',
        severity: 'MEDIUM',
      });
      return sendAuthError(
        res,
        400,
        'INVALID_MFA_CODE',
        'Incorrect verification code. Please check your authenticator app and try again.'
      );
    }

    pendingStaffMfaEnrollments.delete(effectiveChallengeId);
  } else {
    if (isSupabaseConfigured) {
      if (!factorId || !effectiveChallengeId) {
        return sendAuthError(res, 403, 'MFA_FACTOR_REQUIRED', 'A Supabase MFA factor challenge is required. Sign in again to create a new challenge.');
      }
      try {
        const { data: verData, error: verErr } = await admin.auth.mfa.verify({
          factorId,
          challengeId: effectiveChallengeId,
          code: String(code).trim(),
        });
        if (verErr || !verData) {
          return sendAuthError(res, 401, 'INVALID_MFA_CODE', 'The Supabase authenticator challenge was rejected.');
        }
        verified = true;
      } catch (error) {
        console.error('[Auth] Supabase MFA verification failed:', error);
        return sendAuthError(res, 502, 'MFA_VERIFICATION_UNAVAILABLE', 'Supabase MFA verification could not be completed. Retry sign-in.');
      }
    } else {
      const existingSecret =
        authUser.app_metadata?.totp_secret ||
        (db.getState().systemUsers || []).find((u) => u.id === authUser.id)?.totpSecret;
      if (!existingSecret) {
        return sendAuthError(res, 400, 'MFA_NOT_ENROLLED', 'Two-factor authentication is not enrolled for this account. Please sign in again to complete enrollment.');
      }
      verified = verifyTOTPCode(existingSecret, String(code).trim());
    }

    if (!verified) {
      securityAuditService.recordEvent({
        req,
        eventType: 'MFA_VERIFICATION_FAILURE',
        action: 'Staff MFA Verification Failed',
        module: 'Authentication & Security',
        details: `Incorrect TOTP code submitted during staff login challenge for ${authUser.email}`,
        actorId: authUser.id,
        actorEmail: authUser.email,
        outcome: 'FAILURE',
        severity: 'MEDIUM',
      });
      return sendAuthError(
        res,
        400,
        'INVALID_MFA_CODE',
        'Incorrect verification code. Please check your authenticator app and try again.'
      );
    }
  }

  const now = new Date().toISOString();
  const updatedAppMeta: Record<string, any> = {
    ...(authUser.app_metadata || {}),
    mfa_enabled: true,
    aal: 'aal2',
    last_max_auth_at: now,
  };
  // Supabase Auth owns the MFA factor and verification state. Never copy the
  // authenticator secret into app metadata or the legacy JSON account mirror.
  const { data: updatedUserRes, error: metadataUpdateError } = await admin.auth.admin.updateUserById(authUser.id, {
    app_metadata: updatedAppMeta,
  });
  if (metadataUpdateError || !updatedUserRes?.user) {
    console.error('[Auth] Failed to persist authoritative MFA verification state:', metadataUpdateError);
    return sendAuthError(res, 502, 'MFA_STATE_UPDATE_FAILED', 'MFA verification succeeded, but the account security state could not be saved. Retry sign-in.');
  }

  const finalAuthUser = updatedUserRes.user;

  db.addAuditLog(
    isEnrollmentFlow ? 'Staff MFA Enrolled and Verified (AAL2)' : 'Staff MFA Verified (AAL2)',
    'Authentication & Security',
    `Staff member ${authUser.email} successfully completed ${isEnrollmentFlow ? 'MFA enrollment' : 'TOTP challenge'}. Session escalated to AAL2.`,
    authUser.email || targetEmail,
    req.ip
  );

  // Refresh the pending Supabase session so the newly returned access_token carries aal: 'aal2' in app_metadata
  let finalAccessToken = pendingChallenge?.supabaseAccessToken || '';
  let finalRefreshToken = pendingChallenge?.supabaseRefreshToken || '';
  let finalSessionObj = pendingChallenge?.supabaseSession || null;

  if (finalRefreshToken) {
    try {
      const refreshClient = createIsolatedAuthClient();
      const { data: refreshed } = await refreshClient.auth.refreshSession({
        refresh_token: finalRefreshToken,
      });
      if (refreshed?.session) {
        finalAccessToken = refreshed.session.access_token;
        finalRefreshToken = refreshed.session.refresh_token;
        finalSessionObj = refreshed.session;
      }
    } catch {}
  }

  if (effectiveChallengeId) {
    pendingStaffMfaChallenges.delete(effectiveChallengeId);
  }

  const resolvedUser = await buildAuthoritativeSessionFromAuthUser(finalAuthUser, {
    enforceActiveStatus: true,
  });
  resolvedUser.aal = 'aal2';

  if (finalAccessToken) {
    securityAuditService.registerSession({
      rawAccessToken: finalAccessToken,
      rawRefreshToken: finalRefreshToken,
      userId: resolvedUser.id,
      userEmail: resolvedUser.email,
      userName: resolvedUser.name,
      userRole: resolvedUser.role,
      tenantId: resolvedUser.tenantId,
      branchId: resolvedUser.branchId,
      req,
      expiresInSeconds: finalSessionObj?.expires_in,
      aal: 'aal2',
      mfaVerified: true,
    });

    setAuthSessionCookies(res, {
      accessToken: finalAccessToken,
      refreshToken: finalRefreshToken,
      expiresInSeconds: finalSessionObj?.expires_in,
    });
  }

  securityAuditService.recordEvent({
    req,
    eventType: isEnrollmentFlow ? 'MFA_ENROLLED' : 'MFA_VERIFICATION_SUCCESS',
    action: isEnrollmentFlow ? 'Staff MFA Enrolled and Verified (AAL2)' : 'Staff MFA Verified (AAL2)',
    module: 'Authentication & Security',
    details: `Staff member ${resolvedUser.email} successfully completed ${isEnrollmentFlow ? 'MFA enrollment' : 'TOTP challenge'}. Session escalated to AAL2.`,
    actorId: resolvedUser.id,
    actorEmail: resolvedUser.email,
    actorName: resolvedUser.name,
    actorRole: resolvedUser.role,
    outcome: 'SUCCESS',
    severity: 'LOW',
    sessionId: finalAccessToken,
  });

  return res.status(200).json({
    success: true,
    aal: 'aal2',
    token: finalAccessToken,
    refreshToken: finalRefreshToken,
    session: finalSessionObj
      ? {
          access_token: finalSessionObj.access_token,
          refresh_token: finalSessionObj.refresh_token,
          expires_in: finalSessionObj.expires_in,
          expires_at: finalSessionObj.expires_at,
          token_type: 'bearer',
        }
      : undefined,
    user: resolvedUser,
    profile: resolvedUser,
    message: isEnrollmentFlow
      ? 'Two-factor authentication successfully configured and verified. Welcome to Staff Portal.'
      : 'Two-factor authentication verified. Welcome to Staff Portal.',
  });
});

router.post('/staff/reauth', mfaVerifyLimiter, async (req: Request, res: Response) => {
  const { email, password, code } = req.body || {};
  const inputEmail = (email || '').trim().toLowerCase();

  if (!inputEmail || !password || !code) {
    return sendAuthError(
      res,
      400,
      'MISSING_FIELDS',
      'Staff email, password, and 6-digit 2FA code are required for 30-day security re-authentication.'
    );
  }

  try {
    const authClient = createIsolatedAuthClient();
    const { data, error } = await authClient.auth.signInWithPassword({
      email: inputEmail,
      password,
    });

    if (error || !data?.user || !data?.session) {
      return sendAuthError(res, 401, 'INVALID_CREDENTIALS', 'Invalid password. Re-authentication failed.');
    }

    const authUser = data.user;
    const rawSession = data.session;
    const resolvedUser = await buildAuthoritativeSessionFromAuthUser(authUser, {
      enforceActiveStatus: true,
    });

    if (!isStaffRole(resolvedUser.role)) {
      revokeSessionToken(rawSession.access_token);
      return sendAuthError(res, 403, 'FORBIDDEN', 'Access denied: not an authorized staff account.');
    }

    const admin = getAdminClient();
    const { data: factorsData, error: factorsError } = await admin.auth.admin.mfa.listFactors({ userId: authUser.id });
    if (factorsError) {
      console.error('[Auth] Supabase MFA factor lookup failed during re-auth:', factorsError);
      return sendAuthError(res, 502, 'MFA_VERIFICATION_UNAVAILABLE', 'The authoritative MFA provider could not be reached. Retry or contact an administrator.');
    }

    const verifiedTotpFactor = factorsData?.factors?.find((factor: any) => factor.factor_type === 'totp' && factor.status === 'verified');
    if (!verifiedTotpFactor) {
      return sendAuthError(
        res,
        403,
        'MFA_NOT_ENROLLED',
        'A verified Supabase authenticator factor is required. Legacy local TOTP secrets cannot authorize re-authentication.'
      );
    }

    const { data: challengeData, error: challengeError } = await authClient.auth.mfa.challenge({
      factorId: verifiedTotpFactor.id,
    });
    if (challengeError || !challengeData?.id) {
      console.error('[Auth] Supabase MFA challenge failed during re-auth:', challengeError);
      return sendAuthError(res, 502, 'MFA_CHALLENGE_FAILED', 'The authoritative MFA challenge could not be created. Retry or contact an administrator.');
    }

    const { error: verifyError } = await authClient.auth.mfa.verify({
      factorId: verifiedTotpFactor.id,
      challengeId: challengeData.id,
      code: String(code).trim(),
    });
    if (verifyError) {
      return sendAuthError(res, 401, 'INVALID_MFA_CODE', 'The authenticator code was rejected. Re-authentication failed.');
    }

    const now = new Date().toISOString();
    const { data: updatedAuth, error: updateError } = await admin.auth.admin.updateUserById(authUser.id, {
      app_metadata: {
        ...(authUser.app_metadata || {}),
        mfa_enabled: true,
        aal: 'aal2',
        last_max_auth_at: now,
      },
    });
    if (updateError || !updatedAuth?.user) {
      console.error('[Auth] Supabase MFA metadata update failed during re-auth:', updateError);
      return sendAuthError(res, 502, 'MFA_STATE_UPDATE_FAILED', 'MFA verification succeeded but the security state could not be updated. Retry or contact an administrator.');
    }

    resolvedUser.aal = 'aal2';
    resolvedUser.last_max_auth_at = now;

    db.addAuditLog(
      'Staff 30-Day Re-Auth Verified',
      'Authentication & Security',
      `Staff member ${resolvedUser.email} successfully completed 30-day security re-authentication (Password + TOTP).`,
      resolvedUser.email
    );

    return res.status(200).json({
      success: true,
      token: rawSession.access_token,
      refreshToken: rawSession.refresh_token,
      session: {
        access_token: rawSession.access_token,
        refresh_token: rawSession.refresh_token,
        expires_in: rawSession.expires_in,
        expires_at: rawSession.expires_at,
        token_type: 'bearer',
      },
      user: resolvedUser,
      profile: resolvedUser,
      message: '30-day security re-authentication verified successfully.',
    });
  } catch (err: any) {
    if (err instanceof AuthError) {
      return sendAuthError(res, err.statusCode, err.code, err.message);
    }
    return sendAuthError(res, 401, 'INVALID_CREDENTIALS', err?.message || 'Re-authentication failed.');
  }
});

router.post('/users/:id/reset-mfa', authenticateToken, requirePermission('users.manage'), async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const targetId = req.params.id;

  if (!isValidUUID(targetId)) {
    return sendAuthError(res, 400, 'INVALID_USER_ID', 'A valid Supabase Auth user ID is required.');
  }

  const admin = getAdminClient();
  try {
    const { data: existingAuth, error: userError } = await admin.auth.admin.getUserById(targetId);
    if (userError || !existingAuth?.user) {
      return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target Supabase Auth user not found.');
    }

    const { data: factors, error: factorsError } = await admin.auth.admin.mfa.listFactors({ userId: targetId });
    if (factorsError) throw factorsError;
    if (factors?.factors) {
      for (const factor of factors.factors) {
        const { error: deleteError } = await admin.auth.admin.mfa.deleteFactor({ id: factor.id, userId: targetId });
        if (deleteError) throw deleteError;
      }
    }

    const { error: updateError } = await admin.auth.admin.updateUserById(targetId, {
      app_metadata: {
        ...(existingAuth.user.app_metadata || {}),
        mfa_enabled: false,
        aal: 'aal1',
      },
    });
    if (updateError) throw updateError;
  } catch (error) {
    console.error('[Auth] Supabase MFA reset failed:', error);
    return sendAuthError(res, 502, 'MFA_RESET_FAILED', 'Supabase MFA reset did not complete. Retry or contact an administrator.');
  }

  db.addAuditLog(
    'Staff MFA Factor Reset',
    'Security & RBAC',
    `Administrator ${operator.name} reset 2FA/MFA factors for Supabase user ${targetId}`,
    operator.name
  );

  return res.status(200).json({
    success: true,
    message: 'MFA factors have been reset. The staff member must enroll again on next login.',
  });
});

// 4. GET ALL SYSTEM USERS (Authoritative profiles merged with local metadata, Tenant Isolated, users.read)
router.get('/users', authenticateToken, requirePermission('users.read'), async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const admin = getAdminClient();

  let sbProfiles: any[] = [];
  let authUsersMap = new Map<string, any>();
  try {
    const [{ data: pList }, { data: uList }] = await Promise.all([
      admin.from('profiles').select('*'),
      admin.auth.admin.listUsers(),
    ]);
    if (Array.isArray(pList)) sbProfiles = pList;
    if (Array.isArray(uList?.users)) {
      for (const u of uList.users) {
        authUsersMap.set(u.id, u);
      }
    }
  } catch {}

  const state = db.getState();
  const localUsers = state.systemUsers || [];

  // Sync authoritative Supabase profiles into systemUsers list
  for (const prof of sbProfiles) {
    const authU = authUsersMap.get(prof.id);
    const appMeta = authU?.app_metadata || {};
    const mfaEnabled = Boolean(prof.mfa_enabled ?? appMeta.mfa_enabled ?? false);
    const mfaEnrolled = Boolean(appMeta.totp_secret || prof.totp_secret || false);
    const mustChangePassword = Boolean(prof.must_change_password ?? appMeta.must_change_password ?? false);
    const additionalRoles = Array.isArray(appMeta.additional_roles)
      ? appMeta.additional_roles.map((r: string) => normalizeUserRole(r))
      : [];
    const primaryRole = normalizeUserRole(prof.role);
    const allRoles = Array.from(new Set([primaryRole, ...additionalRoles]));

    const existingIdx = localUsers.findIndex(
      (u) => u.id === prof.id || (prof.email && u.email.toLowerCase() === prof.email.toLowerCase())
    );
    const existingRecord = existingIdx >= 0 ? localUsers[existingIdx] : undefined;

    const assignedCampuses: string[] = Array.isArray(appMeta.assigned_campuses) && appMeta.assigned_campuses.length > 0
      ? appMeta.assigned_campuses
      : existingRecord?.assignedCampuses && existingRecord.assignedCampuses.length > 0
        ? existingRecord.assignedCampuses
        : [appMeta.branch_name || existingRecord?.branchName || 'Headquarters Campus'];

    const branchIds: string[] = Array.isArray(appMeta.branch_ids) && appMeta.branch_ids.length > 0
      ? appMeta.branch_ids
      : existingRecord?.branchIds && existingRecord.branchIds.length > 0
        ? existingRecord.branchIds
        : [prof.branch_id || DEFAULT_HQ_BRANCH_UUID];

    const computed = computeEffectivePermissions(
      primaryRole,
      additionalRoles,
      Array.isArray(appMeta.denied_permissions) ? appMeta.denied_permissions : existingRecord?.deniedPermissions
    );

    const syncedUser: SystemUser = {
      ...(existingRecord || {}),
      id: prof.id,
      tenantId: prof.tenant_id || DEFAULT_TENANT_UUID,
      name: prof.full_name || prof.name || (prof.email ? prof.email.split('@')[0] : 'Staff User'),
      email: (prof.email || '').toLowerCase(),
      phone: prof.phone || existingRecord?.phone || undefined,
      role: computed.primaryRole,
      primaryRole: computed.primaryRole,
      additionalRoles: computed.additionalRoles,
      roles: computed.allRoles,
      userRoles: computed.userRoles,
      permissions: computed.effectivePermissions,
      effectivePermissions: computed.effectivePermissions,
      deniedPermissions: computed.deniedPermissions,
      branchId: prof.branch_id || DEFAULT_HQ_BRANCH_UUID,
      branchName: appMeta.branch_name || existingRecord?.branchName || assignedCampuses[0] || 'Headquarters Campus',
      branchIds,
      assignedCampuses,
      status: normalizeAccountStatus(prof.status || appMeta.status || existingRecord?.status || 'Active'),
      isMfaEnabled: mfaEnabled,
      mfaEnabled,
      mfa_enabled: mfaEnabled,
      mfaEnrolled,
      mfa_enrolled: mfaEnrolled,
      must_change_password: mustChangePassword,
      mustChangePassword,
      approvalRoleLevel: appMeta.approval_role_level || existingRecord?.approvalRoleLevel || 'Senior Approver',
      approvalLimit: appMeta.approval_limit ?? existingRecord?.approvalLimit ?? (primaryRole === 'REGULAR_MEMBER' ? 0 : 50000),
      allowedApprovalTypes: Array.isArray(appMeta.allowed_approval_types)
        ? appMeta.allowed_approval_types
        : existingRecord?.allowedApprovalTypes || ['Budget Requests', 'Purchase Vouchers', 'Event Grants'],
      notes: appMeta.notes ?? existingRecord?.notes,
      password_reset_at: appMeta.password_reset_at || existingRecord?.password_reset_at,
      password_changed_at: appMeta.password_changed_at || existingRecord?.password_changed_at,
      temp_password_expires_at: appMeta.temp_password_expires_at || existingRecord?.temp_password_expires_at,
      session_revoked_at: appMeta.session_revoked_at || existingRecord?.session_revoked_at,
      lastLogin: authU?.last_sign_in_at || existingRecord?.lastLogin || 'Never',
    };
    if (existingIdx >= 0) {
      localUsers[existingIdx] = syncedUser;
    } else {
      localUsers.push(syncedUser);
    }
  }

  let users = localUsers.filter((u: any) => {
    if (operator.role === 'SYSTEM_ADMIN' || (operator.roles || []).includes('SYSTEM_ADMIN')) return true;
    return !u.tenantId || u.tenantId === operator.tenantId || u.tenantId === 'tenant-grace-main';
  });

  const sanitized = users.map((u: any) => {
    const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safe } = u;
    const computed = computeEffectivePermissions(
      safe.role || 'REGULAR_MEMBER',
      safe.additionalRoles || [],
      safe.deniedPermissions || []
    );
    return {
      ...safe,
      role: computed.primaryRole,
      primaryRole: computed.primaryRole,
      additionalRoles: computed.additionalRoles,
      roles: computed.allRoles,
      userRoles: computed.userRoles,
      permissions: computed.effectivePermissions,
      effectivePermissions: computed.effectivePermissions,
      deniedPermissions: computed.deniedPermissions,
    };
  });

  return res.status(200).json(sanitized);
});

// Helper to generate a unique, cryptographically strong temporary password (e.g. CMMS-8fK2!mQ7)
export function generateSecureTempPassword(): string {
  const uppers = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lowers = 'abcdefghijkmnpqrstuvwxyz';
  const digits = '23456789';
  const specials = '!@#$%^&*';
  const allChars = uppers + lowers + digits + specials;

  const chars: string[] = [
    uppers[crypto.randomInt(0, uppers.length)],
    lowers[crypto.randomInt(0, lowers.length)],
    digits[crypto.randomInt(0, digits.length)],
    specials[crypto.randomInt(0, specials.length)],
  ];

  for (let i = 0; i < 6; i++) {
    chars.push(allChars[crypto.randomInt(0, allChars.length)]);
  }

  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    const temp = chars[i];
    chars[i] = chars[j];
    chars[j] = temp;
  }

  return `CMMS-${chars.join('')}`;
}

// Helper to resolve a target user from local state or authoritative Supabase profiles
async function resolveTargetSystemUser(targetUserId: string, fallbackEmail?: string): Promise<{ user: SystemUser | null; sbProfile: any }> {
  const state = db.getState();
  const adminClient = getAdminClient();
  const cleanEmail = fallbackEmail ? String(fallbackEmail).trim().toLowerCase() : '';

  let user = (state.systemUsers || []).find(
    (u) =>
      u.id === targetUserId ||
      u.email.toLowerCase() === targetUserId.toLowerCase() ||
      (cleanEmail && u.email.toLowerCase() === cleanEmail)
  ) || null;

  let sbProfile: any = null;
  try {
    if (isValidUUID(targetUserId)) {
      const { data } = await adminClient.from('profiles').select('*').eq('id', targetUserId).maybeSingle();
      sbProfile = data;
    }
    if (!sbProfile && (cleanEmail || targetUserId.includes('@') || user?.email)) {
      const lookupEmail = cleanEmail || (targetUserId.includes('@') ? targetUserId.toLowerCase() : user!.email.toLowerCase());
      const { data } = await adminClient.from('profiles').select('*').ilike('email', lookupEmail).maybeSingle();
      sbProfile = data;
    }
  } catch {}

  if (!user && sbProfile) {
    user = {
      id: sbProfile.id,
      tenantId: sbProfile.tenant_id || DEFAULT_TENANT_UUID,
      name: sbProfile.full_name || sbProfile.email.split('@')[0],
      email: sbProfile.email.toLowerCase(),
      phone: sbProfile.phone || undefined,
      role: normalizeUserRole(sbProfile.role),
      branchId: sbProfile.branch_id || DEFAULT_HQ_BRANCH_UUID,
      branchName: 'Headquarters Campus',
      branchIds: [sbProfile.branch_id || DEFAULT_HQ_BRANCH_UUID],
      assignedCampuses: ['Headquarters Campus'],
      status: normalizeAccountStatus(sbProfile.status),
      lastLogin: 'Never',
    };
    state.systemUsers.push(user);
  }

  return { user, sbProfile };
}

// 5. CREATE SYSTEM USER (users.manage) - Creates authoritative Supabase auth.users + profiles row
router.post('/users', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const newUser = req.body || {};
  if (!newUser.name || !newUser.email) {
    return sendAuthError(res, 400, 'MISSING_FIELDS', 'Name and email are required.');
  }

  const normalizedEmail = String(newUser.email).toLowerCase().trim();
  const adminClient = getAdminClient();

  // Check if user already exists in profiles
  try {
    const { data: existingProf } = await adminClient
      .from('profiles')
      .select('id, email')
      .ilike('email', normalizedEmail)
      .maybeSingle();
    if (existingProf) {
      return sendAuthError(res, 409, 'USER_EXISTS', 'A user account with this email already exists.');
    }
  } catch {}

  const tempPassword =
    newUser.temporaryPassword && String(newUser.temporaryPassword).trim()
      ? String(newUser.temporaryPassword).trim()
      : generateSecureTempPassword();

  const now = new Date();
  const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();
  const normalizedRole = normalizeUserRole(newUser.role || 'MINISTRY_LEADER');
  const additionalRoles: UserRole[] = Array.isArray(newUser.additionalRoles)
    ? Array.from(new Set(newUser.additionalRoles.map((r: string) => normalizeUserRole(r)).filter((r: UserRole) => r !== normalizedRole)))
    : [];
  const allRoles: UserRole[] = [normalizedRole, ...additionalRoles];

  // Privilege Escalation Check on User Creation: Non-SYSTEM_ADMIN cannot create a user with SYSTEM_ADMIN
  const operatorAllRoles = resolveUserRolesList(operator.role, operator.additionalRoles || operator.roles).allRoles;
  if (!operatorAllRoles.includes('SYSTEM_ADMIN') && allRoles.includes('SYSTEM_ADMIN')) {
    return sendAuthError(
      res,
      403,
      'PRIVILEGE_ESCALATION_FORBIDDEN',
      'Privilege escalation blocked: Only a SYSTEM_ADMIN can assign the SYSTEM_ADMIN role.'
    );
  }

  const computedNewUserRbac = computeEffectivePermissions(normalizedRole, additionalRoles);
  const mfaEnabled = Boolean(newUser.isMfaEnabled ?? newUser.mfaEnabled ?? false);
  const targetTenantId = isValidUUID(operator.tenantId) ? operator.tenantId : DEFAULT_TENANT_UUID;
  let linkedMemberId: string | null = null;
  if (newUser.memberId !== undefined && newUser.memberId !== null && newUser.memberId !== '') {
    if (!isValidUUID(String(newUser.memberId))) {
      return sendAuthError(res, 400, 'INVALID_MEMBER_LINK', 'The member account link must use a valid member UUID.');
    }
    const { data: linkedMember, error: memberLookupError } = await adminClient
      .from('members')
      .select('id')
      .eq('id', String(newUser.memberId))
      .eq('tenant_id', targetTenantId)
      .maybeSingle();
    if (memberLookupError || !linkedMember) {
      return sendAuthError(res, 404, 'MEMBER_NOT_FOUND', 'The selected member does not exist in your tenant. No user account was created.');
    }
    linkedMemberId = linkedMember.id;
  }
  const assignedCampuses: string[] =
    Array.isArray(newUser.assignedCampuses) && newUser.assignedCampuses.length > 0
      ? newUser.assignedCampuses
      : [newUser.branchName || 'Headquarters Campus'];
  const requestedBranch = Array.isArray(newUser.branchIds) ? newUser.branchIds[0] : newUser.branchId;
  const targetBranchUuid = isValidUUID(requestedBranch) ? requestedBranch : DEFAULT_HQ_BRANCH_UUID;
  const branchIds: string[] =
    Array.isArray(newUser.branchIds) && newUser.branchIds.length > 0
      ? newUser.branchIds
      : [targetBranchUuid, ...assignedCampuses];

  let createdUserId = newUser.id && isValidUUID(newUser.id) ? newUser.id : '';

  let createdAuthUser = false;
  try {
    const { data: createdAuth, error: createErr } = await adminClient.auth.admin.createUser({
      email: normalizedEmail,
      password: tempPassword,
      email_confirm: true,
      app_metadata: {
        role: normalizedRole,
        additional_roles: additionalRoles,
        status: normalizeAccountStatus(newUser.status || 'Active'),
        must_change_password: true,
        temp_password_expires_at: expiresAt,
        mfa_enabled: mfaEnabled,
        branch_name: newUser.branchName || assignedCampuses[0] || 'Headquarters Campus',
        branch_ids: branchIds,
        assigned_campuses: assignedCampuses,
        approval_role_level: newUser.approvalRoleLevel || 'Senior Approver',
        approval_limit: newUser.approvalLimit ?? (normalizedRole === 'REGULAR_MEMBER' ? 0 : 50000),
        allowed_approval_types: newUser.allowedApprovalTypes || ['Budget Requests', 'Purchase Vouchers', 'Event Grants'],
        notes: newUser.notes || '',
      },
      user_metadata: {
        name: newUser.name,
        full_name: newUser.name,
        must_change_password: true,
      },
    });

    if (createErr || !createdAuth?.user) {
      throw createErr || new Error('Supabase Auth did not return the created user.');
    }
    createdUserId = createdAuth.user.id;
    createdAuthUser = true;

    const { error: profileError } = await adminClient.from('profiles').upsert({
      id: createdUserId,
      tenant_id: targetTenantId,
      branch_id: targetBranchUuid,
      full_name: newUser.name,
      email: normalizedEmail,
      role: normalizedRole,
      phone: newUser.phone || null,
      status: normalizeAccountStatus(newUser.status || 'Active'),
      ...(linkedMemberId ? { member_id: linkedMemberId } : {}),
    });
    if (profileError) throw profileError;

    const roleAssignments = allRoles.map((assignedRole) => ({
      user_id: createdUserId,
      tenant_id: targetTenantId,
      role: assignedRole,
      is_primary: assignedRole === normalizedRole,
      granted_by: isValidUUID(operator.id) ? operator.id : null,
    }));
    const { error: roleAssignmentError } = await adminClient
      .from('profile_role_assignments')
      .upsert(roleAssignments, { onConflict: 'user_id,tenant_id,role' });
    if (roleAssignmentError) throw roleAssignmentError;

    const validBranchUuids = Array.from(new Set([targetBranchUuid, ...branchIds].filter(isValidUUID)));
    const branchAssignments = validBranchUuids.map((assignedBranchId) => ({
      user_id: createdUserId,
      tenant_id: targetTenantId,
      branch_id: assignedBranchId,
      is_default: assignedBranchId === targetBranchUuid,
      granted_by: isValidUUID(operator.id) ? operator.id : null,
    }));
    const { error: branchAssignmentError } = await adminClient
      .from('profile_branch_assignments')
      .upsert(branchAssignments, { onConflict: 'user_id,tenant_id,branch_id' });
    if (branchAssignmentError) throw branchAssignmentError;
  } catch (sbErr: any) {
    if (createdAuthUser && createdUserId) {
      try {
        const { error: rollbackError } = await adminClient.auth.admin.deleteUser(createdUserId);
        if (rollbackError) {
          console.error('[AUTH] Failed to roll back partially provisioned Supabase user:', rollbackError);
        }
      } catch (rollbackError) {
        console.error('[AUTH] Failed to roll back partially provisioned Supabase user:', rollbackError);
      }
    }
    console.error('[AUTH] Staff account provisioning failed:', sbErr);
    return sendAuthError(
      res,
      502,
      'USER_PROVISIONING_FAILED',
      'The staff account could not be fully provisioned in Supabase. No local account was created; retry after checking the account state.'
    );
  }

  const user: SystemUser = {
    ...newUser,
    id: createdUserId || `usr-${Date.now()}`,
    tenantId: targetTenantId,
    email: normalizedEmail,
    role: computedNewUserRbac.primaryRole,
    primaryRole: computedNewUserRbac.primaryRole,
    additionalRoles: computedNewUserRbac.additionalRoles,
    roles: computedNewUserRbac.allRoles,
    userRoles: computedNewUserRbac.userRoles,
    permissions: computedNewUserRbac.effectivePermissions,
    effectivePermissions: computedNewUserRbac.effectivePermissions,
    deniedPermissions: computedNewUserRbac.deniedPermissions,
    branchId: targetBranchUuid,
    branchName: newUser.branchName || assignedCampuses[0] || 'Headquarters Campus',
    branchIds,
    assignedCampuses,
    status: normalizeAccountStatus(newUser.status || 'Active'),
    lastLogin: 'Never',
    isMfaEnabled: mfaEnabled,
    mfaEnabled,
    mfa_enabled: mfaEnabled,
    must_change_password: true,
    mustChangePassword: true,
    password_changed_at: undefined,
    temp_password_expires_at: expiresAt,
    temporaryPassword: undefined,
  };

  // Supabase Auth and profiles are authoritative. Do not persist a second
  // credential-bearing account record in the legacy JSON store.

  db.addAuditLog(
    'STAFF_ACCOUNT_CREATED',
    'User Management & Security',
    `Provisioned staff account for ${user.email} (${user.name}) with role ${user.role}${additionalRoles.length ? ` + [${additionalRoles.join(', ')}]` : ''} and campuses [${assignedCampuses.join(', ')}] by ${operator.email || operator.name}`,
    operator.email || operator.name
  );
  db.addAuditLog(
    'TEMPORARY_PASSWORD_ASSIGNED',
    'Security & Access',
    `Temporary password assigned to staff account ${user.email} (expires in 24 hours). Mandatory first-login password change enforced.`,
    operator.email || operator.name
  );

  const { password, passwordHash, mfaSecret, totpSecret, ...safeUser } = user as any;
  return res.status(201).json({
    ...safeUser,
    temporaryPassword: tempPassword,
    mustChangePassword: true,
    must_change_password: true,
    temp_password_expires_at: expiresAt,
  });
});

// 5A. UPDATE SYSTEM USER DETAILS, ROLES, STATUS, AND MULTI-CAMPUS ASSIGNMENTS (PUT /api/auth/users/:id)
router.put('/users/:id', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const targetId = req.params.id;
  const payload = req.body || {};

  const { user, sbProfile } = await resolveTargetSystemUser(targetId, payload.email);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user account not found.');
  }

  const access = verifyResourceAccess(user, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const updatedName = payload.name ? String(payload.name).trim() : user.name;
  const updatedEmail = payload.email ? String(payload.email).trim().toLowerCase() : user.email;
  const updatedPhone = payload.phone !== undefined ? String(payload.phone).trim() : user.phone;
  const updatedRole = payload.role ? normalizeUserRole(payload.role) : user.role;
  const updatedAdditionalRoles: UserRole[] = Array.isArray(payload.additionalRoles)
    ? Array.from(new Set(payload.additionalRoles.map((r: string) => normalizeUserRole(r)).filter((r: UserRole) => r !== updatedRole)))
    : (user.additionalRoles || []).filter((r: UserRole) => r !== updatedRole);
  const allRoles: UserRole[] = [updatedRole, ...updatedAdditionalRoles];

  // Enforce backend RBAC privilege escalation & self-modification rules
  if (payload.role !== undefined || payload.additionalRoles !== undefined) {
    const roleSecurityCheck = validateRoleMutationSecurity({
      operator,
      targetUser: user,
      nextPrimaryRole: updatedRole,
      nextAdditionalRoles: updatedAdditionalRoles,
    });
    if (!roleSecurityCheck.valid) {
      return sendAuthError(
        res,
        roleSecurityCheck.statusCode || 403,
        roleSecurityCheck.code || 'PRIVILEGE_ESCALATION_FORBIDDEN',
        roleSecurityCheck.message || 'Forbidden role assignment.'
      );
    }
  }

  const computedUpdatedRbac = computeEffectivePermissions(
    updatedRole,
    updatedAdditionalRoles,
    Array.isArray(payload.deniedPermissions) ? payload.deniedPermissions : user.deniedPermissions
  );
  const updatedStatus = payload.status ? normalizeAccountStatus(payload.status) : user.status;
  const updatedMfa = payload.mfaEnabled !== undefined
    ? Boolean(payload.mfaEnabled)
    : payload.isMfaEnabled !== undefined
      ? Boolean(payload.isMfaEnabled)
      : Boolean(user.mfaEnabled ?? user.isMfaEnabled);

  const updatedCampuses: string[] = Array.isArray(payload.assignedCampuses) && payload.assignedCampuses.length > 0
    ? payload.assignedCampuses
    : user.assignedCampuses && user.assignedCampuses.length > 0
      ? user.assignedCampuses
      : [payload.branchName || user.branchName || 'Headquarters Campus'];

  const updatedBranchName = payload.branchName || updatedCampuses[0] || user.branchName || 'Headquarters Campus';
  const updatedBranchIds: string[] = Array.isArray(payload.branchIds) && payload.branchIds.length > 0
    ? payload.branchIds
    : Array.from(new Set([...(user.branchIds || []), ...updatedCampuses]));

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (!effectiveUuid) {
    return sendAuthError(res, 409, 'AUTHORITATIVE_USER_ID_REQUIRED', 'This account is not linked to a valid Supabase Auth user. Link or reconcile the account before updating it.');
  }

  const admin = getAdminClient();
  const { data: existingAuth, error: getUserError } = await admin.auth.admin.getUserById(effectiveUuid);
  if (getUserError || !existingAuth?.user) {
    console.error('[AUTH] Could not load authoritative staff account for update:', getUserError);
    return sendAuthError(res, 502, 'USER_UPDATE_UNAVAILABLE', 'The authoritative staff account could not be loaded. No account changes were saved.');
  }

  const updateTimestamp = new Date().toISOString();
  const { error: profileUpdateError } = await admin
    .from('profiles')
    .update({
      full_name: updatedName,
      email: updatedEmail,
      phone: updatedPhone || null,
      role: updatedRole,
      status: updatedStatus,
      updated_at: updateTimestamp,
    })
    .eq('id', effectiveUuid);
  if (profileUpdateError) {
    console.error('[AUTH] Staff profile update failed:', profileUpdateError);
    return sendAuthError(res, 502, 'USER_PROFILE_UPDATE_FAILED', 'The staff profile could not be updated. No success was reported.');
  }

  const { error: authUpdateError } = await admin.auth.admin.updateUserById(effectiveUuid, {
    email: updatedEmail,
    app_metadata: {
      ...(existingAuth.user.app_metadata || {}),
      role: updatedRole,
      additional_roles: updatedAdditionalRoles,
      status: updatedStatus,
      mfa_enabled: updatedMfa,
      branch_name: updatedBranchName,
      branch_ids: updatedBranchIds,
      assigned_campuses: updatedCampuses,
      approval_role_level: payload.approvalRoleLevel !== undefined ? payload.approvalRoleLevel : user.approvalRoleLevel,
      approval_limit: payload.approvalLimit !== undefined ? Number(payload.approvalLimit) : user.approvalLimit,
      allowed_approval_types: Array.isArray(payload.allowedApprovalTypes) ? payload.allowedApprovalTypes : user.allowedApprovalTypes,
      notes: payload.notes !== undefined ? payload.notes : user.notes,
      must_change_password: Boolean(payload.must_change_password ?? payload.mustChangePassword ?? user.must_change_password),
      ...(updatedStatus === 'Suspended' || updatedStatus === 'Inactive'
        ? { session_revoked_at: updateTimestamp }
        : {}),
    },
    user_metadata: {
      ...(existingAuth.user.user_metadata || {}),
      name: updatedName,
      full_name: updatedName,
      must_change_password: Boolean(payload.must_change_password ?? payload.mustChangePassword ?? user.must_change_password),
    },
  });
  if (authUpdateError) {
    console.error('[AUTH] Supabase Auth update failed after profile update:', authUpdateError);
    return sendAuthError(res, 502, 'USER_AUTH_UPDATE_FAILED', 'The profile was updated, but Supabase Auth metadata could not be synchronized. The account requires administrator reconciliation before retrying.');
  }

  // Do not mutate or persist the legacy JSON systemUsers mirror. Reloading the
  // account uses the authoritative Supabase profile and Auth metadata.
  if (updatedStatus === 'Suspended' || updatedStatus === 'Inactive') {
    revokeAllUserSessions(effectiveUuid);
  }



  db.addAuditLog({
    action: 'USER_ACCOUNT_UPDATED',
    module: 'User Management & RBAC',
    userEmail: operator.email,
    userName: operator.name,
    userRole: operator.role,
    details: `Administrator ${operator.name} (${operator.email}) updated account ${user.name} (${user.email}): Role=${updatedRole}${updatedAdditionalRoles.length ? `+[${updatedAdditionalRoles.join(',')}]` : ''}, Status=${updatedStatus}, Campuses=[${updatedCampuses.join(', ')}], 2FA=${updatedMfa ? 'Enabled' : 'Disabled'}`,
    ipAddress: getClientIp(req),
  });

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Account and multi-campus access updated for ${user.name}.`,
    user: safeUser,
  });
});

// 5B. ADMIN RESET STAFF PASSWORD (SYSTEM_ADMIN)
async function handleAdminUserResetPassword(req: AuthenticatedRequest, res: Response, targetUserId: string) {
  const operator = req.user;
  if (!operator || !operator.id) {
    return sendAuthError(res, 401, 'UNAUTHORIZED', 'Authentication required.');
  }

  // Authoritative profile is already resolved in req.user by authenticateToken
  const adminProfile = operator;
  const resolvedAdminRole = normalizeUserRole(adminProfile.role);
  if (resolvedAdminRole !== 'SYSTEM_ADMIN') {
    return sendAuthError(
      res,
      403,
      'FORBIDDEN',
      'Administrator permission required: Only SYSTEM_ADMIN can reset user passwords.'
    );
  }

  const adminClient = getAdminClient();
  const fallbackTargetEmail = req.body?.email ? String(req.body.email).trim().toLowerCase() : '';
  const { user: targetUser, sbProfile: sbTargetProfile } = await resolveTargetSystemUser(targetUserId, fallbackTargetEmail);

  if (!targetUser) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target staff user not found.');
  }

  if ((targetUser.status as any) === 'Deleted' || (targetUser as any).isDeleted) {
    return sendAuthError(res, 400, 'ACCOUNT_DELETED', 'Target staff user account is invalid or deleted.');
  }

  // Always generate a cryptographically secure one-time temporary credential on backend unless valid custom override provided
  const tempPassword =
    req.body?.temporaryPassword && String(req.body.temporaryPassword).trim()
      ? String(req.body.temporaryPassword).trim()
      : generateSecureTempPassword();

  if (tempPassword.length < 8) {
    return sendAuthError(res, 400, 'INVALID_PASSWORD', 'Temporary password must be at least 8 characters long.');
  }

  // Store only a bcrypt hash in persistent storage; never store or log the plaintext password
  const hashedPassword = bcrypt.hashSync(tempPassword, 10);
  const now = new Date();
  const nowIso = now.toISOString();
  const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();

  (targetUser as any).password = hashedPassword;
  targetUser.must_change_password = true;
  targetUser.mustChangePassword = true;
  targetUser.password_changed_at = undefined;
  targetUser.password_reset_at = nowIso;
  targetUser.password_reset_by = adminProfile.email || adminProfile.name || adminProfile.id;
  targetUser.session_revoked_at = nowIso;
  (targetUser as any).temp_password_expires_at = expiresAt;
  (targetUser as any).temporary_password_expires_at = expiresAt;
  delete (targetUser as any).temporaryPassword;
  db.persist();

  // Invalidate existing sessions for target user
  revokeAllUserSessions(targetUser.id, now.getTime());

  const effectiveTargetUuid = isValidUUID(targetUser.id)
    ? targetUser.id
    : sbTargetProfile?.id && isValidUUID(sbTargetProfile.id)
      ? sbTargetProfile.id
      : '';

  if (effectiveTargetUuid) {
    revokeAllUserSessions(effectiveTargetUuid, now.getTime());
    try {
      const { data: existingAuth } = await adminClient.auth.admin.getUserById(effectiveTargetUuid);
      await adminClient.auth.admin.updateUserById(effectiveTargetUuid, {
        password: tempPassword,
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          must_change_password: true,
          password_changed_at: null,
          password_reset_at: nowIso,
          password_reset_by: adminProfile.email,
          session_revoked_at: nowIso,
          temp_password_expires_at: expiresAt,
        },
        user_metadata: {
          ...(existingAuth?.user?.user_metadata || {}),
          must_change_password: true,
        },
      });
    } catch {}
  }

  securityAuditService.recordEvent({
    req,
    eventType: 'ADMIN_PASSWORD_RESET',
    action: 'ADMIN_PASSWORD_RESET',
    module: 'Security & Users',
    actorId: adminProfile.id,
    actorEmail: adminProfile.email,
    actorName: adminProfile.name,
    actorRole: resolvedAdminRole,
    targetUserId: targetUser.id,
    targetUserEmail: targetUser.email,
    outcome: 'SUCCESS',
    severity: 'HIGH',
    details: `Administrator ${adminProfile.name} (${adminProfile.email}) reset password for target user ${targetUser.name} (${targetUser.email}, ID: ${targetUser.id}). Active sessions invalidated. Mandatory first-login password change enforced. Temporary credential expires in 24 hours. Campus: ${targetUser.branchName || 'Headquarters'}. Result: SUCCESS`,
  });

  // Return the temporary credential exactly once; never expose it again or log it
  return res.status(200).json({
    success: true,
    temporaryPassword: tempPassword,
    mustChangePassword: true,
    must_change_password: true,
    temp_password_expires_at: expiresAt,
    temporary_password_expires_at: expiresAt,
    user: {
      id: targetUser.id,
      email: targetUser.email,
      name: targetUser.name,
      role: targetUser.role,
      branchName: targetUser.branchName,
      must_change_password: true,
      mustChangePassword: true,
      password_reset_at: nowIso,
    },
    message:
      'Password reset successfully. Give this temporary password to the user securely. User must change this password after signing in.',
  });
}

router.post('/admin/users/:userId/reset-password', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminUserResetPassword(req, res, req.params.userId);
});

router.post('/users/:id/reset-password', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminUserResetPassword(req, res, req.params.id);
});

// Helper to persist user role & campus state to both local mirror and authoritative Supabase profile + app_metadata
async function persistUserRbacState(user: SystemUser, sbProfile: any) {
  const computed = computeEffectivePermissions(
    user.role,
    user.additionalRoles || [],
    user.deniedPermissions || []
  );
  user.role = computed.primaryRole;
  user.primaryRole = computed.primaryRole;
  user.additionalRoles = computed.additionalRoles;
  user.roles = computed.allRoles;
  user.userRoles = computed.userRoles;
  user.permissions = computed.effectivePermissions;
  user.effectivePermissions = computed.effectivePermissions;
  user.deniedPermissions = computed.deniedPermissions;
  db.persist();

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    try {
      const admin = getAdminClient();
      await admin
        .from('profiles')
        .update({
          role: computed.primaryRole,
          ...(user.branchId && isValidUUID(user.branchId) ? { branch_id: user.branchId } : {}),
          updated_at: new Date().toISOString(),
        })
        .eq('id', effectiveUuid);

      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          role: computed.primaryRole,
          additional_roles: computed.additionalRoles,
          branch_name: user.branchName,
          branch_ids: user.branchIds,
          assigned_campuses: user.assignedCampuses,
        },
      });
    } catch {}
  }

  return computed;
}

// 6. UPDATE USER ROLE & ADDITIONAL ROLES (users.manage) - Updates authoritative profiles.role + app_metadata.additional_roles
router.put('/users/:id/role', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const { role, additionalRoles } = req.body || {};
  if (!role) {
    return sendAuthError(res, 400, 'ROLE_REQUIRED', 'Role is required.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const access = verifyResourceAccess(user, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const normalizedRole = normalizeUserRole(role);
  // IMPORTANT: Do NOT overwrite additional roles if additionalRoles is omitted; if setting primary role, preserve existing additional roles (excluding the new primary role)
  const normAdditional: UserRole[] = Array.isArray(additionalRoles)
    ? Array.from(new Set(additionalRoles.map((r: string) => normalizeUserRole(r)).filter((r: UserRole) => r !== normalizedRole)))
    : Array.from(new Set((user.additionalRoles || []).map((r: string) => normalizeUserRole(r)).filter((r: UserRole) => r !== normalizedRole)));

  const securityCheck = validateRoleMutationSecurity({
    operator,
    targetUser: user,
    nextPrimaryRole: normalizedRole,
    nextAdditionalRoles: normAdditional,
  });
  if (!securityCheck.valid) {
    return sendAuthError(
      res,
      securityCheck.statusCode || 403,
      securityCheck.code || 'PRIVILEGE_ESCALATION_FORBIDDEN',
      securityCheck.message || 'Forbidden role modification.'
    );
  }

  user.role = normalizedRole;
  user.additionalRoles = normAdditional;
  await persistUserRbacState(user, sbProfile);

  securityAuditService.recordEvent({
    req,
    eventType: 'ROLE_PERMISSION_CHANGED',
    action: 'USER_ROLE_ASSIGNED',
    module: 'Security & RBAC',
    actorId: operator.id,
    actorEmail: operator.email,
    actorName: operator.name,
    actorRole: operator.role,
    targetUserId: user.id,
    targetUserEmail: user.email,
    outcome: 'SUCCESS',
    severity: 'HIGH',
    details: `Administrator ${operator.name} (${operator.email}) assigned primary role ${user.role}${user.additionalRoles?.length ? ` and additional roles [${user.additionalRoles.join(', ')}]` : ''} to ${user.email}`,
  });

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json(safeUser);
});

// 6A-1. SET PRIMARY ROLE WITHOUT OVERWRITING ADDITIONAL ROLES (PUT /api/auth/users/:id/primary-role)
router.put('/users/:id/primary-role', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const { role, keepPreviousPrimaryAsAdditional } = req.body || {};
  if (!role) {
    return sendAuthError(res, 400, 'ROLE_REQUIRED', 'Primary role is required.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const access = verifyResourceAccess(user, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const previousPrimary = normalizeUserRole(user.role);
  const nextPrimary = normalizeUserRole(role);
  const existingExtras = Array.isArray(user.additionalRoles)
    ? user.additionalRoles.map((r) => normalizeUserRole(r))
    : [];

  let nextAdditional = existingExtras.filter((r) => r !== nextPrimary);
  if (keepPreviousPrimaryAsAdditional && previousPrimary !== nextPrimary && !nextAdditional.includes(previousPrimary)) {
    nextAdditional = [previousPrimary, ...nextAdditional];
  }

  const securityCheck = validateRoleMutationSecurity({
    operator,
    targetUser: user,
    nextPrimaryRole: nextPrimary,
    nextAdditionalRoles: nextAdditional,
  });
  if (!securityCheck.valid) {
    return sendAuthError(
      res,
      securityCheck.statusCode || 403,
      securityCheck.code || 'PRIVILEGE_ESCALATION_FORBIDDEN',
      securityCheck.message || 'Forbidden primary role update.'
    );
  }

  user.role = nextPrimary;
  user.additionalRoles = nextAdditional;
  const computed = await persistUserRbacState(user, sbProfile);

  securityAuditService.recordEvent({
    req,
    eventType: 'ROLE_PERMISSION_CHANGED',
    action: 'USER_PRIMARY_ROLE_UPDATED',
    module: 'Security & RBAC',
    actorId: operator.id,
    actorEmail: operator.email,
    actorName: operator.name,
    actorRole: operator.role,
    targetUserId: user.id,
    targetUserEmail: user.email,
    outcome: 'SUCCESS',
    severity: 'HIGH',
    details: `Administrator ${operator.name} (${operator.email}) set primary role for ${user.email} to ${nextPrimary} (Additional roles: [${nextAdditional.join(', ')}])`,
  });

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Primary role updated to ${nextPrimary} for ${user.name}.`,
    user: safeUser,
    primaryRole: computed.primaryRole,
    additionalRoles: computed.additionalRoles,
    effectivePermissions: computed.effectivePermissions,
  });
});

// 6A-2. ADD ADDITIONAL ROLE WITHOUT OVERWRITING PRIMARY ROLE (POST /api/auth/users/:id/roles)
router.post('/users/:id/roles', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const { role } = req.body || {};
  if (!role) {
    return sendAuthError(res, 400, 'ROLE_REQUIRED', 'Role to add is required.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const access = verifyResourceAccess(user, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const primaryRole = normalizeUserRole(user.role);
  const roleToAdd = normalizeUserRole(role);
  const currentExtras = Array.isArray(user.additionalRoles)
    ? user.additionalRoles.map((r) => normalizeUserRole(r)).filter((r) => r !== primaryRole)
    : [];

  // Do NOT overwrite primaryRole when adding another role
  const nextAdditional =
    roleToAdd === primaryRole || currentExtras.includes(roleToAdd)
      ? currentExtras
      : [...currentExtras, roleToAdd];

  const securityCheck = validateRoleMutationSecurity({
    operator,
    targetUser: user,
    nextPrimaryRole: primaryRole,
    nextAdditionalRoles: nextAdditional,
  });
  if (!securityCheck.valid) {
    return sendAuthError(
      res,
      securityCheck.statusCode || 403,
      securityCheck.code || 'PRIVILEGE_ESCALATION_FORBIDDEN',
      securityCheck.message || 'Forbidden role addition.'
    );
  }

  user.role = primaryRole;
  user.additionalRoles = nextAdditional;
  const computed = await persistUserRbacState(user, sbProfile);

  db.addAuditLog(
    'USER_ADDITIONAL_ROLE_ADDED',
    'Security & RBAC',
    `Administrator ${operator.name} (${operator.email}) added role ${roleToAdd} to ${user.email}. Primary role remains ${primaryRole}. All roles: [${computed.allRoles.join(', ')}]`,
    operator.email || operator.name
  );

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Added role ${roleToAdd} to ${user.name}. Primary role (${primaryRole}) preserved.`,
    user: safeUser,
    primaryRole: computed.primaryRole,
    additionalRoles: computed.additionalRoles,
    roles: computed.allRoles,
    effectivePermissions: computed.effectivePermissions,
  });
});

// 6A-3. REMOVE ADDITIONAL ROLE WITHOUT OVERWRITING PRIMARY ROLE (DELETE /api/auth/users/:id/roles/:role)
router.delete('/users/:id/roles/:role', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id, role } = req.params;
  if (!role) {
    return sendAuthError(res, 400, 'ROLE_REQUIRED', 'Role to remove is required.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const access = verifyResourceAccess(user, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const primaryRole = normalizeUserRole(user.role);
  const roleToRemove = normalizeUserRole(role);
  const currentExtras = Array.isArray(user.additionalRoles)
    ? user.additionalRoles.map((r) => normalizeUserRole(r)).filter((r) => r !== primaryRole)
    : [];

  if (roleToRemove === primaryRole && currentExtras.length === 0) {
    return sendAuthError(
      res,
      400,
      'CANNOT_REMOVE_ONLY_ROLE',
      'Cannot remove the user’s only assigned role. Set a new primary role instead.'
    );
  }

  let nextPrimary = primaryRole;
  let nextAdditional = currentExtras.filter((r) => r !== roleToRemove);
  if (roleToRemove === primaryRole && currentExtras.length > 0) {
    // Promote first additional role to primary if primary was explicitly removed
    nextPrimary = currentExtras[0];
    nextAdditional = currentExtras.slice(1);
  }

  const securityCheck = validateRoleMutationSecurity({
    operator,
    targetUser: user,
    nextPrimaryRole: nextPrimary,
    nextAdditionalRoles: nextAdditional,
  });
  if (!securityCheck.valid) {
    return sendAuthError(
      res,
      securityCheck.statusCode || 403,
      securityCheck.code || 'PRIVILEGE_ESCALATION_FORBIDDEN',
      securityCheck.message || 'Forbidden role removal.'
    );
  }

  user.role = nextPrimary;
  user.additionalRoles = nextAdditional;
  const computed = await persistUserRbacState(user, sbProfile);

  db.addAuditLog(
    'USER_ROLE_REMOVED',
    'Security & RBAC',
    `Administrator ${operator.name} (${operator.email}) removed role ${roleToRemove} from ${user.email}. Remaining roles: [${computed.allRoles.join(', ')}]`,
    operator.email || operator.name
  );

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Removed role ${roleToRemove} from ${user.name}.`,
    user: safeUser,
    primaryRole: computed.primaryRole,
    additionalRoles: computed.additionalRoles,
    roles: computed.allRoles,
    effectivePermissions: computed.effectivePermissions,
  });
});

// 6A-4. VIEW EFFECTIVE PERMISSIONS & RBAC BREAKDOWN (GET /api/auth/users/:id/effective-permissions & GET /api/auth/rbac/roles)
router.get('/rbac/roles', authenticateToken, async (_req: AuthenticatedRequest, res: Response) => {
  return res.status(200).json({
    success: true,
    roles: Object.values(ROLES_CATALOG),
    rolePermissions: ROLE_PERMISSIONS,
  });
});

router.get('/users/:id/effective-permissions', authenticateToken, requirePermission('users.read'), async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { user } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const computed = computeEffectivePermissions(
    user.role,
    user.additionalRoles || [],
    user.deniedPermissions || []
  );

  return res.status(200).json({
    success: true,
    userId: user.id,
    email: user.email,
    name: user.name,
    primaryRole: computed.primaryRole,
    additionalRoles: computed.additionalRoles,
    roles: computed.allRoles,
    userRoles: computed.userRoles,
    effectivePermissions: computed.effectivePermissions,
    deniedPermissions: computed.deniedPermissions,
    roleBreakdown: computed.roleBreakdown,
    assignedCampuses: user.assignedCampuses || [user.branchName || 'Headquarters Campus'],
    primaryCampus: user.branchName || 'Headquarters Campus',
  });
});

// 6B. ASSIGN CAMPUS / MULTIPLE CAMPUSES (PUT /api/auth/users/:id/campuses)
router.put('/users/:id/campuses', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const { branchId, branchName, assignedCampuses, branchIds } = req.body || {};

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const campusesList: string[] = Array.isArray(assignedCampuses) && assignedCampuses.length > 0
    ? Array.from(new Set(assignedCampuses.map((c: string) => String(c).trim()).filter(Boolean)))
    : branchName
      ? [String(branchName).trim()]
      : ['Headquarters Campus'];

  const primaryBranchName = branchName && campusesList.includes(String(branchName).trim())
    ? String(branchName).trim()
    : campusesList[0] || 'Headquarters Campus';
  const effectiveBranchId = branchId && isValidUUID(branchId) ? branchId : user.branchId || DEFAULT_HQ_BRANCH_UUID;
  const effectiveBranchIds: string[] = Array.isArray(branchIds) && branchIds.length > 0
    ? branchIds
    : Array.from(new Set([effectiveBranchId, ...campusesList]));

  user.branchId = effectiveBranchId;
  user.branchName = primaryBranchName;
  user.assignedCampuses = campusesList;
  user.branchIds = effectiveBranchIds;
  await persistUserRbacState(user, sbProfile);

  db.addAuditLog(
    'USER_CAMPUS_ACCESS_UPDATED',
    'Security & RBAC',
    `Administrator ${operator.name} (${operator.email}) updated campus assignments for ${user.email}: Primary="${primaryBranchName}", Authorized Campuses=[${campusesList.join(', ')}]`,
    operator.email || operator.name
  );

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Campus assignments updated for ${user.name}.`,
    user: safeUser,
  });
});

// 6B-2. ASSIGN SINGLE BRANCH/CAMPUS TO USER (POST /api/auth/users/:id/campuses)
router.post('/users/:id/campuses', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const { campus, branchName, setAsPrimary } = req.body || {};
  const campusToAdd = String(campus || branchName || '').trim();
  if (!campusToAdd) {
    return sendAuthError(res, 400, 'CAMPUS_REQUIRED', 'Campus / branch name is required.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const currentCampuses = Array.isArray(user.assignedCampuses) && user.assignedCampuses.length > 0
    ? user.assignedCampuses
    : [user.branchName || 'Headquarters Campus'];

  const updatedCampuses = Array.from(new Set([...currentCampuses, campusToAdd]));
  const nextPrimary = setAsPrimary ? campusToAdd : user.branchName || updatedCampuses[0];

  user.branchName = nextPrimary;
  user.assignedCampuses = updatedCampuses;
  user.branchIds = Array.from(new Set([user.branchId || DEFAULT_HQ_BRANCH_UUID, ...updatedCampuses]));
  await persistUserRbacState(user, sbProfile);

  db.addAuditLog(
    'USER_CAMPUS_ADDED',
    'Security & RBAC',
    `Administrator ${operator.name} (${operator.email}) assigned campus "${campusToAdd}" to ${user.email}. Authorized campuses: [${updatedCampuses.join(', ')}]`,
    operator.email || operator.name
  );

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Assigned campus "${campusToAdd}" to ${user.name}.`,
    user: safeUser,
    assignedCampuses: updatedCampuses,
    primaryCampus: nextPrimary,
  });
});

// 6B-3. REMOVE SINGLE BRANCH/CAMPUS FROM USER (DELETE /api/auth/users/:id/campuses/:campus OR DELETE /api/auth/users/:id/campuses)
router.delete(['/users/:id/campuses/:campus', '/users/:id/campuses'], authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const rawParam = req.params.campus ? decodeURIComponent(req.params.campus) : '';
  const campusToRemove = String(rawParam || req.body?.campus || req.body?.campusName || '').trim();
  if (!campusToRemove) {
    return sendAuthError(res, 400, 'CAMPUS_REQUIRED', 'Campus name to remove is required.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(id);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const currentCampuses = Array.isArray(user.assignedCampuses) && user.assignedCampuses.length > 0
    ? user.assignedCampuses
    : [user.branchName || 'Headquarters Campus'];

  const remaining = currentCampuses.filter((c) => c.toLowerCase() !== campusToRemove.toLowerCase());
  if (remaining.length === 0) {
    return sendAuthError(
      res,
      400,
      'CANNOT_REMOVE_LAST_CAMPUS',
      'A user must remain assigned to at least one branch/campus.'
    );
  }

  const nextPrimary =
    user.branchName && remaining.some((c) => c.toLowerCase() === user.branchName.toLowerCase())
      ? user.branchName
      : remaining[0];

  user.branchName = nextPrimary;
  user.assignedCampuses = remaining;
  user.branchIds = Array.from(new Set([user.branchId || DEFAULT_HQ_BRANCH_UUID, ...remaining]));
  await persistUserRbacState(user, sbProfile);

  db.addAuditLog(
    'USER_CAMPUS_REMOVED',
    'Security & RBAC',
    `Administrator ${operator.name} (${operator.email}) removed campus "${campusToRemove}" from ${user.email}. Remaining campuses: [${remaining.join(', ')}]`,
    operator.email || operator.name
  );

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Removed campus "${campusToRemove}" from ${user.name}.`,
    user: safeUser,
    assignedCampuses: remaining,
    primaryCampus: nextPrimary,
  });
});

// 7. ACTIVATE, DISABLE (INACTIVE), SUSPEND, OR UNLOCK USER ACCOUNT (POST /api/auth/users/:id/status & /unlock)
async function handleUpdateUserStatus(req: AuthenticatedRequest, res: Response, targetId: string) {
  const operator = req.user!;
  const rawStatus = req.body?.status || 'Active';
  const nextStatus = normalizeAccountStatus(rawStatus);
  const reason = req.body?.reason ? String(req.body.reason).trim() : '';

  if (operator.id === targetId && (nextStatus === 'Suspended' || nextStatus === 'Inactive')) {
    return sendAuthError(res, 400, 'CANNOT_DISABLE_SELF', 'You cannot suspend or disable your own active administrator account.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(targetId);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const access = verifyResourceAccess(user, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const previousStatus = user.status;
  user.status = nextStatus;

  if (nextStatus === 'Active') {
    clearStaffLockout(user.email, '127.0.0.1');
  } else if (nextStatus === 'Suspended' || nextStatus === 'Inactive') {
    const nowIso = new Date().toISOString();
    user.session_revoked_at = nowIso;
    revokeAllUserSessions(user.id);
  }
  db.persist();

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    if (nextStatus === 'Suspended' || nextStatus === 'Inactive') {
      revokeAllUserSessions(effectiveUuid);
    }
    try {
      const admin = getAdminClient();
      await admin
        .from('profiles')
        .update({ status: nextStatus, updated_at: new Date().toISOString() })
        .eq('id', effectiveUuid);

      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          status: nextStatus,
          ...(nextStatus === 'Suspended' || nextStatus === 'Inactive'
            ? { session_revoked_at: user.session_revoked_at }
            : {}),
        },
      });
    } catch {}
  }

  const actionLabel =
    nextStatus === 'Active'
      ? 'USER_ACCOUNT_ACTIVATED'
      : nextStatus === 'Suspended'
        ? 'USER_ACCOUNT_SUSPENDED'
        : nextStatus === 'Inactive'
          ? 'USER_ACCOUNT_DISABLED'
          : `USER_STATUS_${nextStatus.toUpperCase()}`;

  db.addAuditLog({
    action: actionLabel,
    module: 'Security & Users',
    userEmail: operator.email,
    userName: operator.name,
    userRole: operator.role,
    details: `Administrator ${operator.name} (${operator.email}) changed account status for ${user.name} (${user.email}) from ${previousStatus} to ${nextStatus}.${reason ? ` Reason: ${reason}` : ''}`,
    ipAddress: getClientIp(req),
  });

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    message: `Account status for ${user.name} (${user.email}) updated to ${nextStatus}.`,
    user: safeUser,
  });
}

router.post('/users/:id/status', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleUpdateUserStatus(req, res, req.params.id);
});

router.post('/users/:id/unlock', authenticateToken, requirePermission('users.manage'), async (req: AuthenticatedRequest, res: Response) => {
  return handleUpdateUserStatus(req, res, req.params.id);
});

// 7B. FORCE PASSWORD CHANGE FLAG TOGGLE (POST /api/auth/users/:id/force-password-change)
router.post('/users/:id/force-password-change', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const targetId = req.params.id;
  const forceChange = req.body?.mustChangePassword !== undefined ? Boolean(req.body.mustChangePassword) : true;

  const { user, sbProfile } = await resolveTargetSystemUser(targetId);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  user.must_change_password = forceChange;
  user.mustChangePassword = forceChange;
  db.persist();

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    try {
      const admin = getAdminClient();
      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          must_change_password: forceChange,
        },
        user_metadata: {
          ...(existingAuth?.user?.user_metadata || {}),
          must_change_password: forceChange,
        },
      });
    } catch {}
  }

  db.addAuditLog({
    action: forceChange ? 'FORCE_PASSWORD_CHANGE_ENABLED' : 'FORCE_PASSWORD_CHANGE_CLEARED',
    module: 'Security & Users',
    userEmail: operator.email,
    userName: operator.name,
    userRole: operator.role,
    details: `Administrator ${operator.name} (${operator.email}) ${forceChange ? 'enforced mandatory password change at next login' : 'cleared mandatory password change requirement'} for ${user.name} (${user.email}).`,
    ipAddress: getClientIp(req),
  });

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    mustChangePassword: forceChange,
    must_change_password: forceChange,
    user: safeUser,
    message: forceChange
      ? `${user.name} will be required to change their password at next sign-in.`
      : `Mandatory password change requirement cleared for ${user.name}.`,
  });
});

// 7C. REVOKE ALL ACTIVE SESSIONS FOR TARGET USER (POST /api/auth/users/:id/revoke-sessions)
router.post('/users/:id/revoke-sessions', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const targetId = req.params.id;

  const { user, sbProfile } = await resolveTargetSystemUser(targetId);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const now = new Date();
  const nowIso = now.toISOString();
  user.session_revoked_at = nowIso;
  if (!user.security) user.security = {};
  user.security.sessionRevokedAt = nowIso;
  db.persist();

  revokeAllUserSessions(user.id, now.getTime());

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    revokeAllUserSessions(effectiveUuid, now.getTime());
    try {
      const admin = getAdminClient();
      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          session_revoked_at: nowIso,
          aal: 'aal1',
        },
      });
    } catch {}
  }

  securityAuditService.revokeAllSessionsForUser(user.id, operator.email || operator.name, 'Administrative session revocation');
  securityAuditService.revokeAllSessionsForUser(user.email, operator.email || operator.name, 'Administrative session revocation');

  securityAuditService.recordEvent({
    req,
    eventType: 'SESSION_REVOKED',
    action: 'USER_SESSIONS_REVOKED',
    module: 'Security & Users',
    actorId: operator.id,
    actorEmail: operator.email,
    actorName: operator.name,
    actorRole: operator.role,
    targetUserId: user.id,
    targetUserEmail: user.email,
    outcome: 'SUCCESS',
    severity: 'HIGH',
    details: `Administrator ${operator.name} (${operator.email}) revoked all active sessions and tokens for ${user.name} (${user.email}).`,
  });

  const { password, passwordHash, mfaSecret, totpSecret, temporaryPassword, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    sessionRevokedAt: nowIso,
    user: safeUser,
    message: `All active sessions for ${user.name} (${user.email}) have been revoked immediately.`,
  });
});

// 7D. GET SECURITY EVENTS FOR A SPECIFIC USER OR ALL USERS (GET /api/auth/users/:id/security-events)
router.get('/users/:id/security-events', authenticateToken, requirePermission('users.read'), async (req: AuthenticatedRequest, res: Response) => {
  const targetId = req.params.id;
  const state = db.getState();

  const { user } = await resolveTargetSystemUser(targetId);
  const emailLower = user?.email?.toLowerCase() || (targetId.includes('@') ? targetId.toLowerCase() : '');
  const nameLower = user?.name?.toLowerCase() || '';

  const allLogs = state.auditLogs || [];
  const matchingEvents = allLogs.filter((log) => {
    if (targetId === 'all') return true;
    const logUserEmail = (log.userEmail || '').toLowerCase();
    const logDetails = (log.details || '').toLowerCase();
    if (emailLower && (logUserEmail === emailLower || logDetails.includes(emailLower))) return true;
    if (user?.id && logDetails.includes(user.id.toLowerCase())) return true;
    if (nameLower && nameLower.length > 3 && logDetails.includes(nameLower)) return true;
    return false;
  });

  return res.status(200).json({
    success: true,
    userId: user?.id || targetId,
    email: user?.email || emailLower,
    events: matchingEvents.slice(0, 100),
  });
});

// 8. TOGGLE MFA (users.manage or own account)
router.post('/users/:id/toggle-mfa', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  const { enabled } = req.body || {};

  if (operator.id !== id && operator.role !== 'SYSTEM_ADMIN') {
    return sendAuthError(res, 403, 'FORBIDDEN', 'Unauthorized to modify MFA settings for another user.');
  }

  if (enabled) {
    return handleAdminEnable2Fa(req, res, id);
  } else {
    return handleAdminDisable2Fa(req, res, id);
  }
});

// 9. DELETE USER (users.manage) - IDOR & Self-Deletion Protected
router.delete('/users/:id', authenticateToken, requirePermission('users.manage'), sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const { id } = req.params;
  if (operator.id === id) {
    return sendAuthError(res, 400, 'CANNOT_DELETE_SELF', 'Cannot delete your own active administrator account.');
  }

  const state = db.getState();
  const index = state.systemUsers.findIndex((u) => u.id === id);
  if (index === -1) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'User not found.');
  }

  const target = state.systemUsers[index];
  const access = verifyResourceAccess(target, operator, { checkBranch: false });
  if (!access.authorized) {
    return sendAuthError(res, access.status, 'FORBIDDEN', access.reason || 'Forbidden');
  }

  const deleted = state.systemUsers.splice(index, 1)[0];
  revokeAllUserSessions(id);
  db.persist();
  db.addAuditLog('Revoke User Access', 'Security & Users', `Permanently deleted user account ${deleted.email}`, operator.name);
  return res.status(200).json({ success: true, deletedId: id });
});

// 10. SYSTEM_ADMIN ENABLE 2FA / TOTP ENROLLMENT & VERIFICATION
// Flow:
// Step 1: Admin clicks Enable 2FA -> backend authorization -> create/enroll TOTP factor -> return QR/secret/uri + enrollmentChallengeId
// Step 2: Admin or target user verifies first 6-digit TOTP code (or confirms enrollment) -> mark MFA enabled & verified -> audit event
async function handleAdminEnable2Fa(req: AuthenticatedRequest, res: Response, targetUserId: string) {
  const operator = req.user;
  if (!operator) {
    return sendAuthError(res, 401, 'UNAUTHORIZED', 'Authentication required.');
  }

  if (operator.role !== 'SYSTEM_ADMIN' && operator.id !== targetUserId) {
    return sendAuthError(
      res,
      403,
      'FORBIDDEN',
      'Access denied: Only SYSTEM_ADMIN can manage two-factor authentication for users.'
    );
  }

  const { user, sbProfile } = await resolveTargetSystemUser(targetUserId);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target staff user not found.');
  }

  if ((user.status as any) === 'Deleted' || (user as any).isDeleted) {
    return sendAuthError(res, 400, 'ACCOUNT_DELETED', 'Target staff user account is invalid or deleted.');
  }

  const branding = db.getBranding();
  const systemName = branding.systemName || 'Grace Cathedral CMMS';
  const rawSecret = crypto.randomBytes(20);
  const secret = base32Encode(rawSecret);
  const factorId = `totp_${crypto.randomBytes(8).toString('hex')}`;
  const otpauthUri = `otpauth://totp/${encodeURIComponent(systemName)}:${encodeURIComponent(user.email)}?secret=${secret}&issuer=${encodeURIComponent(systemName)}&algorithm=SHA1&digits=6&period=30`;
  const challengeId = `admin_mfa_enroll_${crypto.randomBytes(12).toString('hex')}`;

  // Store pending enrollment so first TOTP code can be verified immediately in modal OR on user's next login
  pendingStaffMfaEnrollments.set(challengeId, {
    userId: user.id,
    email: user.email.toLowerCase(),
    secret,
    uri: otpauthUri,
    factorId,
    challengeId,
    expiresAt: Date.now() + 30 * 60 * 1000,
  });

  (user as any).totpSecret = secret;
  user.mfaFactorId = factorId;
  user.isMfaEnabled = true;
  user.mfaEnabled = true;
  user.mfa_enabled = true;
  // If code is passed directly in request body, verify it immediately
  const submittedCode = req.body?.code ? String(req.body.code).trim() : '';
  let verifiedImmediately = false;
  if (submittedCode) {
    if (!verifyTOTPCode(secret, submittedCode)) {
      return sendAuthError(res, 400, 'INVALID_MFA_CODE', 'Invalid 6-digit TOTP verification code. Please check your authenticator app.');
    }
    verifiedImmediately = true;
  }

  user.mfaEnrolled = verifiedImmediately;
  user.mfa_enrolled = verifiedImmediately;
  db.persist();

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    try {
      const admin = getAdminClient();
      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          mfa_enabled: true,
          mfa_enrolled: verifiedImmediately,
          mfa_factor_id: factorId,
          totp_secret: secret,
        },
      });
    } catch {}
  }

  db.addAuditLog({
    action: verifiedImmediately ? 'ADMIN_2FA_ENROLLED_AND_VERIFIED' : 'ADMIN_2FA_ENROLLMENT_CREATED',
    module: 'Security & 2FA',
    userEmail: operator.email,
    userName: operator.name,
    userRole: operator.role,
    details: `Administrator ${operator.name} (${operator.email}) enrolled TOTP 2FA factor (${factorId}) for user ${user.email} (${user.id}). Status: ${verifiedImmediately ? 'Verified & Active' : 'Enrolled (Awaiting First TOTP Code Verification)'}`,
    ipAddress: getClientIp(req),
  });

  const { password: _p, passwordHash: _ph, mfaSecret: _ms, totpSecret: _ts, ...safeUser } = user as any;

  return res.status(200).json({
    success: true,
    message: verifiedImmediately
      ? `Two-factor authentication enrolled and verified for ${user.email}.`
      : `TOTP factor generated for ${user.email}. Scan the QR code or enter the secret key in an authenticator app and verify the 6-digit code.`,
    enrollment: {
      factorId,
      challengeId,
      secret,
      uri: otpauthUri,
      issuer: systemName,
      accountName: user.email,
      verified: verifiedImmediately,
    },
    user: safeUser,
  });
}

// 10B. VERIFY TOTP ENROLLMENT FOR USER (POST /api/auth/admin/users/:userId/2fa/verify & /users/:id/2fa/verify)
async function handleAdminVerify2FaEnrollment(req: AuthenticatedRequest, res: Response, targetUserId: string) {
  const operator = req.user;
  if (!operator) {
    return sendAuthError(res, 401, 'UNAUTHORIZED', 'Authentication required.');
  }

  if (operator.role !== 'SYSTEM_ADMIN' && operator.id !== targetUserId) {
    return sendAuthError(res, 403, 'FORBIDDEN', 'Only SYSTEM_ADMIN can verify 2FA enrollment for users.');
  }

  const { code, challengeId, secret: bodySecret } = req.body || {};
  const cleanCode = String(code || '').trim();
  if (!cleanCode || cleanCode.length !== 6) {
    return sendAuthError(res, 400, 'INVALID_MFA_CODE', 'A valid 6-digit authenticator code is required to verify 2FA enrollment.');
  }

  const { user, sbProfile } = await resolveTargetSystemUser(targetUserId);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target user not found.');
  }

  const pending = challengeId ? pendingStaffMfaEnrollments.get(challengeId) : undefined;
  const secretToVerify = pending?.secret || (user as any).totpSecret || bodySecret;

  if (!secretToVerify) {
    return sendAuthError(res, 400, 'MFA_NOT_INITIALIZED', 'No active TOTP factor found. Please click Enable 2FA first.');
  }

  if (!verifyTOTPCode(secretToVerify, cleanCode, 2)) {
    db.addAuditLog({
      action: 'ADMIN_2FA_VERIFY_FAILED',
      module: 'Security & 2FA',
      userEmail: operator.email,
      userName: operator.name,
      userRole: operator.role,
      details: `Failed TOTP verification attempt during 2FA enrollment for user ${user.email}`,
      ipAddress: getClientIp(req),
    });
    return sendAuthError(res, 400, 'INVALID_MFA_CODE', 'Incorrect 6-digit TOTP code. Please check your authenticator app and try again.');
  }

  if (challengeId) {
    pendingStaffMfaEnrollments.delete(challengeId);
  }

  (user as any).totpSecret = secretToVerify;
  user.isMfaEnabled = true;
  user.mfaEnabled = true;
  user.mfa_enabled = true;
  user.mfaEnrolled = true;
  user.mfa_enrolled = true;
  db.persist();

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    try {
      const admin = getAdminClient();
      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          mfa_enabled: true,
          mfa_enrolled: true,
          totp_secret: secretToVerify,
        },
      });
    } catch {}
  }

  db.addAuditLog({
    action: 'ADMIN_2FA_VERIFIED',
    module: 'Security & 2FA',
    userEmail: operator.email,
    userName: operator.name,
    userRole: operator.role,
    details: `Administrator ${operator.name} (${operator.email}) verified first TOTP code and activated 2FA enforcement for ${user.email} (${user.id}).`,
    ipAddress: getClientIp(req),
  });

  const { password: _p, passwordHash: _ph, mfaSecret: _ms, totpSecret: _ts, ...safeUser } = user as any;
  return res.status(200).json({
    success: true,
    verified: true,
    message: `Two-factor authentication verified and active for ${user.name} (${user.email}).`,
    user: safeUser,
  });
}

// 11. SYSTEM_ADMIN DISABLE 2FA / TOTP (Strictly restricted to SYSTEM_ADMIN)
async function handleAdminDisable2Fa(req: AuthenticatedRequest, res: Response, targetUserId: string) {
  const operator = req.user;
  if (!operator) {
    return sendAuthError(res, 401, 'UNAUTHORIZED', 'Authentication required.');
  }

  if (operator.role !== 'SYSTEM_ADMIN' && operator.id !== targetUserId) {
    return sendAuthError(
      res,
      403,
      'FORBIDDEN',
      'Access denied: Only SYSTEM_ADMIN can disable two-factor authentication for users.'
    );
  }

  const { user, sbProfile } = await resolveTargetSystemUser(targetUserId);
  if (!user) {
    return sendAuthError(res, 404, 'USER_NOT_FOUND', 'Target staff user not found.');
  }

  user.isMfaEnabled = false;
  user.mfaEnabled = false;
  user.mfa_enabled = false;
  user.mfaEnrolled = false;
  user.mfa_enrolled = false;
  delete (user as any).totpSecret;
  delete (user as any).mfaSecret;
  delete user.mfaFactorId;
  db.persist();

  for (const [key, record] of pendingStaffMfaEnrollments.entries()) {
    if (record.userId === user.id || record.email.toLowerCase() === user.email.toLowerCase()) {
      pendingStaffMfaEnrollments.delete(key);
    }
  }
  for (const [key, record] of pendingStaffMfaChallenges.entries()) {
    if (record.userId === user.id || record.email.toLowerCase() === user.email.toLowerCase()) {
      pendingStaffMfaChallenges.delete(key);
    }
  }

  const effectiveUuid = isValidUUID(user.id) ? user.id : sbProfile?.id && isValidUUID(sbProfile.id) ? sbProfile.id : '';
  if (effectiveUuid) {
    try {
      const admin = getAdminClient();
      const { data: factors } = await admin.auth.admin.mfa.listFactors({ userId: effectiveUuid });
      if (factors?.factors) {
        for (const factor of factors.factors) {
          await admin.auth.admin.mfa.deleteFactor({ id: factor.id, userId: effectiveUuid });
        }
      }
      const { data: existingAuth } = await admin.auth.admin.getUserById(effectiveUuid);
      await admin.auth.admin.updateUserById(effectiveUuid, {
        app_metadata: {
          ...(existingAuth?.user?.app_metadata || {}),
          mfa_enabled: false,
          mfa_enrolled: false,
          mfa_factor_id: null,
          totp_secret: null,
          aal: 'aal1',
        },
      });
    } catch {}
  }

  db.addAuditLog({
    action: 'ADMIN_2FA_DISABLED',
    module: 'Security & 2FA',
    userEmail: operator.email,
    userName: operator.name,
    userRole: operator.role,
    details: `Administrator ${operator.name} (${operator.email}) disabled 2FA, removed TOTP factor, and invalidated active MFA state for user ${user.email} (${user.id})`,
    ipAddress: getClientIp(req),
  });

  const { password: _p, passwordHash: _ph, mfaSecret: _ms, totpSecret: _ts, ...safeUser } = user as any;

  return res.status(200).json({
    success: true,
    message: `Two-factor authentication disabled for ${user.email}. TOTP factor removed and MFA state cleared.`,
    user: safeUser,
  });
}

// Wire routes for 2FA enable, verify & disable
router.post('/admin/users/:userId/2fa/enable', authenticateToken, sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminEnable2Fa(req, res, req.params.userId);
});

router.post('/users/:id/2fa/enable', authenticateToken, sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminEnable2Fa(req, res, req.params.id);
});

router.post('/admin/users/:userId/2fa/verify', authenticateToken, sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminVerify2FaEnrollment(req, res, req.params.userId);
});

router.post('/users/:id/2fa/verify', authenticateToken, sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminVerify2FaEnrollment(req, res, req.params.id);
});

router.post('/admin/users/:userId/2fa/disable', authenticateToken, sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminDisable2Fa(req, res, req.params.userId);
});

router.post('/users/:id/2fa/disable', authenticateToken, sensitiveAdminLimiter, async (req: AuthenticatedRequest, res: Response) => {
  return handleAdminDisable2Fa(req, res, req.params.id);
});

// ==============================================================================
// 12. STRICT HTTP METHOD ENFORCEMENT (405 METHOD_NOT_ALLOWED)
// Never allow an API endpoint that expects POST to silently behave as GET or return HTML
// ==============================================================================
const postOnlyPaths = [
  '/staff/login',
  '/member/login',
  '/login',
  '/logout',
  '/staff/logout',
  '/refresh',
  '/change-password',
  '/forgot-password',
  '/staff/forgot-password',
  '/verify-reset-code',
  '/reset-password',
  '/staff/mfa/challenge',
  '/staff/mfa/verify',
  '/staff/reauth',
  '/google',
  '/register-onboarding',
  '/register-public',
];

for (const path of postOnlyPaths) {
  router.all(path, (req: Request, res: Response) => {
    res.setHeader('Allow', 'POST');
    return sendAuthError(
      res,
      405,
      'METHOD_NOT_ALLOWED',
      `HTTP method ${req.method} is not allowed on ${req.baseUrl}${req.path}. Expected POST.`
    );
  });
}

router.all('/me', (req: Request, res: Response) => {
  res.setHeader('Allow', 'GET');
  return sendAuthError(
    res,
    405,
    'METHOD_NOT_ALLOWED',
    `HTTP method ${req.method} is not allowed on ${req.baseUrl}${req.path}. Expected GET.`
  );
});

export default router;
