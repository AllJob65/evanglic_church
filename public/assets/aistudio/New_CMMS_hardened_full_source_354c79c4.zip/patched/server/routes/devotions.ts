import { Router, Request, Response } from 'express';
import { db } from '../db';
import { Devotion, DevotionReaction, DevotionComment, DevotionReactionType, DevotionStatus } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
} from '../../src/security/authorization';

const router = Router();

// Helper to extract authenticated user info if token is present
function getOptionalUser(req: Request) {
  return (req as AuthenticatedRequest).user || null;
}

function hasDevotionManagePermission(req: Request): boolean {
  const user = getOptionalUser(req);
  if (!user) return false;
  return ['SYSTEM_ADMIN', 'BRANCHADMIN', 'PASTOR'].includes(user.role);
}

// ----------------------------------------------------------------------------
// 1. GET ALL DEVOTIONS (Public sees published, Pastors/Admins see all)
// ----------------------------------------------------------------------------
router.get('/', (req: Request, res: Response) => {
  const user = getOptionalUser(req);
  const { topic, status, search } = req.query;

  const state = db.getState();
  let devotions = [...(state.devotions || [])];

  // If not Pastor/Admin, only show published devotions
  if (!hasDevotionManagePermission(req)) {
    devotions = devotions.filter((d) => d.status === 'published');
  } else if (status && status !== 'all') {
    devotions = devotions.filter((d) => d.status === status);
  }

  // Filter by topic
  if (topic && topic !== 'All') {
    devotions = devotions.filter((d) => d.topic.toLowerCase() === String(topic).toLowerCase());
  }

  // Search filter
  if (search) {
    const q = String(search).toLowerCase();
    devotions = devotions.filter(
      (d) =>
        d.title.toLowerCase().includes(q) ||
        (d.amharicTitle && d.amharicTitle.toLowerCase().includes(q)) ||
        d.scriptureReference.toLowerCase().includes(q) ||
        d.body.toLowerCase().includes(q) ||
        d.authorName.toLowerCase().includes(q) ||
        d.topic.toLowerCase().includes(q)
    );
  }

  // Attach reaction counts & current user's reaction for each devotion
  const reactions = state.devotionReactions || [];
  const comments = state.devotionComments || [];

  const enriched = devotions.map((dev) => {
    const devReactions = reactions.filter((r) => r.devotionId === dev.id);
    const userReacts = user ? devReactions.filter((r) => r.userId === user.id).map((r) => r.reactionType) : [];
    const devComments = comments.filter((c) => c.devotionId === dev.id && !c.isModerated);

    const counts = {
      heart: devReactions.filter((r) => r.reactionType === 'heart').length,
      amen: devReactions.filter((r) => r.reactionType === 'amen').length,
      praying: devReactions.filter((r) => r.reactionType === 'praying').length,
      inspiring: devReactions.filter((r) => r.reactionType === 'inspiring').length,
    };

    return {
      ...dev,
      reactionsCount: counts,
      userReactions: userReacts,
      commentsCount: devComments.length,
    };
  });

  // Sort by publishedAt desc
  enriched.sort((a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime());

  return res.json({
    success: true,
    total: enriched.length,
    devotions: enriched,
  });
});

// ----------------------------------------------------------------------------
// 2. GET TODAY'S ACTIVE DEVOTION
// ----------------------------------------------------------------------------
router.get('/today', (req: Request, res: Response) => {
  const user = getOptionalUser(req);
  const state = db.getState();
  const devotions = (state.devotions || []).filter((d) => d.status === 'published');

  if (devotions.length === 0) {
    return res.status(404).json({ error: 'No published devotion available for today' });
  }

  // Sort by publishedAt desc
  devotions.sort((a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime());
  const todayDevotion = devotions[0];

  const reactions = state.devotionReactions || [];
  const devReactions = reactions.filter((r) => r.devotionId === todayDevotion.id);
  const userReacts = user ? devReactions.filter((r) => r.userId === user.id).map((r) => r.reactionType) : [];
  const comments = (state.devotionComments || []).filter((c) => c.devotionId === todayDevotion.id && !c.isModerated);

  const enriched = {
    ...todayDevotion,
    reactionsCount: {
      heart: devReactions.filter((r) => r.reactionType === 'heart').length,
      amen: devReactions.filter((r) => r.reactionType === 'amen').length,
      praying: devReactions.filter((r) => r.reactionType === 'praying').length,
      inspiring: devReactions.filter((r) => r.reactionType === 'inspiring').length,
    },
    userReactions: userReacts,
    commentsCount: comments.length,
  };

  return res.json({ success: true, devotion: enriched });
});

// ----------------------------------------------------------------------------
// 3. GET SINGLE DEVOTION BY ID
// ----------------------------------------------------------------------------
router.get('/:id', (req: Request, res: Response) => {
  const user = getOptionalUser(req);
  const { id } = req.params;

  const state = db.getState();
  const devotion = (state.devotions || []).find((d) => d.id === id);

  if (!devotion) {
    return res.status(404).json({ error: 'Devotion not found' });
  }

  if (devotion.status !== 'published' && !hasDevotionManagePermission(req)) {
    return res.status(403).json({ error: 'Access denied: Devotion is not yet published.' });
  }

  const reactions = (state.devotionReactions || []).filter((r) => r.devotionId === id);
  const comments = (state.devotionComments || []).filter((c) => c.devotionId === id && !c.isModerated);

  const enriched = {
    ...devotion,
    reactionsCount: {
      heart: reactions.filter((r) => r.reactionType === 'heart').length,
      amen: reactions.filter((r) => r.reactionType === 'amen').length,
      praying: reactions.filter((r) => r.reactionType === 'praying').length,
      inspiring: reactions.filter((r) => r.reactionType === 'inspiring').length,
    },
    userReactions: user ? reactions.filter((r) => r.userId === user.id).map((r) => r.reactionType) : [],
    commentsCount: comments.length,
    comments: comments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
  };

  return res.json({ success: true, devotion: enriched });
});

// ----------------------------------------------------------------------------
// 4. CREATE DEVOTION (PASTOR / ADMIN ONLY via devotions.manage)
// ----------------------------------------------------------------------------
router.post('/', authenticateToken, requirePermission('devotions.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const {
    title,
    amharicTitle,
    topic,
    scriptureReference,
    keyVerse,
    body,
    prayer,
    status = 'published',
    scheduledFor,
    audioUrl,
  } = req.body;

  if (!title || !scriptureReference || !body) {
    return res.status(400).json({ error: 'Missing required devotion fields: title, scriptureReference, body' });
  }

  const state = db.getState();
  if (!state.devotions) state.devotions = [];

  const newDevotion: Devotion = {
    id: `dev-${Date.now()}`,
    title: String(title).trim(),
    amharicTitle: amharicTitle ? String(amharicTitle).trim() : undefined,
    topic: topic || 'Faith & Daily Living',
    scriptureReference: String(scriptureReference).trim(),
    keyVerse: keyVerse ? String(keyVerse).trim() : undefined,
    body: String(body).trim(),
    prayer: prayer ? String(prayer).trim() : undefined,
    authorId: user.id,
    authorName: user.name || 'Pastor',
    audioUrl: audioUrl || '',
    status: (status as DevotionStatus) || 'published',
    scheduledFor: scheduledFor || undefined,
    publishedAt: status === 'published' ? new Date().toISOString() : (scheduledFor || new Date().toISOString()),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    reactionsCount: { heart: 0, amen: 0, praying: 0, inspiring: 0 },
    commentsCount: 0,
  };

  state.devotions.unshift(newDevotion);
  db.addAuditLog('Create Devotion', 'Devotions', `Created devotion "${title}" (${status})`, user.name);
  db.persist();

  return res.status(201).json({ success: true, devotion: newDevotion });
});

// ----------------------------------------------------------------------------
// 5. UPDATE DEVOTION (PASTOR / ADMIN ONLY via devotions.manage)
// ----------------------------------------------------------------------------
router.put('/:id', authenticateToken, requirePermission('devotions.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const state = db.getState();
  const index = (state.devotions || []).findIndex((d) => d.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Devotion not found' });
  }

  const existing = state.devotions[index];
  const {
    title,
    amharicTitle,
    topic,
    scriptureReference,
    keyVerse,
    body,
    prayer,
    status,
    scheduledFor,
    audioUrl,
  } = req.body;

  state.devotions[index] = {
    ...existing,
    title: title !== undefined ? String(title).trim() : existing.title,
    amharicTitle: amharicTitle !== undefined ? String(amharicTitle).trim() : existing.amharicTitle,
    topic: topic !== undefined ? topic : existing.topic,
    scriptureReference: scriptureReference !== undefined ? String(scriptureReference).trim() : existing.scriptureReference,
    keyVerse: keyVerse !== undefined ? String(keyVerse).trim() : existing.keyVerse,
    body: body !== undefined ? String(body).trim() : existing.body,
    prayer: prayer !== undefined ? String(prayer).trim() : existing.prayer,
    status: status !== undefined ? status : existing.status,
    scheduledFor: scheduledFor !== undefined ? scheduledFor : existing.scheduledFor,
    audioUrl: audioUrl !== undefined ? audioUrl : existing.audioUrl,
    updatedAt: new Date().toISOString(),
  };

  db.addAuditLog('Update Devotion', 'Devotions', `Updated devotion "${state.devotions[index].title}"`, user.name);
  db.persist();

  return res.json({ success: true, devotion: state.devotions[index] });
});

// ----------------------------------------------------------------------------
// 6. UPDATE DEVOTION STATUS (Publish, Archive, Draft via devotions.manage)
// ----------------------------------------------------------------------------
router.put('/:id/status', authenticateToken, requirePermission('devotions.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { status } = req.body as { status: DevotionStatus };

  if (!status || !['draft', 'published', 'scheduled', 'archived'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status. Allowed: draft, published, scheduled, archived' });
  }

  const state = db.getState();
  const devotion = (state.devotions || []).find((d) => d.id === id);

  if (!devotion) {
    return res.status(404).json({ error: 'Devotion not found' });
  }

  devotion.status = status;
  if (status === 'published' && !devotion.publishedAt) {
    devotion.publishedAt = new Date().toISOString();
  }
  devotion.updatedAt = new Date().toISOString();

  db.addAuditLog('Change Devotion Status', 'Devotions', `Set devotion "${devotion.title}" to ${status}`, user.name);
  db.persist();

  return res.json({ success: true, devotion });
});

// ----------------------------------------------------------------------------
// 7. DELETE DEVOTION (PASTOR / ADMIN ONLY via devotions.manage)
// ----------------------------------------------------------------------------
router.delete('/:id', authenticateToken, requirePermission('devotions.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const state = db.getState();
  const index = (state.devotions || []).findIndex((d) => d.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Devotion not found' });
  }

  const removed = state.devotions.splice(index, 1)[0];
  state.devotionReactions = (state.devotionReactions || []).filter((r) => r.devotionId !== id);
  state.devotionComments = (state.devotionComments || []).filter((c) => c.devotionId !== id);

  db.addAuditLog('Delete Devotion', 'Devotions', `Deleted devotion "${removed.title}"`, user.name);
  db.persist();

  return res.json({ success: true, message: 'Devotion deleted successfully' });
});

// ----------------------------------------------------------------------------
// 8. DEVOTION REACTIONS (TOGGLE - Requires Authentication)
// ----------------------------------------------------------------------------
router.post('/:id/reactions', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { reactionType } = req.body as { reactionType: DevotionReactionType };

  if (!reactionType || !['heart', 'amen', 'praying', 'inspiring'].includes(reactionType)) {
    return res.status(400).json({ error: 'Invalid reactionType. Allowed: heart, amen, praying, inspiring' });
  }

  const state = db.getState();
  if (!state.devotionReactions) state.devotionReactions = [];

  const existingIdx = state.devotionReactions.findIndex(
    (r) => r.devotionId === id && r.userId === user.id && r.reactionType === reactionType
  );

  let active = false;
  if (existingIdx !== -1) {
    // Remove reaction (toggle off)
    state.devotionReactions.splice(existingIdx, 1);
    active = false;
  } else {
    // Add reaction (toggle on)
    state.devotionReactions.push({
      id: `react-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      devotionId: id,
      userId: user.id,
      reactionType,
      createdAt: new Date().toISOString(),
    });
    active = true;
  }

  db.persist();

  // Return updated counts
  const devReactions = state.devotionReactions.filter((r) => r.devotionId === id);
  const counts = {
    heart: devReactions.filter((r) => r.reactionType === 'heart').length,
    amen: devReactions.filter((r) => r.reactionType === 'amen').length,
    praying: devReactions.filter((r) => r.reactionType === 'praying').length,
    inspiring: devReactions.filter((r) => r.reactionType === 'inspiring').length,
  };
  const userReactions = devReactions.filter((r) => r.userId === user.id).map((r) => r.reactionType);

  return res.json({
    success: true,
    active,
    reactionType,
    reactionsCount: counts,
    userReactions,
  });
});

// ----------------------------------------------------------------------------
// 9. DEVOTION COMMENTS (LIST & ADD)
// ----------------------------------------------------------------------------
router.get('/:id/comments', (req: Request, res: Response) => {
  const { id } = req.params;
  const state = db.getState();
  const comments = (state.devotionComments || [])
    .filter((c) => c.devotionId === id && !c.isModerated)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return res.json({ success: true, comments });
});

router.post('/:id/comments', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const { commentText } = req.body;

  if (!commentText || !String(commentText).trim()) {
    return res.status(400).json({ error: 'Comment text cannot be empty' });
  }

  const state = db.getState();
  if (!state.devotionComments) state.devotionComments = [];

  const newComment: DevotionComment = {
    id: `comm-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    devotionId: id,
    userId: user.id,
    userName: user.name || 'Fellow Believer',
    commentText: String(commentText).trim(),
    createdAt: new Date().toISOString(),
    isModerated: false,
  };

  state.devotionComments.unshift(newComment);
  db.persist();

  return res.status(201).json({ success: true, comment: newComment });
});

router.delete('/:id/comments/:commentId', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { commentId } = req.params;

  const state = db.getState();
  const comment = (state.devotionComments || []).find((c) => c.id === commentId);

  if (!comment) {
    return res.status(404).json({ error: 'Comment not found' });
  }

  const canManage = ['SYSTEM_ADMIN', 'BRANCHADMIN', 'PASTOR'].includes(user.role);
  if (comment.userId !== user.id && !canManage) {
    return res.status(403).json({ error: 'Unauthorized to delete this comment' });
  }

  state.devotionComments = (state.devotionComments || []).filter((c) => c.id !== commentId);
  db.persist();

  return res.json({ success: true, message: 'Comment deleted' });
});

export default router;
