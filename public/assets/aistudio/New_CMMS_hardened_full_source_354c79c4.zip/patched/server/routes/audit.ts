import { Router, Response } from 'express';
import { db } from '../db';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
  revokeSessionToken,
  revokeAllUserSessions,
  ROLES_CATALOG,
  ROLE_PERMISSIONS,
  computeEffectivePermissions,
} from '../../src/security/authorization';
import {
  securityAuditService,
  redactSensitiveMetadata,
} from '../services/securityAuditService';
import { getCookieSecurityStatus } from '../utils/cookieSecurity';
import { sensitiveAdminLimiter } from '../middleware/rateLimiter';
import { isSupabaseConfigured } from '../../src/lib/supabase';
import { isPgConfigured } from '../pg';

const router = Router();

// Apply authentication to all audit & security governance endpoints
router.use(authenticateToken);

// 1. AUDIT LOGS - Enforce audit.read permission (Strictly SYSTEM_ADMIN)
// Supports search, user/email, eventType, severity, outcome, dateFrom, dateTo, tenantId, and pagination
router.get('/logs', requirePermission('audit.read'), (req: AuthenticatedRequest, res: Response) => {
  const operator = req.user!;
  const allLogs = db.getState().auditLogs || [];
  const {
    search,
    user,
    eventType,
    severity,
    outcome,
    module: modFilter,
    dateFrom,
    dateTo,
    tenantId: requestedTenantId,
    page,
    limit,
  } = req.query;

  // Enforce strict tenant isolation: cross-tenant audit queries are rejected with 403
  if (
    requestedTenantId &&
    String(requestedTenantId) !== 'ALL' &&
    operator.tenantId &&
    String(requestedTenantId) !== operator.tenantId
  ) {
    securityAuditService.recordEvent({
      req,
      eventType: 'UNAUTHORIZED_API_ACCESS',
      action: 'Blocked Cross-Tenant Audit Query',
      module: 'Audit Trail Integrity',
      details: `Blocked cross-tenant audit log query from ${operator.email} (operator tenant: ${operator.tenantId}, requested tenant: ${requestedTenantId}).`,
      actorId: operator.id,
      actorEmail: operator.email,
      actorName: operator.name,
      actorRole: operator.role,
      outcome: 'BLOCKED',
      severity: 'HIGH',
    });
    return res.status(403).json({
      success: false,
      error: 'CROSS_TENANT_ACCESS_DENIED',
      code: 'CROSS_TENANT_ACCESS_DENIED',
      message: 'Cross-tenant audit queries are prohibited. You may only query audit records within your authorized tenant scope.',
    });
  }

  let filtered = allLogs.filter((log) => {
    // Filter out any record explicitly scoped to a different tenant
    const logTenantId = (log as any).tenantId;
    if (logTenantId && operator.tenantId && logTenantId !== operator.tenantId) {
      return false;
    }
    if (search) {
      const q = String(search).trim().toLowerCase();
      const match =
        (log.action || '').toLowerCase().includes(q) ||
        (log.userEmail || '').toLowerCase().includes(q) ||
        (log.userName || '').toLowerCase().includes(q) ||
        (log.details || '').toLowerCase().includes(q) ||
        (log.ipAddress || '').toLowerCase().includes(q) ||
        (log.eventType || '').toLowerCase().includes(q) ||
        (log.correlationId || '').toLowerCase().includes(q) ||
        (log.sessionId || '').toLowerCase().includes(q);
      if (!match) return false;
    }
    if (user && String(user) !== 'ALL') {
      const uq = String(user).trim().toLowerCase();
      if (
        (log.userEmail || '').toLowerCase() !== uq &&
        (log.actorId || '').toLowerCase() !== uq &&
        !(log.userName || '').toLowerCase().includes(uq)
      ) {
        return false;
      }
    }
    if (eventType && String(eventType) !== 'ALL') {
      if ((log.eventType || log.action) !== String(eventType)) return false;
    }
    if (severity && String(severity) !== 'ALL') {
      if ((log.severity || 'LOW').toUpperCase() !== String(severity).toUpperCase()) return false;
    }
    if (outcome && String(outcome) !== 'ALL') {
      if ((log.outcome || 'SUCCESS').toUpperCase() !== String(outcome).toUpperCase()) return false;
    }
    if (modFilter && String(modFilter) !== 'all' && String(modFilter) !== 'ALL') {
      if (log.module !== String(modFilter)) return false;
    }
    if (dateFrom) {
      const fromMs = new Date(String(dateFrom)).getTime();
      if (!isNaN(fromMs) && new Date(log.timestamp).getTime() < fromMs) return false;
    }
    if (dateTo) {
      const toMs = new Date(String(dateTo)).getTime() + 86399999; // inclusive end of day
      if (!isNaN(toMs) && new Date(log.timestamp).getTime() > toMs) return false;
    }
    return true;
  });

  // Redact any residual sensitive strings before returning
  const safeLogs = filtered.map((l) => ({
    ...l,
    details: redactSensitiveMetadata(l.details),
    commitData: l.commitData ? redactSensitiveMetadata(l.commitData) : undefined,
  }));

  if (page || limit) {
    const pageNum = Math.max(1, Number(page) || 1);
    const pageSize = Math.min(500, Math.max(1, Number(limit) || 25));
    const startIdx = (pageNum - 1) * pageSize;
    return res.json({
      success: true,
      logs: safeLogs.slice(startIdx, startIdx + pageSize),
      total: safeLogs.length,
      page: pageNum,
      limit: pageSize,
      totalPages: Math.max(1, Math.ceil(safeLogs.length / pageSize)),
    });
  }

  return res.json(safeLogs);
});

// 2. LOG ACTION - Derives user identity strictly from verified session
router.post('/logs', (req: AuthenticatedRequest, res: Response) => {
  const { action, moduleName, details } = req.body;
  if (!action || !moduleName) {
    return res.status(400).json({ error: 'Action and moduleName are required' });
  }

  const user = req.user;
  try {
    const entry = securityAuditService.recordEvent({
      req,
      eventType: 'PRIVILEGED_ADMIN_ACTION',
      action: String(action),
      module: String(moduleName),
      details: String(details || ''),
      actorId: user?.id,
      actorEmail: user?.email,
      actorName: user?.name,
      actorRole: user?.role,
      outcome: 'SUCCESS',
      severity: 'LOW',
    });
    return res.status(201).json({ success: true, id: entry.id, integrityHash: entry.integrityHash });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: 'AUDIT_PERSISTENCE_FAILED',
      code: 'AUDIT_PERSISTENCE_FAILED',
      message: err?.message || 'Failed to persist audit record to authoritative store.',
    });
  }
});

// 3. BLOCK ANY ORDINARY API ATTEMPT TO MODIFY OR DELETE AUDIT LOGS (Tamper-Resistance Enforcement)
router.delete('/logs*', (req: AuthenticatedRequest, res: Response) => {
  securityAuditService.recordEvent({
    req,
    eventType: 'UNAUTHORIZED_API_ACCESS',
    action: 'Blocked Audit Log Deletion Attempt',
    module: 'Audit Trail Integrity',
    details: `Blocked attempt by ${req.user?.email || 'unknown'} to delete audit records via ${req.originalUrl}. Audit trail is append-only.`,
    actorId: req.user?.id,
    actorEmail: req.user?.email,
    actorName: req.user?.name,
    actorRole: req.user?.role,
    outcome: 'BLOCKED',
    severity: 'CRITICAL',
  });
  return res.status(403).json({
    success: false,
    error: 'AUDIT_IMMUTABLE',
    code: 'AUDIT_IMMUTABLE',
    message: 'Security audit logs are append-only and cannot be modified or deleted through application APIs.',
  });
});

router.put('/logs*', (req: AuthenticatedRequest, res: Response) => {
  return res.status(403).json({
    success: false,
    error: 'AUDIT_IMMUTABLE',
    code: 'AUDIT_IMMUTABLE',
    message: 'Security audit logs are append-only and cannot be modified or deleted through application APIs.',
  });
});

// 4. CENTRALIZED SYSTEM ADMIN SECURITY OVERVIEW & DASHBOARD TELEMETRY
router.get(
  '/security-dashboard',
  requirePermission('audit.read'),
  (req: AuthenticatedRequest, res: Response) => {
    const state = db.getState();
    const allLogs = state.auditLogs || [];
    const users = (state.systemUsers || []).map(({ password, passwordHash, mfaSecret, totpSecret, ...u }: any) => {
      const computed = computeEffectivePermissions(u.role || 'REGULAR_MEMBER', u.additionalRoles || [], u.deniedPermissions || []);
      return {
        ...u,
        role: computed.primaryRole,
        primaryRole: computed.primaryRole,
        additionalRoles: computed.additionalRoles,
        roles: computed.allRoles,
        effectivePermissions: computed.effectivePermissions,
      };
    });
    const sessions = securityAuditService.listSessions();
    const alerts = securityAuditService.getAlerts();
    const integrity = securityAuditService.verifyAuditTrailIntegrity();
    const secConfig = db.getSecurityConfig();
    const cookieStatus = getCookieSecurityStatus();
    const backupConfig = db.getBackupConfig();

    const nowMs = Date.now();
    const last24hMs = nowMs - 24 * 60 * 60 * 1000;
    const last7dMs = nowMs - 7 * 24 * 60 * 60 * 1000;

    const failedLogins24h = allLogs.filter(
      (l) =>
        new Date(l.timestamp).getTime() >= last24hMs &&
        (l.eventType === 'AUTH_LOGIN_FAILURE' ||
          l.eventType === 'MFA_VERIFICATION_FAILURE' ||
          l.action.toLowerCase().includes('failed') ||
          l.outcome === 'FAILURE')
    ).length;

    const failedLogins7d = allLogs.filter(
      (l) =>
        new Date(l.timestamp).getTime() >= last7dMs &&
        (l.eventType === 'AUTH_LOGIN_FAILURE' ||
          l.eventType === 'MFA_VERIFICATION_FAILURE' ||
          l.action.toLowerCase().includes('failed') ||
          l.outcome === 'FAILURE')
    ).length;

    const successfulLogins24h = allLogs.filter(
      (l) =>
        new Date(l.timestamp).getTime() >= last24hMs &&
        (l.eventType === 'AUTH_LOGIN_SUCCESS' ||
          l.eventType === 'MFA_VERIFICATION_SUCCESS' ||
          l.action.toLowerCase().includes('login authenticated') ||
          l.action.toLowerCase().includes('authentication success'))
    ).length;

    const blockedRequests24h = allLogs.filter(
      (l) =>
        new Date(l.timestamp).getTime() >= last24hMs &&
        (l.outcome === 'BLOCKED' ||
          l.eventType === 'UNAUTHORIZED_API_ACCESS' ||
          l.eventType === 'RATE_LIMIT_VIOLATION' ||
          l.eventType === 'TOKEN_INVALID_OR_EXPIRED')
    ).length;

    const privilegedAccounts = users.filter((u: any) =>
      (u.roles || [u.role]).some((r: string) =>
        ['SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER'].includes(r)
      )
    );

    const staffWithoutMfa = privilegedAccounts.filter(
      (u: any) => !u.mfaEnabled && !u.isMfaEnabled && !u.mfa_enabled
    );

    // Real configuration warnings derived from actual server state
    const configWarnings: { id: string; severity: 'HIGH' | 'MEDIUM' | 'LOW'; title: string; recommendation: string }[] = [];
    if (secConfig.mfaEnforcementMode !== 'enforced') {
      configWarnings.push({
        id: 'warn-mfa-policy',
        severity: 'MEDIUM',
        title: 'Global Staff MFA Enforcement is set to Optional',
        recommendation: 'Set MFA Enforcement Policy to "Enforced" in Security Configuration so all staff accounts require AAL2 TOTP.',
      });
    }
    if (staffWithoutMfa.length > 0) {
      configWarnings.push({
        id: 'warn-staff-unprotected',
        severity: 'MEDIUM',
        title: `${staffWithoutMfa.length} Privileged Staff Account(s) Have 2FA Disabled`,
        recommendation: `Enroll TOTP 2FA for: ${staffWithoutMfa.map((u: any) => u.email).slice(0, 4).join(', ')}.`,
      });
    }
    if (!backupConfig.enabled) {
      configWarnings.push({
        id: 'warn-backup-disabled',
        severity: 'HIGH',
        title: 'Automated Disaster Recovery Backup Scheduler is Disabled',
        recommendation: 'Enable automated daily backups to protect audit trail and church member records.',
      });
    }
    if (!integrity.verified) {
      configWarnings.push({
        id: 'warn-audit-chain',
        severity: 'HIGH',
        title: 'Audit Hash Chain Integrity Failure Detected',
        recommendation: integrity.failureReason || `Verify record ${integrity.brokenAtRecordId || 'unknown'} in the tamper-evident audit chain.`,
      });
    }
    if (integrity.legacyUnchainedRecords > 0) {
      configWarnings.push({
        id: 'warn-legacy-unchained-records',
        severity: 'LOW',
        title: `${integrity.legacyUnchainedRecords} Pre-Existing Legacy Record(s) Flagged (Unchained)`,
        recommendation: `Records (${integrity.legacyRecordIds.slice(0, 4).join(', ')}) were created prior to v2.0 SHA-256 hash chaining and are preserved read-only without rewriting historical hashes.`,
      });
    }
    const persistenceErrors = db.getPersistenceErrors();
    if (persistenceErrors.length > 0) {
      configWarnings.push({
        id: 'warn-persistence-errors',
        severity: 'HIGH',
        title: `${persistenceErrors.length} Database Persistence Error(s) Recorded`,
        recommendation: `Latest error at ${persistenceErrors[0].timestamp}: ${persistenceErrors[0].error}`,
      });
    }

    return res.json({
      success: true,
      timestamp: new Date().toISOString(),
      overview: {
        totalAuditEvents: allLogs.length,
        failedLogins24h,
        failedLogins7d,
        successfulLogins24h,
        blockedRequests24h,
        activeSessionsCount: sessions.filter((s) => s.status === 'ACTIVE').length,
        revokedSessionsCount: sessions.filter((s) => s.status === 'REVOKED').length,
        openAlertsCount: alerts.filter((a) => a.status === 'OPEN').length,
        privilegedAccountsCount: privilegedAccounts.length,
        staffMfaCoveragePercent:
          privilegedAccounts.length > 0
            ? Math.round(((privilegedAccounts.length - staffWithoutMfa.length) / privilegedAccounts.length) * 100)
            : 100,
        authArchitecture: {
          provider: isSupabaseConfigured ? 'Supabase Auth + Authoritative Backend RBAC' : 'Hybrid Express JWT + Authoritative Backend RBAC',
          storageEngine: isPgConfigured()
            ? 'PostgreSQL (DATABASE_URL) + Durable Local State Mirror'
            : isSupabaseConfigured
              ? 'Supabase PostgreSQL + Durable Local State Mirror'
              : 'Durable Atomic Disk Snapshot (cmms_db.json) + PostgreSQL Migration 024 Ready',
          tokenTransport: 'Bearer Header + HttpOnly SameSite=Lax Cookie Dual-Support',
          csrfProtection: 'Double-Submit CSRF Header (X-CSRF-Token) enforced on Cookie Auth mutations',
          sessionRevocationMechanism:
            'Durable server-side SHA-256 token hash revocation registry + profiles/app_metadata.session_revoked_at timestamp validation + Supabase global signOut',
        },
        configWarnings,
      },
      rbac: {
        rolesCatalog: Object.values(ROLES_CATALOG),
        rolePermissions: ROLE_PERMISSIONS,
        privilegedAccounts,
      },
      sessions,
      alerts,
      integrity,
      securityConfig: {
        ...secConfig,
        cookieSecurity: cookieStatus,
        rateLimits: [
          { category: 'auth-login', windowMinutes: 15, maxRequests: 10, scope: 'IP Address' },
          { category: 'password-reset-request', windowMinutes: 15, maxRequests: 5, scope: 'IP Address' },
          { category: 'password-reset-verify', windowMinutes: 15, maxRequests: 5, scope: 'IP Address' },
          { category: 'mfa-verify', windowMinutes: 10, maxRequests: 5, scope: 'User / IP' },
          { category: 'sensitive-admin', windowMinutes: 5, maxRequests: 30, scope: 'Authenticated Admin' },
          { category: 'general-authenticated', windowMinutes: 1, maxRequests: 180, scope: 'Authenticated User' },
        ],
        auditRetentionPolicy: {
          retentionDays: 2555, // 7 years compliance retention
          appendOnlyEnforcement: true,
          hashChainAlgorithm: 'SHA-256',
          backupScheduleEnabled: backupConfig.enabled,
          backupFrequency: backupConfig.frequency,
        },
      },
    });
  }
);

// 5. LIST ACTIVE & HISTORICAL SESSIONS (GET /api/audit/sessions)
router.get('/sessions', requirePermission('audit.read'), (req: AuthenticatedRequest, res: Response) => {
  const { status, userId, search } = req.query;
  const sessions = securityAuditService.listSessions({
    status: status ? String(status) : undefined,
    userId: userId ? String(userId) : undefined,
    search: search ? String(search) : undefined,
  });
  return res.json({
    success: true,
    sessions,
    revocationGuarantee:
      'Revoking a session immediately blacklists its SHA-256 token fingerprint on the backend and updates session_revoked_at so any subsequent API call with that token is rejected with 401 SESSION_REVOKED.',
  });
});

// 6. REVOKE A SPECIFIC SESSION BY SAFE SESSION ID (POST /api/audit/sessions/:sessionId/revoke)
router.post(
  '/sessions/:sessionId/revoke',
  requirePermission('users.manage'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    const operator = req.user!;
    const { sessionId } = req.params;
    const reason = req.body?.reason ? String(req.body.reason).trim() : 'Revoked by System Administrator via Security Dashboard';

    const revoked = securityAuditService.markSessionRevoked(
      sessionId,
      operator.email || operator.name,
      reason
    );

    if (!revoked) {
      return res.status(404).json({
        success: false,
        error: 'SESSION_NOT_FOUND',
        message: `Session ${sessionId} was not found in the active session registry.`,
      });
    }

    securityAuditService.recordEvent({
      req,
      eventType: 'SESSION_REVOKED',
      action: 'Session Revoked by Administrator',
      module: 'Session & Device Governance',
      details: `Administrator ${operator.name} (${operator.email}) revoked session ${revoked.sessionId} belonging to ${revoked.userEmail} (${revoked.device}, IP ${revoked.ipAddress}). Reason: ${reason}`,
      actorId: operator.id,
      actorEmail: operator.email,
      actorName: operator.name,
      actorRole: operator.role,
      targetUserId: revoked.userId,
      targetUserEmail: revoked.userEmail,
      outcome: 'SUCCESS',
      severity: 'HIGH',
      sessionId: revoked.sessionId,
    });

    return res.json({
      success: true,
      message: `Session ${revoked.sessionId} for ${revoked.userEmail} has been revoked immediately.`,
      session: {
        sessionId: revoked.sessionId,
        userEmail: revoked.userEmail,
        status: revoked.status,
        revokedAt: revoked.revokedAt,
        revokedBy: revoked.revokedBy,
        revocationReason: revoked.revocationReason,
      },
    });
  }
);

// 7. ACKNOWLEDGE OR RESOLVE A SECURITY ALERT (POST /api/audit/alerts/:alertId/status)
router.post(
  '/alerts/:alertId/status',
  requirePermission('system.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    const operator = req.user!;
    const { alertId } = req.params;
    const status = req.body?.status === 'RESOLVED' ? 'RESOLVED' : 'ACKNOWLEDGED';

    const updated = securityAuditService.updateAlertStatus(
      alertId,
      status,
      operator.email || operator.name
    );

    if (!updated) {
      return res.status(404).json({
        success: false,
        error: 'ALERT_NOT_FOUND',
        message: 'Security alert not found.',
      });
    }

    securityAuditService.recordEvent({
      req,
      eventType: 'PRIVILEGED_ADMIN_ACTION',
      action: `Security Alert ${status}`,
      module: 'Security Alerts & Incident Response',
      details: `Administrator ${operator.name} (${operator.email}) marked security alert "${updated.title}" (${updated.id}) as ${status}.`,
      actorId: operator.id,
      actorEmail: operator.email,
      actorName: operator.name,
      actorRole: operator.role,
      outcome: 'SUCCESS',
      severity: 'LOW',
    });

    return res.json({
      success: true,
      alert: updated,
    });
  }
);

// 8. VERIFY TAMPER-EVIDENT AUDIT HASH CHAIN (POST /api/audit/verify-integrity)
router.post(
  '/verify-integrity',
  requirePermission('audit.read'),
  (req: AuthenticatedRequest, res: Response) => {
    const operator = req.user!;
    const result = securityAuditService.verifyAuditTrailIntegrity();

    securityAuditService.recordEvent({
      req,
      eventType: 'AUDIT_INTEGRITY_VERIFIED',
      action: 'Audit Trail Hash Chain Verified',
      module: 'Audit Trail Integrity',
      details: `Administrator ${operator.name} (${operator.email}) executed cryptographic SHA-256 hash chain verification across ${result.totalRecords} audit records (${result.chainedRecords} chained). Status: ${result.verified ? 'VERIFIED INTACT' : 'BROKEN CHAIN'}`,
      actorId: operator.id,
      actorEmail: operator.email,
      actorName: operator.name,
      actorRole: operator.role,
      outcome: result.verified ? 'SUCCESS' : 'WARNING',
      severity: result.verified ? 'LOW' : 'CRITICAL',
    });

    return res.json({
      success: true,
      integrity: result,
    });
  }
);

// 9. AUTHORIZED & REDACTED SECURITY AUDIT REPORT EXPORT (GET /api/audit/export)
router.get(
  '/export',
  requirePermission('audit.read'),
  sensitiveAdminLimiter,
  (req: AuthenticatedRequest, res: Response) => {
    const operator = req.user!;
    const format = String(req.query.format || 'csv').toLowerCase();
    const allLogs = db.getState().auditLogs || [];

    const safeLogs = allLogs.map((l) => ({
      id: l.id,
      timestamp: l.timestamp,
      eventType: l.eventType || l.action,
      severity: l.severity || 'LOW',
      outcome: l.outcome || 'SUCCESS',
      actorId: l.actorId || l.userEmail,
      actorEmail: l.userEmail,
      actorName: l.userName || l.user || l.userEmail,
      actorRole: l.userRole,
      action: l.action,
      module: l.module,
      ipAddress: l.ipAddress,
      sessionId: l.sessionId || 'sess_system',
      correlationId: l.correlationId || '',
      prevHash: l.prevHash || '',
      integrityHash: l.integrityHash || '',
      details: redactSensitiveMetadata(l.details),
    }));

    securityAuditService.recordEvent({
      req,
      eventType: 'PRIVILEGED_ADMIN_ACTION',
      action: `Exported Security Audit Trail (${format.toUpperCase()})`,
      module: 'Audit Trail Compliance',
      details: `Administrator ${operator.name} (${operator.email}) exported ${safeLogs.length} redacted security audit records in ${format.toUpperCase()} format.`,
      actorId: operator.id,
      actorEmail: operator.email,
      actorName: operator.name,
      actorRole: operator.role,
      outcome: 'SUCCESS',
      severity: 'MEDIUM',
    });

    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="CMMS_Security_Audit_Report_${new Date().toISOString().slice(0, 10)}.json"`
      );
      return res.json({
        exportedAt: new Date().toISOString(),
        exportedBy: operator.email,
        totalRecords: safeLogs.length,
        integrity: securityAuditService.verifyAuditTrailIntegrity(),
        records: safeLogs,
      });
    }

    const headers = [
      'ID',
      'Timestamp',
      'EventType',
      'Severity',
      'Outcome',
      'ActorEmail',
      'ActorRole',
      'Action',
      'Module',
      'IPAddress',
      'SafeSessionID',
      'CorrelationID',
      'PrevHash',
      'IntegrityHash',
      'Details',
    ];
    const rows = safeLogs.map((r) =>
      [
        r.id,
        r.timestamp,
        r.eventType,
        r.severity,
        r.outcome,
        r.actorEmail,
        r.actorRole,
        r.action,
        r.module,
        r.ipAddress,
        r.sessionId,
        r.correlationId,
        r.prevHash,
        r.integrityHash,
        r.details,
      ]
        .map((val) => `"${String(val ?? '').replace(/"/g, '""')}"`)
        .join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="CMMS_Security_Audit_Report_${new Date().toISOString().slice(0, 10)}.csv"`
    );
    return res.send(csv);
  }
);

export default router;

