import { Router, Response } from 'express';
import { generateDevotionAI, generateSermonOutlinesAI } from '../gemini';
import { db } from '../db';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { auditLog } from '../utils/requestContext';

const router = Router();

// Enforce authentication across all AI operations
router.use(authenticateToken);

// Generate daily devotion via Gemini
router.post('/devotion', requirePermission('devotions.read'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const { topic, language } = req.body;
    const devotion = await generateDevotionAI(topic || "God's Unfailing Grace & Hope", language || 'English');
    auditLog(req, {
      action: 'AI Devotion Generation',
      module: 'Devotions',
      details: `Generated AI devotion on topic: "${topic || 'General'}"`,
    });
    return res.json(devotion);
  } catch (err: any) {
    console.error('AI Devotion generation error:', err);
    return res.status(500).json({
      error: 'Failed to generate devotion from AI backend. Please try again later.',
    });
  }
});

// Generate sermon outline via Gemini
router.post('/sermon-outline', requirePermission('pastoral.read'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const { title, passage } = req.body;
    if (!title) {
      return res.status(400).json({ error: 'Sermon title is required' });
    }
    const outline = await generateSermonOutlinesAI(title, passage || 'Romans 8:28-39');
    auditLog(req, {
      action: 'AI Sermon Outline',
      module: 'Pastoral Care',
      details: `Generated sermon outline for "${title}" (${passage})`,
    });
    return res.json(outline);
  } catch (err: any) {
    console.error('AI Sermon Outline error:', err);
    return res.status(500).json({
      error: 'Failed to generate sermon outline from AI backend. Please try again later.',
    });
  }
});

// Natural Language Database Query and Executive Report Generation (Tenant & Branch Isolated)
router.post('/query-report', requirePermission('reports.read'), async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const state = db.getState();
    
    // 1. Tenant Isolation
    let members = (state.members || []).filter((m) => !m.tenantId || m.tenantId === user.tenantId);
    let branches = (state.branches || []).filter((b) => !b.tenantId || b.tenantId === user.tenantId);
    let ministries = (state.ministries || []).filter((m) => !m.tenantId || m.tenantId === user.tenantId);
    let attendanceRecords = (state.attendanceRecords || []).filter((a) => !a.tenantId || a.tenantId === user.tenantId);

    // 2. Branch Isolation
    if (!user.branchIds.includes('*')) {
      members = members.filter((m) => user.branchIds.includes(m.branchId));
      branches = branches.filter((b) => user.branchIds.includes(b.id));
      attendanceRecords = attendanceRecords.filter((a) => !a.branchId || user.branchIds.includes(a.branchId));
    }

    const lower = prompt.toLowerCase();

    // Intelligent query analysis against authorized database entities
    let matchingMembers = [...members];
    let summaryInsights = '';

    if (lower.includes('choir') || lower.includes('worship')) {
      const choirMinistry = ministries.find((m) => m.name.toLowerCase().includes('choir') || m.name.toLowerCase().includes('worship'));
      if (choirMinistry) {
        matchingMembers = members.filter((m) => m.ministryIds?.includes(choirMinistry.id) || (m.ministriesJoinedNow || []).includes(choirMinistry.name));
        summaryInsights = `Filtered ${matchingMembers.length} choir and worship ministry members actively serving across campuses.`;
      }
    } else if (lower.includes('youth')) {
      matchingMembers = members.filter((m) => (m.age && m.age <= 30) || (m.ministriesJoinedNow || []).some(min => min.toLowerCase().includes('youth')));
      summaryInsights = `Found ${matchingMembers.length} youth members (ages <= 30) registered in your authorized jurisdiction.`;
    } else if (lower.includes('married') || lower.includes('spouse') || lower.includes('family')) {
      matchingMembers = members.filter((m) => m.maritalStatus === 'Married');
      summaryInsights = `Found ${matchingMembers.length} married members with mapped spouses and family records in the system.`;
    } else if (lower.includes('attendance') || lower.includes('sunday')) {
      summaryInsights = `Total recorded attendance records: ${attendanceRecords.length}. Average attendance score across membership: ${(members.reduce((a, b) => a + (b.attendanceScore || 0), 0) / (members.length || 1)).toFixed(1)}%.`;
    } else {
      summaryInsights = `Comprehensive database synthesis across ${members.length} members, ${ministries.length} active ministries, and ${branches.length} campuses.`;
    }

    auditLog(req, {
      action: 'AI Natural Language Report',
      module: 'Reports & Intelligence',
      details: `Executed query: "${prompt}"`,
    });

    return res.json({
      title: `Executive Intelligence Report: "${prompt}"`,
      timestamp: new Date().toISOString(),
      prompt,
      summaryInsights,
      statistics: {
        totalMembersCount: members.length,
        matchedMembersCount: matchingMembers.length,
        totalBranchesCount: branches.length,
        totalMinistriesCount: ministries.length,
        totalAttendanceRecordsCount: attendanceRecords.length,
        activeMembersCount: members.filter((m) => m.membershipStatus === 'Active').length,
        marriedMembersCount: members.filter((m) => m.maritalStatus === 'Married').length,
      },
      dataRows: matchingMembers.map((m) => ({
        id: m.id,
        memberIdNumber: m.memberIdNumber,
        fullName: `${m.title} ${m.firstName} ${m.lastName}`,
        gender: m.gender,
        maritalStatus: m.maritalStatus,
        spouseName: m.spouseName || 'N/A',
        primaryPhone: m.primaryPhone,
        branchId: m.branchId,
        membershipStatus: m.membershipStatus,
        attendanceScore: `${m.attendanceScore}%`,
        ministriesJoinedNow: (m.ministriesJoinedNow || []).join(', ') || 'General Fellowship',
      })),
    });
  } catch (err: any) {
    console.error('AI Query Report error:', err);
    return res.status(500).json({
      error: 'Failed to generate report from database. Please try again later.',
    });
  }
});

export default router;
