import { Router, Response } from 'express';
import crypto from 'crypto';
import { Branch, Ministry } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { socketService } from '../../src/services/socketService';
import { query, withTransaction } from '../pg';
import { isDatabaseUuid } from '../repositories/memberRepository';

const router = Router();
function userHasAnyRole(user:AuthenticatedRequest['user'],roles:string[]):boolean{
 return Boolean(user&&[user.role,...(user.roles||[]),...(user.additionalRoles||[])].some(r=>roles.includes(r)));
}
function canManageMinistry(user:AuthenticatedRequest['user'],ministry:MinistryDbRow):boolean{
 if(userHasAnyRole(user,['SYSTEM_ADMIN','PASTOR','MANAGER']))return true;
 return userHasAnyRole(user,['MINISTRY_LEADER'])&&(
  ministry.leader_user_id===user.id ||
  (Boolean(user.memberId)&&ministry.leader_member_id===user.memberId)
 );
}

// Apply authentication to all branch & ministry routes
router.use(authenticateToken);

// ==============================================================================
// BRANCHES - Enforce branches.read and branches.manage
// ==============================================================================
type BranchDbRow={id:string;tenant_id:string;code:string;name:string;city:string|null;phone:string|null;status:string;branch_data:Record<string,any>};
function mapBranchRow(r:BranchDbRow):Branch {
 return {...(r.branch_data||{}),id:r.id,tenantId:r.tenant_id,code:r.code,name:r.name,city:r.city||'',phone:r.phone||'',status:r.status} as Branch;
}
async function writeBranchAudit(user:AuthenticatedRequest['user'],action:string,details:string){
 if(!user||!isDatabaseUuid(user.id)||!isDatabaseUuid(user.tenantId))return;
 try{await query(`INSERT INTO public.audit_logs(tenant_id,user_id,user_email,user_name,user_role,action,module,details)
  VALUES($1::uuid,$2::uuid,$3,$4,$5,$6,'Branches',$7)`,[user.tenantId,user.id,user.email,user.name,user.role,action,details]);}
 catch(error){console.error('[Branch Audit] Failed:',error instanceof Error?error.message:error);}
}
const branchSelect='SELECT id,tenant_id,code,name,city,phone,status,branch_data FROM public.branches';

router.get('/',requirePermission('branches.read'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  const all=user.branchIds.includes('*');
  const ids=[...new Set([...user.branchIds.filter(isDatabaseUuid),...(isDatabaseUuid(user.branchId)?[user.branchId]:[])])];
  const result=all
   ?await query<BranchDbRow>(`${branchSelect} WHERE tenant_id=$1::uuid ORDER BY name`,[user.tenantId])
   :await query<BranchDbRow>(`${branchSelect} WHERE tenant_id=$1::uuid AND id=ANY($2::uuid[]) ORDER BY name`,[user.tenantId,ids]);
  return res.json(result.rows.map(mapBranchRow));
 }catch(error){next(error);}
});

router.post('/',requirePermission('branches.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!,input=req.body as Partial<Branch>;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  if(!input.name?.trim())return res.status(400).json({error:'Branch name is required.'});
  const code=input.code?.trim()||`BR-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  const duplicate=await query('SELECT id FROM public.branches WHERE tenant_id=$1::uuid AND lower(code)=lower($2)',[user.tenantId,code]);
  if(duplicate.rowCount)return res.status(409).json({error:'Branch code already exists in this tenant.'});
  const {id:_id,tenantId:_tenant,code:_code,name:_name,city:_city,phone:_phone,status:_status,...extra}=input as any;
  const result=await query<BranchDbRow>(
   `INSERT INTO public.branches(tenant_id,code,name,city,phone,status,branch_data)
    VALUES($1::uuid,$2,$3,$4,$5,$6,$7::jsonb)
    RETURNING id,tenant_id,code,name,city,phone,status,branch_data`,
   [user.tenantId,code,input.name.trim(),input.city||null,input.phone||null,input.status||'Active',JSON.stringify(extra)]);
  const branch=mapBranchRow(result.rows[0]);
  await writeBranchAudit(user,'CREATE',`Created branch ${branch.name} (${branch.code})`);
  return res.status(201).json(branch);
 }catch(error){next(error);}
});

router.put('/:id',requirePermission('branches.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and branch UUIDs are required.'});
  const current=await query<BranchDbRow>(`${branchSelect} WHERE id=$1::uuid AND tenant_id=$2::uuid`,[req.params.id,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Branch not found'});
  const existing=mapBranchRow(current.rows[0]),merged={...existing,...req.body,id:existing.id,tenantId:user.tenantId} as Branch;
  const {id:_id,tenantId:_tenant,code:_code,name:_name,city:_city,phone:_phone,status:_status,...extra}=merged as any;
  const result=await query<BranchDbRow>(
   `UPDATE public.branches SET code=$3,name=$4,city=$5,phone=$6,status=$7,branch_data=$8::jsonb,updated_at=now()
    WHERE id=$1::uuid AND tenant_id=$2::uuid
    RETURNING id,tenant_id,code,name,city,phone,status,branch_data`,
   [req.params.id,user.tenantId,merged.code,merged.name,merged.city||null,merged.phone||null,merged.status||'Active',JSON.stringify(extra)]);
  const saved=mapBranchRow(result.rows[0]);
  await writeBranchAudit(user,'UPDATE',`Updated branch ${saved.name} (${saved.code})`);
  return res.json(saved);
 }catch(error){next(error);}
});

router.delete('/:id',requirePermission('branches.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and branch UUIDs are required.'});
  const result=await query<BranchDbRow>(
   `UPDATE public.branches SET status='Inactive',updated_at=now()
    WHERE id=$1::uuid AND tenant_id=$2::uuid
    RETURNING id,tenant_id,code,name,city,phone,status,branch_data`,
   [req.params.id,user.tenantId]);
  if(!result.rows[0])return res.status(404).json({error:'Branch not found'});
  await writeBranchAudit(user,'DEACTIVATE',`Deactivated branch ${result.rows[0].name} (${result.rows[0].code})`);
  return res.json({success:true,deactivated:true,branchId:req.params.id});
 }catch(error){next(error);}
});

// ==============================================================================
// MINISTRIES - Enforce ministries.read and ministries.manage
// ==============================================================================
type MinistryDbRow={id:string;tenant_id:string;branch_id:string|null;name:string;category:string|null;leader_name:string|null;leader_user_id:string|null;leader_member_id:string|null;meeting_day:string|null;status:string;ministry_data:Record<string,any>;member_ids:string[];member_count:number};
function mapMinistryRow(r:MinistryDbRow):Ministry {
 const d=r.ministry_data||{};
 return {...d,id:r.id,tenantId:r.tenant_id,branchId:r.branch_id||'',name:r.name,category:r.category||d.category||'General',
  leaderName:r.leader_name||d.leaderName||'Unassigned',leaderUserId:r.leader_user_id||undefined,leaderMemberId:r.leader_member_id||undefined,meetingSchedule:r.meeting_day||d.meetingSchedule,
  status:(r.status||'Active') as Ministry['status'],memberIds:r.member_ids||[],memberCount:Number(r.member_count||0)} as Ministry;
}
async function validateMinistryScope(tenantId:string,branchId:string,memberIds:string[]):Promise<void>{
 const branch=await query('SELECT id FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid',[branchId,tenantId]);
 if(!branch.rowCount)throw new Error('Selected branch does not belong to the authenticated tenant.');
 const ids=[...new Set(memberIds)];
 if(ids.some(id=>!isDatabaseUuid(id)))throw new Error('Ministry member links must use valid member UUIDs.');
 if(ids.length){
  const members=await query('SELECT id FROM public.members WHERE tenant_id=$1::uuid AND id=ANY($2::uuid[])',[tenantId,ids]);
  if(members.rowCount!==ids.length)throw new Error('One or more ministry members do not belong to this tenant.');
 }
}
const ministrySelect=`SELECT m.id,m.tenant_id,m.branch_id,m.name,m.category,m.leader_name,m.leader_user_id,m.leader_member_id,m.meeting_day,m.status,m.ministry_data,
 COALESCE(array_agg(mm.member_id) FILTER (WHERE mm.member_id IS NOT NULL),ARRAY[]::uuid[])::text[] AS member_ids,
 COUNT(mm.member_id)::int AS member_count
 FROM public.ministries m LEFT JOIN public.ministry_members mm ON mm.ministry_id=m.id`;

router.get('/ministries/all',requirePermission('ministries.read'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  const privileged=userHasAnyRole(user,['SYSTEM_ADMIN','PASTOR','MANAGER']);
  const rows=await query<MinistryDbRow>(
   `${ministrySelect} WHERE m.tenant_id=$1::uuid
      AND ($2::boolean OR m.leader_user_id=$3::uuid OR m.leader_member_id=$4::uuid
        OR EXISTS(SELECT 1 FROM public.ministry_members own WHERE own.ministry_id=m.id AND own.member_id=$4::uuid))
     GROUP BY m.id ORDER BY m.name`,
   [user.tenantId,privileged,user.id,isDatabaseUuid(user.memberId)?user.memberId:null]);
  return res.json(rows.rows.map(mapMinistryRow));
 }catch(error){next(error);}
});

router.post('/ministries',requirePermission('ministries.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!,input=req.body as Partial<Ministry>;
  if(!userHasAnyRole(user,['SYSTEM_ADMIN','PASTOR','MANAGER']))return res.status(403).json({error:'Only church administrators or pastors can create ministries.'});
  if(!isDatabaseUuid(user.tenantId))return res.status(400).json({error:'A valid tenant UUID is required.'});
  if(!input.name?.trim())return res.status(400).json({error:'Ministry name is required.'});
  const branchId=isDatabaseUuid(input.branchId)?input.branchId:user.branchId;
  if(!isDatabaseUuid(branchId))return res.status(400).json({error:'A valid branch UUID is required.'});
  const memberIds=Array.isArray(input.memberIds)?input.memberIds:[];
  await validateMinistryScope(user.tenantId,branchId,memberIds);
  const duplicate=await query('SELECT id FROM public.ministries WHERE tenant_id=$1::uuid AND lower(name)=lower($2) LIMIT 1',[user.tenantId,input.name.trim()]);
  if(duplicate.rowCount)return res.status(409).json({error:'A ministry with this name already exists in this church.',code:'DUPLICATE_MINISTRY_NAME'});
  const {id:_id,tenantId:_tenant,branchId:_branch,name:_name,category:_category,leaderName:_leader,...extra}=input as any;
  const saved=await withTransaction(async client=>{
   const inserted=await client.query<MinistryDbRow>(
    `INSERT INTO public.ministries(tenant_id,branch_id,name,category,leader_name,leader_user_id,leader_member_id,meeting_day,status,ministry_data)
     VALUES($1::uuid,$2::uuid,$3,$4,$5,$6::uuid,$7::uuid,$8,$9,$10::jsonb)
     RETURNING id,tenant_id,branch_id,name,category,leader_name,leader_user_id,leader_member_id,meeting_day,status,ministry_data,ARRAY[]::text[] AS member_ids,0::int AS member_count`,
    [user.tenantId,branchId,input.name.trim(),input.category||'General',input.leaderName||null,
     isDatabaseUuid(input.leaderUserId)?input.leaderUserId:null,
     isDatabaseUuid(input.leaderMemberId||input.directorMemberId)?(input.leaderMemberId||input.directorMemberId):null,
     input.meetingSchedule||input.meetingTime||null,input.status||'Active',JSON.stringify(extra)]);
   const ministryId=inserted.rows[0].id;
   if(memberIds.length)await client.query(
    `INSERT INTO public.ministry_members(ministry_id,member_id,role) SELECT $1::uuid,x::uuid,'Member' FROM unnest($2::text[]) x ON CONFLICT DO NOTHING`,
    [ministryId,memberIds]);
   return {...inserted.rows[0],member_ids:memberIds,member_count:memberIds.length};
  });
  const ministry=mapMinistryRow(saved);
  try{socketService.emitToAll('ministry:created',ministry);}catch{}
  return res.status(201).json(ministry);
 }catch(error){next(error);}
});

router.put('/ministries/:id',requirePermission('ministries.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!,id=req.params.id,input=req.body as Partial<Ministry>;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(id))return res.status(400).json({error:'Valid tenant and ministry UUIDs are required.'});
  const current=await query<MinistryDbRow>(`${ministrySelect} WHERE m.id=$1::uuid AND m.tenant_id=$2::uuid GROUP BY m.id`,[id,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Ministry not found'});
  const existingRow=current.rows[0];
  if(!canManageMinistry(user,existingRow))return res.status(403).json({error:'You can manage only ministries assigned to you.'});
  const existing=mapMinistryRow(existingRow);
  const merged={...existing,...input,id,tenantId:user.tenantId} as Ministry;
  const branchId=isDatabaseUuid(merged.branchId)?merged.branchId:existing.branchId;
  if(!isDatabaseUuid(branchId))return res.status(400).json({error:'A valid branch UUID is required.'});
  const memberIds=Array.isArray(merged.memberIds)?merged.memberIds:[];
  await validateMinistryScope(user.tenantId,branchId,memberIds);
  const {id:_id,tenantId:_tenant,branchId:_branch,name:_name,category:_category,leaderName:_leader,memberIds:_members,memberCount:_count,...extra}=merged as any;
  const saved=await withTransaction(async client=>{
   const updated=await client.query<MinistryDbRow>(
    `UPDATE public.ministries SET branch_id=$3::uuid,name=$4,category=$5,leader_name=$6,leader_user_id=$7::uuid,leader_member_id=$8::uuid,meeting_day=$9,status=$10,ministry_data=$11::jsonb
     WHERE id=$1::uuid AND tenant_id=$2::uuid
     RETURNING id,tenant_id,branch_id,name,category,leader_name,leader_user_id,leader_member_id,meeting_day,status,ministry_data,ARRAY[]::text[] AS member_ids,0::int AS member_count`,
    [id,user.tenantId,branchId,merged.name,merged.category||null,merged.leaderName||null,
     isDatabaseUuid(merged.leaderUserId)?merged.leaderUserId:null,
     isDatabaseUuid(merged.leaderMemberId||merged.directorMemberId)?(merged.leaderMemberId||merged.directorMemberId):null,
     merged.meetingSchedule||merged.meetingTime||null,merged.status||'Active',JSON.stringify(extra)]);
   await client.query('DELETE FROM public.ministry_members WHERE ministry_id=$1::uuid',[id]);
   if(memberIds.length)await client.query(
    `INSERT INTO public.ministry_members(ministry_id,member_id,role) SELECT $1::uuid,x::uuid,'Member' FROM unnest($2::text[]) x`,
    [id,memberIds]);
   return {...updated.rows[0],member_ids:memberIds,member_count:memberIds.length};
  });
  const ministry=mapMinistryRow(saved);
  try{socketService.emitToAll('ministry:updated',ministry);}catch{}
  return res.json(ministry);
 }catch(error){next(error);}
});

router.delete('/ministries/:id',requirePermission('ministries.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.id))return res.status(400).json({error:'Valid tenant and ministry UUIDs are required.'});
  const current=await query<MinistryDbRow>(`${ministrySelect} WHERE m.id=$1::uuid AND m.tenant_id=$2::uuid GROUP BY m.id`,[req.params.id,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Ministry not found'});
  if(!canManageMinistry(user,current.rows[0]))return res.status(403).json({error:'You can manage only ministries assigned to you.'});
  if(!userHasAnyRole(user,['SYSTEM_ADMIN','PASTOR','MANAGER']))return res.status(403).json({error:'Only church administrators or pastors can deactivate a ministry.'});
  const result=await query(
   `UPDATE public.ministries SET status='Inactive' WHERE id=$1::uuid AND tenant_id=$2::uuid RETURNING id`,
   [req.params.id,user.tenantId]);
  if(!result.rowCount)return res.status(404).json({error:'Ministry not found'});
  try{socketService.emitToAll('ministry:deleted',{id:req.params.id,softDeleted:true});}catch{}
  return res.json({success:true,deletedId:req.params.id,deactivated:true});
 }catch(error){next(error);}
});

router.delete('/ministries/:minId/sub/:subId',requirePermission('ministries.manage'),async(req:AuthenticatedRequest,res:Response,next)=>{
 try{
  const user=req.user!;
  if(!isDatabaseUuid(user.tenantId)||!isDatabaseUuid(req.params.minId))return res.status(400).json({error:'Valid tenant and ministry UUIDs are required.'});
  const current=await query<MinistryDbRow>(`${ministrySelect} WHERE m.id=$1::uuid AND m.tenant_id=$2::uuid GROUP BY m.id`,[req.params.minId,user.tenantId]);
  if(!current.rows[0])return res.status(404).json({error:'Ministry not found'});
  if(!canManageMinistry(user,current.rows[0]))return res.status(403).json({error:'You can manage only ministries assigned to you.'});
  const mapped=mapMinistryRow(current.rows[0]);
  const subMinistries=(mapped.subMinistries||[]).filter(s=>s.id!==req.params.subId);
  const {id:_id,tenantId:_tenant,branchId:_branch,name:_name,category:_category,leaderName:_leader,memberIds:_members,memberCount:_count,...extra}=mapped as any;
  extra.subMinistries=subMinistries;
  await query('UPDATE public.ministries SET ministry_data=$3::jsonb WHERE id=$1::uuid AND tenant_id=$2::uuid',[req.params.minId,user.tenantId,JSON.stringify(extra)]);
  return res.json({...mapped,subMinistries});
 }catch(error){next(error);}
});

export default router;
