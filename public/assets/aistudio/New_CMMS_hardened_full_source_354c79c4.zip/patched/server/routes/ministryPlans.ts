import { Router, Response } from 'express';
import { db } from '../db';
import { query } from '../pg';
import { getAdminClient, isSupabaseConfigured } from '../../src/lib/supabase';
import {
  authenticateToken,
  AuthenticatedRequest,
  hasPermission,
} from '../../src/security/authorization';
import {
  MinistryAnnualPlan,
  MinistryPlanWorkflowStatus,
  MinistryPlanReviewComment,
  MinistryQuarterlyReport,
  MinistryAnnualReport,
} from '../../src/types';
import {
  generateQuarterlyAndMonthlySchedule,
  aggregateQuarterlyReportsIntoAnnualReport,
  buildMinistryPlanPdfBuffer,
  buildMinistryPlanXlsxBuffer,
} from '../../src/utils/ministryPlanningEngine';
import { socketService } from '../../src/services/socketService';
import { listMinistryAnnualPlans, getMinistryAnnualPlanById } from '../repositories/ministryPlanReadRepository';
import { saveMinistryAnnualPlan } from '../repositories/ministryPlanWriteRepository';
import { persistMinistryPlanAuditLog } from '../repositories/ministryPlanAuditRepository';

const router = Router();

async function ensurePostgresMinistryPlanTables(): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false;
  try {
    // Schema is managed exclusively by reviewed migrations. Never run DDL from an API request.
    const result = await query(
      `SELECT
         to_regclass('public.ministry_annual_plans') AS plans,
         to_regclass('public.ministry_plan_reviews') AS reviews,
         to_regclass('public.ministry_quarterly_reports') AS quarterly_reports,
         to_regclass('public.ministry_annual_reports') AS annual_reports`
    );
    const schema = result.rows[0];
    return Boolean(schema?.plans && schema?.reviews && schema?.quarterly_reports && schema?.annual_reports);
  } catch (err: any) {
    console.warn('[MinistryPlans PG Schema Check]:', err?.message || err);
    return false;
  }
}

async function syncPlanToPostgres(plan: MinistryAnnualPlan): Promise<void> {
  // Never persist a plan without explicit authenticated tenant and branch scope.
  if (!plan.tenantId || !plan.branchId) {
    throw new Error('Ministry plan persistence requires tenantId and branchId.');
  }
  // 1. Direct PostgreSQL pool if DATABASE_URL is configured
  if (process.env.DATABASE_URL) {
    try {
      const ready = await ensurePostgresMinistryPlanTables();
      if (ready) {
        await query(
          `INSERT INTO public.ministry_annual_plans (
            id, plan_code, tenant_id, branch_id, ministry_id, ministry_name, year, title,
            vision_statement, objectives, activities, responsible_person, responsible_person_id,
            target_audience, expected_participants, required_resources, optional_budget, currency,
            kpis, expected_outcomes, risks, mitigation_summary, quarterly_milestones, monthly_activities,
            status, revision_number, submitted_by, submitted_by_name, submitted_at,
            reviewed_by, reviewed_by_name, reviewed_at, approved_by, approved_by_name, approved_at,
            returned_reason, rejected_reason, review_history, quarterly_reports, annual_report,
            created_at, updated_at
          ) VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,$11::jsonb,$12,$13,$14,$15,$16,$17,$18,
            $19::jsonb,$20::jsonb,$21::jsonb,$22,$23::jsonb,$24::jsonb,$25,$26,$27,$28,$29,
            $30,$31,$32,$33,$34,$35,$36,$37,$38::jsonb,$39::jsonb,$40::jsonb,$41,$42
          )
          ON CONFLICT (id) DO UPDATE SET
            title = EXCLUDED.title,
            vision_statement = EXCLUDED.vision_statement,
            objectives = EXCLUDED.objectives,
            activities = EXCLUDED.activities,
            responsible_person = EXCLUDED.responsible_person,
            target_audience = EXCLUDED.target_audience,
            expected_participants = EXCLUDED.expected_participants,
            required_resources = EXCLUDED.required_resources,
            optional_budget = EXCLUDED.optional_budget,
            kpis = EXCLUDED.kpis,
            expected_outcomes = EXCLUDED.expected_outcomes,
            risks = EXCLUDED.risks,
            mitigation_summary = EXCLUDED.mitigation_summary,
            quarterly_milestones = EXCLUDED.quarterly_milestones,
            monthly_activities = EXCLUDED.monthly_activities,
            status = EXCLUDED.status,
            revision_number = EXCLUDED.revision_number,
            submitted_by = EXCLUDED.submitted_by,
            submitted_by_name = EXCLUDED.submitted_by_name,
            submitted_at = EXCLUDED.submitted_at,
            reviewed_by = EXCLUDED.reviewed_by,
            reviewed_by_name = EXCLUDED.reviewed_by_name,
            reviewed_at = EXCLUDED.reviewed_at,
            approved_by = EXCLUDED.approved_by,
            approved_by_name = EXCLUDED.approved_by_name,
            approved_at = EXCLUDED.approved_at,
            returned_reason = EXCLUDED.returned_reason,
            rejected_reason = EXCLUDED.rejected_reason,
            review_history = EXCLUDED.review_history,
            quarterly_reports = EXCLUDED.quarterly_reports,
            annual_report = EXCLUDED.annual_report,
            updated_at = now()`,
          [
            plan.id,
            plan.planCode,
            plan.tenantId,
            plan.branchId,
            plan.ministryId,
            plan.ministryName,
            plan.year,
            plan.title,
            plan.visionStatement || '',
            JSON.stringify(plan.objectives || []),
            JSON.stringify(plan.activities || []),
            plan.responsiblePerson,
            plan.responsiblePersonId || null,
            plan.targetAudience,
            plan.expectedParticipants || 0,
            plan.requiredResources || '',
            plan.optionalBudget || 0,
            plan.currency || 'ETB',
            JSON.stringify(plan.kpis || []),
            JSON.stringify(plan.expectedOutcomes || []),
            JSON.stringify(plan.risks || []),
            plan.mitigationSummary || '',
            JSON.stringify(plan.quarterlyMilestones || []),
            JSON.stringify(plan.monthlyActivities || []),
            plan.status,
            plan.revisionNumber || 1,
            plan.submittedBy || null,
            plan.submittedByName || null,
            plan.submittedAt || null,
            plan.reviewedBy || null,
            plan.reviewedByName || null,
            plan.reviewedAt || null,
            plan.approvedBy || null,
            plan.approvedByName || null,
            plan.approvedAt || null,
            plan.returnedReason || null,
            plan.rejectedReason || null,
            JSON.stringify(plan.reviewHistory || []),
            JSON.stringify(plan.quarterlyReports || []),
            plan.annualReport ? JSON.stringify(plan.annualReport) : null,
            plan.createdAt || new Date().toISOString(),
            new Date().toISOString(),
          ]
        );
      }
    } catch (err: any) {
      console.error('[MinistryPlans PostgreSQL Persistence Failed]:', err?.message || err);
      throw err;
    }
  }

  // 2. Supabase PostgreSQL sync if configured
  if (isSupabaseConfigured) {
    try {
      const admin = getAdminClient();
      await admin.from('ministry_annual_plans').upsert(
        {
          id: plan.id,
          plan_code: plan.planCode,
          tenant_id: plan.tenantId,
          branch_id: plan.branchId,
          ministry_id: plan.ministryId,
          ministry_name: plan.ministryName,
          year: plan.year,
          title: plan.title,
          vision_statement: plan.visionStatement || '',
          objectives: plan.objectives || [],
          activities: plan.activities || [],
          responsible_person: plan.responsiblePerson,
          target_audience: plan.targetAudience,
          expected_participants: plan.expectedParticipants || 0,
          required_resources: plan.requiredResources || '',
          optional_budget: plan.optionalBudget || 0,
          currency: plan.currency || 'ETB',
          kpis: plan.kpis || [],
          expected_outcomes: plan.expectedOutcomes || [],
          risks: plan.risks || [],
          mitigation_summary: plan.mitigationSummary || '',
          quarterly_milestones: plan.quarterlyMilestones || [],
          monthly_activities: plan.monthlyActivities || [],
          status: plan.status,
          revision_number: plan.revisionNumber || 1,
          submitted_by: plan.submittedBy || null,
          submitted_by_name: plan.submittedByName || null,
          submitted_at: plan.submittedAt || null,
          reviewed_by: plan.reviewedBy || null,
          reviewed_by_name: plan.reviewedByName || null,
          reviewed_at: plan.reviewedAt || null,
          approved_by: plan.approvedBy || null,
          approved_by_name: plan.approvedByName || null,
          approved_at: plan.approvedAt || null,
          returned_reason: plan.returnedReason || null,
          rejected_reason: plan.rejectedReason || null,
          review_history: plan.reviewHistory || [],
          quarterly_reports: plan.quarterlyReports || [],
          annual_report: plan.annualReport || null,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );
    } catch (err: any) {
      console.error('[MinistryPlans Supabase Persistence Failed]:', err?.message || err);
      throw err;
    }
  }
}

async function recordPlanningAuditLog(
  req: AuthenticatedRequest,
  action: string,
  details: string,
  commitData?: Record<string, any>
): Promise<void> {
  const user = req.user;
  const logEntry = db.addAuditLog({
    userEmail: user?.email || '',
    userName: user?.name || 'Authenticated User',
    userRole: (user?.role as any) || 'MINISTRY_LEADER',
    action,
    module: 'Ministry Annual Planning & Reporting',
    details,
    ipAddress: req.ip || '127.0.0.1',
    commitData: commitData ? JSON.stringify(commitData) : undefined,
  });

  // Persist to PostgreSQL before returning success when the application uses PostgreSQL.
  if (process.env.DATABASE_URL) {
    await persistMinistryPlanAuditLog(logEntry, user?.tenantId || '');
  }
}

function getPlansStore(): MinistryAnnualPlan[] {
  const state = db.getState();
  if (!Array.isArray(state.ministryAnnualPlans)) {
    state.ministryAnnualPlans = [];
    db.persist();
  }
  return state.ministryAnnualPlans;
}

function isPlanWithinAuthenticatedScope(plan: MinistryAnnualPlan, user: AuthenticatedRequest['user']): boolean {
  if (!user || !plan.tenantId || plan.tenantId !== user.tenantId) return false;
  const authorizedBranches = new Set([...(user.branchIds || []), user.branchId].filter(Boolean));
  if (authorizedBranches.has('*')) return true;
  return Boolean(plan.branchId && authorizedBranches.has(plan.branchId));
}

function isPastorOrReviewer(user: AuthenticatedRequest['user']): boolean {
  if (!user) return false;
  const roles = [user.role, ...(user.additionalRoles || []), ...(user.roles || [])].map((r) =>
    String(r || '').toUpperCase()
  );
  return (
    roles.includes('PASTOR') ||
    roles.includes('SYSTEM_ADMIN') ||
    roles.includes('MANAGER') ||
    hasPermission(user, 'workflows.manage')
  );
}

function isMinistryLeaderOrAuthorized(user: AuthenticatedRequest['user']): boolean {
  if (!user) return false;
  const roles = [user.role, ...(user.additionalRoles || []), ...(user.roles || [])].map((r) =>
    String(r || '').toUpperCase()
  );
  return (
    roles.includes('MINISTRY_LEADER') ||
    roles.includes('PASTOR') ||
    roles.includes('MANAGER') ||
    roles.includes('SYSTEM_ADMIN') ||
    hasPermission(user, 'ministries.read')
  );
}

// Require authentication for all Ministry Annual Planning & Reporting routes
router.use(authenticateToken);

// 1. GET ALL MINISTRY ANNUAL PLANS (with optional filters: ministryId, year, status)
router.get('/', async (req: AuthenticatedRequest, res: Response) => {
  const { ministryId, year, status } = req.query;
  const user = req.user!;
  let plans = getPlansStore().filter((plan) => isPlanWithinAuthenticatedScope(plan, user));

  if (process.env.DATABASE_URL) {
    try {
      const ready = await ensurePostgresMinistryPlanTables();
      if (ready) {
        const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
        const databasePlans = await listMinistryAnnualPlans({ tenantId: user.tenantId, branchIds });
        const byId = new Map(plans.map((plan) => [plan.id, plan]));
        for (const plan of databasePlans) byId.set(plan.id, plan);
        plans = Array.from(byId.values());
      }
    } catch (error: any) {
      console.error('[MinistryPlans List Read Failed]:', error?.message || error);
      return res.status(503).json({ error: 'Unable to retrieve ministry plans from the database.' });
    }
  }

  if (ministryId && ministryId !== 'all') plans = plans.filter((plan) => plan.ministryId === String(ministryId));
  if (year && year !== 'all') plans = plans.filter((plan) => Number(plan.year) === Number(year));
  if (status && status !== 'all') plans = plans.filter((plan) => plan.status.toLowerCase() === String(status).toLowerCase());

  return res.json({ success: true, count: plans.length, plans });
});

// 2. GET SINGLE MINISTRY ANNUAL PLAN BY ID
router.get('/:id', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  const localPlan = plans.find((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user));
  if (localPlan) return res.json({ success: true, plan: localPlan });

  if (!process.env.DATABASE_URL) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }

  try {
    const ready = await ensurePostgresMinistryPlanTables();
    if (!ready) {
      return res.status(503).json({ error: 'Ministry planning database schema is not ready.' });
    }

    const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
    const plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
    if (!plan) return res.status(404).json({ error: 'Ministry annual plan not found' });
    return res.json({ success: true, plan });
  } catch (error: any) {
    console.error('[MinistryPlans Detail Read]:', error?.message || error);
    return res.status(500).json({ error: 'Unable to retrieve ministry annual plan.' });
  }
});
// 3. CREATE NEW MINISTRY ANNUAL PLAN (Auto-generates Q1-Q4 & 12-Month Timeline)
router.post('/', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  if (!isMinistryLeaderOrAuthorized(user)) {
    return res.status(403).json({ error: 'Only Ministry Leaders, Pastors, or Administrators can create annual ministry plans.' });
  }

  const body = req.body || {};
  const ministries = db.getState().ministries || [];
  const matchedMinistry = ministries.find((m) => m.id === body.ministryId || m.name === body.ministryName);
  const ministryId = body.ministryId || matchedMinistry?.id || 'min-1';
  const ministryName = body.ministryName || matchedMinistry?.name || 'Church Ministry Department';
  const requestedBranchId = body.branchId || matchedMinistry?.branchId || user.branchId;
  const allowedBranchIds = new Set([...(user.branchIds || []), user.branchId].filter(Boolean));
  if (!requestedBranchId || (!allowedBranchIds.has('*') && !allowedBranchIds.has(requestedBranchId))) {
    return res.status(403).json({ error: 'You cannot create a ministry plan outside your assigned branch scope.' });
  }
  const year = Number(body.year) || new Date().getFullYear();
  const responsiblePerson = body.responsiblePerson || user.name || 'Ministry Leader';
  const expectedParticipants = Number(body.expectedParticipants) || 250;
  const requiredResources = body.requiredResources || 'Sanctuary / Hall Facilities, Audio-Visual Equipment, Volunteer Team';
  const optionalBudget = Number(body.optionalBudget) || 0;
  const objectives = Array.isArray(body.objectives) ? body.objectives : [];
  const activities = Array.isArray(body.activities) ? body.activities : [];

  // Auto-generate Q1-Q4 and 12-month timeline if not explicitly provided
  const generatedSchedule = generateQuarterlyAndMonthlySchedule({
    ministryName,
    year,
    objectives,
    activities,
    responsiblePerson,
    expectedParticipants,
    requiredResources,
    optionalBudget,
  });

  const quarterlyMilestones =
    Array.isArray(body.quarterlyMilestones) && body.quarterlyMilestones.length === 4
      ? body.quarterlyMilestones
      : generatedSchedule.quarterlyMilestones;

  const monthlyActivities =
    Array.isArray(body.monthlyActivities) && body.monthlyActivities.length === 12
      ? body.monthlyActivities
      : generatedSchedule.monthlyActivities;

  const initialStatus: MinistryPlanWorkflowStatus =
    body.submitImmediately === true ? 'Submitted' : (body.status as MinistryPlanWorkflowStatus) || 'Draft';

  const nowIso = new Date().toISOString();
  const planCode =
    body.planCode ||
    `MAP-${year}-${ministryName.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'MIN'}-${Math.floor(10 + Math.random() * 89)}`;

  const newPlan: MinistryAnnualPlan = {
    id: body.id || `mplan-${year}-${Date.now().toString().slice(-6)}`,
    planCode,
    tenantId: user.tenantId,
    branchId: requestedBranchId,
    ministryId,
    ministryName,
    year,
    title: body.title || `${ministryName} — ${year} Annual Ministry Plan`,
    visionStatement: body.visionStatement || `Advancing ${ministryName} objectives and kingdom impact in ${year}.`,
    objectives,
    activities,
    responsiblePerson,
    responsiblePersonId: user.id,
    targetAudience: body.targetAudience || 'Church Members & Local Community',
    expectedParticipants,
    requiredResources,
    optionalBudget,
    currency: body.currency || 'ETB',
    kpis: Array.isArray(body.kpis) ? body.kpis : [],
    expectedOutcomes: Array.isArray(body.expectedOutcomes) ? body.expectedOutcomes : [],
    risks: Array.isArray(body.risks) ? body.risks : [],
    mitigationSummary: body.mitigationSummary || '',
    quarterlyMilestones,
    monthlyActivities,
    status: initialStatus,
    revisionNumber: 1,
    submittedBy: user.id,
    submittedByName: user.name,
    submittedAt: initialStatus === 'Submitted' ? nowIso : undefined,
    reviewHistory:
      initialStatus === 'Submitted'
        ? [
            {
              id: `rev-${Date.now()}`,
              planId: body.id || '',
              reviewerId: user.id,
              reviewerName: user.name,
              reviewerRole: user.role,
              action: 'Submit',
              comment: 'Created and submitted annual ministry plan for pastoral review.',
              createdAt: nowIso,
            },
          ]
        : [],
    quarterlyReports: [],
    annualReport: null,
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  // PostgreSQL is the authoritative write. Update legacy JSON only after the DB transaction commits.
  await saveMinistryAnnualPlan(newPlan);
  const plans = getPlansStore();
  plans.unshift(newPlan);
  db.persist();

  await recordPlanningAuditLog(
    req,
    initialStatus === 'Submitted' ? 'Ministry Annual Plan Submitted' : 'Ministry Annual Plan Created (Draft)',
    `${user.name} (${user.role}) created ${newPlan.year} Annual Plan "${newPlan.title}" (${newPlan.planCode}) for ${newPlan.ministryName} with status "${newPlan.status}".`,
    { planId: newPlan.id, planCode: newPlan.planCode, status: newPlan.status, ministryId: newPlan.ministryId }
  );

  return res.status(201).json({
    success: true,
    message:
      initialStatus === 'Submitted'
        ? 'Annual ministry plan created and submitted to Pastor for review.'
        : 'Annual ministry plan saved as Draft with auto-generated Q1–Q4 and 12-month timeline.',
    plan: newPlan,
  });
});

// 4. UPDATE / REVISE MINISTRY ANNUAL PLAN
router.put('/:id', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  const idx = plans.findIndex((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, req.user));
  if (idx === -1) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }

  const existing = plans[idx];
  const body = req.body || {};

  // Regenerate Q1-Q4 and monthly timeline if requested
  let quarterlyMilestones = body.quarterlyMilestones ?? existing.quarterlyMilestones;
  let monthlyActivities = body.monthlyActivities ?? existing.monthlyActivities;

  if (body.regenerateSchedule === true) {
    const regen = generateQuarterlyAndMonthlySchedule({
      ministryName: body.ministryName || existing.ministryName,
      year: Number(body.year) || existing.year,
      objectives: body.objectives ?? existing.objectives,
      activities: body.activities ?? existing.activities,
      responsiblePerson: body.responsiblePerson ?? existing.responsiblePerson,
      expectedParticipants: Number(body.expectedParticipants ?? existing.expectedParticipants),
      requiredResources: body.requiredResources ?? existing.requiredResources,
      optionalBudget: Number(body.optionalBudget ?? existing.optionalBudget),
    });
    quarterlyMilestones = regen.quarterlyMilestones;
    monthlyActivities = regen.monthlyActivities;
  }

  const updated: MinistryAnnualPlan = {
    ...existing,
    ...body,
    id: existing.id,
    tenantId: existing.tenantId,
    branchId: existing.branchId,
    quarterlyMilestones,
    monthlyActivities,
    updatedAt: new Date().toISOString(),
  };

  // PostgreSQL is the authoritative write. Update legacy JSON only after the DB transaction commits.
  await saveMinistryAnnualPlan(updated);
  plans[idx] = updated;
  db.persist();

  await recordPlanningAuditLog(
    req,
    'Ministry Annual Plan Updated',
    `${user.name} updated ${updated.ministryName} (${updated.year}) Annual Plan [${updated.planCode}].`,
    { planId: updated.id, status: updated.status }
  );

  return res.json({
    success: true,
    message: 'Ministry annual plan updated in PostgreSQL.',
    plan: updated,
  });
});

// 5. SUBMIT OR REVISE & RESUBMIT PLAN (Ministry Leader Workflow: Draft / Returned for Revision -> Submitted)
router.post('/:id/submit', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  let idx = plans.findIndex((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user));
  let plan = idx >= 0 ? plans[idx] : null;

  // PostgreSQL is authoritative; load plans that are not in this process's legacy JSON cache.
  if (!plan && process.env.DATABASE_URL) {
    const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
    plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
  }
  if (!plan || !isPlanWithinAuthenticatedScope(plan, user)) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }
  const wasReturned = plan.status === 'Returned for Revision';
  const revisionNotes = (req.body?.comment || req.body?.revisionNotes || '').trim();
  const nowIso = new Date().toISOString();

  // Apply any updated fields included in the submission payload
  if (req.body?.planUpdates && typeof req.body.planUpdates === 'object') {
    Object.assign(plan, req.body.planUpdates);
  }

  plan.status = 'Submitted';
  if (wasReturned) {
    plan.revisionNumber = (plan.revisionNumber || 1) + 1;
    plan.returnedReason = undefined;
  }
  plan.submittedBy = user.id;
  plan.submittedByName = user.name;
  plan.submittedAt = nowIso;
  plan.updatedAt = nowIso;

  const entry: MinistryPlanReviewComment = {
    id: `rev-${Date.now()}`,
    planId: plan.id,
    reviewerId: user.id,
    reviewerName: user.name,
    reviewerRole: user.role,
    action: wasReturned ? 'Revise & Resubmit' : 'Submit',
    comment:
      revisionNotes ||
      (wasReturned
        ? `Revised returned plan (Revision v${plan.revisionNumber}) and resubmitted for pastoral approval.`
        : 'Submitted annual ministry plan for pastoral review.'),
    createdAt: nowIso,
  };
  plan.reviewHistory = [entry, ...(plan.reviewHistory || [])];

  // Commit submission/revision and review-history changes to PostgreSQL before touching the JSON cache.
  await saveMinistryAnnualPlan(plan);
  if (idx >= 0) {
    plans[idx] = plan;
    db.persist();
  }

  await recordPlanningAuditLog(
    req,
    wasReturned ? 'Ministry Annual Plan Revised & Resubmitted' : 'Ministry Annual Plan Submitted',
    `${user.name} (${user.role}) ${wasReturned ? `revised (v${plan.revisionNumber}) and resubmitted` : 'submitted'} "${plan.title}" (${plan.planCode}) for Pastoral Review. Notes: ${entry.comment}`,
    { planId: plan.id, planCode: plan.planCode, status: plan.status, revisionNumber: plan.revisionNumber }
  );

  const io = socketService.getIO();
  if (io) {
    io.emit('ministry_plan:updated', { planId: plan.id, status: plan.status, plan });
  }

  return res.json({
    success: true,
    message: wasReturned
      ? `Plan revised (v${plan.revisionNumber}) and resubmitted to Pastor.`
      : 'Annual plan submitted to Pastor for review.',
    plan,
  });
});

// 6. PASTORAL REVIEW WORKFLOW (Review / Comment / Return for Revision / Approve / Reject / Activate / Complete)
router.post('/:id/review', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { action, comment } = req.body || {};

  // Actions 'review', 'return', 'approve', 'reject', 'activate', 'complete' require Pastor / Admin / Manager authority
  const restrictedActions = ['review', 'return', 'approve', 'reject'];
  if (restrictedActions.includes(String(action).toLowerCase()) && !isPastorOrReviewer(user)) {
    return res.status(403).json({
      error: 'Only a Pastor or authorized Senior Reviewer can review, return, approve, or reject ministry annual plans.',
    });
  }

  const plans = getPlansStore();
  let idx = plans.findIndex((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user));
  let plan = idx >= 0 ? plans[idx] : null;

  // PostgreSQL is authoritative for workflow actions; support records not present in this server's JSON cache.
  if (!plan && process.env.DATABASE_URL) {
    const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
    plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
  }
  if (!plan || !isPlanWithinAuthenticatedScope(plan, user)) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }
  const nowIso = new Date().toISOString();
  const cleanComment = String(comment || '').trim();

  let newStatus: MinistryPlanWorkflowStatus = plan.status;
  let reviewActionLabel: MinistryPlanReviewComment['action'] = 'Comment';
  let auditActionTitle = 'Ministry Plan Review Comment Added';

  switch (String(action).toLowerCase()) {
    case 'review':
    case 'start_review':
      newStatus = 'Under Review';
      reviewActionLabel = 'Start Review';
      auditActionTitle = 'Ministry Annual Plan Under Review';
      plan.reviewedBy = user.id;
      plan.reviewedByName = user.name;
      plan.reviewedAt = nowIso;
      break;

    case 'comment':
      reviewActionLabel = 'Comment';
      auditActionTitle = 'Ministry Annual Plan Review Comment';
      if (plan.status === 'Submitted') {
        newStatus = 'Under Review';
      }
      plan.reviewedBy = user.id;
      plan.reviewedByName = user.name;
      plan.reviewedAt = nowIso;
      break;

    case 'return':
    case 'return_for_revision':
      if (!cleanComment) {
        return res.status(400).json({ error: 'Please provide revision instructions when returning a plan.' });
      }
      newStatus = 'Returned for Revision';
      reviewActionLabel = 'Return for Revision';
      auditActionTitle = 'Ministry Annual Plan Returned for Revision';
      plan.returnedReason = cleanComment;
      plan.reviewedBy = user.id;
      plan.reviewedByName = user.name;
      plan.reviewedAt = nowIso;
      break;

    case 'approve':
      newStatus = 'Approved';
      reviewActionLabel = 'Approve';
      auditActionTitle = 'Ministry Annual Plan Approved';
      plan.approvedBy = user.id;
      plan.approvedByName = user.name;
      plan.approvedAt = nowIso;
      plan.reviewedBy = user.id;
      plan.reviewedByName = user.name;
      plan.reviewedAt = nowIso;
      plan.returnedReason = undefined;
      plan.rejectedReason = undefined;
      break;

    case 'activate':
      newStatus = 'Active';
      reviewActionLabel = 'Activate';
      auditActionTitle = 'Ministry Annual Plan Activated';
      break;

    case 'complete':
      newStatus = 'Completed';
      reviewActionLabel = 'Complete';
      auditActionTitle = 'Ministry Annual Plan Completed';
      break;

    case 'reject':
      if (!cleanComment) {
        return res.status(400).json({ error: 'Please provide a rejection reason.' });
      }
      newStatus = 'Rejected';
      reviewActionLabel = 'Reject';
      auditActionTitle = 'Ministry Annual Plan Rejected';
      plan.rejectedReason = cleanComment;
      plan.reviewedBy = user.id;
      plan.reviewedByName = user.name;
      plan.reviewedAt = nowIso;
      break;

    default:
      return res.status(400).json({ error: `Unsupported workflow action: ${action}` });
  }

  plan.status = newStatus;
  plan.updatedAt = nowIso;

  const historyItem: MinistryPlanReviewComment = {
    id: `rev-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    planId: plan.id,
    reviewerId: user.id,
    reviewerName: user.name,
    reviewerRole: user.role,
    action: reviewActionLabel,
    comment: cleanComment || `${reviewActionLabel} executed by ${user.name} (${user.role}).`,
    createdAt: nowIso,
  };

  plan.reviewHistory = [historyItem, ...(plan.reviewHistory || [])];
  // Persist the status transition and review history atomically in PostgreSQL before updating the JSON compatibility cache.
  await saveMinistryAnnualPlan(plan);
  if (idx >= 0) {
    plans[idx] = plan;
    db.persist();
  }

  await recordPlanningAuditLog(
    req,
    auditActionTitle,
    `${user.name} (${user.role}) performed "${reviewActionLabel}" on ${plan.ministryName} (${plan.year}) Plan [${plan.planCode}] -> Status: ${plan.status}. Notes: ${historyItem.comment}`,
    {
      planId: plan.id,
      planCode: plan.planCode,
      action: reviewActionLabel,
      newStatus: plan.status,
      comment: historyItem.comment,
    }
  );

  const io = socketService.getIO();
  if (io) {
    io.emit('ministry_plan:updated', { planId: plan.id, status: plan.status, plan });
  }

  return res.json({
    success: true,
    message: `Plan status updated to "${plan.status}".`,
    plan,
  });
});

// 7. SUBMIT OR UPDATE QUARTERLY REPORT (Q1, Q2, Q3, Q4)
router.post('/:id/quarterly-reports', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  const idx = plans.findIndex((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user));
  let plan = idx >= 0 ? plans[idx] : null;

  if (!plan && process.env.DATABASE_URL) {
    const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
    plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
  }
  if (!plan || !isPlanWithinAuthenticatedScope(plan, user)) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }
  const body = req.body || {};
  const quarter = (body.quarter || 'Q1') as 'Q1' | 'Q2' | 'Q3' | 'Q4';

  if (!['Q1', 'Q2', 'Q3', 'Q4'].includes(quarter)) {
    return res.status(400).json({ error: 'Quarter must be Q1, Q2, Q3, or Q4' });
  }

  const milestone = (plan.quarterlyMilestones || []).find((m) => m.quarter === quarter);
  const allocatedBudget = Number(body.allocatedBudget ?? milestone?.allocatedBudget ?? 0);
  const actualExpense = Number(body.actualExpense ?? 0);
  const budgetVariance = allocatedBudget - actualExpense;

  const kpiPerformance = Array.isArray(body.kpiPerformance)
    ? body.kpiPerformance.map((k: any) => {
        const target = Number(k.quarterlyTarget) || 1;
        const actual = Number(k.actualAchieved) || 0;
        return {
          kpiId: k.kpiId || `kpi-${quarter}`,
          kpiName: k.kpiName || 'Ministry KPI',
          unit: k.unit || '%',
          quarterlyTarget: target,
          actualAchieved: actual,
          achievementRate: Number(((actual / target) * 100).toFixed(1)),
          remarks: k.remarks || '',
        };
      })
    : [];

  const overallKpiScore =
    kpiPerformance.length > 0
      ? Number(
          (
            kpiPerformance.reduce((sum: number, item: any) => sum + item.achievementRate, 0) /
            kpiPerformance.length
          ).toFixed(1)
        )
      : Number(body.overallKpiScore) || 90;

  const nowIso = new Date().toISOString();
  const existingRepIdx = (plan.quarterlyReports || []).findIndex((r) => r.quarter === quarter);

  const reportRecord: MinistryQuarterlyReport = {
    id:
      existingRepIdx >= 0
        ? plan.quarterlyReports[existingRepIdx].id
        : `mqrep-${plan.id}-${quarter.toLowerCase()}-${Date.now().toString().slice(-4)}`,
    planId: plan.id,
    ministryId: plan.ministryId,
    ministryName: plan.ministryName,
    branchId: plan.branchId,
    year: plan.year,
    quarter,
    plannedActivity: body.plannedActivity || milestone?.milestoneSummary || `${quarter} Planned Activities`,
    actualActivity: body.actualActivity || '',
    plannedParticipants: Number(body.plannedParticipants ?? milestone?.expectedParticipants ?? 0),
    actualParticipants: Number(body.actualParticipants ?? 0),
    results: body.results || '',
    kpiPerformance,
    overallKpiScore,
    challenges: body.challenges || '',
    allocatedBudget,
    actualExpense,
    budgetVariance,
    budgetExpenseNotes: body.budgetExpenseNotes || '',
    lessonsLearned: body.lessonsLearned || '',
    nextQuarterAction: body.nextQuarterAction || '',
    status: body.status || 'Submitted',
    submittedBy: user.id,
    submittedByName: user.name,
    submittedAt: nowIso,
    pastorFeedback: body.pastorFeedback,
  };

  if (!Array.isArray(plan.quarterlyReports)) {
    plan.quarterlyReports = [];
  }
  if (existingRepIdx >= 0) {
    plan.quarterlyReports[existingRepIdx] = reportRecord;
  } else {
    plan.quarterlyReports.push(reportRecord);
  }

  // Sort quarterly reports Q1 -> Q4
  plan.quarterlyReports.sort((a, b) => a.quarter.localeCompare(b.quarter));

  // Mark corresponding quarterly milestone as Completed or In Progress
  plan.quarterlyMilestones = (plan.quarterlyMilestones || []).map((qm) =>
    qm.quarter === quarter ? { ...qm, status: 'Completed' } : qm
  );

  // If plan was Approved, automatically transition to Active when execution reports are submitted
  if (plan.status === 'Approved') {
    plan.status = 'Active';
  }

  // Automatically refresh aggregated annual report
  plan.annualReport = aggregateQuarterlyReportsIntoAnnualReport(plan, {
    submittedBy: user.id,
    submittedByName: user.name,
  });

  plan.updatedAt = nowIso;
  // Commit the report, aggregate, and plan status atomically before updating the JSON compatibility cache.
  await saveMinistryAnnualPlan(plan);
  if (idx >= 0) {
    plans[idx] = plan;
    db.persist();
  }

  await recordPlanningAuditLog(
    req,
    'Ministry Quarterly Report Submitted',
    `${user.name} (${user.role}) submitted ${quarter} Quarterly Report for ${plan.ministryName} (${plan.year}) [${plan.planCode}]. Actual Participants: ${reportRecord.actualParticipants}, KPI Score: ${reportRecord.overallKpiScore}%, Actual Expense: ${plan.currency} ${reportRecord.actualExpense.toLocaleString()}.`,
    {
      planId: plan.id,
      quarter,
      actualParticipants: reportRecord.actualParticipants,
      overallKpiScore: reportRecord.overallKpiScore,
      actualExpense: reportRecord.actualExpense,
    }
  );

  return res.status(201).json({
    success: true,
    message: `${quarter} Quarterly Report submitted and aggregated into the ${plan.year} Annual Report.`,
    quarterlyReport: reportRecord,
    annualReport: plan.annualReport,
    plan,
  });
});

// 8. SUBMIT AGGREGATED ANNUAL REPORT
router.post('/:id/annual-report', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  const idx = plans.findIndex((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user));
  let plan = idx >= 0 ? plans[idx] : null;

  if (!plan && process.env.DATABASE_URL) {
    const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
    plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
  }
  if (!plan || !isPlanWithinAuthenticatedScope(plan, user)) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }
  const body = req.body || {};
  const nowIso = new Date().toISOString();

  const aggregated = aggregateQuarterlyReportsIntoAnnualReport(plan, {
    executiveSummary: body.executiveSummary,
    keyAchievements: body.keyAchievements,
    majorChallenges: body.majorChallenges,
    lessonsLearned: body.lessonsLearned,
    strategicRecommendationsNextYear: body.strategicRecommendationsNextYear,
    status: 'Submitted',
    submittedBy: user.id,
    submittedByName: user.name,
  });

  plan.annualReport = aggregated;
  if (body.markPlanCompleted === true && (plan.status === 'Active' || plan.status === 'Approved')) {
    plan.status = 'Completed';
  }
  plan.updatedAt = nowIso;

  // Commit the report, aggregate, and plan status atomically before updating the JSON compatibility cache.
  await saveMinistryAnnualPlan(plan);
  if (idx >= 0) {
    plans[idx] = plan;
    db.persist();
  }

  await recordPlanningAuditLog(
    req,
    'Ministry Annual Report Submitted',
    `${user.name} (${user.role}) submitted the Aggregated ${plan.year} Annual Report for ${plan.ministryName} [${plan.planCode}]. Quarters Aggregated: ${aggregated.quartersIncluded.join(', ') || 'None'}. Total Actual Participants: ${aggregated.totalActualParticipants.toLocaleString()}, Overall KPI Rate: ${aggregated.overallKpiAchievementRate}%.`,
    {
      planId: plan.id,
      year: plan.year,
      quartersIncluded: aggregated.quartersIncluded,
      overallKpiAchievementRate: aggregated.overallKpiAchievementRate,
      totalActualExpense: aggregated.totalActualExpense,
    }
  );

  return res.status(201).json({
    success: true,
    message: `Aggregated ${plan.year} Annual Report for ${plan.ministryName} submitted and persisted in PostgreSQL.`,
    annualReport: aggregated,
    plan,
  });
});

// 9. REAL BINARY PDF EXPORT ENDPOINT
router.get('/:id/export/pdf', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  let plan = plans.find((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user)) || null;
  if (process.env.DATABASE_URL) {
    try {
      const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
      plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
    } catch (error: any) {
      console.error('[MinistryPlans PDF Export Read Failed]:', error?.message || error);
      return res.status(503).json({ error: 'Unable to retrieve the ministry plan for export.' });
    }
  }
  if (!plan || !isPlanWithinAuthenticatedScope(plan, user)) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }

  const pdfBytes = buildMinistryPlanPdfBuffer(plan);
  const safeName = plan.ministryName.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeName}_${plan.year}_Annual_Plan_and_Report.pdf`;

  await recordPlanningAuditLog(
    req,
    'Ministry Plan & Report Exported (PDF)',
    `${req.user?.name || 'User'} exported real binary PDF report for ${plan.ministryName} (${plan.year}) [${plan.planCode}].`,
    { planId: plan.id, format: 'PDF', bytes: pdfBytes.byteLength }
  );

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Length', String(pdfBytes.byteLength));
  return res.send(Buffer.from(pdfBytes));
});

// 10. REAL BINARY EXCEL (.XLSX) EXPORT ENDPOINT
router.get('/:id/export/xlsx', async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const plans = getPlansStore();
  let plan = plans.find((p) => p.id === req.params.id && isPlanWithinAuthenticatedScope(p, user)) || null;
  if (process.env.DATABASE_URL) {
    try {
      const branchIds = [...new Set([...(user.branchIds || []), user.branchId].filter(Boolean))];
      plan = await getMinistryAnnualPlanById({ tenantId: user.tenantId, branchIds }, req.params.id);
    } catch (error: any) {
      console.error('[MinistryPlans XLSX Export Read Failed]:', error?.message || error);
      return res.status(503).json({ error: 'Unable to retrieve the ministry plan for export.' });
    }
  }
  if (!plan || !isPlanWithinAuthenticatedScope(plan, user)) {
    return res.status(404).json({ error: 'Ministry annual plan not found' });
  }

  const xlsxBytes = buildMinistryPlanXlsxBuffer(plan);
  const safeName = plan.ministryName.replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeName}_${plan.year}_Annual_Plan_and_Report.xlsx`;

  await recordPlanningAuditLog(
    req,
    'Ministry Plan & Report Exported (XLSX)',
    `${req.user?.name || 'User'} exported real binary Excel (.xlsx) workbook for ${plan.ministryName} (${plan.year}) [${plan.planCode}].`,
    { planId: plan.id, format: 'XLSX', bytes: xlsxBytes.byteLength }
  );

  res.setHeader(
    'Content-Type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Length', String(xlsxBytes.byteLength));
  return res.send(Buffer.from(xlsxBytes));
});

export default router;
