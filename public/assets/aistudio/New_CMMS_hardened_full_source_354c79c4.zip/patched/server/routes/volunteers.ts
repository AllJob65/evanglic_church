import { Router, Response } from 'express';
import { db } from '../db';
import { VolunteerShift, Asset, DocumentItem } from '../../src/types';
import {
  authenticateToken,
  requirePermission,
  verifyResourceAccess,
  AuthenticatedRequest,
} from '../../src/security/authorization';
import { fileUploadLimiter } from '../middleware/rateLimiter';

const router = Router();

// Apply authentication to all volunteer, asset, and document routes
router.use(authenticateToken);

// ==============================================================================
// VOLUNTEER SHIFTS - Enforce volunteers.read, volunteers.manage
// ==============================================================================
router.get('/shifts', requirePermission('volunteers.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let shifts = db.getState().volunteerShifts;

  // Tenant Isolation
  shifts = shifts.filter((s) => !s.tenantId || s.tenantId === user.tenantId);

  // If Regular Member, only view own shifts
  if (user.role === 'REGULAR_MEMBER') {
    shifts = shifts.filter((s) => s.volunteerId === user.id || s.volunteerName === user.name);
  } else if (!user.branchIds.includes('*')) {
    // Branch Isolation
    shifts = shifts.filter((s) => !s.branchId || user.branchIds.includes(s.branchId));
  }

  return res.json(shifts);
});

router.post('/shifts', requirePermission('volunteers.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const shiftData: VolunteerShift = req.body;
  const shift: VolunteerShift = {
    ...shiftData,
    id: shiftData.id || `shift-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: shiftData.branchId || user.branchId,
    shiftDate: shiftData.shiftDate || new Date().toISOString().split('T')[0],
    startTime: shiftData.startTime || '09:00',
    endTime: shiftData.endTime || '12:00',
    status: shiftData.status || 'Scheduled',
    hoursLogged: shiftData.hoursLogged || 3,
  };

  db.getState().volunteerShifts.unshift(shift);
  db.persist();
  db.addAuditLog('Add Volunteer Shift', 'Volunteers', `Scheduled volunteer shift for ${shift.volunteerName} in ${shift.roleTitle}`, user.name);
  return res.status(201).json(shift);
});

// ==============================================================================
// ASSETS & INVENTORY - Enforce assets.read, assets.manage
// ==============================================================================
router.get('/assets', requirePermission('assets.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let assets = db.getState().assets;

  // Tenant Isolation
  assets = assets.filter((a) => !a.tenantId || a.tenantId === user.tenantId);

  // Branch Isolation
  if (!user.branchIds.includes('*')) {
    assets = assets.filter((a) => !a.branchId || user.branchIds.includes(a.branchId));
  }

  return res.json(assets);
});

router.post('/assets', requirePermission('assets.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const assetData: Asset = req.body;
  const asset: Asset = {
    ...assetData,
    id: assetData.id || `ast-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: assetData.branchId || user.branchId,
    purchaseDate: assetData.purchaseDate || new Date().toISOString().split('T')[0],
  };

  db.getState().assets.unshift(asset);
  db.persist();
  db.addAuditLog('Add Asset', 'Assets & Inventory', `Registered church asset: ${asset.name} (${asset.category})`, user.name);
  return res.status(201).json(asset);
});

// ==============================================================================
// DOCUMENTS VAULT - Enforce documents.read, documents.manage
// ==============================================================================
router.get('/documents', requirePermission('documents.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  let docs = db.getState().documents;

  // Tenant Isolation
  docs = docs.filter((d) => !d.tenantId || d.tenantId === user.tenantId);

  // Confidential docs: hide if regular member unless uploaded by member
  if (user.role === 'REGULAR_MEMBER') {
    docs = docs.filter((d) => (d as any).accessLevel === 'PUBLIC' || (d as any).uploaderId === user.id);
  }

  return res.json(docs);
});

// GET single document by ID - IDOR Protected
router.get('/documents/:id', requirePermission('documents.read'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const doc = db.getState().documents.find((d) => d.id === id);
  if (!doc) {
    return res.status(404).json({ error: 'Document not found' });
  }

  const access = verifyResourceAccess(doc, user, { checkBranch: false });
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  if (user.role === 'REGULAR_MEMBER' && (doc as any).accessLevel !== 'PUBLIC' && (doc as any).uploaderId !== user.id) {
    return res.status(403).json({ error: 'Access denied: document is restricted to church administration', code: 'RESTRICTED_DOCUMENT' });
  }

  return res.json(doc);
});

router.post('/documents', requirePermission('documents.manage'), fileUploadLimiter, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const docData: DocumentItem = req.body;
  const doc: DocumentItem = {
    ...docData,
    id: docData.id || `doc-${Date.now()}`,
    tenantId: user.tenantId,
    branchId: docData.branchId || user.branchId,
    uploadDate: docData.uploadDate || new Date().toISOString().split('T')[0],
    downloadCount: 0,
  };

  db.getState().documents.unshift(doc);
  db.persist();
  db.addAuditLog('Upload Document', 'Document Vault', `Uploaded document record: ${doc.title} (${doc.fileFormat})`, user.name);
  return res.status(201).json(doc);
});

router.delete('/documents/:id', requirePermission('documents.manage'), (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const { id } = req.params;
  const state = db.getState();
  const index = state.documents.findIndex((d) => d.id === id);
  if (index === -1) return res.status(404).json({ error: 'Document not found' });

  const target = state.documents[index];
  const access = verifyResourceAccess(target, user, { checkBranch: false });
  if (!access.authorized) {
    return res.status(access.status).json({ error: access.reason, code: 'FORBIDDEN' });
  }

  const deleted = state.documents.splice(index, 1)[0];
  db.persist();
  db.addAuditLog('Delete Document', 'Document Vault', `Removed document record: ${deleted.title}`, user.name);
  return res.json({ success: true, deletedId: id });
});

// DOCUMENT CATEGORIES
router.get('/documents/categories/all', requirePermission('documents.read'), (req: AuthenticatedRequest, res: Response) => {
  return res.json(db.getState().documentCategories);
});

router.post('/documents/categories', requirePermission('documents.manage'), (req: AuthenticatedRequest, res: Response) => {
  const { categoryName } = req.body;
  if (!categoryName) return res.status(400).json({ error: 'Category name is required' });

  const cats = db.getState().documentCategories;
  if (!cats.includes(categoryName)) {
    cats.push(categoryName);
    db.persist();
    db.addAuditLog('Add Document Category', 'Document Vault', `Added category: ${categoryName}`, req.user?.name);
  }
  return res.status(201).json(cats);
});

router.delete('/documents/categories/:name', requirePermission('documents.manage'), (req: AuthenticatedRequest, res: Response) => {
  const { name } = req.params;
  const state = db.getState();
  const index = state.documentCategories.indexOf(name);
  if (index === -1) return res.status(404).json({ error: 'Category not found' });

  state.documentCategories.splice(index, 1);
  db.persist();
  db.addAuditLog('Delete Document Category', 'Document Vault', `Removed category: ${name}`, req.user?.name);
  return res.json({ success: true, remaining: state.documentCategories });
});

export default router;
