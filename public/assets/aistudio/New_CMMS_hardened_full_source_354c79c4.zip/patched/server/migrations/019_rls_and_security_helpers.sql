-- ==============================================================================
-- CMMS MIGRATION 019: SECURITY DEFINER FUNCTIONS & ROW-LEVEL SECURITY POLICIES
-- ==============================================================================

-- Compatibility layer for local PostgreSQL without hosted Supabase Auth
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'auth') THEN
        CREATE SCHEMA auth;
        CREATE OR REPLACE FUNCTION auth.uid() RETURNS UUID AS $f$
            SELECT NULL::UUID;
        $f$ LANGUAGE sql STABLE;
        CREATE OR REPLACE FUNCTION auth.role() RETURNS TEXT AS $f$
            SELECT 'authenticated'::TEXT;
        $f$ LANGUAGE sql STABLE;
    END IF;
END $$;

-- 1. Current Profile Resolution
CREATE OR REPLACE FUNCTION public.get_current_profile()
RETURNS public.profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    current_prof public.profiles;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT * INTO current_prof
    FROM public.profiles
    WHERE id = auth.uid()::text
    LIMIT 1;

    RETURN current_prof;
END;
$$;

-- 2. Current Tenant Resolution
CREATE OR REPLACE FUNCTION public.get_current_tenant_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT tenant_id FROM public.profiles WHERE id = auth.uid()::text LIMIT 1;
$$;

-- 3. Current Branch Resolution
CREATE OR REPLACE FUNCTION public.get_current_branch_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT branch_id FROM public.profiles WHERE id = auth.uid()::text LIMIT 1;
$$;

-- 4. Current Role Resolution
CREATE OR REPLACE FUNCTION public.get_current_role()
RETURNS TEXT
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT COALESCE(role, 'REGULAR_MEMBER') FROM public.profiles WHERE id = auth.uid()::text LIMIT 1;
$$;

-- 5. Current Member ID Resolution
CREATE OR REPLACE FUNCTION public.get_current_member_id()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    v_member_id TEXT;
    v_prof_member_id TEXT;
    v_prof_email TEXT;
    v_tenant_id UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT member_id, email, tenant_id INTO v_prof_member_id, v_prof_email, v_tenant_id
    FROM public.profiles WHERE id = auth.uid()::text LIMIT 1;

    IF v_prof_member_id IS NOT NULL AND TRIM(v_prof_member_id) != '' THEN
        RETURN v_prof_member_id;
    END IF;

    IF v_prof_email IS NOT NULL AND v_tenant_id IS NOT NULL THEN
        SELECT id INTO v_member_id FROM public.members
        WHERE tenant_id = v_tenant_id AND lower(email) = lower(v_prof_email)
        LIMIT 1;
        IF v_member_id IS NOT NULL THEN
            RETURN v_member_id;
        END IF;
    END IF;

    RETURN NULL;
END;
$$;

-- 6. Branch Access Verification
CREATE OR REPLACE FUNCTION public.can_access_branch(target_branch_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
    u_branch UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();
    IF u_role IN ('SYSTEM_ADMIN', 'MANAGER') THEN
        RETURN true;
    END IF;

    u_branch := public.get_current_branch_id();
    IF target_branch_id IS NULL OR target_branch_id = u_branch THEN
        RETURN true;
    END IF;

    RETURN false;
END;
$$;

-- 7. Ministry Leadership Verification
CREATE OR REPLACE FUNCTION public.is_leader_of_ministry(target_ministry_id TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
    u_member_id TEXT;
    u_tenant_id UUID;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();
    IF u_role IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR') THEN
        RETURN true;
    END IF;

    IF u_role <> 'MINISTRY_LEADER' THEN
        RETURN false;
    END IF;

    u_member_id := public.get_current_member_id();
    u_tenant_id := public.get_current_tenant_id();

    IF u_member_id IS NULL THEN
        RETURN false;
    END IF;

    RETURN EXISTS (
        SELECT 1 FROM public.ministry_members mm
        JOIN public.ministries m ON m.id = mm.ministry_id
        WHERE mm.ministry_id = target_ministry_id
          AND m.tenant_id = u_tenant_id
          AND (mm.member_id = u_member_id OR mm.user_id = auth.uid()::text)
          AND mm.role IN ('Leader', 'Director', 'Coordinator', 'Chairperson')
    );
END;
$$;

-- 8. Pastoral Confidentiality Boundary Default (Prevents SYSTEM_ADMIN automatic override)
CREATE OR REPLACE FUNCTION public.has_pastoral_confidential_override()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT false;
$$;

-- 9. Centralized RBAC Permission Evaluator
CREATE OR REPLACE FUNCTION public.has_permission(required_permission TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
DECLARE
    u_role TEXT;
BEGIN
    IF auth.uid() IS NULL THEN
        RETURN false;
    END IF;

    u_role := public.get_current_role();

    IF u_role = 'SYSTEM_ADMIN' THEN
        IF required_permission IN ('pastoral.confidential', 'counseling.confidential_notes') THEN
            RETURN public.has_pastoral_confidential_override();
        END IF;
        RETURN true;
    END IF;

    IF u_role = 'MANAGER' THEN
        RETURN required_permission IN (
            'members.read', 'members.create', 'members.update', 'members.export',
            'attendance.read', 'attendance.create', 'attendance.update',
            'finance.read', 'finance.create', 'finance.approve', 'finance.export',
            'donations.read', 'donations.create', 'donations.export',
            'pastoral.read_general',
            'ministries.read', 'ministries.manage',
            'groups.read', 'groups.manage',
            'branches.read', 'branches.manage',
            'volunteers.read', 'volunteers.manage',
            'workflows.read', 'workflows.manage',
            'reports.read', 'events.read', 'events.manage',
            'documents.read', 'documents.manage'
        );
    END IF;

    IF u_role = 'PASTOR' THEN
        RETURN required_permission IN (
            'members.read', 'members.update',
            'attendance.read',
            'pastoral.read', 'pastoral.create', 'pastoral.update',
            'pastoral.confidential',
            'counseling.read', 'counseling.create', 'counseling.update',
            'counseling.confidential_notes',
            'prayer.read', 'prayer.create', 'prayer.update',
            'visitations.read', 'visitations.manage',
            'ministries.read', 'branches.read',
            'groups.read',
            'volunteers.read',
            'workflows.read', 'workflows.manage',
            'events.read',
            'documents.read'
        );
    END IF;

    IF u_role = 'MINISTRY_LEADER' THEN
        RETURN required_permission IN (
            'members.read',
            'attendance.read', 'attendance.create', 'attendance.update',
            'pastoral.read_general', 'prayer.read', 'prayer.create',
            'ministries.read', 'branches.read',
            'groups.read', 'groups.manage',
            'volunteers.read', 'volunteers.manage',
            'workflows.read', 'workflows.create',
            'events.read',
            'documents.read'
        );
    END IF;

    IF u_role = 'REGULAR_MEMBER' THEN
        RETURN required_permission IN (
            'members.read_self',
            'attendance.create',
            'finance.read_self',
            'donations.read_self', 'donations.create',
            'prayer.read_self', 'prayer.create',
            'counseling.read_self',
            'workflows.read_self', 'workflows.create',
            'events.read',
            'documents.read'
        );
    END IF;

    RETURN false;
END;
$$;
