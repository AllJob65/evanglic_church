-- ============================================================================
-- Migration 018: Production Email + SMS Communication Logs Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS communication_logs (
    id VARCHAR(120) PRIMARY KEY,
    tenant_id VARCHAR(100) DEFAULT 'default',
    branch_id VARCHAR(100),
    channel VARCHAR(20) NOT NULL CHECK (channel IN ('SMS', 'EMAIL')),
    recipient VARCHAR(255) NOT NULL,
    recipient_name VARCHAR(255),
    member_id VARCHAR(120),
    family_id VARCHAR(120),
    ministry_id VARCHAR(120),
    subject VARCHAR(500),
    message TEXT NOT NULL,
    status VARCHAR(30) NOT NULL CHECK (status IN ('QUEUED', 'SENT', 'FAILED', 'DELIVERED')),
    provider VARCHAR(100) NOT NULL,
    provider_message_id VARCHAR(255),
    error_message TEXT,
    trigger_type VARCHAR(100) DEFAULT 'Direct',
    sent_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(150),
    created_by_name VARCHAR(255)
);

CREATE INDEX IF NOT EXISTS idx_comm_logs_channel ON communication_logs(channel);
CREATE INDEX IF NOT EXISTS idx_comm_logs_status ON communication_logs(status);
CREATE INDEX IF NOT EXISTS idx_comm_logs_member_id ON communication_logs(member_id);
CREATE INDEX IF NOT EXISTS idx_comm_logs_family_id ON communication_logs(family_id);
CREATE INDEX IF NOT EXISTS idx_comm_logs_created_at ON communication_logs(created_at DESC);
