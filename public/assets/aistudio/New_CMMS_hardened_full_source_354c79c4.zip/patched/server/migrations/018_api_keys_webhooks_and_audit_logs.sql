-- ==============================================================================
-- CMMS MIGRATION 018: API KEYS, WEBHOOKS, AUDIT LOGS & PERMISSION DENIED LOGS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.api_keys (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    key_prefix TEXT NOT NULL,
    api_key TEXT,
    api_key_hash TEXT,
    scopes TEXT[] NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_used_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Revoked')),
    rate_limit_per_min INT NOT NULL DEFAULT 60,
    description TEXT
);

CREATE INDEX IF NOT EXISTS idx_api_keys_lookup ON public.api_keys (key_prefix, status);

CREATE TABLE IF NOT EXISTS public.webhooks (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    target_url TEXT NOT NULL,
    events TEXT[] NOT NULL DEFAULT '{}',
    secret_token TEXT,
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_triggered_at TIMESTAMPTZ,
    last_status_code INT,
    failure_count INT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_webhooks_active ON public.webhooks (active);

CREATE TABLE IF NOT EXISTS public.audit_logs (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id TEXT,
    user_email TEXT,
    user_name TEXT,
    user_role TEXT,
    action TEXT NOT NULL,
    module TEXT NOT NULL,
    ip_address TEXT,
    location TEXT,
    details TEXT NOT NULL,
    commit_data TEXT,
    device TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON public.audit_logs (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON public.audit_logs (user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_module ON public.audit_logs (module);

CREATE TABLE IF NOT EXISTS public.permission_denied_logs (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id TEXT NOT NULL,
    user_email TEXT NOT NULL,
    user_role TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    ip_address TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_perm_denied_logs ON public.permission_denied_logs (timestamp DESC);
