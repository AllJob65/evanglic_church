-- ==============================================================================
-- CMMS MIGRATION 005: MEMBERS & ETHIOPIAN PHONE CONSTRAINTS & NORMALIZATION
-- ==============================================================================

-- 1. Helper function to normalize Ethiopian phone numbers to standard E.164 (+251...)
CREATE OR REPLACE FUNCTION public.normalize_ethiopian_phone(phone_input TEXT)
RETURNS TEXT AS $$
DECLARE
  cleaned TEXT;
BEGIN
  IF phone_input IS NULL OR TRIM(phone_input) = '' THEN
    RETURN NULL;
  END IF;

  -- Strip all whitespace, hyphens, and parentheses
  cleaned := regexp_replace(TRIM(phone_input), '[\s\-\(\)]', '', 'g');

  -- Convert 09XXXXXXXX -> +2519XXXXXXXX
  IF cleaned ~ '^09[0-9]{8}$' THEN
    RETURN '+2519' || SUBSTRING(cleaned FROM 3);
  END IF;

  -- Convert 07XXXXXXXX -> +2517XXXXXXXX
  IF cleaned ~ '^07[0-9]{8}$' THEN
    RETURN '+2517' || SUBSTRING(cleaned FROM 3);
  END IF;

  -- Convert 2519XXXXXXXX -> +2519XXXXXXXX
  IF cleaned ~ '^251(9|7)[0-9]{8}$' THEN
    RETURN '+' || cleaned;
  END IF;

  -- Already in valid international format +2519... or +2517...
  IF cleaned ~ '^\+251(9|7)[0-9]{8}$' THEN
    RETURN cleaned;
  END IF;

  RETURN cleaned;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 2. Members Directory Table
CREATE TABLE IF NOT EXISTS public.members (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    member_id_number TEXT NOT NULL,
    member_number TEXT,
    member_code TEXT,
    title TEXT NOT NULL DEFAULT 'Mr',
    name TEXT,
    first_name TEXT NOT NULL,
    middle_name TEXT,
    last_name TEXT NOT NULL,
    preferred_name TEXT,
    amharic_name TEXT,
    date_of_birth DATE,
    age INT,
    gender TEXT NOT NULL CHECK (gender IN ('Male', 'Female')),
    nationality TEXT DEFAULT 'Ethiopian',
    national_id_number TEXT,
    passport_number TEXT,
    photo_url TEXT,

    -- Marital Status & Family
    marital_status TEXT DEFAULT 'Single',
    marriage_date DATE,
    divorce_date DATE,
    spouse_name TEXT,
    spouse_phone TEXT,
    spouse_member_id TEXT,

    -- Contact & Channels
    primary_phone TEXT,
    alt_phone TEXT,
    email TEXT,
    preferred_comm_channel TEXT DEFAULT 'SMS',

    -- Address
    street_address TEXT,
    address TEXT,
    city TEXT DEFAULT 'Addis Ababa',
    sub_city TEXT,
    woreda TEXT,
    kebele TEXT,
    house_number TEXT,
    village TEXT,
    region TEXT DEFAULT 'Addis Ababa',
    country TEXT DEFAULT 'Ethiopia',
    postal_code TEXT,
    gps_coordinates TEXT,

    -- Family & Children
    family_id TEXT,
    family_role TEXT,
    male_children_count INT DEFAULT 0,
    female_children_count INT DEFAULT 0,
    adopted_children_count INT DEFAULT 0,

    -- Spiritual Milestones
    salvation_date DATE,
    salvation_location TEXT,
    led_to_christ_by TEXT,
    salvation_testimony TEXT,
    is_water_baptized BOOLEAN DEFAULT false,
    water_baptized BOOLEAN DEFAULT false,
    water_baptism_date DATE,
    baptism_date DATE,
    water_baptism_location TEXT,
    baptized_by TEXT,
    water_baptism_cert_url TEXT,
    is_holy_spirit_baptized BOOLEAN DEFAULT false,
    holy_spirit_baptism_date DATE,
    spiritual_gifts TEXT[] DEFAULT '{}',
    membership_date DATE,
    membership_location TEXT,
    membership_status TEXT NOT NULL DEFAULT 'Active',
    membership_type TEXT DEFAULT 'Full Member',
    discipleship_status TEXT,
    discipleship_level TEXT,
    previous_church TEXT,
    foundation_course_completed BOOLEAN DEFAULT false,
    bible_study_group_id TEXT,
    mentor_name TEXT,
    current_ministry_status TEXT,
    previous_ministry_status TEXT,
    ministries_served_before TEXT[] DEFAULT '{}',
    ministries_joined_now TEXT[] DEFAULT '{}',

    -- Education & Career
    education_level TEXT,
    institution_name TEXT,
    field_of_study TEXT,
    occupation TEXT,
    employer TEXT,
    employer_name TEXT,
    employer_type TEXT,
    employer_type_other TEXT,
    employer_contact TEXT,
    skills_and_talents TEXT[] DEFAULT '{}',
    languages_spoken TEXT[] DEFAULT '{}',

    -- Pastoral / Status Transitions
    departure_reason TEXT,
    departure_date DATE,
    departure_end_date DATE,
    status_start_date DATE,
    status_end_date DATE,
    departure_notes TEXT,
    excommunication_paper_url TEXT,
    excommunication_paper_name TEXT,
    excommunication_description TEXT,

    -- Medical & Emergency
    blood_type TEXT,
    known_allergies TEXT[] DEFAULT '{}',
    medical_conditions TEXT[] DEFAULT '{}',
    special_needs TEXT,
    emergency_contact JSONB NOT NULL DEFAULT '{}'::jsonb,
    notes TEXT,

    -- System Metrics
    ministry_ids TEXT[] DEFAULT '{}',
    attendance_score INT DEFAULT 100,
    last_active TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, member_id_number)
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_members_tenant ON public.members (tenant_id);
CREATE INDEX IF NOT EXISTS idx_members_branch ON public.members (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_members_name ON public.members (tenant_id, last_name, first_name);
CREATE INDEX IF NOT EXISTS idx_members_phone ON public.members (tenant_id, primary_phone);
CREATE INDEX IF NOT EXISTS idx_members_email ON public.members (tenant_id, email);
CREATE INDEX IF NOT EXISTS idx_members_family ON public.members (tenant_id, family_id);
CREATE INDEX IF NOT EXISTS idx_members_status ON public.members (tenant_id, membership_status);

-- 3. Automatic Phone Normalization Triggers
CREATE OR REPLACE FUNCTION public.trigger_normalize_phone()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.primary_phone IS NOT NULL AND NEW.primary_phone != '' THEN
    NEW.primary_phone := public.normalize_ethiopian_phone(NEW.primary_phone);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_normalize_members_phone ON public.members;
CREATE TRIGGER trg_normalize_members_phone
  BEFORE INSERT OR UPDATE OF primary_phone ON public.members
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_normalize_phone();
