-- ==============================================================================
-- CMMS MIGRATION 003: CHURCH SETTINGS, BRANDING & SMS GATEWAY
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.church_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    church_name TEXT NOT NULL DEFAULT 'Grace Cathedral International Ministries',
    system_name TEXT NOT NULL DEFAULT 'Grace Cathedral CMMS',
    title_badge TEXT DEFAULT 'Sovereign Pro',
    church_motto TEXT DEFAULT 'Reaching the Lost, Discipling the Found, Transforming Nations',
    favicon_url TEXT,
    church_logo_url TEXT,
    dark_logo_url TEXT,
    primary_color_hex TEXT NOT NULL DEFAULT '#2563eb',
    accent_color_hex TEXT NOT NULL DEFAULT '#7c3aed',
    headquarters_address TEXT DEFAULT 'Bole Medhanealem Road, Suite 400, Addis Ababa, Ethiopia',
    contact_phone TEXT DEFAULT '+251 (11) 662-8900',
    contact_email TEXT DEFAULT 'admin@gracecathedral.org',
    tax_id_number TEXT DEFAULT 'ET-NGO-984210',
    -- Phase 23: official church domain restriction for staff email accounts
    allowed_staff_email_domains TEXT[] DEFAULT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id)
);

CREATE TABLE IF NOT EXISTS public.sms_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    provider TEXT NOT NULL DEFAULT 'EthioTelecom',
    sender_id TEXT NOT NULL DEFAULT 'GRACECATH',
    enabled BOOLEAN NOT NULL DEFAULT true,
    sms_url TEXT DEFAULT 'https://api.ethiotelecom.et/sms/v1/send',
    app_id TEXT,
    app_secret TEXT,
    balance_credits INT NOT NULL DEFAULT 4250,
    monthly_quota INT NOT NULL DEFAULT 10000,
    used_credits INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id)
);
