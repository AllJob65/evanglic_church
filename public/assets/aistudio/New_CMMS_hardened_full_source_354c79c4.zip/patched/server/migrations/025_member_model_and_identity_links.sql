-- 025_member_model_and_identity_links.sql
-- Prepared for review only. Do NOT run automatically or against production
-- until the deployed schema has been backed up and the complete migration set approved.
-- This migration extends the already-deployed UUID schema; it does not recreate core tables.

BEGIN;

-- One optional application account may be linked to one member record.
-- No email-based backfill is attempted: ambiguous matches must be resolved manually.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS member_id uuid;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.profiles'::regclass
      AND conname = 'profiles_member_id_fkey'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_member_id_fkey
      FOREIGN KEY (member_id) REFERENCES public.members(id)
      ON DELETE SET NULL NOT VALID;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_member_id_unique
  ON public.profiles(member_id)
  WHERE member_id IS NOT NULL;

ALTER TABLE public.branches ADD COLUMN IF NOT EXISTS branch_data jsonb NOT NULL DEFAULT '{}'::jsonb
  CHECK (jsonb_typeof(branch_data)='object');
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS event_data jsonb NOT NULL DEFAULT '{}'::jsonb
  CHECK (jsonb_typeof(event_data)='object');

-- Live attendance sessions and normalized attendance records.
CREATE TABLE IF NOT EXISTS public.attendance_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
  session_code text NOT NULL,
  group_id uuid,
  group_name text,
  leader_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  leader_name text,
  session_type text NOT NULL DEFAULT 'instant',
  title text NOT NULL,
  service_type text NOT NULL DEFAULT 'Ministry Attendance',
  status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','closed')),
  start_time timestamptz NOT NULL DEFAULT now(),
  end_time timestamptz,
  qr_payload_token text NOT NULL UNIQUE,
  location text,
  attendee_count integer NOT NULL DEFAULT 0 CHECK(attendee_count>=0),
  session_data jsonb NOT NULL DEFAULT '{}'::jsonb CHECK(jsonb_typeof(session_data)='object'),
  UNIQUE(tenant_id,session_code),
  UNIQUE(id,tenant_id,branch_id)
);
CREATE INDEX IF NOT EXISTS attendance_sessions_tenant_branch_start_idx
  ON public.attendance_sessions(tenant_id,branch_id,start_time DESC);
CREATE INDEX IF NOT EXISTS attendance_sessions_active_idx
  ON public.attendance_sessions(tenant_id,status,start_time DESC);

ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS session_id uuid;
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS record_code text;
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS member_name text;
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'Present';
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS absence_reason text;
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS service_session text;
ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS event_id uuid;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.attendance_records'::regclass AND conname='attendance_records_session_tenant_branch_fkey') THEN
    ALTER TABLE public.attendance_records ADD CONSTRAINT attendance_records_session_tenant_branch_fkey
      FOREIGN KEY(session_id,tenant_id,branch_id) REFERENCES public.attendance_sessions(id,tenant_id,branch_id)
      ON DELETE SET NULL (session_id) NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.attendance_records'::regclass AND conname='attendance_records_member_tenant_fkey') THEN
    ALTER TABLE public.attendance_records ADD CONSTRAINT attendance_records_member_tenant_fkey
      FOREIGN KEY(member_id,tenant_id) REFERENCES public.members(id,tenant_id)
      ON DELETE SET NULL (member_id) NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.attendance_records'::regclass AND conname='attendance_records_event_tenant_fkey') THEN
    ALTER TABLE public.attendance_records ADD CONSTRAINT attendance_records_event_tenant_fkey
      FOREIGN KEY(event_id,tenant_id) REFERENCES public.events(id,tenant_id)
      ON DELETE SET NULL (event_id) NOT VALID;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS attendance_records_tenant_branch_checkin_idx
  ON public.attendance_records(tenant_id,branch_id,checkin_time DESC);
CREATE INDEX IF NOT EXISTS attendance_records_member_checkin_idx
  ON public.attendance_records(tenant_id,member_id,checkin_time DESC);
CREATE UNIQUE INDEX IF NOT EXISTS attendance_records_session_member_unique
  ON public.attendance_records(session_id,member_id) WHERE session_id IS NOT NULL AND member_id IS NOT NULL;
ALTER TABLE public.ministries ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'Active';
ALTER TABLE public.ministries ADD COLUMN IF NOT EXISTS ministry_data jsonb NOT NULL DEFAULT '{}'::jsonb
  CHECK (jsonb_typeof(ministry_data)='object');

-- Preserve campus scope on household records in the normalized schema.
ALTER TABLE public.families ADD COLUMN IF NOT EXISTS branch_id uuid;
ALTER TABLE public.families ADD COLUMN IF NOT EXISTS family_photo_url text;
ALTER TABLE public.families ADD COLUMN IF NOT EXISTS woreda text;
ALTER TABLE public.families ADD COLUMN IF NOT EXISTS kebele text;
ALTER TABLE public.families ADD COLUMN IF NOT EXISTS house_number text;
ALTER TABLE public.families ADD COLUMN IF NOT EXISTS registration_date date DEFAULT CURRENT_DATE;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.families'::regclass AND conname='families_branch_id_fkey') THEN
    ALTER TABLE public.families ADD CONSTRAINT families_branch_id_fkey
      FOREIGN KEY(branch_id) REFERENCES public.branches(id) ON DELETE SET NULL NOT VALID;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS families_tenant_branch_idx ON public.families(tenant_id,branch_id);

-- Explicit multi-role assignments. Keep profiles.role as the primary-role
-- compatibility field while the application migrates to this normalized model.
CREATE TABLE IF NOT EXISTS public.profile_role_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('SYSTEM_ADMIN','PASTOR','MINISTRY_LEADER','REGULAR_MEMBER','MANAGER')),
  is_primary boolean NOT NULL DEFAULT false,
  granted_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  granted_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, tenant_id, role)
);

CREATE UNIQUE INDEX IF NOT EXISTS profile_role_one_primary_per_tenant
  ON public.profile_role_assignments(user_id, tenant_id)
  WHERE is_primary = true;

CREATE INDEX IF NOT EXISTS profile_role_tenant_role_idx
  ON public.profile_role_assignments(tenant_id, role, user_id);

-- Explicit branch assignments. A profile's profiles.branch_id remains its
-- default branch for compatibility; this table represents additional scope.
CREATE TABLE IF NOT EXISTS public.profile_branch_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  is_default boolean NOT NULL DEFAULT false,
  granted_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  granted_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, tenant_id, branch_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS profile_branch_one_default_per_tenant
  ON public.profile_branch_assignments(user_id, tenant_id)
  WHERE is_default = true;

CREATE INDEX IF NOT EXISTS profile_branch_tenant_branch_idx
  ON public.profile_branch_assignments(tenant_id, branch_id, user_id);

-- Non-clinical extended registration data that is not represented in the
-- deployed members table. JSONB is divided into named sections to preserve
-- the existing frontend contract while allowing future normalization.
CREATE TABLE IF NOT EXISTS public.member_details (
  member_id uuid PRIMARY KEY REFERENCES public.members(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
  registration_data jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(registration_data) = 'object'),
  spiritual_data jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(spiritual_data) = 'object'),
  household_data jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(household_data) = 'object'),
  professional_data jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(professional_data) = 'object'),
  lifecycle_data jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(lifecycle_data) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS member_details_tenant_branch_idx
  ON public.member_details(tenant_id, branch_id);

-- Highly sensitive information is isolated from ordinary member profile data.
-- Access must be restricted by a dedicated permission and must not be granted
-- to MINISTRY_LEADER or general SYSTEM_ADMIN roles by default.
CREATE TABLE IF NOT EXISTS public.member_private_details (
  member_id uuid PRIMARY KEY REFERENCES public.members(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE RESTRICT,
  emergency_contact jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(emergency_contact) = 'object'),
  health_information jsonb NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(health_information) = 'object'),
  access_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS member_private_details_tenant_branch_idx
  ON public.member_private_details(tenant_id, branch_id);

-- Composite uniqueness enables database-enforced tenant consistency.
CREATE UNIQUE INDEX IF NOT EXISTS members_id_tenant_branch_unique
  ON public.members(id, tenant_id, branch_id);
CREATE UNIQUE INDEX IF NOT EXISTS members_id_tenant_unique
  ON public.members(id, tenant_id);
CREATE UNIQUE INDEX IF NOT EXISTS branches_id_tenant_unique
  ON public.branches(id, tenant_id);
CREATE UNIQUE INDEX IF NOT EXISTS profiles_id_tenant_unique
  ON public.profiles(id, tenant_id);

ALTER TABLE public.ministries ADD COLUMN IF NOT EXISTS leader_user_id uuid;
ALTER TABLE public.ministries ADD COLUMN IF NOT EXISTS leader_member_id uuid;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.ministries'::regclass AND conname='ministries_leader_user_tenant_fkey') THEN
    ALTER TABLE public.ministries ADD CONSTRAINT ministries_leader_user_tenant_fkey
      FOREIGN KEY(leader_user_id,tenant_id) REFERENCES public.profiles(id,tenant_id) ON DELETE SET NULL (leader_user_id) NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.ministries'::regclass AND conname='ministries_leader_member_tenant_fkey') THEN
    ALTER TABLE public.ministries ADD CONSTRAINT ministries_leader_member_tenant_fkey
      FOREIGN KEY(leader_member_id,tenant_id) REFERENCES public.members(id,tenant_id) ON DELETE SET NULL (leader_member_id) NOT VALID;
  END IF;
END $$;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.families'::regclass AND conname='families_branch_tenant_fkey') THEN
    ALTER TABLE public.families ADD CONSTRAINT families_branch_tenant_fkey
      FOREIGN KEY(branch_id,tenant_id) REFERENCES public.branches(id,tenant_id)
      ON DELETE SET NULL (branch_id) NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.families'::regclass AND conname='families_head_member_tenant_fkey') THEN
    ALTER TABLE public.families ADD CONSTRAINT families_head_member_tenant_fkey
      FOREIGN KEY(head_member_id,tenant_id) REFERENCES public.members(id,tenant_id)
      ON DELETE RESTRICT NOT VALID;
  END IF;
END $$;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.member_details'::regclass AND conname='member_details_member_tenant_branch_fkey') THEN
    ALTER TABLE public.member_details ADD CONSTRAINT member_details_member_tenant_branch_fkey
      FOREIGN KEY(member_id,tenant_id,branch_id) REFERENCES public.members(id,tenant_id,branch_id)
      ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.member_private_details'::regclass AND conname='member_private_details_member_tenant_branch_fkey') THEN
    ALTER TABLE public.member_private_details ADD CONSTRAINT member_private_details_member_tenant_branch_fkey
      FOREIGN KEY(member_id,tenant_id,branch_id) REFERENCES public.members(id,tenant_id,branch_id)
      ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.profile_role_assignments'::regclass AND conname='profile_role_assignments_user_tenant_fkey') THEN
    ALTER TABLE public.profile_role_assignments ADD CONSTRAINT profile_role_assignments_user_tenant_fkey
      FOREIGN KEY(user_id,tenant_id) REFERENCES public.profiles(id,tenant_id)
      ON DELETE CASCADE NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.profile_branch_assignments'::regclass AND conname='profile_branch_assignments_user_tenant_fkey') THEN
    ALTER TABLE public.profile_branch_assignments ADD CONSTRAINT profile_branch_assignments_user_tenant_fkey
      FOREIGN KEY(user_id,tenant_id) REFERENCES public.profiles(id,tenant_id)
      ON DELETE CASCADE NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.profile_branch_assignments'::regclass AND conname='profile_branch_assignments_branch_tenant_fkey') THEN
    ALTER TABLE public.profile_branch_assignments ADD CONSTRAINT profile_branch_assignments_branch_tenant_fkey
      FOREIGN KEY(branch_id,tenant_id) REFERENCES public.branches(id,tenant_id)
      ON DELETE CASCADE NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.profiles'::regclass AND conname='profiles_member_tenant_fkey') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_member_tenant_fkey
      FOREIGN KEY(member_id,tenant_id) REFERENCES public.members(id,tenant_id)
      ON DELETE SET NULL (member_id) NOT VALID;
  END IF;
END $$;

-- New detail/assignment tables are not directly exposed to anon/authenticated
-- clients. Access is through authenticated server APIs until narrowly-scoped
-- policies are introduced and tested in a later security migration.
ALTER TABLE public.profile_role_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profile_branch_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.member_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.member_private_details ENABLE ROW LEVEL SECURITY;

COMMENT ON TABLE public.member_details IS
  'Extended non-clinical member registration attributes; access must be tenant/branch scoped.';
COMMENT ON TABLE public.member_private_details IS
  'Sensitive emergency and health information; requires dedicated least-privilege authorization.';
COMMENT ON COLUMN public.profiles.member_id IS
  'Explicit link from an authenticated profile to its member record; intentionally not backfilled by email.';

COMMIT;
