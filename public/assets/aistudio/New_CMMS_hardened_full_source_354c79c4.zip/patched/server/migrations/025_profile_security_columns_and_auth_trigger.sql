-- ==============================================================================
-- CMMS MIGRATION 025: PROFILE SECURITY COLUMN IMMUTABILITY & SAFE AUTO-PROVISIONING
-- ==============================================================================

-- 1. Create trigger function to block non-admin modification of sensitive security columns
CREATE OR REPLACE FUNCTION public.check_profile_security_columns_immutable()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    cur_role TEXT;
BEGIN
    cur_role := public.get_current_role();
    IF cur_role != 'SYSTEM_ADMIN' THEN
        -- Disallow updating sensitive security and governance columns by non-admins
        IF (NEW.role IS DISTINCT FROM OLD.role) OR
           (NEW.tenant_id IS DISTINCT FROM OLD.tenant_id) OR
           (NEW.mfa_enabled IS DISTINCT FROM OLD.mfa_enabled) OR
           (NEW.must_change_password IS DISTINCT FROM OLD.must_change_password) OR
           (NEW.branch_id IS DISTINCT FROM OLD.branch_id) OR
           (NEW.status IS DISTINCT FROM OLD.status) OR
           (NEW.member_id IS DISTINCT FROM OLD.member_id) THEN
            RAISE EXCEPTION 'UNAUTHORIZED_COLUMN_MUTATION: Only SYSTEM_ADMIN can modify sensitive profile governance attributes.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_profile_security_columns ON public.profiles;
CREATE TRIGGER trg_protect_profile_security_columns
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.check_profile_security_columns_immutable();

-- 2. Update Profiles update policy with explicit checks on sensitive columns
DROP POLICY IF EXISTS "Profiles update policy" ON public.profiles;
CREATE POLICY "Profiles update policy" ON public.profiles
    FOR UPDATE TO authenticated
    USING (
        (auth.uid() = id OR auth.uid() = user_id OR public.get_current_role() = 'SYSTEM_ADMIN')
        AND (tenant_id = public.get_current_tenant_id() OR public.get_current_role() = 'SYSTEM_ADMIN')
    )
    WITH CHECK (
        (public.get_current_role() = 'SYSTEM_ADMIN')
        OR (
            role = (SELECT p.role FROM public.profiles p WHERE p.id = auth.uid())
            AND tenant_id = (SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid())
            AND mfa_enabled IS NOT DISTINCT FROM (SELECT p.mfa_enabled FROM public.profiles p WHERE p.id = auth.uid())
            AND must_change_password IS NOT DISTINCT FROM (SELECT p.must_change_password FROM public.profiles p WHERE p.id = auth.uid())
            AND branch_id IS NOT DISTINCT FROM (SELECT p.branch_id FROM public.profiles p WHERE p.id = auth.uid())
            AND status IS NOT DISTINCT FROM (SELECT p.status FROM public.profiles p WHERE p.id = auth.uid())
            AND member_id IS NOT DISTINCT FROM (SELECT p.member_id FROM public.profiles p WHERE p.id = auth.uid())
        )
    );

-- 3. Revoke column-level update privileges for sensitive security columns
DO $$
BEGIN
    REVOKE UPDATE (role, tenant_id, mfa_enabled, must_change_password, branch_id, status, member_id) ON public.profiles FROM authenticated;
    GRANT UPDATE (full_name, display_name, phone, avatar_url, updated_at) ON public.profiles TO authenticated;
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END $$;

-- 4. Safe user creation trigger hardcoding REGULAR_MEMBER (never trust user_metadata for role)
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    def_tenant UUID;
    def_branch UUID;
    full_nm TEXT;
BEGIN
    SELECT id INTO def_tenant FROM public.tenants ORDER BY created_at ASC LIMIT 1;
    IF def_tenant IS NULL THEN
        def_tenant := 'a0000000-0000-0000-0000-000000000001'::uuid;
    END IF;

    SELECT id INTO def_branch FROM public.branches WHERE tenant_id = def_tenant ORDER BY is_headquarters DESC, created_at ASC LIMIT 1;
    IF def_branch IS NULL THEN
        def_branch := 'b0000000-0000-0000-0000-000000000001'::uuid;
    END IF;

    full_nm := COALESCE(
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'name',
        split_part(NEW.email, '@', 1)
    );

    -- Strict: Hardcode REGULAR_MEMBER. Never trust raw_user_meta_data for role.
    INSERT INTO public.profiles (
        id,
        user_id,
        tenant_id,
        branch_id,
        email,
        full_name,
        display_name,
        phone,
        role,
        status,
        must_change_password,
        mfa_enabled
    ) VALUES (
        NEW.id,
        NEW.id,
        def_tenant,
        def_branch,
        NEW.email,
        full_nm,
        full_nm,
        NEW.phone,
        'REGULAR_MEMBER',
        'Active',
        false,
        false
    )
    ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        phone = COALESCE(EXCLUDED.phone, public.profiles.phone);

    RETURN NEW;
END;
$$;

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'auth' AND table_name = 'users') THEN
        DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
        CREATE TRIGGER on_auth_user_created
            AFTER INSERT ON auth.users
            FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();
    END IF;
END $$;
