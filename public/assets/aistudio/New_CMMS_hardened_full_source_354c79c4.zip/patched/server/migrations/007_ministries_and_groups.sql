-- ==============================================================================
-- CMMS MIGRATION 007: MINISTRIES, DEPARTMENTS, GROUPS & ROSTERS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.ministries (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'General',
    description TEXT,
    director_member_id TEXT,
    coordinator_member_id TEXT,
    leader_member_id TEXT,
    leader_member_name TEXT,
    leader_name TEXT,
    member_ids TEXT[] NOT NULL DEFAULT '{}',
    meeting_schedule TEXT,
    meeting_time TEXT,
    meeting_location TEXT,
    budget_year_to_date NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    parent_ministry_id TEXT,
    established_date TEXT,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Pending')),
    member_count INT NOT NULL DEFAULT 0,
    annual_budget NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    spent_budget NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    sub_ministries JSONB NOT NULL DEFAULT '[]'::jsonb,
    monthly_allocations JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ministries_tenant ON public.ministries (tenant_id);
CREATE INDEX IF NOT EXISTS idx_ministries_branch ON public.ministries (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_ministries_leader ON public.ministries (leader_member_id);

CREATE TABLE IF NOT EXISTS public.ministry_members (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    ministry_id TEXT NOT NULL REFERENCES public.ministries(id) ON DELETE CASCADE,
    user_id TEXT,
    member_id TEXT,
    user_name TEXT,
    user_email TEXT,
    user_avatar TEXT,
    role TEXT DEFAULT 'Member' CHECK (
        role IN ('Leader', 'CoLeader', 'Director', 'Coordinator', 'Chairperson', 'Member', 'Volunteer')
    ),
    status TEXT DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Pending')),
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ministry_members_lookup ON public.ministry_members (ministry_id, member_id);
CREATE INDEX IF NOT EXISTS idx_ministry_members_user ON public.ministry_members (ministry_id, user_id);

CREATE TABLE IF NOT EXISTS public.groups (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'Cell Group',
    leader_name TEXT,
    leader_member_id TEXT,
    meeting_schedule TEXT,
    location TEXT,
    member_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_groups_tenant ON public.groups (tenant_id, branch_id);

CREATE TABLE IF NOT EXISTS public.ministry_activity_logs (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    ministry_id TEXT NOT NULL REFERENCES public.ministries(id) ON DELETE CASCADE,
    user_id TEXT,
    user_name TEXT,
    action_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ministry_activity_logs ON public.ministry_activity_logs (ministry_id, created_at DESC);
