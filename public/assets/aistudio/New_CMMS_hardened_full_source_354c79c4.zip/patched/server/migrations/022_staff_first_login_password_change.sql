-- ==============================================================================
-- CMMS MIGRATION 022: STAFF FIRST-LOGIN MANDATORY PASSWORD CHANGE & EXPIRY
-- ==============================================================================

-- Ensure profiles table has must_change_password and password tracking columns
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN IF NOT EXISTS password_changed_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS temp_password_expires_at TIMESTAMPTZ;

-- Refresh system_users view with updated security fields
CREATE OR REPLACE VIEW public.system_users AS
SELECT
    id,
    tenant_id,
    name,
    email,
    phone,
    photo_url,
    avatar,
    role,
    branch_name,
    branch_ids,
    assigned_campuses,
    status,
    last_login,
    is_mfa_enabled,
    mfa_enabled,
    approval_limit,
    approval_role_level,
    allowed_approval_types,
    notes,
    must_change_password,
    password_changed_at,
    temp_password_expires_at,
    last_max_auth_at,
    totp_secret,
    mfa_secret,
    created_at,
    updated_at
FROM public.profiles;

COMMENT ON COLUMN public.profiles.must_change_password IS 'Flag indicating if user must change their temporary password before accessing CMMS';
COMMENT ON COLUMN public.profiles.password_changed_at IS 'Timestamp of the most recent permanent password update';
COMMENT ON COLUMN public.profiles.temp_password_expires_at IS 'Optional expiration timestamp for temporary passwords (e.g. 24h)';
