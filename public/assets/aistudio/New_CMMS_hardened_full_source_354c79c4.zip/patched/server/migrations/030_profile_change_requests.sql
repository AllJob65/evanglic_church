-- 030_profile_change_requests.sql
-- Additive schema for PostgreSQL-backed member profile-change requests.
-- Review-only: do not apply to production until the application repository,
-- authorization policy, backup, and staging migration are approved.

BEGIN;

CREATE TABLE IF NOT EXISTS public.profile_change_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL,
  member_id uuid NOT NULL,
  submitted_by uuid,
  member_name text NOT NULL,
  member_email text,
  member_number text,
  changed_fields jsonb NOT NULL DEFAULT '[]'::jsonb
    CHECK (jsonb_typeof(changed_fields) = 'array'),
  requested_snapshot jsonb NOT NULL
    CHECK (jsonb_typeof(requested_snapshot) = 'object'),
  status text NOT NULL DEFAULT 'Pending'
    CHECK (status IN ('Pending', 'Approved', 'Rejected')),
  submitted_at timestamptz NOT NULL DEFAULT now(),
  reviewed_by uuid,
  reviewed_by_name text,
  reviewed_at timestamptz,
  rejection_reason text,
  decision_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT profile_change_requests_member_tenant_branch_fkey
    FOREIGN KEY (member_id, tenant_id, branch_id)
    REFERENCES public.members(id, tenant_id, branch_id)
    ON UPDATE CASCADE ON DELETE RESTRICT,

  CONSTRAINT profile_change_requests_submitter_tenant_fkey
    FOREIGN KEY (submitted_by, tenant_id)
    REFERENCES public.profiles(id, tenant_id)
    ON DELETE SET NULL (submitted_by),

  CONSTRAINT profile_change_requests_reviewer_tenant_fkey
    FOREIGN KEY (reviewed_by, tenant_id)
    REFERENCES public.profiles(id, tenant_id)
    ON DELETE SET NULL (reviewed_by),

  CONSTRAINT profile_change_requests_decision_consistency_check
    CHECK (
      (status = 'Pending' AND reviewed_at IS NULL AND reviewed_by IS NULL)
      OR
      (status IN ('Approved', 'Rejected') AND reviewed_at IS NOT NULL AND reviewed_by IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS profile_change_requests_queue_idx
  ON public.profile_change_requests (tenant_id, branch_id, submitted_at DESC)
  WHERE status = 'Pending';

CREATE INDEX IF NOT EXISTS profile_change_requests_member_history_idx
  ON public.profile_change_requests (tenant_id, member_id, submitted_at DESC);

-- Requests contain potentially sensitive member profile data. They are
-- accessed only through the authenticated Node API and its authorization
-- layer; browser roles receive no direct table access.
ALTER TABLE public.profile_change_requests ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.profile_change_requests FROM PUBLIC, anon, authenticated;

COMMENT ON TABLE public.profile_change_requests IS
  'Member profile-change requests; access through the authorized server API only.';
COMMENT ON COLUMN public.profile_change_requests.requested_snapshot IS
  'Validated requested member snapshot. Identity and tenant/branch keys are immutable and must be ignored on approval.';
COMMENT ON COLUMN public.profile_change_requests.changed_fields IS
  'Array of field-level change summaries used by the review UI.';

COMMIT;
