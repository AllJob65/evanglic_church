-- ==============================================================================
-- CMMS MIGRATION 024: PRODUCTION SECURITY AUDIT HARDENING, DURABLE SESSIONS,
-- TAMPER-EVIDENT HASH CHAINING, & APPEND-ONLY IMMUTABILITY TRIGGERS
-- ==============================================================================

-- 1. Extend public.audit_logs with full structured security & integrity columns
ALTER TABLE public.audit_logs
  ADD COLUMN IF NOT EXISTS actor_id TEXT,
  ADD COLUMN IF NOT EXISTS event_type TEXT,
  ADD COLUMN IF NOT EXISTS outcome TEXT NOT NULL DEFAULT 'SUCCESS',
  ADD COLUMN IF NOT EXISTS severity TEXT NOT NULL DEFAULT 'LOW',
  ADD COLUMN IF NOT EXISTS correlation_id TEXT,
  ADD COLUMN IF NOT EXISTS target_user_id TEXT,
  ADD COLUMN IF NOT EXISTS target_user_email TEXT,
  ADD COLUMN IF NOT EXISTS prev_hash TEXT,
  ADD COLUMN IF NOT EXISTS integrity_hash TEXT,
  ADD COLUMN IF NOT EXISTS schema_version TEXT NOT NULL DEFAULT '2.0';

-- High-performance indexes for audit querying, forensics, and integrity verification
CREATE INDEX IF NOT EXISTS idx_audit_logs_actor_id ON public.audit_logs (actor_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_type ON public.audit_logs (event_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_severity ON public.audit_logs (severity);
CREATE INDEX IF NOT EXISTS idx_audit_logs_outcome ON public.audit_logs (outcome);
CREATE INDEX IF NOT EXISTS idx_audit_logs_correlation_id ON public.audit_logs (correlation_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_integrity_hash ON public.audit_logs (integrity_hash);

-- 2. Database-enforced append-only immutability trigger on public.audit_logs
-- Prevents ordinary or accidental UPDATE / DELETE / TRUNCATE mutations on existing audit records
CREATE OR REPLACE FUNCTION public.prevent_audit_log_mutation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  RAISE EXCEPTION 'AUDIT_IMMUTABLE: Security audit records in public.audit_logs are append-only and cannot be modified or deleted.';
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_logs_immutable ON public.audit_logs;
CREATE TRIGGER trg_audit_logs_immutable
  BEFORE UPDATE OR DELETE ON public.audit_logs
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_audit_log_mutation();

-- Explicitly revoke UPDATE, DELETE, TRUNCATE on public.audit_logs from application roles
REVOKE UPDATE, DELETE, TRUNCATE ON TABLE public.audit_logs FROM anon, authenticated, public;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cmms_app_audit_writer') THEN
    CREATE ROLE cmms_app_audit_writer NOLOGIN;
  END IF;
END $$;

REVOKE ALL ON TABLE public.audit_logs FROM cmms_app_audit_writer;
GRANT SELECT, INSERT ON TABLE public.audit_logs TO cmms_app_audit_writer;

-- 2B. Independent Trusted Chain Head Checkpoints Table (Tamper-Evident Anchor)
CREATE TABLE IF NOT EXISTS public.audit_chain_checkpoints (
  tenant_id UUID PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  head_hash TEXT NOT NULL,
  last_record_id TEXT NOT NULL,
  chained_records_count INT NOT NULL DEFAULT 0,
  total_records_count INT NOT NULL DEFAULT 0,
  hmac_signature TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.audit_chain_checkpoints ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.audit_chain_checkpoints FROM anon, public;
GRANT SELECT, INSERT, UPDATE ON TABLE public.audit_chain_checkpoints TO authenticated;

DROP POLICY IF EXISTS "Audit checkpoints admin select" ON public.audit_chain_checkpoints;
CREATE POLICY "Audit checkpoints admin select" ON public.audit_chain_checkpoints
  FOR SELECT TO authenticated
  USING (public.get_current_role() = 'SYSTEM_ADMIN' AND tenant_id = public.get_current_tenant_id());

-- 3. Durable Security Sessions Registry Table (Survives restarts & multi-instance deployments)
CREATE TABLE IF NOT EXISTS public.security_sessions (
  session_id TEXT PRIMARY KEY,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  refresh_token_hash TEXT,
  user_id TEXT NOT NULL,
  user_email TEXT NOT NULL,
  user_name TEXT NOT NULL,
  user_role TEXT NOT NULL,
  branch_id TEXT,
  ip_address TEXT,
  user_agent TEXT,
  device TEXT,
  device_fingerprint TEXT,
  login_time TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_activity TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  aal TEXT NOT NULL DEFAULT 'aal1',
  mfa_verified BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'REVOKED', 'EXPIRED')),
  revoked_at TIMESTAMPTZ,
  revoked_by TEXT,
  revocation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_security_sessions_user ON public.security_sessions (user_id, status);
CREATE INDEX IF NOT EXISTS idx_security_sessions_email ON public.security_sessions (lower(user_email), status);
CREATE INDEX IF NOT EXISTS idx_security_sessions_token_hash ON public.security_sessions (token_hash);
CREATE INDEX IF NOT EXISTS idx_security_sessions_last_activity ON public.security_sessions (last_activity DESC);

-- 4. Durable Consumed Refresh Tokens Table (For cross-restart refresh-token reuse detection)
CREATE TABLE IF NOT EXISTS public.consumed_refresh_tokens (
  token_hash TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_email TEXT NOT NULL,
  consumed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_consumed_refresh_tokens_user ON public.consumed_refresh_tokens (user_id);

-- 5. Durable Security Alerts Table
CREATE TABLE IF NOT EXISTS public.security_alerts (
  id TEXT PRIMARY KEY,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
  alert_type TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  actor_id TEXT,
  actor_email TEXT,
  ip_address TEXT,
  correlation_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'ACKNOWLEDGED', 'RESOLVED')),
  acknowledged_by TEXT,
  acknowledged_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_security_alerts_status_ts ON public.security_alerts (status, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_security_alerts_actor ON public.security_alerts (actor_email);

-- 6. Enable Row-Level Security & Restrict Access to SYSTEM_ADMIN
ALTER TABLE public.security_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consumed_refresh_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_alerts ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.security_sessions FROM anon, public;
REVOKE ALL ON TABLE public.consumed_refresh_tokens FROM anon, public;
REVOKE ALL ON TABLE public.security_alerts FROM anon, public;

GRANT SELECT, INSERT, UPDATE ON TABLE public.security_sessions TO authenticated;
GRANT SELECT, INSERT ON TABLE public.consumed_refresh_tokens TO authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.security_alerts TO authenticated;

DROP POLICY IF EXISTS "Security sessions admin select" ON public.security_sessions;
CREATE POLICY "Security sessions admin select" ON public.security_sessions
  FOR SELECT TO authenticated
  USING (public.get_current_role() = 'SYSTEM_ADMIN' OR user_id = auth.uid()::text);

DROP POLICY IF EXISTS "Security alerts admin select" ON public.security_alerts;
CREATE POLICY "Security alerts admin select" ON public.security_alerts
  FOR SELECT TO authenticated
  USING (public.get_current_role() = 'SYSTEM_ADMIN');
