-- ==============================================================================
-- CMMS MIGRATION 010: EVENTS, CONFERENCES & WORKSHOPS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.events (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    ministry_id TEXT,
    title TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'Conference',
    event_type TEXT DEFAULT 'Conference',
    category TEXT,
    start_date TIMESTAMPTZ NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    date TIMESTAMPTZ,
    time TEXT,
    location TEXT NOT NULL,
    description TEXT,
    poster_url TEXT,
    speaker_names TEXT[] NOT NULL DEFAULT '{}',
    speakers TEXT[] NOT NULL DEFAULT '{}',
    capacity INT NOT NULL DEFAULT 500,
    registered_count INT NOT NULL DEFAULT 0,
    is_paid BOOLEAN NOT NULL DEFAULT false,
    ticket_price NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    ticket_types JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'Upcoming' CHECK (
        status IN ('Upcoming', 'In Progress', 'Completed', 'Cancelled')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_events_tenant_start ON public.events (tenant_id, start_date DESC);
CREATE INDEX IF NOT EXISTS idx_events_branch ON public.events (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_events_status ON public.events (tenant_id, status);
