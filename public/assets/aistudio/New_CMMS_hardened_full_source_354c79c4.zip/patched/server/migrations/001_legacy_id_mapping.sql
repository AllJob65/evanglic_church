-- Stable crosswalk between legacy CMMS string IDs and PostgreSQL UUIDs.
-- This migration stores mappings only; it does not move, delete, or rewrite
-- any existing application records.
CREATE TABLE IF NOT EXISTS public.cmms_legacy_id_map (
  entity_type TEXT NOT NULL,
  legacy_id TEXT NOT NULL,
  postgres_id UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_legacy_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (entity_type, legacy_id),
  UNIQUE (entity_type, postgres_id)
);

CREATE INDEX IF NOT EXISTS idx_cmms_legacy_id_map_postgres
  ON public.cmms_legacy_id_map (entity_type, postgres_id);

COMMENT ON TABLE public.cmms_legacy_id_map IS
  'Stable ID crosswalk for staged CMMS legacy-to-PostgreSQL migration. Never truncate during migration.';

-- This table is internal migration metadata, not an API-facing data source.
ALTER TABLE public.cmms_legacy_id_map ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.cmms_legacy_id_map FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.cmms_legacy_id_map TO service_role;
