-- ==============================================================================
-- CMMS MIGRATION 012: PASTORAL RECORDS, PRAYER REQUESTS, COUNSELING & VISITATIONS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.prayer_requests (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    request_number TEXT NOT NULL,
    member_id TEXT,
    member_name TEXT NOT NULL,
    requester_name TEXT,
    requester_user_id TEXT,
    phone TEXT,
    email TEXT,
    category TEXT DEFAULT 'Spiritual Concern',
    title TEXT NOT NULL,
    topic TEXT,
    description TEXT NOT NULL,
    details TEXT,
    is_confidential BOOLEAN NOT NULL DEFAULT false,
    confidentiality_level TEXT,
    urgency TEXT NOT NULL DEFAULT 'Medium' CHECK (
        urgency IN ('Low', 'Medium', 'High', 'Emergency')
    ),
    urgency_level TEXT,
    priority TEXT,
    assigned_intercessor_id TEXT,
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (
        status IN ('Pending', 'Praying', 'Answered', 'Closed')
    ),
    submitted_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    submitted_at TIMESTAMPTZ,
    testimony_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, request_number)
);

CREATE INDEX IF NOT EXISTS idx_prayer_requests_tenant ON public.prayer_requests (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_prayer_requests_member ON public.prayer_requests (tenant_id, member_id);

CREATE TABLE IF NOT EXISTS public.counseling (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    session_code TEXT NOT NULL,
    client_member_id TEXT,
    client_name TEXT NOT NULL,
    counselor_id TEXT,
    counselor_user_id TEXT,
    counselor_name TEXT NOT NULL,
    counseling_type TEXT NOT NULL DEFAULT 'Individual',
    session_date TIMESTAMPTZ NOT NULL,
    session_time TEXT,
    mode TEXT NOT NULL DEFAULT 'In-Person' CHECK (mode IN ('In-Person', 'Virtual Video Call')),
    status TEXT NOT NULL DEFAULT 'Scheduled' CHECK (
        status IN ('Requested', 'Scheduled', 'Completed', 'Cancelled')
    ),
    confidentiality TEXT NOT NULL DEFAULT 'CONFIDENTIAL' CHECK (
        confidentiality IN ('CONFIDENTIAL', 'SEALED', 'GENERAL')
    ),
    encrypted_case_notes TEXT,
    private_clinical_notes TEXT,
    action_items TEXT,
    treatment_goals JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, session_code)
);

CREATE INDEX IF NOT EXISTS idx_counseling_tenant ON public.counseling (tenant_id, session_date DESC);
CREATE INDEX IF NOT EXISTS idx_counseling_client ON public.counseling (tenant_id, client_member_id);

CREATE TABLE IF NOT EXISTS public.pastoral_records (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    member_id TEXT,
    counselor_user_id TEXT,
    category TEXT NOT NULL,
    confidentiality TEXT NOT NULL DEFAULT 'MINISTERIAL' CHECK (
        confidentiality IN ('CONFIDENTIAL', 'SEALED', 'MINISTERIAL', 'GENERAL')
    ),
    summary TEXT NOT NULL,
    details TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Open',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pastoral_records_member ON public.pastoral_records (tenant_id, member_id);

CREATE TABLE IF NOT EXISTS public.visitations (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    visitation_code TEXT NOT NULL,
    member_id TEXT NOT NULL,
    member_name TEXT NOT NULL,
    visitor_names TEXT[] NOT NULL DEFAULT '{}',
    visitation_type TEXT NOT NULL,
    visit_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    location TEXT NOT NULL,
    summary_notes TEXT NOT NULL,
    prayer_points TEXT[] NOT NULL DEFAULT '{}',
    follow_up_required BOOLEAN NOT NULL DEFAULT false,
    follow_up_due_date TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'Completed' CHECK (
        status IN ('Completed', 'Follow-up Pending', 'Closed')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_visitations_member ON public.visitations (tenant_id, member_id);
