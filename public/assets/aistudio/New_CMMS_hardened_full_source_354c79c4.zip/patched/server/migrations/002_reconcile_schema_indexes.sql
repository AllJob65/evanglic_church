-- Reconcile indexes to the actual columns defined in supabase/schema.sql.
-- Refuse to mark this migration successful if the baseline schema is absent.
DO $cmms$
DECLARE
  required_tables TEXT[] := ARRAY[
    'tenants', 'branches', 'profiles', 'members', 'families', 'ministries',
    'ministry_members', 'groups', 'attendance_records', 'attendance', 'events',
    'financial_transactions', 'donations', 'pastoral_records', 'prayer_requests',
    'counseling', 'documents', 'workflow_requests', 'volunteer_shifts', 'assets',
    'lms_courses', 'group_chats', 'video_conferences', 'audit_logs',
    'conversations', 'conversation_participants', 'conversation_messages'
  ];
  missing_tables TEXT[];
BEGIN
  SELECT array_agg(required_name)
    INTO missing_tables
    FROM unnest(required_tables) AS required_name
   WHERE to_regclass('public.' || required_name) IS NULL;

  IF missing_tables IS NOT NULL THEN
    RAISE EXCEPTION
      'CMMS baseline schema is incomplete. Missing tables: % . Apply and validate supabase/schema.sql before continuing.',
      array_to_string(missing_tables, ', ');
  END IF;

  IF to_regclass('public.families') IS NOT NULL
     AND EXISTS (
       SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'public' AND table_name = 'families' AND column_name = 'member_ids'
     ) THEN
    CREATE INDEX IF NOT EXISTS idx_families_member_ids_gin
      ON public.families USING GIN (member_ids);
  END IF;

  IF to_regclass('public.attendance_records') IS NOT NULL
     AND EXISTS (
       SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'public' AND table_name = 'attendance_records' AND column_name = 'checkin_time'
     ) THEN
    CREATE INDEX IF NOT EXISTS idx_attendance_records_tenant_branch_checkin
      ON public.attendance_records (tenant_id, branch_id, checkin_time DESC);
    CREATE INDEX IF NOT EXISTS idx_attendance_records_member_checkin
      ON public.attendance_records (member_id, checkin_time DESC);
  END IF;

  IF to_regclass('public.audit_logs') IS NOT NULL
     AND EXISTS (
       SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'public' AND table_name = 'audit_logs' AND column_name = 'created_at'
     ) THEN
    CREATE INDEX IF NOT EXISTS idx_audit_logs_tenant_created
      ON public.audit_logs (tenant_id, created_at DESC);
  END IF;
END $cmms$;
