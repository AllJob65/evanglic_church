-- 026_auth_onboarding_and_role_backfill.sql
-- Review-only migration. Apply only after backup, schema preflight, and approval.
-- Fixes privilege escalation from user-controlled signup metadata and seeds
-- normalized role/branch assignment tables for the already-existing profiles.

BEGIN;

-- Preserve each existing profile's current primary role, but do not trust
-- auth.users.raw_user_meta_data.role for any future signup.
INSERT INTO public.profile_role_assignments(user_id,tenant_id,role,is_primary,granted_at)
SELECT p.id,p.tenant_id,p.role,true,COALESCE(p.created_at,now())
FROM public.profiles p
WHERE p.tenant_id IS NOT NULL
  AND p.role IN ('SYSTEM_ADMIN','PASTOR','MINISTRY_LEADER','REGULAR_MEMBER','MANAGER')
ON CONFLICT(user_id,tenant_id,role) DO UPDATE
SET is_primary = true;

-- Copy only real UUID branch assignments from the authoritative profiles row.
INSERT INTO public.profile_branch_assignments(user_id,tenant_id,branch_id,is_default,granted_at)
SELECT p.id,p.tenant_id,p.branch_id,true,COALESCE(p.created_at,now())
FROM public.profiles p
JOIN public.branches b ON b.id=p.branch_id AND b.tenant_id=p.tenant_id
WHERE p.tenant_id IS NOT NULL AND p.branch_id IS NOT NULL
ON CONFLICT(user_id,tenant_id,branch_id) DO UPDATE
SET is_default = true;

-- Public sign-up cannot select a role, tenant, or branch through editable
-- user metadata. In a single-active-tenant installation the profile is placed
-- into that tenant with the least-privilege REGULAR_MEMBER role. With multiple
-- active tenants, the profile is left unassigned/Pending until an invitation
-- or an administrator assigns its tenant.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $function$
DECLARE
  active_tenant_count integer;
  resolved_tenant_id uuid;
  resolved_name text;
BEGIN
  SELECT COUNT(*)::integer, (array_agg(t.id ORDER BY t.created_at))[1]
    INTO active_tenant_count, resolved_tenant_id
  FROM public.tenants t
  WHERE t.status = 'Active';

  IF active_tenant_count <> 1 THEN
    resolved_tenant_id := NULL;
  END IF;

  resolved_name := COALESCE(
    NULLIF(BTRIM(NEW.raw_user_meta_data->>'full_name'), ''),
    NULLIF(BTRIM(NEW.raw_user_meta_data->>'name'), ''),
    NULLIF(SPLIT_PART(COALESCE(NEW.email,''), '@', 1), ''),
    'New Member'
  );

  INSERT INTO public.profiles (
    id, tenant_id, branch_id, full_name, email, role, status
  )
  VALUES (
    NEW.id,
    resolved_tenant_id,
    NULL,
    resolved_name,
    COALESCE(NEW.email, ''),
    'REGULAR_MEMBER',
    CASE WHEN resolved_tenant_id IS NULL THEN 'Pending' ELSE 'Active' END
  )
  ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        full_name = EXCLUDED.full_name,
        updated_at = now();

  IF resolved_tenant_id IS NOT NULL THEN
    INSERT INTO public.profile_role_assignments(user_id,tenant_id,role,is_primary,granted_at)
    VALUES(NEW.id,resolved_tenant_id,'REGULAR_MEMBER',true,now())
    ON CONFLICT(user_id,tenant_id,role) DO UPDATE SET is_primary=true;
  END IF;
  RETURN NEW;
END;
$function$;

ALTER FUNCTION public.handle_new_user() SET search_path = pg_catalog, public;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;

COMMIT;
