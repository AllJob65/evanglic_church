-- ==============================================================================
-- CMMS MIGRATION 002: TENANTS AND MULTI-CAMPUS BRANCHES
-- ==============================================================================

-- Tenants root container
CREATE TABLE IF NOT EXISTS public.tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'Active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Branches / Campuses within tenant
CREATE TABLE IF NOT EXISTS public.branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'Headquarters' CHECK (
        type IN ('Headquarters', 'Satellite Campus', 'Outreach Location', 'Regional Center')
    ),
    parent_branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    senior_pastor TEXT,
    pastor_name TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    address TEXT,
    location TEXT,
    city TEXT,
    region TEXT,
    gps_coordinates TEXT,
    service_times JSONB NOT NULL DEFAULT '[]'::jsonb,
    languages TEXT[] NOT NULL DEFAULT '{}',
    timezone TEXT NOT NULL DEFAULT 'Africa/Addis_Ababa',
    established_date TEXT,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (
        status IN ('Active', 'Under Construction', 'Merged', 'Inactive')
    ),
    total_members_count INT NOT NULL DEFAULT 0,
    capacity INT,
    monthly_target_budget NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, code)
);

CREATE INDEX IF NOT EXISTS idx_branches_tenant ON public.branches (tenant_id);
CREATE INDEX IF NOT EXISTS idx_branches_status ON public.branches (tenant_id, status);
