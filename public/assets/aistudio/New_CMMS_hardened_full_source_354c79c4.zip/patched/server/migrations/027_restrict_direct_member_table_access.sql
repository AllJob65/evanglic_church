-- 027_restrict_direct_member_table_access.sql
-- Review-only migration. Apply only after the API cutover is verified in a
-- staging environment. This prevents browser Supabase roles from using the
-- currently permissive legacy member-table RLS policies directly.
-- Server routes access these tables through the server-only DATABASE_URL.

BEGIN;

REVOKE ALL PRIVILEGES ON TABLE
  public.members,
  public.ministry_members,
  public.member_details,
  public.member_private_details
FROM PUBLIC, anon, authenticated;

-- No direct browser grants are reintroduced here. The Express API is the
-- supported access path and enforces verified JWT, tenant, branch, and
-- application permission checks before issuing PostgreSQL queries.

COMMIT;
