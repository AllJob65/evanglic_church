-- ==============================================================================
-- CMMS MIGRATION 008: ATTENDANCE SESSIONS & ATTENDANCE RECORDS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.attendance_sessions (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    group_id TEXT NOT NULL,
    group_name TEXT,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    leader_id TEXT NOT NULL,
    leader_name TEXT,
    type TEXT NOT NULL DEFAULT 'instant' CHECK (type IN ('instant', 'scheduled')),
    title TEXT NOT NULL,
    service_type TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'closed')),
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    qr_payload_token TEXT NOT NULL,
    location TEXT,
    attendee_count INT DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_att_sessions_tenant ON public.attendance_sessions (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_att_sessions_group ON public.attendance_sessions (tenant_id, group_id);

CREATE TABLE IF NOT EXISTS public.attendance_records (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    record_id TEXT,
    session_id TEXT,
    service_name TEXT,
    service_type TEXT,
    service_session TEXT,
    event_name TEXT,
    event_id TEXT,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    time TEXT,
    member_id TEXT NOT NULL,
    member_name TEXT,
    visitor_name TEXT,
    visitor_phone TEXT,
    check_in_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    checked_in_time TIMESTAMPTZ,
    check_in_type TEXT DEFAULT 'qr',
    check_in_method TEXT DEFAULT 'QR Code Scanning',
    status TEXT NOT NULL DEFAULT 'Present',
    absence_reason TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_attendance_tenant_date ON public.attendance_records (tenant_id, branch_id, date);
CREATE INDEX IF NOT EXISTS idx_attendance_member ON public.attendance_records (tenant_id, member_id);
CREATE INDEX IF NOT EXISTS idx_attendance_session ON public.attendance_records (session_id);

CREATE TABLE IF NOT EXISTS public.attendance (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE CASCADE,
    event_id TEXT,
    service_type TEXT NOT NULL DEFAULT 'Sunday Service',
    member_id TEXT,
    check_in_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    verified_by TEXT,
    method TEXT DEFAULT 'QR_CODE' CHECK (method IN ('QR_CODE', 'MANUAL', 'SELF_CHECKIN', 'FACIAL_ID')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_attendance_canonical ON public.attendance (tenant_id, member_id, check_in_time);
