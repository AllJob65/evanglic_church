-- ==============================================================================
-- CMMS MIGRATION 006: FAMILIES, HOUSEHOLDS & PROFILE CHANGE REQUESTS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.families (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    family_code TEXT NOT NULL,
    household_name TEXT NOT NULL,
    head_of_household_member_id TEXT,
    primary_household_phone TEXT,
    family_type TEXT DEFAULT 'Nuclear Family' CHECK (
        family_type IN ('Nuclear Family', 'Extended Family', 'Single Parent', 'Blended Family', 'Other')
    ),
    family_photo_url TEXT,
    primary_language TEXT DEFAULT 'Amharic',
    address TEXT,
    woreda TEXT,
    kebele TEXT,
    house_number TEXT,
    city TEXT DEFAULT 'Addis Ababa',
    region TEXT DEFAULT 'Addis Ababa',
    member_ids JSONB DEFAULT '[]'::jsonb,
    relationships JSONB DEFAULT '[]'::jsonb,
    registration_date TIMESTAMPTZ DEFAULT now(),
    status TEXT DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Archived')),
    total_giving_year_to_date NUMERIC(12, 2) DEFAULT 0.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, family_code)
);

CREATE INDEX IF NOT EXISTS idx_families_tenant ON public.families (tenant_id);
CREATE INDEX IF NOT EXISTS idx_families_code ON public.families (tenant_id, family_code);

CREATE TABLE IF NOT EXISTS public.profile_change_requests (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    member_id TEXT NOT NULL,
    member_id_number TEXT,
    member_name TEXT NOT NULL,
    member_email TEXT,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    reviewed_by TEXT,
    reviewed_at TIMESTAMPTZ,
    rejection_reason TEXT,
    changed_fields JSONB DEFAULT '[]'::jsonb,
    new_snapshot JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_profile_change_requests ON public.profile_change_requests (tenant_id, status);
