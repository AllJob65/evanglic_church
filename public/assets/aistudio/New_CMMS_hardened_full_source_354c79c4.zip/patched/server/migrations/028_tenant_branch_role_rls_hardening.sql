-- 028_tenant_branch_role_rls_hardening.sql
-- Review-only. Apply after migrations 025 and 026 on a staging clone first.
-- All browser-facing policies are tenant/branch/role scoped. Server-side
-- service-role and private DATABASE_URL access remain subject to server RBAC.

BEGIN;

CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC;
GRANT USAGE ON SCHEMA private TO authenticated;

CREATE OR REPLACE FUNCTION private.current_tenant_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT p.tenant_id FROM public.profiles p WHERE p.id = auth.uid() LIMIT 1
$$;

CREATE OR REPLACE FUNCTION private.has_cmms_role(required_role text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profile_role_assignments ra
    WHERE ra.user_id = auth.uid()
      AND ra.tenant_id = private.current_tenant_id()
      AND ra.role = required_role
  ) OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND p.tenant_id = private.current_tenant_id()
      AND p.role = required_role
  )
$$;

CREATE OR REPLACE FUNCTION private.has_any_cmms_role(required_roles text[])
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profile_role_assignments ra
    WHERE ra.user_id = auth.uid()
      AND ra.tenant_id = private.current_tenant_id()
      AND ra.role = ANY(required_roles)
  ) OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND p.tenant_id = private.current_tenant_id()
      AND p.role = ANY(required_roles)
  )
$$;

CREATE OR REPLACE FUNCTION private.branch_allowed(target_branch uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT target_branch IS NULL
    OR private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
    OR EXISTS (
      SELECT 1 FROM public.profile_branch_assignments ba
      WHERE ba.user_id = auth.uid()
        AND ba.tenant_id = private.current_tenant_id()
        AND ba.branch_id = target_branch
    )
    OR EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid()
        AND p.tenant_id = private.current_tenant_id()
        AND p.branch_id = target_branch
    )
$$;

REVOKE ALL ON FUNCTION private.current_tenant_id() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.has_cmms_role(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.has_any_cmms_role(text[]) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.branch_allowed(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.current_tenant_id() TO authenticated;
GRANT EXECUTE ON FUNCTION private.has_cmms_role(text) TO authenticated;
GRANT EXECUTE ON FUNCTION private.has_any_cmms_role(text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION private.branch_allowed(uuid) TO authenticated;

-- Ensure RLS is enabled for every managed exposed table.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'tenants','branches','profiles','members','member_details','member_private_details',
    'profile_role_assignments','profile_branch_assignments','families','ministries',
    'ministry_members','attendance_records','pastoral_records','financial_transactions',
    'workflow_requests','events','volunteer_shifts','assets','documents','lms_courses','audit_logs'
  ] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
  END LOOP;
END $$;

-- Replace the known unrestricted policies and any other existing policies
-- on the managed tables, so permissive policies cannot combine with these.
DO $$
DECLARE t text; p record;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'tenants','branches','profiles','members','member_details','member_private_details',
    'profile_role_assignments','profile_branch_assignments','families','ministries',
    'ministry_members','attendance_records','pastoral_records','financial_transactions',
    'workflow_requests','events','volunteer_shifts','assets','documents','lms_courses',
    'audit_logs'
  ] LOOP
    FOR p IN SELECT policyname FROM pg_policies WHERE schemaname='public' AND tablename=t LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I',p.policyname,t);
    END LOOP;
  END LOOP;
END $$;

-- Tenant and branch directory.
CREATE POLICY tenants_select_current ON public.tenants
  FOR SELECT TO authenticated
  USING (id = private.current_tenant_id());

CREATE POLICY branches_select_scoped ON public.branches
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(id));
CREATE POLICY branches_insert_admin ON public.branches
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));
CREATE POLICY branches_update_admin ON public.branches
  FOR UPDATE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));
CREATE POLICY branches_delete_admin ON public.branches
  FOR DELETE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));

-- Profiles: users can read/update only themselves; system admins can manage
-- profiles in their own tenant. Privilege assignment tables are admin-only.
CREATE POLICY profiles_select_self_or_admin ON public.profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN')));
CREATE POLICY role_assignments_select_self_or_admin ON public.profile_role_assignments
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN')));
CREATE POLICY role_assignments_admin_manage ON public.profile_role_assignments
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));

CREATE POLICY branch_assignments_select_self_or_admin ON public.profile_branch_assignments
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN')));
CREATE POLICY branch_assignments_admin_manage ON public.profile_branch_assignments
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));

-- Member directory. Ordinary members see only their linked profile record.
CREATE POLICY members_select_scoped ON public.members
  FOR SELECT TO authenticated
  USING (
    tenant_id = private.current_tenant_id()
    AND private.branch_allowed(branch_id)
    AND (
      private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR id = (SELECT p.member_id FROM public.profiles p WHERE p.id = auth.uid())
    )
  );
CREATE POLICY members_insert_staff ON public.members
  FOR INSERT TO authenticated
  WITH CHECK (
    tenant_id = private.current_tenant_id()
    AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
  );
CREATE POLICY members_update_staff ON public.members
  FOR UPDATE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));
CREATE POLICY members_delete_admin ON public.members
  FOR DELETE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));

CREATE POLICY member_details_select_staff ON public.member_details
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));
CREATE POLICY member_details_write_staff ON public.member_details
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));
CREATE POLICY member_private_select_pastoral ON public.member_private_details
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));
CREATE POLICY member_private_write_pastoral ON public.member_private_details
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));

-- Families and ministry rosters.
CREATE POLICY families_select_scoped ON public.families
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));
CREATE POLICY families_write_staff ON public.families
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));

CREATE POLICY ministries_select_scoped ON public.ministries
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id));
CREATE POLICY ministries_write_leaders ON public.ministries
  FOR ALL TO authenticated
  USING (
    tenant_id = private.current_tenant_id()
    AND private.branch_allowed(branch_id)
    AND (
      private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR (
        private.has_cmms_role('MINISTRY_LEADER')
        AND (leader_user_id=auth.uid()
          OR leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
      )
    )
  )
  WITH CHECK (
    tenant_id = private.current_tenant_id()
    AND private.branch_allowed(branch_id)
    AND (
      private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR (
        private.has_cmms_role('MINISTRY_LEADER')
        AND (leader_user_id=auth.uid()
          OR leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
      )
    )
  );
CREATE POLICY ministry_members_select_scoped ON public.ministry_members
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.ministries m
      WHERE m.id=ministry_id AND m.tenant_id=private.current_tenant_id()
        AND private.branch_allowed(m.branch_id)
        AND (
          private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
          OR m.leader_user_id=auth.uid()
          OR m.leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid())
          OR member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid())
        )
    )
  );
CREATE POLICY ministry_members_write_leaders ON public.ministry_members
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.ministries m
      WHERE m.id=ministry_id AND m.tenant_id=private.current_tenant_id()
        AND private.branch_allowed(m.branch_id)
        AND (
          private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
          OR (
            private.has_cmms_role('MINISTRY_LEADER')
            AND (m.leader_user_id=auth.uid()
              OR m.leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
          )
        )
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.ministries m
      WHERE m.id=ministry_id AND m.tenant_id=private.current_tenant_id()
        AND private.branch_allowed(m.branch_id)
        AND (
          private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
          OR (
            private.has_cmms_role('MINISTRY_LEADER')
            AND (m.leader_user_id=auth.uid()
              OR m.leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
          )
        )
    )
  );

-- Attendance and events.
CREATE POLICY attendance_select_scoped ON public.attendance_records
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND (private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER','MINISTRY_LEADER'])
      OR member_id = (SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid())));
CREATE POLICY attendance_insert_scoped ON public.attendance_records
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND (private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER','MINISTRY_LEADER'])
      OR member_id = (SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid())));
CREATE POLICY attendance_update_staff ON public.attendance_records
  FOR UPDATE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER','MINISTRY_LEADER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER','MINISTRY_LEADER']));
CREATE POLICY attendance_delete_admin ON public.attendance_records
  FOR DELETE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));

CREATE POLICY events_select_scoped ON public.events
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id));
CREATE POLICY events_write_staff ON public.events
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER','MINISTRY_LEADER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER','MINISTRY_LEADER']));

-- Financial and pastoral data have intentionally narrower access.
CREATE POLICY finance_select_scoped ON public.financial_transactions
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND (private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER'])
      OR member_id = (SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid())));
CREATE POLICY finance_insert_staff ON public.financial_transactions
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']));
CREATE POLICY finance_update_staff ON public.financial_transactions
  FOR UPDATE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']));
-- Financial transactions cannot be deleted through the browser Data API.

CREATE POLICY pastoral_select_staff ON public.pastoral_records
  FOR SELECT TO authenticated
  USING (
    tenant_id = private.current_tenant_id()
    AND private.branch_allowed(branch_id)
    AND (
      counselor_user_id = auth.uid()
      OR (
        COALESCE(upper(confidentiality),'GENERAL') NOT IN ('CONFIDENTIAL','SEALED','MINISTERIAL')
        AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      )
      OR (
        COALESCE(upper(confidentiality),'GENERAL') IN ('CONFIDENTIAL','SEALED','MINISTERIAL')
        AND private.has_cmms_role('PASTOR')
      )
    )
  );
CREATE POLICY pastoral_insert_staff ON public.pastoral_records
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_cmms_role('PASTOR'));
CREATE POLICY pastoral_update_staff ON public.pastoral_records
  FOR UPDATE TO authenticated
  USING (
    tenant_id = private.current_tenant_id()
    AND private.branch_allowed(branch_id)
    AND (
      counselor_user_id = auth.uid()
      OR (
        COALESCE(upper(confidentiality),'GENERAL') NOT IN ('CONFIDENTIAL','SEALED','MINISTERIAL')
        AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      )
      OR (
        COALESCE(upper(confidentiality),'GENERAL') IN ('CONFIDENTIAL','SEALED','MINISTERIAL')
        AND private.has_cmms_role('PASTOR')
      )
    )
  )
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_cmms_role('PASTOR'));

CREATE POLICY workflows_select_scoped ON public.workflow_requests
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND (private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR lower(requester_email) = lower(COALESCE(auth.jwt()->>'email',''))));
CREATE POLICY workflows_insert_own ON public.workflow_requests
  FOR INSERT TO authenticated
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND (lower(requester_email) = lower(COALESCE(auth.jwt()->>'email',''))
      OR private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])));
CREATE POLICY workflows_update_approvers ON public.workflow_requests
  FOR UPDATE TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));

-- Operational modules.
CREATE POLICY volunteers_select_scoped ON public.volunteer_shifts
  FOR SELECT TO authenticated
  USING (
    tenant_id = private.current_tenant_id()
    AND (
      private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR volunteer_member_id = (SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid())
      OR EXISTS (
        SELECT 1 FROM public.ministries m
        WHERE m.id=ministry_id AND m.tenant_id=private.current_tenant_id()
          AND private.branch_allowed(m.branch_id)
          AND private.has_cmms_role('MINISTRY_LEADER')
          AND (m.leader_user_id=auth.uid()
            OR m.leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
      )
    )
  );
CREATE POLICY volunteers_write_leaders ON public.volunteer_shifts
  FOR ALL TO authenticated
  USING (
    tenant_id = private.current_tenant_id()
    AND (
      private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR EXISTS (
        SELECT 1 FROM public.ministries m
        WHERE m.id=ministry_id AND m.tenant_id=private.current_tenant_id()
          AND private.branch_allowed(m.branch_id)
          AND private.has_cmms_role('MINISTRY_LEADER')
          AND (m.leader_user_id=auth.uid()
            OR m.leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
      )
    )
  )
  WITH CHECK (
    tenant_id = private.current_tenant_id()
    AND (
      private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])
      OR EXISTS (
        SELECT 1 FROM public.ministries m
        WHERE m.id=ministry_id AND m.tenant_id=private.current_tenant_id()
          AND private.branch_allowed(m.branch_id)
          AND private.has_cmms_role('MINISTRY_LEADER')
          AND (m.leader_user_id=auth.uid()
            OR m.leader_member_id=(SELECT p.member_id FROM public.profiles p WHERE p.id=auth.uid()))
      )
    )
  );

CREATE POLICY assets_select_scoped ON public.assets
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER','MINISTRY_LEADER']));
CREATE POLICY assets_write_admin ON public.assets
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.branch_allowed(branch_id)
    AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']));

CREATE POLICY documents_select_scoped ON public.documents
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id()
    AND (NOT COALESCE(is_confidential,false) OR private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER'])));
CREATE POLICY documents_write_staff ON public.documents
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','MANAGER']));

CREATE POLICY courses_select_tenant ON public.lms_courses
  FOR SELECT TO authenticated USING (tenant_id = private.current_tenant_id());
CREATE POLICY courses_write_staff ON public.lms_courses
  FOR ALL TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']))
  WITH CHECK (tenant_id = private.current_tenant_id() AND private.has_any_cmms_role(ARRAY['SYSTEM_ADMIN','PASTOR','MANAGER']));

CREATE POLICY audit_select_admin ON public.audit_logs
  FOR SELECT TO authenticated
  USING (tenant_id = private.current_tenant_id() AND private.has_cmms_role('SYSTEM_ADMIN'));

-- The views must obey the caller's underlying table privileges and RLS.
ALTER VIEW public.view_member_demographics SET (security_invoker = true);
ALTER VIEW public.view_monthly_attendance_by_week SET (security_invoker = true);

COMMIT;
