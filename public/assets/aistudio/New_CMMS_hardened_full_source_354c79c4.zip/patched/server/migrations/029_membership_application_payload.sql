-- 029_membership_application_payload.sql
-- Adds the pending member snapshot to the existing deployed workflow_requests table.
-- Review and apply to staging before production. No existing rows are modified.
BEGIN;
ALTER TABLE public.workflow_requests
  ADD COLUMN IF NOT EXISTS pending_member_data jsonb NOT NULL DEFAULT '{}'::jsonb
  CHECK (jsonb_typeof(pending_member_data)='object');
CREATE INDEX IF NOT EXISTS workflow_membership_queue_idx
  ON public.workflow_requests(tenant_id,branch_id,created_at DESC)
  WHERE request_type='Membership Application';
COMMIT;
