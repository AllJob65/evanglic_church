-- ==============================================================================
-- CMMS MIGRATION 014: DOCUMENTS, REPOSITORIES & DOCUMENT CATEGORIES
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.document_categories (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, name)
);

CREATE TABLE IF NOT EXISTS public.documents (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    file_format TEXT NOT NULL DEFAULT 'PDF',
    file_size_mb NUMERIC(6, 2) NOT NULL DEFAULT 1.00,
    uploaded_by TEXT,
    upload_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    version TEXT NOT NULL DEFAULT 'v1.0',
    is_confidential BOOLEAN NOT NULL DEFAULT false,
    tags TEXT[] NOT NULL DEFAULT '{}',
    download_count INT NOT NULL DEFAULT 0,
    file_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_documents_tenant ON public.documents (tenant_id, category);
