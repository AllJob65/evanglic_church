-- ==============================================================================
-- CMMS MIGRATION 011: COMMUNICATIONS, BROADCASTS & NOTIFICATIONS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.communications (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    sender_role TEXT,
    channel TEXT NOT NULL DEFAULT 'SMS' CHECK (
        channel IN ('Email', 'SMS', 'Push Notification', 'WhatsApp', 'Telegram', 'Multi-Channel')
    ),
    trigger_type TEXT DEFAULT 'Manual Broadcast',
    target_audience TEXT NOT NULL,
    recipient_count INT NOT NULL DEFAULT 0,
    sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    status TEXT NOT NULL DEFAULT 'Sent' CHECK (
        status IN ('Sent', 'Scheduled', 'Draft', 'Failed')
    ),
    delivery_rate_percentage NUMERIC(5, 2),
    delivery_stats JSONB NOT NULL DEFAULT '{"sent": 0, "delivered": 0, "opened": 0, "failed": 0}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_communications_tenant_sent ON public.communications (tenant_id, sent_at DESC);
