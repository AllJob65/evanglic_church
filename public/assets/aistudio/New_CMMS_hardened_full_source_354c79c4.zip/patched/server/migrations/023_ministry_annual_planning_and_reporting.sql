-- ==============================================================================
-- CMMS MIGRATION 023: MINISTRY ANNUAL PLANNING & REPORTING WORKFLOW SYSTEM
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.ministry_annual_plans (
    id TEXT PRIMARY KEY DEFAULT 'mplan-' || gen_random_uuid()::text,
    plan_code TEXT NOT NULL UNIQUE,
    tenant_id TEXT NOT NULL DEFAULT 'tenant-grace-main',
    branch_id TEXT NOT NULL DEFAULT 'br-001',
    ministry_id TEXT NOT NULL,
    ministry_name TEXT NOT NULL,
    year INT NOT NULL,
    title TEXT NOT NULL,
    vision_statement TEXT,
    objectives JSONB NOT NULL DEFAULT '[]'::jsonb,
    activities JSONB NOT NULL DEFAULT '[]'::jsonb,
    responsible_person TEXT NOT NULL,
    responsible_person_id TEXT,
    target_audience TEXT NOT NULL,
    expected_participants INT NOT NULL DEFAULT 0,
    required_resources TEXT,
    optional_budget NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    currency TEXT NOT NULL DEFAULT 'ETB',
    kpis JSONB NOT NULL DEFAULT '[]'::jsonb,
    expected_outcomes JSONB NOT NULL DEFAULT '[]'::jsonb,
    risks JSONB NOT NULL DEFAULT '[]'::jsonb,
    mitigation_summary TEXT,
    quarterly_milestones JSONB NOT NULL DEFAULT '[]'::jsonb,
    monthly_activities JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'Draft' CHECK (
        status IN (
            'Draft',
            'Submitted',
            'Under Review',
            'Returned for Revision',
            'Approved',
            'Active',
            'Completed',
            'Rejected'
        )
    ),
    revision_number INT NOT NULL DEFAULT 1,
    submitted_by TEXT,
    submitted_by_name TEXT,
    submitted_at TIMESTAMPTZ,
    reviewed_by TEXT,
    reviewed_by_name TEXT,
    reviewed_at TIMESTAMPTZ,
    approved_by TEXT,
    approved_by_name TEXT,
    approved_at TIMESTAMPTZ,
    returned_reason TEXT,
    rejected_reason TEXT,
    review_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    quarterly_reports JSONB NOT NULL DEFAULT '[]'::jsonb,
    annual_report JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ministry_annual_plans_ministry_year
    ON public.ministry_annual_plans (ministry_id, year DESC);
CREATE INDEX IF NOT EXISTS idx_ministry_annual_plans_status
    ON public.ministry_annual_plans (status);
CREATE INDEX IF NOT EXISTS idx_ministry_annual_plans_branch
    ON public.ministry_annual_plans (branch_id);

CREATE TABLE IF NOT EXISTS public.ministry_plan_reviews (
    id TEXT PRIMARY KEY DEFAULT 'mprev-' || gen_random_uuid()::text,
    plan_id TEXT NOT NULL REFERENCES public.ministry_annual_plans(id) ON DELETE CASCADE,
    reviewer_id TEXT NOT NULL,
    reviewer_name TEXT NOT NULL,
    reviewer_role TEXT NOT NULL,
    action TEXT NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ministry_plan_reviews_plan
    ON public.ministry_plan_reviews (plan_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.ministry_quarterly_reports (
    id TEXT PRIMARY KEY DEFAULT 'mqrep-' || gen_random_uuid()::text,
    plan_id TEXT NOT NULL REFERENCES public.ministry_annual_plans(id) ON DELETE CASCADE,
    ministry_id TEXT NOT NULL,
    ministry_name TEXT NOT NULL,
    branch_id TEXT NOT NULL DEFAULT 'br-001',
    year INT NOT NULL,
    quarter TEXT NOT NULL CHECK (quarter IN ('Q1', 'Q2', 'Q3', 'Q4')),
    planned_activity TEXT NOT NULL,
    actual_activity TEXT NOT NULL,
    planned_participants INT NOT NULL DEFAULT 0,
    actual_participants INT NOT NULL DEFAULT 0,
    results TEXT NOT NULL,
    kpi_performance JSONB NOT NULL DEFAULT '[]'::jsonb,
    overall_kpi_score NUMERIC(6, 2) NOT NULL DEFAULT 0.00,
    challenges TEXT,
    allocated_budget NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    actual_expense NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    budget_variance NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    budget_expense_notes TEXT,
    lessons_learned TEXT,
    next_quarter_action TEXT,
    status TEXT NOT NULL DEFAULT 'Submitted' CHECK (
        status IN ('Draft', 'Submitted', 'Reviewed', 'Approved', 'Returned')
    ),
    submitted_by TEXT NOT NULL,
    submitted_by_name TEXT NOT NULL,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    reviewed_by_name TEXT,
    reviewed_at TIMESTAMPTZ,
    pastor_feedback TEXT,
    UNIQUE (plan_id, quarter)
);

CREATE INDEX IF NOT EXISTS idx_ministry_quarterly_reports_plan
    ON public.ministry_quarterly_reports (plan_id, quarter);

CREATE TABLE IF NOT EXISTS public.ministry_annual_reports (
    id TEXT PRIMARY KEY DEFAULT 'marep-' || gen_random_uuid()::text,
    plan_id TEXT NOT NULL UNIQUE REFERENCES public.ministry_annual_plans(id) ON DELETE CASCADE,
    ministry_id TEXT NOT NULL,
    ministry_name TEXT NOT NULL,
    branch_id TEXT NOT NULL DEFAULT 'br-001',
    year INT NOT NULL,
    executive_summary TEXT NOT NULL,
    quarters_included TEXT[] NOT NULL DEFAULT '{}',
    total_planned_activities INT NOT NULL DEFAULT 0,
    total_actual_activities_completed INT NOT NULL DEFAULT 0,
    total_expected_participants INT NOT NULL DEFAULT 0,
    total_actual_participants INT NOT NULL DEFAULT 0,
    participant_achievement_rate NUMERIC(6, 2) NOT NULL DEFAULT 0.00,
    total_allocated_budget NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    total_actual_expense NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    total_budget_variance NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    budget_utilization_rate NUMERIC(6, 2) NOT NULL DEFAULT 0.00,
    overall_kpi_achievement_rate NUMERIC(6, 2) NOT NULL DEFAULT 0.00,
    aggregated_kpi_results JSONB NOT NULL DEFAULT '[]'::jsonb,
    quarterly_breakdown JSONB NOT NULL DEFAULT '[]'::jsonb,
    key_achievements TEXT,
    major_challenges TEXT,
    lessons_learned TEXT,
    strategic_recommendations_next_year TEXT,
    status TEXT NOT NULL DEFAULT 'Submitted' CHECK (
        status IN ('Draft', 'Submitted', 'Approved')
    ),
    submitted_by TEXT NOT NULL,
    submitted_by_name TEXT NOT NULL,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    approved_by_name TEXT,
    approved_at TIMESTAMPTZ,
    pastor_comments TEXT
);
