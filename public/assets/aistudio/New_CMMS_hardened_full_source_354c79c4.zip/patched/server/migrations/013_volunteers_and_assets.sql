-- ==============================================================================
-- CMMS MIGRATION 013: VOLUNTEER SHIFTS & CHURCH ASSETS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.volunteer_shifts (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    volunteer_id TEXT,
    volunteer_member_id TEXT,
    volunteer_name TEXT NOT NULL,
    ministry_id TEXT,
    ministry_name TEXT,
    role_title TEXT NOT NULL,
    shift_date DATE NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    status TEXT DEFAULT 'Scheduled' CHECK (
        status IN ('Scheduled', 'Confirmed', 'Completed', 'Swapped / Substitute')
    ),
    hours_logged NUMERIC(5, 2) NOT NULL DEFAULT 4.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_volunteer_shifts_tenant ON public.volunteer_shifts (tenant_id, shift_date);
CREATE INDEX IF NOT EXISTS idx_volunteer_shifts_member ON public.volunteer_shifts (tenant_id, volunteer_member_id);

CREATE TABLE IF NOT EXISTS public.assets (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    asset_code TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    custodian_member_name TEXT,
    custodian_name TEXT,
    purchase_date DATE,
    purchase_price NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    current_value NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    condition TEXT DEFAULT 'Good' CHECK (
        condition IN ('Excellent', 'Good', 'Fair', 'Needs Repair', 'Disposed')
    ),
    next_maintenance_date DATE,
    next_maintenance DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, asset_code)
);

CREATE INDEX IF NOT EXISTS idx_assets_tenant ON public.assets (tenant_id, branch_id);
