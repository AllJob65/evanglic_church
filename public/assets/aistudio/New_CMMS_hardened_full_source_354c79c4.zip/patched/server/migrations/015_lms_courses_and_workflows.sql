-- ==============================================================================
-- CMMS MIGRATION 015: LMS COURSES & WORKFLOW APPROVAL ENGINE
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.lms_courses (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    course_code TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT DEFAULT 'Discipleship & Foundations',
    instructor_name TEXT,
    description TEXT,
    total_modules INT NOT NULL DEFAULT 8,
    duration_weeks INT NOT NULL DEFAULT 6,
    enrolled_students_count INT NOT NULL DEFAULT 0,
    enrolled_count INT NOT NULL DEFAULT 0,
    pass_percentage NUMERIC(5, 2) NOT NULL DEFAULT 80.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, course_code)
);

CREATE INDEX IF NOT EXISTS idx_lms_courses_tenant ON public.lms_courses (tenant_id);

CREATE TABLE IF NOT EXISTS public.workflow_requests (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    branch_name TEXT,
    requester_id TEXT,
    request_code TEXT NOT NULL,
    request_type TEXT NOT NULL CHECK (
        request_type IN ('Membership Application', 'Branch Transfer', 'Leave Request', 'Event Authorization', 'Budget Request', 'Purchase Approval')
    ),
    requester_name TEXT NOT NULL,
    requester_phone TEXT,
    requester_email TEXT,
    details TEXT NOT NULL,
    amount_requested NUMERIC(12, 2),
    current_step TEXT DEFAULT 'Submitted for Review',
    assigned_approver_role TEXT NOT NULL DEFAULT 'BRANCH_PASTOR',
    assigned_role TEXT,
    submitted_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (
        status IN ('Pending', 'Approved', 'Rejected', 'Escalated')
    ),
    comments TEXT,
    pending_member_id TEXT,
    pending_member_data JSONB,
    approved_by TEXT,
    approved_at TIMESTAMPTZ,
    rejected_reason TEXT,
    decision_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, request_code)
);

CREATE INDEX IF NOT EXISTS idx_workflows_tenant_status ON public.workflow_requests (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_workflows_requester ON public.workflow_requests (tenant_id, requester_id);
