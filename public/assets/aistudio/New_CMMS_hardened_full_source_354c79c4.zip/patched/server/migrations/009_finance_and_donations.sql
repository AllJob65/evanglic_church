-- ==============================================================================
-- CMMS MIGRATION 009: FINANCIAL TRANSACTIONS, DONATIONS & LEDGER
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.financial_transactions (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE RESTRICT,
    receipt_number TEXT NOT NULL,
    reference_number TEXT,
    member_id TEXT,
    member_name TEXT NOT NULL,
    contribution_type TEXT NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'ETB' CHECK (currency IN ('USD', 'ETB', 'EUR', 'GBP')),
    payment_method TEXT NOT NULL,
    payment_reference TEXT,
    transaction_type TEXT NOT NULL DEFAULT 'INCOME',
    date TIMESTAMPTZ NOT NULL DEFAULT now(),
    transaction_date TIMESTAMPTZ,
    fund_category TEXT,
    service_associated TEXT,
    tax_deductible BOOLEAN NOT NULL DEFAULT false,
    status TEXT NOT NULL DEFAULT 'Completed' CHECK (status IN ('Completed', 'Pending', 'Refunded')),
    notes TEXT,
    recorded_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, receipt_number)
);

CREATE INDEX IF NOT EXISTS idx_financial_tx_tenant_date ON public.financial_transactions (tenant_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_financial_tx_branch ON public.financial_transactions (tenant_id, branch_id);
CREATE INDEX IF NOT EXISTS idx_financial_tx_member ON public.financial_transactions (tenant_id, member_id);

CREATE TABLE IF NOT EXISTS public.donations (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    member_id TEXT,
    donor_name TEXT,
    donor_email TEXT,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'ETB',
    category TEXT NOT NULL DEFAULT 'Tithe',
    payment_method TEXT NOT NULL DEFAULT 'Telebirr',
    gateway_reference TEXT,
    status TEXT NOT NULL DEFAULT 'Completed',
    is_anonymous BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_donations_tenant_created ON public.donations (tenant_id, created_at DESC);
