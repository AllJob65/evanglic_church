-- ==============================================================================
-- CMMS MIGRATION 016: REALTIME CHAT, VIDEO CONFERENCES & AD-HOC CONVERSATIONS
-- Reconciled with audio notes, waveforms, media attachments & participant tracking
-- ==============================================================================

-- Ministry / Group Live Chat Sessions
CREATE TABLE IF NOT EXISTS public.group_chats (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    group_id TEXT,
    ministry_id TEXT,
    leader_id TEXT,
    leader_profile_id TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ministry Group Chat Messages
CREATE TABLE IF NOT EXISTS public.ministry_chat_messages (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    ministry_id TEXT NOT NULL,
    ministry_name TEXT,
    sender_id TEXT NOT NULL,
    sender_name TEXT NOT NULL,
    sender_email TEXT,
    sender_role TEXT,
    sender_avatar TEXT,
    text TEXT NOT NULL,
    scripture_ref TEXT,
    attachment_url TEXT,
    attachment_name TEXT,
    audio_url TEXT,
    duration_seconds NUMERIC(6, 2),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
    reactions JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_ministry_chat_messages ON public.ministry_chat_messages (ministry_id, timestamp DESC);

-- Video Conferences / Rooms
CREATE TABLE IF NOT EXISTS public.video_conferences (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    group_id TEXT,
    ministry_id TEXT,
    leader_id TEXT,
    leader_profile_id TEXT,
    title TEXT NOT NULL DEFAULT 'Group Live Session',
    room_url TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
    participants JSONB NOT NULL DEFAULT '[]'::jsonb,
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ad-hoc and Direct Conversations (Phase 20, 21, 22)
CREATE TABLE IF NOT EXISTS public.conversations (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    type TEXT NOT NULL CHECK (type IN ('direct', 'ad_hoc_group', 'video')),
    title TEXT,
    created_by TEXT NOT NULL,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
    room_url TEXT,
    active_video_call JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at TIMESTAMPTZ,
    CONSTRAINT chk_conversation_title CHECK (
        (type = 'direct') OR (title IS NOT NULL AND length(trim(title)) > 0)
    )
);

CREATE INDEX IF NOT EXISTS idx_conversations_tenant_status ON public.conversations (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_conversations_created_by ON public.conversations (created_by);

-- Conversation Participants
CREATE TABLE IF NOT EXISTS public.conversation_participants (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    conversation_id TEXT NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    added_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    left_at TIMESTAMPTZ,
    user_name TEXT,
    user_email TEXT,
    user_role TEXT,
    UNIQUE (conversation_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_conversation_participants_user_active ON public.conversation_participants (user_id, conversation_id) WHERE left_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_conversation_participants_lookup ON public.conversation_participants (conversation_id, user_id);

-- Conversation Messages (Including audio notes, waveforms & media attachments)
CREATE TABLE IF NOT EXISTS public.conversation_messages (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    conversation_id TEXT NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL,
    sender_name TEXT,
    sender_role TEXT,
    body TEXT NOT NULL,
    audio_url TEXT,
    duration_seconds NUMERIC(6, 2),
    waveform JSONB,
    media_type TEXT,
    attachment_url TEXT,
    attachment_name TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_conversation_messages_created ON public.conversation_messages (conversation_id, created_at DESC);
