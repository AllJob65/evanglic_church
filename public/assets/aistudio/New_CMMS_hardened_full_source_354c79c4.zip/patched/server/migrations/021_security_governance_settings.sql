-- ==============================================================================
-- CMMS MIGRATION 021: SECURITY GOVERNANCE SETTINGS (2FA, LOCKOUT, JWT LIFESPAN)
-- ==============================================================================

ALTER TABLE public.church_settings
ADD COLUMN IF NOT EXISTS jwt_lifespan_hours INT NOT NULL DEFAULT 8,
ADD COLUMN IF NOT EXISTS lockout_max_attempts INT NOT NULL DEFAULT 5,
ADD COLUMN IF NOT EXISTS lockout_duration_minutes INT NOT NULL DEFAULT 15,
ADD COLUMN IF NOT EXISTS mfa_enforcement_mode TEXT NOT NULL DEFAULT 'enforced';

COMMENT ON COLUMN public.church_settings.jwt_lifespan_hours IS 'JWT token validity duration in hours before re-authentication';
COMMENT ON COLUMN public.church_settings.lockout_max_attempts IS 'Maximum failed login attempts before temporary account lockout';
COMMENT ON COLUMN public.church_settings.lockout_duration_minutes IS 'Duration in minutes for account lockout';
COMMENT ON COLUMN public.church_settings.mfa_enforcement_mode IS 'Enforcement policy for two-factor authentication (enforced or optional)';
