-- ==============================================================================
-- CMMS MIGRATION 020: REAL SECURITY AUDIT LOGS (IP, USER AGENT, DEVICE FINGERPRINT)
-- ==============================================================================

ALTER TABLE public.audit_logs
  ADD COLUMN IF NOT EXISTS user_agent TEXT,
  ADD COLUMN IF NOT EXISTS device_fingerprint TEXT,
  ADD COLUMN IF NOT EXISTS session_id TEXT;

CREATE INDEX IF NOT EXISTS idx_audit_logs_ip ON public.audit_logs (ip_address);
CREATE INDEX IF NOT EXISTS idx_audit_logs_fingerprint ON public.audit_logs (device_fingerprint);
