-- ==============================================================================
-- CMMS MIGRATION 004: SYSTEM USERS, PROFILES, RBAC OVERRIDES & PASSWORD RESETS
-- ==============================================================================

-- Consolidated profiles / system_users table
CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES public.branches(id) ON DELETE SET NULL,
    branch_name TEXT,
    branch_ids TEXT[] NOT NULL DEFAULT '{}',
    assigned_campuses TEXT[] NOT NULL DEFAULT '{}',
    role TEXT NOT NULL DEFAULT 'REGULAR_MEMBER' CHECK (
        role IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER')
    ),
    status TEXT NOT NULL DEFAULT 'Active' CHECK (
        status IN ('Active', 'Pending', 'Suspended', 'Inactive')
    ),
    display_name TEXT,
    name TEXT NOT NULL,
    full_name TEXT,
    email TEXT NOT NULL,
    phone TEXT,
    photo_url TEXT,
    avatar TEXT,
    password_hash TEXT,
    must_change_password BOOLEAN NOT NULL DEFAULT false,
    mfa_enabled BOOLEAN NOT NULL DEFAULT false,
    is_mfa_enabled BOOLEAN NOT NULL DEFAULT false,
    totp_secret TEXT,
    mfa_secret TEXT,
    last_login TIMESTAMPTZ,
    last_max_auth_at TIMESTAMPTZ,
    approval_limit NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    approval_role_level TEXT,
    allowed_approval_types TEXT[] NOT NULL DEFAULT '{}',
    notes TEXT,
    member_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_profiles_tenant_role ON public.profiles (tenant_id, role);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles (email);
CREATE INDEX IF NOT EXISTS idx_profiles_member_id ON public.profiles (member_id);

-- Explicit alias view or table for system_users compatibility
CREATE OR REPLACE VIEW public.system_users AS
SELECT
    id,
    tenant_id,
    name,
    email,
    phone,
    photo_url,
    avatar,
    role,
    branch_name,
    branch_ids,
    assigned_campuses,
    status,
    last_login,
    is_mfa_enabled,
    mfa_enabled,
    approval_limit,
    approval_role_level,
    allowed_approval_types,
    notes,
    must_change_password,
    last_max_auth_at,
    totp_secret,
    mfa_secret,
    created_at,
    updated_at
FROM public.profiles;

-- Password Resets table
CREATE TABLE IF NOT EXISTS public.password_resets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    email TEXT NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    ip_address TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_password_resets_lookup ON public.password_resets (token_hash, used_at, expires_at);

-- Role Permission Overrides
CREATE TABLE IF NOT EXISTS public.role_permission_overrides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (
        role IN ('SYSTEM_ADMIN', 'MANAGER', 'PASTOR', 'MINISTRY_LEADER', 'REGULAR_MEMBER')
    ),
    permissions JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_by TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, role)
);

-- Permission Change Audit Log
CREATE TABLE IF NOT EXISTS public.permission_change_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    old_permissions JSONB,
    new_permissions JSONB NOT NULL,
    reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_perm_change_log ON public.permission_change_log (tenant_id, created_at DESC);
