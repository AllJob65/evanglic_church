-- ==============================================================================
-- CMMS MIGRATION 017: DAILY DEVOTIONS & BIBLE ENGAGEMENT PLATFORM
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.devotions (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    amharic_title TEXT,
    topic TEXT NOT NULL,
    scripture_reference TEXT NOT NULL,
    bible_version_id INT,
    key_verse TEXT,
    body TEXT NOT NULL,
    prayer TEXT,
    author_id TEXT,
    author_name TEXT NOT NULL,
    audio_url TEXT,
    status TEXT NOT NULL DEFAULT 'draft' CHECK (
        status IN ('draft', 'published', 'scheduled', 'archived')
    ),
    scheduled_for TIMESTAMPTZ,
    published_at TIMESTAMPTZ,
    reactions_count JSONB NOT NULL DEFAULT '{"heart": 0, "amen": 0, "praying": 0, "inspiring": 0}'::jsonb,
    comments_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_devotions_status_pub ON public.devotions (status, published_at DESC);

CREATE TABLE IF NOT EXISTS public.devotion_reactions (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    devotion_id TEXT NOT NULL REFERENCES public.devotions(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    reaction_type TEXT NOT NULL CHECK (
        reaction_type IN ('heart', 'amen', 'praying', 'inspiring')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (devotion_id, user_id, reaction_type)
);

CREATE TABLE IF NOT EXISTS public.devotion_comments (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    devotion_id TEXT NOT NULL REFERENCES public.devotions(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    userName TEXT,
    user_name TEXT,
    user_photo_url TEXT,
    comment_text TEXT NOT NULL,
    is_moderated BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_devotion_comments ON public.devotion_comments (devotion_id, created_at DESC);

-- Bible Personal Notes
CREATE TABLE IF NOT EXISTS public.bible_notes (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    book_id TEXT NOT NULL,
    chapter INT NOT NULL,
    verse INT,
    passage_title TEXT,
    note_text TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_notes_user ON public.bible_notes (user_id, book_id, chapter);

-- Bible Color Highlights
CREATE TABLE IF NOT EXISTS public.bible_highlights (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    book_id TEXT NOT NULL,
    chapter INT NOT NULL,
    verse INT NOT NULL,
    color TEXT NOT NULL CHECK (color IN ('yellow', 'green', 'blue', 'rose', 'purple')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_highlights_user ON public.bible_highlights (user_id, book_id, chapter);

-- Bible Bookmarks
CREATE TABLE IF NOT EXISTS public.bible_bookmarks (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    book_id TEXT NOT NULL,
    book_name_amharic TEXT,
    book_name_english TEXT,
    chapter INT NOT NULL,
    verse INT NOT NULL,
    verse_text TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_bookmarks_user ON public.bible_bookmarks (user_id);

-- Bible Reading History
CREATE TABLE IF NOT EXISTS public.bible_reading_history (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    book_id TEXT NOT NULL,
    book_name TEXT NOT NULL,
    chapter INT NOT NULL,
    read_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_reading_history ON public.bible_reading_history (user_id, read_at DESC);

-- Bible Reading Plans Progress
CREATE TABLE IF NOT EXISTS public.bible_reading_plans (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    plan_id TEXT NOT NULL,
    completed_days INT[] NOT NULL DEFAULT '{}',
    streak_count INT NOT NULL DEFAULT 0,
    last_completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, plan_id)
);

-- Bible Reader Display Settings
CREATE TABLE IF NOT EXISTS public.bible_settings (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL UNIQUE,
    preferred_version_id TEXT NOT NULL DEFAULT '111',
    preferred_version_name TEXT DEFAULT 'New International Version (NIV)',
    preferred_version_abbreviation TEXT DEFAULT 'NIV',
    preferred_language TEXT DEFAULT 'English',
    font_size TEXT DEFAULT 'medium',
    font_family TEXT DEFAULT 'serif',
    line_spacing TEXT DEFAULT 'comfortable',
    reading_width TEXT DEFAULT 'normal',
    theme TEXT DEFAULT 'light',
    show_verse_numbers BOOLEAN NOT NULL DEFAULT true,
    show_footnotes BOOLEAN NOT NULL DEFAULT true,
    show_cross_references BOOLEAN NOT NULL DEFAULT true,
    show_red_letters BOOLEAN NOT NULL DEFAULT true,
    remember_reading_position BOOLEAN NOT NULL DEFAULT true,
    track_reading_history BOOLEAN NOT NULL DEFAULT true,
    last_reading_position JSONB DEFAULT '{"bookId":"JHN","bookEnglish":"John","bookAmharic":"የዮሐንስ ወንጌል","chapter":3,"verse":16}'::jsonb,
    enable_notes BOOLEAN NOT NULL DEFAULT true,
    enable_highlights BOOLEAN NOT NULL DEFAULT true,
    enable_bookmarks BOOLEAN NOT NULL DEFAULT true,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Pastor / Leader Bible Broadcast Messages
CREATE TABLE IF NOT EXISTS public.bible_messages (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL,
    sender_name TEXT NOT NULL,
    sender_role TEXT NOT NULL,
    translation_id TEXT NOT NULL,
    translation_name TEXT NOT NULL,
    translation_abbreviation TEXT,
    book_id TEXT NOT NULL,
    book_name TEXT NOT NULL,
    chapter INT NOT NULL,
    verse_start INT NOT NULL,
    verse_end INT,
    reference TEXT NOT NULL,
    passage_text TEXT NOT NULL,
    note TEXT,
    recipient_type TEXT NOT NULL,
    recipient_target_ids TEXT[] DEFAULT '{}',
    recipient_target_names TEXT[] DEFAULT '{}',
    recipient_count INT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft',
    scheduled_at TIMESTAMPTZ,
    sent_at TIMESTAMPTZ,
    timezone TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_messages_sent ON public.bible_messages (sent_at DESC);

-- Bible Message Recipients Tracking
CREATE TABLE IF NOT EXISTS public.bible_message_recipients (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    message_id TEXT NOT NULL REFERENCES public.bible_messages(id) ON DELETE CASCADE,
    member_id TEXT NOT NULL,
    member_name TEXT,
    member_email TEXT,
    is_read BOOLEAN NOT NULL DEFAULT false,
    read_at TIMESTAMPTZ,
    delivered_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_recipients ON public.bible_message_recipients (message_id, member_id);

-- Bible Push Notifications
CREATE TABLE IF NOT EXISTS public.bible_notifications (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    message_id TEXT,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    reference TEXT,
    note TEXT,
    sender_name TEXT,
    sender_role TEXT,
    is_read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bible_notifications_user ON public.bible_notifications (user_id, is_read);
