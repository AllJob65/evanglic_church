import type { PoolClient } from 'pg';
import { withTransaction } from '../pg';
import { isDatabaseUuid } from './memberRepository';

/**
 * PostgreSQL-only attendance check-in primitive.
 *
 * This module is deliberately not wired into the HTTP route yet. The route still
 * has legacy response and QR-token contracts that must be migrated together.
 * All scope values must come from the verified server authentication context.
 */
export interface AttendanceScope {
  tenantId: string;
  /** Explicit branch selected by the actor, constrained by branchIds. */
  branchId: string;
  /** ['*'] is reserved for actors whose verified context grants all branches. */
  branchIds: readonly string[];
}

export interface SessionCheckInInput {
  sessionCode: string;
  memberId: string;
  checkInMethod: 'Manual Web Click' | 'QR Code Scanning';
  checkedInAt: Date;
  memberName?: string;
  notes?: string;
}

export interface SessionCheckInResult {
  alreadyCheckedIn: boolean;
  record: {
    id: string;
    tenantId: string;
    branchId: string;
    sessionId: string;
    sessionCode: string;
    memberId: string;
    memberName: string;
    eventName: string;
    serviceType: string;
    checkInMethod: string;
    checkInTime: string;
    status: string;
  };
  attendeeCount: number;
}

interface SessionRow {
  id: string;
  tenant_id: string;
  branch_id: string;
  session_code: string;
  title: string;
  service_type: string;
  status: string;
  attendee_count: number;
}

interface MemberRow {
  id: string;
  first_name: string | null;
  last_name: string | null;
}

function assertScope(scope: AttendanceScope): void {
  if (!isDatabaseUuid(scope.tenantId) || !isDatabaseUuid(scope.branchId)) {
    throw new Error('Attendance scope must contain valid tenant and branch UUIDs.');
  }
  if (!scope.branchIds.includes('*') && !scope.branchIds.includes(scope.branchId)) {
    throw new Error('Attendance branch is outside the authenticated user scope.');
  }
}

export async function createSessionCheckIn(
  scope: AttendanceScope,
  input: SessionCheckInInput,
): Promise<SessionCheckInResult> {
  assertScope(scope);
  if (!input.sessionCode.trim()) throw new Error('Session code is required.');
  if (!isDatabaseUuid(input.memberId)) throw new Error('A valid member UUID is required.');
  if (!(input.checkedInAt instanceof Date) || Number.isNaN(input.checkedInAt.getTime())) {
    throw new Error('A valid check-in timestamp is required.');
  }

  return withTransaction(async (client: PoolClient) => {
    // Lock the session row to serialize check-ins against other check-ins,
    // session closure and QR rotation performed through the same repository.
    const sessionResult = await client.query<SessionRow>(
      `SELECT id, tenant_id, branch_id, session_code, title, service_type,
              status, attendee_count
         FROM public.attendance_sessions
        WHERE tenant_id = $1 AND branch_id = $2 AND session_code = $3
        FOR UPDATE`,
      [scope.tenantId, scope.branchId, input.sessionCode],
    );
    const session = sessionResult.rows[0];
    if (!session) throw new Error('Attendance session not found.');
    if (session.status !== 'active') throw new Error('Attendance session is closed.');

    const memberResult = await client.query<MemberRow>(
      `SELECT id, first_name, last_name
         FROM public.members
        WHERE id = $1 AND tenant_id = $2 AND branch_id = $3
        LIMIT 1`,
      [input.memberId, scope.tenantId, scope.branchId],
    );
    const member = memberResult.rows[0];
    if (!member) throw new Error('Member does not exist in the selected tenant and branch.');

    const existingResult = await client.query(
      `SELECT id, tenant_id, branch_id, session_id, member_id, member_name,
              event_name, service_type, checkin_method, checkin_time, status
         FROM public.attendance_records
        WHERE tenant_id = $1 AND branch_id = $2
          AND session_id = $3 AND member_id = $4
        ORDER BY checkin_time ASC
        LIMIT 1`,
      [scope.tenantId, scope.branchId, session.id, member.id],
    );

    if (existingResult.rows[0]) {
      const existing = existingResult.rows[0];
      return {
        alreadyCheckedIn: true,
        record: {
          id: existing.id,
          tenantId: existing.tenant_id,
          branchId: existing.branch_id,
          sessionId: existing.session_id,
          sessionCode: session.session_code,
          memberId: existing.member_id,
          memberName: existing.member_name ?? '',
          eventName: existing.event_name,
          serviceType: existing.service_type,
          checkInMethod: existing.checkin_method ?? '',
          checkInTime: new Date(existing.checkin_time).toISOString(),
          status: existing.status,
        },
        attendeeCount: Number(session.attendee_count),
      };
    }

    const resolvedName = [member.first_name, member.last_name].filter(Boolean).join(' ').trim()
      || input.memberName?.trim()
      || 'Member';

    const inserted = await client.query(
      `INSERT INTO public.attendance_records
         (tenant_id, branch_id, event_name, service_type, member_id,
          checkin_method, checkin_time, session_id, member_name, status, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'Present', $10)
       RETURNING id, tenant_id, branch_id, session_id, member_id, member_name,
                 event_name, service_type, checkin_method, checkin_time, status`,
      [
        scope.tenantId,
        scope.branchId,
        session.title,
        session.service_type,
        member.id,
        input.checkInMethod,
        input.checkedInAt.toISOString(),
        session.id,
        resolvedName,
        input.notes ?? null,
      ],
    );

    const countResult = await client.query<{ attendee_count: number }>(
      `UPDATE public.attendance_sessions
          SET attendee_count = attendee_count + 1
        WHERE id = $1 AND tenant_id = $2 AND branch_id = $3
        RETURNING attendee_count`,
      [session.id, scope.tenantId, scope.branchId],
    );
    if (!countResult.rows[0]) throw new Error('Session count update failed.');

    const row = inserted.rows[0];
    return {
      alreadyCheckedIn: false,
      record: {
        id: row.id,
        tenantId: row.tenant_id,
        branchId: row.branch_id,
        sessionId: row.session_id,
        sessionCode: session.session_code,
        memberId: row.member_id,
        memberName: row.member_name,
        eventName: row.event_name,
        serviceType: row.service_type,
        checkInMethod: row.checkin_method,
        checkInTime: new Date(row.checkin_time).toISOString(),
        status: row.status,
      },
      attendeeCount: Number(countResult.rows[0].attendee_count),
    };
  });
}
