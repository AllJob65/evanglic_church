import { randomBytes, randomUUID } from 'node:crypto';
import type { PoolClient } from 'pg';
import { query, withTransaction } from '../pg';
import { isDatabaseUuid } from './memberRepository';

export interface AttendanceSessionScope {
  tenantId: string;
  branchId?: string;
  branchIds: readonly string[];
}

export interface CreateAttendanceSessionInput {
  branchId: string;
  leaderUserId?: string | null;
  leaderName?: string | null;
  groupId?: string | null;
  groupName?: string | null;
  sessionType?: string;
  title: string;
  serviceType?: string;
  location?: string | null;
  sessionData?: Record<string, unknown>;
}

export interface AttendanceSessionRecord {
  id: string;
  tenantId: string;
  branchId: string;
  sessionCode: string;
  groupId: string | null;
  groupName: string | null;
  leaderUserId: string | null;
  leaderName: string | null;
  sessionType: string;
  title: string;
  serviceType: string;
  status: 'active' | 'closed';
  startTime: string;
  endTime: string | null;
  qrPayloadToken: string;
  location: string | null;
  attendeeCount: number;
  sessionData: Record<string, unknown>;
}

interface SessionDbRow {
  id: string;
  tenant_id: string;
  branch_id: string;
  session_code: string;
  group_id: string | null;
  group_name: string | null;
  leader_user_id: string | null;
  leader_name: string | null;
  session_type: string;
  title: string;
  service_type: string;
  status: 'active' | 'closed';
  start_time: Date | string;
  end_time: Date | string | null;
  qr_payload_token: string;
  location: string | null;
  attendee_count: number;
  session_data: Record<string, unknown> | null;
}

const columns = `id, tenant_id, branch_id, session_code, group_id, group_name,
  leader_user_id, leader_name, session_type, title, service_type, status,
  start_time, end_time, qr_payload_token, location, attendee_count, session_data`;

function assertScope(scope: AttendanceSessionScope): void {
  if (!isDatabaseUuid(scope.tenantId)) throw new Error('A valid tenant UUID is required.');
  if (scope.branchId && !isDatabaseUuid(scope.branchId)) throw new Error('A valid branch UUID is required.');
  if (!scope.branchIds.includes('*') && scope.branchIds.length === 0) {
    throw new Error('Authenticated user has no authorized attendance branches.');
  }
}

function assertBranch(scope: AttendanceSessionScope, branchId: string): void {
  if (!isDatabaseUuid(branchId)) throw new Error('A valid branch UUID is required.');
  if (!scope.branchIds.includes('*') && !scope.branchIds.includes(branchId)) {
    throw new Error('Attendance branch is outside the authenticated user scope.');
  }
}

function mapSession(row: SessionDbRow): AttendanceSessionRecord {
  return {
    id: row.id,
    tenantId: row.tenant_id,
    branchId: row.branch_id,
    sessionCode: row.session_code,
    groupId: row.group_id,
    groupName: row.group_name,
    leaderUserId: row.leader_user_id,
    leaderName: row.leader_name,
    sessionType: row.session_type,
    title: row.title,
    serviceType: row.service_type,
    status: row.status,
    startTime: new Date(row.start_time).toISOString(),
    endTime: row.end_time ? new Date(row.end_time).toISOString() : null,
    qrPayloadToken: row.qr_payload_token,
    location: row.location,
    attendeeCount: Number(row.attendee_count),
    sessionData: row.session_data ?? {},
  };
}

function makeSessionCode(): string {
  return `att_${randomBytes(9).toString('hex')}`;
}

function makeQrToken(): string {
  return randomUUID() + randomUUID().replace(/-/g, '');
}

export async function createAttendanceSession(
  scope: AttendanceSessionScope,
  input: CreateAttendanceSessionInput,
): Promise<AttendanceSessionRecord> {
  if (!isDatabaseUuid(scope.tenantId)) throw new Error('A valid tenant UUID is required.');
  assertBranch(scope, input.branchId);
  if (!input.title?.trim()) throw new Error('Session title is required.');
  if (input.leaderUserId && !isDatabaseUuid(input.leaderUserId)) {
    throw new Error('A valid leader user UUID is required.');
  }
  if (input.groupId && !isDatabaseUuid(input.groupId)) throw new Error('A valid group UUID is required.');

  // Verify the selected branch belongs to this tenant before inserting. The
  // branch authorization check above is necessary but is not a tenant check.
  const branch = await query<{ id: string }>(
    'SELECT id FROM public.branches WHERE id = $1::uuid AND tenant_id = $2::uuid',
    [input.branchId, scope.tenantId],
  );
  if (!branch.rowCount) throw new Error('Selected branch does not belong to this tenant.');

  if (input.leaderUserId) {
    const leader = await query<{ id: string }>(
      'SELECT id FROM public.profiles WHERE id = $1::uuid AND tenant_id = $2::uuid',
      [input.leaderUserId, scope.tenantId],
    );
    if (!leader.rowCount) throw new Error('Selected session leader does not belong to this tenant.');
  }

  const result = await query<SessionDbRow>(
    `INSERT INTO public.attendance_sessions
      (tenant_id, branch_id, session_code, group_id, group_name, leader_user_id,
       leader_name, session_type, title, service_type, status, qr_payload_token,
       location, session_data)
     VALUES ($1::uuid, $2::uuid, $3, $4::uuid, $5, $6::uuid, $7, $8, $9, $10,
             'active', $11, $12, $13::jsonb)
     RETURNING ${columns}`,
    [
      scope.tenantId, input.branchId, makeSessionCode(), input.groupId ?? null,
      input.groupName ?? null, input.leaderUserId ?? null, input.leaderName ?? null,
      input.sessionType ?? 'instant', input.title.trim(),
      input.serviceType ?? 'Ministry Attendance', makeQrToken(),
      input.location ?? null, JSON.stringify(input.sessionData ?? {}),
    ],
  );
  return mapSession(result.rows[0]);
}

export async function listAttendanceSessions(
  scope: AttendanceSessionScope,
  filters: { status?: 'active' | 'closed'; groupId?: string; branchId?: string } = {},
): Promise<AttendanceSessionRecord[]> {
  assertScope(scope);
  const values: unknown[] = [scope.tenantId];
  const where = ['tenant_id = $1::uuid'];

  if (filters.branchId && filters.branchId !== 'all' && filters.branchId !== '*') {
    assertBranch(scope, filters.branchId);
    values.push(filters.branchId);
    where.push(`branch_id = $${values.length}::uuid`);
  } else if (!scope.branchIds.includes('*')) {
    values.push([...scope.branchIds.filter(isDatabaseUuid)]);
    where.push(`branch_id = ANY($${values.length}::uuid[])`);
  }
  if (filters.status) {
    values.push(filters.status);
    where.push(`status = $${values.length}`);
  }
  if (filters.groupId) {
    if (!isDatabaseUuid(filters.groupId)) throw new Error('A valid group UUID is required.');
    values.push(filters.groupId);
    where.push(`group_id = $${values.length}::uuid`);
  }

  const result = await query<SessionDbRow>(
    `SELECT ${columns} FROM public.attendance_sessions WHERE ${where.join(' AND ')} ORDER BY start_time DESC`,
    values,
  );
  return result.rows.map(mapSession);
}

export async function getAttendanceSession(
  scope: AttendanceSessionScope,
  sessionId: string,
): Promise<AttendanceSessionRecord | null> {
  assertScope(scope);
  if (!isDatabaseUuid(sessionId) && !/^att_[a-f0-9]{18}$/.test(sessionId)) throw new Error('A valid attendance session identifier is required.');
  const values: unknown[] = [scope.tenantId, sessionId];
  let branchClause = '';
  if (!scope.branchIds.includes('*')) {
    values.push([...scope.branchIds.filter(isDatabaseUuid)]);
    branchClause = ` AND branch_id = ANY($3::uuid[])`;
  }
  const result = await query<SessionDbRow>(
    `SELECT ${columns} FROM public.attendance_sessions
      WHERE tenant_id = $1::uuid AND (id::text = $2 OR session_code = $2)${branchClause}`,
    values,
  );
  return result.rows[0] ? mapSession(result.rows[0]) : null;
}

export async function closeAttendanceSession(
  scope: AttendanceSessionScope,
  sessionId: string,
): Promise<AttendanceSessionRecord | null> {
  assertScope(scope);
  if (!isDatabaseUuid(sessionId) && !/^att_[a-f0-9]{18}$/.test(sessionId)) throw new Error('A valid attendance session identifier is required.');
  return withTransaction(async (client: PoolClient) => {
    const locked = await client.query<SessionDbRow>(
      `SELECT ${columns} FROM public.attendance_sessions
        WHERE (id::text = $1 OR session_code = $1) AND tenant_id = $2::uuid
        FOR UPDATE`,
      [sessionId, scope.tenantId],
    );
    const row = locked.rows[0];
    if (!row || (!scope.branchIds.includes('*') && !scope.branchIds.includes(row.branch_id))) return null;
    if (row.status === 'active') {
      const updated = await client.query<SessionDbRow>(
        `UPDATE public.attendance_sessions SET status = 'closed', end_time = now()
          WHERE id = $1::uuid AND tenant_id = $2::uuid RETURNING ${columns}`,
        [row.id, scope.tenantId],
      );
      return mapSession(updated.rows[0]);
    }
    return mapSession(row);
  });
}

export async function rotateAttendanceSessionQrToken(
  scope: AttendanceSessionScope,
  sessionId: string,
): Promise<AttendanceSessionRecord | null> {
  assertScope(scope);
  if (!isDatabaseUuid(sessionId)) throw new Error('A valid attendance session UUID is required.');
  return withTransaction(async (client: PoolClient) => {
    const locked = await client.query<SessionDbRow>(
      `SELECT ${columns} FROM public.attendance_sessions
        WHERE (id::text = $1 OR session_code = $1) AND tenant_id = $2::uuid
        FOR UPDATE`,
      [sessionId, scope.tenantId],
    );
    const row = locked.rows[0];
    if (!row || (!scope.branchIds.includes('*') && !scope.branchIds.includes(row.branch_id))) return null;
    if (row.status !== 'active') throw new Error('Cannot rotate the QR token for a closed session.');
    const updated = await client.query<SessionDbRow>(
      `UPDATE public.attendance_sessions SET qr_payload_token = $3
        WHERE id = $1::uuid AND tenant_id = $2::uuid RETURNING ${columns}`,
      [row.id, scope.tenantId, makeQrToken()],
    );
    return mapSession(updated.rows[0]);
  });
}
