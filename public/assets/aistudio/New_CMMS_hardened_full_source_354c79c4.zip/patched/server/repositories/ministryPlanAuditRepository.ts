import { withTransaction } from '../pg';
import { AuditLog } from '../../src/types';

/**
 * Persist the already-created ministry audit entry without changing its ID or
 * integrity-chain fields. The caller supplies a tenant from authenticated scope.
 */
export async function persistMinistryPlanAuditLog(log: AuditLog, tenantId: string): Promise<void> {
  if (!tenantId) throw new Error('Authenticated tenant scope is required for ministry audit persistence.');
  if (!log.id || !log.action || !log.module || !log.details) {
    throw new Error('A complete ministry audit entry is required.');
  }

  await withTransaction(async (client) => {
    const inserted = await client.query(
      `INSERT INTO public.audit_logs (
        id, tenant_id, timestamp, user_id, actor_id, user_email, user_name, user_role,
        event_type, outcome, severity, correlation_id, action, module,
        target_user_id, target_user_email, ip_address, user_agent, device_fingerprint,
        session_id, details, commit_data, device, prev_hash, integrity_hash, schema_version
      ) VALUES (
        $1, $2::uuid, $3::timestamptz, $4, $5, $6, $7, $8,
        $9, $10, $11, $12, $13, $14,
        $15, $16, $17, $18, $19,
        $20, $21, $22, $23, $24, $25, $26
      ) ON CONFLICT (id) DO NOTHING
      RETURNING id`,
      [
        log.id, tenantId, log.timestamp, log.actorId || log.userEmail, log.actorId || log.userEmail,
        log.userEmail, log.userName || log.user || log.userEmail, log.userRole,
        log.eventType || log.action, log.outcome || 'SUCCESS', log.severity || 'LOW',
        log.correlationId || null, log.action, log.module, log.targetUserId || null,
        log.targetUserEmail || null, log.ipAddress || null, log.userAgent || null,
        log.deviceFingerprint || null, log.sessionId || null, log.details,
        log.commitData || null, log.device || null, log.prevHash || null,
        log.integrityHash || null, log.schemaVersion || '2.0',
      ],
    );

    if (inserted.rowCount === 0) {
      const existing = await client.query(
        `SELECT tenant_id, timestamp, action, module, integrity_hash
           FROM public.audit_logs
          WHERE id = $1
          FOR SHARE`,
        [log.id],
      );
      const row = existing.rows[0];
      const sameTenant = row?.tenant_id === tenantId;
      const sameEvent = row?.timestamp && new Date(row.timestamp).getTime() === new Date(log.timestamp).getTime()
        && row.action === log.action
        && row.module === log.module
        && (row.integrity_hash || null) === (log.integrityHash || null);
      if (!sameTenant || !sameEvent) {
        throw new Error('Audit event ID collision: the existing record does not match this tenant and event.');
      }
    }
  });
}
