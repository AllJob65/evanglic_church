import { withTransaction } from '../pg';
import { MinistryAnnualPlan } from '../../src/types';

export async function saveMinistryAnnualPlan(plan: MinistryAnnualPlan): Promise<void> {
  if (!plan.id || !plan.tenantId || !plan.branchId) {
    throw new Error('Ministry plan ID, tenantId, and branchId are required for persistence.');
  }

  await withTransaction(async (client) => {
    const result = await client.query(
      `INSERT INTO public.ministry_annual_plans (
        id, plan_code, tenant_id, branch_id, ministry_id, ministry_name, year, title,
        vision_statement, objectives, activities, responsible_person, responsible_person_id,
        target_audience, expected_participants, required_resources, optional_budget, currency,
        kpis, expected_outcomes, risks, mitigation_summary, quarterly_milestones, monthly_activities,
        status, revision_number, submitted_by, submitted_by_name, submitted_at,
        reviewed_by, reviewed_by_name, reviewed_at, approved_by, approved_by_name, approved_at,
        returned_reason, rejected_reason, review_history, quarterly_reports, annual_report,
        created_at, updated_at
      ) VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,$11::jsonb,$12,$13,$14,$15,$16,$17,$18,
        $19::jsonb,$20::jsonb,$21::jsonb,$22,$23::jsonb,$24::jsonb,$25,$26,$27,$28,$29,
        $30,$31,$32,$33,$34,$35,$36,$37,$38::jsonb,$39::jsonb,$40::jsonb,$41,$42
      )
      ON CONFLICT (id) DO UPDATE SET
        plan_code = EXCLUDED.plan_code,
        ministry_id = EXCLUDED.ministry_id,
        ministry_name = EXCLUDED.ministry_name,
        year = EXCLUDED.year,
        title = EXCLUDED.title,
        vision_statement = EXCLUDED.vision_statement,
        objectives = EXCLUDED.objectives,
        activities = EXCLUDED.activities,
        responsible_person = EXCLUDED.responsible_person,
        responsible_person_id = EXCLUDED.responsible_person_id,
        target_audience = EXCLUDED.target_audience,
        expected_participants = EXCLUDED.expected_participants,
        required_resources = EXCLUDED.required_resources,
        optional_budget = EXCLUDED.optional_budget,
        currency = EXCLUDED.currency,
        kpis = EXCLUDED.kpis,
        expected_outcomes = EXCLUDED.expected_outcomes,
        risks = EXCLUDED.risks,
        mitigation_summary = EXCLUDED.mitigation_summary,
        quarterly_milestones = EXCLUDED.quarterly_milestones,
        monthly_activities = EXCLUDED.monthly_activities,
        status = EXCLUDED.status,
        revision_number = EXCLUDED.revision_number,
        submitted_by = EXCLUDED.submitted_by,
        submitted_by_name = EXCLUDED.submitted_by_name,
        submitted_at = EXCLUDED.submitted_at,
        reviewed_by = EXCLUDED.reviewed_by,
        reviewed_by_name = EXCLUDED.reviewed_by_name,
        reviewed_at = EXCLUDED.reviewed_at,
        approved_by = EXCLUDED.approved_by,
        approved_by_name = EXCLUDED.approved_by_name,
        approved_at = EXCLUDED.approved_at,
        returned_reason = EXCLUDED.returned_reason,
        rejected_reason = EXCLUDED.rejected_reason,
        review_history = EXCLUDED.review_history,
        quarterly_reports = EXCLUDED.quarterly_reports,
        annual_report = EXCLUDED.annual_report,
        updated_at = EXCLUDED.updated_at
      WHERE public.ministry_annual_plans.tenant_id = EXCLUDED.tenant_id
        AND public.ministry_annual_plans.branch_id = EXCLUDED.branch_id
      RETURNING id`,
      [
        plan.id, plan.planCode, plan.tenantId, plan.branchId, plan.ministryId, plan.ministryName,
        plan.year, plan.title, plan.visionStatement || '', JSON.stringify(plan.objectives || []),
        JSON.stringify(plan.activities || []), plan.responsiblePerson, plan.responsiblePersonId || null,
        plan.targetAudience, plan.expectedParticipants || 0, plan.requiredResources || '',
        plan.optionalBudget || 0, plan.currency || 'ETB', JSON.stringify(plan.kpis || []),
        JSON.stringify(plan.expectedOutcomes || []), JSON.stringify(plan.risks || []),
        plan.mitigationSummary || '', JSON.stringify(plan.quarterlyMilestones || []),
        JSON.stringify(plan.monthlyActivities || []), plan.status, plan.revisionNumber || 1,
        plan.submittedBy || null, plan.submittedByName || null, plan.submittedAt || null,
        plan.reviewedBy || null, plan.reviewedByName || null, plan.reviewedAt || null,
        plan.approvedBy || null, plan.approvedByName || null, plan.approvedAt || null,
        plan.returnedReason || null, plan.rejectedReason || null,
        JSON.stringify(plan.reviewHistory || []), JSON.stringify(plan.quarterlyReports || []),
        plan.annualReport ? JSON.stringify(plan.annualReport) : null,
        plan.createdAt || new Date().toISOString(), plan.updatedAt || new Date().toISOString(),
      ],
    );

    if (result.rowCount !== 1) {
      throw new Error('Ministry plan scope conflict: the existing record belongs to a different tenant or branch.');
    }
  });
}
