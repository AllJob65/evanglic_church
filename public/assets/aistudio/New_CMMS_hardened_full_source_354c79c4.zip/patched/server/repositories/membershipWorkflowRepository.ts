import { randomUUID } from 'crypto';
import { query, withTransaction } from '../pg';
import type { WorkflowRequest, Member } from '../../src/types';

export interface MembershipApplicationInput {
  tenantId: string;
  branchId: string;
  requestCode: string;
  requesterName: string;
  requesterPhone?: string;
  requesterEmail?: string;
  branchName?: string;
  details: string;
  pendingMemberData: Partial<Member>;
  submittedDate?: string;
  status?: 'Pending' | 'Approved';
  approvedBy?: string;
}
type Row = {
  id:string; tenant_id:string; branch_id:string|null; request_code:string; request_type:string;
  requester_name:string; requester_phone:string|null; requester_email:string|null; branch_name:string|null;
  details:string; current_step:string|null; assigned_role:string|null; status:string|null;
  comments:string|null; approved_by:string|null; approved_at:string|null; rejected_reason:string|null;
  decision_notes:string|null; pending_member_data:Partial<Member>|null; created_at:string;
};
function mapRow(r:Row):WorkflowRequest {
  return {
    id:r.id,tenantId:r.tenant_id,branchId:r.branch_id||undefined,requestCode:r.request_code,
    requestType:'Membership Application',requesterName:r.requester_name,requesterPhone:r.requester_phone||undefined,
    requesterEmail:r.requester_email||undefined,branchName:r.branch_name||'',details:r.details,
    currentStep:r.current_step||'Submitted for Review',assignedApproverRole:(r.assigned_role||'PASTOR') as any,
    submittedDate:r.created_at?.slice(0,10)||'',status:(r.status||'Pending') as WorkflowRequest['status'],
    comments:r.comments||undefined,approvedBy:r.approved_by||undefined,approvedAt:r.approved_at||undefined,
    rejectedReason:r.rejected_reason||undefined,decisionNotes:r.decision_notes||undefined,
    pendingMemberData:r.pending_member_data||undefined,
  };
}
const selectColumns=`id,tenant_id,branch_id,request_code,request_type,requester_name,requester_phone,
 requester_email,branch_name,details,current_step,assigned_role,status,comments,approved_by,approved_at,
 rejected_reason,decision_notes,pending_member_data,created_at`;

export async function createMembershipApplication(input:MembershipApplicationInput):Promise<WorkflowRequest>{
  const id=randomUUID();
  const result=await query<Row>(
    `INSERT INTO public.workflow_requests
      (id,tenant_id,branch_id,request_code,request_type,requester_name,requester_phone,requester_email,
       branch_name,details,current_step,assigned_role,status,pending_member_data,approved_by,approved_at)
     VALUES($1::uuid,$2::uuid,$3::uuid,$4,'Membership Application',$5,$6,$7,$8,$9,
       'Membership Application Review','PASTOR',$10,$11::jsonb,$12,CASE WHEN $10='Approved' THEN now() ELSE NULL END)
     RETURNING ${selectColumns}`,
    [id,input.tenantId,input.branchId,input.requestCode,input.requesterName,input.requesterPhone||null,
     input.requesterEmail||null,input.branchName||null,input.details,input.status||'Pending',JSON.stringify(input.pendingMemberData),input.approvedBy||null]
  );
  return mapRow(result.rows[0]);
}

export async function listMembershipApplications(scope:{tenantId:string;branchIds:string[];allBranches:boolean}):Promise<WorkflowRequest[]>{
  const result=scope.allBranches
    ? await query<Row>(`SELECT ${selectColumns} FROM public.workflow_requests
        WHERE tenant_id=$1::uuid AND request_type='Membership Application'
        ORDER BY created_at DESC,id DESC`,[scope.tenantId])
    : await query<Row>(`SELECT ${selectColumns} FROM public.workflow_requests
        WHERE tenant_id=$1::uuid AND request_type='Membership Application'
          AND (branch_id IS NULL OR branch_id=ANY($2::uuid[]))
        ORDER BY created_at DESC,id DESC`,[scope.tenantId,scope.branchIds]);
  return result.rows.map(mapRow);
}
export async function getMembershipApplication(id:string,tenantId:string,branchIds:string[],allBranches:boolean):Promise<WorkflowRequest|null>{
  const result=allBranches
    ? await query<Row>(`SELECT ${selectColumns} FROM public.workflow_requests WHERE id=$1::uuid AND tenant_id=$2::uuid AND request_type='Membership Application'`,[id,tenantId])
    : await query<Row>(`SELECT ${selectColumns} FROM public.workflow_requests WHERE id=$1::uuid AND tenant_id=$2::uuid AND request_type='Membership Application' AND (branch_id IS NULL OR branch_id=ANY($3::uuid[]))`,[id,tenantId,branchIds]);
  return result.rows[0]?mapRow(result.rows[0]):null;
}
export async function saveMembershipDecision(input:{
  id:string;tenantId:string;status:'Approved'|'Rejected';approvedBy:string;rejectedReason?:string;decisionNotes?:string;
}):Promise<WorkflowRequest|null>{
  const result=await query<Row>(
    `UPDATE public.workflow_requests SET status=$3,approved_by=$4,approved_at=CASE WHEN $3='Approved' THEN now() ELSE NULL END,
       rejected_reason=$5,decision_notes=$6,updated_at=now()
     WHERE id=$1::uuid AND tenant_id=$2::uuid AND request_type='Membership Application' AND status='Pending'
     RETURNING ${selectColumns}`,
    [input.id,input.tenantId,input.status,input.approvedBy,input.rejectedReason||null,input.decisionNotes||null]
  );
  return result.rows[0]?mapRow(result.rows[0]):null;
}
export async function findMembershipApplication(ref:string):Promise<WorkflowRequest|null>{
  const result=await query<Row>(
    `SELECT ${selectColumns} FROM public.workflow_requests
      WHERE request_type='Membership Application'
        AND (lower(request_code)=lower($1) OR lower(requester_email)=lower($1) OR regexp_replace(coalesce(requester_phone,''),'[^0-9]','','g')=regexp_replace($1,'[^0-9]','','g'))
      ORDER BY created_at DESC LIMIT 1`,[ref]
  );
  return result.rows[0]?mapRow(result.rows[0]):null;
}


/**
 * Approve a membership application atomically. The member row, extended
 * registration details, ministry links, profile link, and workflow decision
 * are committed together so a failed approval cannot leave a half-created
 * member or a still-pending request.
 */
export async function approveMembershipApplication(input:{
  id:string;tenantId:string;approvedBy:string;decisionNotes?:string;
}):Promise<{workflow:WorkflowRequest;memberId:string}>{
  return withTransaction(async client=>{
    const locked=await client.query<Row>(
      `SELECT ${selectColumns} FROM public.workflow_requests
       WHERE id=$1::uuid AND tenant_id=$2::uuid AND request_type='Membership Application'
       FOR UPDATE`,
      [input.id,input.tenantId]
    );
    const row=locked.rows[0];
    if(!row) throw new Error('Membership application not found.');
    if(row.status!=='Pending') throw new Error('This application has already been decided.');
    const data=(row.pending_member_data||{}) as Partial<Member>;
    const branchId=row.branch_id;
    if(!branchId) throw new Error('Application has no assigned branch.');
    const branch=await client.query(
      `SELECT id FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid AND status='Active'`,
      [branchId,input.tenantId]
    );
    if(!branch.rowCount) throw new Error('The application branch is not active in this tenant.');
    const firstName=String(data.firstName||row.requester_name.split(/\s+/)[0]||'').trim();
    const lastName=String(data.lastName||row.requester_name.split(/\s+/).slice(1).join(' ')||'Member').trim();
    if(!firstName||!lastName) throw new Error('Applicant first name and last name are required.');
    const email=String(data.email||row.requester_email||'').trim().toLowerCase()||null;
    const phone=String(data.primaryPhone||row.requester_phone||'').trim()||null;
    const duplicate=await client.query(
      `SELECT id FROM public.members WHERE tenant_id=$1::uuid AND
       (($2::text IS NOT NULL AND lower(email)=lower($2)) OR
        ($3::text IS NOT NULL AND regexp_replace(coalesce(phone,''),'[^0-9]','','g')=regexp_replace($3,'[^0-9]','','g')))
       LIMIT 1`,
      [input.tenantId,email,phone]
    );
    if(duplicate.rowCount) throw new Error('A member with this email address or phone number already exists. Review the Members list before approving this application.');
    const memberId=randomUUID();
    const memberNumber=String(data.memberIdNumber||`GC-${new Date().getFullYear()}-${randomUUID().slice(0,8).toUpperCase()}`);
    const gender=data.gender==='Female'?'Female':'Male';
    const ministryIds=[...new Set((Array.isArray(data.ministryIds)?data.ministryIds:[]).filter((v):v is string=>typeof v==='string'))];
    if(ministryIds.length){
      const valid=await client.query(
        'SELECT COUNT(*)::int AS count FROM public.ministries WHERE id=ANY($1::uuid[]) AND tenant_id=$2::uuid',
        [ministryIds,input.tenantId]
      );
      if(Number(valid.rows[0]?.count)!==ministryIds.length) throw new Error('One or more selected ministries are not available in this church.');
    }
    await client.query(
      `INSERT INTO public.members
       (id,tenant_id,branch_id,member_number,first_name,middle_name,last_name,gender,marital_status,date_of_birth,
        phone,email,address,city,membership_status,fellowship_group)
       VALUES($1::uuid,$2::uuid,$3::uuid,$4,$5,$6,$7,$8,$9,$10::date,$11,$12,$13,$14,'Active',$15)`,
      [memberId,input.tenantId,branchId,memberNumber,firstName,data.middleName||null,lastName,gender,
       data.maritalStatus||'Single',data.dateOfBirth||null,phone,email,data.streetAddress||null,data.city||null,
       data.bibleStudyGroupId||null]
    );
    const coreKeys=new Set(['id','tenantId','branchId','memberIdNumber','firstName','middleName','lastName','gender','maritalStatus','dateOfBirth','primaryPhone','email','streetAddress','city','membershipStatus','ministryIds','createdAt','lastActive','attendanceScore','emergencyContact','bloodType','knownAllergies','medicalConditions','specialNeeds','notes']);
    const registration=Object.fromEntries(Object.entries(data as Record<string,unknown>).filter(([key])=>!coreKeys.has(key)));
    const spiritualKeys=['salvationDate','salvationLocation','ledToChristBy','salvationTestimony','isWaterBaptized','waterBaptized','waterBaptismDate','baptismDate','waterBaptismLocation','baptizedBy','waterBaptismCertUrl','isHolySpiritBaptized','holySpiritBaptismDate','spiritualGifts','membershipLocation','discipleshipStatus','discipleshipLevel','previousChurch','foundationCourseCompleted','bibleStudyGroupId','mentorName','currentMinistryStatus','previousMinistryStatus','ministriesServedBefore','ministriesJoinedNow'];
    const householdKeys=['familyId','familyRole','maleChildrenCount','femaleChildrenCount','adoptedChildrenCount','spouseName','spousePhone','spouseMemberId'];
    const professionalKeys=['educationLevel','institutionName','fieldOfStudy','occupation','employer','employerName','employerType','employerTypeOther','employerContact','skillsAndTalents','languagesSpoken'];
    const lifecycleKeys=['departureReason','departureDate','departureEndDate','statusStartDate','statusEndDate','departureNotes','excommunicationPaperUrl','excommunicationPaperName','excommunicationDescription'];
    const pick=(keys:string[])=>Object.fromEntries(keys.filter(key=>(data as any)[key]!==undefined).map(key=>[key,(data as any)[key]]));
    await client.query(
      `INSERT INTO public.member_details(member_id,tenant_id,branch_id,registration_data,spiritual_data,household_data,professional_data,lifecycle_data)
       VALUES($1::uuid,$2::uuid,$3::uuid,$4::jsonb,$5::jsonb,$6::jsonb,$7::jsonb,$8::jsonb)`,
      [memberId,input.tenantId,branchId,JSON.stringify(registration),JSON.stringify(pick(spiritualKeys)),
       JSON.stringify(pick(householdKeys)),JSON.stringify(pick(professionalKeys)),JSON.stringify(pick(lifecycleKeys))]
    );
    const health=Object.fromEntries(['bloodType','knownAllergies','medicalConditions','specialNeeds'].filter(k=>(data as any)[k]!==undefined).map(k=>[k,(data as any)[k]]));
    const emergency=data.emergencyContact||{};
    if(Object.keys(health).length||Object.values(emergency as Record<string,unknown>).some(v=>v!==undefined&&v!==null&&String(v).trim())||data.notes){
      await client.query(
        `INSERT INTO public.member_private_details(member_id,tenant_id,branch_id,emergency_contact,health_information,access_note)
         VALUES($1::uuid,$2::uuid,$3::uuid,$4::jsonb,$5::jsonb,$6)`,
        [memberId,input.tenantId,branchId,JSON.stringify(emergency),JSON.stringify(health),data.notes||null]
      );
    }
    for(const ministryId of ministryIds){
      await client.query('INSERT INTO public.ministry_members(ministry_id,member_id) VALUES($1::uuid,$2::uuid)',[ministryId,memberId]);
    }
    if(email){
      await client.query(
        `UPDATE public.profiles SET status='Active',member_id=$2::uuid,updated_at=now()
         WHERE tenant_id=$1::uuid AND lower(email)=lower($3)`,
        [input.tenantId,memberId,email]
      );
    }
    const decided=await client.query<Row>(
      `UPDATE public.workflow_requests SET status='Approved',approved_by=$3,approved_at=now(),
       current_step='Completed & Archived',decision_notes=$4,updated_at=now()
       WHERE id=$1::uuid AND tenant_id=$2::uuid AND status='Pending'
       RETURNING ${selectColumns}`,
      [input.id,input.tenantId,input.approvedBy,input.decisionNotes||'Approved by church administration']
    );
    if(!decided.rows[0]) throw new Error('Application decision could not be saved; no member was created.');
    return {workflow:mapRow(decided.rows[0]),memberId};
  });
}
