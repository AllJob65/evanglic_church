import { randomUUID } from 'crypto';
import { PoolClient } from 'pg';
import { query, withTransaction } from '../pg';
import type { Member } from '../../src/types';

type MemberRow = {
  id: string; tenant_id: string; branch_id: string; member_number: string;
  first_name: string; middle_name: string | null; last_name: string;
  gender: 'Male' | 'Female'; marital_status: string | null; date_of_birth: string | null;
  phone: string | null; email: string | null; address: string | null; city: string | null;
  membership_status: string; fellowship_group: string | null; created_at: string; updated_at: string;
};
type JsonRow = { member_id: string; registration_data: Record<string, unknown>; spiritual_data: Record<string, unknown>; household_data: Record<string, unknown>; professional_data: Record<string, unknown>; lifecycle_data: Record<string, unknown> };
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function isDatabaseUuid(value: unknown): value is string { return typeof value === 'string' && UUID_RE.test(value); }

const SPIRITUAL_KEYS = ['salvationDate','salvationLocation','ledToChristBy','salvationTestimony','isWaterBaptized','waterBaptized','waterBaptismDate','baptismDate','waterBaptismLocation','baptizedBy','waterBaptismCertUrl','isHolySpiritBaptized','holySpiritBaptismDate','spiritualGifts','membershipLocation','discipleshipStatus','discipleshipLevel','previousChurch','foundationCourseCompleted','bibleStudyGroupId','mentorName','currentMinistryStatus','previousMinistryStatus','ministriesServedBefore','ministriesJoinedNow'];
const HOUSEHOLD_KEYS = ['familyId','familyRole','maleChildrenCount','femaleChildrenCount','adoptedChildrenCount','spouseName','spousePhone','spouseMemberId'];
const PROFESSIONAL_KEYS = ['educationLevel','institutionName','fieldOfStudy','occupation','employer','employerName','employerType','employerTypeOther','employerContact','skillsAndTalents','languagesSpoken'];
const LIFECYCLE_KEYS = ['departureReason','departureDate','departureEndDate','statusStartDate','statusEndDate','departureNotes','excommunicationPaperUrl','excommunicationPaperName','excommunicationDescription'];
const PRIVATE_KEYS = ['bloodType','knownAllergies','medicalConditions','specialNeeds','emergencyContact','notes'];
const CORE_KEYS = new Set(['id','tenantId','branchId','memberIdNumber','firstName','middleName','lastName','dateOfBirth','gender','maritalStatus','primaryPhone','email','streetAddress','city','membershipStatus','ministryIds','createdAt','lastActive',...SPIRITUAL_KEYS,...HOUSEHOLD_KEYS,...PROFESSIONAL_KEYS,...LIFECYCLE_KEYS,...PRIVATE_KEYS]);
function pick(source: Record<string, unknown>, keys: string[]) { return Object.fromEntries(keys.filter(k => source[k] !== undefined).map(k => [k,source[k]])); }
function withoutCore(input: Member) { return Object.fromEntries(Object.entries(input as unknown as Record<string,unknown>).filter(([k,v]) => !CORE_KEYS.has(k) && v !== undefined)); }
function baseDomain(r: MemberRow): Member {
 return { id:r.id,tenantId:r.tenant_id,branchId:r.branch_id,memberIdNumber:r.member_number,title:'',firstName:r.first_name,middleName:r.middle_name||undefined,lastName:r.last_name,dateOfBirth:r.date_of_birth?String(r.date_of_birth).slice(0,10):'',gender:r.gender,maritalStatus:(r.marital_status||'Single') as Member['maritalStatus'],primaryPhone:r.phone||'',email:r.email||undefined,streetAddress:r.address||'',city:r.city||'',membershipStatus:r.membership_status as Member['membershipStatus'],emergencyContact:{name:'',relationship:'',phone:''},ministryIds:[],createdAt:r.created_at,lastActive:r.updated_at,attendanceScore:0 };
}
async function hydrate(rows: MemberRow[]): Promise<Member[]> {
 if (!rows.length) return [];
 const ids=rows.map(r=>r.id);
 const [details,ministries]=await Promise.all([
  query<JsonRow>('SELECT member_id,registration_data,spiritual_data,household_data,professional_data,lifecycle_data FROM public.member_details WHERE member_id=ANY($1::uuid[])',[ids]),
  query<{member_id:string;ministry_id:string}>('SELECT member_id,ministry_id FROM public.ministry_members WHERE member_id=ANY($1::uuid[])',[ids])
 ]);
 const detailMap=new Map(details.rows.map(x=>[x.member_id,x]));
 const ministryMap=new Map<string,string[]>();
 for(const x of ministries.rows) ministryMap.set(x.member_id,[...(ministryMap.get(x.member_id)||[]),x.ministry_id]);
 return rows.map(row=>{
  const d=detailMap.get(row.id);
  // Sensitive emergency/health fields are intentionally not included in ordinary member reads.
  return { ...baseDomain(row), ...(d?.registration_data||{}), ...(d?.spiritual_data||{}), ...(d?.household_data||{}), ...(d?.professional_data||{}), ...(d?.lifecycle_data||{}), emergencyContact:{name:'',relationship:'',phone:''}, ministryIds:ministryMap.get(row.id)||[] } as Member;
 });
}
export interface MemberScope { tenantId:string; branchIds:string[]; branchId?:string; allBranches:boolean; }
function assertScope(s:MemberScope) {
 if(!isDatabaseUuid(s.tenantId)) throw new Error('Authenticated profile has no valid tenant UUID.');
 if(!s.allBranches && ![...s.branchIds,s.branchId||''].some(isDatabaseUuid)) throw new Error('Authenticated profile has no valid branch UUID assignments.');
}
function whereScope(s:MemberScope,params:unknown[]) {
 assertScope(s); params.push(s.tenantId); let w=`tenant_id=$${params.length}::uuid`;
 if(!s.allBranches) {
  if(s.branchId && s.branchId!=='all') {
   if(!isDatabaseUuid(s.branchId)||!s.branchIds.includes(s.branchId)) throw new Error('Branch access denied.');
   params.push(s.branchId);w+=` AND branch_id=${params.length}::uuid`;
  } else {
   const ids=[...new Set(s.branchIds.filter(isDatabaseUuid))];
   params.push(ids);w+=` AND branch_id=ANY(${params.length}::uuid[])`;
  }
 } else if(s.branchId && s.branchId!=='all') {
  if(!isDatabaseUuid(s.branchId)) throw new Error('Invalid branch UUID filter.');
  params.push(s.branchId);w+=` AND branch_id=${params.length}::uuid`;
 }
 return w;
}
const columns=`id,tenant_id,branch_id,member_number,first_name,middle_name,last_name,gender,marital_status,date_of_birth,phone,email,address,city,membership_status,fellowship_group,created_at,updated_at`;
async function saveExtras(client:PoolClient,id:string,tenantId:string,branchId:string,input:Member) {
 const raw=input as unknown as Record<string,unknown>;
 const reg=withoutCore(input);
 await client.query(`INSERT INTO public.member_details(member_id,tenant_id,branch_id,registration_data,spiritual_data,household_data,professional_data,lifecycle_data,updated_at)
 VALUES($1::uuid,$2::uuid,$3::uuid,$4::jsonb,$5::jsonb,$6::jsonb,$7::jsonb,$8::jsonb,now())
 ON CONFLICT(member_id) DO UPDATE SET tenant_id=EXCLUDED.tenant_id,branch_id=EXCLUDED.branch_id,registration_data=EXCLUDED.registration_data,spiritual_data=EXCLUDED.spiritual_data,household_data=EXCLUDED.household_data,professional_data=EXCLUDED.professional_data,lifecycle_data=EXCLUDED.lifecycle_data,updated_at=now()`,
 [id,tenantId,branchId,JSON.stringify(reg),JSON.stringify(pick(raw,SPIRITUAL_KEYS)),JSON.stringify(pick(raw,HOUSEHOLD_KEYS)),JSON.stringify(pick(raw,PROFESSIONAL_KEYS)),JSON.stringify(pick(raw,LIFECYCLE_KEYS))]);
 const health=pick(raw,['bloodType','knownAllergies','medicalConditions','specialNeeds']);
 const contact=input.emergencyContact as unknown as Record<string,unknown>|undefined;
 const hasPrivateValues=Boolean(
  (contact&&Object.values(contact).some(v=>v!==undefined&&v!==null&&String(v).trim()!=='')) ||
  Object.values(health).some(v=>Array.isArray(v)?v.length>0:v!==undefined&&v!==null&&v!=='') ||
  (typeof input.notes==='string'&&input.notes.trim())
 );
 if(hasPrivateValues) {
  await client.query(`INSERT INTO public.member_private_details(member_id,tenant_id,branch_id,emergency_contact,health_information,access_note,updated_at)
  VALUES($1::uuid,$2::uuid,$3::uuid,$4::jsonb,$5::jsonb,$6,now())
  ON CONFLICT(member_id) DO UPDATE SET tenant_id=EXCLUDED.tenant_id,branch_id=EXCLUDED.branch_id,emergency_contact=EXCLUDED.emergency_contact,health_information=EXCLUDED.health_information,access_note=EXCLUDED.access_note,updated_at=now()`,
  [id,tenantId,branchId,JSON.stringify(contact||{}),JSON.stringify(health),typeof input.notes==='string'?input.notes:null]);
 }
 await client.query('DELETE FROM public.ministry_members WHERE member_id=$1::uuid',[id]);
 for(const ministryId of [...new Set(input.ministryIds||[])]) {
  if(!isDatabaseUuid(ministryId)) throw new Error('Invalid ministry UUID in member ministry list.');
  await client.query('INSERT INTO public.ministry_members(ministry_id,member_id) VALUES($1::uuid,$2::uuid)',[ministryId,id]);
 }
}
export async function listMembers(scope:MemberScope,filters:{search?:string;status?:string;limit?:number;offset?:number}={}):Promise<{members:Member[];total:number}> {
 const params:unknown[]=[]; const clauses=[whereScope(scope,params)];
 if(filters.status&&filters.status!=='all'){params.push(filters.status);clauses.push(`membership_status=$${params.length}`);}
 if(filters.search?.trim()){params.push(`%${filters.search.trim()}%`);const p=params.length;clauses.push(`(first_name ILIKE $${p} OR middle_name ILIKE $${p} OR last_name ILIKE $${p} OR email ILIKE $${p} OR member_number ILIKE $${p} OR phone ILIKE $${p})`);}
 const where=clauses.join(' AND ');
 const count=await query<{total:string}>(`SELECT COUNT(*)::text AS total FROM public.members WHERE ${where}`,params);
 const limit=Number.isFinite(filters.limit)&&filters.limit?Math.max(1,Math.min(200,Math.trunc(filters.limit as number))):undefined,offset=Number.isFinite(filters.offset)?Math.max(0,Math.trunc(filters.offset as number)):0;
 const rows=await query<MemberRow>(`SELECT ${columns} FROM public.members WHERE ${where} ORDER BY created_at DESC,id DESC${limit? ` LIMIT ${limit} OFFSET ${offset}`:''}`,params);
 return {members:await hydrate(rows.rows),total:Number(count.rows[0]?.total||0)};
}
export async function getMemberById(id:string,scope:MemberScope):Promise<Member|null>{
 if(!isDatabaseUuid(id)) return null; const p:unknown[]=[id]; const w=`id=$1::uuid AND ${whereScope(scope,p)}`;
 const r=await query<MemberRow>(`SELECT ${columns} FROM public.members WHERE ${w} LIMIT 1`,p); return (await hydrate(r.rows))[0]||null;
}
export async function createMemberRecord(input:Member,scope:MemberScope):Promise<Member>{
 assertScope(scope);const branchId=input.branchId||scope.branchId;
 if(!isDatabaseUuid(branchId)||(!scope.allBranches&&![...scope.branchIds,scope.branchId||''].includes(branchId))) throw new Error('Branch access denied or invalid branch UUID.');
 const id=randomUUID(),number=input.memberIdNumber?.trim()||`GC-${new Date().getFullYear()}-${randomUUID().slice(0,8).toUpperCase()}`;
 await withTransaction(async client=>{
 const branchCheck=await client.query("SELECT 1 FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid AND status='Active' LIMIT 1",[branchId,scope.tenantId]);
 if(!branchCheck.rowCount) throw new Error('The selected branch is not active in this tenant.');
 const requestedMinistries=[...new Set(input.ministryIds||[])];
 if(requestedMinistries.some(id=>!isDatabaseUuid(id))) throw new Error('Invalid ministry UUID in member ministry list.');
 if(requestedMinistries.length){
  const ministryCheck=await client.query('SELECT COUNT(*)::int AS count FROM public.ministries WHERE id=ANY($1::uuid[]) AND tenant_id=$2::uuid',[requestedMinistries,scope.tenantId]);
  if(Number(ministryCheck.rows[0]?.count)!==requestedMinistries.length) throw new Error('One or more selected ministries do not belong to this tenant.');
 }
 await client.query(`INSERT INTO public.members(id,tenant_id,branch_id,member_number,first_name,middle_name,last_name,gender,marital_status,date_of_birth,phone,email,address,city,membership_status,fellowship_group)
 VALUES($1::uuid,$2::uuid,$3::uuid,$4,$5,$6,$7,$8,$9,$10::date,$11,$12,$13,$14,$15,$16)`,
 [id,scope.tenantId,branchId,number,input.firstName.trim(),input.middleName||null,input.lastName.trim(),input.gender,input.maritalStatus||'Single',input.dateOfBirth||null,input.primaryPhone||null,input.email||null,input.streetAddress||null,input.city||null,input.membershipStatus||'Active',input.bibleStudyGroupId||null]);
 await saveExtras(client,id,scope.tenantId,branchId,input);
 });
 const saved=await getMemberById(id,scope);
 if(!saved) throw new Error('Member was created but could not be reloaded.');
 return saved;
}
export async function updateMemberRecord(id:string,input:Partial<Member>,scope:MemberScope):Promise<Member|null>{
 const current=await getMemberById(id,scope);if(!current)return null;
 const merged={...current,...input,id:current.id,tenantId:current.tenantId} as Member;
 const branchId=merged.branchId||current.branchId;
 if(!isDatabaseUuid(branchId)||(!scope.allBranches&&![...scope.branchIds,scope.branchId||''].includes(branchId))) throw new Error('Branch access denied.');
 const updated=await withTransaction(async client=>{
 const branchCheck=await client.query("SELECT 1 FROM public.branches WHERE id=$1::uuid AND tenant_id=$2::uuid AND status='Active' LIMIT 1",[branchId,scope.tenantId]);
 if(!branchCheck.rowCount) throw new Error('The selected branch is not active in this tenant.');
 const requestedMinistries=[...new Set(merged.ministryIds||[])];
 if(requestedMinistries.some(id=>!isDatabaseUuid(id))) throw new Error('Invalid ministry UUID in member ministry list.');
 if(requestedMinistries.length){
  const ministryCheck=await client.query('SELECT COUNT(*)::int AS count FROM public.ministries WHERE id=ANY($1::uuid[]) AND tenant_id=$2::uuid',[requestedMinistries,scope.tenantId]);
  if(Number(ministryCheck.rows[0]?.count)!==requestedMinistries.length) throw new Error('One or more selected ministries do not belong to this tenant.');
 }
 const r=await client.query(`UPDATE public.members SET branch_id=$3::uuid,first_name=$4,middle_name=$5,last_name=$6,gender=$7,marital_status=$8,date_of_birth=$9::date,phone=$10,email=$11,address=$12,city=$13,membership_status=$14,fellowship_group=$15,updated_at=now()
 WHERE id=$1::uuid AND tenant_id=$2::uuid RETURNING id`,
 [id,scope.tenantId,branchId,merged.firstName,merged.middleName||null,merged.lastName,merged.gender,merged.maritalStatus||'Single',merged.dateOfBirth||null,merged.primaryPhone||null,merged.email||null,merged.streetAddress||null,merged.city||null,merged.membershipStatus,merged.bibleStudyGroupId||null]);
 if(!r.rows[0])return false;await saveExtras(client,id,scope.tenantId,branchId,merged);return true;
 });
 return updated?getMemberById(id,scope):null;
}
export async function deleteMemberRecord(id:string,scope:MemberScope):Promise<boolean>{
 if(!isDatabaseUuid(id))return false;const p:unknown[]=[id];const w=`id=$1::uuid AND ${whereScope(scope,p)}`;
 const r=await query(`DELETE FROM public.members WHERE ${w}`,p);return r.rowCount===1;
}
