import { query } from '../pg';
import { MinistryAnnualPlan, MinistryPlanWorkflowStatus } from '../../src/types';

export interface MinistryPlanReadScope {
  tenantId: string;
  branchIds: string[];
}

function toIso(value: unknown): string {
  return value ? new Date(value as string | number | Date).toISOString() : new Date(0).toISOString();
}

export function mapMinistryAnnualPlanRow(row: Record<string, any>): MinistryAnnualPlan {
  return {
    id: String(row.id),
    planCode: String(row.plan_code),
    tenantId: String(row.tenant_id),
    branchId: String(row.branch_id),
    ministryId: String(row.ministry_id),
    ministryName: String(row.ministry_name),
    year: Number(row.year),
    title: String(row.title),
    visionStatement: row.vision_statement || '',
    objectives: row.objectives || [],
    activities: row.activities || [],
    responsiblePerson: row.responsible_person || '',
    responsiblePersonId: row.responsible_person_id || undefined,
    targetAudience: row.target_audience || '',
    expectedParticipants: Number(row.expected_participants || 0),
    requiredResources: row.required_resources || '',
    optionalBudget: Number(row.optional_budget || 0),
    currency: row.currency || 'ETB',
    kpis: row.kpis || [],
    expectedOutcomes: row.expected_outcomes || [],
    risks: row.risks || [],
    mitigationSummary: row.mitigation_summary || '',
    quarterlyMilestones: row.quarterly_milestones || [],
    monthlyActivities: row.monthly_activities || [],
    status: row.status as MinistryPlanWorkflowStatus,
    revisionNumber: Number(row.revision_number || 1),
    submittedBy: row.submitted_by || '',
    submittedByName: row.submitted_by_name || '',
    submittedAt: row.submitted_at ? toIso(row.submitted_at) : undefined,
    reviewedBy: row.reviewed_by || undefined,
    reviewedByName: row.reviewed_by_name || undefined,
    reviewedAt: row.reviewed_at ? toIso(row.reviewed_at) : undefined,
    approvedBy: row.approved_by || undefined,
    approvedByName: row.approved_by_name || undefined,
    approvedAt: row.approved_at ? toIso(row.approved_at) : undefined,
    returnedReason: row.returned_reason || undefined,
    rejectedReason: row.rejected_reason || undefined,
    reviewHistory: row.review_history || [],
    quarterlyReports: row.quarterly_reports || [],
    annualReport: row.annual_report || null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

export async function listMinistryAnnualPlans(scope: MinistryPlanReadScope): Promise<MinistryAnnualPlan[]> {
  if (!scope.tenantId) throw new Error('Tenant scope is required to list ministry plans.');
  const branches = [...new Set(scope.branchIds.filter(Boolean))];
  const allBranches = branches.includes('*');
  const result = await query(
    `SELECT * FROM public.ministry_annual_plans
     WHERE tenant_id = $1 AND ($2::boolean OR branch_id = ANY($3::text[]))
     ORDER BY year DESC, updated_at DESC`,
    [scope.tenantId, allBranches, branches],
  );
  return result.rows.map((row) => mapMinistryAnnualPlanRow(row));
}

export async function getMinistryAnnualPlanById(
  scope: MinistryPlanReadScope,
  planId: string,
): Promise<MinistryAnnualPlan | null> {
  if (!scope.tenantId) throw new Error('Tenant scope is required to read a ministry plan.');
  const branches = [...new Set(scope.branchIds.filter(Boolean))];
  const allBranches = branches.includes('*');
  const result = await query(
    `SELECT * FROM public.ministry_annual_plans
     WHERE id = $1 AND tenant_id = $2
       AND ($3::boolean OR branch_id = ANY($4::text[]))
     LIMIT 1`,
    [planId, scope.tenantId, allBranches, branches],
  );
  return result.rows[0] ? mapMinistryAnnualPlanRow(result.rows[0]) : null;
}
