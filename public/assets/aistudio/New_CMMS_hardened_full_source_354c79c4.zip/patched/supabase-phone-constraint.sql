-- =========================================================================
-- CHURCH MANAGEMENT SYSTEM (CMMS) - ETHIOPIAN PHONE CONSTRAINT & NORMALIZATION
-- =========================================================================
-- Regex Specification:
--   - Local 10-digit format starting with '09' (e.g. 0910109191)
--   - Local 10-digit format starting with '07' (e.g. 0712345678)
--   - International 13-character format starting with '+2519' or '+2517' (e.g. +251910109191 or +251712345678)
-- Pattern: ^(09|07|\+2519|\+2517)[0-9]{8}$
-- =========================================================================

-- 1. Helper function to normalize Ethiopian phone numbers to standard E.164 (+251...)
CREATE OR REPLACE FUNCTION public.normalize_ethiopian_phone(phone_input TEXT)
RETURNS TEXT AS $$
DECLARE
  cleaned TEXT;
BEGIN
  IF phone_input IS NULL OR TRIM(phone_input) = '' THEN
    RETURN NULL;
  END IF;

  -- Strip all whitespace, hyphens, and parentheses
  cleaned := regexp_replace(TRIM(phone_input), '[\s\-\(\)]', '', 'g');

  -- Convert 09XXXXXXXX -> +2519XXXXXXXX
  IF cleaned ~ '^09[0-9]{8}$' THEN
    RETURN '+2519' || SUBSTRING(cleaned FROM 3);
  END IF;

  -- Convert 07XXXXXXXX -> +2517XXXXXXXX
  IF cleaned ~ '^07[0-9]{8}$' THEN
    RETURN '+2517' || SUBSTRING(cleaned FROM 3);
  END IF;

  -- Convert 2519XXXXXXXX -> +2519XXXXXXXX
  IF cleaned ~ '^251(9|7)[0-9]{8}$' THEN
    RETURN '+' || cleaned;
  END IF;

  -- Already in valid international format +2519... or +2517...
  IF cleaned ~ '^\+251(9|7)[0-9]{8}$' THEN
    RETURN cleaned;
  END IF;

  RETURN cleaned;
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- 2. Clean existing phone data in public.profiles (if any) before applying constraint
UPDATE public.profiles
SET phone = public.normalize_ethiopian_phone(phone)
WHERE phone IS NOT NULL AND phone != '';

-- Drop existing constraint if it exists to allow re-running
ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS check_profiles_ethiopian_phone;

-- Add strict CHECK constraint on profiles.phone
ALTER TABLE public.profiles
  ADD CONSTRAINT check_profiles_ethiopian_phone
  CHECK (
    phone IS NULL 
    OR phone = '' 
    OR phone ~ '^(09|07|\+2519|\+2517)[0-9]{8}$'
  );


-- 3. Clean existing phone data in public.members (if any) before applying constraint
UPDATE public.members
SET phone = public.normalize_ethiopian_phone(phone)
WHERE phone IS NOT NULL AND phone != '';

-- Drop existing constraint if it exists
ALTER TABLE public.members
  DROP CONSTRAINT IF EXISTS check_members_ethiopian_phone;

-- Add strict CHECK constraint on members.phone
ALTER TABLE public.members
  ADD CONSTRAINT check_members_ethiopian_phone
  CHECK (
    phone IS NULL 
    OR phone = '' 
    OR phone ~ '^(09|07|\+2519|\+2517)[0-9]{8}$'
  );


-- 4. Optional: Automatic Normalization Trigger to standardize stored values to E.164 (+251...)
CREATE OR REPLACE FUNCTION public.trigger_normalize_phone()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.phone IS NOT NULL AND NEW.phone != '' THEN
    NEW.phone := public.normalize_ethiopian_phone(NEW.phone);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_normalize_profiles_phone ON public.profiles;
CREATE TRIGGER trg_normalize_profiles_phone
  BEFORE INSERT OR UPDATE OF phone ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_normalize_phone();

DROP TRIGGER IF EXISTS trg_normalize_members_phone ON public.members;
CREATE TRIGGER trg_normalize_members_phone
  BEFORE INSERT OR UPDATE OF phone ON public.members
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_normalize_phone();
