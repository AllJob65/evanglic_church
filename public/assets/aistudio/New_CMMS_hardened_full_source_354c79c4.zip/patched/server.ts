import express from 'express';
import http from 'http';
import path from 'path';
import compression from 'compression';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Import real-time & queue services
import { socketService } from './src/services/socketService';
import { queueService } from './src/services/queueService';

// Import modular v4 REST routes & controllers
import modularRoutes from './src/routes';

// Import route modules
import authRoutes from './server/routes/auth';
import memberRoutes from './server/routes/members';
import branchRoutes from './server/routes/branches';
import attendanceRoutes from './server/routes/attendance';
import pastoralRoutes from './server/routes/pastoral';
import volunteerRoutes from './server/routes/volunteers';
import auditRoutes from './server/routes/audit';
import systemRoutes from './server/routes/system';
import aiRoutes from './server/routes/ai';
import integrationRoutes from './server/routes/integrations';
import accessibilityRoutes from './server/routes/accessibility';
import workflowRoutes from './server/routes/workflows';
import ministryCollabRoutes from './server/routes/ministryCollab';
import videoConferenceRoutes from './server/routes/videoConferences';
import groupChatRoutes from './server/routes/groupChats';
import externalApiRoutes from './server/routes/externalApi';
import bibleRoutes from './server/routes/bible';
import devotionRoutes from './server/routes/devotions';
import conversationRoutes from './server/routes/conversations';
import ministryPlansRoutes from './server/routes/ministryPlans';
import communicationsRoutes from './server/routes/communications';
import registrationLinksRoutes from './server/routes/registrationLinks';
import { globalErrorHandler } from './src/middleware/errorHandler';
import { generalAuthenticatedLimiter } from './server/middleware/rateLimiter';
import { initRateLimitRedisFromEnv } from './server/middleware/rateLimitStore';
import { initBackupScheduler } from './server/services/backupService';
import { testConnection } from './server/pg';
import cookieParser from 'cookie-parser';
import {
  strictCorsMiddleware,
  helmetSecurityMiddleware,
  enforceHttps,
  permissionsPolicy,
} from './server/middleware/httpSecurity';

const app = express();
const httpServer = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;
const IS_VERCEL = Boolean(process.env.VERCEL);

// Configure reverse proxy trust correctly for Cloud Run / Vercel / Nginx
app.set('trust proxy', 1);

// 1. HTTPS enforcement (production only)
app.use(enforceHttps);

// 2. Strict CORS middleware (rejects wildcard '*' for authenticated traffic)
app.use(strictCorsMiddleware);

// 3. Helmet security headers (CSP, HSTS, X-Content-Type-Options, Referrer-Policy)
app.use(helmetSecurityMiddleware);

// 4. Permissions-Policy headers
app.use(permissionsPolicy);

// 5. HTTP Response Compression (gzip/deflate for high throughput)
app.use(compression());

// 6. Cookie parsing with secure defaults
app.use(cookieParser());

// Initialize Socket.io real-time engine (only in persistent server mode)
if (!IS_VERCEL) {
  socketService.init(httpServer);
}

// Middleware for body parsing (tightened to safe 2MB limit)
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// Basic request logger & Vercel rewrite URL normalization
app.use((req, _res, next) => {
  // Restore original sub-path if rewritten by Vercel to /api or /api/index?__path=...
  const rewrittenSubPath = typeof req.query?.__path === 'string' ? req.query.__path : '';
  if (rewrittenSubPath && (req.path === '/api' || req.path === '/api/' || req.path === '/api/index')) {
    const cleanSub = rewrittenSubPath.replace(/^\/+/, '');
    const rawQuery = req.url.includes('?') ? req.url.split('?')[1] : '';
    const searchParams = new URLSearchParams(rawQuery);
    searchParams.delete('__path');
    const qs = searchParams.toString();
    req.url = `/api/${cleanSub}${qs ? `?${qs}` : ''}`;
  } else if (!req.url.startsWith('/api') && (IS_VERCEL || req.originalUrl?.startsWith('/api'))) {
    req.url = `/api${req.url.startsWith('/') ? '' : '/'}${req.url}`;
  }
  if (req.path.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.path}`);
  }
  next();
});

// Health check & System stats
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'CMMS Sovereign Enterprise Backend',
    version: '5.0.0',
    realtime: {
      socketIoActive: Boolean(socketService.getIO()),
    },
    queue: queueService.getStats(),
  });
});

// Apply general rate limiter across all /api routes (health checks are excluded)
app.use('/api', generalAuthenticatedLimiter);

// Consolidated /api/v1 Modular REST API
app.use('/api/v1', modularRoutes);
app.use('/api/v4', modularRoutes);
app.use('/api/approvals', modularRoutes);

// Register existing API routes for backwards compatibility
app.use('/api/auth', authRoutes);
app.use('/api/members', memberRoutes);
app.use('/api/branches', branchRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/pastoral', pastoralRoutes);
app.use('/api/volunteers', volunteerRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/system', systemRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/integrations', integrationRoutes);
app.use('/api/accessibility', accessibilityRoutes);
app.use('/api/workflows', workflowRoutes);
app.use('/api/ministry-collab', ministryCollabRoutes);
app.use('/api/ministry-plans', ministryPlansRoutes);
app.use('/api/v1/ministry-plans', ministryPlansRoutes);
app.use('/api/communications', communicationsRoutes);
app.use('/api/v1/communications', communicationsRoutes);
app.use('/api/registration-links', registrationLinksRoutes);
app.use('/api/v1/registration-links', registrationLinksRoutes);
app.use('/api/video-conferences', videoConferenceRoutes);
app.use('/api/group-chats', groupChatRoutes);
app.use('/api/conversations', conversationRoutes);
app.use('/api/bible', bibleRoutes);
app.use('/api/v1/bible', bibleRoutes);
app.use('/api/devotions', devotionRoutes);
app.use('/api/v1/devotions', devotionRoutes);
app.use('/api/v1/external', externalApiRoutes);
app.use('/api/external', externalApiRoutes);

// Never return HTML from an API endpoint: catch any unmatched /api/* route and return structured JSON 404
app.all('/api/*', (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  return res.status(404).json({
    success: false,
    error: 'ENDPOINT_NOT_FOUND',
    code: 'ENDPOINT_NOT_FOUND',
    message: `API endpoint ${req.method} ${req.originalUrl} not found.`,
  });
});

// Global Error Handler for API routes
app.use(globalErrorHandler);

async function startServer() {
  await initRateLimitRedisFromEnv();
  // Initialize automated background backup cron scheduler
  initBackupScheduler();

  // Start listening on PORT 3000 immediately so health probes and dev server checks succeed without delay
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`[CMMS Server] Running at http://0.0.0.0:${PORT} in ${process.env.NODE_ENV || 'development'} mode`);
  });

  // Vite middleware for dev or high-performance static server for production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');

    // Serve static files with intelligent cache headers
    app.use(
      express.static(distPath, {
        maxAge: '1y',
        etag: true,
        lastModified: true,
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('index.html')) {
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
          } else if (filePath.includes(path.join('dist', 'assets'))) {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          } else {
            res.setHeader('Cache-Control', 'public, max-age=86400, stale-while-revalidate=604800');
          }
        },
      })
    );

    // Single-Page Application (SPA) HTML fallback
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Database migrations are an explicit release operation (npm run migrate),
  // never an automatic side effect of server startup or a serverless cold start.
  if (process.env.DATABASE_URL) {
    testConnection()
      .then((conn) => {
        if (conn.ok) {
          console.log(
            `[PostgreSQL] Connectivity verified for database '${conn.database || 'default'}' (${conn.latencyMs}ms). Migrations are not run automatically.`
          );
        } else {
          console.error(`[PostgreSQL] DATABASE_URL is configured but the connection failed: ${conn.message}`);
        }
      })
      .catch((dbErr: any) => {
        console.error(`[PostgreSQL] Database connectivity check failed: ${dbErr?.message || dbErr}`);
      });
  }
}

if (!IS_VERCEL) {
  startServer().catch((err) => {
    console.error('[CMMS Server] Failed to start server:', err);
    process.exit(1);
  });
}

export { app };
export default app;
